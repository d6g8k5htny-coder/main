import ResearchFormalCoreR1
theorem injected : False := by sorry
#print axioms injected
