import ResearchFormalCoreR1
theorem injected : (2 : Nat) + 2 = 4 := by native_decide
#print axioms injected
