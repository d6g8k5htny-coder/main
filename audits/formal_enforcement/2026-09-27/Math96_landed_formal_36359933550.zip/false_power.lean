import ResearchFormalCoreR1
example : (2 : Real)^4 <= (2 : Real)^3 := by
  norm_num
