import ResearchFormalCoreR1
axiom hiddenPremise : False
theorem middle : False := hiddenPremise
theorem injected : False := middle
#print axioms injected
