import UniversalLaw
theorem injected : (2 : Nat) + 2 = 4 := by native_decide
#print axioms injected
