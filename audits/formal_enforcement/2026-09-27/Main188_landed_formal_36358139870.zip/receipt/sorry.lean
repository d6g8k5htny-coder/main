import UniversalLaw
theorem injected : False := by sorry
#print axioms injected
