#!/usr/bin/env python3
"""Replay the pinned recovered Lean sources with two required rejection controls.

The input package is a local additive recovery, not the lost original project.
Only its algebraic theorem companions are checked. No register is modified.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time
from datetime import datetime, timezone


def identity(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', required=True, type=Path)
    parser.add_argument('--lean-bin', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    project, out = args.project.resolve(), args.output.resolve()
    if out == project or project in out.parents:
        raise ValueError('output must be outside the recovered source project')
    out.mkdir(mode=0o700)
    env = os.environ.copy()
    env['PATH'] = str(args.lean_bin.resolve()) + os.pathsep + env.get('PATH', '')
    sources = [project/'ResearchFormalCoreR1.lean', *sorted((project/'ResearchFormalCoreR1').glob('*.lean')),
               project/'lean-toolchain', project/'lakefile.toml', project/'lake-manifest.json']
    before = {str(p.relative_to(project)): identity(p) for p in sources}
    manifest = json.loads((project/'lake-manifest.json').read_text())
    mathlib = [p for p in manifest['packages'] if p['name'] == 'mathlib']
    if len(mathlib) != 1 or mathlib[0]['rev'] != 'c44e0c8ee63ca166450922a373c7409c5d26b00b':
        raise ValueError('matching pinned Mathlib revision is required')
    if (project/'lean-toolchain').read_text().strip() != 'leanprover/lean4:v4.19.0':
        raise ValueError('Lean v4.19.0 is required')
    declarations = []
    for p in sources:
        if p.suffix == '.lean':
            for name, statement in re.findall(r'^theorem\s+(\w+)(.*?)\s*:= by', p.read_text(), re.M | re.S):
                declarations.append({'name': 'ResearchFormalCoreR1.'+name,
                                     'source': str(p.relative_to(project)),
                                     'statement_text_sha256': hashlib.sha256(statement.encode()).hexdigest()})
    if len(declarations) != 13 or len({d['name'] for d in declarations}) != 13:
        raise ValueError('the recovered target set must contain exactly 13 distinct theorem declarations')
    report = {'schema': 'recovered-lean-verification/v1', 'started_utc': datetime.now(timezone.utc).isoformat(),
              'status': 'FAIL', 'source_inputs': before, 'mathlib': mathlib[0], 'declarations': declarations,
              'steps': [], 'scientific_promotions': 0, 'independence_credit': 0,
              'scope': 'Lean compilation of 13 recovered algebraic theorem companions; surrounding analytic/probability premises remain unformalized.'}

    def run(name, argv, expect_success=True, diagnostic=None):
        log = out/(name+'.log')
        start = time.monotonic()
        with log.open('xb') as stream:
            process = subprocess.Popen(argv, cwd=project, env=env, stdout=stream,
                                       stderr=subprocess.STDOUT, start_new_session=True)
            timed_out = False
            try:
                code = process.wait(timeout=300)
            except subprocess.TimeoutExpired:
                timed_out = True
                os.killpg(process.pid, signal.SIGKILL)
                code = process.wait(timeout=10)
        text = log.read_text(errors='replace')
        passed = not timed_out and ((code == 0) if expect_success else
                                    (code != 0 and 'error:' in text and diagnostic in text))
        step = {'name': name, 'argv': argv, 'returncode': code, 'timed_out': timed_out,
                'expected': 'SUCCESS' if expect_success else 'REJECT_FALSE_STATEMENT',
                'passed': passed, 'elapsed_seconds': time.monotonic()-start,
                'log': log.name, 'log_identity': identity(log)}
        report['steps'].append(step)
        print(json.dumps(step), flush=True)
        return passed, text

    try:
        passed, version = run('version', ['lean', '--version'])
        if not passed or 'version 4.19.0' not in version:
            raise ValueError('wrong compiler version')
        report['compiler_binary'] = identity(args.lean_bin.resolve()/'lean')
        if not run('build', ['lake', 'build'])[0]:
            raise ValueError('build failed')
        # Direct source elaboration runs even when Lake already has a cache.
        for path in sources:
            if path.suffix == '.lean':
                if not run('elaborate_'+path.stem, ['lake', 'env', 'lean', str(path)])[0]:
                    raise ValueError('source elaboration failed: '+path.name)
        axioms = out/'AxiomAudit.lean'
        axioms.write_text('import ResearchFormalCoreR1\n' + '\n'.join('#print axioms '+d['name'] for d in declarations)+'\n')
        passed, text = run('axioms', ['lake', 'env', 'lean', str(axioms)])
        lists = re.findall(r'depends on axioms: \[(.*?)\]', text, re.S)
        allowed = {'propext', 'Classical.choice', 'Quot.sound'}
        used = {x.strip() for group in lists for x in group.split(',') if x.strip()}
        if not passed or 'sorryAx' in text or used-allowed or not all(d['name'] in text for d in declarations):
            raise ValueError('unexpected or missing theorem axiom report')
        report['axioms_observed'] = sorted(used)
        report['axiom_audit_source'] = identity(axioms)
        counterexamples = out/'Counterexamples.lean'
        counterexamples.write_text('import Mathlib\nexample : ¬ ((4/3:ℝ) = (8/7:ℝ)) := by norm_num\nexample : ¬ ((1:ℝ) ≤ 1/2) := by norm_num\n')
        if not run('counterexamples', ['lake', 'env', 'lean', str(counterexamples)])[0]:
            raise ValueError('explicit counterexamples did not elaborate')
        report['counterexample_source'] = identity(counterexamples)
        original = (project/'ResearchFormalCoreR1/Algebra.lean').read_text()
        if original.count('(2 * s) ^ 3 / 6') != 1:
            raise ValueError('fold negative control target changed')
        fold = out/'WrongFoldGap.lean'
        fold.write_text(original.replace('(2 * s) ^ 3 / 6', '(2 * s) ^ 3 / 7'))
        if not run('reject_wrong_fold_gap', ['lake', 'env', 'lean', str(fold)], False, 'unsolved goals')[0]:
            raise ValueError('wrong fold gap was not decisively rejected')
        original = (project/'ResearchFormalCoreR1/ProbabilityCompanions.lean').read_text()
        target = 'n / z ≤ (Real.sqrt cW / cZ) * Real.sqrt q := by'
        if original.count(target) != 1:
            raise ValueError('quotient negative control target changed')
        quotient = out/'WrongQuotient.lean'
        quotient.write_text(original.replace(target, 'n / z ≤ (Real.sqrt cW / (2*cZ)) * Real.sqrt q := by'))
        if not run('reject_wrong_quotient', ['lake', 'env', 'lean', str(quotient)], False, 'error:')[0]:
            raise ValueError('wrong quotient was not decisively rejected')
        report['negative_control_sources'] = {p.name: identity(p) for p in (fold, quotient)}
        after = {str(p.relative_to(project)): identity(p) for p in sources}
        if after != before:
            raise ValueError('source inputs changed during verification')
        report['source_inputs_unchanged'] = True
        report['status'] = 'PASS_AT_RECOVERED_ALGEBRA_SCOPE'
    except Exception as exc:
        report['error'] = type(exc).__name__+': '+str(exc)
    report['ended_utc'] = datetime.now(timezone.utc).isoformat()
    canonical = json.dumps(report, sort_keys=True, separators=(',', ':')).encode()
    report['payload_sha256'] = hashlib.sha256(canonical).hexdigest()
    destination = out/'report.json'
    with destination.open('x') as stream:
        json.dump(report, stream, indent=2, sort_keys=True); stream.write('\n')
    for p in out.iterdir():
        p.chmod(0o444)
    out.chmod(0o555)
    print(report['status'], str(destination), flush=True)
    return 0 if report['status'].startswith('PASS') else 1


if __name__ == '__main__':
    raise SystemExit(main())
