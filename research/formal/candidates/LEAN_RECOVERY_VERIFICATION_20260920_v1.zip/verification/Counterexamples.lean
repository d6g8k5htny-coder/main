import Mathlib
example : ¬ ((4/3:ℝ) = (8/7:ℝ)) := by norm_num
example : ¬ ((1:ℝ) ≤ 1/2) := by norm_num
