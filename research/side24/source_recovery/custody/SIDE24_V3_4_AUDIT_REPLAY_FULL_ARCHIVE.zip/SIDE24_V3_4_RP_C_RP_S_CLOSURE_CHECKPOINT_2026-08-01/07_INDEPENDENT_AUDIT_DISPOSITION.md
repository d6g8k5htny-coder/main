# SIDE24 independent-audit disposition

**Date:** 2026-07-31  
**Input:** `SIDE24_INDEPENDENT_AUDIT_SNAPSHOT_2026-07-31.zip`  
**Controlling result:** **ACCEPT the local verification evidence; REJECT the
theorem-level closure claim; retain HOLD.**

## 1. Executive disposition

The audit is high-quality evidence for several local calculations.  Its four
independent scripts rerun with 54/54 checks passing, its six fresh historical
transcripts are byte-identical to the committed transcripts, and its GOE
calculation independently recovers

```text
D_2 = 29/6 - sqrt(6).
```

Those results strengthen coefficient provenance.  They do not exercise the
remaining proof interfaces.  Searches of all four independent scripts find
no Palm transfer, finite-r joint blow-up, regional witness estimate, or elder
selection calculation.  The theorem-level statement that every load-bearing
derivation re-verifies is therefore unsupported.

The audit also correctly finds the negative kappa-linear sign in
`-det H_S`, but incorrectly labels the sign error non-load-bearing.  Once the
omitted third witness-value pin is restored, that sign controls the contact
cancellation itself.  Section 3 gives the exact calculation.

## 2. Finding-by-finding reconciliation

| Audit item | V3.1 disposition | Exact scope |
|---|---|---|
| R1-R6 historical reruns | **ACCEPTED — local reproduction** | All six pass normally and reproduce their transcripts byte-for-byte.  Their 63 bare `assert` statements make optimized-mode PASS output non-evidentiary. |
| 54/54 independent checks | **ACCEPTED — narrower than reported** | Strong evidence for the formulas actually checked; not a coverage count for the theorem. |
| Constants suite | **ACCEPTED — local arithmetic** | Checks gamma/c3 formula equivalence, one isotropic substitution, radial/pushforward arithmetic, one Gaussian integral, and four numerical Poisson-identity points.  It does not check `I_5`, `P_3(24)`, the assembled `e^-288` correction, or the certified epsilon bound. |
| First-variation suite | **ACCEPTED — local moment algebra** | Independently recovers `P_3(L)` and `P_3(24)`.  It imports the isotropic projection and logarithmic coefficient law and does not prove differentiability, remainder control, or finite-volume transfer. |
| B.1 suite | **ACCEPTED — obsolete ten-condition diagnostic only** | Correctly re-derives the raw unpinned formulas and the negative sign.  It omits `p(P)=-alpha*kappa/6`, so it cannot validate the typed value-window contact event or G6-prime. |
| GOE suite | **ACCEPTED — local coefficient** | Exact symbolic `D_2`, covariance, GOE-plus-scalar law, density normalization, and moment checks survive independent rerun.  Monte Carlo is corroborative only. |
| F2 sign correction | **ACCEPTED and upgraded to load-bearing** | V3 already carries the negative sign.  The new regression proves the positive sign destroys the value-pinned `eta^2` cancellation. |
| F1 stale `CHANGE_LOG` row | **ACCEPTED for original V2** | Direct audit of the actual original binaries gives 23/24 matches; only this row differs. |
| Binary limitation | **RESOLVED here** | The original six PDFs and DOCX are available in this workspace and all seven match their V2 manifest entries. |
| N1 “B.1 + G6-prime checks out” | **REJECTED** | The suite omits the third value pin and every finite-r/Palm interface. |
| N2 GOE convention echo | **ACCEPTED editorially** | Future technical appendices should say: diagonal `N(0,2)`, off-diagonal `N(0,1)`. |
| N3 sanity-check note | **ACCEPTED** | Useful audit-trail evidence; no mathematical status change. |
| “Both bundles content-clean except F2” | **REJECTED as overbroad** | A targeted glyph sweep checks selected strings, not every derivation or logical interface. |
| Candidate theorem reverified | **REJECTED** | None of RP-A/RP-L, RP-C/RP-S, RP-F, or uniform elder selection is closed. |

## 3. Why the sign is load-bearing

Write `d=q_M-q_S`, `m=q_M+q_S`, and impose the missing third value

```text
p(P)=-alpha*kappa/6.
```

On the regular chart this gives

```text
m = [eta*d + kappa*eta*((2c+eta)^2-8alpha*c*eta)/(2s^2)]/(2c)
```

and

```text
u = [2s^2*d+kappa*(2c+eta)^2]/(8kappa*c*eta).
```

With the corrected negative kappa-linear sign, exact substitution gives

```text
-det H_S = (kappa^2*eta^2/s^2)
           *((u-1)^2-(1-alpha)).
```

With the positive sign printed in V2, the same value relation, expressed at a
fixed bounded normalized coordinate `u` on the typed support, gives instead

```text
lim_(eta->0) (-det H_S)_printed = c^2*kappa^2/s^2,
```

which is generically nonzero.  (At fixed raw `d`, even the corrected square
coordinate can diverge; the type cone is what keeps `u` bounded.)  Thus the
wrong sign removes two powers of
`eta` from this endpoint determinant and prevents the claimed three-factor
`eta^6` product suppression.  Taking `abs(det H_S)` cannot repair a wrong
cross-term before the cancellation.

The exact check is
`scripts/verify_value_pinned_sign_impact.py`.

## 4. Two further precision corrections

The raw unpinned product is generically degree six in `kappa`; “exact degree
six” is not uniform on its leading-coefficient zero set.  Degree can drop at
`2c=+/-eta`.  These loci are coefficient-degeneracy loci, not geometric point
collisions by themselves.  Indeed,

```text
|P-S|^2 = ((2c-eta)^2+4s^2)/(4eta^2),
|P-M|^2 = ((2c+eta)^2+4s^2)/(4eta^2).
```

Actual collision additionally requires `s=0`.  The V3 constrained-contact
draft already uses this distinction.

## 5. Reproduction engineering

The six historical scripts are mathematically passing in ordinary Python,
but contain 63 bare assertions and print success unconditionally.  All six
therefore emit byte-identical PASS transcripts under `python -O`, when their
checks have been removed.

The four independent scripts avoid bare assertions and remain active under
optimization, but still return process status zero after a failed check.  The
new `scripts/run_external_audit_checks.py` makes them fail-closed by requiring:

1. process status zero;
2. no `FAIL` marker;
3. terminal `ALL_ASSERTIONS_PASS`;
4. byte identity with the preserved transcript; and
5. byte identity between normal and optimized runs.

The reviewer scripts themselves remain unmodified as provenance evidence.

## 6. Controlling open gates

The independent suite does not address:

- **RP-A/RP-L:** determinant-weighted Palm normalization, weighted coarea,
  shallow-eigenvalue control, and weighted tail transfer;
- **RP-C/RP-S:** finite-r collar and singular-near joint compactifications,
  boundary-family independence, covariance floors or mean mismatch, and
  compatible three-Hessian envelopes;
- **RP-F:** independent fixed-distance endpoint-factor audit; or
- recombination into uniform elder selection.

The candidate theorem remains **HOLD**.  Packaging and further decimal checks
are lower priority than these interfaces.

## 7. Next work order

1. Prove the determinant-weighted shallow-eigenvalue/coarea estimate and
   polynomial exact-field approximation bounds required by RP-A/RP-L.
2. Construct and audit the joint `(r,rho)` collar compactification.
3. Construct and audit the joint `(t,rho)` singular-near compactification,
   including the angular axis.
4. Re-audit RP-F and recombine the five disjoint elder-failure terms.
5. Change HOLD only after independent review of those arguments.
