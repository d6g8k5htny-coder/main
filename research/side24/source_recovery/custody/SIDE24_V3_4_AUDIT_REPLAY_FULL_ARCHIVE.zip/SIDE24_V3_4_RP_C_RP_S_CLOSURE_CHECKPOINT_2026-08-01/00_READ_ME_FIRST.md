# SIDE24 V3.4 RP-C/RP-S closure checkpoint

**Checkpoint date:** 2026-08-01 (America/Chicago)  
**Project status:** **HOLD — new regional proof awaits independent audit; do not submit**

This is a new, non-overwriting successor to V3.3.  It preserves the complete
V3.3 adjudication layer and executes the seven-part anisotropic work order
that V3.3 left open.  The controlling new proof is
`drafts/rp_c_rp_s_facewise_closure.md`; its concise disposition is
`13_RP_C_RP_S_CLOSURE_DISPOSITION.md`.

The V3.4 advance is:

- the exact generic transverse side-24 Schur comparison;
- a separate axial Hermite blow-up, including fifth-order midpoint and
  endpoint charts;
- a pair-pin-measurable mixed singular frame with exact raw Jacobian,
  both anisotropic factors, full contact/collinear boundary rank, and a
  quantified collinear ESIP;
- one density-weighted three-Hessian monomial
  `[r(r+s^2)]^2(r^2+s^3)` pointwise off the endpoint-axis, plus the exact
  measure-level endpoint-axis replacement forced by a counterexample;
- a deterministic noncollinear bound and an axial ESIP-weighted replacement,
  rather than the false stronger pathwise claim on the exact axis; and
- complete collar and singular-near Kac--Rice ledgers, including endpoint
  collisions and the angular axis.

Accordingly RP-C and RP-S are **proved in the V3.4 draft, awaiting independent
audit**, and the compact-positive-mark elder-selection premise list is empty.
The HOLD is retained under the V3.3 promotion protocol until the new face
families, moment lemma, and integrations have been independently reviewed.

## Controlling order

If two files conflict, use this order:

1. `13_RP_C_RP_S_CLOSURE_DISPOSITION.md` and
   `drafts/rp_c_rp_s_facewise_closure.md`;
2. `11_V5_FORWARD_BRANCH_ADJUDICATION.md` for V5 claims not superseded by
   V3.4;
3. `09_AUDIT_RECONCILIATION_RESPONSE.md`;
4. `07_INDEPENDENT_AUDIT_DISPOSITION.md` for earlier audit claims not
   superseded by the reconciliation or V3.3;
5. `01_V3_CORRECTIVE_CHECKPOINT.md` and the earlier drafts in `drafts/`;
6. `baseline/11_COMPLETE_PRE_REVIEW_PACKET_R2.pdf`;
7. uploaded closure bundles and preserved audit snapshots, for provenance
   only.

Within tier 1, the detailed controlling companion is
drafts/three_hessian_conditional_moment_envelope.md.  The quartic remainder
note is a controlling negative regression for the rejected stronger route.

No `CLOSED` label in V2--V5 overrides this checkpoint.

## What the preserved V5 branch genuinely added

- The 128-entry source ZIP passes CRC and path-safety checks.
- Its V5 manifest is exact: 127/127 non-self payload hashes and the self-prefix
  hash match.
- All twelve delivered scripts pass in normal and optimized Python; all 24
  outputs are byte-identical to the committed transcripts.
- Verifier v7 passes 23/23 and v8 passes 30/30 in both modes.  Verifier v8's
  theorem-status checks are textual and are not treated as proof.
- The exact endpoint soft factor `det H_p=rD_p` and the corrected contact limit
  give the normalizer asymptotic
  \[
  r^{-2}W_r\longrightarrow
  \kappa^2(\det Q)^2\mathbf1_{\{Q\prec0\}}.
  \]
- A polynomial-threshold Gaussian tube estimate, the missing cross-endpoint
  Weyl bridge, and polynomial high-jet truncation close RP-A and RP-L.
- Exact collar and singular-near determinant regressions identify the correct
  boundary monomials and exposed the axial and midpoint faces that were still
  open at the V5 stage; the V3.4 draft addresses them.

## Package-lineage result

The V5 manifest is exact for the current archive, but the shared
`SIDE24_gap_fill/` tree is not immutable.  Against the V5 archive, V4 has
106/108 matching referents and V3 has 24/37.  Two shared paths were overwritten
between V4 and V5, so the branch's “nothing was overwritten” statement is
false for historical evidence.  V5 also omits the controlling V3.2 checkpoint
identity.  V3.3 therefore treats it as a preserved parallel branch, not a
silent successor.

## Reproduce the checks

Use Python 3.11 or later:

```bash
python -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/python scripts/run_v3_checks.py
.venv/bin/python scripts/run_external_audit_checks.py
```

The final lines must be `ALL_V3_CHECKS_PASS` and
`ALL_EXTERNAL_AUDIT_RUNNER_CHECKS_PASS`.  The V3.4 runner compares normal and
optimized output for the checkpoint checks; the frozen V5 audit internally
does the same for its twelve scripts and verifiers v7/v8.  All fail through
explicit exceptions or nonzero child exits.

## Reading order

The detailed sixth-gate proof is
drafts/three_hessian_conditional_moment_envelope.md; read it immediately
after the controlling facewise note.  The quartic regression note records
why the stronger all-face pathwise claim was rejected.

1. `13_RP_C_RP_S_CLOSURE_DISPOSITION.md`
2. `drafts/rp_c_rp_s_facewise_closure.md`
3. `drafts/three_hessian_conditional_moment_envelope.md`
4. `drafts/generic_transverse_collar_face.md`
5. `drafts/mixed_singular_transition_face.md`
6. `evidence/COLLAR_PROJECTIVE_CHART_AUDIT_2026-08-01.md`
7. `evidence/HYBRID_SECTION6_INDEPENDENT_AUDIT_2026-08-01.md`
8. `drafts/quartic_remainder_audit_note.md`
9. `01_V3_CORRECTIVE_CHECKPOINT.md`
10. `02_GAP_REGISTER.csv`
11. `11_V5_FORWARD_BRANCH_ADJUDICATION.md`
12. `12_V5_PACKAGE_LINEAGE_MATRIX.csv`
13. `drafts/palm_transfer_repair_v3_3.md`
14. `drafts/rp_f_global_envelope_counterexample.md`
15. `drafts/joint_collar_compactification_target.md`
16. `09_AUDIT_RECONCILIATION_RESPONSE.md`
17. `10_PACKAGE_SCOPE_MATRIX.csv`
18. `07_INDEPENDENT_AUDIT_DISPOSITION.md`
19. the frozen R2 baseline PDF as needed

The scripts certify their stated algebraic, executable, diagnostic, or
package-integrity scopes only.  The analytic finite-\(r\) comparison,
conditional-moment, and Kac--Rice arguments are in the V3.4 proof note; a
passing script is not a substitute for their independent review.
