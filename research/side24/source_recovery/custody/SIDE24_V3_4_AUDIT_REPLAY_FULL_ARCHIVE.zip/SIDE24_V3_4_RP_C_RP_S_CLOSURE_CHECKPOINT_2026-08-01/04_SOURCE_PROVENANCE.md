# Source provenance

## Frozen baseline

- File: `baseline/11_COMPLETE_PRE_REVIEW_PACKET_R2.pdf`
- Package identifier inside the file: `SIDE24-PRE-REVIEW-2026-07-31-R2`
- SHA-256: `b652a8b31820a458b43b46d7f83eb5b842b973c0a8bd37d8cb9e0ff95cb9c83f`
- Role: authoritative pre-V3 mathematical baseline; candidate/open status

## Audited V2 attachment

- File name: `OKComputer_Project_Gap_Closure.zip`
- SHA-256: `7285eba7c789a26b80cb8a9d69bc8929b28be0b8cb522981530bbdcb7066f93e`
- Role: provenance and regression evidence only; the source ZIP is not
  embedded wholesale, but all 24 manifest referents are preserved verbatim
  under `evidence/original_v2/`; not authoritative

## Independent audit snapshot

- File: `evidence/independent_audit/SIDE24_INDEPENDENT_AUDIT_SNAPSHOT_2026-07-31.zip`
- SHA-256: `9e2e0637706685692cdce770f4c4e74c7154baaabbc319de77e6defd34ab5a01`
- Internal ledger: 16/16 payload files verified
- Role: independent local verification and review provenance; not a controlling
  theorem-status source

The audit's findings and run log are preserved verbatim beside the ZIP.  Its
four scripts and transcripts are copied verbatim under
`evidence/independent_audit/suite/` so the hardened runner can execute them.
The six historical scripts and committed transcripts are similarly preserved
under `evidence/historical_reproduction/`.

The original V2 manifest and all 24 of its referents are copied verbatim under
`evidence/original_v2/`.  This makes the direct 23/24 result, including all
seven binary matches, reproducible without the auditor's re-encoded mount.
`scripts/audit_original_v2_manifest.py` resolves the split V2/gap-fill paths
and enforces the expected single stale `CHANGE_LOG.md` row.

## Audit reconciliation snapshot

- File: `evidence/audit_reconciliation/SIDE24 AUDIT RECONCILIATION SNAPSHOT 2026-07-31.zip`
- SHA-256: `7be11c3e2ee6a185ca13bb91a18b656855ca3f458d853c93c5f5ba71fbb8a97e`
- Internal ledger: 8/8 payload files verified
- Independent verifier SHA-256:
  `6900e0c4c5717143fdb1d700744a755b1e5d64d3120ddaed48fbaaa7a21d57dc`
- Role: accepted independent confirmation of the V3.1 sign disposition and
  audit errata; no theorem-level authority

The reconciliation describes a 109-file V4 closure bundle for which neither
bytes nor a source SHA are present here.  Its package observations are retained
as externally reported and are not merged with the 64-file or 92-file uploads.
See `10_PACKAGE_SCOPE_MATRIX.csv`.

## V3.2 grandparent and V3.3 direct predecessor

- File: `SIDE24_V3_2_RECONCILIATION_CHECKPOINT_2026-07-31.zip`
- SHA-256: `5a17a8e6053943d969968229e9c509bf16abc686faee204f6e4fb78cd3c50407`
- Role: controlling grandparent through V3.3

V3.3 was cloned from the unpacked V3.2 checkpoint.

- Direct predecessor: SIDE24_V3_3_V5_ADJUDICATION_CHECKPOINT_2026-08-01.zip
- SHA-256: 4040d654bddb1fc3b22eafa87bea7d0875166c03150d12602d6c1a0cb6385cfc
- Local identity ledger: evidence/PREDECESSOR_V3_3_SHA256.txt

V3.4 was cloned from the frozen V3.3 directory into a new sibling directory.
Both predecessors remain unchanged and are identified by hash rather than
embedded recursively.

## V5 forward branch

- Uploaded name: `OKComputer_Project_Gap_Closure(1).zip`
- Preserved file:
  `evidence/v5_forward_branch/OKComputer_Project_Gap_Closure_1_119ffbfa.zip`
- SHA-256: `119ffbfae2d11cc2d3de60f15c06a653c48b17d06ab0a2e125260ab0f1458c5a`
- Regular files: 128; CRC and safe-path checks pass
- Current V5 manifest: 127/127 payloads plus valid self-prefix hash
- Historical referents against current shared bytes: V4 106/108; V3 24/37
- Role: preserved forward-work evidence and local identities; not a
  provenance-complete successor and not a controlling theorem-status source

The source branch labels V5 as 2026-08-02 but gives an explicit 2026-08-01
date and 2026-08-01 CDT PDF creation metadata.  V3.3 uses the declared
America/Chicago date and preserves the source labels without normalization.
See `11_V5_FORWARD_BRANCH_ADJUDICATION.md` and
`12_V5_PACKAGE_LINEAGE_MATRIX.csv`.

## V3.4 policy

V3.4 modifies none of the frozen sources, V3.3 checkpoint, or review evidence.
It adds the new facewise proof, companion calculations, and fail-closed
algebraic verifiers.  The singular calculation uses a pair-pin-measurable
raw frame; it does not reuse the historical subtraction of an unpinned
midpoint value.  The sixth work-order gate is stated in its correct hybrid
form: pathwise off the collinear axis, density-weighted with ESIP on that
axis, and measure-level on the axial endpoint where a genuine \(d^{-1}\)
pointwise factor remains.  The rejected stronger routes and their exact
regressions are preserved as audit evidence.  Algebraic and numerical scripts certify only their stated
equation or diagnostic scopes.  Proof status is controlled by the prose
status ledger and gap register, never by file names, dates, transcript strings,
or a successful script exit alone.
