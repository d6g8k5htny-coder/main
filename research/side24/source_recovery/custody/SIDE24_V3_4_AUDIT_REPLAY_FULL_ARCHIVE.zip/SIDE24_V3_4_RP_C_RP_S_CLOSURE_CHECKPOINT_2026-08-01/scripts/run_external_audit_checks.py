#!/usr/bin/env python3
"""Fail-closed runner for the preserved external audit scripts.

The four independent scripts use explicit checks but return status zero even
when a check fails.  This runner therefore requires a clean process exit, no
``FAIL`` marker, and an exact final ``ALL_ASSERTIONS_PASS`` line.  It also
runs the suite under optimized Python and requires byte-identical output.

The six historical reproduction scripts are run only in normal mode with
their committed transcripts.  Their bare ``assert`` statements disappear
under ``python -O``; optimized execution is deliberately not accepted as
evidence for those scripts.
"""

from __future__ import annotations

import ast
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
INDEPENDENT = ROOT / "evidence" / "independent_audit" / "suite"
HISTORICAL = ROOT / "evidence" / "historical_reproduction"

INDEPENDENT_SCRIPTS = [
    "verify_constants_v1_1.py",
    "verify_first_variation_v1_1.py",
    "verify_b1_elimination_v1_1.py",
    "verify_goe_cone_v1_1.py",
]
HISTORICAL_SCRIPTS = [
    "triple_contact_elimination.py",
    "contact_covariance_verification.py",
    "arithmetic_ledgers.py",
    "d2_closed_form.py",
    "goe_cone_coefficient.py",
    "first_variation_derivation.py",
]


def run(path: Path, optimized: bool = False) -> bytes:
    command = [sys.executable]
    if optimized:
        command.append("-O")
    command.append(str(path))
    completed = subprocess.run(command, capture_output=True, check=False)
    if completed.returncode != 0:
        raise RuntimeError(
            f"{path.name} returned {completed.returncode}:\n"
            f"{completed.stderr.decode(errors='replace')}"
        )
    if completed.stderr:
        raise RuntimeError(
            f"{path.name} wrote stderr:\n"
            f"{completed.stderr.decode(errors='replace')}"
        )
    return completed.stdout


def require_pass_transcript(path: Path, output: bytes) -> None:
    lines = output.decode("utf-8").splitlines()
    if not lines or lines[-1] != "ALL_ASSERTIONS_PASS":
        raise RuntimeError(f"{path.name} lacks a terminal ALL_ASSERTIONS_PASS")
    if any("FAIL" in line for line in lines):
        raise RuntimeError(f"{path.name} emitted a FAIL marker")


def bare_assert_count(path: Path) -> int:
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    return sum(isinstance(node, ast.Assert) for node in ast.walk(tree))


independent_checks = 0
for filename in INDEPENDENT_SCRIPTS:
    script = INDEPENDENT / filename
    normal = run(script)
    optimized = run(script, optimized=True)
    require_pass_transcript(script, normal)
    require_pass_transcript(script, optimized)
    if normal != optimized:
        raise RuntimeError(f"{filename} output changes under python -O")
    committed = script.with_name(script.stem + ".out.txt").read_bytes()
    if normal != committed:
        raise RuntimeError(f"{filename} output differs from preserved transcript")
    if bare_assert_count(script) != 0:
        raise RuntimeError(f"{filename} unexpectedly contains bare assert")
    independent_checks += 1
    print(f"INDEPENDENT_PASS = {filename}")

historical_asserts = 0
for filename in HISTORICAL_SCRIPTS:
    script = HISTORICAL / filename
    normal = run(script)
    committed = script.with_suffix(".out.txt").read_bytes()
    if normal != committed:
        raise RuntimeError(f"{filename} output differs from committed transcript")
    count = bare_assert_count(script)
    if count == 0:
        raise RuntimeError(f"{filename} no longer exhibits the recorded assert risk")
    historical_asserts += count
    print(f"HISTORICAL_NORMAL_MODE_PASS = {filename}; BARE_ASSERTS = {count}")

if historical_asserts != 63:
    raise RuntimeError(
        f"expected 63 historical bare asserts, found {historical_asserts}"
    )

print(f"INDEPENDENT_SCRIPT_COUNT = {independent_checks}")
print(f"HISTORICAL_SCRIPT_COUNT = {len(HISTORICAL_SCRIPTS)}")
print(f"HISTORICAL_BARE_ASSERT_COUNT = {historical_asserts}")
print(
    "SCOPE_LIMIT: transcript and local-equation reproducibility only; "
    "no global proof interface is exercised"
)
print("ALL_EXTERNAL_AUDIT_RUNNER_CHECKS_PASS")
