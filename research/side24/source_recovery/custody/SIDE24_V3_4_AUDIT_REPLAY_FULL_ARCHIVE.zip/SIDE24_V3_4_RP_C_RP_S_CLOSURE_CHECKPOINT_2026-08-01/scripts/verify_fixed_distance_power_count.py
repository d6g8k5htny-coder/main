#!/usr/bin/env python3
"""Exact algebra and power ledger for the RP-F fixed-distance bound.

The accompanying proof supplies covariance nondegeneracy and conditional
Kac--Rice uniformity.  This script checks only the exact endpoint determinant
factor and the final radial power count, with explicit exceptions under -O.
"""

from __future__ import annotations

import sympy as sp


def require_zero(label: str, expression: sp.Expr) -> None:
    remainder = sp.factor(sp.cancel(sp.together(expression)))
    if remainder != 0:
        raise RuntimeError(f"{label} failed; residual={remainder}")


r = sp.symbols("r", nonzero=True)
a_m, b_m1, b_m2 = sp.symbols("a_M b_M1 b_M2")
a_s, b_s1, b_s2 = sp.symbols("a_S b_S1 b_S2")
q_m11, q_m12, q_m22 = sp.symbols("q_M11 q_M12 q_M22")
q_s11, q_s12, q_s22 = sp.symbols("q_S11 q_S12 q_S22")


def endpoint_hessian(a, b1, b2, q11, q12, q22):
    return sp.Matrix(
        [
            [r * a, r * b1, r * b2],
            [r * b1, q11, q12],
            [r * b2, q12, q22],
        ]
    )


h_m = endpoint_hessian(a_m, b_m1, b_m2, q_m11, q_m12, q_m22)
h_s = endpoint_hessian(a_s, b_s1, b_s2, q_s11, q_s12, q_s22)
d_m = sp.factor(h_m.det())
d_s = sp.factor(h_s.det())

require_zero("M endpoint determinant has exact r factor", d_m - r * (d_m / r))
require_zero("S endpoint determinant has exact r factor", d_s - r * (d_s / r))
if sp.denom(sp.cancel(d_m / r)) != 1 or sp.denom(sp.cancel(d_s / r)) != 1:
    raise RuntimeError("normalized endpoint determinants are not polynomials")
if sp.factor(d_m / r).subs(r, 0) == 0 or sp.factor(d_s / r).subs(r, 0) == 0:
    raise RuntimeError("generic normalized endpoint determinant vanished at contact")

product = sp.factor(d_m * d_s)
require_zero(
    "two endpoints have exact r^2 factor",
    product - r**2 * sp.cancel(product / r**2),
)
if sp.denom(sp.cancel(product / r**2)) != 1:
    raise RuntimeError("normalized two-endpoint product is not polynomial")

# Conditional Kac--Rice numerator: r^2 endpoint determinants times an r^3
# remote-value window.  Palm normalization divides by Z_r of order r^2.
endpoint_power = 2
window_power = 3
normalizer_power = -2
palm_power = endpoint_power + window_power + normalizer_power
if palm_power != 3:
    raise RuntimeError(f"expected Palm power 3, found {palm_power}")

print("EACH_ENDPOINT_DETERMINANT_FACTOR = r")
print("TWO_ENDPOINT_WEIGHT_FACTOR = r^2")
print("REMOTE_VALUE_WINDOW_FACTOR = r^3")
print("PALM_NORMALIZER_FACTOR = r^-2")
print("FIXED_DISTANCE_PALM_COUNT_FACTOR = r^3")

# Correct the baseline's optional global joint-target norm constant.  With
# a=r^3/12 in [0,1/12], L=(b-a*kappa,-kappa/6,...).  The matrix of
# 37|L|^2-(b^2+kappa^2) has positive leading minor 36 and determinant
# 1-37a^2 >= 107/144, proving the safe 1/37 bound.  The old 1/2 bound already
# fails at a=b=0.
a, b, kappa = sp.symbols("a b kappa", real=True)
joint_target_sq = (b - a * kappa) ** 2 + kappa**2 / 36
certificate = sp.expand(37 * joint_target_sq - (b**2 + kappa**2))
matrix = sp.Matrix(
    [[36, -37 * a], [-37 * a, 37 * a**2 + sp.Rational(1, 36)]]
)
require_zero(
    "1/37 target-norm quadratic certificate",
    certificate - (sp.Matrix([b, kappa]).T * matrix * sp.Matrix([b, kappa]))[0],
)
require_zero(
    "1/37 certificate determinant",
    sp.factor(matrix.det()) - (1 - 37 * a**2),
)
require_zero(
    "worst-range determinant floor",
    (1 - 37 * a**2).subs(a, sp.Rational(1, 12))
    - sp.Rational(107, 144),
)
if not (
    joint_target_sq.subs({a: 0, b: 0, kappa: 1})
    < sp.Rational(1, 2)
):
    raise RuntimeError("baseline 1/2 target-norm counterexample failed")

print("JOINT_TARGET_NORM_1_OVER_37 = VERIFIED_FOR_0_LE_A_LE_1_OVER_12")
print("BASELINE_JOINT_TARGET_NORM_1_OVER_2 = REJECTED")
print(
    "SCOPE_LIMIT: algebraic determinant factor and power ledger only; "
    "uniform covariance and Kac--Rice steps are proved in the companion note"
)
print("ALL_FIXED_DISTANCE_POWER_CHECKS_PASS")
