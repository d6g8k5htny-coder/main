#!/usr/bin/env python3
"""Audit all 24 V2 manifest referents, including the seven binaries."""

from __future__ import annotations

import csv
import hashlib
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
V2_ROOT = ROOT / "evidence" / "original_v2" / "SIDE24_v2_2026-08-01"
GAP_ROOT = ROOT / "evidence" / "original_v2" / "SIDE24_gap_fill"
MANIFEST = V2_ROOT / "09_PACKAGE_MANIFEST_V2.csv"


def resolve(relative: str) -> Path:
    if relative == "SIDE24_GAP_FILL_SUPPLEMENT.md":
        return GAP_ROOT / relative
    if relative.startswith("scripts/"):
        return GAP_ROOT / relative
    return V2_ROOT / relative


with MANIFEST.open(newline="", encoding="utf-8") as handle:
    rows = list(csv.DictReader(handle))

if len(rows) != 24:
    raise RuntimeError(f"expected 24 manifest rows, found {len(rows)}")

matches: list[str] = []
differences: list[tuple[str, int, int, str, str]] = []
for row in rows:
    relative = row["file"]
    path = resolve(relative)
    if not path.is_file():
        raise RuntimeError(f"missing manifest referent: {relative}")
    payload = path.read_bytes()
    actual_size = len(payload)
    actual_hash = hashlib.sha256(payload).hexdigest()
    expected_size = int(row["bytes"])
    expected_hash = row["sha256"]
    if actual_size == expected_size and actual_hash == expected_hash:
        matches.append(relative)
        print(f"MATCH = {relative}")
    else:
        differences.append(
            (
                relative,
                expected_size,
                actual_size,
                expected_hash,
                actual_hash,
            )
        )
        print(
            f"DIFF = {relative}; expected_bytes={expected_size}; "
            f"actual_bytes={actual_size}; expected_sha256={expected_hash}; "
            f"actual_sha256={actual_hash}"
        )

if len(matches) != 23:
    raise RuntimeError(f"expected 23 matches, found {len(matches)}")
if len(differences) != 1 or differences[0][0] != "CHANGE_LOG.md":
    raise RuntimeError(f"unexpected manifest differences: {differences}")
if differences[0][1:3] != (3500, 4628):
    raise RuntimeError(
        "CHANGE_LOG size discrepancy changed: "
        f"expected/actual={differences[0][1:3]}"
    )

binary_names = {
    "00_READ_ME_FIRST_V2.pdf",
    "02_PRE_REVIEW_DOSSIER_V2.pdf",
    "03_SIDE24_MANUSCRIPT_V2.pdf",
    "04_TECHNICAL_APPENDIX_V2.pdf",
    "05_REPRODUCTION_GUIDE_V2.pdf",
    "07_REVIEW_RESPONSE_FORM_V2.docx",
    "11_COMPLETE_PRE_REVIEW_PACKET_V2.pdf",
}
if not binary_names.issubset(matches):
    raise RuntimeError("one or more binary manifest referents failed")

print("MANIFEST_ROW_COUNT = 24")
print("MANIFEST_MATCH_COUNT = 23")
print("MANIFEST_DIFF_COUNT = 1")
print("ALL_SEVEN_BINARY_REFERENTS_MATCH = VERIFIED")
print("ONLY_CHANGE_LOG_ROW_IS_STALE = VERIFIED")
print("ALL_ORIGINAL_V2_MANIFEST_CHECKS_PASS")
