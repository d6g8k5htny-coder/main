#!/usr/bin/env python3
"""Exact local-model audit of the V2 connection-level elder mark.

For the index-two Morse saddle f(x,y,z)=z^2-x^2-y^2 at level h=0, the two
upper sectors have maximin connection level exactly h, never strictly below
h.  This invalidates the strict inequality used by the V2 mark.
"""

from __future__ import annotations

import sympy as sp


z, delta = sp.symbols("z delta", real=True, positive=True)
axis_path_value = z**2

endpoint_plus = axis_path_value.subs(z, delta)
endpoint_minus = axis_path_value.subs(z, -delta)
path_minimum = axis_path_value.subs(z, 0)

if sp.simplify(endpoint_plus - delta**2) != 0:
    raise RuntimeError("positive-sector endpoint check failed")
if sp.simplify(endpoint_minus - delta**2) != 0:
    raise RuntimeError("negative-sector endpoint check failed")
if path_minimum != 0:
    raise RuntimeError("axis path should meet the saddle level")

# Every continuous path from z=+delta to z=-delta has a point with z=0.
# At such a point f=-x^2-y^2<=0, so every path has minimum at most zero.
# The axis path has minimum zero, proving the maximin value is exactly h=0.
print("LOCAL_MODEL = z^2 - x^2 - y^2")
print("SADDLE_LEVEL = 0")
print("AXIS_PATH_MINIMUM = 0")
print("EVERY_CONNECTING_PATH_UPPER_BOUND = 0 (by IVT on z)")
print("MAXIMIN_CONNECTION_LEVEL = 0")
print("V2_STRICT_TEST_m_LT_h = FALSE")
print("ALL_LOCAL_MODEL_CHECKS_PASS")

