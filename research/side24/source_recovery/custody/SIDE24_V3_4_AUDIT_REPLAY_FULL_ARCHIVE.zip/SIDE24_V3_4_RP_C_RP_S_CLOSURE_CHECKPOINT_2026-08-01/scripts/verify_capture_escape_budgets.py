#!/usr/bin/env python3
"""Verify the rational margins used by the repaired deterministic dynamics.

This ledger checks arithmetic only.  It does not verify the normal-form
reduction, exact-field approximation, or determinant-weighted Palm transfer.
"""

from __future__ import annotations

from fractions import Fraction as F


def require(name: str, condition: bool) -> None:
    if not condition:
        raise RuntimeError(f"{name} failed")


K = 4096
epsilon_0 = F(1, 1024 * K)

# The endpoint cone uses pin preservation to replace an inadmissible absolute
# rR error by a distance-weighted error.  The displayed number 257/1024 is a
# conservative upper bound for (1+delta)/4 when delta<=1/512.
cone_adverse = (
    F(257, 1024)
    + F(257, 1024 * K)
    + F(1, 2048 * K**2)
    + epsilon_0
)
strip_adverse = (
    F(7, 8)
    + F(5, 8 * K)
    + F(3, 32 * K**2)
    + F(4, 3) * epsilon_0
)
level_bracket = (
    F(21, 32 * K)
    + F(1, K**2)
    + 3 * epsilon_0
    + F(3, 8192)
    + F(1, 4 * K)
)
inward_adverse = (
    1
    + F(1, K)
    + F(1, 4 * K**2)
    + 6 * epsilon_0
    + F(4, K)
)

require("outward cone margin", cone_adverse < F(1, 3))
require("outward strip margin", strip_adverse < F(9, 10))
require("outward level reserve", level_bracket < F(1, 768))
require(
    "outward terminal level",
    F(49, 192) - F(1, 768) == F(65, 256) > F(1, 4),
)
require("inward tube margin", inward_adverse < 2)

# At R=1 these dominate the pin-preserving perturbation ratios; larger R only
# improves them.  eta_R=delta/16 exactly.
eta_at_r_one = F(1, 8192)
delta_at_r_one = F(1, 512)
require("eta equals delta/16", eta_at_r_one == delta_at_r_one / 16)
require("cone robustness reserve", 3 * eta_at_r_one < F(1, 3))
require("strip robustness reserve", F(4, 3) * eta_at_r_one < F(1, 10))
require("tube robustness reserve", 12 * eta_at_r_one < 2)

print(f"OUTWARD_CONE_ADVERSE = {cone_adverse} < 1/3")
print(f"OUTWARD_STRIP_ADVERSE = {strip_adverse} < 9/10")
print(f"LEVEL_BRACKET = {level_bracket} < 1/768")
print("TERMINAL_LEVEL = 65/256 > 1/4")
print(f"INWARD_TUBE_ADVERSE = {inward_adverse} < 2")
print("PIN_PRESERVING_ROBUSTNESS_BUDGETS = VERIFIED")
print("SCOPE_LIMIT: arithmetic margins only; Palm O(r^3) is not claimed")
print("ALL_CAPTURE_ESCAPE_BUDGETS_PASS")

