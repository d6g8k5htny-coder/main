#!/usr/bin/env python3
"""Audit the ten-pin cubic system printed in the V2 supplement.

This checker deliberately uses explicit exceptions instead of bare ``assert`` so
that ``python -O`` cannot disable the mathematical comparisons.  It proves the
sign correction inside that declared ten-pin system.  It does *not* promote the
system to the load-bearing triple-contact chart: V2 omitted the third-point
value constraint, which is checked in a separate V3 verifier.
"""

from __future__ import annotations

import sympy as sp


def require_zero(name: str, expression: sp.Expr) -> None:
    reduced = sp.factor(sp.cancel(expression))
    if reduced != 0:
        raise RuntimeError(f"{name} failed: residual = {reduced}")


def require_nonzero(name: str, expression: sp.Expr) -> sp.Expr:
    reduced = sp.factor(sp.cancel(expression))
    if reduced == 0:
        raise RuntimeError(f"{name} unexpectedly vanished")
    return reduced


X, Y = sp.symbols("X Y")
c, s, eta, kappa = sp.symbols("c s eta kappa", nonzero=True)
q_m, q_s = sp.symbols("q_M q_S")
coefficients = sp.symbols("a0:10")

monomials = [
    1,
    X,
    Y,
    X**2,
    X * Y,
    Y**2,
    X**3,
    X**2 * Y,
    X * Y**2,
    Y**3,
]
p = sum(a * monomial for a, monomial in zip(coefficients, monomials))
p_x = sp.diff(p, X)
p_y = sp.diff(p, Y)

m_x = -sp.Rational(1, 2)
s_x = sp.Rational(1, 2)
p_x_coord = c / eta
p_y_coord = s / eta

pin_equations = [
    sp.Eq(p.subs({X: m_x, Y: 0}), 0),
    sp.Eq(p.subs({X: s_x, Y: 0}), -kappa / 6),
    sp.Eq(p_x.subs({X: m_x, Y: 0}), 0),
    sp.Eq(p_y.subs({X: m_x, Y: 0}), 0),
    sp.Eq(p_x.subs({X: s_x, Y: 0}), 0),
    sp.Eq(p_y.subs({X: s_x, Y: 0}), 0),
    sp.Eq(p_x.subs({X: p_x_coord, Y: p_y_coord}), 0),
    sp.Eq(p_y.subs({X: p_x_coord, Y: p_y_coord}), 0),
    sp.Eq(sp.diff(p, Y, 2).subs({X: m_x, Y: 0}), q_m),
    sp.Eq(sp.diff(p, Y, 2).subs({X: s_x, Y: 0}), q_s),
]

solutions = sp.solve(pin_equations, list(coefficients), dict=True, simplify=True)
if len(solutions) != 1:
    raise RuntimeError(f"expected one interpolation solution, found {len(solutions)}")

pinned_p = sp.simplify(p.subs(solutions[0]))
hessian = sp.Matrix(
    [
        [sp.diff(pinned_p, X, 2), sp.diff(pinned_p, X, Y)],
        [sp.diff(pinned_p, X, Y), sp.diff(pinned_p, Y, 2)],
    ]
)

det_m = sp.factor(hessian.subs({X: m_x, Y: 0}).det())
det_s = sp.factor(hessian.subs({X: s_x, Y: 0}).det())
det_p = sp.factor(hessian.subs({X: p_x_coord, Y: p_y_coord}).det())

common_square = kappa**2 * (4 * c**2 - eta**2) ** 2
common_transverse = 4 * s**4 * (q_m - q_s) ** 2

claimed_minus_det_m = (
    common_square
    + 4
    * kappa
    * s**2
    * ((12 * c**2 + eta**2) * q_m + (4 * c**2 - eta**2) * q_s)
    + common_transverse
) / (64 * c**2 * s**2)

# The minus sign on the kappa-linear term is load-bearing.  V2 printed it as
# plus; the exact interpolation gives the expression below.
claimed_minus_det_s = (
    common_square
    - 4
    * kappa
    * s**2
    * ((4 * c**2 - eta**2) * q_m + (12 * c**2 + eta**2) * q_s)
    + common_transverse
) / (64 * c**2 * s**2)

require_zero("corrected -det(H_M)", -det_m - claimed_minus_det_m)
require_zero("corrected -det(H_S)", -det_s - claimed_minus_det_s)

v2_printed_minus_det_s = (
    common_square
    + 4
    * kappa
    * s**2
    * ((4 * c**2 - eta**2) * q_m + (12 * c**2 + eta**2) * q_s)
    + common_transverse
) / (64 * c**2 * s**2)
v2_residual = require_nonzero(
    "V2 printed -det(H_S) discrepancy", -det_s - v2_printed_minus_det_s
)
require_zero(
    "V2 discrepancy closed form",
    v2_residual
    + kappa
    * ((4 * c**2 - eta**2) * q_m + (12 * c**2 + eta**2) * q_s)
    / (8 * c**2),
)

_, denominator_p = sp.fraction(det_p)
require_zero("third-point denominator", denominator_p - 64 * c**2 * eta * s**2)

product_degree = sp.degree(sp.together(det_m * det_s * det_p), kappa)
if product_degree != 6:
    raise RuntimeError(f"expected kappa-degree 6, found {product_degree}")

# The angular parametrization is restricted to the unit circle in the
# application.  Because the identities hold with c and s algebraically
# independent, they continue to hold after imposing c^2+s^2=1 away from the
# chart denominators.  This checker does not claim removability at c*s=0 or
# integrability near collision strata.
print("CORRECTED_MINUS_DET_H_M = VERIFIED")
print("CORRECTED_MINUS_DET_H_S = VERIFIED (kappa-linear sign is negative)")
print("V2_PRINTED_MINUS_DET_H_S = REJECTED (nonzero symbolic residual)")
print("DET_H_P_DENOMINATOR = VERIFIED")
print("PRODUCT_DEGREE_IN_KAPPA = 6")
print(
    "SCOPE_LIMIT: ten-pin V2 audit only; third value pin, axis charts, "
    "finite-r transfer, and G6' are not claimed"
)
print("ALL_EQUATION_CHECKS_PASS")
