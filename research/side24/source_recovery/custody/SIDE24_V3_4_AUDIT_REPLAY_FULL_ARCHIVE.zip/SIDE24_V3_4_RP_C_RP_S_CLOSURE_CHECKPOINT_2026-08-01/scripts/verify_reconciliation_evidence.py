#!/usr/bin/env python3
"""Fail-closed verification of the independent reconciliation snapshot."""

from __future__ import annotations

import ast
import hashlib
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "evidence" / "audit_reconciliation"
SNAPSHOT = EVIDENCE / "SIDE24 AUDIT RECONCILIATION SNAPSHOT 2026-07-31.zip"
SCRIPT = EVIDENCE / "verify_disposition_s3_v1.py"
DELIVERED_SCRIPT = ROOT / "scripts" / "verify_disposition_s3_v1.py"
TRANSCRIPT = EVIDENCE / "verify_disposition_s3_v1.out.txt"


def require(label: str, condition: bool) -> None:
    if not condition:
        raise RuntimeError(f"{label} failed")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


require(
    "reconciliation snapshot hash",
    sha256(SNAPSHOT)
    == "7be11c3e2ee6a185ca13bb91a18b656855ca3f458d853c93c5f5ba71fbb8a97e",
)
require(
    "independent verifier hash",
    sha256(SCRIPT)
    == "6900e0c4c5717143fdb1d700744a755b1e5d64d3120ddaed48fbaaa7a21d57dc",
)
require(
    "delivered independent verifier is verbatim",
    sha256(DELIVERED_SCRIPT) == sha256(SCRIPT),
)
require(
    "independent transcript hash",
    sha256(TRANSCRIPT)
    == "884b5411e5d9fc303103faf44110bd7bd5ec9aee8c8d8da5c443a817db3160f5",
)

ledger: dict[str, str] = {}
for line in (EVIDENCE / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
    if not line.strip():
        continue
    digest, relative = line.split("  ", 1)
    ledger[relative] = digest
require("snapshot ledger entry count", len(ledger) == 8)
for relative, expected in ledger.items():
    require(f"snapshot ledger hash for {relative}", sha256(EVIDENCE / relative) == expected)

tree = ast.parse(SCRIPT.read_text(encoding="utf-8"), filename=str(SCRIPT))
require(
    "independent verifier has no bare asserts",
    not any(isinstance(node, ast.Assert) for node in ast.walk(tree)),
)


def run(optimized: bool = False) -> subprocess.CompletedProcess[bytes]:
    command = [sys.executable]
    if optimized:
        command.append("-O")
    command.append(str(SCRIPT))
    return subprocess.run(command, capture_output=True, check=False)


normal = run()
optimized = run(optimized=True)
for label, completed in (("normal", normal), ("optimized", optimized)):
    require(f"{label} verifier exit zero", completed.returncode == 0)
    require(f"{label} verifier stderr empty", not completed.stderr)
    lines = completed.stdout.decode("utf-8").splitlines()
    require(f"{label} verifier terminal PASS", lines[-1] == "ALL_ASSERTIONS_PASS")
    require(f"{label} verifier 15 checks", sum(line.startswith("[ok]") for line in lines) == 15)

require("normal transcript identity", normal.stdout == TRANSCRIPT.read_bytes())
require("optimized transcript identity", optimized.stdout == normal.stdout)

# Execute the reviewer's own ck(False, ...) after loading the script.  Loading
# first reproduces its 15 checks; the injected probe must then terminate with 1.
probe = (
    "import runpy; "
    f"ns=runpy.run_path({str(SCRIPT)!r}); "
    "ns['ck'](False, 'INJECTED_FAIL_CLOSED_PROBE')"
)
failed = subprocess.run(
    [sys.executable, "-c", probe], capture_output=True, check=False
)
require("injected failure exits one", failed.returncode == 1)
require(
    "injected failure marker",
    b"CHECK FAILED: INJECTED_FAIL_CLOSED_PROBE" in failed.stdout,
)

print("RECONCILIATION_SNAPSHOT_SHA256 = VERIFIED")
print("RECONCILIATION_INTERNAL_LEDGER = 8/8")
print("INDEPENDENT_DISPOSITION_CHECKS = 15/15")
print("NORMAL_AND_OPTIMIZED_TRANSCRIPTS = BYTE_IDENTICAL")
print("INJECTED_FAILURE_EXIT_STATUS = 1")
print(
    "SCOPE_LIMIT: contact-plane algebra and reproduction engineering only; "
    "no Palm, finite-r regional, or elder-selection conclusion"
)
print("ALL_RECONCILIATION_EVIDENCE_CHECKS_PASS")
