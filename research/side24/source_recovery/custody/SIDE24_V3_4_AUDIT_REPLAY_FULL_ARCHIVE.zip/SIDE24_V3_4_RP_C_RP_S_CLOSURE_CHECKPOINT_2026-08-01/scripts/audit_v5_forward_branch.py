#!/usr/bin/env python3
"""Fail-closed package and executable audit of the frozen V5 forward branch."""

from __future__ import annotations

import ast
import csv
import hashlib
import io
import stat
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path, PurePosixPath


def require(name: str, condition: bool) -> None:
    if not condition:
        raise RuntimeError(f"{name} failed")


ROOT = Path(__file__).resolve().parents[1]
ARCHIVE = (
    ROOT
    / "evidence/v5_forward_branch/"
    "OKComputer_Project_Gap_Closure_1_119ffbfa.zip"
)
EXPECTED_ARCHIVE_HASH = (
    "119ffbfae2d11cc2d3de60f15c06a653c48b17d06ab0a2e125260ab0f1458c5a"
)
archive_hash = hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()
require("archive SHA-256", archive_hash == EXPECTED_ARCHIVE_HASH)

with zipfile.ZipFile(ARCHIVE) as package:
    infos = package.infolist()
    require("archive entry count", len(infos) == 128)
    names = [item.filename for item in infos]
    require("archive paths unique", len(names) == len(set(names)))
    for item in infos:
        path = PurePosixPath(item.filename)
        require(f"relative safe path {item.filename}", not path.is_absolute() and ".." not in path.parts)
        mode = (item.external_attr >> 16) & 0xFFFF
        require(f"no symlink {item.filename}", not stat.S_ISLNK(mode))

    manifest_name = "SIDE24_v5_2026-08-02/09_PACKAGE_MANIFEST_V5.csv"
    manifest_bytes = package.read(manifest_name)
    rows = list(csv.DictReader(io.StringIO(manifest_bytes.decode("utf-8"))))
    require("V5 manifest rows", len(rows) == 128)
    self_rows = [row for row in rows if row["scope"] == "manifest_self_hash_excluding_this_row"]
    require("one V5 self row", len(self_rows) == 1)
    payload_rows = [row for row in rows if row not in self_rows]
    require("V5 payload row count", len(payload_rows) == 127)
    for row in payload_rows:
        require(f"manifest path {row['file']}", row["file"] in names)
        digest = hashlib.sha256(package.read(row["file"])).hexdigest()
        require(f"manifest digest {row['file']}", digest == row["sha256"])
    self_line = (
        f"{manifest_name},manifest_self_hash_excluding_this_row,"
        f"{self_rows[0]['sha256']}"
    ).encode("utf-8")
    self_offset = manifest_bytes.find(self_line)
    require("V5 self row located", self_offset >= 0)
    prefix_hash = hashlib.sha256(manifest_bytes[:self_offset]).hexdigest()
    require("V5 self-prefix digest", prefix_hash == self_rows[0]["sha256"])
    require("V5 manifest covers archive", {row["file"] for row in rows} == set(names))

    v4_name = "SIDE24_v4_2026-08-01/09_PACKAGE_MANIFEST_V4.csv"
    v4_text = package.read(v4_name).decode("utf-8")
    v4_rows = list(csv.DictReader(io.StringIO(v4_text.split("# manifest self-hash", 1)[0])))
    v4_matches = []
    for row in v4_rows:
        actual = hashlib.sha256(package.read(row["path"])).hexdigest()
        v4_matches.append(actual == row["sha256"] and len(package.read(row["path"])) == int(row["bytes"]))
    require("V4 payload count", len(v4_matches) == 108)
    require("V4 current matches", sum(v4_matches) == 106)

    v3_name = "SIDE24_v3_2026-08-01/09_PACKAGE_MANIFEST_V3.csv"
    v3_rows = list(csv.DictReader(io.StringIO(package.read(v3_name).decode("utf-8"))))
    v3_matches = []
    for row in v3_rows:
        if row["role"] == "v3 package file":
            resolved = f"SIDE24_v3_2026-08-01/{row['file']}"
        else:
            resolved = f"SIDE24_gap_fill/{row['file']}"
        actual_bytes = package.read(resolved)
        v3_matches.append(
            hashlib.sha256(actual_bytes).hexdigest() == row["sha256"]
            and len(actual_bytes) == int(row["bytes"])
        )
    require("V3 payload count", len(v3_matches) == 37)
    require("V3 current matches", sum(v3_matches) == 24)

    supplement = package.read("SIDE24_gap_fill/SIDE24_GAP_FILL_SUPPLEMENT.md").decode("utf-8")
    require(
        "frozen G.8 regression present",
        r"\|L_r(b,\kappa)\|^2\ge\tfrac12(b^2+\kappa^2)" in supplement,
    )
    require("frozen theorem remains HOLD", "Candidate theorem | **HOLD**" in supplement)

    with tempfile.TemporaryDirectory(prefix="side24_v5_audit_") as temporary:
        destination = Path(temporary)
        package.extractall(destination)
        evidence = destination / "SIDE24_gap_fill"
        scripts = sorted((evidence / "scripts").glob("*.py"))
        require("script count", len(scripts) == 12)
        for script_path in scripts:
            source = script_path.read_text(encoding="utf-8")
            tree = ast.parse(source, filename=str(script_path))
            require(
                f"no bare assert {script_path.name}",
                not any(isinstance(node, ast.Assert) for node in ast.walk(tree)),
            )
            require(f"raising helper {script_path.name}", "def ck(" in source and "raise SystemExit" in source)
            committed = script_path.with_suffix(".out.txt").read_text(encoding="utf-8")
            for optimized in (False, True):
                command = [sys.executable]
                if optimized:
                    command.append("-O")
                command.append(str(script_path))
                completed = subprocess.run(
                    command,
                    capture_output=True,
                    text=True,
                    timeout=600,
                    check=False,
                )
                mode = "optimized" if optimized else "normal"
                require(f"{mode} exit {script_path.name}", completed.returncode == 0)
                require(f"{mode} stderr {script_path.name}", completed.stderr == "")
                require(f"{mode} marker {script_path.name}", "ALL_ASSERTIONS_PASS" in completed.stdout)
                require(f"{mode} transcript {script_path.name}", completed.stdout == committed)

        for version, count in (("v7", 23), ("v8", 30)):
            verifier = evidence / f"verifier/{version}/verify.py"
            for optimized in (False, True):
                command = [sys.executable]
                if optimized:
                    command.append("-O")
                command.append(str(verifier))
                completed = subprocess.run(
                    command,
                    capture_output=True,
                    text=True,
                    timeout=1200,
                    check=False,
                )
                transcript_name = "verify.O.out.txt" if optimized else "verify.out.txt"
                committed = (verifier.parent / transcript_name).read_text(encoding="utf-8")
                require(f"{version} exit optimized={optimized}", completed.returncode == 0)
                require(f"{version} transcript optimized={optimized}", completed.stdout == committed)
                require(f"{version} count optimized={optimized}", f"{count}/{count}" in completed.stdout)

print(f"ARCHIVE_SHA256 = {archive_hash}")
print("ARCHIVE_ENTRIES = 128")
print("V5_MANIFEST = 127/127 PAYLOADS + VALID SELF PREFIX")
print("V4_HISTORICAL_REFERENTS = 106/108")
print("V3_HISTORICAL_REFERENTS = 24/37")
print("SCRIPT_RERUNS = 24/24 BYTE_IDENTICAL")
print("VERIFIER_V7 = 23/23 BOTH MODES")
print("VERIFIER_V8 = 30/30 BOTH MODES")
print("SCOPE_LIMIT: executable and package integrity only; V5 proof-status")
print("strings are adjudicated independently in the V3.3 mathematical notes.")
print("ALL_ASSERTIONS_PASS")

