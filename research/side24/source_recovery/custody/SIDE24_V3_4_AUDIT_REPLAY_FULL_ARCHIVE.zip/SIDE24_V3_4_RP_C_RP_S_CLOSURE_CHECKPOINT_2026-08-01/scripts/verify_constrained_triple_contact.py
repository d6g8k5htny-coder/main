#!/usr/bin/env python3
"""Exact verification of the value-pinned SIDE24 cubic contact identities.

Requires SymPy >= 1.12.  Unlike the v2 elimination, this verifier imposes the
third critical value p(P)=-alpha*kappa/6.  Every failed identity raises an
exception carrying the unreduced symbolic remainder; Python ``assert`` is not
used, so checks are retained under optimized execution.
"""

from __future__ import annotations

import sympy as sp


def require_zero(expr: sp.Expr, label: str) -> None:
    """Raise an explicit error unless ``expr`` is identically zero."""
    remainder = sp.factor(sp.cancel(sp.together(expr)))
    if remainder != 0:
        raise RuntimeError(f"{label} failed; symbolic remainder: {remainder}")


def hessian(poly: sp.Expr, x: sp.Symbol, y: sp.Symbol) -> sp.Matrix:
    return sp.Matrix(
        [
            [sp.diff(poly, x, 2), sp.diff(poly, x, y)],
            [sp.diff(poly, x, y), sp.diff(poly, y, 2)],
        ]
    )


def verify_regular_chart() -> None:
    X, Y = sp.symbols("X Y")
    c, s, eta, kappa = sp.symbols("c s eta kappa", nonzero=True)
    alpha, d, m = sp.symbols("alpha d m")

    Mx = -sp.Rational(1, 2)
    Sx = sp.Rational(1, 2)
    Px, Py = c / eta, s / eta

    lam = (-kappa * (4 * c**2 - eta**2) + 2 * d * s**2) / (8 * c * s)
    gamma = -2 * (
        lam * (Px**2 - sp.Rational(1, 4))
        + (m / 2 - d * Px) * Py
    ) / Py**2

    p = (
        kappa * (X**3 / 3 - X / 4 - sp.Rational(1, 12))
        + lam * (X**2 - sp.Rational(1, 4)) * Y
        + sp.Rational(1, 2) * (m / 2 - d * X) * Y**2
        + gamma * Y**3 / 6
    )
    pX, pY = sp.diff(p, X), sp.diff(p, Y)

    qM = (m + d) / 2
    qS = (m - d) / 2

    # The normal form must satisfy all value/station/curvature pins except the
    # third value before the value relation is inserted.
    base_checks = {
        "p(M)=0": p.subs({X: Mx, Y: 0}),
        "p(S)=-kappa/6": p.subs({X: Sx, Y: 0}) + kappa / 6,
        "p_X(M)=0": pX.subs({X: Mx, Y: 0}),
        "p_Y(M)=0": pY.subs({X: Mx, Y: 0}),
        "p_X(S)=0": pX.subs({X: Sx, Y: 0}),
        "p_Y(S)=0": pY.subs({X: Sx, Y: 0}),
        "p_X(P)=0": pX.subs({X: Px, Y: Py}),
        "p_Y(P)=0": pY.subs({X: Px, Y: Py}),
        "p_YY(M)=q_M": sp.diff(p, Y, 2).subs({X: Mx, Y: 0}) - qM,
        "p_YY(S)=q_S": sp.diff(p, Y, 2).subs({X: Sx, Y: 0}) - qS,
    }
    for label, expr in base_checks.items():
        require_zero(expr, label)

    R = (2 * c + eta) ** 2 - 8 * alpha * c * eta
    value_relation = 2 * s**2 * (2 * c * m - eta * d) - kappa * eta * R
    m_value_pinned = (eta * d + kappa * eta * R / (2 * s**2)) / (2 * c)

    require_zero(
        value_relation.subs(m, m_value_pinned),
        "third-value linear relation",
    )
    require_zero(
        (p.subs({X: Px, Y: Py}) + alpha * kappa / 6).subs(
            m, m_value_pinned
        ),
        "p(P)=-alpha*kappa/6",
    )

    H = hessian(p, X, Y)
    detM_raw = sp.factor(H.subs({X: Mx, Y: 0}).det())
    detS_raw = sp.factor(H.subs({X: Sx, Y: 0}).det())
    detP_raw = sp.factor(H.subs({X: Px, Y: Py}).det())

    A = 4 * c**2 - eta**2
    expected_minus_detM_raw = (
        kappa**2 * A**2
        + 4
        * kappa
        * s**2
        * ((12 * c**2 + eta**2) * qM + A * qS)
        + 4 * s**4 * d**2
    ) / (64 * c**2 * s**2)
    # The minus sign in this linear term is the correction to Supplement B.1.
    expected_minus_detS_raw = (
        kappa**2 * A**2
        - 4
        * kappa
        * s**2
        * (A * qM + (12 * c**2 + eta**2) * qS)
        + 4 * s**4 * d**2
    ) / (64 * c**2 * s**2)
    require_zero(-detM_raw - expected_minus_detM_raw, "raw -det H_M")
    require_zero(-detS_raw - expected_minus_detS_raw, "corrected raw -det H_S")

    u = (2 * s**2 * d + kappa * (2 * c + eta) ** 2) / (
        8 * kappa * c * eta
    )
    expected_minus_detM = kappa**2 * eta**2 / s**2 * (u**2 - alpha)
    expected_minus_detS = (
        kappa**2 * eta**2 / s**2 * ((u - 1) ** 2 - (1 - alpha))
    )
    expected_detP = -kappa**2 * eta**2 / s**2 * (
        (u - alpha) ** 2 + alpha * (1 - alpha)
    )

    substitutions = {m: m_value_pinned}
    require_zero(
        (-detM_raw).subs(substitutions) - expected_minus_detM,
        "value-pinned -det H_M",
    )
    require_zero(
        (-detS_raw).subs(substitutions) - expected_minus_detS,
        "value-pinned -det H_S",
    )
    require_zero(
        detP_raw.subs(substitutions) - expected_detP,
        "value-pinned det H_P",
    )

    # These three identities make the square completion transparent.
    require_zero(
        2 * s**2 * d + kappa * (2 * c - eta) ** 2
        - 8 * kappa * c * eta * (u - 1),
        "S square coordinate",
    )
    require_zero(
        2 * s**2 * d + kappa * R
        - 8 * kappa * c * eta * (u - alpha),
        "P square coordinate",
    )

    print("REGULAR_CHART_VALUE_RELATION_VERIFIED")
    print("REGULAR_CHART_THREE_DETERMINANTS_VERIFIED")
    print("CORRECTED_H_S_LINEAR_SIGN_VERIFIED")


def verify_perpendicular_chart() -> None:
    """Verify c=0 with s=+1; s=-1 follows by Y reflection."""
    X, Y = sp.symbols("X Y")
    eta, kappa = sp.symbols("eta kappa", nonzero=True)
    alpha, mu = sp.symbols("alpha mu")

    Mx = -sp.Rational(1, 2)
    Sx = sp.Rational(1, 2)
    Px, Py = 0, 1 / eta
    d = -kappa * eta**2 / 2
    m = kappa * eta**2 * mu
    lam = kappa * eta * (mu - 1 + 2 * alpha) / 2
    gamma = -2 * (
        lam * (Px**2 - sp.Rational(1, 4))
        + (m / 2 - d * Px) * Py
    ) / Py**2

    p = (
        kappa * (X**3 / 3 - X / 4 - sp.Rational(1, 12))
        + lam * (X**2 - sp.Rational(1, 4)) * Y
        + sp.Rational(1, 2) * (m / 2 - d * X) * Y**2
        + gamma * Y**3 / 6
    )
    pX, pY = sp.diff(p, X), sp.diff(p, Y)
    require_zero(pX.subs({X: Px, Y: Py}), "c=0 p_X(P)=0")
    require_zero(pY.subs({X: Px, Y: Py}), "c=0 p_Y(P)=0")
    require_zero(
        p.subs({X: Px, Y: Py}) + alpha * kappa / 6,
        "c=0 p(P)=-alpha*kappa/6",
    )

    H = hessian(p, X, Y)
    detM = sp.factor(H.subs({X: Mx, Y: 0}).det())
    detS = sp.factor(H.subs({X: Sx, Y: 0}).det())
    detP = sp.factor(H.subs({X: Px, Y: Py}).det())

    expected_detM = kappa**2 * eta**2 * (
        sp.Rational(1, 4)
        - mu / 2
        - (mu - 1 + 2 * alpha) ** 2 / 4
    )
    expected_detS = kappa**2 * eta**2 * (
        mu / 2
        + sp.Rational(1, 4)
        - (mu - 1 + 2 * alpha) ** 2 / 4
    )
    expected_detP = -kappa**2 * eta**2 * (
        mu**2 + 4 * alpha * (1 - alpha)
    ) / 4

    require_zero(detM - expected_detM, "c=0 det H_M")
    require_zero(detS - expected_detS, "c=0 det H_S")
    require_zero(detP - expected_detP, "c=0 det H_P")

    # det H_M>0 is equivalent to this quadratic being negative; its roots are
    # -2*alpha +/- 2*sqrt(alpha), as stated in the companion derivation.
    max_cone_polynomial = sp.factor(
        -4 * expected_detM / (kappa**2 * eta**2)
    )
    require_zero(
        max_cone_polynomial
        - (mu**2 + 4 * alpha * mu - 4 * alpha * (1 - alpha)),
        "c=0 maximum type-cone polynomial",
    )

    print("PERPENDICULAR_C0_CHART_VERIFIED")
    print("PERPENDICULAR_C0_TYPE_CONE_VERIFIED")


def main() -> None:
    print(f"SYMPY_VERSION={sp.__version__}")
    verify_regular_chart()
    verify_perpendicular_chart()
    print("ALL_EXACT_IDENTITIES_VERIFIED")
    print(
        "OPEN_PREMISE=finite-r joint (r,rho)/(t,rho) compactification and "
        "uniform angularly integrated conditional determinant estimate"
    )


if __name__ == "__main__":
    main()
