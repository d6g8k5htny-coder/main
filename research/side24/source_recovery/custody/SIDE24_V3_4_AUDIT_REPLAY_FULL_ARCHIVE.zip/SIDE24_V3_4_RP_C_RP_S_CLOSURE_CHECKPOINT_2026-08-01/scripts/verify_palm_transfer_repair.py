#!/usr/bin/env python3
"""Exact regressions supporting the V3.3 Palm-transfer repair."""

from __future__ import annotations

import sympy as sp


def require(name: str, condition: bool) -> None:
    if not condition:
        raise RuntimeError(f"{name} failed")


r, kappa, s = sp.symbols("r kappa s", positive=True)
a0, a1, a2, a3 = sp.symbols("a0 a1 a2 a3", real=True)
g = a0 + a1 * s + a2 * s**2 / 2 + a3 * s**3 / 6
gp = sp.diff(g, s)
solution = sp.solve(
    [
        sp.Eq(gp.subs(s, -r / 2), 0),
        sp.Eq(gp.subs(s, r / 2), 0),
        sp.Eq(g.subs(s, r / 2) - g.subs(s, -r / 2), -kappa * r**3 / 6),
    ],
    [a1, a2, a3],
    dict=True,
)[0]
require("cubic third derivative", sp.simplify(solution[a3] - 2 * kappa) == 0)
gpp = sp.diff(g, s, 2).subs(solution)
require("left longitudinal soft limit", sp.simplify(gpp.subs(s, -r / 2) + kappa * r) == 0)
require("right longitudinal soft limit", sp.simplify(gpp.subs(s, r / 2) - kappa * r) == 0)

alpha, beta1, beta2 = sp.symbols("alpha beta1 beta2", real=True)
q11, q12, q22 = sp.symbols("q11 q12 q22", real=True)
hessian = sp.Matrix(
    [
        [r * alpha, r * beta1, r * beta2],
        [r * beta1, q11, q12],
        [r * beta2, q12, q22],
    ]
)
transverse = sp.Matrix([[q11, q12], [q12, q22]])
d_factor = alpha * transverse.det() - r * (
    beta1**2 * q22 - 2 * beta1 * beta2 * q12 + beta2**2 * q11
)
require("exact endpoint factor", sp.simplify(hessian.det() - r * d_factor) == 0)

qdet = sp.symbols("qdet", nonzero=True, real=True)
d_left_limit = -kappa * qdet
d_right_limit = kappa * qdet
require(
    "normalizer integrand limit",
    sp.simplify(-d_left_limit * d_right_limit - kappa**2 * qdet**2) == 0,
)

# Corrected target L=(b-a*kappa,-kappa/6), a=r^3/12 in [0,1/12].
b, a = sp.symbols("b a", real=True)
target_norm = (b - a * kappa) ** 2 + kappa**2 / 36
safe_residual = sp.expand(target_norm - (b**2 + kappa**2) / 37)
safe_matrix = sp.Matrix(
    [
        [sp.Rational(36, 37), -a],
        [-a, a**2 + sp.Rational(1, 1332)],
    ]
)
require(
    "safe target quadratic form",
    sp.simplify(
        safe_residual
        - (sp.Matrix([[b, kappa]]) * safe_matrix * sp.Matrix([b, kappa]))[0]
    )
    == 0,
)
require(
    "safe target determinant",
    sp.simplify(safe_matrix.det() - (1 - 37 * a**2) / 1369) == 0,
)
require(
    "safe target positive through r=1",
    sp.Rational(1, 1) - 37 * sp.Rational(1, 12) ** 2 > 0,
)
false_half = sp.simplify(target_norm.subs({b: 0, a: 0}) - kappa**2 / 2)
require("V5 one-half floor is false", false_half == -sp.Rational(17, 36) * kappa**2)

# Power ledgers: shallow numerator r^2 endpoint weight, r^2 shallow
# determinant weight, r coarea mass; Palm division by r^2.
shallow_unnormalized = r**2 * r**2 * r
shallow_palm = sp.simplify(shallow_unnormalized / r**2)
remote_unnormalized = r**2 * r**3
remote_palm = sp.simplify(remote_unnormalized / r**2)
require("shallow numerator r^5", shallow_unnormalized == r**5)
require("shallow Palm r^3", shallow_palm == r**3)
require("remote numerator r^5", remote_unnormalized == r**5)
require("remote Palm r^3", remote_palm == r**3)

print("CUBIC_CONTACT_LIMIT = alpha_M:-kappa, alpha_S:+kappa")
print("ENDPOINT_FACTOR = det(H_p)=r*D_p")
print("NORMALIZER_LIMIT = kappa^2*(det Q)^2*1{Q negative definite}")
print("SAFE_JOINT_TARGET_FLOOR = 1/37 for 0<r<=1")
print("V5_HALF_TARGET_FLOOR = REJECTED")
print("SHALLOW_POWER = r^2*r^2*r/r^2 = r^3")
print("REMOTE_POWER = r^2*r^3/r^2 = r^3")
print("SCOPE_LIMIT: exact algebra and power ledgers; the Gaussian tube and")
print("Borell arguments are proved in drafts/palm_transfer_repair_v3_3.md.")
print("ALL_ASSERTIONS_PASS")

