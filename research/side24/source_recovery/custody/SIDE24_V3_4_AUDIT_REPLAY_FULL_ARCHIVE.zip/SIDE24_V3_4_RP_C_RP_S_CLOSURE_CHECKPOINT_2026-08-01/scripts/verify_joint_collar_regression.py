#!/usr/bin/env python3
"""Exact local regressions for the anisotropic collar compactification."""

from __future__ import annotations

import sympy as sp


def require(name: str, condition: bool) -> None:
    if not condition:
        raise RuntimeError(f"{name} failed")


x1, x2, x3 = sp.symbols("x1 x2 x3", real=True)
kernel = sp.exp(-(x1**2 + x2**2 + x3**2) / 2)


def covariance(alpha: tuple[int, int, int], beta: tuple[int, int, int]):
    expression = kernel
    variables = (x1, x2, x3)
    for index, order in enumerate(alpha):
        expression = sp.diff(expression, variables[index], order)
    for index, order in enumerate(beta):
        expression = sp.diff(expression, variables[index], order)
    return (-1) ** sum(beta) * expression.subs({x1: 0, x2: 0, x3: 0})


f = (0, 0, 0)
f1, f2, f3 = (1, 0, 0), (0, 1, 0), (0, 0, 1)
f11, f12, f13 = (2, 0, 0), (1, 1, 0), (1, 0, 1)
f22, f23, f33 = (0, 2, 0), (0, 1, 1), (0, 0, 2)
f111 = (3, 0, 0)
f112, f113 = (2, 1, 0), (2, 0, 1)
f122, f123, f133 = (1, 2, 0), (1, 1, 1), (1, 0, 2)
f222, f223, f233, f333 = (0, 3, 0), (0, 2, 1), (0, 1, 2), (0, 0, 3)

pins = [f, f111, f1, f11, f2, f12, f3, f13]
remainder = [
    f22,
    f23,
    f33,
    f112,
    f113,
    f122,
    f123,
    f133,
    f222,
    f223,
    f233,
    f333,
]
family = pins + remainder
gram = sp.Matrix([[covariance(a, b) for b in family] for a in family])
pin_gram = gram[: len(pins), : len(pins)]
require("contact pin determinant", sp.factor(pin_gram.det()) == 12)
schur = sp.simplify(
    gram[len(pins) :, len(pins) :]
    - gram[len(pins) :, : len(pins)]
    * pin_gram.inv()
    * gram[: len(pins), len(pins) :]
)
index = {item: i for i, item in enumerate(remainder)}

X, Y, Z = sp.symbols("X Y Z", real=True)
rho2 = Y**2 + Z**2
longitudinal = sp.zeros(len(remainder), 1)
for item, coefficient in [
    (f112, X * Y),
    (f113, X * Z),
    (f122, Y**2 / 2),
    (f123, Y * Z),
    (f133, Z**2 / 2),
]:
    longitudinal[index[item]] = coefficient
var_longitudinal = sp.factor((longitudinal.T * schur * longitudinal)[0])
require(
    "collar longitudinal variance",
    sp.simplify(var_longitudinal - rho2 * (4 * X**2 + rho2) / 2) == 0,
)

transverse_map = sp.zeros(2, len(remainder))
transverse_map[0, index[f22]] = Y
transverse_map[0, index[f23]] = Z
transverse_map[1, index[f23]] = Y
transverse_map[1, index[f33]] = Z
transverse_covariance = sp.simplify(transverse_map * schur * transverse_map.T)
require("transverse determinant", sp.factor(transverse_covariance.det()) == 2 * rho2**2)
collar_det = sp.factor(var_longitudinal * transverse_covariance.det())
require("exact collar determinant", collar_det == rho2**3 * (4 * X**2 + rho2))
require("axis degeneration", sp.simplify(collar_det.subs({Y: 0, Z: 0})) == 0)

r, x, y, z = sp.symbols("r x y z", real=True)
joint_scaled = sp.factor(collar_det.subs({X: r * x, Y: r * y, Z: r * z}))
require(
    "generic joint collar exponent",
    sp.factor(joint_scaled / r**8)
    == (y**2 + z**2) ** 3 * (4 * x**2 + y**2 + z**2),
)

q = sp.symbols("q", real=True)
hermite_nodal = q**2 * (q - r) ** 2
axial_coefficient = sp.factor(sp.diff(hermite_nodal, q) / sp.factorial(4))
transverse_coefficient = q * (q - r) / 2
require(
    "axial Hermite coefficient",
    axial_coefficient == q * (q - r) * (2 * q - r) / 12,
)
axial_det_monomial = sp.factor(
    axial_coefficient**2 * transverse_coefficient**4
)
axial_target = sp.factor(q**6 * (q - r) ** 6 * (2 * q - r) ** 2 / (12**2 * 2**4))
require("axial face monomial", axial_det_monomial == axial_target)
require("midpoint leading cancellation", axial_target.subs(q, r / 2) == 0)
endpoint_leading = sp.limit(
    axial_target / (q**6 * r**8 / (12**2 * 2**4)), q, 0
)
require("endpoint q^6 r^8 scale", endpoint_leading == 1)

c, rho_sq = sp.symbols("c rho_sq", real=True)
singular_det = rho_sq**5 * (c**2 + rho_sq) * (3 * c**2 + rho_sq) / 24
C, RHO = sp.symbols("C RHO", real=True)
singular_scaled = sp.factor(singular_det.subs({c: r * C, rho_sq: r**2 * RHO}))
require(
    "singular joint exponent",
    sp.factor(singular_scaled / r**14)
    == RHO**5 * (C**2 + RHO) * (3 * C**2 + RHO) / 24,
)

print("COLLAR_EXACT = rho_perp^6*(4*X^2+rho_perp^2)")
print("COLLAR_GENERIC_JOINT_SCALE = r^8")
print("COLLAR_AXIS = exact leading degeneration")
print("AXIAL_FACE = [q(r-q)]^6*(r-2q)^2 times a positive residual constant")
print("MIDPOINT_FACE = secondary blow-up required")
print("SINGULAR_EXACT = rho_perp^10*(c^2+rho_perp^2)*(3c^2+rho_perp^2)/24")
print("SCOPE_LIMIT: exact local Bargmann-Fock contact covariance and Hermite")
print("face monomials; finite-r side-24 comparison and integration remain open.")
print("ALL_ASSERTIONS_PASS")

