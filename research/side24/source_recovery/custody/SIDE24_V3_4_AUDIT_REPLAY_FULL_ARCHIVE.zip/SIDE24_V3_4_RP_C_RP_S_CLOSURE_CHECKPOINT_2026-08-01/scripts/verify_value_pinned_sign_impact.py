#!/usr/bin/env python3
"""Prove that the corrected ``-det H_S`` sign is load-bearing.

The independent audit correctly rediscovered the negative kappa-linear sign
in the value-unpinned ten-condition interpolation, but classified the typo as
sign-insensitive after absolute values are taken.  This verifier inserts the
missing witness-value relation.  With the corrected sign, ``-det H_S`` has
the required eta^2 factor; with the printed positive sign, its eta -> 0 limit
is generically nonzero.  Explicit exceptions keep every check active under
``python -O``.
"""

from __future__ import annotations

import sympy as sp


def require_zero(label: str, expression: sp.Expr) -> None:
    remainder = sp.factor(sp.cancel(sp.together(expression)))
    if remainder != 0:
        raise RuntimeError(f"{label} failed; residual={remainder}")


def require_nonzero(label: str, expression: sp.Expr) -> sp.Expr:
    remainder = sp.factor(sp.cancel(sp.together(expression)))
    if remainder == 0:
        raise RuntimeError(f"{label} unexpectedly vanished")
    return remainder


c, s, eta, kappa = sp.symbols("c s eta kappa", nonzero=True)
alpha, d, m, u = sp.symbols("alpha d m u")

q_m = (m + d) / 2
q_s = (m - d) / 2
A = 4 * c**2 - eta**2

minus_det_s_correct = (
    kappa**2 * A**2
    - 4
    * kappa
    * s**2
    * (A * q_m + (12 * c**2 + eta**2) * q_s)
    + 4 * s**4 * d**2
) / (64 * c**2 * s**2)

minus_det_s_printed = (
    kappa**2 * A**2
    + 4
    * kappa
    * s**2
    * (A * q_m + (12 * c**2 + eta**2) * q_s)
    + 4 * s**4 * d**2
) / (64 * c**2 * s**2)

# The third-value condition p(P)=-alpha*kappa/6 is equivalent to this
# solution for m=q_M+q_S on the regular c*s*eta != 0 chart.
R_alpha = (2 * c + eta) ** 2 - 8 * alpha * c * eta
m_value_pinned = (
    eta * d + kappa * eta * R_alpha / (2 * s**2)
) / (2 * c)

d_from_u = (
    8 * kappa * c * eta * u - kappa * (2 * c + eta) ** 2
) / (2 * s**2)
expected_value_pinned = (
    kappa**2
    * eta**2
    / s**2
    * ((u - 1) ** 2 - (1 - alpha))
)

correct_value_pinned = sp.factor(
    minus_det_s_correct.subs(m, m_value_pinned).subs(d, d_from_u)
)
wrong_value_pinned = sp.factor(
    minus_det_s_printed.subs(m, m_value_pinned).subs(d, d_from_u)
)

require_zero(
    "correct sign gives the value-pinned square completion",
    correct_value_pinned - expected_value_pinned,
)
require_zero(
    "correct sign has zero eta-contact limit at fixed normalized u",
    sp.limit(correct_value_pinned, eta, 0),
)

wrong_contact_limit = sp.factor(sp.limit(wrong_value_pinned, eta, 0))
require_zero(
    "printed sign leaves the claimed nonzero contact limit at fixed u",
    wrong_contact_limit - c**2 * kappa**2 / s**2,
)
require_nonzero(
    "printed sign destroys eta^2 suppression",
    wrong_contact_limit,
)

# The loci 2c=+/- eta are coefficient-degeneracy loci, not point collisions
# unless the additional angular condition s=0 is imposed.
dist_p_s_sq = ((2 * c - eta) ** 2 + 4 * s**2) / (4 * eta**2)
dist_p_m_sq = ((2 * c + eta) ** 2 + 4 * s**2) / (4 * eta**2)
require_zero(
    "2c=eta leaves P-S distance s^2/eta^2",
    dist_p_s_sq.subs(eta, 2 * c) - s**2 / (4 * c**2),
)
require_zero(
    "2c=-eta leaves P-M distance s^2/eta^2",
    dist_p_m_sq.subs(eta, -2 * c) - s**2 / (4 * c**2),
)

print("CORRECTED_SIGN_VALUE_PINNED_ETA2_FACTOR = VERIFIED")
print(f"PRINTED_SIGN_ETA0_LIMIT = {wrong_contact_limit}")
print("PRINTED_SIGN_LOAD_BEARING_FAILURE = VERIFIED")
print("2C_PLUS_MINUS_ETA = COEFFICIENT_DEGENERACY_NOT_COLLISION")
print(
    "SCOPE_LIMIT: limiting contact-plane algebra only; no finite-r, Palm, "
    "regional Kac--Rice, or elder-selection claim"
)
print("ALL_SIGN_IMPACT_CHECKS_PASS")
