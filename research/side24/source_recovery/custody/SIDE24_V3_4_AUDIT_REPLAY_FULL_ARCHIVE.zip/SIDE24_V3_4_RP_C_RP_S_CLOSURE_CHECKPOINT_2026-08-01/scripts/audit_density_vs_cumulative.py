#!/usr/bin/env python3
"""Guard against confusing a density with mass in a shrinking window.

The V2 off-diagonal argument inserted an extra factor of the lifetime itself
after passing to a density.  A Gaussian toy model makes the error explicit:
the mass of a window of width Delta is O(Delta), but division by Delta leaves
a density with a nonzero limit as the lifetime tends to zero.
"""

from __future__ import annotations

import sympy as sp


ell, delta = sp.symbols("ell delta", real=True, positive=True)
u = sp.symbols("u", real=True)

# If X and Y are independent N(0,1), then X-Y is N(0,2).
gap_density = sp.exp(-(ell**2) / 4) / (2 * sp.sqrt(sp.pi))
window_mass = sp.integrate(
    sp.exp(-(u**2) / 4) / (2 * sp.sqrt(sp.pi)),
    (u, ell, ell + delta),
)
recovered_density = sp.limit(window_mass / delta, delta, 0, dir="+")
contact_limit = sp.limit(gap_density, ell, 0, dir="+")

if sp.simplify(recovered_density - gap_density) != 0:
    raise RuntimeError("window differentiation did not recover the gap density")
if sp.simplify(contact_limit - 1 / (2 * sp.sqrt(sp.pi))) != 0:
    raise RuntimeError("unexpected zero-gap density")
if contact_limit == 0:
    raise RuntimeError("toy density should have a nonzero contact limit")

print("WINDOW_MASS_ORDER = O(delta)")
print(f"RECOVERED_DENSITY = {gap_density}")
print(f"ZERO_GAP_LIMIT = {contact_limit}")
print("V2_EXTRA_FACTOR_OF_ELL = REJECTED")
print("CONSERVATIVE_OFF_DIAGONAL_BOUND = O(1)")
print("ALL_DENSITY_CHECKS_PASS")

