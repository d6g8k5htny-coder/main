#!/usr/bin/env python3
"""Verify V3.4 structure, identities, status discipline, and checksums."""

from __future__ import annotations

import ast
import csv
import hashlib
from pathlib import Path


def require(name: str, condition: bool) -> None:
    if not condition:
        raise RuntimeError(f"{name} failed")


ROOT = Path(__file__).resolve().parents[1]
EXPECTED = [
    "00_READ_ME_FIRST.md",
    "01_V3_CORRECTIVE_CHECKPOINT.md",
    "02_GAP_REGISTER.csv",
    "03_V2_DISPOSITION.md",
    "04_SOURCE_PROVENANCE.md",
    "05_V3_CORRECTIVE_ADDENDUM.pdf",
    "06_SHA256SUMS.txt",
    "07_INDEPENDENT_AUDIT_DISPOSITION.md",
    "08_AUDIT_FINDINGS_REGISTER.csv",
    "09_AUDIT_RECONCILIATION_RESPONSE.md",
    "10_PACKAGE_SCOPE_MATRIX.csv",
    "11_V5_FORWARD_BRANCH_ADJUDICATION.md",
    "12_V5_PACKAGE_LINEAGE_MATRIX.csv",
    "13_RP_C_RP_S_CLOSURE_DISPOSITION.md",
    "requirements.txt",
    "baseline/11_COMPLETE_PRE_REVIEW_PACKET_R2.pdf",
    "drafts/elder_mark_and_exhaustion.md",
    "drafts/constrained_triple_contact_repair.md",
    "drafts/capture_escape_repair.md",
    "drafts/fixed_distance_witness_audit.md",
    "drafts/palm_transfer_repair_v3_3.md",
    "drafts/rp_f_global_envelope_counterexample.md",
    "drafts/joint_collar_compactification_target.md",
    "drafts/generic_transverse_collar_face.md",
    "drafts/mixed_singular_transition_face.md",
    "drafts/quartic_remainder_audit_note.md",
    "drafts/rp_c_rp_s_facewise_closure.md",
    "drafts/three_hessian_conditional_moment_envelope.md",
    "drafts/value_preserving_interpolation_envelope.md",
    "evidence/PDF_QA.txt",
    "evidence/V5_PDF_QA.txt",
    "evidence/V3_CHECK_RESULTS.txt",
    "evidence/V3_1_CHECK_RESULTS.txt",
    "evidence/V3_2_CHECK_RESULTS.txt",
    "evidence/V3_3_CHECK_RESULTS.txt",
    "evidence/V3_4_CHECK_RESULTS.txt",
    "evidence/PREDECESSOR_V3_2_SHA256.txt",
    "evidence/PREDECESSOR_V3_3_SHA256.txt",
    "evidence/COLLAR_PROJECTIVE_CHART_AUDIT_2026-08-01.md",
    "evidence/HYBRID_SECTION6_INDEPENDENT_AUDIT_2026-08-01.md",
    "evidence/verify_hybrid_mixed_curvature_and_axis_absorption.out.txt",
    "evidence/verify_hybrid_mixed_curvature_and_axis_absorption.O.out.txt",
    "evidence/verify_hybrid_mixed_curvature_and_axis_absorption.negative_probe.out.txt",
    "evidence/independent_audit/SIDE24_INDEPENDENT_AUDIT_SNAPSHOT_2026-07-31.zip",
    "evidence/independent_audit/INDEPENDENT_AUDIT_FINDINGS_2026-07-31.md",
    "evidence/independent_audit/INDEPENDENT_AUDIT_RUN_LOG_2026-07-31.md",
    "evidence/audit_reconciliation/SIDE24 AUDIT RECONCILIATION SNAPSHOT 2026-07-31.zip",
    "evidence/audit_reconciliation/AUDIT_RECONCILIATION_ADDENDUM_2026-07-31.md",
    "evidence/audit_reconciliation/verify_disposition_s3_v1.py",
    "evidence/audit_reconciliation/verify_disposition_s3_v1.out.txt",
    "evidence/v5_forward_branch/OKComputer_Project_Gap_Closure_1_119ffbfa.zip",
    "scripts/run_v3_checks.py",
    "scripts/run_external_audit_checks.py",
    "scripts/audit_original_v2_manifest.py",
    "scripts/verify_constrained_triple_contact.py",
    "scripts/verify_corrected_det_hs.py",
    "scripts/verify_value_pinned_sign_impact.py",
    "scripts/verify_disposition_s3_v1.py",
    "scripts/verify_reconciliation_evidence.py",
    "scripts/verify_fixed_distance_power_count.py",
    "scripts/verify_capture_escape_budgets.py",
    "scripts/verify_palm_transfer_repair.py",
    "scripts/verify_joint_collar_regression.py",
    "scripts/diagnose_side24_generic_collar.py",
    "scripts/verify_facewise_collar_axis_integration.py",
    "scripts/verify_quartic_endpoint_counterexample.py",
    "scripts/verify_hybrid_mixed_curvature_and_axis_absorption.py",
    "scripts/audit_v5_forward_branch.py",
    "scripts/verify_checkpoint_structure.py",
    "scripts/audit_density_vs_cumulative.py",
    "scripts/audit_v2_elder_mark.py",
]

missing = [relative for relative in EXPECTED if not (ROOT / relative).is_file()]
require("required-file set", not missing)

checksum_records: dict[str, str] = {}
for line in (ROOT / "06_SHA256SUMS.txt").read_text(encoding="utf-8").splitlines():
    if not line.strip():
        continue
    digest, relative = line.split("  ", 1)
    require(f"unique checksum row {relative}", relative not in checksum_records)
    checksum_records[relative] = digest
checksum_targets = {
    path.relative_to(ROOT).as_posix()
    for path in ROOT.rglob("*")
    if path.is_file()
    and path.name != "06_SHA256SUMS.txt"
    and "__pycache__" not in path.parts
    and path.suffix != ".pyc"
}
require("checksum target set", set(checksum_records) == checksum_targets)
for relative, expected_digest in sorted(checksum_records.items()):
    actual_digest = hashlib.sha256((ROOT / relative).read_bytes()).hexdigest()
    require(f"checksum for {relative}", actual_digest == expected_digest)

fixed_hashes = {
    "baseline/11_COMPLETE_PRE_REVIEW_PACKET_R2.pdf":
        "b652a8b31820a458b43b46d7f83eb5b842b973c0a8bd37d8cb9e0ff95cb9c83f",
    "evidence/independent_audit/SIDE24_INDEPENDENT_AUDIT_SNAPSHOT_2026-07-31.zip":
        "9e2e0637706685692cdce770f4c4e74c7154baaabbc319de77e6defd34ab5a01",
    "evidence/audit_reconciliation/SIDE24 AUDIT RECONCILIATION SNAPSHOT 2026-07-31.zip":
        "7be11c3e2ee6a185ca13bb91a18b656855ca3f458d853c93c5f5ba71fbb8a97e",
    "evidence/v5_forward_branch/OKComputer_Project_Gap_Closure_1_119ffbfa.zip":
        "119ffbfae2d11cc2d3de60f15c06a653c48b17d06ab0a2e125260ab0f1458c5a",
}
for relative, expected in fixed_hashes.items():
    require(
        f"frozen hash {relative}",
        hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() == expected,
    )

predecessor = (ROOT / "evidence/PREDECESSOR_V3_2_SHA256.txt").read_text(
    encoding="utf-8"
)
require(
    "V3.2 grandparent identity",
    "5a17a8e6053943d969968229e9c509bf16abc686faee204f6e4fb78cd3c50407"
    in predecessor,
)
predecessor_v3_3 = (
    ROOT / "evidence/PREDECESSOR_V3_3_SHA256.txt"
).read_text(encoding="utf-8")
require(
    "V3.3 direct predecessor identity",
    "4040d654bddb1fc3b22eafa87bea7d0875166c03150d12602d6c1a0cb6385cfc"
    in predecessor_v3_3,
)

readme = (ROOT / "00_READ_ME_FIRST.md").read_text(encoding="utf-8")
checkpoint = (ROOT / "01_V3_CORRECTIVE_CHECKPOINT.md").read_text(
    encoding="utf-8"
)
adjudication = (ROOT / "11_V5_FORWARD_BRANCH_ADJUDICATION.md").read_text(
    encoding="utf-8"
)
joint_target = (
    ROOT / "drafts/joint_collar_compactification_target.md"
).read_text(encoding="utf-8")
require("readme V3.4 title", "V3.4" in readme)
require("checkpoint V3.4 title", "V3.4" in checkpoint)
require("readme HOLD status", "**HOLD" in readme)
require("checkpoint HOLD status", "**HOLD" in checkpoint)
require("adjudication partial acceptance", "PARTIAL ACCEPTANCE" in adjudication)
require(
    "adjudication localizes open gates",
    "RP-C" in adjudication and "RP-S" in adjudication and "Candidate theorem | **HOLD**" in adjudication,
)
require(
    "global Palm envelope rejected",
    "global RP-F claim is rejected" in adjudication
    and "pair-conditioned law" in adjudication,
)
require(
    "joint collar regression recorded",
    r"\varrho^6(4X^2+\varrho^2)" in adjudication
    and "secondary" in joint_target
    and "midpoint" in joint_target,
)

closure = (ROOT / "drafts/rp_c_rp_s_facewise_closure.md").read_text(
    encoding="utf-8"
)
moment_envelope = (
    ROOT / "drafts/three_hessian_conditional_moment_envelope.md"
).read_text(encoding="utf-8")
require(
    "V3.4 common Hessian monomial",
    r"[r(r+s^2)]^2(r^2+s^3)" in closure,
)
require(
    "V3.4 facewise conclusions",
    r"\mathbb E^{MS}N_{\rm col}\le Cr^3" in closure
    and r"\mathbb E^{MS}N_{\rm sing}\le Cr^3" in closure,
)
require(
    "V3.4 audit discipline",
    "HOLD / ready for independent" in closure,
)
require(
    "V3.4 hybrid moment discipline",
    "Axial density-weighted statement" in closure
    and "pathwise bound" in moment_envelope
    and "false on the exact axial face" in moment_envelope,
)
require(
    "V3.4 explicit collar projective frames",
    "Axial-interior projective crossover" in closure
    and r"\delta_m^2" in closure
    and "EP.2" in closure,
)
require(
    "V3.4 pair-measurable singular frame",
    r"\bar V_0" in closure
    and "must be a function of the raw witness block" in closure
    and r"\ge c\Lambda^{10}" in closure
    and "No unpinned midpoint coarea integral" in closure,
)
require(
    "endpoint pointwise overclaim rejected",
    "There is no version of (H.26)" in moment_envelope
    and "measure-level estimate" in moment_envelope,
)

audit_disposition = (ROOT / "07_INDEPENDENT_AUDIT_DISPOSITION.md").read_text(
    encoding="utf-8"
)
require("audit disposition retains HOLD", "retain HOLD" in audit_disposition)
require(
    "audit disposition records load-bearing sign",
    "load-bearing" in audit_disposition
    and "c^2*kappa^2/s^2" in audit_disposition,
)

with (ROOT / "02_GAP_REGISTER.csv").open(
    newline="", encoding="utf-8"
) as handle:
    rows = list(csv.DictReader(handle))
require("gap-register row count", len(rows) >= 27)
ids = [row["id"] for row in rows]
require("gap-register unique IDs", len(ids) == len(set(ids)))
status_by_id = {row["id"]: row["status"] for row in rows}
require("candidate theorem remains HOLD", status_by_id.get("V3-13") == "HOLD")
require(
    "finite-r collar proved pending audit",
    status_by_id.get("V3-09") == "PROVED_IN_V3_4_AUDIT_PENDING",
)
require(
    "finite-r singular proved pending audit",
    status_by_id.get("V3-10") == "PROVED_IN_V3_4_AUDIT_PENDING",
)
require(
    "elder selection proved pending audit",
    status_by_id.get("V3-12") == "PROVED_IN_V3_4_AUDIT_PENDING",
)
require(
    "Palm capture proved with repair",
    status_by_id.get("V3-08") == "PROVED_WITH_V3_3_REPAIR",
)
require(
    "fixed-distance integrated status",
    status_by_id.get("V3-11") == "PROVED_COMPACT_AND_INTEGRATED_V3_3",
)
require(
    "global conditional envelope rejected",
    status_by_id.get("V3.2-R4") == "REJECTED_IN_V3_3",
)

with (ROOT / "12_V5_PACKAGE_LINEAGE_MATRIX.csv").open(
    newline="", encoding="utf-8"
) as handle:
    lineage = list(csv.DictReader(handle))
require("lineage row count", len(lineage) == 5)
lineage_by_id = {row["package_id"]: row for row in lineage}
require(
    "V5 exact current manifest",
    lineage_by_id["V5_FORWARD_BRANCH"]["manifest_result"]
    == "127/127 non-self V5 payloads",
)
require(
    "V4 historical mismatch recorded",
    lineage_by_id["V5_EMBEDDED_V4"]["manifest_result"] == "106/108",
)

text_suffixes = {".md", ".csv", ".txt", ".py"}
for path in sorted(ROOT.rglob("*")):
    if not path.is_file() or path.suffix.lower() not in text_suffixes:
        continue
    data = path.read_bytes()
    bad = [byte for byte in data if byte < 32 and byte not in (9, 10)]
    require(f"no control characters in {path.relative_to(ROOT)}", not bad)

for script in sorted((ROOT / "scripts").glob("*.py")):
    source = script.read_text(encoding="utf-8")
    tree = ast.parse(source, filename=str(script))
    bare_asserts = [node for node in ast.walk(tree) if isinstance(node, ast.Assert)]
    require(f"no bare assert in {script.name}", not bare_asserts)
    for forbidden in ("/" + "mnt/", "/" + "workspace/"):
        require(
            f"no hardcoded runtime path in {script.name}",
            forbidden not in source,
        )

print(f"EXPECTED_FILE_COUNT = {len(EXPECTED)}")
print(f"CHECKSUM_TARGET_COUNT = {len(checksum_records)}")
print(f"GAP_REGISTER_ROW_COUNT = {len(rows)}")
print(f"LINEAGE_ROW_COUNT = {len(lineage)}")
print("FROZEN_HASHES = 4/4 VERIFIED")
print("NO_TEXT_CONTROL_CHARACTERS = VERIFIED")
print("NO_BARE_ASSERTS = VERIFIED")
print("NO_HARDCODED_RUNTIME_PATHS = VERIFIED")
print("HOLD_PENDING_INDEPENDENT_V3_4_AUDIT = VERIFIED")
print("ALL_STRUCTURE_CHECKS_PASS")
