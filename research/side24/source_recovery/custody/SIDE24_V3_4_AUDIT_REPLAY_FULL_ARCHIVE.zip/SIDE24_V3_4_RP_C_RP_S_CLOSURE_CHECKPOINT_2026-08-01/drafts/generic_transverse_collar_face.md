# Generic transverse collar face for the exact side-24 field

## Statement

Let \(f\) be the centered periodized Bargmann--Fock field on
\(\mathbb T_{24}^{3}\), normalized by \(K_{24}(0)=1\). Its Fourier masses

\[
 w_n=Z_{24}^{-1}\exp\!\left(-\frac12
       \left|\frac{2\pi n}{24}\right|^2\right),\qquad n\in\mathbb Z^3,
\]

are strictly positive. Fix an oriented orthonormal frame
\(E=(t,e_2,e_3)\in SO(3)\), a midpoint \(x\in\mathbb T_{24}^3\), and

\[
 M=x-\frac r2t,\qquad S=x+\frac r2t,\qquad
 y=x+r(\xi_1t+\xi_2e_2+\xi_3e_3).
\]

Write \(\rho_\xi=(\xi_2^2+\xi_3^2)^{1/2}\),
\(X=r\xi_1\), and \(\varrho=r\rho_\xi\). Let

\[
 \Phi_r=(f(M),\nabla f(M),f(S),\nabla f(S))
\]

and let \(C_{24}(r,E,\xi)\) be the \(3\times3\) conditional covariance of
\((\partial_tf(y),\partial_{e_2}f(y),\partial_{e_3}f(y))\) given
\(\Phi_r\).

For \(0<\epsilon<C\), put

\[
 \mathcal K_{\epsilon,C}=\left\{\xi:\ |\xi|\le C,\quad
 \rho_\xi\ge\epsilon,\quad
 \min\{|\xi_1|,|\xi_1-\tfrac12|,|\xi_1+\tfrac12|\}\ge\epsilon
 \right\}.
\]

The last three inequalities merely implement the requested separation from
the midpoint and endpoint faces. They are not needed for this lemma once
\(\rho_\xi\ge\epsilon\); the strict transverse condition already keeps the
witness distinct from both pair points.

**Generic-face lemma.** There are \(r_0=r_0(\epsilon,C)>0\) and finite
constants \(0<c_{\epsilon,C}\le C_{\epsilon,C}<\infty\), depending only on
the exact side-24 covariance and the displayed compact set, such that,
uniformly in \(x,E,\xi\) and \(0<r\le r_0\),

\[
 c_{\epsilon,C}\,
 \varrho^6(4X^2+\varrho^2)
 \ \le\ \det C_{24}(r,E,\xi)\ \le\
 C_{\epsilon,C}\,
 \varrho^6(4X^2+\varrho^2).
 \tag{1}
\]

Thus the generic transverse face of RP-C has the required finite-\(r\)
Schur-complement comparison for the exact periodized field. No planar
approximation or unquantified periodization-tail replacement occurs in the
proof.

## Corrected pins and normalized witness residuals

Use the corrected pin basis

\[
 V_r=\left(f(M),\nabla f(M),
 \frac{\nabla f(S)-\nabla f(M)}r,
 \frac{f(S)-f(M)-\frac r2(\partial_tf(S)+\partial_tf(M))}{r^3}
 \right).
\]

It spans the same Gaussian subspace as \(\Phi_r\). Put
\(d_r=(\nabla f(S)-\nabla f(M))/r\), \(u=\xi+\frac12t\), and denote the
last scalar component of \(V_r\) by \(v_r\). The following functionals
differ from the witness gradient only by linear combinations of \(V_r\):

\[
\begin{aligned}
 R_{2,r}&=r^{-1}\left[\partial_{e_2}f(y)-\partial_{e_2}f(M)
       -r(\xi_1+\tfrac12)(d_r)_{e_2}\right],\\
 R_{3,r}&=r^{-1}\left[\partial_{e_3}f(y)-\partial_{e_3}f(M)
       -r(\xi_1+\tfrac12)(d_r)_{e_3}\right],\\
 R_{1,r}&=r^{-2}\left[\partial_tf(y)-\partial_tf(M)-r\,u\cdot d_r
       +r^2(6\xi_1^2-\tfrac32)v_r\right].
\end{aligned}
\tag{2}
\]

Here \(u\cdot d_r\) is interpreted in the frame \(E\), with
\(u=(\xi_1+\frac12,\xi_2,\xi_3)\). Consequently, with
\(A_r=\operatorname{diag}(r^{-2},r^{-1},r^{-1})\),

\[
 \widehat C_r:=\operatorname{Cov}(R_{1,r},R_{2,r},R_{3,r}\mid V_r)
 =A_r C_{24}(r,E,\xi)A_r,
 \qquad \det C_{24}=r^8\det\widehat C_r.
 \tag{3}
\]

For the joint value-gradient density, put

\[
 R_{0,r}=r^{-3}\left[f(y)-f(M)
 -\frac r2u\mathbin\cdot\{\nabla f(y)+\nabla f(M)\}\right].
 \tag{3a}
\]

This is an exact trapezoidal Hermite residual.  Conditional on the pair
pins, the map from \((f(y),\nabla f(y))\) to
\((R_{0,r},R_{1,r},R_{2,r},R_{3,r})\) is triangular up to shears, with
diagonal \((r^{-3},r^{-2},r^{-1},r^{-1})\).  Its determinant therefore has
magnitude exactly \(r^{-7}\).

Taylor expansion in the spectral Hilbert space gives the uniform limits

\[
 V_r\longrightarrow P_t=(f,D_tf,D_{e_2}f,D_{e_3}f,
 D_t^2f,D_tD_{e_2}f,D_tD_{e_3}f,-D_t^3f/12)
\]

and, with \(D_v=\xi_2D_{e_2}+\xi_3D_{e_3}\),

\[
\begin{aligned}
 R_{1,r}&\longrightarrow A_1=\xi_1D_t^2D_vf+\tfrac12D_tD_v^2f,\\
 R_{2,r}&\longrightarrow A_2=D_vD_{e_2}f,\\
 R_{3,r}&\longrightarrow A_3=D_vD_{e_3}f.
\end{aligned}
\tag{4}
\]

The value row has the simultaneous limit

\[
 R_{0,r}\longrightarrow A_0=-\frac1{12}D_u^3f,
 \qquad u=(\xi_1+\tfrac12)t+\xi_2e_2+\xi_3e_3.             \tag{4a}
\]

The coefficient \(6\xi_1^2-3/2\) in (2) cancels the pure \(D_t^3\) term:
before using \(v_r\to-D_t^3/12\), its coefficient is
\(\xi_1^2/2-1/8\).

## Exact side-24 rank argument

The symbols of the contact pins span

\[
 \mathcal P_t=\operatorname{span}
 \{1,T,E_2,E_3,T^2,TE_2,TE_3,T^3\}.
\]

Put \(V=\xi_2E_2+\xi_3E_3\). The four residual symbols are

\[
 a_0=-\{(\xi_1+\tfrac12)T+V\}^3/12,\quad
 a_1=TV(\xi_1T+V/2),\quad a_2=VE_2,\quad a_3=VE_3.
\]

If \(\sum_{j=0}^3\alpha_ja_j\in\mathcal P_t\), the \(V^3\) term first
forces \(\alpha_0=0\).  The \(TV^2\) term then forces
\(\alpha_1=0\).  Comparison of degree-two terms finally gives
\(V(\alpha_2E_2+\alpha_3E_3)=0\), hence
\(\alpha_2=\alpha_3=0\). Therefore the residual classes are independent
modulo the pin space whenever \(\rho_\xi>0\).

For the exact side-24 field, a derivative polynomial with zero variance
vanishes at every frequency \((2\pi/24)n\). A polynomial vanishing on the
whole integer lattice is identically zero (iterate the one-variable fact in
the three coordinates). Since every Fourier mass is positive, the Gram
matrix of the twelve limiting functionals in (4), (4a), and \(P_t\) is therefore
strictly positive definite. This proves

\[
 \widehat C_0(E,\xi):=\operatorname{Cov}(A_1,A_2,A_3\mid P_t)\succ0
 \quad\text{for }\rho_\xi>0.
\]

This is an exact Fourier-distribution argument for the periodized field,
not an appeal to the planar Bargmann--Fock covariance.

The same argument gives a uniform eigenfloor for the normalized joint
value-gradient block on each strict transverse compact set.  Together with
the exact determinant in (3a), its density is \(O(r^{-7})\).

## Compactness and constants

Exponential Fourier decay gives every spectral derivative moment, so the
maps \(r\mapsto V_r\) and \(r\mapsto R_r\) extend continuously in the
spectral \(L^2\) space to (4), uniformly on
\(SO(3)\times\mathcal K_{\epsilon,C}\). Schur complements are continuous
because the corrected-pin Gram matrix has a positive uniform floor on this
compact set. Hence there are

\[
 m_0=\min_{SO(3)\times\mathcal K_{\epsilon,C}}
       \lambda_{\min}(\widehat C_0)>0,
 \qquad
 M_0=\max_{SO(3)\times\mathcal K_{\epsilon,C}}
       \lambda_{\max}(\widehat C_0)<\infty.
\]

Uniform continuity permits \(r_0>0\), also chosen so that
\((C+1/2)r_0<12\), for which

\[
 \lambda_{\min}(\widehat C_r)\ge m_0/2,
 \qquad \lambda_{\max}(\widehat C_r)\le2M_0.
\]

On the normalized domain,

\[
 \epsilon^8\le
 \rho_\xi^6(4\xi_1^2+\rho_\xi^2)
 \le5C^8.
\]

Therefore (1) holds with

\[
 c_{\epsilon,C}=\frac{(m_0/2)^3}{5C^8},
 \qquad
 C_{\epsilon,C}=\frac{(2M_0)^3}{\epsilon^8}.
\]

The midpoint \(x\) causes no additional parameter because the field is
stationary. Using \(SO(3)\), rather than attempting a global continuous
choice of \((e_2,e_3)\) on \(S^2\), avoids the tangent-frame obstruction;
the determinant is invariant under rotations of the transverse frame.

## Sharp domain limitation and counterexample

The upper bound in (1) cannot include the finite-\(r\) axial face. If
\(\varrho=0\) and \(y\) is an axial point distinct from \(M,S\), then the
reference monomial is zero, while

\[
 \det\operatorname{Cov}(\nabla f(y)\mid\Phi_r)>0.
\]

The strict inequality follows from Fourier-distribution independence of
the derivative evaluations at the three distinct points. Thus no finite
constant can satisfy
\(\det C_{24}\le C\varrho^6(4X^2+\varrho^2)\) on the axis. A separate
Hermite/axial blow-up is mandatory. Midpoint and endpoint charts become
separate issues only in the closure toward that axial face; they do not
obstruct the strict transverse compact set proved here.

## Numerical regression

The accompanying diagnostic evaluates the corrected Schur complement using
50,541 Fourier modes (\(|k|\le6\)), four pair orientations, six generic
directions, and \(r=0.4,0.2,0.1,0.05,0.02\), plus the contact limit. The
determinant ratio stayed in [0.781040, 1.83594]; at \(r=0.02\) every probe
was within \(0.21\%\) of its contact-limit ratio. The minimum normalized
Schur eigenvalue was 0.0485002. These numbers are diagnostic only; the
proof above uses the complete exact spectrum.
