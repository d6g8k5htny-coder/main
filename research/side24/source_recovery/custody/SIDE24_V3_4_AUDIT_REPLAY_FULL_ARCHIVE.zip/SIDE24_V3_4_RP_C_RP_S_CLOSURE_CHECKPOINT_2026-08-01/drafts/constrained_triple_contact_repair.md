# SIDE24 triple-contact repair: the missing third-value pin

**Status (2026-07-31).** This note repairs the limiting two-dimensional cubic
elimination used at the singular-near contact face.  It does **not** close the
finite-`r` collar or singular-near Kac--Rice estimates.  The exact remaining
finite-`r` premise is stated at the end.

## 1. Why the v2 elimination did not prove G6-prime

The script `SIDE24_gap_fill/scripts/triple_contact_elimination.py` imposed

- stationarity at `M=(-1/2,0)`, `S=(1/2,0)`, and
  `P=(c/eta,s/eta)`;
- `p(M)=0` and `p(S)=-kappa/6`; and
- endpoint transverse curvatures `p_YY(M)=q_M`,
  `p_YY(S)=q_S`.

It did **not** impose the witness-value condition

```text
p(P) = -alpha*kappa/6,       0 <= alpha <= 1.
```

That condition is load-bearing: it creates the relation among `q_M`, `q_S`
that produces the `eta^2` factor in every plane determinant.  Without it, the
generic endpoint determinants are indeed order `kappa^2` as `eta -> 0`, but
those cubics are not the value-window triple contacts counted in G6-prime.

The v2 display also has the wrong sign in the term linear in `kappa` for
`-det H_S`.  Before imposing the third-value condition, the correct formula is

```text
-det H_S = [kappa^2(4c^2-eta^2)^2
             -4*kappa*s^2((4c^2-eta^2)q_M
                          +(12c^2+eta^2)q_S)
             +4*s^4(q_M-q_S)^2] /(64c^2s^2).
```

This is the formula printed by the symbolic output, not the positive-sign
formula printed in Supplement B.1.

## 2. Exact value-pinned cubic normal form

Assume

```text
kappa > 0, eta > 0, 0 <= alpha <= 1,
c^2+s^2=1, and c*s != 0.
```

Put

```text
M=(-1/2,0),  S=(1/2,0),  P=(c/eta,s/eta),
d=q_M-q_S,   m=q_M+q_S.
```

Every cubic satisfying the two endpoint value, stationarity, and transverse
curvature conditions has the unique normal form

```text
p(X,Y) = kappa*(X^3/3-X/4-1/12)
       + lambda*(X^2-1/4)*Y
       + (1/2)*(m/2-d*X)*Y^2
       + (gamma/6)*Y^3.                                  (2.1)
```

The equation `p_X(P)=0` gives

```text
lambda = [-kappa*(4c^2-eta^2)+2d*s^2]/(8cs).              (2.2)
```

The equation `p_Y(P)=0` determines `gamma`.  Eliminating `gamma` from the
third-value equation `p(P)=-alpha*kappa/6` gives

```text
2s^2(2cm-eta*d) = kappa*eta*R_alpha,                       (2.3)
R_alpha=(2c+eta)^2-8alpha*c*eta.
```

Thus the missing value pin is exactly the missing linear relation between the
sum and difference of the endpoint transverse curvatures.

Define the normalized cone coordinate

```text
u = [2s^2*d+kappa*(2c+eta)^2]/(8*kappa*c*eta).             (2.4)
```

Direct differentiation of (2.1), followed by (2.2)--(2.4), gives the exact
identities

```text
-det H_M = (kappa^2*eta^2/s^2) [u^2-alpha],                (2.5)

-det H_S = (kappa^2*eta^2/s^2)
           [(u-1)^2-(1-alpha)],                            (2.6)

 det H_P = -(kappa^2*eta^2/s^2)
           [(u-alpha)^2+alpha*(1-alpha)].                  (2.7)
```

Here each Hessian is the two-by-two Hessian of the restriction to the plane
spanned by the pair axis and the third-point direction.

### Proof of the value relation

At `P=(c/eta,s/eta)`, use `p_Y(P)=0` to eliminate the cubic `Y^3`
term from `p(P)`.  Substitution of (2.2) then reduces the value to

```text
p(P) = -kappa*(2c+eta)^2/(48c*eta)
       -d*s^2/(24c*eta)
       +m*s^2/(12eta^2).
```

Equating this to `-alpha*kappa/6` is exactly (2.3).

### Proof of the determinant identities

Before the value relation is used, set `A=4c^2-eta^2` and
`B=4c^2+eta^2`.  The corrected endpoint formulas are

```text
-det H_M = [kappa^2*A^2
             +4*kappa*s^2((12c^2+eta^2)q_M+A*q_S)
             +4s^4*d^2]/(64c^2s^2),

-det H_S = [kappa^2*A^2
             -4*kappa*s^2(A*q_M+(12c^2+eta^2)q_S)
             +4s^4*d^2]/(64c^2s^2).
```

Using (2.3), the three numerators complete squares:

```text
64c^2s^2*(-det H_M)
  = [2s^2*d+kappa*(2c+eta)^2]^2
    -64alpha*kappa^2*c^2*eta^2,

64c^2s^2*(-det H_S)
  = [2s^2*d+kappa*(2c-eta)^2]^2
    -64(1-alpha)*kappa^2*c^2*eta^2,

64c^2s^2*(det H_P)
  = -[2s^2*d+kappa*R_alpha]^2
    -64alpha*(1-alpha)*kappa^2*c^2*eta^2.
```

The three bracketed square variables equal respectively

```text
8*kappa*c*eta*u,
8*kappa*c*eta*(u-1),
8*kappa*c*eta*(u-alpha),
```

which proves (2.5)--(2.7).

## 3. Type-cone consequence

If the full three-dimensional Hessian at `M` is negative definite, then its
restriction to the contact plane is negative definite and therefore
`det H_M>0`.  Equation (2.5) implies

```text
u^2 < alpha.                                               (3.1)
```

Consequently `|u|<=1` on the typed support.  Equations (2.5)--(2.7) then give,
for an absolute constant `C`,

```text
|det H_M det H_S det H_P| <=
    C*kappa^6*eta^6*s^(-6).                                (3.2)
```

Thus, on every angular subchart `|s|>=s_0>0`, the exact elimination proves
the contact-face factor

```text
kappa^6*eta^6*R_eta
```

with `R_eta` uniformly bounded on compact `(alpha,eta)` sets after the type
restriction.  This is the algebraic content needed in Module B equation
(38).  It is not available from the value-unpinned v2 script.

## 4. The perpendicular chart `c=0`

The coordinate `u` is singular at `c=0`, although the geometry is not.  Take
`c=0`; then `s^2=1` and `P=(0,s/eta)`.  The equation `p_X(P)=0` forces

```text
d = -kappa*eta^2/2.                                       (4.1)
```

Define

```text
mu=m/(kappa*eta^2).
```

The equations `p_Y(P)=0` and `p(P)=-alpha*kappa/6` give

```text
lambda=(kappa*eta*s/2)*(mu-1+2alpha).                      (4.2)
```

The exact determinants are

```text
det H_M = kappa^2*eta^2
          [1/4-mu/2-(mu-1+2alpha)^2/4],                    (4.3)

det H_S = kappa^2*eta^2
          [mu/2+1/4-(mu-1+2alpha)^2/4],                    (4.4)

det H_P = -kappa^2*eta^2
          [mu^2+4alpha*(1-alpha)]/4.                       (4.5)
```

Negative definiteness at `M` implies `det H_M>0`, equivalently

```text
mu^2+4alpha*mu-4alpha*(1-alpha)<0,
```

or

```text
-2alpha-2sqrt(alpha) < mu < -2alpha+2sqrt(alpha).          (4.6)
```

In particular `|mu|<4`, and all three determinants are uniformly
`O(kappa^2*eta^2)` on the typed support.  Hence `c=0` is a regular separate
contact chart, not a collision singularity.

## 5. The collinear axis `s=0`

For `s=0`, a nondegenerate cubic restricted to the pair line cannot have the
three distinct stationary points `M`, `S`, and `P`: its derivative is
quadratic and already has the two roots `M` and `S`.  This boundary must be
handled by the singular-axis probability estimate, not by division through
the `s`-chart.

At the Euclidean contact face, Module B's corrected conditional density obeys

```text
p_corr <= C*s^(-5)*exp(-c_0/s^4)                           (5.1)
```

near `s=0`, because the corrected mean mismatch remains nonzero when
`eta<=eta_0<1`.  Combining (3.2) with the spherical area element
`s ds dphi` is integrable:

```text
integral_0^epsilon s^(-10)*exp(-c_0/s^4) ds < infinity.    (5.2)
```

More generally, the exponential absorbs every fixed polynomial angular loss
coming from a finite collection of divided differences.  This closes the
**limiting contact-face angular integral**, but not its finite-`r` uniform
version.

The loci `2c=+/-eta` are not algebraic singularities of the displayed
determinants.  They only make one leading square coefficient vanish (or align
a projection with an endpoint).  Actual point collision requires the
additional condition `s=0`; with `eta<1` it is outside the singular-near
chart in any event.

## 6. Radial integration, conditional on the finite-r envelope

Suppose the exact side-24 conditional Kac--Rice integrand satisfies, uniformly
for `C_1*r<=t<=delta`, compact `b`, compact positive `kappa`, and
`alpha in [0,1]`,

```text
integral_(S^2) p_(f(y),grad f(y)|pair)(u,0)
  E[W_r*|det H_y| | all pins] d omega
 <= C*t^(-7)*[r(r+t^2)]^2*(r^2+t^3).                      (6.1)
```

Using `Z_r>=c_Z*r^2`, value-window width `kappa*r^3/6`, and polar volume
`t^2 dt`, the Palm witness expectation is bounded by

```text
C*r * integral_(C_1*r)^delta
       t^(-5)*[r(r+t^2)]^2*(r^2+t^3) dt.                  (6.2)
```

The six terms are

```text
r^7*t^(-5),  2r^6*t^(-3),  r^5*t^(-1),
r^5*t^(-2),  2r^4,          r^3*t^2.
```

Their integrals are respectively

```text
O(r^3), O(r^4), O(r^5 log(1/r)), O(r^4), O(r^4), O(r^3).
```

Therefore (6.1) implies the desired singular-near bound `O(r^3)`.  The radial
calculus in Module B is correct; the unresolved issue is precisely the
uniform estimate (6.1).

## 7. Exact residual premise

The contact calculation above does not control the higher-order Taylor terms
when the small separation and an angular degeneracy approach zero together.
To close G5/G6-prime one still needs the following finite-`r` lemma.

> **Finite-r joint-blow-up lemma (open).** Construct normalized
> divided-difference functionals for the exact side-24 field that extend
> continuously over (i) the collar compactification of `(r,rho)=(0,0)` and
> (ii) the singular-near compactification of `(t,rho)=(0,0)`, uniformly in
> `eta=r/t in [0,eta_0]`, `alpha in [0,1]`, direction frames, and compact mark
> sets.  On every boundary face prove:
>
> 1. the designated pair-pin family is independent;
> 2. the normalized third value-gradient residual family has either a
>    positive conditional covariance eigenfloor or a quantified mean-mismatch
>    penalty uniform enough to replace (5.1);
> 3. after imposing the endpoint type cone, the conditional ninth-degree
>    Hessian moment obeys the angularly weighted determinant estimate needed
>    for (6.1), and the analogous collar estimate; and
> 4. the constants and polynomial angular losses are uniform on the full
>    compactification.

Full positive Fourier support proves a positive eigenfloor only after the
normalized derivative distributions and their independence have been
identified on each boundary face.  The existing Module E contact-face
argument does not identify the new faces where `rho` is comparable to `r` or
`t`.  The value-unpinned v2 elimination also cannot substitute for this
lemma.

Until that joint-blow-up lemma is proved, the honest status is:

- corrected limiting cubic elimination: **proved**;
- `c=0` limiting chart and contact angular integrability: **proved**;
- six-term radial power count conditional on (6.1): **proved**;
- uniform finite-`r` collar and singular-near SIDE24 bounds: **open**.
