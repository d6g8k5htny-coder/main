# Palm transfer repair for RP-A and RP-L

## Scope

Let \(f=f_{24}\) be the normalized periodized Bargmann--Fock field on
\(\mathbb T^3_{24}\).  Put

\[
 M=x-\frac r2t,\qquad S=x+\frac r2t,
\]

and condition on

\[
 f(M)=b,\quad f(S)=b-\frac{\kappa r^3}{6},\quad
 \nabla f(M)=\nabla f(S)=0,
\]

where \(t\in S^2\) and \((b,\kappa)\) ranges in a fixed compact subset of
\(\mathbb R\times(0,\infty)\).  Conditional expectation before determinant
weighting is \(\mathbb E^0\).  Define

\[
 W_r=|\det H_M\det H_S|
 \mathbf1_{\{H_M\prec0,\operatorname{ind}(H_S)=2\}},
 \qquad Z_r=\mathbb E^0W_r.
\]

The goal is to prove the two Palm estimates

\[
 \mathbb P^{MS}(A^c)=O(r^3),\qquad
 \mathbb P^{MS}(F_{\rm self})=O(r^3).
\]

This note repairs the gaps in V5 G.1--G.7.  It uses the deterministic
capture/escape theorem already checked in the V3 corrective layer.

## 1. Fourier-distribution nondegeneracy

The periodized field has strictly positive spectral weight at every character
of the side-24 torus.  For a finite family of derivative evaluations, a
linear relation is a finite distribution

\[
 T=\sum_{j,\alpha}c_{j,\alpha}\partial^\alpha\delta_{x_j}.
\]

Its variance is the positive weighted sum of the squared Fourier coefficients
\(\widehat T(k)\).  Zero variance therefore implies
\(\widehat T(k)=0\) for every torus character.  Fourier uniqueness for
distributions gives \(T=0\), and distributions supported at distinct points,
with distinct derivative orders at a common point, are linearly independent.
Thus every genuinely distinct finite derivative family has a positive Gram
matrix.

This is the correct proof.  The V5 argument that an entire function vanishing
on a lattice must vanish identically is false in general.

## 2. Corrected pins and their contact limit

Use the corrected eight-vector

\[
 V_r=\left(
 f(M),\nabla f(M),
 \frac{\nabla f(S)-\nabla f(M)}r,
 \frac{f(S)-f(M)-\frac r2t\cdot(\nabla f(S)+\nabla f(M))}{r^3}
 \right).
\]

It converges in \(L^2\), uniformly in \(t\), to

\[
 V_0=\left(f(x),\nabla f(x),Hf(x)t,-\frac1{12}\partial_t^3f(x)\right).
\]

The components of \(V_0\) are independent derivative distributions, so their
Gram matrix is positive.  Continuity on the compact parameter set gives a
uniform eigenfloor for \(\operatorname{Cov}(V_r)\).  Under the pair target,

\[
 V_r=(b,0,0,-\kappa/6),
\]

so the conditional Gaussian means and covariances of every fixed normalized
jet are uniformly bounded.

## 3. Exact endpoint soft factors and the true limit

For each coordinate direction \(e_i\), set

\[
 h_i(s)=\partial_{ti}f(x+st).
\]

The gradient pins give

\[
 \int_{-r/2}^{r/2}h_i(s)\,ds
 =\partial_i f(S)-\partial_i f(M)=0.
\]

Applying the zero-mean endpoint identity to this \(h_i\), rather than to
\(\partial_i f\), yields

\[
 H_M=\begin{pmatrix}r\alpha_M&r\beta_M^T\\r\beta_M&Q_M\end{pmatrix},
\qquad
 H_S=\begin{pmatrix}r\alpha_S&r\beta_S^T\\r\beta_S&Q_S\end{pmatrix},
\]

and hence

\[
 \det H_p=rD_p,\qquad
 D_p=\alpha_p\det Q_p-r\beta_p^T\operatorname{adj}(Q_p)\beta_p.
\]

The one-dimensional cubic satisfying the two derivative pins and the value
gap has third derivative \(2\kappa\).  Therefore

\[
 \alpha_M\to-\kappa,qquad \alpha_S\to\kappa,qquad
 Q_M,Q_S\to Q,
\]

where, conditional on \(V_0=(b,0,0,-\kappa/6)\), the transverse symmetric
matrix \(Q\) is a nondegenerate Gaussian with full support in
\(\operatorname{Sym}_2\).  The endpoint variables are not jointly centered or
nondegenerate, contrary to the wording of V5 G.3.

Away from the probability-zero boundary \(\det Q=0\), the type indicator
converges to \(\mathbf1_{\{Q\prec0\}}\), and

\[
 \frac{W_r}{r^2}\longrightarrow
 \kappa^2(\det Q)^2\mathbf1_{\{Q\prec0\}}.
\]

Uniform Gaussian polynomial moments give uniform integrability.  Consequently

\[
 \frac{Z_r}{r^2}\longrightarrow
 z_0(t,b,\kappa)
 :=\kappa^2\mathbb E[(\det Q)^2\mathbf1_{\{Q\prec0\}}\mid V_0],
\]

where \(z_0>0\) and is continuous.  Compactness of the mark set gives

\[
 0<c_Zr^2\le Z_r\le C_Zr^2,
 \qquad \mathbb E^0W_r^2\le Cr^4.
\]

## 4. The missing cross-endpoint bridge

On the typed support, \(Q_M\prec0\).  The fundamental theorem of calculus
gives

\[
 Q_S-Q_M=\int_{-r/2}^{r/2}\partial_tQ(x+st)\,ds,
\]

so

\[
 \|Q_S-Q_M\|\le rJ_3,
\]

where \(J_3\) is a polynomially controlled normalized third-jet variable.
Let \(\lambda_M=\lambda_{\min}(-Q_M)>0\).  If \(Q_S\prec0\), Weyl's
inequality gives

\[
 \lambda_{\min}(-Q_S)\le\lambda_M+rJ_3.
\]

Conversely, one may start from \(Q_S\) on the subevent where it is negative;
the same estimate bridges back to \(Q_M\).  If \(Q_S\) is not negative while
\(Q_M\prec0\), Weyl already forces \(\lambda_M\le rJ_3\), so that case belongs
to the same shallow layer.

For a negative \(2\times2\) matrix \(Q\),

\[
 |\det Q|\le\lambda_{\min}(-Q)\|Q\|,
 \qquad \|\operatorname{adj}Q\|=\|Q\|.
\]

Applying these inequalities at both endpoints and using the bridge gives,
for fixed \(N\) and a nonnegative polynomial \(P\),

\[
 W_r\le Cr^2[\lambda_M+rP(U_r)]^2(1+\|U_r\|)^N.
\]

This is the step printed incorrectly in V5 G.4.1, where the eigenvalue of
\(Q_S\) was applied directly to \(D_M\).

## 5. Polynomial-threshold Gaussian tube lemma

**Lemma.**  Let \(U_r\) be a uniformly nondegenerate finite conditional
Gaussian vector containing \(Q_M\), and let \(\mathcal H_r\) be a conditioned
Gaussian derivative supremum with a uniform Borell tail.  For every fixed
nonnegative polynomial \(P\) and every polynomial weight \(G\),

\[
 \mathbb E^0\left[
 G(U_r,\mathcal H_r)
 \mathbf1_{\{0<\lambda_M\le rP(U_r,\mathcal H_r)\}}
 \right]\le C_G r.
\]

**Proof.**  On a ball of radius \(R\), the positive-semidefinite shell
\(0<\lambda_{\min}(-Q)\le\varepsilon\) lies in an
\(\varepsilon\)-tube around the rectifiable cone boundary
\(\det Q=0\), whose volume is at most
\(C\varepsilon(1+R)^d\).  The conditional Gaussian density is uniformly
bounded on compact marks.  Decompose the finite jet and derivative supremum
into dyadic shells.  On shell \(j\), the random threshold and polynomial
weight contribute at most fixed powers of \(2^j\), while Gaussian and Borell
tails contribute \(e^{-c2^{2j}}\) after a harmless reindexing.  The shell
sum is therefore

\[
 Cr\sum_{j\ge0}2^{mj}e^{-c2^{2j}}\le C'r.
\]

The same proof covers any fixed polynomial threshold, including the
\(R^5\) threshold required by capture/escape.  This is stronger than V5
G.4.2's single displayed \(P_0\).

Combining the lemma with the weighted expansion yields

\[
 \mathbb E^0\!\left[
 W_r\mathbf1_{\{0<\lambda_M\le rP\}}
 \right]\le Cr^5,
\]

and division by \(Z_r\ge c_Zr^2\) gives an \(O(r^3)\) Palm probability.

## 6. High-jet and exact-field failures

Let \(X\) be one plus the controlling finite-jet and derivative-supremum
norm.  Gaussian regression and Borell give
\(\mathbb P^0(X>u)\le Ce^{-cu^2}\).  Allow the normal-form envelope and the
interpolation constant to have their actual fixed polynomial dependence

\[
 R\le C(1+X)^{d_R},\qquad C_+\le C(1+X)^{d_C}.
\]

Choose

\[
 0<\alpha<\min\{(5d_R)^{-1},(d_C+3d_R)^{-1}\}.
\]

On \(X\le r^{-\alpha}\), both \(rR^5\le\varepsilon_0\) and the
pin-preserving approximation inequality
\(C_+r\le(8192R^3)^{-1}\) hold for all sufficiently small \(r\).  The
complement has probability at most
\(C\exp(-cr^{-2\alpha})\).  This contains as a special case the simpler
linear-envelope estimate \(\exp(-cr^{-2/5})\), but does not assume linear
dependence where the Taylor construction produces a polynomial.

Cauchy--Schwarz and the
second-moment/normalizer bounds give

\[
 \mathbb P^{MS}(F)
 \le \frac{(\mathbb E^0W_r^2)^{1/2}
 (\mathbb P^0(F))^{1/2}}{Z_r}
 \le C(\mathbb P^0(F))^{1/2}=o(r^3).
\]

The V5 choice \(u=r^{-1}\) did not directly control the smaller thresholds
created by \(R^5\) and \(R^{-3}\); the displayed choice of \(\alpha\) does.

## 7. RP-A and RP-L

On the complement of the shallow and high-jet failures, the deterministic
capture/escape theorem applies.  The inward upper half-branch reaches \(M\),
so adjacency failure \(A^c\) is impossible.

The outward upper half-branch reaches a point in its \(\{f>h\}\) component
whose value exceeds \(b=f(M)\).  If the two upper sectors were the same
component while \(M\) were its representative (the event
\(F_{\rm self}\)), that component would contain a point higher than its
purported representative, a contradiction.  Thus \(F_{\rm self}\) is also
impossible on the deterministic good event.

The shallow layer has Palm mass \(O(r^3)\), and all remaining failures have
mass \(o(r^3)\).  Therefore, uniformly on compact positive mark sets,

\[
 \boxed{
 \mathbb P^{MS}(A^c)\le C_Ar^3,
 \qquad
 \mathbb P^{MS}(F_{\rm self})\le C_Lr^3.}
\]

This closes RP-A and RP-L with the repairs above.  It does not close RP-C or
RP-S.
