# Superseded \(ee\)-curvature interpolation route

**Audit status:** retained as a strict \(c\sigma\ne0\) derivation only; it is
not the controlling all-face proof.  The endpoint remainder assertion
(I.20) fails on the perpendicular \(c=0\) face because this interpolant
misses the \((X^2-a^2)Y\) mode.  The exact regression is recorded in
quartic_remainder_audit_note.md.  The controlling replacement is
three_hessian_conditional_moment_envelope.md, which uses the endpoint
mixed-curvature difference on every noncollinear chart and a
density-weighted ESIP bound on the genuinely collinear face.

This note remains useful for the strict \(c\sigma\ne0\) algebra.  On that
restricted chart its point is that type is imposed on the exact field
Hessian, not silently transferred to an unrelated cubic.

## 1. Exact value-preserving cubic

In the plane \(\Pi\) through the pair and witness, put

\[
 M=(-r/2,0),\qquad S=(r/2,0),\qquad
 y=s(c,\sigma),\qquad c^2+\sigma^2=1,\qquad\eta=r/s<1.     \tag{I.1}
\]

On a strict \(c\sigma\ne0\) chart, let \(Q\in\mathcal P_3(\mathbb R^2)\)
be the unique cubic satisfying

\[
 Q(p)=f(p),\qquad \nabla_\Pi Q(p)=0,\qquad p=M,S,y,         \tag{I.2}
\]

and

\[
 D_{ee}^2Q(M)-D_{ee}^2Q(S)
 =D_{ee}^2f(M)-D_{ee}^2f(S).                              \tag{I.3}
\]

These are ten linear conditions.  They preserve the exact witness value, so
if

\[
 f(y)=b-\alpha\kappa r^3/6,\qquad0\le\alpha\le1,           \tag{I.4}
\]

the value-pinned cubic elimination uses the actual \(\alpha\), not a Taylor
surrogate.  There is a free-coordinate \(u\), linear in the curvature
difference, for which

\[
\begin{aligned}
-\det H_{Q,M}^{\Pi}&=L(u^2-\alpha),\\
-\det H_{Q,S}^{\Pi}&=L((u-1)^2-(1-\alpha)),\\
 \det H_{Q,y}^{\Pi}&=-L((u-\alpha)^2+\alpha(1-\alpha)),
                                                               \tag{I.5}
\end{aligned}
\]

where

\[
                         L=\frac{\kappa^2r^4}{\sigma^2s^2}. \tag{I.6}
\]

The regular \(c=0\) chart uses the exact perpendicular \(\mu\)-formulas and
a different tenth divided difference; no division by \(c\) is made there.

## 2. Uniform confluent interpolation as \(\eta\to0\)

Scale physical coordinates by \(s\), so the nodes are
\((-a,0),(a,0),(c,\sigma)\), with \(a=\eta/2\).  Replace the coalescing raw
endpoint rows by

\[
\begin{aligned}
L_0&=[F(a,0)+F(-a,0)]/2,\\
L_1&=[F(a,0)-F(-a,0)]/(2a),\\
L_2&=[F_X(a,0)-F_X(-a,0)]/(2a),\\
L_3&=\frac3{a^2}\{[F_X(a,0)+F_X(-a,0)]/2-L_1\},\\
L_4&=[F_Y(a,0)+F_Y(-a,0)]/2,\\
L_5&=[F_Y(a,0)-F_Y(-a,0)]/(2a),\\
L_6&=[F_{YY}(a,0)-F_{YY}(-a,0)]/(2a).                     \tag{I.7}
\end{aligned}
\]

Together with \(F,F_X,F_Y\) at \((c,\sigma)\), these are ten rows.  Their
limits are

\[
 F,F_X,F_{XX},F_{XXX},F_Y,F_{XY},F_{XYY}\quad\hbox{at }0,
                                                               \tag{I.8}
\]

and \(F,F_X,F_Y\) at \((c,\sigma)\).

A cubic annihilated by the first seven rows has the form

\[
                    P(X,Y)=A X^2Y+B Y^2+C Y^3.             \tag{I.9}
\]

The three witness rows give

\[
 2Ac\sigma=0,\qquad
 \sigma^2(B+C\sigma)=0,\qquad
 2B\sigma+3C\sigma^2=0.                                  \tag{I.10}
\]

Thus \(A=B=C=0\) when \(c\sigma\ne0\).  Equivalently, the residual
three-by-three interpolation matrix has determinant \(2c\sigma^5\).
Consequently the normalized interpolation matrix and its inverse extend
continuously through \(\eta=0\), with no negative power of \(\eta\):

\[
 \|I_\eta\|+\|I_\eta^{-1}\|\le C\theta^{-N}
 \quad\hbox{on }|c\sigma|\ge\theta.                        \tag{I.11}
\]

Near \(c=0\), use the normalized \(X^2Y\) divided difference as the tenth
condition.  The remaining monomials are \(Y^2,XY^2,Y^3\); the witness matrix
at \((0,\sigma)\) has determinant \(\sigma^6\).  This supplies a regular
perpendicular chart.  The face \(\sigma=0\) is instead handled by the
collinear ESIP chart.

## 3. Explicit fourth-order remainder

Set \(g=f-Q\).  Then

\[
 g=\nabla_\Pi g=0\quad\hbox{at }M,S,y,\qquad
 g_{ee}(M)=g_{ee}(S).                                     \tag{I.12}
\]

The leading quartic interpolation error has the exact pair-pinned form

\[
\begin{aligned}
G(X,Y)={}&A h^2+Yh(BX+C_1)+Y^2(DX^2+E_0)\\
         &+Y^3(FX+G_0)+HY^4,\qquad
h=X^2-\eta^2/4.                                           \tag{I.13}
\end{aligned}
\]

At \(\eta=0\), the witness value-gradient equations give

\[
\begin{aligned}
C_1={}&-\left(2Ac^2/\sigma+\tfrac32Bc+D\sigma
                    +F\sigma^2/(2c)\right),\\
E_0={}&Ac^4/\sigma^2+Bc^3/\sigma+Dc^2+Fc\sigma+H\sigma^2,\\
G_0={}&-\left(Bc^3/(2\sigma^2)+Dc^2/\sigma
                    +\tfrac32Fc+2H\sigma\right).           \tag{I.14}
\end{aligned}
\]

The finite-\(\eta\) expressions add only polynomials in \(\eta,\eta^2\)
over the same \(c\sigma\) or \(c\sigma^2\) denominators.  Hence no
\(\eta^{-1}\) is hidden in the remainder.  The five free quartic symbols

\[
                  T^4,\quad T^3E,\quad T^2E^2,\quad TE^3,\quad E^4
                                                               \tag{I.15}
\]

are independent modulo the degree-at-most-three pin symbols.  Strict
side-24 spectral positivity therefore gives bounded conditional polynomial
moments for their residualized versions on strict angular charts.

Because interpolation reproduces every cubic, the divided-difference Peano
remainder and (I.11) give

\[
 \|D^2g\|\le Cs^2J\theta^{-N},\qquad
 \|D^3g\|\le CsJ\theta^{-N}.                               \tag{I.16}
\]

The pair zeros improve the endpoint entries:

\[
 g(X,0)=(X+r/2)^2(X-r/2)^2A_g(X),\qquad
 g_e(X,0)=(X+r/2)(X-r/2)B_g(X).                            \tag{I.17}
\]

It follows exactly that

\[
\Delta_{M,S}:=H_f^\Pi-H_Q^\Pi
=
\begin{pmatrix}
r^2A_{M,S}&rsB_{M,S}\\
rsB_{M,S}&s^2C
\end{pmatrix},
\qquad
\Delta_y=s^2A_y,                                          \tag{I.18}
\]

where all coefficients have bounded polynomial moments up to the displayed
fixed angular power.  The same \(C\) occurs at \(M,S\) because (I.3) was
matched exactly.

## 4. The \(r\)-versus-\(s^2\) crossover and legitimate type use

Write

\[
 H_Q^\Pi(M)=\begin{pmatrix}a&b\\b&q\end{pmatrix}.
\]

The exact pair pins give \(a=O(rP(J))\), \(b=O(rP(J))\), and
\(q=O(P(J))\).  From (I.18),

\[
\begin{aligned}
\det(H_Q+\Delta)-\det H_Q
={}&qr^2A+as^2C-2brsB+r^2s^2(AC-B^2).                    \tag{I.19}
\end{aligned}
\]

Thus

\[
 |\det H_f^\Pi(M)-\det H_Q^\Pi(M)|
 +|\det H_f^\Pi(S)-\det H_Q^\Pi(S)|
 \le Cr(r+s^2)P(J)\theta^{-N}.                            \tag{I.20}
\]

The two crossover charts are explicit.  If \(r\ge s^2\), put
\(\lambda=s^2/r\) and divide (I.19) by \(r^2\).  If \(r\le s^2\), put
\(\mu=r/s^2\) and divide it by \(rs^2\).  Every coefficient extends
continuously to \(\lambda=0\) or \(\mu=0\); the surviving quartic symbols are
respectively the \(T^4\) coefficient in \(A\) and the \(E^2\) coefficient in
\(C\).  This is the required edge-square crossover, not a thin-triangle
condition-number assertion.

For the cubic \(Q\), exact Taylor identities at \(y\) give

\[
 \|H_Q^\Pi(y)\|\le CsP(J)\theta^{-N}.                      \tag{I.21}
\]

Together with \(\Delta_y=s^2A_y\) and

\[
 \det(A+E)-\det A
 =\operatorname{tr}(\operatorname{adj}(A)E)+\det E,        \tag{I.22}
\]

this yields

\[
 |\det H_f^\Pi(y)-\det H_Q^\Pi(y)|
 \le Cs^3P(J)\theta^{-N}.                                 \tag{I.23}
\]

Now use the type only on the exact field.  Since \(H_f(M)\prec0\), its plane
determinant is positive.  Equations (I.5) and (I.20) give

\[
 L(u^2-\alpha)=-\det H_{Q,M}^\Pi
 \le Cr(r+s^2)P(J)\theta^{-N},
\]

and hence

\[
 Lu^2\le L+Cr(r+s^2)P(J)\theta^{-N}.                       \tag{I.24}
\]

Because \(L\lesssim r^2\) and

\[
                 r(r+s^2)\le r^2+s^3\qquad(r\le s),       \tag{I.25}
\]

(I.5), (I.20), (I.23), and (I.24) prove

\[
\begin{aligned}
|\det H_f^\Pi(M)|+|\det H_f^\Pi(S)|
 &\le Cr(r+s^2)P(J)\theta^{-N},\\
|\det H_f^\Pi(y)|
 &\le C(r^2+s^3)P(J)\theta^{-N}.                          \tag{I.26}
\end{aligned}
\]

## 5. Hard complement

Let \(e_h\perp\Pi\) and write

\[
 H_p=\begin{pmatrix}A_p&b_p\\b_p^T&c_p\end{pmatrix}.
\]

The scalar function \(D_{e_h}f|_\Pi\) vanishes at all three points.  Exact
Newton divided differences give, at an endpoint,
\(b_t=O(r)P(J)\) and \(b_e=O(s)P(J)\).  Moreover

\[
 \operatorname{adj}(A_p)=
 \begin{pmatrix}O(r+s^2)&O(r)\\O(r)&O(r)\end{pmatrix}
 P(J)\theta^{-N}.                                         \tag{I.27}
\]

Therefore

\[
 b_p^T\operatorname{adj}(A_p)b_p
 =O(r^2(r+s^2)+r^2s+rs^2)P(J)\theta^{-N}
 =O(r(r+s^2))P(J)\theta^{-N}.                             \tag{I.28}
\]

At \(y\), every plane and hard-mixed column is \(O(s)P(J)\theta^{-N}\), so
the Schur correction is \(O(s^3)P(J)\theta^{-N}\).  Combining
(I.26)--(I.28) with

\[
 \det H_p=c_p\det A_p-b_p^T\operatorname{adj}(A_p)b_p
\]

proves

\[
\begin{aligned}
|\det H_M|,|\det H_S|&\le Cr(r+s^2)P(J)\theta^{-N},\\
|\det H_y|&\le C(r^2+s^3)P(J)\theta^{-N}.                  \tag{I.29}
\end{aligned}
\]

Thus the common conditional-moment monomial is

\[
                    [r(r+s^2)]^2(r^2+s^3).                \tag{I.30}
\]

The interpolation chart genuinely loses rank at \(c=0\) and \(\sigma=0\).
The perpendicular and collinear charts are therefore required; no uniform
constant from the generic chart is extended across either face.
