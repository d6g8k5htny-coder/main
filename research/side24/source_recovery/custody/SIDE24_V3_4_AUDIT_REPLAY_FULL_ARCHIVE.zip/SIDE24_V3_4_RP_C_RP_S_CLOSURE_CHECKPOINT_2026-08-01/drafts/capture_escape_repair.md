# V3 capture/escape repair

**Status.** The deterministic statement below is closed under its displayed
normal-form and pin-preserving approximation hypotheses.  It does not, by
itself, prove the determinant-weighted Palm probability estimate.  That
probabilistic transfer is isolated at the end as a residual premise.

## Corrected deterministic proposition

Let

\[
P(X,Y)=p_0(X)+\frac12\left(X^2-\frac14\right)a\cdot Y
-\frac12Y^\top TY+\frac12X\,Y^\top WY+\frac16C[Y,Y,Y]+rQ(X,Y),
\]

where \(p_0(X)=X^3/3-X/4-1/12\), \(Y\in\mathbb R^2\), and
\(T\succeq\tau I\).  At

\[
M=(-1/2,0),\qquad S=(1/2,0),
\]

assume

\[
Q(M)=Q(S)=0,\qquad \nabla Q(M)=\nabla Q(S)=0.
\]

Set

\[
R=1+|a|+\|W\|+\|C\|+\|Q\|_{C^2}\ge1,\quad
K=4096,\quad \varepsilon_0=\frac1{1024K},
\]

and suppose

\[
rR^5\le\varepsilon_0,\qquad \tau\ge2KR^5+2R.
\]

Write \(m=2R/\tau\) and \(\delta=1/(512R^3)\).  In the axial/transverse
splitting, write the endpoint Jacobian explicitly as

\[
D^2P(S)=
\begin{pmatrix}
A&B^\top\\
B&-T+E_D
\end{pmatrix}.
\]

Assume the block bounds

\[
A\ge\frac34,\qquad |B|\le R,\qquad \|E_D\|\le\frac{3R}{4},
\]

and assume that \(D^2P(S)\) has exactly one positive eigenvalue.  For the
gradient-ascent field \(F=\nabla P\):

1. The outward unstable half-branch enters

   \[
   \mathcal C_E=\left\{0\le\xi=X-\frac12\le\delta,
   \quad E(Y):=Y^\top TY\le\frac{4R^2}{\tau}\xi^2\right\},
   \]

   remains there to \(\xi=\delta\), then remains in

   \[
   \mathcal S_E=\left\{\frac12+\delta\le X\le\frac54,
   \quad E(Y)\le\frac9{16}\frac{R^2}{\tau}\right\},
   \]

   and reaches \(X=5/4\) at a potential strictly above \(P(M)\).

2. The inward half-branch enters

   \[
   \mathcal T_{\rm in}=\left\{-\frac12<X<\frac12,
   \quad |Y|\le m\left(\frac14-X^2\right)\right\},
   \]

   remains in that tube, and converges to \(M\).

3. No upper bound on \(\lambda_{\max}(T)\) is used.

## Proof repairs

The positive endpoint eigenvector \(v=(v_X,v_Y)\) satisfies

\[
E(v_Y)\le\frac83\frac{R^2}{\tau}|v_X|^2,
\qquad
\frac{|v_Y|}{|v_X|}<\frac{2R}{\tau}=m.
\]

The inequalities are strict, so the local unstable-manifold theorem gives
entry of the two oriented half-branches into the regions above; tangent-line
information alone is not being used as a global conclusion.

### Outward endpoint and strip

On \(\mathcal C_E\),

\[
|Y|\le m\xi\le\frac{\xi}{KR^4}.
\]

The endpoint pins are load-bearing.  They give

\[
|\nabla Q(X,Y)|\le R(\xi+|Y|)\le R(1+m)\xi,
\]

and hence \(r|Q_X|\le rR(1+m)\xi\).  This replaces the invalid V2
comparison of an absolute \(rR\) error with \(\xi\) as \(\xi\downarrow0\).
Direct substitution gives

\[
F_X\ge\left[1-\left(\frac12+\delta\right)Rm
-\frac12Rm^2\delta-rR(1+m)\right]\xi\ge\frac34\xi.
\]

Let \(q=|TY|\) and
\(G_E=E(Y)-4(R^2/\tau)\xi^2\).  On \(G_E=0\), \(q\ge2R\xi\), and the four
adverse ratios in \((TY)\cdot F_Y\) are bounded by

\[
\frac{257}{1024}+\frac{257}{1024K}
+\frac1{2048K^2}+\varepsilon_0<\frac13.
\]

The moving-boundary contribution is nonpositive, so

\[
\frac12\dot G_E\le-\frac23q^2<0.
\]

On the outer strip, direct estimates give

\[
F_X\ge\frac34\delta,
\qquad
\frac12\dot E\le-\frac1{10}q^2
\quad\text{when }E=\frac9{16}\frac{R^2}{\tau}.
\]

The energy term is bounded without using \(\lambda_{\max}(T)\), and the
terminal-level ledger remains

\[
P(5/4,Y)>\frac{49}{192}-\frac1{768}
=\frac{65}{256}>P(M)=0.
\]

### Inward tube

Put \(h(X)=1/4-X^2\).  For \((X,Y)\in\mathcal T_{\rm in}\), its distance to
the nearer endpoint is at most \(2h(X)+|Y|\).  Pin preservation therefore
gives at every point with \(h(X)>0\),

\[
|\nabla Q(X,Y)|\le R(2+m)h(X)\le3Rh(X).
\]

Consequently

\[
F_X\le-\left[1-\frac{Rm}{2}-\frac{Rm^2}{8}-3rR\right]h
\le-\frac34h<0.
\]

For \(G_{\rm in}=|Y|^2-m^2h(X)^2\),

\[
\frac12\dot G_{\rm in}=Y\cdot F_Y+2m^2XhF_X.
\]

On \(|Y|=mh\), the leading term obeys

\[
-Y^\top TY\le-\tau m^2h^2=-4\frac{R^2}{\tau}h^2.
\]

All adverse terms, including the moving boundary for \(X<0\), are at most

\[
\left(1+\frac1K+\frac1{4K^2}+6\varepsilon_0+\frac4K\right)
\frac{R^2}{\tau}h^2
<2\frac{R^2}{\tau}h^2.
\]

Thus \(\dot G_{\rm in}/2\le-2(R^2/\tau)h^2<0\), and the inward branch remains
in the tube until convergence to \(M\).  Since \(X\) decreases strictly, a limiting
value greater than \(-1/2\) would leave \(h\) bounded away from zero and
contradict the longitudinal bound.  Hence

\[
X(t)\to-\frac12,\qquad |Y(t)|\le mh(X(t))\to0.
\]

This removes the V2 auxiliary threshold and invariant-ball argument.  In
particular, its claim
\(h(-1/2+\delta_0)\ge\delta_0\) is false because the left side is
\(\delta_0-\delta_0^2\).

## Pin-preserving exact-field robustness under explicit endpoint hypotheses

For \(\widetilde F=F+\mathcal E=\nabla\widetilde P\), require

\[
\mathcal E(M)=\mathcal E(S)=0,\qquad
\|D\mathcal E\|_\infty\le\eta_R:=\frac1{8192R^3},
\qquad \widetilde P(M)=P(M).
\]

Assume also that \(D^2\widetilde P(S)\) has exactly one positive eigenvalue
and that its axial/transverse blocks satisfy
\[
\widetilde A\ge\frac34-\eta_R,\qquad
|\widetilde B|\le R+\eta_R,\qquad
\|\widetilde E_D\|\le\frac{3R}{4}+\eta_R.
\]
Repeating the endpoint block estimate with these perturbed constants places
the two orientations of the exact unstable eigendirection strictly inside the
cone and tube for the stated \(\eta_R\).  Thus entry is an explicit
hypothesis-and-estimate
step, not an inference from boundary flux alone.

The endpoint equalities turn the absolute error into a distance-weighted
one.  They imply \(|\mathcal E|\le2\eta_R\xi\) on the cone and
\(|\mathcal E|\le3\eta_Rh\) in the inward tube.  The corresponding cone,
strip, and tube flux costs are respectively bounded by

\[
\frac{3\eta_R}{R}q^2,\qquad
\frac{4\eta_R}{3R}q^2,\qquad
12\frac{\eta_R}{R}\frac{R^2}{\tau}h^2,
\]

all below the strict margins above.  Since \(\eta_R=\delta/16\), the strip's
longitudinal margin also persists.  If the fixed comparison chart supplies a
path from \(M\) to the terminal section of length at most \(3\), then
\(\|\nabla(\widetilde P-P)\|_\infty\le\eta_R\) makes the path-integrated
potential error at most \(3\eta_R\), already covered by the terminal-level
reserve.  A bare
absolute \(C^1\) error without endpoint pin preservation is insufficient.

## Residual Palm-transfer premise

To infer

\[
\mathbb P^{MS}_{r,t,b,\kappa}(\mathcal D_r^c)=O(r^3)
\]

uniformly on compact positive mark sets, a complete proof must establish all
of the following in one finite-\(r\), side-24 coordinate system:

1. \(cr^2\le Z_r=\mathbb E^0W_r\le Cr^2\) and
   \(\mathbb E^0W_r^2\le Cr^4\).
2. Exact endpoint soft-mode factorizations
   \(\det H_M=rD_M\), \(\det H_S=rD_S\), with uniform polynomial moments.
3. A weighted shallow-eigenvalue expansion

   \[
   W_r\le Cr^2[\lambda_*+rP(U_r)]^2(1+\|U_r\|)^N
   \]

   and a uniform eigenvalue/coarea density giving

   \[
   \mathbb E^0\!\left[W_r
   \mathbf1_{\{0<\lambda_*\le rP_0(U_r)\}}\right]\le Cr^5.
   \]

   The essential cubic integral is
   \(r^2\int_0^{rP_0(u)}[s+rP(u)]^2ds=O(r^5)\).
4. Uniform sub-Gaussian finite-jet and fifth-derivative tails, together with
   explicit polynomial dependence of the normal-form size and exact-field
   approximation constant on that envelope.
5. The exact scaling identification
   \(\tau_r=\lambda_*/(\kappa r)\), reducing coercivity failure to the shallow
   layer in item 3.

The baseline sketches these ingredients but does not yet present their
uniform combination at independent-proof standard.  Accordingly the
deterministic result is retained with the repairs above, while the Palm
\(O(r^3)\) estimate remains a named residual probabilistic premise.

The exact rational margins are checked by
`scripts/verify_capture_escape_budgets.py`; that script intentionally makes
no claim about the normal-form reduction or Palm transfer.
