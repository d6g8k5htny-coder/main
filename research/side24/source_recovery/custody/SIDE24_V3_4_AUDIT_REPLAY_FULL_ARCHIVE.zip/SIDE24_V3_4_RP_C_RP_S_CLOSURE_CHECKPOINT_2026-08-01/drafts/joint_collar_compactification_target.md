# Correct target for the collar and singular-near compactifications

**Superseded planning note.**  This file records the work order inherited
by V3.4; it is not the controlling proof or current status source.  The
explicit axial-interior and midpoint frames are now in
`rp_c_rp_s_facewise_closure.md`, and the singular chart now uses the
pair-pin-measurable four-row frame there.  Item 6 below was also sharpened:
the same pointwise density-weighted monomial is false on the axial endpoint
divisor, where the controlling proof retains the collision radius through
the physical radial measure.  See
`three_hessian_conditional_moment_envelope.md`, (H.27).

## 1. Why the V5 radial floor is not the right object

The V5 numerical collar script fixes the pair separation at \(r=0.4\) and
sends the witness distance to zero.  RP-C requires a joint limit in which the
pair and witness collide together.  Those limits do not commute at the
degenerate angular faces.

The exact local contact calculation already gives, in coordinates
\((X,Y,Z)\) with \(\varrho^2=Y^2+Z^2\),

\[
 \det C_{\rm col}
 =\varrho^6(4X^2+\varrho^2).
\]

This formula has three immediate consequences:

1. Under \((X,Y,Z)=r(x,y,z)\), the determinant is generically \(r^8\).
2. It vanishes on the pair axis \(Y=Z=0\).
3. No normalization by the sixth power of total radial distance can have a
   positive uniform limit over the angular compactification.

Thus the sentence in V5 G.9 asserting \(\det C=\rho^6A\) with positive
\(A\) at every compactified direction is false at the joint corner.  The
failure is exact, not a numerical-resolution issue.

## 2. Axial Hermite face

Put the two pair points at axial coordinates \(0\) and \(r\), and let an
axial witness be at \(q\in(0,r)\).  After conditioning on the two values and
the two axial derivatives, cubic Hermite interpolation removes all terms
through degree three.  The leading residual of the axial gradient is

\[
 \partial_t f(q)_{\rm res}
 =\frac{q(q-r)(2q-r)}{12}\,\partial_t^4f(0)_{\rm res}
 +O(r^4).
\]

For either transverse gradient component, the endpoint gradient pins give
the two-point interpolation residual

\[
 \partial_v f(q)_{\rm res}
 =\frac{q(q-r)}2\,\partial_{ttv}f(0)_{\rm res}+O(r^3),
\]

and similarly for \(w\).  Fourier-distribution independence makes the
limiting residual covariance positive.  Away from the midpoint face,

\[
 \det\operatorname{Cov}(\nabla f(q)\mid\text{pair pins})
 \asymp [q(r-q)]^6(r-2q)^2.
\]

Hence:

- if \(q=o(r)\), the determinant is \(\asymp q^6r^8\);
- if \(q/r\to\theta\notin\{0,1,1/2\}\), it is \(\asymp r^{14}\);
- at \(q=r/2\), the leading axial functional cancels and a secondary
  midpoint blow-up is mandatory.

This explains why the fixed-\(r\) probe sees a sixth power in \(q\), while
its normalized coefficient collapses like \(r^8\) at the joint corner.

## 3. Singular-near anisotropy

The exact local singular-near calculation is

\[
 \det C_{\rm sing}
 =\frac{\varrho^{10}(c^2+\varrho^2)(3c^2+\varrho^2)}{24}.
\]

The factors \(c^2+\varrho^2\) and \(3c^2+\varrho^2\) are structural.  They
must remain in the finite-(r) comparison and in the angular integral; they
cannot be replaced by a direction-independent covariance floor.

## 4. Facewise acceptance lemma still required

RP-C and RP-S will close only after a finite collection of explicit charts
proves all of the following for the exact periodized side-24 covariance:

1. **Generic transverse face:** comparison to
   \(\varrho^6(4X^2+\varrho^2)\), with uniform Schur-complement constants.
2. **Axial face:** comparison to
   \([q(r-q)]^6(r-2q)^2\) away from the midpoint.
3. **Midpoint face:** one further divided difference after \(r-2q=0\), or a
   quantified target-mean mismatch giving an integrable exponential penalty.
4. **Endpoint faces:** compatible charts as \(q/r\to0\) and \(q/r\to1\).
5. **Singular-near faces:** preservation of the two anisotropic factors and
   the existing collinear mean-mismatch penalty.
6. **Hessian moments:** the three-determinant conditional moment bound with
   the same monomial weights on every face.
7. **Integration:** the resulting density-weight products integrate to
   \(O(r^3)\), including the angular axis.

Pointwise positivity on a generic face is insufficient.  Continuity and
compactness can be invoked only after the correct face-dependent
normalizations have been installed and their limiting residual families have
been proved independent.
