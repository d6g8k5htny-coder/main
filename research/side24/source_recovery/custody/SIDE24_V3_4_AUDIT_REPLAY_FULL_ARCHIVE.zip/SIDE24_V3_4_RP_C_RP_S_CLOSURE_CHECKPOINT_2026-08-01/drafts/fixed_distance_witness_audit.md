# SIDE24 RP-F: independent fixed-distance witness proof

**Status (2026-07-31): PROVED for the fixed side-24 field, uniformly on
compact positive mark sets.**  This note independently audits and restates
baseline Lemma 3.4c.  It does not prove the all-mark Gaussian envelope and it
does not address RP-A/RP-L, RP-C, or RP-S.

## 1. Statement

Let

```text
M=x-(r/2)t,  S=x+(r/2)t,  h=b-kappa*r^3/6,
```

and condition the normalized periodized Bargmann--Fock field on the corrected
maximum--saddle pair pins at `M,S`.  Let

```text
W_r=|det H_M det H_S| 1{M maximum}1{S index two},
Z_r=E[W_r | pair pins],
```

and let `N_fixed` count all critical points `y`, without a type restriction,
such that

```text
dist(y,{M,S}) >= delta,  h < f(y) < b.
```

For every `delta>0` and compact

```text
K subset S^2 x R x (0,infinity)
```

there are `r_0,C>0` such that, uniformly for `(t,b,kappa) in K` and
`x in T_24^3` and `0<r<r_0`,

```text
E_r^{MS} N_fixed <= C r^3.                         (F.1)
```

Here `E_r^{MS}[F]=E[W_r F | pair pins]/Z_r`.

## 2. Uniform remote density block

Let `P_r^corr` be the corrected divided-difference pair-pin vector and put

```text
R_y=(f(y),grad f(y)).
```

The periodized side-24 covariance has strictly positive Fourier coefficient
at every lattice frequency.  Therefore its covariance quadratic form is
faithful on distributions: a finite linear combination of derivative
evaluations has zero variance only if that distribution is zero.

At `r=0`, the corrected pair coordinates are derivative distributions
supported at the midpoint `x`.  Their independence is the already verified
positive contact covariance.  For
`dist(y,{M,S})>=delta` and `r<delta/2`, the value-gradient distributions in
`R_y` are supported at a point separated from `x` by at least `delta/2`.
Distributions supported at the two distinct points cannot cancel each other;
at either point, distinct derivatives of the delta distribution are linearly
independent.  Hence

```text
(P_0^corr,R_y)
```

is linearly independent on every contact face.

Covariance depends continuously on `r,t,x,y`.  The torus, a finite frame
atlas for `t`, the compact mark set, and the separated `y` region are compact.
Consequently there are constants `0<c_delta<C_delta<infinity` such that the
covariance of `(P_r^corr,R_y)` has all eigenvalues in this interval for small
`r`.  Its Schur complement gives the same uniform bounds for the conditional
covariance of `R_y` given the pair pins.

The conditional mean is an affine function of the corrected pair target with
uniformly bounded coefficients.  On `K` it is bounded.  Thus, for
`u in [h,b]`,

```text
p_{R_y | P_r^corr}(u,0) <= C_(delta,K).             (F.2)
```

No global Gaussian penalty in `(b,kappa)` is needed for (F.1).

## 3. Exact endpoint factors under the enlarged conditioning

For a fixed frame vector `e_i`, define

```text
g_i(s)=partial_{e_i} f(x+s t).
```

The gradient pins give `g_i(-r/2)=g_i(r/2)=0`.  Taylor's integral identity
therefore yields exactly

```text
partial_{t e_i}f(M)
 =-(1/r) integral_(-r/2)^(r/2) (r/2-s)
        partial_{tt e_i}f(x+s t) ds,

partial_{t e_i}f(S)
 =(1/r) integral_(-r/2)^(r/2) (s+r/2)
        partial_{tt e_i}f(x+s t) ds.                (F.3)
```

Each expression is `r` times a normalized segment average whose Gaussian
moments are uniformly bounded.  In the `t` plus transverse decomposition,

```text
H_p = [[r a_p, r b_p^T],
       [r b_p,     Q_p]],   p in {M,S}.               (F.4)
```

Expanding along the first row gives

```text
det H_M=r D_M,  det H_S=r D_S,                        (F.5)
```

where `D_M,D_S` are degree-three polynomials in the normalized segment
averages and hard transverse entries.

Now condition additionally on `R_y=(u,0)`.  The enlarged pin covariance has
the uniform eigenfloor from Section 2.  Gaussian regression gives uniformly
bounded conditional means and covariance operator norms for all normalized
endpoint variables and for `H_y`.  Degeneracy of the remaining Hessian block
would not matter for an upper moment bound.  Since the three determinants
have total polynomial degree nine, (F.5) and Gaussian moment bounds imply

```text
E[W_r |det H_y| | pair pins,R_y=(u,0)] <= C_(delta,K) r^2.
                                                               (F.6)
```

The endpoint type indicators only decrease the absolute value.

## 4. Conditional Kac--Rice calculation

Conditional Kac--Rice, applied to the unrestricted remote critical-point
count, gives

```text
E[W_r N_fixed | pair pins]
 = integral_{dist(y,{M,S})>=delta} integral_h^b
     p_{R_y | P_r^corr}(u,0)
     E[W_r |det H_y| | pair pins,R_y=(u,0)] du dy.     (F.7)
```

The torus has finite volume, (F.2) is bounded, (F.6) contributes `r^2`, and

```text
b-h=kappa*r^3/6 <= C_K r^3.                            (F.8)
```

Therefore

```text
E[W_r N_fixed | pair pins] <= C_(delta,K) r^5.         (F.9)
```

The independently verified contact normalizer satisfies

```text
c_K r^2 <= Z_r <= C_K r^2.                             (F.10)
```

Indeed, after division by `r^2` the two endpoint determinants converge in
moments to `kappa^2(det Q)^2` on the nonempty open cone `Q<0`; the limiting
conditional Gaussian law has full support, so its expectation is strictly
positive, continuously and uniformly on `K`.

Dividing (F.9) by the lower bound in (F.10) proves (F.1).

## 5. Scope and consequence

This closes exactly RP-F in the compact-mark elder-selection inequality.  It
does not establish the stronger global display

```text
C r^3[1+(|b|+kappa)^10] exp(-c(b^2+kappa^2)),
```

because that display requires a separate quantitative lower bound on the
conditional remote target mismatch for unbounded marks.  The global
all-typed majorant is a different domination interface.

Two details in the baseline global-envelope sketch therefore must not be used
to strengthen (F.1).  First, the density in (F.7) is the conditional density

```text
p_(P_r^corr,R_y)(L_r,(u,0)) / p_(P_r^corr)(L_r),
```

not the joint numerator alone.  On compact `K` the denominator has a uniform
positive lower bound, which is all this proof needs.  Second, for the displayed
corrected target

```text
L_r=(b-kappa*r^3/12,-kappa/6,0,...,0),
```

the historical coefficient `1/2` in
`|L_r|^2 >= (1/2)(b^2+kappa^2)` is false.  For `0<r<=1`, the safe elementary
bound

```text
|L_r|^2 >= (1/37)(b^2+kappa^2)
```

does hold.  Even that joint-target coercivity does not automatically survive
division by the pair-pin density.  A global Palm Gaussian penalty would need
a coercive lower bound for the conditional Schur residual

```text
(u,0)-Cov(R_y,P_r^corr)Cov(P_r^corr)^(-1)L_r.
```

No such global statement is claimed here.

The remaining selection gates are therefore RP-A/RP-L, RP-C, and RP-S.
Uniform elder selection and the candidate theorem remain on HOLD.
