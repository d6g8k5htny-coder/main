# Replacement for Supplement A.1--A.2: the elder mark and elder-failure exhaustion

This section supersedes Supplement A.1--A.2 in
`SIDE24_GAP_FILL_SUPPLEMENT.md`.  It retains the sound level-transition idea
from baseline Lemma 1.2a, supplies the missing Borel details, and proves that
the resulting global mark agrees with an explicit mark constructed from the
two local upper-sector germs of an index-two saddle.

The ambient manifold below is the flat torus
\(X=\mathbb T^3_{24}\), although the level-transition construction works on
any compact connected manifold.  Write
\[
    U_a(g):=\{z\in X:g(z)>a\},\qquad g\in C^2(X).
\]
We use open superlevel components only.  For a Morse function with distinct
critical values, these encode the same finite \(H_0\) persistence pairing as
the closed superlevel filtration.

The statements labelled **proved** below are deterministic descriptive-set
theory or Morse-theoretic facts.  No small-\(r\) probability estimate is used
in their proofs.  The final \(O(r^3)\) selection estimate is stated separately
and remains conditional on five explicitly listed Palm estimates.

---

## A.1. A corrected Borel elder-pair mark

### A.1.1. The Borel component relation

Fix a countable family \(\mathcal B=\{B_k:k\geq1\}\) of path-connected
coordinate balls such that each \(\overline{B_k}\) is compact and, for every
open \(V\subset X\) and every \(z\in V\), some \(B_k\) satisfies
\[
        z\in B_k,\qquad \overline{B_k}\subset V.
\]
For fixed \(k\), put
\[
 B_k\Subset U_a(g)
 \quad\Longleftrightarrow\quad
 \inf_{z\in\overline{B_k}}g(z)>a.                                      \tag{A.1}
\]
The map \(g\mapsto\inf_{\overline{B_k}}g\) is 1-Lipschitz in the uniform
norm.  Hence (A.1) is Borel in \((g,a)\).

For \(x,y\in X\), define \(\mathcal R(g,a;x,y)\) to hold if there are
\(k_1,\ldots,k_m\) such that
\[
\begin{split}
 &x\in B_{k_1},\qquad y\in B_{k_m},\qquad
 B_{k_i}\cap B_{k_{i+1}}\neq\varnothing,\quad 1\leq i<m,\\
 &B_{k_i}\Subset U_a(g),\quad 1\leq i\leq m.
\end{split}                                                            \tag{A.2}
\]
This is a countable union over finite strings of a countable family, so
\(\mathcal R\) is Borel in \((g,a,x,y)\).  Moreover,
\[
 \mathcal R(g,a;x,y)
 \quad\Longleftrightarrow\quad
 x,y\text{ belong to the same component of }U_a(g).                    \tag{A.3}
\]
Indeed, a chain in (A.2) has connected union contained in \(U_a(g)\).
Conversely, an open connected subset of a manifold is path connected.  A
path in a component of \(U_a(g)\) has compact image; covering that image by
members of \(\mathcal B\) whose closures lie in \(U_a(g)\), and ordering a
finite subcover along the path, produces a chain as in (A.2).

Fix a countable dense set \(D=\{q_j:j\geq1\}\subset X\).  Define
\[
\begin{split}
 \mathcal O(g,M,a)
 \quad\Longleftrightarrow\quad &g(M)>a\ \text{ and there is }j\geq1
 \text{ such that}\\
 &g(q_j)>g(M),\qquad \mathcal R(g,a;M,q_j).
\end{split}                                                            \tag{A.4}
\]
Thus \(\mathcal O(g,M,a)\) says that the component of \(U_a(g)\) containing
\(M\) contains a point strictly higher than \(M\).  The use of the dense set
does not alter that meaning: if such a point exists, a small open
neighborhood of it in the same component has value greater than \(g(M)\)
and contains some \(q_j\).  Formula (A.4) is Borel.

### A.1.2. The level-transition mark

Let \(\mathcal G\subset C^2(X)\) be the set of Morse functions with pairwise
distinct critical values.  This is an open, hence Borel, subset of
\(C^2(X)\): the finitely many nondegenerate critical points persist under a
small \(C^2\) perturbation, the gradient has a positive lower bound outside
their isolating neighborhoods, and the finite minimum gap between their
critical values remains positive.

For \(g\in\mathcal G\), a local maximum \(M\), and an index-two critical point
\(S\), set \(b=g(M)\) and \(h=g(S)\).  Define
\[
\begin{split}
 e_{\mathrm{lev}}(g;M,S):={}&
 \mathbf 1_{\{b>h\}}
 \mathbf 1\Big\{\exists n\geq1:\ n^{-1}<b-h\ \text{ and, for every }
 q\in\mathbb Q\cap(0,n^{-1}),\\[-2mm]
 &\hspace{43mm}
 \neg\mathcal O(g,M,h+q)\ \text{ and }\mathcal O(g,M,h-q)\Big\}.
                                                                         \tag{A.5}
\end{split}
\]
Set \(e_{\mathrm{lev}}=0\) unless \(g\in\mathcal G\), \(M\) is a local
maximum, and \(S\) is an index-two critical point.  Criticality and type are
Borel conditions on the first two jets, and all quantifiers in (A.5) are
countable.  Hence
\[
 (g,M,S)\longmapsto e_{\mathrm{lev}}(g;M,S)
 \quad\text{is Borel on }C^2(X)\times X^2.                              \tag{A.6}
\]

**Theorem A.1 (correctness of the level-transition mark; proved).**  On
\(\mathcal G\),
\[
 e_{\mathrm{lev}}(g;M,S)=1
 \quad\Longleftrightarrow\quad
 (M,S)\text{ is the finite superlevel }H_0\text{ elder pair}.           \tag{A.7}
\]

**Proof.**  For a level \(a<b\), the class born at \(M\) is the elder
representative of its component precisely when that component contains no
point higher than \(M\), i.e. precisely when \(\mathcal O(g,M,a)\) is false.
As the threshold decreases, superlevel components merge but never split.
Consequently, once the component containing \(M\) has acquired a point above
\(b\), the predicate \(\mathcal O\) remains true at all lower regular levels.

For a Morse function with distinct critical values, the deformation lemma
makes this representative status locally constant between consecutive
critical values.  If the finite class born at \(M\) dies at the merging
saddle \(S\), it is representative at every sufficiently close level above
\(h\), and immediately below \(h\) its component contains the strictly higher
elder representative of the other component.  Choose \(n\) so that
\(n^{-1}<b-h\) and the interval \([h-n^{-1},h+n^{-1}]\) contains no critical
value other than \(h\).  The two conditions in (A.5) then hold.

Conversely, (A.5) says that the class of \(M\) is representative at every
sufficiently close regular level above \(h\), but not representative at every
sufficiently close regular level below \(h\).  The only critical value at
which that one-sided change can occur is \(h\).  Since \(S\) is index two in
dimension three, its superlevel handle either merges two components or is a
same-component attachment.  A same-component attachment cannot change the
representative.  Hence the handle at \(S\) merges the component represented
by \(M\) with one having a strictly higher representative, which is exactly
the finite elder pairing.  \(\square\)

This proves, after the minor basis correction in (A.1)--(A.3), the substance
of baseline Lemma 1.2a.  It also gives a global Borel check on the local-sector
construction below.

### A.1.3. Connection level and birth level without a zero floor

For continuous \(g\) and \(u,v\in X\), define the maximin connection level
\[
 \mathfrak m_g(u,v)
   :=\sup_{\gamma:u\leadsto v}\ \min_{s\in[0,1]}g(\gamma(s)),            \tag{A.8}
\]
where the supremum is over continuous paths.  On a compact Riemannian
manifold, \((g,u,v)\mapsto\mathfrak m_g(u,v)\) is continuous for the uniform
topology on \(g\).  The dependence on \(g\) is 1-Lipschitz.  For the endpoint
dependence, join nearby endpoints by short geodesics; uniform continuity of
\(g\), together with
\(\mathfrak m_g(u,v)\leq\min\{g(u),g(v)\}\), gives both semicontinuity
inequalities.  In particular,
\[
 \mathcal R(g,a;u,v)\quad\Longleftrightarrow\quad
 \mathfrak m_g(u,v)>a,\qquad u,v\in U_a(g).                            \tag{A.9}
\]

For \(u\in U_a(g)\), define the birth height of its open superlevel component
by the extended-real countable supremum
\[
 \beta_g(u,a)
 :=\sup_{j\geq1}
 \begin{cases}
    g(q_j),&\mathcal R(g,a;u,q_j),\\
    -\infty,&\text{otherwise}.
 \end{cases}                                                           \tag{A.10}
\]
This is Borel in \((g,u,a)\).  It equals
\[
 \sup\{g(z):z\in C_a(u)\},                                             \tag{A.11}
\]
where \(C_a(u)\) is the component of \(U_a(g)\) containing \(u\).  On
\(\mathcal G\), (A.11) is attained at the component's unique representative
maximum.  Importantly, (A.10) never multiplies a value by an indicator.  If
all values in the component are negative, \(\beta_g(u,a)\) is the correct
negative birth height rather than the spurious value zero.

### A.1.4. A measurable adaptive upper-sector germ

We now construct the two upper-sector probes without choosing a universal
spatial radius.  Let \(\iota>0\) be the injectivity radius of the flat torus
and let
\[
        q_n:=2^{-n-4}\iota,\qquad n=0,1,2,\ldots .                       \tag{A.12}
\]
Suppose \(S\) is an index-two critical point of \(g\), and write
\(H=D^2g(S)\).  Thus \(H\) has a unique positive eigenspace.  Let
\(P_+(H)\) denote its orthogonal spectral projection and put
\[
 \mu(H):=\min_{\lambda\in\operatorname{spec}(H)}|\lambda|>0.            \tag{A.13}
\]
To select a Borel orientation, using the fixed parallel frame
\((e_1,e_2,e_3)\) of the flat torus, let
\[
 j(H):=\min\operatorname*{argmax}_{1\leq j\leq3}\|P_+(H)e_j\|,
 \qquad
 v(H):=\frac{P_+(H)e_{j(H)}}{\|P_+(H)e_{j(H)}\|}.                       \tag{A.14}
\]
The denominator is nonzero, and \(H\mapsto v(H)\) is Borel on the
index-two locus.  Replacing \(v\) by \(-v\) will only interchange the labels
\(+\) and \(-\).

Identify tangent spaces by the flat parallelism and define
\[
 \omega_n(g,S)
 :=\sup_{|z|\leq4q_n}
       \big\|D^2g(\exp_S z)-D^2g(S)\big\|_{\mathrm{op}}.                \tag{A.15}
\]
The maps \(\omega_n\) are continuous on \(C^2(X)\times X\).  Since
\(D^2g\) is continuous, the integer
\[
 N(g,S):=\min\{n\geq0:\omega_n(g,S)<\mu(H)/16\}                       \tag{A.16}
\]
is finite.  It is Borel because the event \(\{N=n\}\) is a finite Boolean
combination of Borel inequalities.  Set
\[
 \rho(g,S):=q_{N(g,S)},\qquad
 u_\pm(g,S):=\exp_S\big(\pm\rho(g,S)v(H)\big).                          \tag{A.17}
\]

**Lemma A.2 (adaptive-sector certificate; proved).**  Let \(h=g(S)\).  The
points \(u_+\) and \(u_-\) lie in the two distinct local upper-sector germs
of \(S\).  Every smaller dyadic radius satisfying (A.16) gives points in the
same respective global components of \(U_h(g)\).  Moreover,
\[
 \begin{array}{rcl}
 C_+(S)\neq C_-(S)
 &\Longleftrightarrow&
 \neg\mathcal R(g,h;u_+,u_-)\\[1mm]
 &\Longleftrightarrow&
 \mathfrak m_g(u_+,u_-)=h,                                             \tag{A.18}\\
 C_+(S)=C_-(S)
 &\Longleftrightarrow&
 \mathfrak m_g(u_+,u_-)>h.
 \end{array}
\]
Here \(C_\pm(S)\) denotes the component of \(U_h(g)\) containing \(u_\pm\).

**Proof.**  Let \(v=v(H)\), \(\rho=\rho(g,S)\), and let \(\lambda_+>0\) be
the positive eigenvalue of \(H\).  Taylor's formula with integral remainder
and (A.15)--(A.16) give, for \(0<|t|\leq4\rho\),
\[
 g(\exp_S(tv))-h
 \geq \frac12\big(\lambda_+-\mu(H)/16\big)t^2>0.                       \tag{A.19}
\]
If \(y\perp v\) and \(0<|y|\leq4\rho\), the restriction of \(H\) to
\(v^\perp\) is at most \(-\mu(H)I\), and the same calculation yields
\[
 g(\exp_S y)-h
 \leq-\frac12\big(\mu(H)-\mu(H)/16\big)|y|^2<0.                       \tag{A.20}
\]
Thus the two punctured axial segments lie above \(h\), while the transverse
disc separates them below \(h\).  This separation gives exactly two local
components, not merely two distinguished points.  Indeed, for each fixed
axial coordinate \(t\), the function
\(y\mapsto g(\exp_S(tv+y))\) on \(v^\perp\) has Hessian at most
\(-(15/16)\mu(H)I\), and is therefore strictly concave.  Its strict
superlevel set above \(h\) is convex.  Any point of
\(U_h(g)\cap B(S,4\rho)\) has nonzero axial coordinate by (A.20), can be
joined at fixed axial coordinate to the corresponding point on the axis,
and can then be joined along the positive or negative axial segment to
\(u_+\) or \(u_-\).  Hence the sign of the axial coordinate gives precisely
the two components of this local superlevel set.  They are the two local
upper-sector germs in the Morse handle model.  Formula (A.19) also connects
probes at any two smaller certified dyadic radii without leaving \(U_h(g)\),
proving germ independence.

Concatenating the two axial segments through \(S\) gives a path from \(u_+\)
to \(u_-\) whose minimum is exactly \(h\), so
\(\mathfrak m_g(u_+,u_-)\geq h\).  If the probes lie in the same open
component of \(U_h(g)\), a connecting path has compact image in \(U_h(g)\)
and therefore has minimum strictly greater than \(h\).  Conversely,
\(\mathfrak m_g(u_+,u_-)>h\) supplies such a path.  This proves (A.18).
\(\square\)

The strict inequality \(\mathfrak m<h\) used in the superseded Supplement
A.1 is therefore impossible for these sector probes: the path through \(S\)
always gives \(\mathfrak m\geq h\).  Distinct upper components correspond to
the equality \(\mathfrak m=h\), not to \(\mathfrak m<h\).

Define
\[
 \beta_\pm(g,S):=\beta_g(u_\pm(g,S),g(S))                               \tag{A.21}
\]
and, on the typed generic locus, define the sector mark
\[
 e_{\mathrm{sec}}(g;M,S)
 :=\mathbf 1_{\{\mathfrak m_g(u_+,u_-)=g(S)\}}
   \mathbf 1_{\{g(M)=\min(\beta_+,\beta_-)\}}.                         \tag{A.22}
\]
Set it to zero off that locus.  Every ingredient in (A.22) is Borel by
(A.8), (A.10), and (A.13)--(A.17), so \(e_{\mathrm{sec}}\) is Borel.

**Theorem A.3 (correctness and equivalence of the sector mark; proved).**
For \(g\in\mathcal G\), a local maximum \(M\), and an index-two saddle \(S\),
\[
 e_{\mathrm{sec}}(g;M,S)=e_{\mathrm{lev}}(g;M,S)
 =\mathbf 1_{\{(M,S)\text{ is the finite elder }H_0\text{ pair}\}}.    \tag{A.23}
\]

**Proof.**  If \(C_+=C_-\), the index-two handle is a same-component
attachment and kills no \(H_0\) class; both sides of (A.23) vanish.  If
\(C_+\neq C_-\), lowering the threshold through \(h=g(S)\) merges exactly
those two components.  By (A.10)--(A.11), \(\beta_+\) and \(\beta_-\) are
their birth heights.  Their representative maxima are unique and have
different values because \(g\in\mathcal G\).  The elder rule preserves the
component having the larger birth height and kills the one having the smaller
birth height.  Therefore \(M\) pairs with \(S\) exactly when
\(g(M)=\min(\beta_+,\beta_-)\).  Equation (A.18) supplies the separation
condition in (A.22), and Theorem A.1 identifies the same pair via (A.5).
\(\square\)

We henceforth write simply
\[
             e(g;M,S):=e_{\mathrm{sec}}(g;M,S)=e_{\mathrm{lev}}(g;M,S)
                                                                         \tag{A.24}
\]
on \(\mathcal G\), using either Borel extension off \(\mathcal G\).

---

## A.2. Corrected elder-failure exhaustion

Let \(g\in\mathcal G\), let \(M\) be a local maximum, let \(S\) be an
index-two saddle, and put
\[
       b=g(M),\qquad h=g(S)<b,\qquad r=d(M,S).
\]
Let \(C_\pm\) be the adaptive upper-sector components from Lemma A.2 and let
\(Q_\pm\) be their unique representative maxima, so
\(g(Q_\pm)=\beta_\pm\).  Define the **component-adjacency event**
\[
 A:=\{M\in C_+\cup C_-\}                                                \tag{A.25}
\]
and the **self-attachment event**
\[
 L:=\{C_+=C_-\}.                                                        \tag{A.26}
\]
Both are Borel: (A.25)--(A.26) are finite Boolean combinations of the
component relation \(\mathcal R\) evaluated at the adaptive probes.  Notice
that (A.25) is weaker than convergence of an entire gradient-ascent
half-branch to \(M\); a deterministic branch-capture theorem may be used to
bound \(A^c\), but is not part of the definition.

**Lemma A.4 (disjoint elder-failure exhaustion; proved).**  Conditional on
\(A\cap\{e=0\}\), exactly one of the following cases occurs.

1. **Earlier death.**  In the incident component containing \(M\), the
   representative is not \(M\).  The class born at \(M\) has a unique elder
   death saddle \(R\notin\{M,S\}\), and
   \[
                         h<g(R)<b.                                     \tag{A.27}
   \]

2. **Same-component attachment.**  The maximum \(M\) is the representative
   of its incident component and \(C_+=C_-\).  The handle at \(S\) kills no
   \(H_0\) class.

3. **The opposite component is younger.**  The maximum \(M\) is the
   representative of its incident component, \(C_+\neq C_-\), and the other
   component has representative maximum \(N\notin\{M,S\}\) satisfying
   \[
                         h<g(N)<b.                                     \tag{A.28}
   \]

Thus, outside the same-component case, elder failure under component
adjacency always supplies a third critical point in the **open** pair window
\((h,b)\).

**Proof.**  On \(A\), choose the incident component \(C_M\) containing
\(M\); it is unambiguous unless \(C_+=C_-\), in which case both labels denote
the same component.

If \(M\) is not the representative of \(C_M\), then \(C_M\) contains a
higher representative and hence the class born at \(M\) has already died.
Because \(M\) and that representative lie in the same open component of
\(U_h(g)\), their connection level is strictly above \(h\).  The merge-tree
death level of \(M\) is therefore strictly above \(h\).  It is strictly below
\(b\), since birth and death are distinct critical values.  Its unique death
saddle \(R\) proves (A.27), giving case 1.

Suppose now that \(M\) is the representative of \(C_M\).  If
\(C_+=C_-\), the local index-two handle attaches to one component and cannot
kill an \(H_0\) class, giving case 2.  If \(C_+\neq C_-\), let \(N\) be the
representative maximum of the other component.  Its value is greater than
\(h\), because that component is a nonempty subset of \(U_h(g)\).  If
\(g(N)>b\), the component represented by \(M\) is younger and \((M,S)\) is
the elder pair, contrary to \(e=0\).  Equality is impossible because critical
values are distinct.  Hence \(h<g(N)<b\), giving case 3.  The three cases are
disjoint by the successive alternatives “\(M\) is/is not representative,”
“the sectors are/are not the same component,” and are exhaustive. \(\square\)

### A.2.1. A genuinely disjoint spatial partition

Fix \(C>2\) and \(\delta_0>0\), and assume
\[
                         0<r<\delta_0/C.                               \tag{A.29}
\]
For \(y\in X\), write
\(d_P(y):=d(y,\{M,S\})\), and define
\[
\begin{array}{ll}
 \mathcal R_{\mathrm{col}}(r)
   :=\{y:d_P(y)\leq Cr\},
 &\text{(the boundary \(Cr\) belongs to the collar)},\\[1mm]
 \mathcal R_{\mathrm{sing}}(r)
   :=\{y:Cr<d_P(y)<\delta_0\},
 &\text{(the open intermediate annulus)},\\[1mm]
 \mathcal R_{\mathrm{far}}
   :=\{y:d_P(y)\geq\delta_0\},
 &\text{(the boundary \(\delta_0\) belongs to the far region)}.
\end{array}                                                            \tag{A.30}
\]
Because the same distance function is used in all three definitions and
\(Cr<\delta_0\),
\[
 X=\mathcal R_{\mathrm{col}}(r)\ \dot\cup\
   \mathcal R_{\mathrm{sing}}(r)\ \dot\cup\
   \mathcal R_{\mathrm{far}}.                                         \tag{A.31}
\]
This avoids the overlap and uncovered sets created by mixing distance from
\(\{M,S\}\) with distance from the midpoint.

If \(x\) is the geodesic midpoint of \((M,S)\) and \(s=d(x,y)\), then
\[
                  |s-d_P(y)|\leq r/2.                                 \tag{A.32}
\]
Consequently the singular region satisfies
\(s>(C-1/2)r\), so the ratio \(r/s\) lies in the compact chart
\([0,(C-1/2)^{-1})\); the collar satisfies
\(s\leq(C+1/2)r\); and the far region satisfies
\(s\geq\delta_0-r/2\).  Thus (A.30) can be translated into midpoint charts
by constant changes without changing its disjointness.

In case 1 of Lemma A.4 let \(Y=R\), and in case 3 let \(Y=N\).  These points
are unique.  On the generic locus they are Borel functions of \((g,M,S)\).
Here is the selection detail.  The critical-point graph
\[
 \mathscr C:=\{(g,y)\in\mathcal G\times X:\nabla g(y)=0\}
\]
is Borel and has finite fibers.  The Lusin--Novikov finite-fiber
uniformization theorem therefore supplies a countable family of Borel
partial maps whose values enumerate every fiber.  Equivalently, one may
construct these maps by assigning each critical point the first rational
coordinate ball in a fixed enumeration that isolates it, then using the
implicit-function theorem on that ball.  Applying the Borel elder-pair mark
and the Borel component relation to this enumeration selects \(R\) as the
unique critical point satisfying \(e(g;M,R)=1\), and selects \(N\) as the
unique representative maximum in the other component.  Define
\[
\begin{split}
 F_{\mathrm{adj}}&:=\{e=0\}\cap A^c,\\
 F_{\mathrm{self}}&:=\{e=0\}\cap A\cap\{\text{case 2 of Lemma A.4}\},\\
 F_j&:=\{e=0\}\cap A\cap\{\text{case 1 or case 3}\}
          \cap\{Y\in\mathcal R_j\},
 \qquad j\in\{\mathrm{col},\mathrm{sing},\mathrm{far}\}.
                                                                         \tag{A.33}
\end{split}
\]
Lemma A.4 and (A.31) give the **exact disjoint failure partition**
\[
 \{e=0\}=F_{\mathrm{adj}}\ \dot\cup F_{\mathrm{self}}
 \ \dot\cup F_{\mathrm{col}}\ \dot\cup F_{\mathrm{sing}}
 \ \dot\cup F_{\mathrm{far}}.                                        \tag{A.34}
\]

For probabilistic estimates it is unnecessary to estimate the law of the
canonical witness.  Define the all-witness counts
\[
 N_j:=\#\big\{y\notin\{M,S\}:\nabla g(y)=0,\ h<g(y)<b,
                      \ y\in\mathcal R_j\big\}.                        \tag{A.35}
\]
Then
\[
              \mathbf1_{F_j}\leq\mathbf1_{\{N_j\geq1\}}\leq N_j,
              \qquad j\in\{\mathrm{col},\mathrm{sing},\mathrm{far}\}.
                                                                         \tag{A.36}
\]
The counts are finite and Borel on \(\mathcal G\).  Other, noncanonical
witnesses may occur in several regions, but this causes no ambiguity in
(A.34): each failure is allocated by its unique canonical witness, while
(A.35)--(A.36) are used only as upper bounds.

---

## A.3. What is proved and what remains probabilistic

Let \(\mathbb P^{MS}_{r,t,b,\kappa}\) denote the determinant-weighted Palm law
for the pins
\[
 g(M)=b,\qquad g(S)=h=b-\kappa r^3/6,\qquad
 \nabla g(M)=\nabla g(S)=0,
\]
with \(M\) a maximum and \(S\) index two, and let
\[
 p_r(t,b,\kappa):=\mathbb E^{MS}_{r,t,b,\kappa}[e(g;M,S)].              \tag{A.37}
\]
Taking probabilities in (A.34) and using (A.36) gives the proved inequality
\[
\begin{split}
 1-p_r(t,b,\kappa)
 \leq{}&\mathbb P^{MS}_{r,t,b,\kappa}(A^c)
       +\mathbb P^{MS}_{r,t,b,\kappa}(F_{\mathrm{self}})\\
      &+\mathbb E^{MS}_{r,t,b,\kappa}N_{\mathrm{col}}
       +\mathbb E^{MS}_{r,t,b,\kappa}N_{\mathrm{sing}}
       +\mathbb E^{MS}_{r,t,b,\kappa}N_{\mathrm{far}}.                \tag{A.38}
\end{split}
\]

The following are a sufficient residual-premise set for this union-bound
route to the claimed selection rate.  Uniformly in \(t\in S^2\) and
\((b,\kappa)\) in every fixed compact subset of
\(\mathbb R\times(0,\infty)\), prove
\[
\begin{array}{rcll}
 \mathbb P^{MS}_{r,t,b,\kappa}(A^c)&\leq&C_A r^3,
   &\textbf{(RP-A: component adjacency/capture)},\\
 \mathbb P^{MS}_{r,t,b,\kappa}(F_{\mathrm{self}})&\leq&C_L r^3,
   &\textbf{(RP-L: same-component attachment)},\\
 \mathbb E^{MS}_{r,t,b,\kappa}N_{\mathrm{col}}&\leq&C_{\mathrm{col}}r^3,
   &\textbf{(RP-C: collar triple contact)},\\
 \mathbb E^{MS}_{r,t,b,\kappa}N_{\mathrm{sing}}&\leq&C_{\mathrm{sing}}r^3,
   &\textbf{(RP-S: singular-near triple contact)},\\
 \mathbb E^{MS}_{r,t,b,\kappa}N_{\mathrm{far}}&\leq&C_{\mathrm{far}}r^3.
   &\textbf{(RP-F: fixed-distance Kac--Rice)}
\end{array}                                                            \tag{A.39}
\]
Under (A.39), (A.38) yields
\[
 1-p_r(t,b,\kappa)
 \leq(C_A+C_L+C_{\mathrm{col}}+C_{\mathrm{sing}}+C_{\mathrm{far}})r^3.
                                                                         \tag{A.40}
\]

### Status ledger

| Statement | Status |
|---|---|
| Borel component relation (A.1)--(A.3) | **PROVED** |
| Global level-transition elder mark (A.5)--(A.7) | **PROVED** |
| Adaptive measurable upper-sector germ (A.12)--(A.18) | **PROVED** |
| Negative-safe component birth height (A.10) | **PROVED** |
| Equality \(e_{\mathrm{sec}}=e_{\mathrm{lev}}\) (A.23) | **PROVED** |
| Disjoint deterministic elder-failure exhaustion (A.27)--(A.34) | **PROVED** |
| Selection inequality (A.38) | **PROVED** |
| Bounds RP-A, RP-L, RP-C, and RP-S in (A.39) | **RESIDUAL PREMISES; not proved here** |
| Bound RP-F in (A.39) | **PROVED AND INDEPENDENTLY AUDITED IN V3.2; see `fixed_distance_witness_audit.md`** |
| Uniform conclusion \(1-p_r=O(r^3)\) | **CONDITIONAL on the four still-open bounds RP-A/RP-L/RP-C/RP-S** |

Accordingly, this replacement closes the definition, correctness,
measurability, and deterministic-exhaustion defects.  It does **not** by
itself close the probabilistic elder-selection estimate.
