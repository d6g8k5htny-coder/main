# Mixed singular transition face and value-window audit

This companion note records the projective calculation used in Section 5 of
`rp_c_rp_s_facewise_closure.md`.

Let the pair axis be \(u\), choose transverse directions \(v,w\), and put
\(h=r/2=\eta s/2\).  Under the centered law conditional on the exact pair
values and gradients,

\[
 F(\pm h,0,0)=F_u(\pm h,0,0)=F_v(\pm h,0,0)=F_w(\pm h,0,0)=0.
\]

Analytic division gives

\[
 F(u,0,0)=(u^2-h^2)^2H(u),\quad
 F_v(u,0,0)=(u^2-h^2)A(u),\quad
 F_w(u,0,0)=(u^2-h^2)B(u).                               \tag{M.1}
\]

The value row must not subtract the unpinned random midpoint value \(F(x)\).
Use the exact raw-witness transform

\[
\begin{aligned}
 \bar V_0={}&s^{-3}\{F(y)-\tfrac{s\varrho}{2}F_v(y)
                         -\tfrac{sc}{3}F_u(y)\},\\
 V_1={}&s^{-2}F_u(y),\qquad
 V_2=s^{-1}F_v(y),\qquad V_3=s^{-1}F_w(y).                \tag{M.1a}
\end{aligned}
\]

The triangular map from the raw witness value-gradient vector has exact
determinant magnitude \(s^{-7}\).  With \(a=\eta^2/4\), \(D=1-a\), Taylor
expansion on the positive axial chart gives

\[
\begin{aligned}
\bar V_0={}&-D(1+3a)sH_0/3-(1+3a)\varrho A_0/6
 -2D(1+a)s^2H_1/3-(3+a)s\varrho A_1/6
 -\varrho^2D_0/6+O_3,\\
V_1={}&4DsH_0+2\varrho A_0+D(4+D)s^2H_1
 +(2+D)s\varrho A_1+\varrho^2D_0/2+O_3,\\
V_2={}&sDA_0+\varrho C_0+O_2,\qquad
V_3=sDB_0+\varrho E_0+O_2,                               \tag{M.1b}
\end{aligned}
\]

where \(O_j=O_{L^2}((s+\varrho)^j)\), uniformly in
\(a\in[0,\eta_0^2/4]\).  Analytic Hermite division plus exponential
side-24 Fourier decay gives these uniform remainders.

Use \(H_0,H_1,A_0,A_1,B_0,C_0=F_{vv}(0),E_0=F_{vw}(0)\), and
\(D_0=F_{uvv}(0)\).  Modulo the pair-pin span their Fourier monomials are

\[
 u^4,u^5,u^2v,u^3v,u^2w,v^2,vw,uv^2,                    \tag{M.2}
\]

respectively.  They are distinct from the pair symbols

\[
 1,u,u^2,u^3,v,uv,w,uw.                                  \tag{M.3}
\]

Put

\[
 s=\Lambda T,\quad\varrho=\Lambda R,\quad T^2+R^2=1,
 \qquad a=\eta^2/4,\quad D=1-a.                          \tag{M.4}
\]

The first-order value and tangential-gradient rows are proportional.  Put

\[
 \lambda={12c\over c^2+3a},\qquad
 \bar W=V_1+\lambda\bar V_0.                              \tag{M.5}
\]

Then, since \(c=1+O(\varrho^2)\),

\[
 \bar W=-{3D\over1+3a}
 \{s^2D^2H_1+s\varrho DA_1+\varrho^2D_0/2\}+O_3.         \tag{M.6}
\]

Normalize as
\((\bar V_0/\Lambda,\bar W/\Lambda^2,V_2/\Lambda,V_3/\Lambda)\).
The limiting rows are

\[
\begin{aligned}
U_0&=-(1+3a)(4TDH_0+2RA_0)/12,\\
U_1&=-3D(T^2D^2H_1+TRDA_1+R^2D_0/2)/(1+3a),\\
U_2&=TDA_0+RC_0,\\
U_3&=TDB_0+RE_0.                                          \tag{M.6a}
\end{aligned}
\]

The second row occupies the new \((H_1,A_1,D_0)\) symbol sector, and the
fourth the distinct \((B_0,E_0)\) sector.  The remaining two rows are
independent for all \(T,R\ge0\), \(T^2+R^2=1\).  In particular the endpoint
frames are exactly

\[
 T=0:(A_0,D_0,C_0,E_0),\qquad
 R=0:(H_0,H_1,A_0,B_0).                                  \tag{M.7}
\]

The sum of squared nonzero coefficient minors factors as

\[
 {D^2\over16}(R^2+T^2D^2)(R^2+2T^2D^2)^4>0.             \tag{M.8}
\]

Fourier uniqueness and uniform spectral-Hilbert convergence now give on
the full projective quarter-circle

\[
 \det\operatorname{Cov}(\bar V_0,V_1,V_2,V_3\mid V_r)
 \ge c\Lambda^{10}.                                      \tag{M.9}
\]

This legitimate four-row frame simultaneously supplies the mixed,
contact-dominant, and collinear-dominant overlaps; the former random-midpoint
coarea issue and the former second blow-up are absent.

For the ESIP use \(V_1\) itself.  The collinear cubic mean mismatch is

\[
 |(V_1)_{\rm target}-\mathbb EV_1|
 \ge c_K\kappa,                                          \tag{M.10}
\]


\[
 \operatorname{Var}(V_1\mid V_r)
 \le C(s^2+\varrho^2)\le C\Lambda^2.                     \tag{M.11}
\]

The mismatch stays separated from zero for \(c=\pm1\),
\(0\le\eta\le\eta_0<1\), compact positive \(\kappa\), and a sufficiently
small axis chart.  It gives

\[
 p_{(f(y),\nabla f(y))\mid V_r}(u,0)
 \le Cs^{-7}\Lambda^{-5}e^{-c_K/\Lambda^2}.              \tag{M.12}
\]

Finally, the controlling all-witness definition is

\[
 N_j=\#\{y\ne M,S:\nabla f(y)=0,\ h<f(y)<b,
                    \ y\in\mathcal R_j\}.                \tag{M.13}
\]

Therefore both RP-C and RP-S use exactly one value integration of width
\(\kappa r^3/6\).  The interval is part of the canonical count, not a later
probabilistic restriction.
