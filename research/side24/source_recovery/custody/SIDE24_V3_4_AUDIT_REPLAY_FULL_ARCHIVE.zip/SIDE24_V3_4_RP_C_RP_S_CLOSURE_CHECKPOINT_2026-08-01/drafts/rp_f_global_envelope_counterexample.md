# Exact counterexample to the V5 global Palm Gaussian envelope

## Claim being tested

V5 G.8 bounds a joint Gaussian target density by
\(e^{-c(b^2+\kappa^2)}\) and carries that penalty into the pair-conditioned
Palm expectation of a remote witness.  The passage is invalid because
conditioning divides by the pair-pin density.  For the side-24 field the
claimed conditional penalty is not merely unproved; it is false.

## Product/parity construction

The periodized side-24 covariance factorizes:

\[
 K_{24}(z)=k_{24}(z_1)k_{24}(z_2)k_{24}(z_3),
\]

where \(k_{24}\) is even.  Choose the pair axis \(t=e_1\), midpoint \(x=0\),
and a remote point

\[
 y=(0,y_2,y_3),\qquad |(y_2,y_3)|\ge\delta.
\]

In the contact limit, the odd pair-pin block contains

\[
 O=(f_1,f_2,f_3,u),\qquad u=-f_{111}/12,
\]

and the \(\kappa\)-target occurs only in \(u\).

By one-coordinate parity, the remote even coordinates
(f(y),f_2(y),f_3(y)) have zero covariance with (u).  For the remaining
remote coordinate, product structure gives

\[
 \operatorname{Cov}(f_1(y),O)
 =k_{24}(y_2)k_{24}(y_3)\operatorname{Cov}(f_1(0),O).
\]

Its regression on \(O\) is therefore the same scalar multiple of the pinned
coordinate \(f_1(0)\), whose target is zero.  The entire conditional law of
\((f(y),\nabla f(y))\) on this transverse plane is independent of the gap pin
and hence independent of \(\kappa\).

Analyticity shows that at \(y_1=\varepsilon\) the residual \(\kappa\)-column is
only \(O(|\varepsilon|)\).  Spatial integration near the plane therefore has
the model behavior

\[
 \int_{-\varepsilon_0}^{\varepsilon_0}
 e^{-c\kappa^2\varepsilon^2}\,d\varepsilon
 \asymp \kappa^{-1},
\]

not \(e^{-c'\kappa^2}\).  Multiplication by determinant moments changes only
polynomial factors and cannot restore global Gaussian decay.

## Correct replacement

For every compact positive mark set \(K\), the pair density is bounded above
and below, so the V3.2 conditional proof gives

\[
 \sup_{(t,b,\kappa)\in K}
 \mathbb E^{MS}N_{\rm far}\le C_Kr^3.
\]

For the unbounded lifetime integral, retain the all-pair intensity:

\[
 p_P(L_r)Z_r\mathbb E^{MS}N_{\rm far}
 =p_P(L_r)\mathbb E^0[W_rN_{\rm far}]
 \le Cr^5\operatorname{poly}(b,\kappa)e^{-c(b^2+\kappa^2)}.
\]

The Gaussian factor is valid on this unnormalized joint Kac--Rice numerator.
It is not a property of the Palm-conditioned expectation by itself.
