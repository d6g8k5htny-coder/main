# SIDE24 V3.4 — RP-C/RP-S closure disposition

**Date:** 2026-08-01  
**Disposition:** the seven-part facewise work order is complete in the V3.4
proof layer.  RP-C and RP-S are promoted from `OPEN` to
`PROVED_IN_V3_4_AUDIT_PENDING`.

## Controlling result

The controlling facewise proof is
`drafts/rp_c_rp_s_facewise_closure.md`; its detailed sixth-gate
companion is drafts/three_hessian_conditional_moment_envelope.md.  Their two
regional conclusions are

\[
 \mathbb E^{MS}N_{\rm col}=O(r^3),\qquad
 \mathbb E^{MS}N_{\rm sing}=O(r^3),
\]

uniformly in the pair direction and on compact subsets of
\(\mathbb R\times(0,\infty)\) for \((b,\kappa)\).

The proof uses one common **density-weighted** determinant monomial

\[
 \mathcal D(r,s)=[r(r+s^2)]^2(r^2+s^3)
\]

on every non-endpoint collar and singular-near face.  The pathwise
\(\mathcal D\) bound holds on noncollinear charts, including \(c=0\).  It
is false on the exact collinear axis; there the proof keeps the density
attached and uses the quantified ESIP penalty to absorb a finite \(s^{-6}\)
or \(r^{-3}\) deficit.  A second exact counterexample shows that even the
density-weighted pointwise form has an unavoidable \(d^{-1}\) factor at an
axial endpoint collision.  That divisor is controlled only after inserting
the physical \(d^2\,dd\) measure, as in (8.4) and (EP.2).  Thus the literal
"same pointwise envelope on every face" reading of item 6 is disproved; its
measure-level replacement is what closes the regional integral.

## Work-order accounting

Every **PROVED** entry below means proved in the V3.4 draft and still subject
to the package's independent-audit promotion gate.

| # | Required item | V3.4 evidence | Result |
|---|---|---|---|
| 1 | Generic transverse comparison | exact gradient frame (3.2)--(3.5), explicit value row (3.6a), exact \(r^{-7}\) raw Jacobian | **PROVED** |
| 2 | Separate axial Hermite face | exact factorization (4.1)--(4.5), axial-interior crossover (AI.1)--(AI.4), Fourier-symbol independence | **PROVED** |
| 3 | Midpoint secondary analysis | full five-scale frame (MP.1)--(MP.6), fifth-order face, quantified ESIP | **PROVED** |
| 4 | Endpoint charts | endpoint residual frame (4.9)--(4.13), oblique refinement (6.10)--(6.12), reflected chart | **PROVED** |
| 5 | Singular-near anisotropy | both factors in (5.1), pair-measurable frame (5.3a)--(5.8), covariance bound (5.12), ESIP (5.14)--(5.16), exact raw \(s^{-7}\) Jacobian, full contact/collinear overlap | **PROVED** |
| 6 | Three-Hessian conditional moment control | pointwise common \(\mathcal D\) off the endpoint-axis; collinear ESIP absorption; exact endpoint-axis measure ledger (H.27) | **PROVED IN THE NECESSARY HYBRID FORM; LITERAL ALL-FACE POINTWISE FORM DISPROVED** |
| 7 | Full integration | collar equations (8.1)--(8.6), including (EP.2); singular equations (9.1)--(9.5), including angular axis | **PROVED** |

The canonical count issue is resolved directly from (A.35): every regional
count includes \(h<f(y)<b\).  The single value integration has exact width
\(\kappa r^3/6\); it is not an added assumption.

## Important stratification facts

- The transverse reference monomial is
  \(\varrho^6(4X^2+\varrho^2)\); it is not extended through the axis.
- A deterministic common-\(\mathcal D\) bound on the exact collinear axis is
  false.  The package includes the typed quintic obstruction and uses the
  density-weighted statements (6.7)--(6.8) instead.
- The inherited singular value row subtracted an unpinned random midpoint
  value and therefore did not have the claimed four-variable Jacobian.  The
  repaired pair-measurable row has exact raw Jacobian \(s^{-7}\).  Its first
  two rows coalesce at order \(\Lambda\); the explicit second row
  \(\bar W/\Lambda^2\) produces one uniform \(\Lambda^{10}\) covariance
  determinant across the mixed, contact, and collinear faces.  No
  \((\eta^4,\Lambda)\) second blow-up is needed.
- The oblique endpoint collision estimate is refined to
  \(Cr^5d\rho^{-3}P(J)\), using
  \(dH_Su-rH_St=O(r^2)\).  Combined with the endpoint density and
  \(d^2dd\) volume, its Palm radial factor is \(r^2\,dd\), which integrates
  to \(O(r^3)\).  The axial endpoint instead retains its exact \(d^{-1}\)
  density-weighted factor through \(d^2\,dd\), giving (EP.2).
- The angular axis is integrated with the actual exponential
  \(e^{-c/(s^2+\varrho^2)}\); compactness is never invoked across it.

## Executable evidence and its boundary

`scripts/verify_facewise_collar_axis_integration.py` is fail-closed and checks
the exact Hermite, endpoint, anisotropic, ESIP, and six-term ledger algebra in
normal and optimized Python.  `scripts/diagnose_side24_generic_collar.py`
provides a full-spectrum numerical diagnostic of the exact periodized
covariance.  The quartic endpoint regression prevents reintroduction of the
rejected \(ee\)-curvature/type-transfer route while confirming that the
actual product in that family obeys \(\mathcal D\).
`scripts/verify_hybrid_mixed_curvature_and_axis_absorption.py` separately
checks the mixed-curvature interpolant, both obstruction families, the
pair-measurable singular frame, its 18-minor factorization, and the explicit
generic collar value row in normal and optimized modes.  None of these scripts
is presented as a substitute for the analytic
Fourier-independence, compact-atlas, conditional-moment, or Kac--Rice
arguments in the proof note.

## Promotion status

Combining the two new bounds with the V3.3 RP-A/RP-L proof and the V3.2 RP-F
proof empties the compact-positive-mark elder-selection premise list and
proves

\[
                   1-p_r(t,b,\kappa)=O(r^3).
\]

The package remains **HOLD / do not submit** until an independent audit has
checked the new face families, the hybrid Section 6 envelope, and both
integrations.  This obeys the promotion protocol recorded in V3.3; it is no
longer a claim that a
mathematical RP-C/RP-S premise is missing.
