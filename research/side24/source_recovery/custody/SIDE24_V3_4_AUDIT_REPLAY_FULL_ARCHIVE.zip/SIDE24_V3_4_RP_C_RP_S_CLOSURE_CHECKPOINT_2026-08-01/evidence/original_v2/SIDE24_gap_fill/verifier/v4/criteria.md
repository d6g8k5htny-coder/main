# Verifier v4 — criteria (2026-08-01)

Supersedes v3 (all 18 v3 checks retained). New:
19. Display (A.7) contains the explicit gap Jacobian r³/6 and (A.8) the
    scalar 6^{2/3}/18 (r-power consistency of the pushforward).
20. No placeholder or broken displays (no \cdots}{}, no (mirror)/(−1)^sym
    stubs).
21. Lemma A.4.2's cone bound uses the full τ-strength |Y| ≤ ξ/(KR⁴).
