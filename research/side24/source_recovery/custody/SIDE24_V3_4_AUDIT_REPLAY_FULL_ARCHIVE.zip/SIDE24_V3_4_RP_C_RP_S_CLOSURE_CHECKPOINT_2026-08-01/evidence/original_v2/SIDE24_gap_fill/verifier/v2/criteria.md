# Verifier v2 — criteria (2026-08-01)

Supersedes v1. Changes vs v1: five transcripts required (adds
first_variation_derivation); residual-premise budget tightened (the two boxed
RESIDUAL PREMISES of items 6 and 7 must be gone; only the item-12 paywalled
flag may remain); new v2 package snapshot checks.

## Checks

1. Supplement exists and references all 12 register items.
2. Register reconciliation table present with all 12 rows.
3. Five script transcripts exist and each ends with ALL_ASSERTIONS_PASS:
   arithmetic_ledgers, contact_covariance_verification,
   triple_contact_elimination, goe_cone_coefficient, first_variation_derivation.
4. Item-6 boxed RESIDUAL PREMISE removed; replacement disposition present
   (B.1 + G6′ envelope).
5. Item-7 boxed RESIDUAL PREMISE removed; first-variation closure present
   (pure partials, P₃(L) exact recovery, scale check 3/2).
6. No boxed RESIDUAL PREMISE remains; the item-12 paywalled-pass flag is
   still present (historical mentions of the former premises are fine).
7. Corrected Fourier prefactor display present: (2π)^{3/2}24^{−3}.
8. Density-convention paragraph present (item 11).
9. v2 snapshot exists: SIDE24_v2_2026-08-01/CHANGE_LOG.md,
   GAP_REGISTER_V2.md, MANUSCRIPT_V2_INTEGRATION.md.
10. GAP_REGISTER_V2.md marks all 12 items CLOSED.
11. MANUSCRIPT_V2_INTEGRATION.md references all 12 register items.
12. CHANGE_LOG.md preserves the 2026-07-31 baseline entry (no overwrite).
13. first_variation_derivation transcript contains P_3(24) = -620813376/35
    and the 3/2 scale check.
14. Verifier run records exist under verifier/runs/ and README.md indexes
    both v1 and v2.
