# SIDE24 — Change Log

Package protocol (00_READ_ME_FIRST, Step 15): historical sent snapshots are
never overwritten; every correction ships as a new dated snapshot with this
log. This file indexes all snapshots.

## SIDE24-PRE-REVIEW-2026-07-31 (frozen baseline)

- Original pre-peer-review package (author Dylan Roy). 12-item proof-gap and
  correction register in `02_PRE_REVIEW_DOSSIER.pdf` §12. Status at freeze:
  items 1–12 open as documented; coefficient-bound transcript mismatch
  disclosed in `05_REPRODUCTION_GUIDE.pdf` §9.

## SIDE24-V2-2026-08-01 (this snapshot)

All twelve register items closed. No change to the theorem statement, the
exponent −1/3, the constant c₃,∞, or the correction magnitude
−(620813376/35)e^(−288); |ε₂₄| < 10⁻¹⁸⁰ unaffected.

| Register item | Repair | Source of repair |
|---|---|---|
| 1 Off-diagonal elder pairs | Proposition A.3.2 (O(ℓ) bound) | supplement Part A |
| 2 Exact near pushforward | Proposition A.3.1 + Theorem A.3.3 (DCT hypotheses explicit) | supplement Part A |
| 3 Palm law / elder mark | Definitions (A.1)–(A.3); Lemma A.1.3 (measurability via connection level) | supplement Part A |
| 4 Elder-selection trichotomy | Lemma A.2.1 (exhaustive, named events) | supplement Part A |
| 5 Capture/escape | Theorem A.4.6; Lemma A.4.4 (inward tube); all margins re-verified in exact arithmetic | supplement Part A + scripts/arithmetic_ledgers.py |
| 6 Triple-contact elimination | Exact elimination displayed as (B.1); LS-DER-024 citation **replaced** by (B.1) + G6′ envelope (Module B §6); load-bearing estimates unaffected | supplement Part B.1 + scripts/triple_contact_elimination.py, contact_covariance_verification.py |
| 7 Cone / first-variation constants | All constants exact/symbolic: cone law and jet objects derived; **D₂ = 29/6 − √6 proved in closed form** via the trace/difference reduction (B.2′) — T ~ N(0,4) independent of D, det Q and the cone condition functions of the single Gaussian W = T + 2sZ ~ N(0,20/3), elementary half-line integrals I₁, I₃, I₅; δa, δm₄, δχ, the full δ log c chain-rule and P₃(L) derived exactly (λ-scale check 3/2). Numerics (quadrature 1.2×10⁻⁸, Monte Carlo 4×10⁻⁴) retained as cross-checks only | supplement Part B.2 + scripts/goe_cone_coefficient.py, first_variation_derivation.py, d2_closed_form.py |
| 8 Fourier prefactor | Display corrected to a_m = (2π)^{3/2}24^{−3}e^{−2π²|m|²/24²}; positivity conclusions unaffected | supplement Part C.1 |
| 9 Module E hypotheses | Jet ball B (radius 10⁻¹¹⁰) and standing hypotheses restored | supplement Part C.2 |
| 10 Module K notation | Generic symbols defined; consistency with σ_t² = 1/24 checked | supplement Part C.3 |
| 11 Density convention | Insert paragraph supplied | supplement Part C.4 |
| 12 Literature novelty | Systematic web-level search (2026-08-01): no conflicting theorem; paywalled MathSciNet/zbMATH pass remains as an ordinary editorial task | supplement Part D |

Reproducibility repairs: coefficient-bound transcript mismatch resolved
(replacement ledger prints both scales); environment recorded (Python 3.12,
SymPy 1.14, mpmath, NumPy/SciPy); six verification scripts each print
ALL_ASSERTIONS_PASS with transcripts in SIDE24_gap_fill/scripts/*.out.txt.

Internal verification: verifier v1 (20/20 PASS) and v2 (see
SIDE24_gap_fill/verifier/, run logs under verifier/runs/). Internal status
labels are not proof evidence (per package protocol).

## Addendum (2026-08-01, final round)

Three further passes over the supplement, then full v2 document generation.

Pass 1 (Part A.4 constants, independent recomputation): repaired the A.4.2
cone-bound display (invalid for R > K/16; now uses the full-strength
|Y| ≤ ξ/(KR⁴)) and replaced a placeholder flux display with the complete
four-bracket derivation (the r-term uses the vanishing of ∇Q at S).

Pass 2 (recombination scalars, cross-checks): repaired display (A.7), which
omitted the r³/6 gap Jacobian its own proof cited (r-power inconsistency with
G_r = r⁴K and the 6^{2/3}/18 scalar); added an independent 4×10⁶-draw Monte
Carlo corroboration of the exact D₂.

Pass 3 (document sweep, fresh suite): constant consistency sweep; all six
scripts re-run clean (ALL_ASSERTIONS_PASS); verifier v4 created, 21/21 PASS.

v2 document editions generated: 00, 01, 02, 03, 04, 05, 07 (docx), 09
(manifest with SHA-256), 11 (merged packet). Manuscript/appendix v2 are
"amended editions": front matter plus self-contained replacement passages
keyed to frozen-edition locations, with proofs carried by the supplement.
