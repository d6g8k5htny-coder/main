# Verifier index

- v1 (created 2026-08-01): checks coverage of all 12 dossier register items, re-execution of all four script suites with ALL_ASSERTIONS_PASS, honest RESIDUAL PREMISE labeling, Fourier prefactor repair, first-moment intensity convention. First version.

## v2 (2026-08-01)

- `v2/criteria.md`, `v2/verify.py` — 14 checks. Supersedes v1: five transcripts required (adds first_variation_derivation); no boxed RESIDUAL PREMISE may remain (items 6 and 7 closed; only the item-12 paywalled flag persists); new v2 package snapshot checks (SIDE24_v2_2026-08-01 change log, register v2, integration sheet).
- Runs: see `runs/2026-08-01_run2.md`.

### Run 3 (2026-08-01, v2)

Precision pass: claim taxonomy added; D₂ reworded from "derived" to "numerically confirmed (1.2×10⁻⁸, two methods)"; B.1 mirror formula made exact; register disclosures updated. 14/14 PASS. See `runs/2026-08-01_run3.md`.

## v3 (2026-08-01)

- `v3/criteria.md`, `v3/verify.py` — 18 checks. Supersedes v2: six transcripts (adds d2_closed_form, the exact closed-form proof of D₂ = 29/6 − √6); D₂ must be claimed exact, not numerically confirmed; new checks for the repaired Lemma A.4.4 budget (δ₀ = 1/(512R⁴), machine-verified in arithmetic_ledgers) and the Lemma A.2.1 Case-2 witness y = M₂.
- Runs: see `runs/2026-08-01_run4.md`.

## v4 (2026-08-01)

- `v4/criteria.md`, `v4/verify.py` — 21 checks. Supersedes v3: adds the (A.7) gap-Jacobian consistency check, a no-placeholder-display check, and the A.4.2 full-strength cone-bound check.
- Runs: see `runs/2026-08-01_run5.md`.
