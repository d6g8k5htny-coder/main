#!/usr/bin/env python3
"""Verifier v2 for the SIDE24 gap-fill project. Prints PASS/FAIL per check."""
import os, re, sys

ROOT = "/mnt/agents/output"
GF = os.path.join(ROOT, "SIDE24_gap_fill")
SUPP = os.path.join(GF, "SIDE24_GAP_FILL_SUPPLEMENT.md")
V2 = os.path.join(ROOT, "SIDE24_v2_2026-08-01")
SCR = os.path.join(GF, "scripts")

results = []
def check(name, ok):
    results.append((name, bool(ok)))
    print(f"[{'PASS' if ok else 'FAIL'}] {name}")

supp = open(SUPP, encoding="utf-8").read() if os.path.exists(SUPP) else ""

# 1: supplement references all 12 items
check("1 supplement references all 12 register items",
      all(re.search(rf"(Gap item|Gap)\s+{i}\b|item {i}\b|\| {i} \|", supp) for i in range(1, 13)))

# 2: reconciliation table, 12 rows
rows = re.findall(r"^\| (\d+) \|", supp, re.M)
check("2 reconciliation table has 12 rows", sorted(set(int(r) for r in rows)) == list(range(1, 13)))

# 3: five transcripts pass
scripts = ["arithmetic_ledgers", "contact_covariance_verification",
           "triple_contact_elimination", "goe_cone_coefficient",
           "first_variation_derivation", "d2_closed_form"]
ok3 = True
for s in scripts:
    p = os.path.join(SCR, s + ".out.txt")
    if not (os.path.exists(p) and "ALL_ASSERTIONS_PASS" in open(p).read()):
        ok3 = False
        print(f"    missing/failing transcript: {s}")
check("3 six transcripts contain ALL_ASSERTIONS_PASS", ok3)

# 4: item-6 premise resolved by replacement
check("4 item 6 resolved by replacement (B.1 + G6 envelope)",
      "RESOLVED BY REPLACEMENT (Gap item 6)" in supp and "G6" in supp)

# 5: item-7 premise closed
check("5 item 7 closed (first-variation derivation)",
      "residual closed" in supp and "partial_{m_4}" in supp.replace("\\", "") or
      ("residual closed" in supp and "P_3(L)" in supp and "3/2" in supp))

# 6: no boxed RESIDUAL PREMISE remains; only the item-12 paywalled flag
n_boxed = len(re.findall(r"> \*\*RESIDUAL PREMISE", supp))
check("6 no boxed RESIDUAL PREMISE remains; item-12 paywalled flag present",
      n_boxed == 0 and "RESIDUAL PREMISE: paywalled" in supp)

# 7: Fourier prefactor
check("7 corrected Fourier prefactor present", "(2\\pi)^{3/2}" in supp and "24^{-3}" in supp)

# 8: density convention
check("8 density-convention paragraph present", "density" in supp.lower() and "C.4" in supp)

# 9: v2 snapshot files exist
files = ["CHANGE_LOG.md", "GAP_REGISTER_V2.md", "MANUSCRIPT_V2_INTEGRATION.md"]
check("9 v2 snapshot files exist", all(os.path.exists(os.path.join(V2, f)) for f in files))

# 10: register v2 all closed
reg = open(os.path.join(V2, "GAP_REGISTER_V2.md"), encoding="utf-8").read() if os.path.exists(os.path.join(V2, "GAP_REGISTER_V2.md")) else ""
closed = re.findall(r"^\| \d+ \|[^|]*\| CLOSED", reg, re.M)
check("10 GAP_REGISTER_V2 marks all 12 items CLOSED", len(closed) == 12)

# 11: integration sheet references all 12 items
integ = open(os.path.join(V2, "MANUSCRIPT_V2_INTEGRATION.md"), encoding="utf-8").read() if os.path.exists(os.path.join(V2, "MANUSCRIPT_V2_INTEGRATION.md")) else ""
check("11 integration sheet references all 12 gap items",
      all(f"gap item {i}" in integ for i in range(1, 13)))

# 12: change log preserves baseline
cl = open(os.path.join(V2, "CHANGE_LOG.md"), encoding="utf-8").read() if os.path.exists(os.path.join(V2, "CHANGE_LOG.md")) else ""
check("12 change log preserves 2026-07-31 baseline", "SIDE24-PRE-REVIEW-2026-07-31" in cl)

# 13: first-variation transcript content
fv = open(os.path.join(SCR, "first_variation_derivation.out.txt")).read() if os.path.exists(os.path.join(SCR, "first_variation_derivation.out.txt")) else ""
check("13 first-variation transcript: P_3(24) and 3/2 scale check",
      "620813376" in fv and "3/2" in fv)

# 14: runs + README index
runs = os.listdir(os.path.join(GF, "verifier", "runs")) if os.path.isdir(os.path.join(GF, "verifier", "runs")) else []
readme = open(os.path.join(GF, "verifier", "README.md")).read() if os.path.exists(os.path.join(GF, "verifier", "README.md")) else ""
check("14 run records exist and README indexes v1, v2, v3",
      len(runs) >= 1 and all(f"v{i}" in readme for i in (1,2,3)))

# 15: d2 transcript
d2 = open(os.path.join(SCR, "d2_closed_form.out.txt")).read() if os.path.exists(os.path.join(SCR, "d2_closed_form.out.txt")) else ""
check("15 d2 transcript: exact D2 and I1/I3/I5",
      "D_2 = 29/6 - sqrt(6)" in d2 and "I1 =" in d2 and "I3 =" in d2 and "I5 =" in d2)

# 16: supplement claims D2 exact, not merely numerical
supp_flat = re.sub(r"\s+", " ", supp)
check("16 supplement: D2 exact (B.2') claimed",
      "B.2" in supp and "exactly" in supp and "Closed-form evaluation (exact" in supp
      and "is now exact/symbolic" in supp_flat)

# 17: A.4.4 budget in ledger transcript
al = open(os.path.join(SCR, "arithmetic_ledgers.out.txt")).read() if os.path.exists(os.path.join(SCR, "arithmetic_ledgers.out.txt")) else ""
check("17 ledger transcript: A.4.4 budget lines",
      "A44_LATERAL_ADVERSE_RATIO" in al and "A44_FX_ADVERSE_IN_TUBE" in al)

# 18: repaired delta_0 and Case-2 witness
check("18 supplement: delta_0 = 1/(512R^4) and witness y = M_2",
      "512R^4" in supp and "y=M_2" in supp)

n = sum(1 for _, ok in results if ok)
print(f"\n{n}/{len(results)} PASS")
sys.exit(0 if n == len(results) else 1)
