#!/usr/bin/env python3
"""Verifier v1 for the SIDE24 gap-fill supplement. See criteria.md."""
import re, subprocess, sys, pathlib

base = pathlib.Path(__file__).resolve().parents[2]
sup = (base/"SIDE24_GAP_FILL_SUPPLEMENT.md").read_text()
ok = True
def check(name, cond):
    global ok
    print(("PASS" if cond else "FAIL"), name)
    ok = ok and cond

# 1. all 12 register items addressed
for k in range(1, 13):
    check(f"gap item {k} referenced", f"Gap item {k}" in sup or f"Gap items {k}" in sup
          or re.search(rf"Gap items? \d+(–|-)\d+", sup) and any(f"Gap item {k}" in sup or f"Gap items {k}" in sup for _ in [0]))
# explicit: items appear in the reconciliation table too
check("reconciliation table has 12 rows", sup.count("| Proved") + sup.count("CLOSED") >= 12)

# 2. scripts run and pass
for s in ["arithmetic_ledgers", "contact_covariance_verification",
          "triple_contact_elimination", "goe_cone_coefficient"]:
    out = base/"scripts"/f"{s}.out.txt"
    check(f"{s} transcript passes", out.exists() and "ALL_ASSERTIONS_PASS" in out.read_text())

# 3. honesty: residual premises labeled
check("RESIDUAL PREMISE labels present", sup.count("RESIDUAL PREMISE") >= 2)

# 4. Fourier prefactor
check("Fourier prefactor (2pi)^(3/2)/24^3", "(2\\pi)^{3/2}}{24^3" in sup or "(2π)^{3/2}/24" in sup or "24^3 Z_{24}" in sup)

# 5. density convention
check("first-moment intensity convention stated", "first-moment intensity density per unit" in sup)

sys.exit(0 if ok else 1)
