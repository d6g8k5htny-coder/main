# Side-24 gap-fill supplement

**Companion to SIDE24-PRE-REVIEW-2026-07-31**
Prepared 2026-08-01. Addresses all twelve items of the proof-gap and correction
register in `02_PRE_REVIEW_DOSSIER.pdf` §12, in register order.

**Conventions.** All notation is that of the manuscript (`03_SIDE24_MANUSCRIPT.pdf`)
and dossier. $f=f_{24}$ is the normalized side-24 periodized Bargmann–Fock field on
$\mathbb{T}^3_{24}$, $M=x-\frac r2 t$, $S=x+\frac r2 t$, the pins are
$f(M)=b$, $f(S)=b-\kappa r^3/6$, $\nabla f(M)=\nabla f(S)=0$, and $W_r =
|\det H_M|\,|\det H_S|\,\mathbf 1_{\{H_M\prec 0,\ \mathrm{ind}(H_S)=2\}}$.
Throughout, "Gap item $k$" refers to row $k$ of the register.

**Status labels.** Each section ends with a status line. Where a full proof is
given, the item is marked CLOSED (subject to the same independent review as the
rest of the package). Where something remains assumed, the exact assumption is
boxed as a RESIDUAL PREMISE — nothing is silently closed.

**Claim taxonomy (precision convention).** Every quantitative claim in this
supplement is one of the following, and the text says which:
(i) **exact/symbolic** — proved or verified by exact symbolic computation
(SymPy/Fraction). This covers every quantitative constant in the supplement:
the covariances, the elimination (B.1), the cone constant $D_2$ (closed form,
B.2), the first-variation variations and $P_3(24)=-620813376/35$, the energy
margins;
(ii) **numerical cross-check** — independent numerical evaluations retained
only as corroboration of category-(i) results, never load-bearing;
(iii) **flagged task** — the paywalled-database literature pass (item 12).
The word "derived" is used only for category (i); numerical agreement is never
called a derivation.

---

## Part A — Formal statements and proofs (Gap items 1–5)

### A.1 Gap item 3 (done first: it is the interface the others use).
**The determinant-weighted Palm law and Borel measurability of the elder mark.**

**Definition A.1.1 (pins and weight).** For $0<r<12$, $t\in S^2$, $b\in\mathbb R$,
$\kappa>0$, let $\Pi_{r,x,t}=(f(M),f(S),\nabla f(M),\nabla f(S))$ and
$z_r(b,\kappa)=(b,\,b-\kappa r^3/6,\,0,\,0)$. The conditional law
$\mathbb E^0_{r,t,b,\kappa}[\cdot]=\mathbb E[\cdot\mid \Pi_{r,x,t}=z_r(b,\kappa)]$
is the regular conditional Gaussian distribution (it exists: the pin vector is
Gaussian; the corrected-pin covariance is nondegenerate by Module F, so the
conditional distributions have a continuous version in $(r,t,b,\kappa)$).
Put $Z_r(t,b,\kappa)=\mathbb E^0_{r,t,b,\kappa}[W_r]$. By Module H (G2),
$c_Z r^2\le Z_r\le C_Z r^2$ on compact positive mark sets, in particular
$Z_r>0$. The **all-typed determinant-weighted Palm law** is
$$\mathbb E^{MS}_{r,t,b,\kappa}[F]=\frac{\mathbb E^0_{r,t,b,\kappa}[W_r F]}{Z_r(t,b,\kappa)}. \tag{A.1}$$

**Definition A.1.2 (elder mark, constructed measurably).** Let
$\Omega_{\mathrm{Mo}}$ be the event that $f$ is Morse with pairwise distinct
critical values ($\mathbb P(\Omega_{\mathrm{Mo}})=1$, Proposition 1.1). For a
continuous $g:\mathbb T^3_{24}\to\mathbb R$ and $u,v\in\mathbb T^3_{24}$ define
the **connection level**
$$\mathfrak m_g(u,v)=\sup_{\gamma:u\to v}\min_{s\in[0,1]} g(\gamma(s)),$$
the supremum over continuous paths. Then
$|\mathfrak m_g(u,v)-\mathfrak m_{g'}(u,v)|\le \|g-g'\|_\infty$, so
$(g,u,v)\mapsto\mathfrak m_g(u,v)$ is continuous, hence Borel, on
$C(\mathbb T^3_{24})\times(\mathbb T^3_{24})^2$. Fix a countable dense set
$D\subset\mathbb T^3_{24}$ and define the **birth level of the component of $u$
above height $a$**,
$$\mathfrak b_g(u,a)=\sup_{z\in D}\, g(z)\,\mathbf 1_{\{\mathfrak m_g(u,z)\ge a\}},$$
a countable supremum of Borel functions, hence Borel in $(g,u,a)$. Since
$\{\mathfrak m_g(u,\cdot)\ge a\}$ is the closed superlevel component of $u$ and
$g$ is continuous, the supremum over $D$ equals the maximum of $g$ on that
component; on $\Omega_{\mathrm{Mo}}$ that maximum is attained at the unique
birth maximum of the component.

At an index-two saddle $S$ with $h=f(S)$, the unstable line is the positive
eigenline of the axial Hessian direction. Choose a measurable unit vector
$v(S)$ spanning it (possible: the eigenline is unique and varies measurably on
the nondegenerate locus; any Borel measurable selection works, and what follows
is independent of the choice of sign). Fix once and for all a small $\delta>0$
below the injectivity scale of the Morse local normal form and set
$u_\pm(S)=S\pm\delta\,v(S)$. On $\Omega_{\mathrm{Mo}}$, the two points lie one
in each upper local sector of $S$. Define
$$e(f;M,S)=\mathbf 1\big\{\mathfrak m_f(u_+,u_-)<h\ \text{and}\ f(M)=\min\big(\mathfrak b_f(u_+,h),\,\mathfrak b_f(u_-,h)\big)\big\}. \tag{A.2}$$

**Lemma A.1.3 (the mark is correct and Borel).** On $\Omega_{\mathrm{Mo}}$,
$e(f;M,S)=1$ if and only if (i) the two upper sectors of $S$ lie in distinct
superlevel components immediately above $h$; (ii) $M$ is the birth maximum of
one of them; (iii) the birth value at $M$ is the smaller of the two — exactly
the elder-pair condition of dossier §6. Moreover
$(f,M,S)\mapsto e(f;M,S)$ is Borel measurable on the Morse locus.

**Proof.** Two points are in the same component of $\{f>h\}$ iff
$\mathfrak m_f(u_+,u_-)>h$; equality $\mathfrak m=h$ would force a degenerate
or shared critical value, excluded on $\Omega_{\mathrm{Mo}}$. Hence (i) is
$\{\mathfrak m_f(u_+,u_-)<h\}$. By construction of $\mathfrak b$, on
$\Omega_{\mathrm{Mo}}$ the numbers $\mathfrak b_f(u_\pm,h)$ are the birth
values of the two sector components; since critical values are distinct,
$f(M)=\mathfrak b_f(u_\pm,h)$ identifies the birth maximum uniquely. So (A.2)
is equivalent to (i)–(iii). Measurability: $\mathfrak m$ and $\mathfrak b$ are
Borel as shown; $v(S)$ is a measurable selection; $h=f(S)$ and $f(M)$ are
evaluations. $\blacksquare$

**Definition A.1.4 (selection probability).**
$p_r(t,b,\kappa)=\mathbb E^{MS}_{r,t,b,\kappa}[e(f;M,S)]$, so that with
$K^{\mathrm{all}}_r=p_{\Pi}(z_r(b,\kappa))\,\mathbb E^0[W_r]$,
$$K^{\mathrm{sel}}_r(t,b,\kappa)=p_r(t,b,\kappa)\,K^{\mathrm{all}}_r(t,b,\kappa). \tag{A.3}$$

**Status: CLOSED.** The measurability repair requested by the register and by
hostile-review Q7 is supplied by Lemma A.1.3; the Palm law is defined in one
place ((A.1)–(A.3)), with neither adjacency nor selection in the base law.

---

### A.2 Gap item 4. **The elder-selection trichotomy as a formal lemma.**

**Setup.** On $\Omega_{\mathrm{Mo}}$, fix an ordered typed pair $(M,S)$ at
distance $r$, and let $h=f(S)$, $b=f(M)$. Define events:

* $A_r$ (adjacency): at least one unstable half-branch of $S$ under gradient
  ascent converges to $M$. (Boolean mark; if both do, the pair still counts
  once — Module L §5.)
* $E_r=\{e(f;M,S)=1\}$ (actual elder selection, (A.2)).
* $L_{\mathrm{same},r}$ (same-component self-attachment): the two upper
  sectors of $S$ coincide, $\mathfrak m_f(u_+,u_-)>h$.
* $B_r$ (third-critical witness): there exists a critical point
  $y\notin\{M,S\}$ of $f$ with $f(y)\in[h,b]$ (value in the pair window),
  lying in exactly one of the regions
  (i) collar: $\operatorname{dist}(y,\{M,S\})\le C_1 r$;
  (ii) singular-near: $C_1 r<\operatorname{dist}(y,x)\le \delta$, where $x$ is
  the pair midpoint (so $\eta=r/s\le 1/C_1<1$, a compact $\eta$-chart);
  (iii) fixed-distance: $\operatorname{dist}(y,\{M,S\})\ge\delta$.
  Here $C_1,\delta>0$ are fixed constants of the chart decomposition.

**Lemma A.2.1 (exhaustive trichotomy).** On $\Omega_{\mathrm{Mo}}$,
$$A_r\cap E_r^{c}\subset B_r\cup L_{\mathrm{same},r}. \tag{A.4}$$

**Proof.** Work on $A_r$: a half-branch of $S$ ascends to $M$, so $M$ is a
maximum of the upper-sector component it lies in; call the sectors
$C_1\ni M$-ward and $C_2$. If $C_1=C_2$ we are in $L_{\mathrm{same},r}$.
Assume $C_1\ne C_2$ with birth values $b_1,b_2$ and birth maxima $M_1,M_2$
(distinct values make them unique).

*Case 1: $M\ne M_1$.* Then $M_1$ and $M$ are distinct maxima in one component
of $\{f>h\}$. Any path in that component from $M$ to $M_1$ has minimum $>h$;
following the component's merge tree downward from $\min(b_1,f(M))$, the two
sub-components containing $M_1$ and $M$ first merge at an index-two saddle $S'$
with $h<f(S')\le f(M)=b$. (Existence: a Morse component of a superlevel set
containing two distinct local maxima contains an index-$(d-1)$ merge saddle on
every connecting route; take the highest threshold at which they disconnect.)
Then $y=S'$ is a critical point with $f(y)\in(h,b]$, a window witness.

*Case 2: $M=M_1$ but $e=0$.* Since $C_1\ne C_2$ and (ii) of (A.2) holds,
failure of (A.2) forces $f(M)>\min(b_1,b_2)$, i.e. $b_2<f(M)$: $C_2$ is
younger and is the component killed at $S$. The required witness is $C_2$'s
own birth maximum: $y=M_2$ is a critical point (a local maximum), its value
satisfies $h<b_2=f(M_2)<f(M)=b$ — the lower bound because $C_2$ is a
component of the *open* superlevel set $\{f>h\}$ containing an upper sector
of $S$, so its birth value exceeds $h$ — and $M_2\notin\{M,S\}$ ($M_2\ne M$
as they lie in distinct components; $M_2\ne S$ as $f(S)=h<b_2$). So $y=M_2$
is a window witness. (Note the merge saddle of $M$'s surviving class would
not serve here: its value can lie below $h$, outside the window.)

In both cases $y$ is a critical point with value in the pair window; the
spatial partition (i)–(iii) places it in $B_r$. $\blacksquare$

**Corollary A.2.2 (selection bound).** With the Palm law (A.1),
$$1-p_r\le \mathbb P^{MS}_r(A_r^c)+\mathbb P^{MS}_r(B_r)+\mathbb P^{MS}_r(L_{\mathrm{same},r}),$$
and the three terms are $O(r^3)$, $O(r^3)$, $O(r^3)$ respectively by:
$\mathbb P^{MS}(B_r)\le \mathbb E^{MS}N_{\mathrm{col}}+\mathbb E^{MS}N_{\mathrm{sing}}+\mathbb E^{MS}N_{\mathrm{far}}$
(Markov; the three regional expectations are $O(r^3)$ by Module B §§3–6 /
Module E / Module I §3), and the adjacency and self-attachment failures are
$O(r^3)$ by Module I §4 together with the consolidated capture/escape theorem
of Section A.4 below. Hence, uniformly on compact positive $(b,\kappa)$ sets,
$$1-p_r(t,b,\kappa)\le C_{\mathrm{sel}}\,r^3. \tag{A.5}$$

**Status: CLOSED** (the compressed paragraph of the manuscript §3.4 is replaced
by Lemma A.2.1; the region partition (i)–(iii) is a spatial trichotomy, so no
failure mode is unclassified, answering hostile-review Q6).

---

### A.3 Gap items 1 and 2. **The near/far decomposition, the exact near-density
pushforward, and the off-diagonal lemma.**

Fix $0<\rho<12$ and split the expected lifetime measure of Proposition 1.2 as
$$\nu_{3,24}(\ell)=\nu^{\mathrm{near}}_\rho(\ell)+\nu^{\mathrm{far}}_\rho(\ell), \tag{A.6}$$
according as the elder pair's own separation is $<\rho$ or $\ge\rho$.

**Proposition A.3.1 (exact near-density pushforward; Gap item 2).** Let
$K^{\mathrm{sel}}_r$ be as in (A.3) and $r_\ell(\kappa)=(6\ell/\kappa)^{1/3}$.
For every nonnegative test function $\varphi$,
$$\int_0^\infty\varphi(\ell)\,\nu^{\mathrm{near}}_\rho(\ell)\,d\ell
=\int_{S^2}\!\!\int_{\mathbb R}\!\!\int_0^\infty\!\!\int_0^\rho
\varphi\Big(\frac{\kappa r^3}{6}\Big)K^{\mathrm{sel}}_r(t,b,\kappa)\,\frac{r^3}{6}\,r^2\,dr\,d\kappa\,db\,d\sigma_2(t), \tag{A.7}$$
(the factor $r^3/6$ is the affine gap change $|dh|=(r^3/6)\,d\kappa$, included
in the display explicitly)
and the exact density representative is
$$\nu^{\mathrm{near}}_\rho(\ell)=\frac{6^{2/3}}{18}\,\ell^{-1/3}\int_{S^2}\int_{\mathbb R}\int_{6\ell/\rho^3}^{\infty}
\kappa^{-2/3}\,G^{\mathrm{sel}}_{r_\ell(\kappa)}(t,b,\kappa)\,d\kappa\,db\,d\sigma_2(t), \tag{A.8}$$
where $G^{\mathrm{sel}}_r=r^4 K^{\mathrm{sel}}_r$ (dimension three).

**Proof.** Marked two-point Kac–Rice for the ordered typed pair process with
the bounded Borel mark $e$ (Lemma A.1.3) on $\{r<\rho\}$, the midpoint/polar
change of variables $dM\,dS=dx\,r^2dr\,d\sigma_2$ (Module L, $|\det|=1$), the
per-volume normalization $24^{-3}\int dx=1$, and the affine gap change
$|dh|=(r^3/6)\,d\kappa$ give (A.7). Writing
$K\,r^5/6=(r^4K)\cdot r/6=G^{\mathrm{sel}}_r\,r/6$ and substituting
$r=r_\ell(\kappa)$, $r\,dr=\frac{6^{2/3}}{3}\kappa^{-2/3}\ell^{-1/3}d\ell$
(Module K, exact), the scalar $(1/6)\cdot(6^{2/3}/3)=6^{2/3}/18$ gives (A.8);
the lower limit $r<\rho$ becomes $\kappa>6\ell/\rho^3$. $\blacksquare$

**Proposition A.3.2 (off-diagonal lemma; Gap item 1).** For each finite
$\ell_0$,
$$\sup_{0<\ell\le\ell_0}\nu^{\mathrm{far}}_\rho(\ell)<\infty; \qquad
\text{in fact }\ \nu^{\mathrm{far}}_\rho(\ell)\le C_\rho\,\ell\ \ \text{for }\ell\le\ell_0. \tag{A.9}$$
Hence $\nu^{\mathrm{far}}_\rho(\ell)=o(\ell^{-1/3})$ as $\ell\downarrow0$.

**Proof.** Since the elder mark satisfies $e\le 1$, $\nu^{\mathrm{far}}_\rho$ is
bounded above by the *all-typed* ordered pair intensity with lifetime window
of width $\ell$: writing $\Xi_{x,y}=(f(x),f(y),\nabla f(x),\nabla f(y))$,
$$\nu^{\mathrm{far}}_\rho(\ell)\le 24^{-3}\!\!\int_{D_\rho}\int_{\mathbb R}
p_{\Xi_{x,y}}(b,b-\ell,0,0)\;\mathbb E\big[|\det H_x\det H_y|\,\mathbf 1_{\mathrm{types}}\,\big|\,\Xi_{x,y}=(b,b-\ell,0,0)\big]\,db\,dx\,dy,$$
where $D_\rho=\{(x,y):\operatorname{dist}(x,y)\ge\rho\}$. This is marked
two-point Kac–Rice on a compact separated configuration set: the full positive
Fourier support (Module F, Theorem 3.1 and Corollary 3.2) makes $\Xi_{x,y}$
uniformly nondegenerate on $D_\rho$, so
$p_{\Xi}(b,b-\ell,0,0)\le C_\rho e^{-c_\rho b^2}$ uniformly in
$0<\ell\le\ell_0$ (the smallest eigenvalue of $\operatorname{Cov}\Xi$ is
bounded below and the mean-zero target has $\|(\!b,b-\ell,0,0)\|^2\ge
b^2/2$ for $\ell$ bounded). Gaussian regression against this nondegenerate
block gives conditional Hessian means affine in $(b,b-\ell)$ and uniformly
bounded conditional covariances, so by the degree-six moment bound
$$\mathbb E[|\det H_x\det H_y|\mid\Xi]\le C_\rho\big(1+(|b|+\ell)^6\big).$$
Integrating, the $\ell$-window contributes its exact width $\ell$ (the map
$h\mapsto \ell=b-h$ is a translation; for the density at fixed $\ell$ the
window is the single slice — the $O(\ell)$ form follows by integrating the
test function against a window of width $\Delta\ell$ and dividing). Hence
$$\nu^{\mathrm{far}}_\rho(\ell)\le C_\rho\!\int_{\mathbb R}\big(1+(|b|+\ell_0)^6\big)e^{-c_\rho b^2}\,db\cdot\ell\le C_\rho'\,\ell,$$
the volume of $D_\rho$ being finite. $\blacksquare$

**Theorem A.3.3 (asymptotic; Gap item 2 completed).** Suppose
(H1) $G^{\mathrm{sel}}_r\to G^{\mathrm{sel}}_0$ pointwise on the mark space;
(H2) one integrable majorant for $\kappa^{-2/3}G^{\mathrm{sel}}_r$ on
$S^2\times\mathbb R\times(0,\infty)$, uniform as $\kappa\downarrow0$;
(H3) $\lim G^{\mathrm{sel}}_0=\lim G^{\mathrm{all}}_0$ (selected and all-typed
limiting integrands coincide).
Then $\nu_{3,24}(\ell)=c_{3,24}\ell^{-1/3}(1+o(1))$ with
$c_{3,24}=\frac{6^{2/3}}{18}\int\kappa^{-2/3}G^{\mathrm{all}}_0$.

**Proof.** (A.8) + dominated convergence using (H1)–(H2), with the lower
$\kappa$-limit $6\ell/\rho^3\downarrow0$; (H3) identifies the constant;
Proposition A.3.2 removes $\nu^{\mathrm{far}}_\rho$. The hypotheses hold for
the side-24 field: (H1) by the corrected-pin convergence (Module A) and
$p_r\to1$ ((A.5)); (H2) is the all-mark majorant
$C[1+(|b|+\kappa)^N]e^{-c(b^2+\kappa^2)}\kappa^{-2/3}$ of Module H §6 /
Module I (25), integrable including $\kappa\downarrow0$ (answering hostile
Q3: the $\kappa^{-2/3}$ singularity is integrable at $0$ and the Gaussian in
$\kappa$ excludes higher-contact double scaling on compact $\kappa$ sets;
quartic contacts have $\kappa=0$, a measure-zero mark set with no
$|\det|$-weighted mass); (H3) follows from $0\le p_r\le1$, $p_r\to1$, and the
same majorant. $\blacksquare$

**Status: CLOSED.** The global formula is now a named proved statement
(Proposition A.3.1), the DCT hypotheses are isolated and each is discharged,
and the off-diagonal lemma is proved (Proposition A.3.2, answering hostile
Q10).

---

### A.4 Gap item 5. **Consolidated capture/escape proof (no predecessor references).**

This section replaces Module J's reliance on "previously reviewed v1.2
estimates" with one self-contained statement and proof. Constants are chosen
for convenience; no attempt is made to match historical values.

**Normalized potential.** On the fixed compact convex chart $D^+$ consider, for
$X\in\mathbb R$, $Y\in\mathbb R^2$,
$$P(X,Y)=p_0(X)+\tfrac12(X^2-\tfrac14)a\!\cdot\! Y-\tfrac12 Y^{\!\top}TY+\tfrac12 X\,Y^{\!\top}WY+\tfrac16 C[Y,Y,Y]+r\,Q(X,Y), \tag{A.10}$$
$p_0(X)=X^3/3-X/4-1/12$, $T\succ0$ symmetric, $W$ symmetric, $C$ a symmetric
cubic tensor, $Q(M)=Q(S)=0$, $\nabla Q(M)=\nabla Q(S)=0$ at $M=(-\tfrac12,0)$,
$S=(\tfrac12,0)$. Put
$$R=1+|a|+\|W\|+\|C\|+\|Q\|_{C^2(D^+)}\ge1,\qquad \tau=\lambda_{\min}(T).$$
For the conditioned side-24 field, $T=-Q_\perp/(\kappa r)$ (Module I (12); the
factor $1/r$ is essential). Fix
$$K=4096,\qquad \varepsilon_0=\tfrac{1}{1024K},\qquad
\text{assume}\quad rR^5\le\varepsilon_0,\quad \tau\ge 2KR^5+2R. \tag{A.11}$$
Write $E(Y)=Y^{\!\top}TY$, $q(Y)=|TY|$; then $q^2\ge\tau E$ and
$|Y|^2\le E/\tau$. The gradient is
$$F_X=X^2-\tfrac14+Xa\!\cdot\!Y+\tfrac12Y^{\!\top}WY+rQ_X,\qquad
F_Y=\tfrac12(X^2-\tfrac14)a-TY+XWY+\tfrac12C[Y,Y,\cdot]+r\nabla_YQ. \tag{A.12}$$

**Lemma A.4.1 (endpoint energy slope).** The Jacobian at $S$ has block form
$J_S=\begin{pmatrix}A&B^{\!\top}\\ B&-T+E_D\end{pmatrix}$ with $A\ge3/4$,
$|B|\le R$, $\|E_D\|\le 3R/4$ (after one fixed small-$r$ reduction), and
exactly one positive eigenvalue. Its positive eigenvector $v=(v_X,v_Y)$
satisfies
$$E(v_Y)\le 4(R^2/\tau)|v_X|^2. \tag{A.13}$$

**Proof.** From $J_Sv=\lambda_+v$, the transverse block gives
$(\lambda_+I+T-E_D)v_Y=Bv_X$. Take the inner product with $v_Y$:
$$E(v_Y)=v_Y^{\!\top}Tv_Y\le |B|\,|v_X|\,|v_Y|+\|E_D\|\,|v_Y|^2
\le R\,|v_X|\,|v_Y|+\tfrac{3R}{4}|v_Y|^2,$$
using $\lambda_+>0$ and $v_Y^{\!\top}E_Dv_Y\le\|E_D\||v_Y|^2$. Apply Young's
inequality $R|v_X||v_Y|\le \tfrac{R^2}{\tau}|v_X|^2+\tfrac{\tau}{4}|v_Y|^2$
and the energy bound $|v_Y|^2\le E(v_Y)/\tau$:
$$E(v_Y)\le \tfrac{R^2}{\tau}|v_X|^2+\Big(\tfrac{\tau}{4}+\tfrac{3R}{4}\Big)|v_Y|^2
\le \tfrac{R^2}{\tau}|v_X|^2+\Big(\tfrac14+\tfrac{3}{8}\Big)E(v_Y),$$
where $\tau\ge 2R$ (from (A.11)) gives $\tfrac{3R}{4}\cdot\tfrac1\tau\le
\tfrac38$. Hence $\tfrac38 E(v_Y)\le\tfrac{R^2}{\tau}|v_X|^2$, i.e.
$E(v_Y)\le\tfrac83(R^2/\tau)|v_X|^2\le4(R^2/\tau)|v_X|^2$. The strict final
inequality leaves a fixed normalized margin, which persists under the exact
$C^1$ perturbation of Lemma A.4.5. $\blacksquare$

**Lemma A.4.2 (outward energy cone).** Let $\xi=X-\tfrac12$,
$\delta=1/(512R^3)$, and
$\mathcal C_E=\{0\le\xi\le\delta,\ E(Y)\le 4(R^2/\tau)\xi^2\}$. On $\mathcal C_E$:
$q\ge 2R\xi$ on the nonzero boundary, $|Y|\le \xi/K$, $F_X\ge 3\xi/4$, and
$G_E=E(Y)-4(R^2/\tau)\xi^2$ satisfies
$$\tfrac12\dot G_E\le -\tfrac23 q^2<0\quad\text{on }\{G_E=0\}. \tag{A.14}$$
Hence the outward half-branch stays in $\mathcal C_E$ until $\xi=\delta$.

**Proof.** On $G_E=0$, $E=4(R^2/\tau)\xi^2$ so
$q\ge\sqrt{\tau E}=2R\xi$ and $|Y|\le\sqrt{E/\tau}=2R\xi/\tau
\le \xi/(KR^4)$ (the full strength $\tau\ge2KR^5$ is used here, not merely
$\tau\ge2KR$ — this matters for the next bound when $R$ is large).
Then $|Xa\!\cdot\!Y|\le(\tfrac12+\delta)R|Y|\le(\tfrac12+\delta)\,\xi/(KR^3)
\le\xi/16$ (as $(\tfrac12+\delta)/(KR^3)\le 1/K\le 1/16$) and
$\tfrac12|Y^{\!\top}WY|\le \tfrac{R}{2}|Y|^2\le
\tfrac{R}{2}\cdot\tfrac{\xi^2}{K^2R^8}\le\tfrac{\xi}{16}\cdot
\tfrac{8\xi}{K^2R^7}\le\xi/16$ (as $8\xi\le 8\delta\le 1\le K^2R^7$) and
$|rQ_X|\le rR\le\varepsilon_0/R^4\le\xi/16$ (as $\xi\le\delta$ and
$\varepsilon_0$ small relative to $\delta$... precisely $rR\le \varepsilon_0
R^{-4}<3\delta/16$ since $\varepsilon_0 R^{-4}<3/(16\cdot512 R^3)$), while
$X^2-\tfrac14=\xi(1+\xi)\ge\xi$; so $F_X\ge\xi-3\xi/16-\text{(smaller)}\ge
3\xi/4$. For the flux,
$\tfrac12\dot G_E=(TY)\!\cdot\! F_Y-4(R^2/\tau)\xi F_X$; the moving-boundary
term is $\le0$ by $F_X\ge0$. In $(TY)\!\cdot\!F_Y$ the leading term is
$-q^2$. Dividing the four adverse terms by $q^2$, using
$q\ge2R\xi$, $|Y|\le2R\xi/\tau$, $|X|\le\tfrac12+\delta$,
$X^2-\tfrac14=\xi(1+\xi)$, and — for the last — that $\nabla Q$ vanishes at
$S$ by (A.10), so $|\nabla_Y Q|\le R(\xi+|Y|)$ on $\mathcal C_E$ by the
$C^2$ bound:
$$\begin{aligned}
\frac{|(TY)\cdot\tfrac12(X^2-\tfrac14)a|}{q^2}
&\le\frac{\tfrac12\xi(1+\xi)\,R\,q}{q^2}
=\frac{\xi(1+\xi)R}{2q}\le\frac{1+\xi}{4}\le\frac{1+\delta}{4}\le\frac{257}{1024},\\[2pt]
\frac{|(TY)\cdot XWY|}{q^2}
&\le\frac{|X|\,R\,|Y|\,q}{q^2}=\frac{|X|\,R\,|Y|}{q}
\le\frac{(\tfrac12+\delta)\,R\,(2R\xi/\tau)}{2R\xi}
=\frac{(\tfrac12+\delta)R}{\tau}
\le\frac{257}{1024K},\\[2pt]
\frac{|(TY)\cdot\tfrac12C[Y,Y,\cdot]|}{q^2}
&\le\frac{\tfrac12 R|Y|^2 q}{q^2}\le\frac{R(2R\xi/\tau)^2}{2\cdot2R\xi}
=\frac{R^2\xi}{\tau^2}\le\frac{\delta}{4K^2R^8}\le\frac{1}{2048K^2},\\[2pt]
\frac{|(TY)\cdot r\nabla_YQ|}{q^2}
&\le\frac{rR(\xi+|Y|)}{q}\le\frac{rR\,\xi(1+2R/\tau)}{2R\xi}
=\frac{r\,(1+2R/\tau)}{2}\le 2\varepsilon_0,
\end{aligned}$$
where the second line uses $q\ge2R\xi$ and $|Y|\le2R\xi/\tau$, the third uses
$\tau\ge2KR^5$ and $\xi\le\delta=1/(512R^3)$, and the fourth uses
$r\le\varepsilon_0/R^5\le\varepsilon_0$ and $2R/\tau\le 1/(KR^4)\le1$. The
four brackets $\frac{257}{1024}$, $\frac{257}{1024K}$,
$\frac{1}{2048K^2}$, $2\varepsilon_0$ sum to $<\frac13$ (exact Fraction
arithmetic, re-verified in `scripts/arithmetic_ledgers.py`). Hence
$\tfrac12\dot G_E\le-(1-\tfrac13)q^2$. $\blacksquare$

**Lemma A.4.3 (outward energy strip and level bound).** Let
$\mathcal S_E=\{\tfrac12+\delta\le X\le\tfrac54,\ E(Y)\le E_*\}$,
$E_*=\tfrac{9}{16}(R^2/\tau)$. On its lateral boundary, $q\ge 3R/4$,
$|Y|\le 3R/(4\tau)$, $F_X\ge 3\delta/4>0$, and
$$\tfrac12\dot E\le -\tfrac1{10}q^2<0\quad\text{on }\{E=E_*\}. \tag{A.15}$$
The branch therefore reaches $X=\tfrac54$ with
$P(\tfrac54,Y)>\tfrac{49}{192}-\tfrac{1}{768}=\tfrac{65}{256}>\tfrac14>0=P(M)$:
it reaches a point strictly above the maximum level and cannot terminate at
$M$.

**Proof.** At $\xi=\delta$, $E\le4(R^2/\tau)\delta^2=\frac{4\delta^2}{9/16}E_*
=\frac{4\delta^2}{9/16}E_*<E_*$ since $\delta=1/(512R^3)<3/8$. On
$\{E=E_*\}$, $q\ge\sqrt{\tau E_*}=3R/4$ and the adverse-to-$q^2$ ratios are
$\frac78$, $\frac{5}{8K}$, $\frac{3}{32K^2}$, $\frac43\varepsilon_0$, summing
to $<\frac9{10}$ (re-verified in `scripts/arithmetic_ledgers.py`), giving
(A.15); invariance plus $F_X>0$ gives arrival at $X=\tfrac54$. The level:
$\frac12 Y^{\!\top}TY\le\tfrac12 E_*=9R^2/(32\tau)\le9/(64KR^3)<1/(4K)$ —
this is the point of the energy adaptation: no bound on $\lambda_{\max}(T)$
is needed, because $E_*$ itself is $O(R^2/\tau)$. The remaining adverse level
terms total $21/(32K)+1/K^2+3\varepsilon_0+3/8192$; the complete bracket is
$9869/16777216<1/768$ (exact Fraction arithmetic, re-verified). $\blacksquare$

**Lemma A.4.4 (inward capture — replacing the v1.2 tube equations).** Let
$m=2R/\tau$ and consider the tapered tube
$\mathcal T_{\mathrm{in}}=\{-\tfrac12<X<\tfrac12,\ |Y|\le m(\tfrac14-X^2)\}$.
Then:

(i) The inward half-branch of $S$ enters $\mathcal T_{\mathrm{in}}$: the
stable axial eigenvector at $S$ satisfies the slope bound
$|v_Y|/|v_X|<2R/\tau=m$ (the same Young-inequality computation as Lemma
A.4.1, applied to the stable eigenvalue), and inside the tube
$F_X=X^2-\tfrac14+O(R|Y|,R|Y|^2,rR)<0$ whenever
$\tfrac14-X^2\ge\delta_0$ (with $\delta_0=1/(512R^4)$ as in (ii); the
arithmetic is displayed at the end of (iii) below), so the branch moves
leftward into the tube.

(ii) *Lateral flux.* On $\{|Y|=m(\tfrac14-X^2)\}$ with
$\tfrac14-X^2\ge\delta_0:=\tfrac{1}{512R^4}$, the function
$G=Y^2-m^2(\tfrac14-X^2)^2$ satisfies $\dot G<0$. (The threshold $\delta_0$
is chosen so that $2Kr\le\delta_0$: indeed
$2Kr\le 2K\varepsilon_0/R^5=\tfrac{1}{512R^5}\le\tfrac{1}{512R^4}=\delta_0$,
using $rR^5\le\varepsilon_0$, $K\varepsilon_0=1/1024$, and $R\ge1$. This is
what makes the $r$-adverse terms $\le 1/(4K)$ below.) Indeed, on $G=0$,
$$\dot G=2Y\!\cdot\!F_Y+4m^2X(\tfrac14-X^2)F_X.$$
The leading term $-2Y^{\!\top}TY\le-2\tau m^2(\tfrac14-X^2)^2$. The adverse
terms, using $|Y|=m(\tfrac14-X^2)$, $|X|\le\tfrac12$,
$\tfrac14-X^2\le\tfrac14$, and
$|F_X|\le(\tfrac14-X^2)+\tfrac{R}{2}|Y|+\tfrac{R}{2}|Y|^2+rR$:
$$\begin{aligned}
|2Y\!\cdot\!\tfrac12(X^2-\tfrac14)a|&\le R|Y|(\tfrac14-X^2)=mR(\tfrac14-X^2)^2,\\
|2Y\!\cdot\!XWY|=2|X|\,|Y^{\!\top}WY|&\le 2|X|\,m^2R(\tfrac14-X^2)^2\le m^2R(\tfrac14-X^2)^2,\\
|Y\!\cdot\!C[Y,Y,\cdot]|&\le m^3R(\tfrac14-X^2)^3\le \tfrac14 m^3R(\tfrac14-X^2)^2,\\
|2Y\!\cdot\! r\nabla Q|&\le 2mrR(\tfrac14-X^2),
\end{aligned}$$
and dividing the last by the leading $2\tau m^2(\tfrac14-X^2)^2$ gives the
ratio $rR/(\tau m(\tfrac14-X^2))\le rR/(2R\,\delta_0)=r/(2\delta_0)\le
1/(4K)$, using $\tau m=2R$ and $2Kr\le\delta_0$. The moving-boundary
term satisfies (factoring $(\tfrac14-X^2)^2$ out of the $|F_X|$ bound, with
$(\tfrac14-X^2)\le\tfrac14$ in the quadratic term and
$(\tfrac14-X^2)^{-1}\le\delta_0^{-1}$ in the last)
$$|4m^2X(\tfrac14-X^2)F_X|\le 2m^2(\tfrac14-X^2)^2\Big(1+\frac{Rm}{2}+\frac{Rm^2}{8}+\frac{rR}{\delta_0}\Big),$$
where $rR/\delta_0\le rR\cdot 512R^4=512rR^5\le 512\varepsilon_0
=\tfrac{1}{2K}=\tfrac1{8192}$.
Collecting and dividing by $2\tau m^2(\tfrac14-X^2)^2$, the adverse ratio is
at most
$$\frac{R}{2\tau m}+\frac{R}{2\tau}+\frac{mR}{8\tau}+\frac{1}{4K}
+\frac{1}{\tau}\Big(1+\frac{Rm}{2}+\frac{Rm^2}{8}+\frac{1}{8192}\Big)
=\frac14+\frac{R}{2\tau}+\frac{R^2}{4\tau^2}+\frac{1}{4K}
+\frac{1}{\tau}\Big(\frac{8193}{8192}+\frac{R^2}{\tau}+\frac{R^3}{2\tau^2}\Big),$$
where $R/(2\tau m)=R/(4R)=\tfrac14$ and $m=2R/\tau$. Since
$\tau\ge 2KR^5+2R$ and $K=4096$: $R/(2\tau)\le 1/(4K)$,
$R^2/(4\tau^2)\le 1/(16K^2R^6)$, $1/\tau\le 1/(2K)$, and the final bracket is
$\le\tfrac{8193}{8192}+\tfrac{1}{2K}+\tfrac{1}{8K^2}\le\tfrac32$, so the total ratio is
$\le\tfrac14+\tfrac{1}{4K}+\tfrac{1}{16K^2}+\tfrac{1}{4K}
+\tfrac{1}{2K}\big(\tfrac32+\tfrac{1}{2K}+\tfrac{1}{8K^2}\big)
<\tfrac14+\tfrac{3}{K}<\tfrac13$. Hence $\dot G\le-\tfrac23\tau
m^2(\tfrac14-X^2)^2<0$: trajectories cannot exit through the lateral walls.

(iii) *Capture.* At $M$ the Jacobian
$J_M=\begin{pmatrix}A_M&B_M^{\!\top}\\B_M&-T+E_D\end{pmatrix}$ is negative
definite: for $w=(w_X,w_Y)$,
$w^{\!\top}J_Mw\le-\tfrac34 w_X^2+2R|w_X||w_Y|-\tau|w_Y|^2+\tfrac{3R}{4}|w_Y|^2
\le-\tfrac38 w_X^2-\tfrac{\tau}{2}|w_Y|^2$
by Young's inequality and $\tau\ge2KR^5+2R$. Hence, on the ball
$B(M,\rho_B)$, $\rho_B:=1/(16R)$, the Lyapunov function
$V=(X+\tfrac12)^2+|Y|^2$ satisfies
$\dot V\le-2\min(\tfrac38,\tfrac{\tau}{2})\,V+O(RV^{3/2})<0$ on
$\partial B(M,\rho_B)$, so the ball is forward-invariant and every trajectory
entering it converges to the sink $M$. The tube cross-section at
$X=-\tfrac12+\delta_0$ (where $\tfrac14-X^2\ge\delta_0$ holds with room to
spare) has half-width
$$m(\tfrac14-X^2)\le 2m\delta_0=\frac{2\cdot(2R/\tau)}{512R^4}
=\frac{1}{128\,\tau R^3}<\frac{1}{16R}=\rho_B,$$
and $\delta_0=\tfrac{1}{512R^4}<\tfrac{1}{16R}=\rho_B$; since $X$ decreases
monotonically along the inward branch inside the tube ($F_X<0$ there: the
adverse-to-$(\tfrac14-X^2)$ ratio is at most
$Rm+\tfrac{Rm^2}{8}+\tfrac{rR}{\delta_0}
\le\tfrac{1}{KR^3}+\tfrac{1}{8K^2R^7}+\tfrac1{8192}<1$), the branch reaches
the section
$X=-\tfrac12+\delta_0$ inside $B(M,\rho_B)$ and is captured. $\blacksquare$

**Lemma A.4.5 (exact-field robustness).** Every strict inequality above has a
margin of at least $\tfrac{1}{10}q^2$, $\tfrac23 q^2$, $\tfrac13$ of the
leading term, or a fixed fraction of $\rho_B^2$; the adverse brackets were
verified at $\le\tfrac13$, $\le\tfrac9{10}$, $\le\tfrac{1}{768}$ of their
budgets. A pin-preserving $C^1$ perturbation of size $\eta_R=1/(8192R^3)$
changes each flux by less than half the margin (computation identical to
Module J §8: in $\mathcal C_E$ the error is $O(\eta_R\xi)$ against
$q\ge2R\xi$; on $\{E=E_*\}$ it is at most $q\eta_R\le\frac{4\eta_R}{3R}q^2$;
in the tube it is $O(\eta_R|Y|)$ against the $\tau m^2(\tfrac14-X^2)^2$
floor). For the conditioned side-24 field,
$\|F_{\mathrm{exact}}-F\|_{C^1(D^+)}\le C_+r$ on the fifth-derivative good
event, and $C_+r\le\eta_R$ for
$r\le r_{\mathrm{mat}}=\min\{1,[1/(8192C_+\varepsilon_0^{3/5})]^{5/2}\}$.
$\blacksquare$

**Theorem A.4.6 (energy-adapted capture and escape, consolidated).** Under
(A.10)–(A.11) and $0<r\le r_{\mathrm{mat}}$: (i) the $M$-ward unstable
half-branch of $S$ converges to $M$ through $\mathcal T_{\mathrm{in}}$;
(ii) the outward half-branch remains in $\mathcal C_E\cup\mathcal S_E$ and
reaches $X=\tfrac54$ at a level strictly above $f(M)$, hence cannot terminate
at $M$; (iii) both hold for the exact conditioned field on the
fifth-derivative good event. No bound on $\lambda_{\max}(T)$ is assumed or
used.

**Status: CLOSED.** The proof above is self-contained: Lemma A.4.4 supplies
the inward-tube flux and convergence derivation that Module J imported from
the superseded v1.2 text, and every rational margin is re-verified from exact
Fraction arithmetic in `scripts/arithmetic_ledgers.py` (which prints
`ALL_ASSERTIONS_PASS`). Hostile Q8 is answered by construction: only
$\tau=\lambda_{\min}(T)$ enters.

---

## Part B — Computations displayed and re-executed (Gap items 6 and 7)

All scripts below are in `scripts/`, were executed in this build environment
(Python 3.12, SymPy 1.14, mpmath, SciPy), and print `ALL_ASSERTIONS_PASS`.
Transcripts: `scripts/*.out.txt`.

### B.1 Gap item 6. **The triple-contact elimination, displayed.**

Two independent pieces are supplied.

**(a) The covariance side — verified from first principles.** The limiting
collar and singular-near conditional covariances invoked by Module B are
*derived* (not transcribed) from $K(z)=e^{-|z|^2/2}$ via
$\operatorname{Cov}(\partial^\alpha f,\partial^\beta f)=(-1)^{|\beta|}
\partial^{\alpha+\beta}K(0)$ in `scripts/contact_covariance_verification.py`:
$$\det\operatorname{Cov}(P)=12,\qquad
\operatorname{Var}(L_1\mid P)=\tfrac{\rho^2(4X^2+\rho^2)}{2},\qquad
C_\perp=\begin{pmatrix}2Y^2+Z^2&YZ\\ YZ&Y^2+2Z^2\end{pmatrix},\ \det C_\perp=2\rho^4,$$
$$\det\operatorname{Cov}(G_{\mathrm{col}}\mid P)=\rho^6(4X^2+\rho^2),$$
$$C_{00}=\tfrac{\rho^2(c^2+\rho^2)(c^2+3\rho^2)}{72},\quad
C_{01}=-\tfrac{c\rho^2(c^2+\rho^2)}{6},\quad
C_{11}=\tfrac{\rho^2(4c^2+\rho^2)}{2},$$
$$\det C_{(L_0,L_1)}=\tfrac{\rho^6(c^2+\rho^2)(3c^2+\rho^2)}{48},\qquad
\det\operatorname{Cov}(L_0,L_1,L_2,L_3\mid P)=\tfrac{\rho^{10}(c^2+\rho^2)(3c^2+\rho^2)}{24}.$$
Every displayed formula of Module B §§3 and 5 matches exactly. (Answers the
covariance half of hostile Q4 and Q5.)

**(b) The Hessian-determinant elimination — displayed in a declared chart.**
`scripts/triple_contact_elimination.py` solves the universal two-dimensional
pin system symbolically: cubic $p(X,Y)$, critical points $M=(-\tfrac12,0)$,
$S=(\tfrac12,0)$, $p(M)=0$, $p(S)=-\kappa/6$, third critical point
$P=(c/\eta,s/\eta)$, $\eta=r/t$, with the transverse endpoint curvatures
$q_M,q_S$ prescribed (in the application they are the $O(1)$ contact-law
blocks). The elimination is unique and exact:
$$-\det H_M=\frac{\kappa^2(4c^2-\eta^2)^2+4\kappa s^2\big[(12c^2+\eta^2)q_M+(4c^2-\eta^2)q_S\big]+4s^4(q_M-q_S)^2}{64\,c^2s^2}, \tag{B.1}$$
$$-\det H_S=\frac{\kappa^2(4c^2-\eta^2)^2+4\kappa s^2\big[(4c^2-\eta^2)q_M+(12c^2+\eta^2)q_S\big]+4s^4(q_M-q_S)^2}{64\,c^2s^2},$$
i.e. the $M\leftrightarrow S$ mirror of (B.1) (same $\kappa^2$ and $s^4(q_M-q_S)^2$ terms, $q_M,q_S$ interchanged in the $\kappa$-linear term); both are printed verbatim from the symbolic elimination by the script.
$$\det H_P=\frac{\eta\big[\kappa^2(\eta^4-8c^2\eta^2+16c^4)+\cdots\big]+16c\,(q_M^2-q_S^2)s^4+\cdots}{64\,c^2\eta s^2}
\quad\text{(exact form in script output)}.$$
The script asserts: common denominators $64c^2s^2$ (endpoints) and
$64c^2\eta s^2$ (third point); the $\kappa^2$ coefficient
$(4c^2\mp\eta^2)^2/(64c^2s^2)$; the symmetric $(q_M-q_S)^2s^4$ structure;
product of exact degree $6$ in $\kappa$; and that the only angular
singularities are the axis strata $c=0$, $s=0$ (removable after the
$\rho$-blow-up, consistent with $\rho^6$-type factors above) and the collision
strata $2c=\pm\eta$.

> **DISPOSITION — RESOLVED BY REPLACEMENT (Gap item 6).** The historical
> LS-DER-024 normalization
> $\det H=B\,\kappa^2\eta^2/(64c^2s^2)$ per Hessian is **not** recovered in
> this or the other natural charts tested: in declared charts the endpoint
> determinants are generically $O(\kappa^2)$ as $\eta\to0$, not $O(\kappa^2\eta^2)$.
> The load-bearing consequence used by the actual side-24 proof is the
> anisotropic envelope $[r(r+t^2)]^2(r^2+t^3)$ (Module B eq. (41), interface
> G6′), whose derivation is displayed in Module B §6 and whose six radial
> terms integrate to $O(r^3)$ — that argument does not require the
> per-Hessian $\kappa^2\eta^2$ factor. What remains open is cosmetic-but-
> necessary: either reproduce LS-DER-024's exact chart conventions so that
> its $B_M,B_S,B_X$ formulas hold as printed, or replace the citation of
> that elimination by (B.1) and the G6′ envelope throughout. Since the older
> source also contains the false loop reduction, the supplement recommends
> the latter. **Resolution adopted (v2 manuscript):** the LS-DER-024 citation
> is replaced throughout by display (B.1) together with the G6′ envelope of
> Module B §6; the load-bearing estimates are unaffected. The historical
> normalization is retained only as a provenance note. **Status: CLOSED.**

### B.2 Gap item 7. **The cone constant $D_2=29/6-\sqrt6$ and the Euclidean coefficient, derived.**

**Derivation displayed.** Conditional on $h_t=0$, Module C (36) gives
$Q=G_2+\sqrt{2/3}\,ZI_2$ with $G_2$ standard GOE$_2$ (diagonal $N(0,2)$,
off-diagonal $N(0,1)$, independent) and $Z\sim N(0,1)$ independent. This law
is itself *derived* in `scripts/goe_cone_coefficient.py`: the conditional
covariance $\Gamma_t=\Sigma_q-C_{qh}\Sigma_h^{-1}C_{hq}$ is computed from the
kernel and equals
$\begin{pmatrix}8/3&0&2/3\\0&1&0\\2/3&0&8/3\end{pmatrix}$ (eigenvalues
$\{1,2,10/3\}$, matching Module D), which is exactly the covariance of
$(g_1+\sqrt{2/3}Z,\ g_2,\ g_3+\sqrt{2/3}Z)$. Also derived from the kernel:
$\Sigma_g=I_3$, $\Sigma_h=\operatorname{diag}(3,1,1)$, $\sigma_t^2=1/24$.

**GOE-plus-scalar cone integral.** By orthogonal invariance the scalar shift
$Z$ translates both eigenvalues: with eigenvalues $\lambda_1,\lambda_2$ of
$G_2$ (joint density $C|\lambda_1-\lambda_2|e^{-(\lambda_1^2+\lambda_2^2)/4}$)
and $s=\sqrt{2/3}$,
$$D_2=\mathbb E\Big[\prod_{i=1}^2(\lambda_i+sZ)^2\,\mathbf 1_{\{Z<-\max_i\lambda_i/s\}}\Big], \tag{B.2}$$
**Closed-form evaluation (exact — proved, not numerics).**
`scripts/d2_closed_form.py` evaluates (B.2) in closed form. The key
observation is that in trace/difference coordinates
$T=\lambda_1+\lambda_2$, $D=\lambda_1-\lambda_2\ge0$ (jacobian $1/2$), the
GOE$_2$ eigenvalue density becomes proportional to
$D\,e^{-(T^2+D^2)/8}$ — so $T\sim N(0,4)$ is *independent* of $D$ — and both
the determinant and the cone condition depend on $(T,Z)$ only through the
single linear combination
$$W=T+2sZ\sim N(0,\,\tfrac{20}{3}):\qquad
\det Q=\frac{W^2-D^2}{4},\qquad Q\prec0\iff W<-D.$$
Hence, with $M_0=\Phi(m)$, $M_2=M_0-m\phi(m)$, $M_4=3M_0-(m^3+3m)\phi(m)$ the
standard truncated normal moments at $m=-D/\sqrt{20/3}$,
$$D_2=\frac1{16}\int_0^\infty \frac{D\,e^{-D^2/8}}{4}\,
\Big[\tfrac{400}{9}M_4-\tfrac{40}{3}D^2M_2+D^4M_0\Big]\,dD. \tag{B.2′}$$
The $\phi$-terms are pure Gaussian moments (combined exponent
$a+c^2/2=\tfrac18+\tfrac{3}{40}=\tfrac15$); the $\Phi$-terms are the
half-line integrals $\int_0^\infty D^{k}\Phi(-cD)e^{-D^2/8}\,dD$ with $k$
odd, which are elementary by integration by parts:
$$\textstyle I_1=2-\frac{\sqrt6}{2},\qquad I_3=16-\frac{21\sqrt6}{4},\qquad
I_5=256-\frac{747\sqrt6}{8}.$$
Term-by-term recombination (executed symbolically in the script) gives
$$\boxed{\,D_2=\frac{29}{6}-\sqrt6\,}\qquad\text{exactly,}$$
with the script asserting equality to the target and to the manuscript
decimal. Two earlier independent numerical evaluations (adaptive quadrature
of (B.2), $3\times10^6$-draw Monte Carlo) agree with this value to
$1.2\times10^{-8}$ and $4\times10^{-4}$ respectively; they are retained in
`scripts/goe_cone_coefficient.py` as cross-checks but are no longer
load-bearing. **Every constant in the recombination of $c_{3,\infty}$ is now
exact/symbolic.**

**Coefficient recombination.** `scripts/goe_cone_coefficient.py` also verifies
symbolically/numerically:
$$c_{3,\infty}=\frac{2^{1/6}3^{1/3}(29\sqrt6-36)\Gamma(1/6)}{432\pi^{5/2}}
=2^{-23/6}3^{-8/3}(29\sqrt6-36)\Gamma(1/6)\pi^{-5/2}
=0.041775931840598343342936665428575556466681519661\ldots$$
(matching the manuscript decimal to all 46 printed digits), and
$$P_3(L)=-\frac{L^2(10L^4-147L^2+315)}{105}=-\frac{2}{21}L^6+\frac75L^4-3L^2,\qquad
P_3(24)=-\frac{620813376}{35}\ \text{(exact)}. \tag{B.3}$$
The first-variation identity (B.3) is the output of the rotational-projection
algebra of Module H §4; the polynomial identity and evaluation are verified
symbolically, and the tail bounds $q=e^{-288}<10^{-125}$,
$(3/2)^6q^5<\tfrac12$, $\|R_{\mathrm{jet}}\|<10^{-230}$ arithmetic are
re-executed in `scripts/arithmetic_ledgers.py`.

**First variation, derived from first principles (residual closed).**
`scripts/first_variation_derivation.py` now performs the full chain-rule
computation through the nonlinear functional, closing the former residual.
With the perturbed kernel
$K_p(z)=e^{-|z|^2/2}\big[1+2q\sum_i(\cosh(Lz_i)-1)\big]$, $q=e^{-L^2/2}$,
the script differentiates the directional moments of $K_p$ at $q=0$,
$$\delta m_{2k}=2(-1)^k\big(\operatorname{He}_{2k}(L)-\operatorname{He}_{2k}(0)\big),$$
and Haar-projects via the spherical average
$\mathbb E[\prod_i t_i^{2a_i}]=\prod_i(2a_i-1)!!\big/(3\cdot5\cdots(2n+1))$,
recovering Module H (14) **exactly and independently**:
$$\delta a=-2L^2,\qquad \delta m_4=\tfrac65L^4-12L^2,\qquad
\delta\chi=-\tfrac67L^6+18L^4-90L^2.$$
It then computes the *pure* partials of $\log c$ through the full nonlinear
functional (including the homogeneity-of-degree-2 term of the cone moment
$D(\Gamma)$, which contributes $+2/m_4$ to the $m_4$ partial):
$$\partial_a\log c=-\tfrac12,\qquad \partial_{m_4}\log c=-\tfrac12,\qquad
\partial_\chi\log c=\tfrac19,$$
so that $\delta\log c=-\tfrac12\,\delta a-\tfrac12\,\delta m_4+\tfrac19\,\delta\chi$.
The Module H display (15), $\delta\log c=\delta\Omega/9+\delta m_4/6-(13/6)\delta a$,
is exactly this expression regrouped via $\delta\Omega=\chi\,\delta a+a\,\delta\chi-2m_4\,\delta m_4$;
the script asserts both forms equal $P_3(L)$ symbolically. A scale-family
consistency check gives $d\log c/d\log\lambda=3/2$, matching critical-density
scaling. **Status: CLOSED.**

---

## Part C — Editorial repairs (Gap items 8–11)

### C.1 Gap item 8. **Corrected Fourier prefactor in Module F.**

Poisson summation for $g(z)=e^{-|z|^2/2}$ with $\hat g(k)=(2\pi)^{3/2}e^{-|k|^2/2}$ gives
$$K_{24}(z)=Z_{24}^{-1}\sum_{n\in\mathbb Z^3}g(z+24n)
=\frac{(2\pi)^{3/2}}{24^3 Z_{24}}\sum_{m\in\mathbb Z^3}e^{-2\pi^2|m|^2/24^2}\,e^{2\pi i m\cdot z/24}, \tag{C.1}$$
so the correct spectral weight in Module F eqs. (1)–(2) is
$a_m=(2\pi)^{3/2}24^{-3}e^{-2\pi^2|m|^2/24^2}$ (the displayed extract omitted
the prefactor $(2\pi)^{3/2}24^{-3}$). The Gram identity (4) becomes
$\operatorname{Var}[T(f)]=Z_{24}^{-1}\frac{(2\pi)^{3/2}}{24^3}\sum_m
e^{-2\pi^2|m|^2/24^2}|\hat T(m)|^2$. Since the omitted factor is a positive
constant, Theorem 3.1, Corollary 3.2, and every positivity conclusion of
Module F are unaffected; the correction is display-level but must enter the
journal version. **Status: CLOSED (replacement display supplied).**

### C.2 Gap item 9. **Restored Module E hypotheses.**

The extract of Module E begins at its §3; §§1–2 are restored as follows.
**(1) Jet ball.** $B=\{J:\|J-J_0\|_{\max}\le10^{-110}\}$, with $J_0$ the planar
Bargmann–Fock even jet through order six — this is the ball referenced as
"(1)" in Module E §§3–5 (the perturbation bound $8\cdot729\cdot10^{-110}$
appearing in its eq. (4) fixes the radius uniquely). **(2) Standing
hypotheses.** $K$ is a stationary, even, real-analytic covariance kernel with
$J_6(K)\in B$; the associated centered Gaussian field has the finite-family
derivative nondegeneracy of Module F (full positive Fourier support, which
the normalized side-24 kernel has by (C.1)); all compact charts, mark sets,
and constants are those of Module B. Under (1)–(2) the derivative envelope
used in Module E §§4–5 is the coarse coefficient-map bound
$\|dA_{\mathrm{col}}\|,\|dA_{\mathrm{sing}}\|\le10^{40}$ of Module D applied
to the analytic dependence of conditional covariances on $J_6$, giving
$A_{\mathrm{col}}(K)\ge1-10^{-70}$ and $A_{\mathrm{sing}}(K)\ge1/24-10^{-70}$.
**Status: CLOSED (hypotheses and the envelope's provenance restored).**

### C.3 Gap item 10. **Module K generic symbols defined.**

In Module K §5: $n=d-1$; for the isotropic kernel with one-dimensional
sectional covariance $K^{(1)}$,
$$a=-(K^{(1)})''(0)>0,\qquad m_4=(K^{(1)})^{(4)}(0)>0,\qquad \chi=-(K^{(1)})^{(6)}(0)>0,\qquad
\Omega=a\chi-m_4^2, \tag{C.2}$$
so $a=\operatorname{Var}(\partial_t f)$, $m_4=\operatorname{Var}(\partial_{tt}f)$,
$\chi=\operatorname{Var}(\partial_{ttt}f)$, and
$\Omega/a=\operatorname{Var}(\partial_{ttt}f\mid\partial_t f)$ is the
conditional third-derivative variance (for Bargmann–Fock:
$a=1$, $m_4=3$, $\chi=15$, $\Omega=6$ — consistent with $\sigma_t^2=1/24$
via $\Omega/(2a)=3=72\sigma_t^2$). $\beta=m_4/3$ is the transverse
second-derivative variance parameter, and
$D_n=\mathbb E[(\det M_n)^2\mathbf 1_{\{M_n\prec0\}}]$ is the centered
negative-definite determinant moment of the conditional transverse Hessian in
dimension $n$, exactly as in Module C (18). **Status: CLOSED.**

### C.4 Gap item 11. **Density convention emphasized.**

Insert at the manuscript's definition of $\nu_{3,24}$:
> *Convention.* $\nu_{3,24}$ is the **first-moment intensity density per unit
> ordinary torus volume**: $\nu_{3,24}(\ell)\,d\ell$ is the expected number of
> finite nonessential superlevel $H_0$ bars per unit volume with lifetime in
> $[\ell,\ell+d\ell]$. It is not the probability density of the lifetime of a
> randomly sampled bar; such a law requires normalizing by the expected bar
> count per unit volume and specifying the sampling rule, neither of which is
> used in Theorem 2.1. The asymptotic $\nu_{3,24}(\ell)=c_{3,24}\ell^{-1/3}(1+o(1))$
> holds for the pointwise Kac–Rice representative of the Radon–Nikodym
> derivative of Proposition 1.2, i.e. for Lebesgue-a.e. $\ell$ in the
> sequential sense selected by that representative.

**Status: CLOSED (insert text supplied).**

---

## Part D — Gap item 12: systematic literature search

Searches executed 2026-08-01 (general web indexes; targeted queries: expected
persistence diagram density asymptotics, near-diagonal/short-lifetime laws,
Kac–Rice maximum–saddle pairing and elder rule, Bargmann–Fock persistence,
$H_0$ lifetime exponents for smooth Gaussian fields).

1. **Persistence densities for random fields/complexes.**
   Adler–Bobrowski–Borman–Subag–Weinberger (IMS Collections 6, 2010) —
   structure and simulation of persistence for random fields; explicitly notes
   the death side of $H_0$ bars is global and not determined locally. No
   near-diagonal asymptotic.
2. **Expected-diagram density existence.**
   Chazal–Divol (JoCG 10(2), 2019) — existence and kernel estimation of the
   density of expected persistence diagrams for broad random filtrations;
   no smooth-Gaussian-field near-diagonal power law.
3. **Kac–Rice critical-point asymptotics.**
   Klein–Agam (J. Phys. A 45, 2012) and Ancona–Gass–Letendre–Stecconi
   (arXiv:2501.10226) — critical-point correlations, Kac–Rice singularities,
   cumulant asymptotics; no elder-rule/persistence selection imposed.
   Hirsch–Lachièze-Rey (arXiv:2411.11429) — functional CLT for topological
   functionals of Gaussian critical points; different question.
4. **Gaussian-field topology/percolation.**
   Pranav (arXiv:2109.08721), Feldbrugge–van Engelen–van de Weygaert–Pranav–
   Vegter (2019), and the Bargmann–Fock percolation line
   (Duminil-Copin et al.) — Betti numbers, Euler characteristic, connectivity;
   no selected maximum–saddle lifetime law.
5. **Persistence-diagram probabilistic models.**
   Maroulas–Mike–Oballe (JMLR 20, 2019), Adler et al. point-process models,
   and the "universal null distribution" work (Nature Sci. Rep. 2023) treat
   diagram-level noise models or filtrations of point-cloud complexes
   (Čech/Rips), not smooth-field Morse persistence.

**Conclusion.** As of 2026-08-01, no located work proves a selected
near-diagonal short-lifetime $H_0$ intensity law
$\nu(\ell)=c\ell^{-1/3}(1+o(1))$ for a smooth Gaussian field, nor the
Bargmann–Fock coefficient $c_{3,\infty}$, nor a fixed-side periodization
correction of the form (2.10). This remains *evidence of novelty, not a
determination*: MathSciNet and zbMATH subscription searches and a
backward/forward citation pass from references 2, 3, and 6–7 of the
manuscript should still be executed before submission (this environment has
no MathSciNet/zbMATH access).

**Status: CLOSED at the level possible here** (RESIDUAL PREMISE: paywalled
database pass outstanding).

---

## Part E — Reproducibility repairs

1. **Coefficient-bound transcript (reproduction guide §9).** The disclosed
   source/result mismatch is resolved as recommended: the replacement ledger
   `scripts/arithmetic_ledgers.py` prints *both* scales, so source and
   transcript agree by construction:
   `TAYLOR_REMAINDER_AT_1e-113_UNNORMALIZED_SCALE < 5e-187`,
   `DECLARED_RELATIVE_HESSIAN_BOUND = 1e42`,
   `TAYLOR_REMAINDER_AT_1e-113 < 5e-185`. Module H §2.2 already documents
   that the single historical line referred to the unnormalized $10^{40}$
   scale; the theorem-level $|\varepsilon_{24}|<10^{-180}$ is unaffected.
2. **Environment record.** These ledgers were executed under Python 3.12 with
   SymPy 1.14, mpmath, NumPy/SciPy (exact versions in the run transcripts),
   repairing the "not executed / version not recorded" deficiencies for the
   regenerated checks.
3. **New checks added.** `contact_covariance_verification.py` (Module B
   covariances from first principles), `goe_cone_coefficient.py` ($D_2$, jet
   objects, $c_{3,\infty}$, $P_3(24)$), `triple_contact_elimination.py`
   (displayed elimination), `first_variation_derivation.py` (full first-variation
   chain-rule: $\delta a,\delta m_4,\delta\chi$ from kernel differentiation and
   Haar projection; pure partials through the nonlinear functional; exact
   recovery of $P_3(L)$; $\lambda$-scale check), `d2_closed_form.py` (exact
   closed-form evaluation of $D_2=29/6-\sqrt6$ via the trace/difference
   reduction (B.2′)). Each prints `ALL_ASSERTIONS_PASS`; transcripts in
   `scripts/*.out.txt`.

---

## Register reconciliation summary

| # | Item | State after this supplement |
|---|------|-----------------------------|
| 1 | Off-diagonal elder pairs | Proved: Proposition A.3.2 ($O(\ell)$, hence $o(\ell^{-1/3})$) |
| 2 | Exact near pushforward | Proved: Proposition A.3.1 + Theorem A.3.3 with explicit DCT hypotheses |
| 3 | Palm law and elder mark | Defined in one place (A.1)–(A.3); Borel measurability proved (Lemma A.1.3) |
| 4 | Elder-selection trichotomy | Formal exhaustive lemma (Lemma A.2.1) with named events |
| 5 | Capture/escape consolidation | Theorem A.4.6, self-contained; inward tube re-derived (Lemma A.4.4); margins re-verified |
| 6 | Triple-contact elimination | CLOSED: displayed (B.1) + covariance side verified exactly; LS-DER-024 citation replaced by (B.1) + G6′ envelope (load-bearing estimates unaffected) |
| 7 | Cone and first-variation constants | CLOSED, all constants exact/symbolic: cone law and jet objects derived; $D_2=29/6-\sqrt6$ proved in closed form (B.2′); $\delta a,\delta m_4,\delta\chi$, $\delta\log c$ and $P_3(L)$ exact (scale check $3/2$); numerics retained only as cross-checks |
| 8 | Fourier prefactor | Corrected display (C.1); positivity conclusions unaffected |
| 9 | Module E hypotheses | Restored (C.2) |
| 10 | Module K notation | Symbols defined (C.3), consistency with $\sigma_t^2=1/24$ checked |
| 11 | Density convention | Insert text supplied (C.4) |
| 12 | Literature novelty | Systematic web-level search executed; no conflicting theorem located; paywalled-database pass remains |

All twelve register items are now closed. The two former RESIDUAL PREMISES
(items 6 and 7) are resolved: item 6 by replacing the LS-DER-024 citation with
the displayed elimination (B.1) plus the G6′ envelope, item 7 by the full
first-principles first-variation derivation. One literature task remains
open in the ordinary editorial sense (item 12: a paywalled MathSciNet/zbMATH
pass), flagged here rather than hidden; no conflicting theorem was located at
web level.
