# Manuscript v2 — Integration Sheet (SIDE24-V2-2026-08-01)

The 2026-07-31 manuscript PDF is frozen. This sheet is the authoritative
list of edits producing manuscript v2: each entry gives the target location in
`03_SIDE24_MANUSCRIPT.pdf` / `04_TECHNICAL_APPENDIX.pdf` and the replacement
material, all of which is stated and proved in full in
`SIDE24_gap_fill/SIDE24_GAP_FILL_SUPPLEMENT.md` (cited below as [S]).

## Manuscript (03)

1. **§2, after Theorem 2.1** — insert the density-convention paragraph [S, C.4]:
   one display fixing that "density" means the ℓ-density of finite nonessential
   superlevel H₀ bars, with the Kac–Rice counting measure normalized as in
   §3.2 (gap item 11).
2. **§3.1 (Palm framework)** — replace the informal elder-mark usage with
   Definitions (A.1)–(A.3) [S, Part A]: Palm law of the critical-point process,
   the elder mark via connection level m_g(u,v) and birth level b_g(u,a), and
   Lemma A.1.3 (Borel measurability; proof via 1-Lipschitz connection level and
   a countable dense sup) (gap item 3).
3. **§3.3 (elder selection)** — insert Lemma A.2.1 (trichotomy) [S, Part A]:
   every finite nonessential bar is selected by exactly one of the three named
   events (elder-rule, collar, singular-near), with the selection probability
   1 − p_r = O(r³) as displayed (gap item 4).
4. **§3.4 (near pushforward)** — replace the heuristic identification with
   Proposition A.3.1 (exact near pushforward) and Theorem A.3.3 (limit
   interchange under the stated DCT hypotheses) [S, Part A] (gap item 2).
5. **§3.5 (off-diagonal pairs)** — insert Proposition A.3.2: the contribution
   of off-diagonal elder pairs is O(ℓ), hence o(ℓ^(−1/3)) and invisible in the
   asymptotic (gap item 1).
6. **§3.6–3.7 (capture/escape)** — replace the consolidated argument with the
   self-contained Theorem A.4.6 and Lemma A.4.4 (inward tube re-derived)
   [S, Part A]: T = −Q_⊥/(κr), K = 4096, ε₀ = 1/(1024K), rR⁵ ≤ ε₀,
   τ ≥ 2KR⁵ + 2R; the four margins re-verified in exact rational arithmetic
   (257/1024 + 257/(1024K) + 1/(2048K²) + 2ε₀ < 1/3;
   7/8 + 5/(8K) + 3/(32K²) + (4/3)ε₀ < 9/10; bracket 9869/16777216 < 1/768;
   P(5/4, Y) > 49/192 − 1/768 = 65/256 > 1/4) (gap item 5).
7. **§3.8 (finite-size correction)** — add one sentence: the first-variation
   display δ log c = δΩ/9 + δm₄/6 − (13/6)δa and the variations (14) of
   Module H are derived from first principles in the supplement [S, B.2],
   including the pure partials ∂_a = ∂_{m₄} = −1/2, ∂_χ = 1/9 and the
   D(Γ)-homogeneity term; the regrouped display is an algebraic identity via
   δΩ = χδa + aδχ − 2m₄δm₄ (gap item 7).

## Technical appendix (04)

8. **Module B §6 / interface G6′** — delete the citation of the historical
   LS-DER-024 per-Hessian normalization; replace by the displayed exact
   elimination (B.1) of [S, B.1] (common denominators 64c²s² and 64c²ηs²,
   κ²-coefficient (4c² ∓ η²)², product of exact degree 6 in κ) together with
   the anisotropic envelope [r(r + t²)]²(r² + t³) whose six radial terms
   integrate to O(r³). The load-bearing estimates are unchanged (gap item 6).
9. **Module F eqs. (1)–(2)** — correct the spectral weight to
   a_m = (2π)^{3/2}24^{−3}e^{−2π²|m|²/24²} and the Gram identity (4)
   accordingly [S, C.1]; Theorem 3.1 and Corollary 3.2 unaffected (gap item 8).
10. **Module E, opening** — restore §§1–2: the jet ball
    B = {J : ‖J − J₀‖_max ≤ 10⁻¹¹⁰} and the standing hypotheses (stationary
    even real-analytic kernel, J₆(K) ∈ B, Module F nondegeneracy), with the
    derivative-envelope provenance A_col ≥ 1 − 10⁻⁷⁰,
    A_sing ≥ 1/24 − 10⁻⁷⁰ [S, C.2] (gap item 9).
11. **Module K** — add the symbol definitions of [S, C.3]; consistency with
    σ_t² = 1/24 checked (gap item 10).
12. **Module H §4** — append the first-variation derivation paragraph of
    [S, B.2] (kernel differentiation of K_p, Haar projection, exact recovery
    of P₃(L), λ-scale check 3/2) (gap item 7, with entry 7 above).
12a. **Module C/D, cone constant** — replace the asserted value of D₂ by the
    closed-form evaluation [S, B.2′]: trace/difference coordinates make
    T ~ N(0,4) independent of D ≥ 0; det Q = (W² − D²)/4 and the cone
    condition is W < −D for the single Gaussian W = T + 2sZ ~ N(0, 20/3);
    truncated-moment recombination with the elementary half-line integrals
    I₁ = 2 − √6/2, I₃ = 16 − 21√6/4, I₅ = 256 − 747√6/8 gives
    D₂ = 29/6 − √6 exactly (scripts/d2_closed_form.py) (gap item 7).

## Reproduction guide (05)

13. **§9** — replace the disclosed coefficient-bound transcript mismatch by the
    replacement ledger `arithmetic_ledgers.py`, which prints both scales
    (TAYLOR_REMAINDER_AT_1e-113 < 5e-185 at the declared relative scale;
    < 5e-187 at the unnormalized 10⁴⁰ scale; DECLARED_RELATIVE_HESSIAN_BOUND =
    1e42). Add the six verification scripts and their transcripts to the
    reproduction file list.

## Bibliography (08)

14. **Novelty pass** — record the systematic web-level literature search of
    2026-08-01 [S, Part D] (no conflicting theorem located) and schedule the
    paywalled MathSciNet/zbMATH pass before journal submission (gap item 12).
