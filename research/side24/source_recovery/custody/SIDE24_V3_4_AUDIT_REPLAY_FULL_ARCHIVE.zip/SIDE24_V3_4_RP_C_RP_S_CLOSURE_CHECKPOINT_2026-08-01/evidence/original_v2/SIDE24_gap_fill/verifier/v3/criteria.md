# Verifier v3 — criteria (2026-08-01)

Supersedes v2. Changes: six transcripts required (adds d2_closed_form);
D₂ must be claimed exact (closed form), not numerically confirmed; new
checks for the Lemma A.4.4 repaired budget and the Lemma A.2.1 Case-2
witness.

## Checks

1. Supplement exists and references all 12 register items.
2. Register reconciliation table present with 12 rows.
3. Six script transcripts exist and contain ALL_ASSERTIONS_PASS:
   arithmetic_ledgers, contact_covariance_verification,
   triple_contact_elimination, goe_cone_coefficient,
   first_variation_derivation, d2_closed_form.
4. Item-6 boxed RESIDUAL PREMISE absent; replacement disposition present.
5. Item-7 closed: first-variation derivation present (P₃(L), scale 3/2).
6. No boxed RESIDUAL PREMISE remains; item-12 paywalled flag present.
7. Corrected Fourier prefactor display present.
8. Density-convention paragraph present.
9. v2 snapshot files exist (change log, register v2, integration sheet).
10. GAP_REGISTER_V2 marks all 12 items CLOSED.
11. MANUSCRIPT_V2_INTEGRATION references all 12 gap items.
12. CHANGE_LOG preserves the 2026-07-31 baseline.
13. first_variation_derivation transcript: P₃(24) and 3/2 scale check.
14. Run records exist; README indexes v1, v2, v3.
15. d2_closed_form transcript: asserts D₂ = 29/6 − sqrt(6) exactly and the
    half-line integrals I1, I3, I5.
16. Supplement claims D₂ exact/closed form (B.2′) and does NOT describe D₂
    as "numerically confirmed" in its status sentences.
17. arithmetic_ledgers transcript contains the A.4.4 budget lines
    (A44_LATERAL_ADVERSE_RATIO < 1/3, A44_FX_ADVERSE_IN_TUBE < 1).
18. Supplement contains the repaired A.4.4 threshold δ₀ = 1/(512R⁴) and the
    A.2.1 Case-2 witness y = M₂.
