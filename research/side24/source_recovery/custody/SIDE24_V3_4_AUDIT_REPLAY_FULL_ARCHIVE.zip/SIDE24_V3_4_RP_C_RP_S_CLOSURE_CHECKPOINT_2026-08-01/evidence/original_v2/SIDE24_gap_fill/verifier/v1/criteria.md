# Verifier v1 — acceptance criteria for SIDE24 gap-fill

Created: 2026-08-01. Measures whether each of the 12 dossier gap-register items
(02_PRE_REVIEW_DOSSIER §12) is addressed by the supplement, and whether every
computational claim re-executes.

## Checks
1. Every one of the 12 register items maps to a numbered section of
   `SIDE24_GAP_FILL_SUPPLEMENT.md` (grep for "Gap item k", k=1..12).
2. All scripts in `scripts/` run under python3 and print ALL_ASSERTIONS_PASS:
   - triple_contact_elimination.py: exact κ²η² factor in each of det H_M, det H_S,
     det H_y, hence exact κ⁶η⁶ in the product.
   - goe_cone_coefficient.py: D₂ = 29/6 − √6 verified to ≥ 30 digits against an
     independent eigenvalue-integral evaluation; c_{3,∞} closed form matches the
     manuscript decimal; P₃(24) = −620813376/35.
   - arithmetic_ledgers.py: energy margins (1/3, 9/10, 1/768 brackets), radial power
     ledger (r³/6 · r⁻⁶ · r² · r²dr = r dr/6), lifetime factor 6^(2/3)/3,
     combined scalar 6^(2/3)/18, tail bounds Q=e⁻²⁸⁸<10⁻¹²⁵.
3. Honesty check: the supplement explicitly labels any residual unproven premise
   (search for "RESIDUAL PREMISE"); no gap item is claimed closed without either a
   proof or a labeled residual premise.
4. Fourier prefactor correction states the (2π)^{3/2}/24³ factor (grep).
5. Supplement states the per-volume first-moment intensity convention (grep).
