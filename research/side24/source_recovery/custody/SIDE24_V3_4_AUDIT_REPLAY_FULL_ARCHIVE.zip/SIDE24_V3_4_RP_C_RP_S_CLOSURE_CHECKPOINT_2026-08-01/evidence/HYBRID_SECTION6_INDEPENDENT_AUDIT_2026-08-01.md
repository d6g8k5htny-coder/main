# SIDE24 V3.4 hybrid Section 6 — independent executable audit

**Date:** 2026-08-01  
**Scope:** mixed-curvature interpolant, quartic remainder factors, exact-axis
countermodels, algebraic ESIP deficits, and active-document references  
**Package audited:** `SIDE24_V3_4_RP_C_RP_S_CLOSURE_CHECKPOINT_2026-08-01`

## Outcome

The new noncollinear mixed-curvature repair is algebraically sound.  A fresh
generic ten-coefficient elimination verifies its unisolvence for
`eta*sigma != 0`, all three exact square completions, regularity at the
perpendicular face `c=0`, and the claimed endpoint remainder factors.

The collinear-axis replacement is also directionally correct: an explicit
typed quintic gives a determinant product of exact order `r^3` at `s=2r`,
where the common monomial is order `r^6`.  The singular `s^-6` and collar
`r^-3` deficits are exactly the deficits printed in the new note, and a
Mahalanobis exponential absorbs every fixed power after integration.

One claim should nevertheless be narrowed before promotion.  The pointwise
collar envelope (6.8)/(H.26), with a right side depending only on the common
monomial and a radial axial parameter, does not include the independent
endpoint-collision factor `d^-1`.  The controlling proof's later equation
(8.4) correctly retains and integrates that factor.  Thus the final endpoint
ledger can survive, but “one density-weighted monomial on every face” is too
strong if it is meant pointwise before spatial integration.

**Integration note.**  The controlling V3.4 sources were revised after this
finding.  They now exclude the axial endpoint from (6.8)/(H.26), state the
measure-level replacement (H.27)/(EP.2), qualify the confluent interpolation
matrix, repair the segment coordinate, and mark the earlier compactification
target as superseded.  The singular-frame audit also led to the
pair-pin-measurable \(\bar V_0\) repair in Section 6 below.  The cleanup list
in Section 5 is therefore historical; its duplicate equation tags remain
only inside a clearly withdrawn HTML-comment block.

## 1. Executable result

Artifact:

`verify_hybrid_mixed_curvature_and_axis_absorption.py`

- 202 exact checks, all pass;
- normal and `python -O` transcripts are byte-identical;
- zero bare Python `assert` statements;
- injected `--negative-probe` exits with status 1;
- Python 3.12.13, SymPy 1.14.0;
- script SHA-256:
  `0ba99085cf5b1655deb95859a63f02478057491fe1d394124d853e93bea8c481`;
- normal/optimized transcript SHA-256:
  `0a8cd0874a146de25432e8a200ffb5746cb3bc98dc81ceb05f016e5f5c7a8e03`.

The script is independent of the package implementation and solves the
generic systems directly.

## 2. Mixed-curvature cubic — verified

In the centered normalized chart

```text
M=(-eta/2,0), S=(eta/2,0), P=(c,sigma),
```

the raw ten-row interpolation matrix has determinant

```text
2 eta^5 sigma^6.
```

After the two endpoint value-gradient pins, the four-dimensional kernel is

```text
A(X^2-eta^2/4)Y + Y^2(BX+C) + E Y^3.
```

The normalized mixed-curvature row is exactly `2A`.  Once `A=0`, the
witness value/X-gradient/Y-gradient matrix on `(XY^2,Y^2,Y^3)` has
determinant `-sigma^6`.  In particular, no `c` factor appears, so the
perpendicular face `c=0` is regular.

The solved Hessians agree exactly with (H.7)--(H.8).  In normalized
coordinates, with

```text
v = [D sigma + kappa(2c+eta)]/(2 kappa eta),
L0 = kappa^2 eta^4/sigma^2,
```

the verifier obtains

```text
-det H_Q(M) = L0(v^2-alpha),
-det H_Q(S) = L0((v-1)^2-(1-alpha)),
 det H_Q(P) = -L0((v-alpha)^2+alpha(1-alpha)).
```

Multiplication by the physical Hessian scale gives
`L=kappa^2 r^4/(sigma^2 s^2)`, exactly as printed.

For a completely generic homogeneous quartic Taylor term, subtracting its
mixed-curvature cubic interpolant gives

```text
g(X,0)   = tau*q40*(2X-eta)^2*(2X+eta)^2/16,
g_Y(X,0) = tau*q31*X*(2X-eta)*(2X+eta)/4.
```

Consequently, at both endpoints,

```text
g_XX = 2*tau*eta^2*q40,
g_XY = tau*eta^2*q31/2,
g_YY = tau*(bounded chart coefficient).
```

Putting `tau=s` and converting normalized Hessians back to physical ones
gives exactly `(r^2,r^2,s^2)` for the three entries.  The witness remainder
is `s^2` entrywise.  This independently verifies (H.11)/(6.5) at the
quartic-leading level and identifies the divided-difference mechanism behind
the general smooth statement.

## 3. Exact collinear obstruction — verified and made explicit

For `M=-r/2`, `S=r/2`, `y=2r`, `kappa=1`, and `alpha=1/2`, let

```text
q_r(x)=r^3 p(x/r),

p(z)=(2z+1)^2[
  64z^3-222z^2+174z-79/2
  +250z^3-1500z^2+3000z-2000
]/20250.
```

Then all three derivatives vanish and the values are
`0,-r^3/6,-r^3/12`.  The normalized second derivatives are

```text
p''(-1/2) = -3277/2025,
p''( 1/2) =   569/1125,
p''( 2  ) =    12/25.
```

Extending by `-(x_2^2+x_3^2)/2` makes `M` a maximum and `S` an index-two
critical point.  The absolute three-determinant product is a nonzero exact
constant times `r^3`, whereas

```text
D(r,2r)=r^6(1+4r)^2(1+8r).
```

Their ratio diverges like `r^-3`.  The fifth derivative of this family is
nonzero and scales as `r^-2`, making the large-jet/ESIP diagnosis explicit.

## 4. Endpoint-collision qualification to (6.8)/(H.26)

There is a second exact typed family that reproduces the endpoint powers
used in Section 8.  For `0<d<r/2`, define

```text
q'_r(x) = (20/r^2)x(x-d)(x-r)(x-r/2).
```

It has `q_r(r)-q_r(0)=-r^3/6`, and

```text
q''_r(0) = -10d,
q''_r(d) = 10d(r-2d)(r-d)/r^2,
q''_r(r) = 10(r-d).
```

The witness value is in the canonical interval; for example, at `d=r/4`,
`q_r(d)=-alpha*r^3/6` with `0<alpha<1`.  With two fixed negative hard
curvatures, `M` is a maximum and `y,S` are index-two.  The determinant
product is

```text
1000 d^2(r-2d)(r-d)^2/r^2 = Theta(r d^2)  (d=o(r)).
```

On the exact axial endpoint, (4.2)--(4.5) give the gradient-density
prefactor `d^-3 r^-4 exp(-c/r^2)`.  The product therefore leaves

```text
d^-1 r^-3 exp(-c/r^2).
```

No fixed power of `r^-1` in (6.8)/(H.26) can dominate `d^-1` uniformly as
`d -> 0`; here `s` remains comparable to `r`, so the common-monomial side
has no hidden `d`.  This is also exactly what the controlling proof now
records after spatial volume and Palm normalization:

```text
r^-2 (d^-3 r^-4)(r d^2)d^2 dd = r^-5 d dd.   (8.4)
```

Its integral is `O(r^-3 exp(-c/r^2))`, hence certainly `O(r^3)`.  The
recommended correction is therefore to exclude the endpoint-collision face
from the pointwise claim (6.8)/(H.26), and state its integrated `d`-ledger
separately as Section 8 already does.  Likewise, qualify the disposition's
“identical monomial on every face” as an **integrated facewise ledger**, not
a pointwise density-weighted envelope at the axial endpoint.

## 5. Document and cross-reference sweep

After stripping the explicitly withdrawn HTML block:

- the controlling facewise note has 70 active equation tags, all unique;
- the companion moment note has 28 active equation tags, all unique;
- every local parenthesized equation reference in both files resolves;
- `(4.13)` in Section 8 correctly points to the endpoint density estimate;
- the current `00_READ_ME_FIRST.md`, `01_V3_CORRECTIVE_CHECKPOINT.md`, and
  `13_RP_C_RP_S_CLOSURE_DISPOSITION.md` explicitly reject the false
  all-face pathwise claim.  No active stale “Lemma 6.1” reference remains.

Four cleanup items remain:

1. In `three_hessian_conditional_moment_envelope.md`, the sentence saying
   “the interpolation matrix and its inverse extend through eta=0” is
   literally false for the raw value-gradient matrix, whose determinant is
   `2 eta^5 sigma^6`.  The **divided-difference-normalized system** and the
   pin-compatible solved cubic extend.  Name that normalization explicitly.
2. The same note defines `h(q)=D_e g(M+qt)` for
   `-r/2<=q<=r/2`.  With centered endpoints this should be either
   `h(q)=D_e g(x+qt)` or `h(q)=D_e g(M+(q+r/2)t)`.
3. `drafts/joint_collar_compactification_target.md` still has the heading
   “Facewise acceptance lemma still required” and an unqualified “same
   monomial weights on every face.”  It is a lower-priority historical
   target, but it appears in the reading order and should receive a
   superseded-by-V3.4 banner plus the density-weighted/integrated qualifier.
4. The withdrawn source block in the controlling note contains duplicate raw
   tags `(6.1)`--`(6.9)`.  Rendered Markdown is clean, but source-grep and
   simplistic equation checkers see duplicates.  Moving the rejected proof
   to an archival note would eliminate that avoidable ambiguity.

The disposition says the package includes a “typed quintic obstruction,”
but the V3.4 scripts contain no explicit quintic regression.  The verifier
delivered with this audit now supplies both that regression and the separate
endpoint-collision family.

## 6. Exact singular and generic value-row reconstruction

The initially supplied singular first-order symbols did not identify finite
random variables.  A valid pair-measurable choice on the positive axial
chart is

```text
V0bar=s^-3{F(y)-(s*varrho/2)F_v(y)-(s*c/3)F_u(y)},
V1=s^-2 F_u(y),  V2=s^-1 F_v(y),  V3=s^-1 F_w(y).
```

The raw witness-to-corrected determinant is exactly `s^-7`.  With
`a=eta^2/4`, `D=1-a`, and, at the projective face,

```text
W=V1+[12/(1+3a)]V0bar,
```

the whole first projective order cancels for every `a`, and the second row is

```text
W = -3D/(1+3a)[s^2 D^2 H1+s*varrho*D A1+varrho^2 D0/2]+O_3.
```

The exact near-axis coefficient is `12c/(c^2+3a)`; the displayed form is its
positive-axis limit.  The normalized frame

```text
(V0bar/Lambda, W/Lambda^2, V2/Lambda, V3/Lambda)
```

has 18 nonzero coefficient minors.  Their squared sum factors as

```text
D^2(R^2+T^2D^2)(R^2+2T^2D^2)^4/16.
```

It is uniformly positive on `T^2+R^2=1`, `D>=D_min>0`, including both
`T=0` and `R=0`.  Thus the same finite frame gives covariance determinant
order `Lambda^10` on the full mixed/contact/collinear boundary; the proposed
`eta^8+Lambda^2` second blow-up is unnecessary.  The axial gradient `V1`
itself supplies ESIP: its target mismatch is
`kappa(c^2-a)` up to orientation, and its residual variance is
`O(s^2+varrho^2)`.

Subtracting `F(x)` in `V0` is not valid: `F(x)` is not part of either the
pair pins or the raw witness vector.  The polynomial
`(u^2-h^2)^2` has zero endpoint values and derivatives but midpoint value
`h^4`, proving the midpoint value is not pair-measurable.  Such a row has no
claimed four-dimensional triangular Jacobian.

For the generic transverse collar, a fully explicit trapezoidal value row is

```text
R0=r^-3{f(y)-f(M)-(r/2)u dot [grad f(y)+grad f(M)]},
u=(xi1+1/2)t+xi2 e2+xi3 e3.
```

Together with the printed `R1,R2,R3`, its contact symbol is

```text
R0 -> -D_u^3/12.
```

The coefficient minor of `(R0,R1,R2,R3)` on
`(V^3,T V^2,V E2,V E3)` is `-1/24`, and the exact raw-to-corrected
determinant is `r^-7`.  This fills the formerly prose-only `R0` and Jacobian
claim.

## 7. Scope boundary

This audit does not certify the exact side-24 covariance comparisons,
Fourier-distribution independence on every face, the finite atlas,
conditional Gaussian moment bounds, Kac--Rice interchange, or theorem-level
promotion.  The HOLD should remain pending those independent checks.
