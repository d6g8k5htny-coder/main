# SIDE24 — Independent Audit Run Log
**Date:** 2026-07-31 · **Session:** continuation after interrupted audit (prior working tree lost; everything below executed fresh)

## Environment
- Python 3.12.3 · sympy 1.14.0 · mpmath 1.3.0 · numpy 2.4.4 · scipy 1.17.1
- Workspace `/home/claude/audit/` — `repro/` (fresh re-runs), `independent/` (from-scratch suite), `docs/`, `snapshot/`, `pkg/` (unpacked V2 bundles)
- Project sources read-only at `/mnt/project/`

## 1. Reproduction re-runs (repro/)
Command per script: `python3 <script>.py > <script>.fresh.txt 2>&1`, then `diff <script>.fresh.txt /mnt/project/<script>_out.txt`.

| # | Script | Result | Transcript diff |
|---|--------|--------|-----------------|
| R1 | triple_contact_elimination.py | ALL_ASSERTIONS_PASS | byte-identical |
| R2 | contact_covariance_verification.py | ALL_ASSERTIONS_PASS | byte-identical |
| R3 | arithmetic_ledgers.py | ALL_ASSERTIONS_PASS | byte-identical |
| R4 | d2_closed_form.py | ALL_ASSERTIONS_PASS | byte-identical |
| R5 | goe_cone_coefficient.py | ALL_ASSERTIONS_PASS | byte-identical |
| R6 | first_variation_derivation.py | ALL_ASSERTIONS_PASS | byte-identical |

## 2. Manifest audit
`sha256sum` against `09_PACKAGE_MANIFEST_V2.csv` (24 entries): **15 MATCH** — all `.md` sources except CHANGE_LOG.md, all six scripts, all six transcripts. **8 DIFF** — CHANGE_LOG.md (finding F1: manifest bytes 3500 vs actual 4628; entry predates the final-round Addendum) and the seven binary deliverables (mount serves re-encoded page-bundle ZIPs / base form → hashes not checkable here; LIMITATION, content audited instead). One manifest row is the manifest itself (excluded by convention).

## 3. Document sweep
All V2 bundles unpacked to `pkg/` (03: 3pp, 04: 4pp, 11: 17pp; each with `manifest.json`, page-complete). Glyph-normalized (NFKC + κ/η/²/− mappings, whitespace-stripped) scans confirmed every targeted constant/display listed in the findings doc §1[D], including the 46-digit c₃,∞ decimal checked digit-for-digit against a fresh 60-dps recomputation.

## 4. Independent suite (independent/)
Written from scratch against the manuscript's claims. Each run: `python3 -u verify_<x>_v1_1.py > verify_<x>_v1_1.out.txt 2>&1`.

| Script | Checks | Result |
|--------|--------|--------|
| verify_constants_v1_1.py | 12 | ALL_ASSERTIONS_PASS |
| verify_first_variation_v1_1.py | 14 | ALL_ASSERTIONS_PASS |
| verify_b1_elimination_v1_1.py | 15 | ALL_ASSERTIONS_PASS (includes the F2 finding assertion B1b3) |
| verify_goe_cone_v1_1.py | 13 | ALL_ASSERTIONS_PASS |

**Total: 54/54 PASS, 0 FAIL.**

### Engineering notes (for reproducibility of the audit itself)
- **b1 elimination:** first draft had three intentionally failing probes (B1b/B1b2/B1g) pending diagnosis; after the sign analysis they were converted to positive assertions: B1b asserts the transcript's minus form, B1b3 asserts the printed v2 form differs (prints `FINDING_F2_CONFIRMED` + the factored difference), B1b2 asserts the reflection law, B1g split into poles/finiteness/zero-locus checks.
- **goe cone, G5 incident:** the first rebuild used density constant 1/(8√π); G5 measured error was exactly √2, diagnosing the correct symmetrized constant 1/(8√(2π)) (ordered form 1/(4√2·√π)). Fixed; incident recorded as N3.
- **goe cone, quadrature performance:** the raw 3-level nested quadrature of the eigenvalue-coordinate definition (moving-window inner integrals) is impractically slow at useful precision in this container and, at dps=15, under-resolves (observed |tot−1| > 1e-9 even with the correct constant). Replaced by (a) separable rotated-coordinate 1-D quadratures for G5 (errors < 1e-20 at dps=25) and (b) a seeded, vectorized Monte-Carlo of the raw definition for G4c: H per pinned GOE₂ convention (diag N(0,2), off-diag N(0,1)), eigenvalues m∓r, s=(λ₁+λ₂)/2 ⟂ gap, t = s + √(2/3)·Z, D₂ = E[(t²−w²)²; t>w], N = 2×10⁶, seed 20260731 → D₂ᴹᶜ = 2.3721960659, se = 0.0107854048, exact 29/6−√6 = 2.3838435906, z = −1.08. Exactness is carried by the symbolic G4a; MC verifies the raw-definition ↔ reduction link end-to-end.
- **process hygiene:** long runs backgrounded via `nohup timeout 900 python3 -u … &` and polled; `pkill` patterns use the `[.]` bracket trick to avoid matching the polling shell's own command line.

## 5. Snapshot
`SIDE24_INDEPENDENT_AUDIT_SNAPSHOT_2026-07-31.zip` — contents: this log, the findings document, the four independent scripts + their output transcripts, the six fresh reproduction transcripts, and `SHA256SUMS` over all included files. Assembled per package protocol (new dated artifact; nothing in the V2 snapshot modified).
