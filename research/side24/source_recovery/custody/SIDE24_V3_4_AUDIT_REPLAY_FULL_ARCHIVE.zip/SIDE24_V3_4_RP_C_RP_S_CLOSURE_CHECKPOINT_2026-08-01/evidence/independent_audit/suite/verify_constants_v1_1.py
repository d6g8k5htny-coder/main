"""verify_constants_v1_1.py -- Independent verification (written 2026-07-31, Claude/Anthropic).

Rebuilt 2026-07-31 after session interruption; check list identical to the
interrupted session's script (C5a carries that session's ledger fix: the two
endpoint softs contribute r*r = r^2 in total).

Checks, with exact symbolic algebra, the scalar identities used in
03_SIDE24_MANUSCRIPT (Theorem 2.1, Sections 3.2-3.3, 3.7) and Appendix
Modules C, K, L:

  C1. Gamma(7/6) = Gamma(1/6)/6.
  C2. The two displayed closed forms of c_{3,infinity} agree:
        2^(-23/6) 3^(-8/3) (29 sqrt6 - 36) Gamma(1/6) pi^(-5/2)
      = 2^(1/6) 3^(1/3) (29 sqrt6 - 36) Gamma(1/6) / (432 pi^(5/2)).
  C3. Substituting the planar values Sigma_g = I_3, Sigma_h = diag(3,1,1),
      sigma_t^2 = 1/24, D_t = 29/6 - sqrt6 into
        c = B_3 * 4 pi * (sigma^2)^(2/3) D_t / sqrt(det Sg det Sh),
        B_3 = 3 Gamma(7/6) / (2^(4/3) pi^(7/2)),
      reproduces c_{3,infinity} exactly.
  C4. Numerical value of c_{3,infinity} to 40 digits (manuscript p.2 digits).
  C5. Radial ledger: (r^3/6) * r^(-6) * r^2 dr = (1/6) r^(-1) dr, times polar
      r^2 gives (1/6) r dr; combined scalar (1/6)(6^(2/3)/3) = 6^(2/3)/18.
  C6. Lifetime pushforward: for ell = kappa r^3/6 at fixed kappa,
      r dr = (6^(2/3)/3) kappa^(-2/3) ell^(-1/3) d ell   (Module K (9)-(10)).
  C7. sigma_t^2 = Omega/(144 a) for the isotropic jet; planar check 6/144 = 1/24.
  C8. Isotropic-family recombination instance at d=3, a=1, m4=3, Omega=6,
      D_2 = 29/6 - sqrt6 (det Sg = a^3, det Sh = m4^3/9, sigma_t^2 =
      Omega/(144a)) reproduces c_{3,infinity}.  (The m4^{1/2} family exponent
      is exercised separately in verify_first_variation_v1_1.py, S4d.)
  C9. Cone radial constant: (2pi)^(-3/2) * Int_0^inf r^6 e^(-r^2/2) dr = 15/(4pi)
      (Module C (29)).
  C10. Poisson summation prefactor for the side-24 torus: the 1-D identity
       sum_n e^(-(z+nL)^2/2) = (sqrt(2pi)/L) sum_m e^(-2 pi^2 m^2/L^2) cos(2 pi m z/L)
       at L = 24, verified at high precision at several z (the per-axis
       prefactor sqrt(2pi)/L that cubes to the corrected (2pi)^{3/2}/24^3
       display, Part C.1 / Module F repair).
"""
import sympy as sp
import mpmath as mp

ok = True
def check(name, cond):
    global ok
    print(f"{name}: {'PASS' if cond else 'FAIL'}")
    ok = ok and bool(cond)

s6 = sp.sqrt(6)
G16 = sp.gamma(sp.Rational(1, 6))

# ---- C1
check("C1_gamma_identity", sp.simplify(sp.gamma(sp.Rational(7, 6)) - G16/6) == 0)

# ---- C2: the two closed forms
formA = 2**sp.Rational(-23, 6) * 3**sp.Rational(-8, 3) * (29*s6 - 36) * G16 * sp.pi**sp.Rational(-5, 2)
formB = 2**sp.Rational(1, 6) * 3**sp.Rational(1, 3) * (29*s6 - 36) * G16 / (432 * sp.pi**sp.Rational(5, 2))
check("C2_two_closed_forms_equal", sp.simplify(formA - formB) == 0)

# ---- C3: planar substitution into the master formula
B3 = 3 * sp.gamma(sp.Rational(7, 6)) / (2**sp.Rational(4, 3) * sp.pi**sp.Rational(7, 2))
sigma2 = sp.Rational(1, 24)
Dt = sp.Rational(29, 6) - s6
c_planar = B3 * 4*sp.pi * sigma2**sp.Rational(2, 3) * Dt / sp.sqrt(sp.Integer(1) * 3)
check("C3_planar_substitution", sp.simplify(sp.expand(c_planar - formA)) == 0)

# ---- C4: numeric value, 40 digits
mp.mp.dps = 50
val = (mp.mpf(2)**(mp.mpf(-23)/6) * mp.mpf(3)**(mp.mpf(-8)/3)
       * (29*mp.sqrt(6) - 36) * mp.gamma(mp.mpf(1)/6) * mp.pi**(mp.mpf(-5)/2))
print("  c_{3,inf} =", mp.nstr(val, 40))
check("C4_numeric_matches_manuscript_digits",
      mp.nstr(val, 40).startswith("0.041775931840598343342936665428575556466"))

# ---- C5: radial ledger (fixed form) and combined scalar
r = sp.symbols('r', positive=True)
ledger = (r**3/6) * r**-6 * r**2              # gap Jacobian * pins * (both endpoint softs: r*r)
check("C5a_radial_ledger_(1/6)r", sp.simplify(ledger * r**2 - sp.Rational(1, 6)*r) == 0)  # times polar r^2
check("C5b_combined_scalar_6^(2/3)/18",
      sp.simplify(sp.Rational(1, 6) * 6**sp.Rational(2, 3)/3 - 6**sp.Rational(2, 3)/18) == 0)

# ---- C6: lifetime pushforward r dr -> (6^(2/3)/3) kappa^(-2/3) ell^(-1/3) d ell
kappa, ell = sp.symbols('kappa ell', positive=True)
r_of_ell = (6*ell/kappa)**sp.Rational(1, 3)
rdr = sp.simplify(r_of_ell * sp.diff(r_of_ell, ell))          # r * dr/d ell
target = 6**sp.Rational(2, 3)/3 * kappa**sp.Rational(-2, 3) * ell**sp.Rational(-1, 3)
check("C6_pushforward_r_dr", sp.simplify(rdr - target) == 0)

# ---- C7: sigma_t^2 = Omega/(144 a), planar instance
check("C7_sigma_t2_planar_6/144=1/24", sp.Rational(6, 144) == sp.Rational(1, 24))

# ---- C8: isotropic-family instance at the planar point
a, m4, Om = sp.symbols('a m4 Omega', positive=True)
c_family = B3 * 4*sp.pi * (Om/(144*a))**sp.Rational(2, 3) * Dt / sp.sqrt(a**3 * m4**3/9)
c_at_planar = c_family.subs({a: 1, m4: 3, Om: 6})
check("C8_moduleK_planar_instance", sp.simplify(sp.expand(c_at_planar - formA)) == 0)
# power bookkeeping used downstream: a-exponent is -2/3 - 3/2 = -13/6
check("C8b_a_exponent_-13/6",
      sp.simplify(sp.Rational(-2, 3) - sp.Rational(3, 2) + sp.Rational(13, 6)) == 0)

# ---- C9: cone radial constant
check("C9_cone_radial_15/(4pi)",
      sp.simplify((2*sp.pi)**sp.Rational(-3, 2)
                  * sp.integrate(r**6*sp.exp(-r**2/2), (r, 0, sp.oo)) - 15/(4*sp.pi)) == 0)

# ---- C10: 1-D Poisson identity at L = 24, high precision
mp.mp.dps = 60
L = mp.mpf(24)
def lhs_sum(z):
    return mp.nsum(lambda n: mp.e**(-(z + n*L)**2/2), [-2000, 2000])
def rhs_sum(z):
    return (mp.sqrt(2*mp.pi)/L) * mp.nsum(
        lambda m: mp.e**(-2*mp.pi**2*m*m/L**2) * mp.cos(2*mp.pi*m*z/L), [-2000, 2000])
errs = [abs(lhs_sum(z) - rhs_sum(z)) for z in [mp.mpf('0'), mp.mpf('0.3'), mp.mpf('7.1'), mp.mpf('11.9')]]
print("  max Poisson identity error:", mp.nstr(max(errs), 5))
check("C10_poisson_prefactor_(2pi)^{1/2}/L_per_axis", max(errs) < mp.mpf('1e-45'))

print("ALL_ASSERTIONS_PASS" if ok else "ASSERTION_FAILURES_PRESENT")
