"""verify_goe_cone_v1_1.py -- Independent verification (2026-07-31, Claude/Anthropic).

Rebuilt 2026-07-31 after session interruption. G4 uses the fast
trace/half-gap reduction adopted at the end of the interrupted session
(symbolic, exact) with a raw finite-window quadrature retained as a
numerical cross-check.

Verifies, from the planar Bargmann-Fock covariance K(z) = e^{-|z|^2/2} alone:

  G1. The exact jet covariances at the origin (spectral moments of N(0, I_3)):
        Sigma_g = I_3,  Sigma_h = diag(3,1,1),  Sigma_q = [[3,0,1],[0,1,0],[1,0,3]],
        C_qh nonzero only in the h_1 = f_tt column.
  G2. Gamma = Sigma_q - C_qh Sigma_h^{-1} C_hq = [[8/3,0,2/3],[0,1,0],[2/3,0,8/3]],
      with eigenvalues {1, 2, 10/3}  (Module D, Section 2).
  G3. The conditional law Q | h_t = 0 has the same second moments as
        G_2 + sqrt(2/3) Z I_2,
      where G_2 is GOE_2 in the convention: diagonal entries N(0,2),
      off-diagonal N(0,1), all independent; Z ~ N(0,1) independent
      (Module B (8) shape and Module C (36)).  The convention is thereby
      pinned explicitly (review item: "state the GOE normalization").
  G4. D_2 := E[(det Q)^2 1{Q negative definite}] = 29/6 - sqrt(6), exactly,
      via the (s, w) factorization of the GOE_2 eigenvalue law:
        lambda_{1,2} = s -/+ w,  s ~ N(0,1) independent of the half-gap w
        with density w e^{-w^2/2} (w > 0);  with t = s + cZ ~ N(0, 5/3),
        c = sqrt(2/3):
        det Q = (t^2 - w^2)^2-root form, Q < 0  <=>  t < -w, and by t-symmetry
        D_2 = E[(t^2 - w^2)^2 ; t > w].
      Evaluated in closed form symbolically; cross-checked by direct
      quadrature of the raw eigenvalue-coordinate definition (moderate
      precision; exactness is carried by the symbolic G4a).
  G5. Sanity: the eigenvalue density integrates to 1 and reproduces
      E[l1^2 + l2^2] = 6 for this convention.  (These checks caught a
      sqrt(2) normalization slip in the first rebuild of this script:
      the symmetrized constant is 1/(8 sqrt(2 pi)), equivalently
      1/(4 sqrt(2) sqrt(pi)) on the ordered region.)
  G6. The limiting contact pin vector P = (f, f_111, f_1, f_11, f_2, f_12,
      f_3, f_13) has det Cov(P) = 12 exactly (Module B (6)); computed here
      from spectral moments with the parity block structure.
"""
import sympy as sp
import mpmath as mp

ok = True
def check(name, cond):
    global ok
    print(f"{name}: {'PASS' if cond else 'FAIL'}")
    ok = ok and bool(cond)

# ---------- spectral moment machinery: Cov(d^A f, d^B f) = i^{|A|} (-i)^{|B|} m_{A+B},
# m_alpha = product of 1-D standard Gaussian moments (0 for odd, (2k-1)!! for 2k).
def gmom(k):
    return sp.Integer(sp.factorial2(k-1)) if k % 2 == 0 else sp.Integer(0)
def m_of(alpha):
    return sp.prod([gmom(a) for a in alpha])
def cov(A, B):
    s = (sp.I**sum(A)) * ((-sp.I)**sum(B))
    tot = tuple(a+b for a, b in zip(A, B))
    return sp.simplify(s * m_of(tot))

e = lambda *idx: tuple(sum(1 for i in idx if i == k) for k in (1, 2, 3))
# frame: t = e1, n1 = e2, n2 = e3
g  = [e(1), e(2), e(3)]                       # gradient
h  = [e(1,1), e(1,2), e(1,3)]                 # Hessian t-row
qv = [e(2,2), e(2,3), e(3,3)]                 # transverse Hessian coords

Sg = sp.Matrix(3, 3, lambda i, j: cov(g[i], g[j]))
Sh = sp.Matrix(3, 3, lambda i, j: cov(h[i], h[j]))
Sq = sp.Matrix(3, 3, lambda i, j: cov(qv[i], qv[j]))
Cqh = sp.Matrix(3, 3, lambda i, j: cov(qv[i], h[j]))

check("G1a_Sigma_g=I3", Sg == sp.eye(3))
check("G1b_Sigma_h=diag(3,1,1)", Sh == sp.diag(3, 1, 1))
check("G1c_Sigma_q", Sq == sp.Matrix([[3, 0, 1], [0, 1, 0], [1, 0, 3]]))
check("G1d_Cqh_only_ftt_column",
      all(sp.simplify(Cqh[i, j]) == 0 for i in range(3) for j in (1, 2)))

Gamma = sp.simplify(Sq - Cqh * Sh.inv() * Cqh.T)
check("G2a_Gamma_matrix", Gamma == sp.Matrix([[sp.Rational(8, 3), 0, sp.Rational(2, 3)],
                                              [0, 1, 0],
                                              [sp.Rational(2, 3), 0, sp.Rational(8, 3)]]))
check("G2b_Gamma_eigenvalues_1_2_10/3", sorted(Gamma.eigenvals().keys()) == [1, 2, sp.Rational(10, 3)])

# G3: second moments of G_2 + c Z I_2, c^2 = 2/3, GOE convention diag N(0,2) offdiag N(0,1)
c2 = sp.Rational(2, 3)
model = sp.Matrix([[2 + c2, 0, c2], [0, 1, 0], [c2, 0, 2 + c2]])   # Var(q1), Var(q2)=1, Cov(q1,q3)=c^2
check("G3_conditional_law_matches_GOE_plus_scalar", sp.simplify(Gamma - model) == sp.zeros(3, 3))

# ---------- G4: exact D_2 via the (s, w, t) reduction
# Q|h=0 ~ G2 + c Z I,  c=sqrt(2/3), G2 GOE: diag N(0,2), offdiag N(0,1)  => weight e^{-Tr H^2/4}
# ordered eigenvalue density (1/(4 sqrt(2) sqrt(pi))) (l2-l1) e^{-(l1^2+l2^2)/4}
# s=(l1+l2)/2 ~ N(0,1) independent of half-gap w with density w e^{-w^2/2} (w>0)
# t = s + cZ ~ N(0,5/3);  D2 = E[(t^2-w^2)^2 ; t > w]  (t-symmetry of the cone event)
t, w = sp.symbols('t w', positive=True)
phi = sp.sqrt(sp.Rational(3, 10)/sp.pi)*sp.exp(-sp.Rational(3, 10)*t*t)
inner = sp.integrate((t*t - w*w)**2*phi, (t, w, sp.oo))
D2 = sp.integrate(w*sp.exp(-w*w/2)*inner, (w, 0, sp.oo))
D2 = sp.nsimplify(sp.simplify(D2), [sp.sqrt(6)])
print("  D2 symbolic =", D2)
check("G4a_D2_exact_29/6_minus_sqrt6", sp.simplify(D2 - (sp.Rational(29, 6) - sp.sqrt(6))) == 0)

# normalization sanity of the (s, w) factorization itself
s_ = sp.symbols('s')
Znorm = (sp.integrate(sp.exp(-s_*s_/2), (s_, -sp.oo, sp.oo))/sp.sqrt(2*sp.pi)
         * sp.integrate(w*sp.exp(-w*w/2), (w, 0, sp.oo)))
check("G4b_sw_factorization_normalized", sp.simplify(Znorm) == 1)

# ---------- G4c/G5: raw-definition cross-checks (fast forms)
mp.mp.dps = 25
c = mp.sqrt(mp.mpf(2)/3)
norm = 1/(8*mp.sqrt(2*mp.pi))   # symmetrized joint density: |l1-l2| e^{-(l1^2+l2^2)/4}/(8 sqrt(2 pi))

# G5: normalization + second moment of the stated eigenvalue density,
# via rotated coordinates u=(l1+l2)/sqrt2, v=(l2-l1)/sqrt2 (separable 1-D quads).
# (These checks caught a sqrt(2) slip in this script's first rebuild: the
#  symmetrized constant is 1/(8 sqrt(2 pi)), i.e. 1/(4 sqrt2 sqrt(pi)) ordered.)
Iu0 = mp.quad(lambda u: mp.e**(-u*u/4), [-40, 40])
Iu2 = mp.quad(lambda u: u*u*mp.e**(-u*u/4), [-40, 40])
Iv1 = mp.quad(lambda v: mp.sqrt(2)*abs(v)*mp.e**(-v*v/4), [-40, 0, 40])
Iv3 = mp.quad(lambda v: v*v*mp.sqrt(2)*abs(v)*mp.e**(-v*v/4), [-40, 0, 40])
tot = norm*Iu0*Iv1
sec = norm*(Iu2*Iv1 + Iu0*Iv3)   # l1^2+l2^2 = u^2+v^2
check("G5a_eigdensity_normalized", abs(tot-1) < mp.mpf('1e-20'))
check("G5b_E[l1^2+l2^2]=6", abs(sec-6) < mp.mpf('1e-19'))

# G4c: Monte-Carlo cross-check of D2 straight from the raw definition:
# sample H per the pinned GOE_2 convention (diag N(0,2), off-diag N(0,1)),
# eigenvalues m -+ r; s=(l1+l2)/2 ~ N(0,1) independent of the gap;
# w=(l2-l1)/2 >= 0; t = s + c Z, Z ~ N(0,1) indep, c = sqrt(2/3);
# D2 = E[(t^2-w^2)^2 ; t>w].  Seeded, vectorized, 2e6 samples.
import numpy as np
rng = np.random.default_rng(20260731)
N = 2_000_000
x = rng.normal(0, np.sqrt(2), N); y = rng.normal(0, np.sqrt(2), N)
zo = rng.normal(0, 1, N); Z = rng.normal(0, 1, N)
m = (x+y)/2; r = np.sqrt(((x-y)/2)**2 + zo**2)
w = r; tt = m + float(c)*Z
val = np.where(tt > w, (tt*tt - w*w)**2, 0.0)
D2mc = val.mean(); se = val.std(ddof=1)/np.sqrt(N)
targ_f = float(mp.mpf(29)/6 - mp.sqrt(6))
print("  D2 MC =", D2mc, " se =", se, " target =", targ_f, " z =", round((D2mc-targ_f)/se, 3))
check("G4c_raw_definition_montecarlo_within_5se", abs(D2mc - targ_f) < 5*se)

# ---------- G6: det Cov(P) = 12 for P = (f, f_111, f_1, f_11, f_2, f_12, f_3, f_13)
P = [e(), e(1,1,1), e(1), e(1,1), e(2), e(1,2), e(3), e(1,3)]
CovP = sp.Matrix(8, 8, lambda i, j: cov(P[i], P[j]))
check("G6_detCovP=12", sp.simplify(CovP.det()) == 12)

print("ALL_ASSERTIONS_PASS" if ok else "ASSERTION_FAILURES_PRESENT")
