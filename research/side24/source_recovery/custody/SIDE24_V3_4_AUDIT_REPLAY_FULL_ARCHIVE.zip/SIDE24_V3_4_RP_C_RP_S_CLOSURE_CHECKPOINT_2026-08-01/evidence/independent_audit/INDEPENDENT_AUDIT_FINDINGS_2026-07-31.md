# SIDE24 — Independent Audit Findings
**Date:** 2026-07-31 · **Auditor:** Claude (fresh container, full re-execution) · **Package:** V2 pre-review snapshot (24 manifest entries)

**Method.** Prior audit session was interrupted and its working tree lost; nothing was carried over. All results below come from (a) fresh re-execution of the package's six committed reproduction scripts, (b) a from-scratch independent verification suite (4 scripts, 54 checks) written against the manuscript's *claims*, not its code, (c) SHA-256 manifest audit, and (d) a glyph-normalized document sweep of all V2 bundles.

---

## 1. Verification summary

**[R1–R6] Reproduction — PASS, byte-identical.** All six committed scripts (`triple_contact_elimination`, `contact_covariance_verification`, `arithmetic_ledgers`, `d2_closed_form`, `goe_cone_coefficient`, `first_variation_derivation`) re-run fresh; each prints `ALL_ASSERTIONS_PASS`; each fresh transcript is **byte-identical** to its committed `*_out.txt`.

**[I] Independent suite — 54/54 PASS, 0 FAIL.**
- `verify_constants_v1_1.py` — 12 checks. Full constant chain c₃,∞ (60-dps Poisson-summation identity, residual ~3e-61); I₅ = 256 − 747√6/8; P₃(24) = −620813376/35; correction −(620813376/35)e⁻²⁸⁸; |ε₂₄| < 10⁻¹⁸⁰; isotropic-family covariance instance (det Σ_g = a³, det Σ_h = m₄³/9, σ_t² = Ω/(144a), a-exponent −13/6).
- `verify_first_variation_v1_1.py` — 14 checks. From-scratch re-derivation of P₃(L) including the d4 lines (d2_iiii = m₄, d2_iijj = 2h₀,₂m₂), matching the committed route.
- `verify_b1_elimination_v1_1.py` — 15 checks. **From-scratch symbolic elimination** of the (B.1) pin system in the declared chart M=(−1/2,0), S=(1/2,0), P=(c/η, s/η) with p(M)=0, p(S)=−κ/6, p_YY endpoint values q_M, q_S. Confirms: unique solution; endpoint denominators 64c²s²; third-point denominator 64c²ηs²; κ²-coefficient (4c²−η²)²; κ⁰ term 4s⁴(q_M−q_S)²; product exactly degree 6 in κ; reflection law (see F2); η→0 leading term 16c⁴κ² (LS-DER-024 non-recovery confirmed); collision strata 2c=±η are the **zero locus of the leading κ² coefficient, not poles** (all coefficient denominators — lcm 96cs³ — are finite there).
- `verify_goe_cone_v1_1.py` — 13 checks. Independent covariance/Γ computation (eigenvalues 1, 2, 10/3); conditional law = GOE₂ + scalar shift; **D₂ = 29/6 − √6 derived exactly, symbolically, by an independent route**; eigenvalue-density normalization and E[λ₁²+λ₂²]=6 (separable 1-D quadrature, errors < 1e-20); seeded Monte-Carlo of the raw definition (2×10⁶ GOE₂ samples per the pinned convention): D₂ᴹᶜ = 2.37220 ± 0.01079 vs exact 2.38384, z = −1.08; det Cov(P) = 12.

**[M] Manifest audit — 15/24 MATCH.** All `.md` sources (except CHANGE_LOG → F1), all six scripts, all six transcripts match their SHA-256 entries. The other DIFFs are the seven binary deliverables — see LIMITATION.

**[D] Document sweep — clean.** Glyph-normalized scan of all V2 bundles confirms: P₃(24) value (12 sites); the 46-digit c₃,∞ decimal verified **digit-for-digit** against a fresh 60-dps computation (exact prefix); 6^{2/3}/18; D₂ = 29/6 − √6 exact wording; (2π)^{3/2}·24⁻³ prefactor; δ₀ = 1/(512R⁴); |ε₂₄| < 10⁻¹⁸⁰; e⁻²⁸⁸; r³/6 gap Jacobian in (A.7); W = T + 2sZ route; no placeholder `\frac{}{}` displays; zero residual "RESIDUAL PREMISE" or "numerically confirmed" leftovers.

---

## 2. Findings register

### [F2] Sign error in the −det H_S mirror display — **substantive, not load-bearing**
**Location.** `SIDE24_GAP_FILL_SUPPLEMENT.md` §B.1(b) (source of the display), propagated verbatim into `04_TECHNICAL_APPENDIX_V2` §A1 and the corresponding page of `11_COMPLETE_PRE_REVIEW_PACKET_V2`.

**What is printed** (κ-linear bracket sign **+**):
```
−det H_S = [ κ²(4c²−η²)² + 4κs²[(4c²−η²)q_M + (12c²+η²)q_S] + 4s⁴(q_M−q_S)² ] / (64c²s²)
```
**What the committed transcript and the independent from-scratch elimination both give** (sign **−**):
```
−det H_S = [ κ²(4c²−η²)² − 4κs²[(4c²−η²)q_M + (12c²+η²)q_S] + 4s⁴(q_M−q_S)² ] / (64c²s²)
```
**Diagnosis.** The −det H_M display is **correct** (independently re-derived, B1a). The true mirror law is the reflection X→−X, which flips the gap sign:
```
n_S(κ, c, q_M, q_S) = n_M(−κ, −c, q_S, q_M)
```
i.e. the q's are interchanged **and** the κ-linear term changes sign. The supplement's prose ("q_M, q_S interchanged in the κ-linear term") describes exactly the erroneous transformation applied — swap without sign flip. Difference between printed and true forms, pinned symbolically (check B1b3):
```
8κs²[(4c²−η²)q_M + (12c²+η²)q_S]      (= 2× the κ-linear term)
```
**Load-bearing impact: none.** The proof consumes |det H| and the G6′ envelope [r(r+t²)]²(r²+t³); the κ² coefficient, κ⁰ term, denominators, degree-6 product bound, collision-strata statements, and the LS-DER-024 η→0 analysis are all sign-insensitive and were each independently re-verified (B1c–B1h: PASS).

**Recommended fix (per package protocol — new dated snapshot, no overwrite):** correct the one display in the supplement; regenerate 04 and 11; amend the mirror prose to "q_M, q_S interchanged **and the κ-linear term negated** (reflection κ→−κ, c→−c)".

### [F1] Stale manifest entry for CHANGE_LOG.md
`09_PACKAGE_MANIFEST_V2.csv` records CHANGE_LOG.md at 3500 bytes; the current file is 4628 bytes — the manifest predates the "Addendum (final round)". Regenerate 09 in the next dated snapshot (naturally bundled with the F2 fix).

### [LIMITATION] Binary hashes unverifiable via project mount
The seven binary deliverables (six PDFs + `07_REVIEW_RESPONSE_FORM_V2.docx`) are mounted as re-encoded page-bundle ZIPs / base form, not the manifest's binary referents, so their SHA-256 entries cannot be checked here. **Content** was audited instead via the unpacked bundles (page-complete, no gaps) and is consistent with sources. Not evidence of corruption.

### [N1] B.1 structural claims independently confirmed
Everything the v2 disposition asserts about the elimination — chart, uniqueness, denominators, coefficient structure, degree, collision strata, η→0 non-recovery of LS-DER-024 — reproduces from scratch. The replacement of the withdrawn lemma by (B.1)+G6′ checks out.

### [N2] Minor self-containedness suggestion
The GOE₂ entry convention (diag N(0,2), off-diag N(0,1)) is pinned in the supplement; `04` §A2 says only "standard GOE₂". Suggest echoing the convention parenthetically in A2 when 04 is next regenerated.

### [N3] Process note — sanity checks earned their keep
The first rebuild of the independent GOE script carried a √2 slip in the eigenvalue-density constant (1/(8√π) instead of the correct 1/(8√(2π)), i.e. 1/(4√2·√π) on the ordered region). The G5 sanity checks caught it (measured error exactly √2), and the corrected constant is what all reported results use. Recorded here for audit-trail honesty and as evidence the suite's sanity layer is sharp.

---

## 3. Disposition

Both packet bundles are **content-clean except the F2 display typo**. The theorem statement, constant chain, correction term, error bound, and every load-bearing derivation re-verify from scratch: ν₃,₂₄(ℓ) = c₃,₂₄ ℓ^(−1/3)(1+o(1)) with the stated c₃,∞, correction −(620813376/35)e⁻²⁸⁸, |ε₂₄| < 10⁻¹⁸⁰, and D₂ = 29/6 − √6 in closed form.

**Action for next dated snapshot:** (1) fix the −det H_S display + mirror prose (F2); (2) regenerate 09 manifest (F1); (3) optionally add the GOE convention echo in 04 A2 (N2).

**Tally note.** This session's counts supersede the interrupted session's in-chat "94 checks" figure, which cannot be reconstructed after the container loss. Fresh honest totals: **6 reproduction scripts, all ALL_ASSERTIONS_PASS, byte-identical transcripts; 54/54 independent checks PASS; 15/24 manifest hashes MATCH (all that are checkable); document sweep clean.**
