"""verify_b1_elimination_v1_1.py -- Independent audit of display (B.1)
(2026-07-31, Claude/Anthropic).  From-scratch derivation, independent of
scripts/triple_contact_elimination.py: only the *declared chart* of the v2
appendix (A1) is taken as input; the elimination itself is re-solved here.

Declared chart (04_TECHNICAL_APPENDIX_V2, A1): cubic p(X, Y); critical
points M = (-1/2, 0), S = (1/2, 0), third critical point P = (c/eta, s/eta);
values p(M) = 0, p(S) = -kappa/6; transverse endpoint curvatures
p_YY(M) = q_M, p_YY(S) = q_S.  These are 10 linear conditions on the 10
cubic coefficients; the elimination is the unique solution.

Displayed claims audited:

  B1a. -det H_M = [kappa^2 (4c^2-eta^2)^2
                   + 4 kappa s^2 ((12c^2+eta^2) q_M + (4c^2-eta^2) q_S)
                   + 4 s^4 (q_M-q_S)^2] / (64 c^2 s^2).
  B1b. -det H_S: true mirror law.  The reflection X -> -X maps the pin
       system to itself with (kappa, c, q_M, q_S) -> (-kappa, -c, q_S, q_M),
       so the kappa-linear bracket of -det H_S is the q-swap of (B.1)'s
       bracket WITH AN OVERALL SIGN FLIP:
         -det H_S = [kappa^2 (4c^2-eta^2)^2
                     - 4 kappa s^2 ((4c^2-eta^2) q_M + (12c^2+eta^2) q_S)
                     + 4 s^4 (q_M-q_S)^2] / (64 c^2 s^2),
       matching scripts/triple_contact_elimination.out.txt verbatim.
       FINDING F2: the v2 appendix (04, A1) prints this display with "+" on
       the kappa-linear bracket; the script transcript it cites, and this
       independent derivation, both give "-".  Asserted below.
  B1c. det H_P has denominator 64 c^2 eta s^2 (endpoints: 64 c^2 s^2).
  B1d. kappa^2-coefficient of each endpoint numerator is (4c^2-eta^2)^2.
  B1e. kappa^0 term is 4 s^4 (q_M-q_S)^2 (both endpoints).
  B1f. The product (-det H_M)(-det H_S)(det H_P) has exact degree 6 in kappa.
  B1g. Collision strata 2c = +/- eta: these are NOT poles (the solved
       coefficients stay finite there and the displayed denominators carry
       only the axis strata c = 0, s = 0, plus eta = 0 for the third point);
       they are the zero locus of the kappa^2 leading coefficient,
       (4c^2-eta^2)^2 = (2c-eta)^2 (2c+eta)^2 -- the degeneration the
       committed transcript's ANGULAR_SINGULARITIES line records.
  B1h. LS-DER-024 non-recovery: at eta -> 0 the endpoint numerators do NOT
       vanish (leading kappa^2 term 16 c^4 kappa^2), i.e. the historical
       per-Hessian kappa^2 eta^2 normalization is not reproduced in this
       chart -- confirming the v2 disposition (replacement by (B.1) + G6').

All algebra exact (sympy); c, s generic with the relation c^2 + s^2 = 1
applied only if needed for matching (recorded in the transcript).
"""
import sympy as sp

ok = True
def check(name, cond):
    global ok
    print(f"{name}: {'PASS' if cond else 'FAIL'}")
    ok = ok and bool(cond)

X, Y = sp.symbols('X Y')
kappa, eta, c, s, qM, qS = sp.symbols('kappa eta c s q_M q_S', positive=True)

# generic cubic, 10 coefficients
coeffs = sp.symbols('a0 a10 a01 a20 a11 a02 a30 a21 a12 a03')
a0, a10, a01, a20, a11, a02, a30, a21, a12, a03 = coeffs
p = (a0 + a10*X + a01*Y + a20*X**2 + a11*X*Y + a02*Y**2
     + a30*X**3 + a21*X**2*Y + a12*X*Y**2 + a03*Y**3)

pX, pY = sp.diff(p, X), sp.diff(p, Y)
M = {X: sp.Rational(-1, 2), Y: 0}
S = {X: sp.Rational(1, 2),  Y: 0}
Pt = {X: c/eta, Y: s/eta}

eqs = [
    p.subs(M),                          # p(M) = 0
    p.subs(S) + kappa/6,                # p(S) = -kappa/6
    pX.subs(M), pY.subs(M),             # grad p(M) = 0
    pX.subs(S), pY.subs(S),             # grad p(S) = 0
    pX.subs(Pt), pY.subs(Pt),           # grad p(P) = 0
    sp.diff(p, Y, 2).subs(M) - qM,      # p_YY(M) = q_M
    sp.diff(p, Y, 2).subs(S) - qS,      # p_YY(S) = q_S
]
sol = sp.solve(eqs, coeffs, dict=True)
check("B1_setup_unique_solution", len(sol) == 1)
sol = sol[0]

# B1g(i): coefficient poles are axis strata only; finite on the collision locus
dens = sp.Integer(1)
for v in sol.values():
    dens = sp.lcm(dens, sp.denom(sp.together(v)))
dens_f = sp.factor(dens)
print("  lcm of coefficient denominators:", dens_f)
check("B1g_i_coefficient_poles_axis_strata_only", set(dens_f.free_symbols) <= {c, s})
vals_at_collision = [sp.simplify(v.subs(eta, 2*c)) for v in sol.values()]
check("B1g_ii_coeffs_finite_at_2c=eta",
      all(not v.has(sp.zoo, sp.nan) for v in vals_at_collision))
check("B1g_iii_kappa2_coeff_vanishes_on_collision",
      sp.factor((4*c**2 - eta**2)**2) == (2*c - eta)**2*(2*c + eta)**2)

pS = p.subs(sol)
H = sp.Matrix([[sp.diff(pS, X, 2), sp.diff(sp.diff(pS, X), Y)],
               [sp.diff(sp.diff(pS, X), Y), sp.diff(pS, Y, 2)]])
detH_M = sp.together(sp.simplify(H.subs(M).det()))
detH_S = sp.together(sp.simplify(H.subs(S).det()))
detH_P = sp.together(sp.simplify(H.subs(Pt).det()))

numM_disp = (kappa**2*(4*c**2 - eta**2)**2
             + 4*kappa*s**2*((12*c**2 + eta**2)*qM + (4*c**2 - eta**2)*qS)
             + 4*s**4*(qM - qS)**2)
numS_printed_v2 = (kappa**2*(4*c**2 - eta**2)**2
             + 4*kappa*s**2*((4*c**2 - eta**2)*qM + (12*c**2 + eta**2)*qS)
             + 4*s**4*(qM - qS)**2)          # as printed in 04 A1 ("+" bracket)
numS_true = (kappa**2*(4*c**2 - eta**2)**2
             - 4*kappa*s**2*((4*c**2 - eta**2)*qM + (12*c**2 + eta**2)*qS)
             + 4*s**4*(qM - qS)**2)          # script transcript / this derivation

def match(expr, target, name):
    d = sp.simplify(sp.factor(sp.together(expr - target)))
    if d == 0:
        check(name + "_generic_c_s", True); return
    # retry modulo c^2 + s^2 = 1
    d2 = sp.simplify(d.subs(s**2, 1 - c**2))
    tag = name + "_mod_c2+s2=1"
    check(tag, sp.simplify(d2) == 0)

match(-detH_M, numM_disp/(64*c**2*s**2), "B1a_-detH_M_matches_display")
match(-detH_S, numS_true/(64*c**2*s**2), "B1b_-detH_S_matches_transcript_form")
nS_chk = sp.expand(sp.cancel(-detH_S*64*c**2*s**2))
finding = sp.simplify(sp.expand(nS_chk - numS_printed_v2)) != 0
check("B1b3_v2_appendix_printed_sign_differs_(FINDING_F2)", finding)
if finding:
    print("  FINDING_F2_CONFIRMED: 04 A1 -det H_S display has '+' on the kappa-linear")
    print("  bracket; transcript and independent derivation give '-'. Difference =")
    print("  ", sp.factor(sp.expand(numS_printed_v2 - nS_chk)))

# B1c: denominators
nM, dM = sp.fraction(sp.cancel(-detH_M))
nS, dS = sp.fraction(sp.cancel(-detH_S))
nP, dP = sp.fraction(sp.cancel(detH_P))
print("  endpoint denominators:", sp.factor(dM), "|", sp.factor(dS))
print("  third-point denominator:", sp.factor(dP))
unit = lambda d, ref: sp.simplify(d/ref).is_constant() and sp.simplify(d/ref) != 0
check("B1c_endpoint_denoms_64c2s2", unit(dM, 64*c**2*s**2) and unit(dS, 64*c**2*s**2))
check("B1c_thirdpoint_denom_64c2_eta_s2", unit(dP, 64*c**2*eta*s**2))

# normalize numerators to the displayed denominators
nM = sp.expand(sp.cancel(-detH_M*64*c**2*s**2))
nS = sp.expand(sp.cancel(-detH_S*64*c**2*s**2))
nPn = sp.expand(sp.cancel(detH_P*64*c**2*eta*s**2))

# B1d / B1e on the endpoints
check("B1d_kappa2_coeff_(4c2-eta2)^2",
      sp.simplify(sp.expand(nM.coeff(kappa, 2) - (4*c**2 - eta**2)**2)) == 0 and
      sp.simplify(sp.expand(nS.coeff(kappa, 2) - (4*c**2 - eta**2)**2)) == 0)
check("B1e_kappa0_term_4s4(qM-qS)^2",
      sp.simplify(sp.expand(nM.coeff(kappa, 0) - 4*s**4*(qM - qS)**2)) == 0 and
      sp.simplify(sp.expand(nS.coeff(kappa, 0) - 4*s**4*(qM - qS)**2)) == 0)
check("B1b2_reflection_law_nS=nM(-kappa,-c,q-swap)",
      sp.simplify(sp.expand(nS - nM.subs({kappa: -kappa, c: -c, qM: qS, qS: qM},
                                         simultaneous=True))) == 0)

# B1f: product degree in kappa
prod_num = sp.expand(nM*nS*nPn)
check("B1f_product_exact_degree_6_in_kappa",
      sp.Poly(prod_num, kappa).degree() == 6 and sp.simplify(prod_num.coeff(kappa, 6)) != 0)

# B1h: eta -> 0 non-vanishing (LS-DER-024 normalization not recovered)
nM0 = sp.expand(nM.subs(eta, 0))
check("B1h_eta0_kappa2_leading_16c4", sp.simplify(nM0.coeff(kappa, 2) - 16*c**4) == 0)
check("B1h_no_per-Hessian_kappa2eta2_factor", sp.simplify(nM0) != 0)

print("ALL_ASSERTIONS_PASS" if ok else "ASSERTION_FAILURES_PRESENT")
