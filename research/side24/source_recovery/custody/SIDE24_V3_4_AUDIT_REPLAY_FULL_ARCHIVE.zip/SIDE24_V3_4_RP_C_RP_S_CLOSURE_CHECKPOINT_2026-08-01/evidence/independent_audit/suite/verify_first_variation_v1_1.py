"""verify_first_variation_v1_1.py -- Independent verification (2026-07-31, Claude/Anthropic).

Rebuilt 2026-07-31 after session interruption (the two d^4 perturbation
lines between S1 and the d^6 block are reconstructed by the same
one-perturbed-factor rule the recovered d^6 lines use; S3b validates the
reconstruction against the stated closed form).

Independently re-derives, from first principles, the six-nearest-image first
variation of the coefficient functional (Appendix Module H, Section 4), i.e.

    DF(J_0)[J_near^(1)] = P_3(L) e^{-L^2/2},
    P_3(L) = -L^2 (10 L^4 - 147 L^2 + 315) / 105,   P_3(24) = -620813376/35.

Derivation encoded here (independent of the author's scripts):

  Step 1. The side-L periodized kernel is the product of three 1-D periodized
     kernels. With q = e^{-L^2/2}, the normalized 1-D even derivative moments
     to first order in q are
         m_{2j} = He_{2j}(0) + 2 q (He_{2j}(L) - He_{2j}(0)) + O(q^4-scale),
     where He_k is the probabilists' Hermite polynomial, because
     (d/dz)^k e^{-z^2/2} = (-1)^k He_k(z) e^{-z^2/2} and the normalization
     Z_L = 1 + 2q + ... divides out (Module G (2)-(3)).

  Step 2. The 3-D jet perturbation from the six images +/- L e_i is assembled
     from products of 1-D moments; only one factor per entry is perturbed at
     first order.

  Step 3. Phi is O(3)-invariant and J_0 is O(3)-fixed, so DF(J_0) sees only
     the Haar rotational projection of the perturbation.  The projection of an
     even jet is characterized by its three isotropic radial moments
         a   = second spectral moment  = -<d^2_v K>(0),
         m4  = fourth spectral moment  = +<d^4_v K>(0),
         chi = sixth spectral moment   = -<d^6_v K>(0),
     with spherical averages
         <d^2_v> = (1/3) sum_i d_ii,
         <d^4_v> = (1/5) sum_i d_iiii + (2/5) sum_{i<j} d_iijj,
         <d^6_v> = (1/7) sum_i d_i^6 + (3/7) sum_{i != j} d_i^4 d_j^2
                   + (6/7) d_112233.
     (Coefficients are the exact moments of a uniform unit vector on S^2,
      verified symbolically below.)

  Step 4. In the isotropic family, c = A * Omega^{2/3} m4^{1/2} a^{-13/6}
     (Module K (18), d = 3) with Omega = a chi - m4^2, so
         d log c = (2/3) dOmega/Omega + (1/2) dm4/m4 - (13/6) da/a.
     At the planar jet a = 1, m4 = 3, chi = 15, Omega = 6 this is
         d log c = dOmega/9 + dm4/6 - (13/6) da       (Module H (15)).

  The script performs Steps 1-4 symbolically in L and compares against
  P_3(L).  It also verifies the numerator/denominator identity
  -(2/21)L^6 + (7/5)L^4 - 3L^2 = -L^2(10L^4-147L^2+315)/105 and the value at
  L = 24.
"""
import sympy as sp

ok = True
def check(name, cond):
    global ok
    print(f"{name}: {'PASS' if cond else 'FAIL'}")
    ok = ok and bool(cond)

L, q = sp.symbols('L q', positive=True)
x = sp.symbols('x')

He = lambda k, z: sp.simplify((-1)**k * sp.exp(z**2/2) * sp.diff(sp.exp(-x**2/2), x, k).subs(x, z))

# --- Step 0: sphere moments of a uniform unit vector (verify the averaging weights)
th, ph = sp.symbols('theta phi')
v = sp.Matrix([sp.sin(th)*sp.cos(ph), sp.sin(th)*sp.sin(ph), sp.cos(th)])
def sphere_avg(expr):
    return sp.simplify(sp.integrate(sp.integrate(expr*sp.sin(th), (th, 0, sp.pi)), (ph, 0, 2*sp.pi))/(4*sp.pi))
check("S0a_<v1^2>=1/3", sphere_avg(v[0]**2) == sp.Rational(1, 3))
check("S0b_<v1^4>=1/5", sphere_avg(v[0]**4) == sp.Rational(1, 5))
check("S0c_<v1^2 v2^2>=1/15", sphere_avg(v[0]**2*v[1]**2) == sp.Rational(1, 15))
check("S0d_<v1^6>=1/7", sphere_avg(v[0]**6) == sp.Rational(1, 7))
check("S0e_<v1^4 v2^2>=1/35", sphere_avg(v[0]**4*v[1]**2) == sp.Rational(1, 35))
check("S0f_<v1^2v2^2v3^2>=1/105", sphere_avg(v[0]**2*v[1]**2*v[2]**2) == sp.Rational(1, 105))

# --- Step 1: perturbed 1-D moments to first order in q
h0 = {2*j: He(2*j, 0) for j in range(4)}          # 1, -1, 3, -15
dm = {2*j: 2*q*(He(2*j, L) - h0[2*j]) for j in range(4)}   # first-order normalized perturbation
check("S1_h0_values", [h0[0], h0[2], h0[4], h0[6]] == [1, -1, 3, -15])

# --- Step 2+3: first-order perturbation of the rotationally projected radial moments.
# One perturbed 1-D factor per entry; images +/- L e_i perturb only direction-i moments.
d2_ii   = dm[2]                       # per axis
d2_iiii = dm[4]                       # per axis (pure 4th moment in i)
d2_iijj = dm[2]*h0[2] + h0[2]*dm[2]   # per unordered pair {i,j}: axis-i images perturb the i-factor,
                                      # axis-j images perturb the j-factor
d6_iiiiii = dm[6]
d6_i4j2 = dm[4]*h0[2] + h0[4]*dm[2]   # per ordered pair (i,j), i!=j: axis-i images perturb m4 factor,
                                      # axis-j images perturb m2 factor
d6_112233 = 3*dm[2]*h0[2]**2          # three axes each perturb one m2 factor

avg_d2 = sp.Rational(1, 3)*3*d2_ii
avg_d4 = sp.Rational(1, 5)*3*d2_iiii + sp.Rational(2, 5)*3*d2_iijj      # 3 unordered pairs
avg_d6 = sp.Rational(1, 7)*3*d6_iiiiii + sp.Rational(3, 7)*6*d6_i4j2 + sp.Rational(6, 7)*d6_112233

# spectral moments: a = -<d2>, m4 = +<d4>, chi = -<d6>
da   = sp.expand(-avg_d2)
dm4  = sp.expand(+avg_d4)
dchi = sp.expand(-avg_d6)

check("S3a_da=-2L^2 q",   sp.simplify(da - (-2*L**2*q)) == 0)
check("S3b_dm4=6L^2(L^2-10)/5 q", sp.simplify(dm4 - sp.Rational(6, 5)*L**2*(L**2-10)*q) == 0)
check("S3c_dchi=30L^2(-L^4+21L^2-105)/35 q",
      sp.simplify(dchi - sp.Rational(30, 35)*L**2*(-L**4+21*L**2-105)*q) == 0)

# --- Step 4: logarithmic differential at (a,m4,chi)=(1,3,15), Omega=6
dOmega = sp.expand(15*da + 1*dchi - 2*3*dm4)      # dOmega = chi da + a dchi - 2 m4 dm4
dlogc = sp.expand(dOmega/9 + dm4/6 - sp.Rational(13, 6)*da)
P3_derived = sp.simplify(dlogc/q)
P3_stated = -L**2*(10*L**4 - 147*L**2 + 315)/105
check("S4a_P3(L)_matches_stated_closed_form", sp.simplify(P3_derived - P3_stated) == 0)
check("S4b_alt_form", sp.simplify(P3_stated - (-sp.Rational(2, 21)*L**6 + sp.Rational(7, 5)*L**4 - 3*L**2)) == 0)
check("S4c_P3(24)=-620813376/35", sp.nsimplify(P3_stated.subs(L, 24)) == sp.Rational(-620813376, 35))
check("S4d_dlog_from_general_powers",
      sp.simplify(sp.Rational(2, 3)/6 - sp.Rational(1, 9)) == 0 and
      sp.simplify(sp.Rational(1, 2)/3 - sp.Rational(1, 6)) == 0)  # (2/3)/Omega=1/9, (1/2)/m4=1/6 at planar

print("ALL_ASSERTIONS_PASS" if ok else "ASSERTION_FAILURES_PRESENT")
