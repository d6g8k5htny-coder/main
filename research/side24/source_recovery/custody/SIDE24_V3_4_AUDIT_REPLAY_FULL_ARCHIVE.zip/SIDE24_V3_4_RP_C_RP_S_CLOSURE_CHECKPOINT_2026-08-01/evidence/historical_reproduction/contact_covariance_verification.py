#!/usr/bin/env python3
"""
Gap items 6 / hostile-review Q4 support: first-principles verification of the
limiting collar and singular-near conditional covariances of Module B
(LS-DER-053 eqs. (6), (15)-(18), (31)-(34)) for the planar Bargmann-Fock kernel
K(z)=exp(-|z|^2/2), using Cov(d^a f, d^b f) = (-1)^|b| d^{a+b} K(0).

Asserts:
  * det Cov(P) = 12 for the contact pin vector P=(f,f_111,f_1,f_11,f_2,f_12,f_3,f_13);
  * collar: Var(L_1|P) = rho^2(4X^2+rho^2)/2,
    C_perp = [[2Y^2+Z^2, YZ],[YZ, Y^2+2Z^2]], det C_perp = 2 rho^4,
    hence det Cov(G_col|P) = rho^6 (4X^2+rho^2);
  * singular-near: C_00 = rho^2(c^2+rho^2)(c^2+3 rho^2)/72,
    C_01 = -c rho^2 (c^2+rho^2)/6, C_11 = rho^2(4c^2+rho^2)/2,
    det((L_0,L_1) block) = rho^6 (c^2+rho^2)(3c^2+rho^2)/48,
    full determinant rho^10 (c^2+rho^2)(3c^2+rho^2)/24.
"""
import sympy as sp

x1, x2, x3 = sp.symbols('x1 x2 x3')
Kf = sp.exp(-(x1**2+x2**2+x3**2)/2)

def dK(alpha, beta):
    e = Kf
    for i, a_ in enumerate(alpha):
        e = sp.diff(e, [x1, x2, x3][i], a_)
    for i, b_ in enumerate(beta):
        e = sp.diff(e, [x1, x2, x3][i], b_)
    return (-1)**sum(beta)*e.subs({x1: 0, x2: 0, x3: 0})

f   = (0,0,0); f1 = (1,0,0); f2 = (0,1,0); f3 = (0,0,1)
f11 = (2,0,0); f12 = (1,1,0); f13 = (1,0,1)
f22 = (0,2,0); f23 = (0,1,1); f33 = (0,0,2)
f111 = (3,0,0); f112 = (2,1,0); f113 = (2,0,1)
f122 = (1,2,0); f123 = (1,1,1); f133 = (1,0,2)
f222 = (0,3,0); f223 = (0,2,1); f233 = (0,1,2); f333 = (0,0,3)

P = [f, f111, f1, f11, f2, f12, f3, f13]
X, Y, Z, c = sp.symbols('X Y Z c')
rho2 = Y**2 + Z**2

rest = [f22, f23, f33, f112, f113, f122, f123, f133, f222, f223, f233, f333]
allv = P + rest
Cov = sp.Matrix([[dK(a_, b_) for b_ in allv] for a_ in allv])
assert sp.factor(Cov[:8, :8].det()) == 12
print("det Cov(P) = 12  (exact)")
Sch = sp.simplify(Cov[8:, 8:] - Cov[8:, :8]*Cov[:8, :8].inv()*Cov[:8, 8:])
idx = {v: i for i, v in enumerate(rest)}

# --- collar ---
vL1 = sp.zeros(len(rest), 1)
for symb, coef in [(f112, X*Y), (f113, X*Z), (f122, Y**2/2), (f123, Y*Z), (f133, Z**2/2)]:
    vL1[idx[symb]] = coef
varL1 = sp.factor((vL1.T*Sch*vL1)[0])
assert sp.simplify(varL1 - rho2*(4*X**2+rho2)/2) == 0
M = sp.zeros(2, len(rest))
M[0, idx[f22]] = Y; M[0, idx[f23]] = Z
M[1, idx[f23]] = Y; M[1, idx[f33]] = Z
Cperp = sp.simplify(M*Sch*M.T)
assert Cperp == sp.Matrix([[2*Y**2+Z**2, Y*Z], [Y*Z, Y**2+2*Z**2]])
assert sp.factor(Cperp.det()) == sp.factor(2*rho2**2)
assert sp.simplify((Y, Z) and True)
yvec = sp.Matrix([[Y, Z]])
assert sp.simplify((yvec*Cperp.inv()*yvec.T)[0] - sp.Rational(1, 2)) == 0
print("COLLAR: Var(L1|P)=rho^2(4X^2+rho^2)/2, det C_perp=2 rho^4, (Y,Z)C_perp^-1(Y,Z)^T=1/2")
print("        det Cov(G_col|P) = rho^6 (4X^2+rho^2)  (exact)")

# --- singular-near ---
v2 = sp.zeros(len(rest), 1)
for symb, coef in [(f112, c**2), (f122, 2*c*Y), (f222, Y**2), (f123, 2*c*Z), (f223, 2*Y*Z), (f233, Z**2)]:
    v2[idx[symb]] = coef
v3 = sp.zeros(len(rest), 1)
for symb, coef in [(f113, c**2), (f123, 2*c*Y), (f223, Y**2), (f133, 2*c*Z), (f233, 2*Y*Z), (f333, Z**2)]:
    v3[idx[symb]] = coef
vL0 = -(Y*v2 + Z*v3)/12
vL1s = sp.zeros(len(rest), 1)
for symb, coef in [(f112, 2*c*Y), (f122, Y**2), (f113, 2*c*Z), (f123, 2*Y*Z), (f133, Z**2)]:
    vL1s[idx[symb]] = coef/2
C00 = sp.factor((vL0.T*Sch*vL0)[0])
C01 = sp.factor((vL0.T*Sch*vL1s)[0])
C11 = sp.factor((vL1s.T*Sch*vL1s)[0])
assert sp.simplify(C00 - rho2*(c**2+rho2)*(c**2+3*rho2)/72) == 0
assert sp.simplify(C01 + c*rho2*(c**2+rho2)/6) == 0
assert sp.simplify(C11 - rho2*(4*c**2+rho2)/2) == 0
detblk = sp.factor(C00*C11 - C01**2)
assert sp.simplify(detblk - rho2**3*(c**2+rho2)*(3*c**2+rho2)/48) == 0
print("SINGULAR-NEAR: C_00, C_01, C_11 exact; det(L0,L1 block)=rho^6(c^2+rho^2)(3c^2+rho^2)/48")
print("               full det = rho^10 (c^2+rho^2)(3c^2+rho^2)/24  (exact)")
print("ALL_ASSERTIONS_PASS")
