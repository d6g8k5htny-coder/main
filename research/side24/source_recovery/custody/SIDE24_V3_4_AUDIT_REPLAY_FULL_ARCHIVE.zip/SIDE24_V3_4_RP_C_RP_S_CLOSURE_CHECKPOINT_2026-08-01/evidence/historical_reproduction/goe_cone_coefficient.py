#!/usr/bin/env python3
"""
Gap item 7 (first half): the GOE-plus-scalar cone moment
    D_2 = E[(det Q)^2 1{Q negative definite}],  Q = G_2 + sqrt(2/3) Z I_2,
with G_2 standard GOE_2 (diag N(0,2), off-diag N(0,1)) and Z ~ N(0,1) independent.

Method (displayed derivation, not black-box quadrature):
  1. Orthogonal invariance: eigenvalues (l1,l2) of G_2 have joint density
     C |l1-l2| exp(-(l1^2+l2^2)/4); Z shifts both eigenvalues by sZ, s=sqrt(2/3).
  2. The cone {Q < 0} is {Z < -max(l1,l2)/s}; det Q = (l1+sZ)(l2+sZ).
  3. The Z-integration uses exact truncated Gaussian moments
     M_0=Phi(m), M_1=-phi(m), M_2=M_0-m phi(m), M_3=-(m^2+2)phi(m),
     M_4=3 M_0-(m^3+3m) phi(m).
  4. The remaining (l1,l2)-integral is evaluated by adaptive quadrature and
     compared against the closed form 29/6 - sqrt(6).
Asserts agreement to 1e-6, plus the Euclidean jet objects Sigma_g=I_3,
Sigma_h=diag(3,1,1), sigma^2=1/24, eig(Gamma)={1,2,10/3}, the two equivalent
closed forms of c_{3,inf} and its 46-digit decimal, and P_3(24)=-620813376/35.
"""
import math
import numpy as np
from scipy.integrate import dblquad
from scipy.special import ndtr
import mpmath as mp
import sympy as sp

sq = math.sqrt(2/3)
sq2pi = math.sqrt(2*math.pi)

def inner(l1, l2):
    m = -max(l1, l2)/sq
    ph = math.exp(-m*m/2)/sq2pi
    M0 = ndtr(m)
    M1 = -ph
    M2 = M0 - m*ph
    M3 = -(m*m+2)*ph
    M4 = 3*M0 - (m**3 + 3*m)*ph
    A0, A1, A2 = l1*l2, (l1+l2)*sq, sq*sq
    return (A0**2*M0 + 2*A0*A1*M1 + (2*A0*A2+A1**2)*M2
            + 2*A1*A2*M3 + A2**2*M4)

def dens(l1, l2):
    return abs(l1-l2)*math.exp(-(l1*l1+l2*l2)/4)

Cn = 1.0/dblquad(lambda l2, l1: dens(l1, l2), -np.inf, np.inf,
                 lambda l1: -np.inf, lambda l1: np.inf, epsabs=1e-13)[0]
D2 = dblquad(lambda l2, l1: Cn*dens(l1, l2)*inner(l1, l2), -np.inf, np.inf,
             lambda l1: -np.inf, lambda l1: np.inf, epsabs=1e-11)[0]
target = 29/6 - math.sqrt(6)
assert abs(D2-target) < 1e-6, (D2, target)
print(f"D_2 adaptive quadrature = {D2:.12f}")
print(f"29/6 - sqrt(6)         = {target:.12f}   (|diff| < 1e-6)")

# Monte Carlo independence check (3e6 draws, tolerance 3e-3)
rng = np.random.default_rng(20260731)
N = 3_000_000
g1 = rng.normal(0, math.sqrt(2), N); g3 = rng.normal(0, math.sqrt(2), N)
g2 = rng.normal(0, 1, N); Zv = rng.normal(0, 1, N)
q1 = g1 + sq*Zv; q3 = g3 + sq*Zv
detv = q1*q3 - g2**2
sel = (q1+q3 < 0) & (detv > 0)
mc = float(np.mean(detv**2*np.where(sel, 1.0, 0.0)))
assert abs(mc-target) < 3e-3, mc
print(f"D_2 Monte Carlo        = {mc:.6f}  (|diff| < 3e-3)")

# Euclidean jet objects from K(z)=exp(-|z|^2/2)
x1, x2, x3 = sp.symbols('x1 x2 x3')
Kf = sp.exp(-(x1**2+x2**2+x3**2)/2)
def dK(alpha, beta):
    e = Kf
    for i, a_ in enumerate(alpha):
        e = sp.diff(e, [x1, x2, x3][i], a_)
    for i, b_ in enumerate(beta):
        e = sp.diff(e, [x1, x2, x3][i], b_)
    return (-1)**sum(beta)*e.subs({x1: 0, x2: 0, x3: 0})

f11, f12, f13 = (2,0,0), (1,1,0), (1,0,1)
f22, f23, f33 = (0,2,0), (0,1,1), (0,0,2)
h = [f11, f12, f13]; q = [f22, f23, f33]
Sh = sp.Matrix([[dK(a_, b_) for b_ in h] for a_ in h])
Sq = sp.Matrix([[dK(a_, b_) for b_ in q] for a_ in q])
Cqh = sp.Matrix([[dK(a_, b_) for b_ in h] for a_ in q])
Gamma = sp.simplify(Sq - Cqh*Sh.inv()*Cqh.T)
assert Sh == sp.diag(3, 1, 1)
assert sorted(Gamma.eigenvals().keys()) == [sp.Integer(1), sp.Integer(2), sp.Rational(10, 3)]
# Sigma_g = I_3, sigma^2 = 1/24
g = [(1,0,0), (0,1,0), (0,0,1)]
Sg = sp.Matrix([[dK(a_, b_) for b_ in g] for a_ in g])
assert Sg == sp.eye(3)
f111 = (3,0,0)
su = sp.Rational(dK(f111, f111), 144)
cug = sp.Matrix([[-dK(f111, (1,0,0))/12, 0, 0]])
sig2 = sp.simplify(su - (cug*Sg.inv()*cug.T)[0])
assert sig2 == sp.Rational(1, 24)
# Gamma equals law of (g1+sZ, g2, g3+sZ): covariance check
s2 = sp.Rational(2, 3)
Gmodel = sp.Matrix([[2+s2, 0, s2], [0, 1, 0], [s2, 0, 2+s2]])
assert sp.simplify(Gamma - Gmodel) == sp.zeros(3)
print("JET_OBJECTS: Sigma_g=I_3, Sigma_h=diag(3,1,1), sigma^2=1/24, eig(Gamma)={1,2,10/3},")
print("             q|h=0 law == G_2 + sqrt(2/3) Z I_2  (exact covariance match)")

# c_{3,inf}: both closed forms and the manuscript decimal
mp.mp.dps = 60
G16 = mp.gamma(mp.mpf(1)/6)
form1 = 2**(mp.mpf(1)/6)*3**(mp.mpf(1)/3)*(29*mp.sqrt(6)-36)*G16/(432*mp.pi**(mp.mpf(5)/2))
form2 = 2**(-mp.mpf(23)/6)*3**(-mp.mpf(8)/3)*(29*mp.sqrt(6)-36)*G16*mp.pi**(-mp.mpf(5)/2)
assert abs(form1-form2) < mp.mpf(10)**-55
dec = mp.nstr(form1, 47)
assert dec.startswith("0.0417759318405983433429366654285755564666815196")
print("c_3,inf =", mp.nstr(form1, 50))
print("  matches manuscript decimal and both closed forms (2^(1/6)3^(1/3)/432 vs 2^(-23/6)3^(-8/3))")

# P_3(L) and P_3(24)
L = sp.Symbol('L')
P3 = -L**2*(10*L**4-147*L**2+315)/105
assert sp.expand(P3 - (-sp.Rational(2,21)*L**6 + sp.Rational(7,5)*L**4 - 3*L**2)) == 0
assert sp.Rational(P3.subs(L, 24)) == -sp.Rational(620813376, 35)
print("P_3(L) = -L^2(10L^4-147L^2+315)/105 = -(2/21)L^6+(7/5)L^4-3L^2")
print("P_3(24) = -620813376/35  (exact)")
print("ALL_ASSERTIONS_PASS")
