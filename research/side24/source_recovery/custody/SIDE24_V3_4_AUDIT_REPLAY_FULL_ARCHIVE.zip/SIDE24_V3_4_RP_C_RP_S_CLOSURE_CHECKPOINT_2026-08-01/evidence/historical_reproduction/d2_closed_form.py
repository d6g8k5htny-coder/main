#!/usr/bin/env python3
"""Exact closed-form evaluation of the cone constant D_2 = E[(det Q)^2 1_{Q<0}]
for Q = G_2 + sqrt(2/3) Z I_2, G_2 standard GOE_2, Z standard normal independent.

Reduction (all steps exact):
  Eigenvalues of G_2: l1 >= l2, density C |l1-l2| exp(-(l1^2+l2^2)/4).
  Trace/difference coordinates T = l1+l2, D = l1-l2 >= 0 (jacobian 1/2):
    density proportional to D exp(-(T^2+D^2)/8); T ~ N(0,4) independent of D.
  det Q = ((T+2sZ)^2 - D^2)/4 with s^2 = 2/3, and Q negative-definite iff
    W := T + 2sZ < -D.  Since the integrand depends on T,Z only through
    W ~ N(0, 4 + 4s^2) = N(0, 20/3), for fixed D the problem is scalar:
    E[(W^2-D^2)^2 1_{W<-D}] = sw^4 M4(m) - 2 D^2 sw^2 M2(m) + D^4 M0(m),
    m = -D/sw, M_k standard truncated normal moments.
  The remaining half-line integrals int_0^inf D^k Phi(-cD) e^{-aD^2} dD
  (a = 1/8, c^2 = 3/20) with k odd are elementary by integration by parts;
  the phi-terms are pure Gaussian moments (b = a + c^2/2 = 1/5).

Result: D_2 = 29/6 - sqrt(6), exactly.  Prints ALL_ASSERTIONS_PASS.
"""
import sympy as sp
from sympy import Rational, sqrt, pi, symbols
from sympy.functions.combinatorial.factorials import factorial, factorial2

D = symbols('D', positive=True)
c2 = Rational(3, 20)          # c^2, cutoff m = -c D
a = Rational(1, 8)            # D-density exponent
b = a + c2/2                  # phi-term exponent = 1/5
assert b == Rational(1, 5)

P, E0 = symbols('P E0')       # P = Phi(-cD), E0 = exp(-c^2 D^2/2)
phim = E0/sqrt(2*pi)
msq = -sp.sqrt(c2)*D          # signed cutoff
M0 = P
M2 = P - msq*phim
M4 = 3*P - (msq**3 + 3*msq)*phim
sw2 = Rational(20, 3)
inner = sp.expand((sw2**2*M4 - 2*D**2*sw2*M2 + D**4*M0)/16)
w = D*sp.exp(-a*D**2)/4       # normalized D-density (integral 1 on half-line)
assert sp.integrate(w, (D, 0, sp.oo)) == 1
expr = sp.expand(w*inner)

# --- exact integration helpers ---
def G2i(i, bb):  # int_0^inf D^{2i} e^{-bb D^2} dD
    if i == 0:
        return sqrt(pi)/(2*sqrt(bb))
    return factorial2(2*i-1)*sqrt(pi)/(2**(i+1)*bb**(Rational(2*i+1, 2)))

def I_Phi_odd(j):  # int_0^inf Phi(-cD) D^{2j+1} e^{-aD^2} dD, by parts
    c = sp.sqrt(c2)
    Jj0 = factorial(j)/(2*a**(j+1))
    s = sum(a**i/factorial(i) * G2i(i, b)/sqrt(2*pi) for i in range(j+1))
    return Rational(1, 2)*Jj0 - c*factorial(j)/(2*a**(j+1))*s

I1, I3, I5 = (sp.simplify(I_Phi_odd(j)) for j in (0, 1, 2))
print("I1 =", I1, "\nI3 =", I3, "\nI5 =", I5)
assert I1 == 2 - sqrt(6)/2
assert I3 == 16 - 21*sqrt(6)/4
assert I5 == 256 - 747*sqrt(6)/8

# term-by-term integral of expr (coefficients read from the expansion)
K2, K4 = G2i(1, b), G2i(2, b)
D2 = sp.simplify(-Rational(5, 24)*I3 + Rational(1, 64)*I5 + Rational(25, 12)*I1
                 - sqrt(30)/(192*sqrt(pi))*K4 + 5*sqrt(30)/(48*sqrt(pi))*K2)
print("D_2 =", D2)
assert sp.simplify(D2 - (Rational(29, 6) - sqrt(6))) == 0

# cross-check against the manuscript decimal and independent MC scale
assert abs(float(D2) - 2.3838435905) < 1e-9
print("D_2 = 29/6 - sqrt(6)  EXACT (closed form proved)")
print("ALL_ASSERTIONS_PASS")
