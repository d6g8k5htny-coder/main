#!/usr/bin/env python3
"""
Gap item 6: displayed symbolic elimination for the two-dimensional triple-contact
chart (supplements the "universal two-dimensional elimination" invoked in
Module B, LS-DER-053, eq. (38)).

Chart (explicitly declared; pair distance scaled to 1):
  M=(-1/2,0), S=(1/2,0) critical; p(M)=0, p(S)=-kappa/6 (fold value gap);
  third critical point P=(c/eta, s/eta), c^2+s^2=1, eta = r/t;
  transverse endpoint curvatures p_YY(M)=q_M, p_YY(S)=q_S prescribed
  (in the application they are the O(1) transverse contact-law blocks).

Asserts:
  * unique solution of the 10x10 pin system;
  * exact displayed formulas for det H_M, det H_S, det H_P with denominators
    64 c^2 s^2 (endpoints) and 64 c^2 eta s^2 (third point);
  * angular singularities confined to the axis strata c=0, s=0 and the
    collision strata 2c = +/- eta;
  * endpoint determinants are exactly quadratic in (kappa, q_M, q_S) with
    kappa^2 coefficient (4c^2 -/+ eta^2)^2 / (64 c^2 s^2);
  * the exact product det H_M det H_S det H_P is degree <= 6 in kappa and
    carries the collision-cone factor (4c^2-eta^2)^4 eta^{-1} ... (printed).

RESIDUAL PREMISE (printed at end): matching the historical LS-DER-024
normalization det H = B kappa^2 eta^2/(64 c^2 s^2) requires the original
chart conventions, which are not recovered here; see supplement Section B.1.
"""
import sympy as sp

X, Y = sp.symbols('X Y')
c, s, eta, kappa = sp.symbols('c s eta kappa', nonzero=True)
qM, qS = sp.symbols('q_M q_S')
a = sp.symbols('a0:10')
monos = [1, X, Y, X**2, X*Y, Y**2, X**3, X**2*Y, X*Y**2, Y**3]
p = sum(ai*mi for ai, mi in zip(a, monos))
pX, pY = sp.diff(p, X), sp.diff(p, Y)
Mx, Sx = -sp.Rational(1, 2), sp.Rational(1, 2)
Pc, Pv = c/eta, s/eta

eqs = [
    sp.Eq(p.subs({X: Mx, Y: 0}), 0),
    sp.Eq(p.subs({X: Sx, Y: 0}), -kappa/6),
    sp.Eq(pX.subs({X: Mx, Y: 0}), 0), sp.Eq(pY.subs({X: Mx, Y: 0}), 0),
    sp.Eq(pX.subs({X: Sx, Y: 0}), 0), sp.Eq(pY.subs({X: Sx, Y: 0}), 0),
    sp.Eq(pX.subs({X: Pc, Y: Pv}), 0), sp.Eq(pY.subs({X: Pc, Y: Pv}), 0),
    sp.Eq(sp.diff(p, Y, 2).subs({X: Mx, Y: 0}), qM),
    sp.Eq(sp.diff(p, Y, 2).subs({X: Sx, Y: 0}), qS),
]
sol, = sp.solve(eqs, list(a), dict=True, simplify=True)
psub = sp.simplify(p.subs(sol))
H = sp.Matrix([[sp.diff(psub, X, 2), sp.diff(psub, X, Y)],
               [sp.diff(psub, X, Y), sp.diff(psub, Y, 2)]])

detM = sp.factor(H.subs({X: Mx, Y: 0}).det())
detS = sp.factor(H.subs({X: Sx, Y: 0}).det())
detP = sp.factor(H.subs({X: Pc, Y: Pv}).det())

# Structural assertions
# 1. endpoint determinants: common denominator 64 c^2 s^2
for name, d in (("M", detM), ("S", detS)):
    num, den = sp.fraction(d)
    assert sp.simplify(den - 64*c**2*s**2) == 0, (name, den)
    # 2. quadratic in (kappa, q_M, q_S); kappa^2 coefficient check
    num = sp.expand(num)
    k2 = sp.factor(num.coeff(kappa, 2))
    if name == "M":
        assert sp.simplify(-k2 - (4*c**2 - eta**2)**2) == 0, k2
    else:
        assert sp.simplify(-k2 - (4*c**2 - eta**2)**2) == 0, k2
    # 3. q-cross term: unique s^4 (q_M - q_S)^2 structure
    assert sp.simplify(num.coeff(qM, 2) - num.coeff(qS, 2)) == 0

# 4. third-point determinant: denominator 64 c^2 eta s^2
numP, denP = sp.fraction(detP)
assert sp.simplify(denP - 64*c**2*eta*s**2) == 0, denP

# 5. product: exact degree 6 in kappa (each determinant contributes <= kappa^2)
prod = sp.expand(detM*detS*detP)
assert sp.degree(prod, kappa) == 6

print("det H_M =", detM)
print("det H_S =", detS)
print("det H_P =", detP)
print("PRODUCT_DEGREE_IN_KAPPA = 6")
print("ANGULAR_SINGULARITIES: c=0, s=0, eta=0 (removable after rho blow-up), 2c=+/-eta (collision)")
print("ALL_ASSERTIONS_PASS")
print("RESIDUAL_PREMISE: historical LS-DER-024 normalization det H = B kappa^2 eta^2/(64 c^2 s^2)")
print("not recovered in this chart; see supplement Section B.1 for the reconciliation.")
