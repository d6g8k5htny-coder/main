#!/usr/bin/env python3
"""
verify_disposition_s3_v1.py -- independent audit of the 2026-07-31
disposition, section 3 ("Why the sign is load-bearing"), sections 4
(degree/collision precision) -- from MY OWN generic-cubic elimination,
not the package's normal form (2.1).

Fail-closed: every check raises SystemExit on failure (survives -O).
"""
import sys
import sympy as sp

ok = True
def ck(cond, msg):
    global ok
    if not cond:
        print("CHECK FAILED:", msg); sys.exit(1)
    print("[ok]", msg)

kap, eta, alpha, c, s = sp.symbols('kappa eta alpha c s', positive=True)
qM, qS = sp.symbols('q_M q_S')
X, Y = sp.symbols('X Y')

# ---- generic 10-coefficient cubic, my original pin system ----
a = sp.symbols('a0:10')
p = (a[0] + a[1]*X + a[2]*Y + a[3]*X**2 + a[4]*X*Y + a[5]*Y**2
     + a[6]*X**3 + a[7]*X**2*Y + a[8]*X*Y**2 + a[9]*Y**3)
pX, pY = sp.diff(p, X), sp.diff(p, Y)
pYY = sp.diff(p, Y, 2)
M = (-sp.Rational(1, 2), 0); S = (sp.Rational(1, 2), 0); P = (c/eta, s/eta)
def at(e, pt): return e.subs({X: pt[0], Y: pt[1]})
eqs = [at(p, M), at(p, S) + kap/6,
       at(pX, M), at(pY, M), at(pX, S), at(pY, S),
       at(pYY, M) - qM, at(pYY, S) - qS,
       at(pX, P), at(pY, P)]
sol = sp.solve(eqs, list(a), dict=True)
ck(len(sol) == 1, "S0 unique solution of the 10-pin system")
ps = sp.simplify(p.subs(sol[0]))
pXs, pYs = sp.diff(ps, X), sp.diff(ps, Y)
H = lambda pt: sp.Matrix([[at(sp.diff(ps, X, 2), pt), at(sp.diff(ps, X, Y), pt)],
                          [at(sp.diff(ps, X, Y), pt), at(sp.diff(ps, Y, 2), pt)]])
ndM = sp.simplify(-H(M).det()); ndS = sp.simplify(-H(S).det())
dHP = sp.simplify(H(P).det())

A = 4*c**2 - eta**2
ndS_true = (kap**2*A**2 - 4*kap*s**2*(A*qM + (12*c**2 + eta**2)*qS)
            + 4*s**4*(qM - qS)**2)/(64*c**2*s**2)
ck(sp.simplify(ndS - ndS_true) == 0, "S1 -det H_S = corrected B.1 (kappa-linear NEGATIVE)")

# ---- value pin p(P) = -alpha*kappa/6 : the disposition's relations ----
d_, m_ = sp.symbols('d m')
subdm = {qM: (m_ + d_)/2, qS: (m_ - d_)/2}
pP = sp.simplify(at(ps, P).subs(subdm))
m_sol = sp.solve(sp.Eq(pP, -alpha*kap/6), m_)
ck(len(m_sol) == 1, "V0 value pin solvable uniquely for m")
m_sol = sp.simplify(m_sol[0])
m_disp = (eta*d_ + kap*eta*((2*c + eta)**2 - 8*alpha*c*eta)/(2*s**2))/(2*c)
ck(sp.simplify(m_sol - m_disp) == 0,
   "V1 m = [eta d + kappa eta ((2c+eta)^2 - 8 alpha c eta)/(2s^2)]/(2c)  (disposition formula)")

u_def = (2*s**2*d_ + kap*(2*c + eta)**2)/(8*kap*c*eta)
d_of_u = sp.solve(sp.Eq(sp.Symbol('u'), u_def), d_)[0]
u = sp.Symbol('u')

def pin_and_u(expr):
    e = expr.subs(subdm).subs(m_, m_sol).subs(d_, d_of_u)
    return sp.simplify(sp.factor(sp.simplify(e)))

ndS_p = pin_and_u(ndS)
ndM_p = pin_and_u(ndM)
dHP_p = pin_and_u(dHP)
tS = kap**2*eta**2/s**2*((u - 1)**2 - (1 - alpha))
tM = kap**2*eta**2/s**2*(u**2 - alpha)
tP = -kap**2*eta**2/s**2*((u - alpha)**2 + alpha*(1 - alpha))
ck(sp.simplify(ndS_p - tS) == 0, "V2 pinned -det H_S = (k^2 e^2/s^2)((u-1)^2-(1-alpha))")
ck(sp.simplify(ndM_p - tM) == 0, "V3 pinned -det H_M = (k^2 e^2/s^2)(u^2-alpha)")
ck(sp.simplify(dHP_p - tP) == 0, "V4 pinned det H_P = -(k^2 e^2/s^2)((u-alpha)^2+alpha(1-alpha))")

# ---- the printed (+) sign under the SAME value pin ----
ndS_printed = (kap**2*A**2 + 4*kap*s**2*(A*qM + (12*c**2 + eta**2)*qS)
               + 4*s**4*(qM - qS)**2)/(64*c**2*s**2)
ndSp_p = pin_and_u(ndS_printed)
lim_printed = sp.simplify(sp.limit(ndSp_p, eta, 0))
ck(sp.simplify(lim_printed - c**2*kap**2/s**2) == 0,
   "V5 printed(+) sign, value-pinned, fixed u: lim_{eta->0} -det H_S = c^2 k^2/s^2  (NOT O(eta^2))")
lim_true = sp.simplify(sp.limit(ndS_p, eta, 0))
ck(lim_true == 0, "V6 corrected(-) sign, value-pinned, fixed u: lim_{eta->0} -det H_S = 0 (eta^2 factor)")
ser = sp.simplify(sp.series(ndSp_p, eta, 0, 1).removeO())
ck(sp.simplify(ser - c**2*kap**2/s**2) == 0,
   "V7 printed(+) leading term is exactly c^2 k^2/s^2 + O(eta)")

# ---- degree-in-kappa: generic vs the leading-coefficient zero locus ----
def kdeg(e):
    n, _ = sp.fraction(sp.cancel(sp.together(e)))
    return sp.degree(sp.expand(n), kap)
prod_raw = sp.cancel(sp.together(ndM*ndS*dHP))
ck(kdeg(prod_raw) == 6, "D1 raw unpinned three-factor product: generic kappa-degree 6")
prod_col = sp.cancel(sp.together(prod_raw.subs(eta, 2*c)))
dcol = kdeg(prod_col)
ck(dcol < 6, f"D2 at 2c=eta the kappa-degree DROPS (observed degree {dcol}) -- 'exact degree 6' is not uniform")
print("     observed kappa-degree at 2c=eta:", dcol)

# ---- collision geometry: coefficient-degeneracy loci are not collisions ----
PS2 = sp.simplify((P[0] - sp.Rational(1, 2))**2 + P[1]**2)
PM2 = sp.simplify((P[0] + sp.Rational(1, 2))**2 + P[1]**2)
ck(sp.simplify(PS2 - ((2*c - eta)**2 + 4*s**2)/(4*eta**2)) == 0,
   "D3 |P-S|^2 = ((2c-eta)^2+4s^2)/(4 eta^2)")
ck(sp.simplify(PM2 - ((2*c + eta)**2 + 4*s**2)/(4*eta**2)) == 0,
   "D4 |P-M|^2 = ((2c+eta)^2+4s^2)/(4 eta^2)")
ck(sp.simplify(PS2.subs(eta, 2*c) - s**2/(4*c**2)) == 0,
   "D5 at 2c=eta: |P-S|^2 = s^2/(4c^2) > 0 for s!=0 -- degeneracy locus, not a collision (collision needs s=0)")

print("ALL_ASSERTIONS_PASS")
