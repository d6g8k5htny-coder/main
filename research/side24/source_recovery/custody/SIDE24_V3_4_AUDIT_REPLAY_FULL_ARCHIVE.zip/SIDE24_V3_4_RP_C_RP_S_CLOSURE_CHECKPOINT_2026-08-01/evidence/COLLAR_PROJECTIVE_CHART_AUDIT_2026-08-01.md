# SIDE24 collar projective-chart audit note

**Date:** 2026-08-01  
**Scope:** exact quotient expansions for the collar axial-interior,
midpoint, and axial-endpoint faces. This records the derivation of the
lettered displays added to the facewise-closure draft and does not change
package status.

Let

\[
 M=x-rt/2,\qquad S=x+rt/2,\qquad
 y=x+r(\zeta t+\rho v),\qquad w\perp\{t,v\},
\]

and center after conditioning on the corrected pair-pin vector \(V_r\).
Modulo the limiting contact-pin span

\[
 \mathcal P=\operatorname{span}\{1,T,E,W,T^2,TE,TW,T^3\},
\]

the exact corrected gradient residuals have expansions

\[
\begin{aligned}
r^{-2}D_t\widetilde f(y)
={}&\rho\zeta T^2E+\frac{\rho^2}{2}TE^2\\
&+r\left[-\frac{\rho}{24}T^3E-\frac{\zeta}{24}T^4
 +\frac{\rho^3}{6}TE^3+\frac{\zeta\rho^2}{2}T^2E^2
 +\frac{\zeta^2\rho}{2}T^3E+\frac{\zeta^3}{6}T^4\right]\\
&+r^2\left[\frac1{1920}T^5+O_{L^2}(|\zeta|+\rho)\right]
 +O_{L^2}(r^3),\\
r^{-1}D_v\widetilde f(y)
={}&\rho E^2+r\left[-\frac18T^2E+\frac{\rho^2}{2}E^3
 +\zeta\rho TE^2+\frac{\zeta^2}{2}T^2E\right]+O_{L^2}(r^2),\\
r^{-1}D_w\widetilde f(y)
={}&\rho EW+r\left[-\frac18T^2W+\frac{\rho^2}{2}E^2W
 +\zeta\rho TEW+\frac{\zeta^2}{2}T^2W\right]+O_{L^2}(r^2).
                                                               \tag{A.1}
\end{aligned}
\]

These are expansions of exact divided differences in the spectral Hilbert
space, not a replacement of the side-24 covariance by the Euclidean one.
Exponential spectral decay makes the remainders uniform in the pair frame.

## Axial-interior face

Put \(A_\zeta=\zeta^2-1/4\),
\(\epsilon_a=(r^2+\rho^2)^{1/2}\), \(R=r/\epsilon_a\), and
\(P=\rho/\epsilon_a\). When \(\zeta\) is separated from
\(0,\pm1/2\), (A.1) gives the normalized rows

\[
 P\zeta T^2E+R\frac{\zeta A_\zeta}{6}T^4,\qquad
 PE^2+R\frac{A_\zeta}{2}T^2E,\qquad
 PEW+R\frac{A_\zeta}{2}T^2W.                              \tag{A.2}
\]

They are independent modulo \(\mathcal P\) on the whole quarter-circle
\(R^2+P^2=1\). The \(P=0\) face has distinct symbols
\(T^4,T^2E,T^2W\). If \(P>0\), the \(W\) and \(E^2\) monomials
successively isolate the last two rows, after which the first row is
nonzero. Consequently

\[
 \det\operatorname{Cov}(\nabla f(y)\mid V_r)
 \asymp r^8\epsilon_a^6.                                  \tag{A.3}
\]

The target mean obeys

\[
 D_t\mathbb E[f(y)\mid V_r]
 =\kappa r^2(\zeta^2-1/4)+O(r^2\rho+r^3),                  \tag{A.4}
\]

so its Mahalanobis distance is at least
\(c\kappa^2/\epsilon_a^2\).

## Midpoint face

At the simultaneous midpoint corner define

\[
 \epsilon_m=(r^2+\rho^2)^{1/2},\qquad
 \delta_m^2=(\rho\zeta)^2+\rho^4+(r\rho)^2+(r\zeta)^2+r^4
\]

and projectivize the five displayed monomials by

\[
 (a_1,\ldots,a_5)=\delta_m^{-1}
 (\rho\zeta,\rho^2,r\rho,r\zeta,r^2).
\]

Equation (A.1) yields the three boundary rows

\[
\begin{aligned}
 &a_1T^2E+\frac{a_2}{2}TE^2-\frac{a_3}{24}T^3E
       -\frac{a_4}{24}T^4+\frac{a_5}{1920}T^5,\\
 &P_mE^2-\frac{R_m}{8}T^2E,\qquad
 P_mEW-\frac{R_m}{8}T^2W,                                \tag{A.5}
\end{aligned}
\]

where \(R_m=r/\epsilon_m\) and \(P_m=\rho/\epsilon_m\). If \(P_m>0\),
the \(EW\) and \(E^2\) monomials isolate the last two rows and the first
cannot vanish because \(\sum a_j^2=1\). If \(P_m=0\), the projective
relations give \(a_1=a_2=a_3=0\), while
\((a_4,a_5)\ne(0,0)\); the rows then have distinct
\(T^4/T^5,T^2E,T^2W\) content. After choosing the midpoint chart small
enough to absorb the higher terms in (A.1),

\[
 \det\operatorname{Cov}(\nabla f(y)\mid V_r)
 \asymp r^8\delta_m^2\epsilon_m^4,\qquad
 \mu^TC^{-1}\mu\ge c\kappa^2/\delta_m^2.                  \tag{A.6}
\]

At \(\zeta=\rho=0\), this is the exact \(r^{16}\) determinant scale and
the \(e^{-c/r^4}\) penalty.

## Axial endpoint

Write \(y=M+du\), with \(\rho=|t\wedge u|\le2r\). The two
critical-point identities at \(M,y\) make \(u\) an \(O(d)\) domain column
at both Hessians; the pair identity makes \(t\) an \(O(r)\) column at
\(S\). In orthonormal domain frames,

\[
 |\det H_M\det H_S\det H_y|\le Crd^2P(J).                 \tag{A.7}
\]

The normalized endpoint gradient density is
\(O(d^{-3}r^{-4}e^{-c/r^2})\). Value marginalization therefore leaves a
genuine \(d^{-1}\) factor. With \(dy=d^2\,dd\,d\omega\), angular-cap
area \(O(r^2)\), and \(Z_r^{-1}=O(r^{-2})\),

\[
 Z_r^{-1}\int_{\rho\le2r}\int_0^{\delta r}
 d^2[d^{-1}r^{-3-N}e^{-c/r^2}]\,dd\,d\omega
 \le Cr^{-1-N}e^{-c/r^2}=O(r^3).                          \tag{A.8}
\]

Thus the endpoint divisor requires a measure-level ledger; it is not a
pointwise instance of the common \(\mathcal D\) envelope.
