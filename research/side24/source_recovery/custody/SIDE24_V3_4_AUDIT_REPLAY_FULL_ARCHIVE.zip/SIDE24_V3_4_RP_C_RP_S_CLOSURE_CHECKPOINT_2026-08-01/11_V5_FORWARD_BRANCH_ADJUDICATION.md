# SIDE24 V3.3 — V5 forward-branch adjudication

**Adjudication date:** 2026-08-01 (America/Chicago)  
**Input identity:** `OKComputer_Project_Gap_Closure(1).zip`  
**SHA-256:** `119ffbfae2d11cc2d3de60f15c06a653c48b17d06ab0a2e125260ab0f1458c5a`  
**Verdict:** **PARTIAL ACCEPTANCE; HOLD remains.**

The supplied archive is preserved verbatim under
`evidence/v5_forward_branch/`.  It is an auditable forward-work branch, not a
provenance-complete successor to V3.2.  V3.3 integrates the parts that survive
independent checking, repairs the Palm argument, and rejects the claims that
regress beyond V3.2.

## 1. What verifies exactly

- The ZIP contains 128 regular files and passes CRC validation.
- The V5 manifest is exact: all 127 non-self payload hashes match, its
  self-prefix hash matches, and every archive path occurs exactly once.
- All twelve delivered scripts pass in normal and optimized Python; all 24
  fresh outputs are byte-identical to their committed transcripts.
- Verifier v7 passes 23/23 and v8 passes 30/30 in both modes.  The scripts use
  explicit raising checks rather than disableable bare assertions.
- The exact endpoint kernel, endpoint determinant factor
  `det H_p = r D_p`, corrected-pin target, and local contact covariance
  identities are useful forward progress.
- V5 correctly keeps RP-C, RP-S, uniform elder selection, and the candidate
  theorem open.

These facts establish reproducibility and several local identities.  They do
not by themselves prove the theorem-level status strings searched by v8.

## 2. Package-lineage correction

V5's version-specific directories are new, but its shared
`SIDE24_gap_fill/` tree is mutable.  Relative to the prior V4 state, two
existing shared paths were overwritten and nineteen evidence paths were added.
Consequently:

| Manifest | Result against this archive | Meaning |
|---|---:|---|
| V5 | 127/127 payloads | exact current-state manifest |
| V4 | 106/108 payloads | supplement source and verifier README no longer match |
| V3 | 24/37 payloads | thirteen historical referents no longer match |

The overwritten historical byte sequences are not stored elsewhere in the
archive.  The phrase "nothing was overwritten" is therefore false for the
shared evidence tree.  V5 also omits the controlling V3.2 archive, its hash,
the audit-reconciliation response, the package-scope matrix, and the V3.2
fixed-distance audit.  It is a parallel branch and cannot silently replace
V3.2.

The V5 date is also ambiguous: directory and title use 2026-08-02, while the
explicit document date and CDT creation metadata use 2026-08-01.  V3.3 uses
the declared America/Chicago date and records the source labels verbatim.

## 3. G.8 global RP-F claim is rejected

V5 G.8 asserts

\[
 \|L_r(b,\kappa)\|^2\ge \tfrac12(b^2+\kappa^2).
\]

For its displayed corrected target

\[
 L_r=(b-\kappa r^3/12,0,\ldots,0,-\kappa/6),
\]

the assertion is false.  At \(b=0\) and \(r\downarrow0\), the ratio tends to
\(1/36\), not a number at least \(1/2\).  For \(0<r\le1\), the safe elementary
joint-target bound is

\[
 \|L_r(b,\kappa)\|^2\ge \frac1{37}(b^2+\kappa^2).
\]

More importantly, the remote Kac--Rice density under the pair-conditioned law
is

\[
 \frac{p_{P,R}(L_r,a)}{p_P(L_r)},
\]

not the joint density \(p_{P,R}(L_r,a)\).  Dividing by the pair-pin density can
cancel the claimed Gaussian penalty in \((b,\kappa)\).  G.8 supplies no
coercive Schur-residual estimate that would restore it, and such a global Palm
penalty is generally false.

The correct proof-level statement is the V3.2 compact-positive-mark RP-F
bound.  The global lifetime integral is controlled without a global Palm
penalty by retaining the all-pair Kac--Rice factor:

\[
 (p_P Z_r)\,\mathbb E^{MS}N_{\rm far}
 =p_P\,\mathbb E^0[W_rN_{\rm far}].
\]

The right-hand side is an unnormalized joint Kac--Rice numerator, so its joint
target density legitimately provides Gaussian mark decay.  This repairs the
integrated interface while refusing the false stronger conditional claim.

## 4. Palm-transfer proof repair

V5 G.1--G.7 contain the right architecture, but several printed steps are not
valid as written:

1. A function vanishing on a lattice need not vanish identically as an entire
   function.  Spectral independence instead follows because the Fourier
   coefficients of a finite distribution determine that distribution on the
   torus.
2. The raw-to-corrected pin map has unbounded shear coefficients in its final
   row; the claimed bounded off-diagonal triangular equivalence is false.
   Direct \(L^2\) convergence of the corrected vector supplies the required
   eigenfloor.
3. G.2.1 must be applied to
   \(h_i(s)=\partial_{ti}f(x+st)\), whose integral is zero under the gradient
   pins, not to \(h_i(s)=\partial_i f(x+st)\).
4. The contact-limit endpoint rows are neither centered nor jointly
   nondegenerate.  Under the corrected target,
   \(\alpha_M\to-\kappa\), \(\alpha_S\to\kappa\), and
   \(Q_M,Q_S\to Q\).  The correct normalizer limit is
   \[
   r^{-2}W_r\longrightarrow
   \kappa^2(\det Q)^2\mathbf1_{\{Q\prec0\}}.
   \]
5. G.4.1 defines \(\lambda_*=\lambda_{\min}(-Q_S)\) and then uses it to
   bound \(D_M\).  That is false without the omitted bridge
   \(\|Q_M-Q_S\|\le rP(U)\) and Weyl's inequality.
6. G.4.2 treats one specific threshold, while G.7 needs the higher-degree
   random threshold generated by \(R(U)^5\).  A uniform polynomial-threshold
   Gaussian tube lemma is required.
7. Failure of \(rR^5\le\varepsilon_0\) is controlled at
   \(R\asymp r^{-1/5}\), not by merely taking a tail threshold \(r^{-1}\).

`drafts/palm_transfer_repair_v3_3.md` supplies all seven repairs.  Its conclusion
is that, uniformly on compact positive mark sets,

\[
 \mathbb P^{MS}(A^c)\le C_Ar^3,
 \qquad
 \mathbb P^{MS}(F_{\rm self})\le C_Lr^3.
\]

Thus RP-A and RP-L are accepted as **proved with the V3.3 repair**, not as
proved by the text of V5 G.7 alone.

## 5. Collar normalization regression

V5's fixed-\(r\), \(\rho\downarrow0\) numerical probe does not test the joint
corner \(r,\rho\downarrow0\).  The exact local contact covariance already in
the evidence gives, with \(\varrho^2=Y^2+Z^2\),

\[
 \det C_{\rm col}=\varrho^6(4X^2+\varrho^2).
\]

Under the joint scaling \((X,Y,Z)=r(x,y,z)\), this is generically \(r^8\),
not \(r^6\), and it vanishes identically on the pair axis
\(Y=Z=0\).  Therefore the V5 sentence claiming a positive limiting
\(\rho^{-6}\) coefficient at every compactified direction, including the
axis, is false.  Its own numerical script fixes \(r=0.4\), so it cannot see
this degeneration.

The singular-near local determinant likewise has the anisotropic factor

\[
 \frac{\varrho^{10}(c^2+\varrho^2)(3c^2+\varrho^2)}{24}.
\]

The correct remaining gate is a stratified anisotropic compactification, not
an isotropic \(\rho^6A\) floor.  The repaired target and exact regression are
in `drafts/joint_collar_compactification_target.md` and
`scripts/verify_joint_collar_regression.py`.

## 6. Controlling status after V3.3

| Interface | V3.3 status |
|---|---|
| RP-A — adjacency failure | **PROVED WITH V3.3 PALM REPAIR** |
| RP-L — same-component attachment | **PROVED WITH V3.3 PALM REPAIR** |
| RP-F — fixed-distance witness | **PROVED on compact positive marks; integrated all-mark numerator repaired** |
| Global Gaussian decay of the Palm-conditioned RP-F expectation | **REJECTED / not needed** |
| RP-C — collar witness | **OPEN** |
| RP-S — singular-near witness | **OPEN** |
| Uniform elder selection | **CONDITIONAL on RP-C and RP-S** |
| Candidate theorem | **HOLD** |

The project has therefore genuinely reduced the probabilistic HOLD to the two
regional third-witness estimates, but only after replacing V5's Palm and
collar arguments with the corrected statements above.

## 7. Next exact work order

1. Resolve the generic collar face with the normalization
   \(\varrho^6(4X^2+\varrho^2)\), uniformly for the side-24 covariance.
2. Blow up the axial face \(\varrho=0\) separately; do not infer it by
   compactness from the generic face.
3. Repeat for the singular-near determinant with the two factors
   \(c^2+\varrho^2\) and \(3c^2+\varrho^2\), including the mean-mismatch
   penalty on the collinear chart.
4. Prove the compatible three-Hessian conditional moment envelope on each
   face and perform the six-term radial/angular integral.
5. Only after RP-C and RP-S pass independent review may the elder-selection
   estimate or candidate theorem be promoted.
