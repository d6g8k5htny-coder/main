# Disposition of the uploaded V2 gap-fill package

The V2 attachment is retained as provenance, not as a controlling proof
source.  Its advertised all-gap closure is withdrawn for the reasons below.

## Rejected or superseded claims

1. **Elder mark.**  For the local index-two model
   \(f(x,y,z)=z^2-x^2-y^2\), the two upper probes have maximin connection
   level exactly the saddle height \(h=0\).  Every connecting path crosses
   \(z=0\), while the axial path attains minimum zero.  Thus the V2 test
   \(\mathfrak m<h\) is false in the canonical model.  Its use of
   \(g(z)\mathbf1_{\{\cdots\}}\) also creates a spurious zero floor when
   all relevant maxima are negative.  The replacement is
   `drafts/elder_mark_and_exhaustion.md`.

2. **Failure trichotomy.**  V2 mixes distance from \(\{M,S\}\) with distance
   from the midpoint, leaving overlaps and uncovered sets.  V3 uses one
   distance function and assigns both boundaries explicitly.

3. **Off-diagonal rate.**  The mass of a lifetime window is proportional to
   its width, but division by that width produces a density.  V2's extra
   factor of \(\ell\) therefore does not follow.  The valid separated-pair
   estimate is the baseline uniform \(O(1)\) bound, which is already
   sufficient for \(o(\ell^{-1/3})\).

4. **Cubic determinant display.**  The printed \(-\det H_S\) formula has the
   wrong sign in its \(\kappa\)-linear term.  More importantly, the ten-pin
   interpolation omitted the third critical point's value constraint and
   therefore is not the load-bearing triple-contact system.  V3 checks the
   sign defect and supplies the constrained elimination separately.

5. **Capture/escape.**  V2 compares an absolute \(rR\) error with a margin
   vanishing like \(\xi\), asserts the false inequality
   \(h(-1/2+\delta_0)\ge\delta_0\), and invokes an invariant-ball estimate
   with an unspecified remainder constant.  V3 restores the tapered tube and
   uses the endpoint pins to obtain distance-weighted errors.

6. **Probabilistic closure.**  Contact-limit covariance and cubic identities
   do not prove uniform finite-\(r\) side-24 bounds.  The joint blown-up chart,
   every new boundary face, angular integration, determinant envelopes, and
   determinant-weighted Palm transfer must still be proved.

7. **Package integrity.**  V2 is dated 2026-08-01 although this checkpoint is
   frozen on 2026-07-31, its combined packet omits baseline material, its
   manifest is stale, and its verifier is a string linter tied to a hardcoded
   path.  Those files cannot serve as mathematical or archival certification.

## Retained computational facts

Several V2 scripts reproduce useful exact identities already present in the
R2 baseline, including \(D_2=29/6-\sqrt6\), the first-variation polynomial,
and limiting contact covariances.  Those identities remain usable within
their declared scopes.  They do not imply the elder-selection estimate or
the candidate theorem.

