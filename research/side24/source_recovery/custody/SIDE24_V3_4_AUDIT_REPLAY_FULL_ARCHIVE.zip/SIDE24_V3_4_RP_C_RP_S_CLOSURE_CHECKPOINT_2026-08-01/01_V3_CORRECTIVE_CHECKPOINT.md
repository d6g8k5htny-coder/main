# SIDE24 V3.4 corrective checkpoint

**Frozen:** 2026-08-01 (America/Chicago)  
**Scope:** dimension \(3\), torus side \(24\), normalized periodized
Bargmann--Fock field, finite nonessential superlevel \(H_0\) bars,
first-moment lifetime density as \(\ell\downarrow0\)  
**Verdict:** **HOLD / READY FOR INDEPENDENT AUDIT.  The V3.4 draft proves the
last two regional premises, but the promotion protocol forbids submission
before independent review.**

**V3.1 note.**  The independent audit dated 2026-07-31 is reconciled in
`07_INDEPENDENT_AUDIT_DISPOSITION.md`.  Its local reproduction, constant,
first-variation, and GOE evidence is retained.  Its theorem-level closure
claim and its classification of the `-det H_S` sign as non-load-bearing are
rejected by exact value-pinned calculation.

**V3.2 note.**  The reviewer subsequently accepted that disposition and
independently reproduced the sign mechanism.  The reconciliation is integrated
in `09_AUDIT_RECONCILIATION_RESPONSE.md`.  V3.2 also independently proves the
compact-mark fixed-distance witness bound RP-F.

**V3.3 note.**  The later 128-file V5 forward branch is preserved and
adjudicated in `11_V5_FORWARD_BRANCH_ADJUDICATION.md`.  Its package and
executables reproduce, but its global Palm RP-F envelope and isotropic collar
floor do not survive independent checking.  Seven explicit repairs close
RP-A/RP-L on compact positive mark sets.  At the V3.3 stage, RP-C and RP-S
remained open.

**V3.4 note.**  The seven-item facewise work order is completed in
`drafts/rp_c_rp_s_facewise_closure.md`.  RP-C and RP-S are proved in this
draft with separate transverse, axial, midpoint, endpoint, mixed singular,
and collinear charts, a common density-weighted Hessian monomial off the
endpoint-axis, and complete radial/angular integration.  The monomial is
deterministic on the noncollinear atlas and retained only after the ESIP
density on the exact collinear axis.  At an axial endpoint, an exact
counterexample leaves a \(d^{-1}\) pointwise factor, so the proof uses the
measure-level \(d^2\,dd\) ledger instead.  Both stronger all-face pathwise
and all-face pointwise assertions are explicitly rejected.
They await independent audit before the HOLD is lifted.

## 1. Outcome

The uploaded V2 gap-closure package cannot be integrated as a proof.  It
regressed several arguments that were stated correctly in the frozen R2
pre-review packet and declared closure across two interfaces that remained
open at V3 intake.  V3 therefore restores R2 as the baseline, keeps only independently
checkable improvements, and replaces the single vague “selection gap” with
specific acceptance tests.

The candidate conclusion remains

\[
\nu_{3,24}(\ell)=c_{3,24}\ell^{-1/3}(1+o(1)),
\qquad \ell\downarrow0.
\]

The local all-typed contact calculation, exact near-density pushforward,
integrable majorant, coefficient reduction, and sufficient \(O(1)\)
off-diagonal estimate remain the strongest retained baseline.  V3 advances
the elder mark, deterministic exhaustion, constrained contact algebra, and
capture/escape proof.  V3.4 supplies the previously missing implication from
the all-typed contact law to the elder-selected law on compact positive mark
sets; independent audit is the remaining promotion step.

## 2. Controlling proof-status map

| Layer | V3.4 disposition | What is still required |
|---|---|---|
| Borel elder-pair mark | Proved in V3 | Independent proofread only |
| Deterministic elder-failure exhaustion | Proved in V3 | Independent proofread only |
| Near-density pushforward | Retained from R2 | Independent Kac--Rice review |
| Separated-pair contribution | Retained as uniform \(O(1)\) | Independent Kac--Rice review |
| Contact-face cubic elimination | Repaired and exactly checked in V3 | Finite-\(r\) transfer supplied in V3.4; independent audit pending |
| Deterministic capture/escape | Repaired under explicit hypotheses | Side-24 use supplied by the V3.3 RP-A/RP-L repair; independent proofread pending |
| Determinant-weighted Palm capture transfer (RP-A/RP-L) | **Proved with V3.3 repair** | Independent proofread of the tube/coarea and high-jet arguments |
| Collar third-witness expectation (RP-C) | **Proved in V3.4; audit pending** | Independent check of the face atlas, endpoint ledger, and hybrid density-weighted moment lemma |
| Singular-near third-witness expectation (RP-S) | **Proved in V3.4; audit pending** | Independent check of the mixed projective frame, ESIP, and six-term ledger |
| Fixed-distance witness expectation (RP-F) | **Proved on compact positive marks; all-mark numerator repaired** | No global Palm Gaussian envelope is claimed or needed |
| Uniform elder selection | **Proved in V3.4; audit pending** | Independent review of RP-C/RP-S and recombination |
| Candidate theorem | **HOLD** | Independent review of V3.4 and the retained baseline interfaces |

## 3. Corrected elder mark and topology

V3 restores the level-transition construction from R2 and supplies the
technical details it needed.  For the open superlevel set
\(U_a(g)=\{g>a\}\), a countable basis of coordinate balls with compact
closures gives a Borel component relation.  The predicate
\(\mathcal O(g,M,a)\) records whether the component containing \(M\) also
contains a point higher than \(g(M)\).  The Borel mark is the one-sided
transition

\[
\neg\mathcal O(g,M,h+q),\qquad
\mathcal O(g,M,h-q)
\]

for every sufficiently small positive rational \(q\).  The Morse deformation
lemma makes this transition equivalent to the finite elder pairing.

An independent sector formulation is also constructed.  A dyadic radius is
chosen measurably from a Hessian-continuity certificate, so the two probes
really lie in the local upper-sector germs.  Their maximin connection level
satisfies

\[
\mathfrak m_g(u_+,u_-)=h
\quad\text{when the sectors are in distinct open components},
\]

and is strictly greater than \(h\) when they are already in the same
component.  This explains the fatal V2 defect: the path through the saddle
always has minimum \(h\), so \(\mathfrak m<h\) cannot characterize distinct
upper sectors.

The component birth functional is a supremum over eligible values with
\(-\infty\) for ineligible terms.  It therefore works when all relevant
maxima are negative; multiplying by an indicator would incorrectly insert
zero.

Conditional on component adjacency, elder failure now has three disjoint
topological cases: earlier death of \(M\)'s class, same-component attachment
at \(S\), or a younger representative in the opposite component.  The first
and third supply a unique canonical critical witness in the open value window
\((h,b)\).  One distance function,
\(d(y,\{M,S\})\), gives the exact spatial partition

\[
\begin{aligned}
\text{collar: }&d\le Cr,\\
\text{singular-near: }&Cr<d<\delta_0,\\
\text{far: }&d\ge\delta_0.
\end{aligned}
\]

The complete proof and Borel details are in
`drafts/elder_mark_and_exhaustion.md`.

## 4. Density versus cumulative mass

V2 claimed an \(O(\ell)\) separated-pair density by assigning the width of a
lifetime window to the density after differentiation.  That factor is not
available: a window mass is \(O(\Delta\ell)\), and division by
\(\Delta\ell\) leaves an \(O(1)\) density.  The R2 compact separated-set
Kac--Rice argument gives

\[
\sup_{0<\ell\le\ell_0}\nu^{\rm far}_\rho(\ell)<\infty,
\]

which is sufficient because every bounded function is
\(o(\ell^{-1/3})\).  `scripts/audit_density_vs_cumulative.py` encodes a
Gaussian test case that prevents this cumulative/density confusion from
returning.

## 5. Triple-contact algebra: the omitted value pin

The V2 ten-pin cubic interpolation is useful only as a diagnostic system.  Its
printed \(-\det H_S\) has the wrong sign in the \(\kappa\)-linear term, as
proved by `scripts/verify_corrected_det_hs.py`.  More importantly, that system
omits the third critical point's value constraint and therefore cannot
replace the historical triple-contact elimination.

V3 restores the missing pin.  In the two-dimensional contact plane, let

\[
M=(-1/2,0),\quad S=(1/2,0),\quad
P=(c/\eta,s/\eta),\quad c^2+s^2=1,
\]

with

\[
p(M)=0,\qquad p(S)=-\kappa/6,\qquad
p(P)=-\alpha\kappa/6,\quad 0\le\alpha\le1,
\]

all three points critical, and endpoint transverse curvatures
\(q_M,q_S\).  On the generic chart \(c\eta s\ne0\), put

\[
u=\frac{2s^2(q_M-q_S)+\kappa(2c+\eta)^2}
        {8\kappa c\eta}.
\]

Exact elimination gives

\[
\begin{aligned}
-\det H_M
 &=\frac{\kappa^2\eta^2}{s^2}(u^2-\alpha),\\
-\det H_S
 &=\frac{\kappa^2\eta^2}{s^2}
   \big((u-1)^2-(1-\alpha)\big),\\
\det H_P
 &=-\frac{\kappa^2\eta^2}{s^2}
   \big((u-\alpha)^2+\alpha(1-\alpha)\big).
\end{aligned}
\]

The maximum type at \(M\) forces \(|u|<\sqrt\alpha\).  Thus, away from the
angular axis, the product has the missing contact factor
\(O(\kappa^6\eta^6)\).  A separate regular \(c=0\) chart yields the same
\(O(\kappa^2\eta^2)\) scale for each determinant under the maximum type.
The exact derivation, axis qualifications, and verifier are in
`drafts/constrained_triple_contact_repair.md` and
`scripts/verify_constrained_triple_contact.py`.

This remains only a contact-face result by itself.  The uniform finite-\(r\)
transfer and angular integration are supplied separately by the V3.4
facewise proof; they are not inferred from this elimination.

## 6. Capture and escape

The R2 inward tapered-tube strategy is retained; V2's threshold and
invariant-ball replacement is withdrawn.  The repaired deterministic proof
uses

\[
\mathcal T_{\rm in}
=\left\{|Y|\le\frac{2R}{\tau}\left(\frac14-X^2\right)\right\}
\]

all the way to \(M\).  The endpoint pins imply
\(|\nabla Q|\le3R(1/4-X^2)\), so both the longitudinal and lateral margins
vanish at the correct rate.  The outward cone similarly uses the stronger
bound \(|Y|\le\xi/(KR^4)\) and the pin-preserving estimate
\(|\nabla Q|\le R(1+m)\xi\).  This repairs the invalid comparison of a fixed
\(rR\) error with \(\xi\downarrow0\).

The deterministic theorem closes under the displayed normal form and a
pin-preserving approximation whose derivative error is at most
\(1/(8192R^3)\).  A bare absolute \(C^1\) error is insufficient because the
cone and tube margins vanish at the endpoints.  Exact rational margins are
checked by `scripts/verify_capture_escape_budgets.py`.

V3.3 supplies the determinant-weighted Palm transfer.  The exact endpoint
factor \(\det H_p=rD_p\) gives \(Z_r\asymp r^2\) and
\(\mathbb E^0W_r^2=O(r^4)\).  A cross-endpoint Weyl bridge reduces every
shallow typed configuration to one \(O(rP(U))\) eigenvalue tube; the weighted
tube numerator is \(O(r^5)\), hence \(O(r^3)\) after Palm normalization.
Polynomial high-jet truncation makes all remaining capture/escape failures
\(o(r^3)\).  The seven corrected steps and their scope are in
`drafts/palm_transfer_repair_v3_3.md`.

## 7. Selection proposition after the V3.4 regional proof

Let \(N_{\rm col}\), \(N_{\rm sing}\), and \(N_{\rm far}\) be the all-witness
critical-point counts from the repaired deterministic partition.  The exact
proved reduction is

\[
\begin{aligned}
1-p_r(t,b,\kappa)\le{}&
\mathbb P^{MS}(A^c)+\mathbb P^{MS}(F_{\rm self})\\
&+\mathbb E^{MS}N_{\rm col}
+\mathbb E^{MS}N_{\rm sing}
+\mathbb E^{MS}N_{\rm far}.
\end{aligned}
\]

V3.3 proves the capture/self terms and retains the V3.2 proof of the
fixed-distance term.  V3.4 now proves

\[
 \mathbb E^{MS}N_{\rm col}\le Cr^3,\qquad
 \mathbb E^{MS}N_{\rm sing}\le Cr^3
\]

by the explicit facewise construction in
`drafts/rp_c_rp_s_facewise_closure.md`.  Substitution in the displayed
selection inequality proves \(1-p_r=O(r^3)\) on compact positive mark sets.
The proof keeps the finite-\(r\) remainders, collision factors, and ESIP
penalties visible; it does not promote contact-face positivity by itself.

## 8. Reproducibility and claim discipline

The V3.4 runner compares normal and optimized output for every checkpoint
check except the frozen V5 audit, which performs that dual-mode comparison
internally.  Failures propagate through explicit exceptions and nonzero child
exits.  Each mathematical script prints a scope limit.  Passing the runner
means only that the displayed symbolic identities, arithmetic margins, package
facts, and regression countermodels were reproduced.

The following are not inferred from a passing script alone:

- a covariance eigenfloor on a compactified finite-\(r\) chart;
- a Kac--Rice domination or exchange of limits;
- angular removability or integrability;
- a Palm probability rate without the analytic tube and tail arguments;
- elder selection; or
- the candidate theorem.

## 9. Next work order

1. Independently audit every limiting derivative-distribution family in the
   V3.4 finite atlas, especially (AI.1)--(AI.4), (MP.1)--(MP.6), and the
   pair-measurable singular frame (5.3a)--(5.12).
2. Independently rederive the hybrid Section 6 envelope: the
   mixed-curvature noncollinear bound, the failure of a pathwise axis bound,
   the density-weighted ESIP replacement, the oblique endpoint
   \(r^5d\rho^{-3}\) refinement, and the separate axial endpoint
   measure ledger (EP.2).
3. Re-execute both collar and singular Kac--Rice ledgers from the canonical
   count (A.35), including the axis exponential.
4. Only after those checks pass, lift `HOLD` and integrate the result into the
   submission manuscript.

No submission package should be assembled from this checkpoint until those
steps are complete.

## 10. Independent-audit response

The preserved audit snapshot has SHA-256

```text
9e2e0637706685692cdce770f4c4e74c7154baaabbc319de77e6defd34ab5a01.
```

Its internal ledger verifies 16/16 payload files.  All four independent
scripts rerun normally and under `python -O`, producing byte-identical stored
transcripts.  All six historical scripts rerun normally and reproduce their
committed transcripts byte-for-byte.

These are local reproducibility facts.  The B.1 script uses the obsolete
ten-condition interpolation and omits the witness-value pin.  The dedicated
V3.1 regression proves that after the pin is inserted the corrected sign gives
the required `eta^2` suppression, whereas at fixed bounded type-cone
coordinate the printed positive sign leaves the nonzero limit
`c^2*kappa^2/s^2`.  The sign is load-bearing.

Direct access to the original V2 binaries also resolves the audit's mount
limitation: 23 of 24 manifest entries match, including all six PDFs and the
DOCX.  Only the stale `CHANGE_LOG.md` row differs.  None of these results
closes a row in the controlling proof-status map.

## 11. Reconciliation and RP-F advance

The independent reconciliation snapshot verifies the value-pinned sign by a
fresh generic-cubic elimination and accepts the controlling HOLD disposition.
Its exact source ZIP is preserved under `evidence/audit_reconciliation/`; the
new wrapper checks the internal ledger, both normal and optimized transcripts,
and an injected fail-closed probe.

Package observations are now keyed by SHA in
`10_PACKAGE_SCOPE_MATRIX.csv`.  In particular, the two V3.1 scripts reported
missing from a separate 109-file V4 workspace are present in the actual V3.1
checkpoint.  The six-PDF and seven-PDF counts belong to different V2
manifests.

The independent proof in `drafts/fixed_distance_witness_audit.md` closes RP-F
on the compact positive mark sets required by the elder-selection reduction.
It uses a conditional remote density bound, not the baseline's unreviewed
global Gaussian penalty.

## 12. V5 forward-branch adjudication

The V5 archive has SHA-256

```text
119ffbfae2d11cc2d3de60f15c06a653c48b17d06ab0a2e125260ab0f1458c5a
```

Its current manifest and executable transcripts verify exactly, but its shared
evidence tree does not preserve every earlier referent: V4 matches 106/108 and
V3 matches 24/37.  The branch is therefore evidence, not a provenance-complete
successor.

The Palm argument is accepted only with the V3.3 repairs.  In particular, the
pair-conditioned remote density divides by the pair-pin density, so the
claimed global \(e^{-c(b^2+\kappa^2)}\) Palm penalty can cancel.  The correct
all-mark calculation retains the unnormalized pair factor.  The collar claim
also fails at the joint axis because

\[
\det C_{\rm col}=\varrho^6(4X^2+\varrho^2),
\]

which scales generically as \(r^8\) under a joint collision and vanishes on
\(\varrho=0\).  Consequently RP-A and RP-L are proved with the V3.3 repair.
The V3.4 successor resolves the two interfaces which were still open at this
point; see `13_RP_C_RP_S_CLOSURE_DISPOSITION.md`.  HOLD is retained for
independent audit, not for a named residual premise.
