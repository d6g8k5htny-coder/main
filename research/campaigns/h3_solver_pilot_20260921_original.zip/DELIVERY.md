# H3 search-and-certify experiment — delivered candidate

Recorded 2026-09-21T23:11:05.480235+00:00.

## Main research result

The new author-side argument and exact scalar certificate support
**Z(r) >= (1747/1000) r² for every 0 < r <= 1/20**, under the existing
2D normalized SIDE24 field, fixed x-axis points, height6/5, gap r³/6 and
canonical six-pin Gaussian conditioning law. This is an additive candidate,
not a canonical status promotion or a qualifying independent review.

The previous stated whole-band coefficient was17/10. The improvement is47/1700,
about2.7647%. The resulting endpoint floor at r=1/20 is1747/400000=.0043675.
The already sharper fixed-radius RN floor .0077592917375327855 remains unchanged;
this new whole-band estimate is NOT substituted into that consumer's budget.
No all-angle, 3D, full RN annulus, selected-event transfer, q0 or prize closure follows.

## Why this is more than unsuccessful sampling

A finite NONCERTIFYING search evaluated30,351 event-cutoff pairs and selected
epsilon=103/500 and d=9/100. A separate exact-rational implementation then
certified the selected parameters through the uniform analytic reduction.
It retains the normalized kernel's image tails, shifted Gram positivity,
whole-band pin-energy bound1266466/160083<8, both event tails and the positive
part determinant inequality. The positive bracket is verified BEFORE lower
probabilities are multiplied into it.

The sufficient-bound formula is enclosed by
**[1.747106129274, 1.747994749902]**. Its lower endpoint exceeds1747/1000.
This interval is NOT an enclosure of the true Z(r)/r². Uniformity comes from
analytically bounding the entire radius band before scalar evaluation, not
from checking finitely many radii or observing no counterexample.

The complete analytic argument is PROOF.md (8,469bytes), SHA256
0d5fc5ece05df2f5717e0c8fc61c041b8663997933e8ec92c58c8cdf4b4f192d.
The deterministic CERTIFICATE.json is18,967bytes, rawSHA256
c26d9be8134de716c2f42378d09e7121855279fec1a068c2e4b5e7ef95823095;
canonical compact-JSON SHA256
dfc9c25f1ebdd6545b56bf1ecc3606cd3b950a8f2b5e779bcfe11b88f94c7dea.

## Implemented mechanisms

The pipeline proposes parameters, certifies the selected candidate, records a
formula-level dependency DAG with recursive hashes, reports downstream affected
nodes, and caches deterministic scalar work by source/code/runtime/parameters/context.
The cache is trusted-local, not hermetic, distributed or authenticated. Its hash
is integrity evidence, not scientific authority. Source/context are checked before
and after use; caller context itself is not an authenticated admission service.
A cold run recomputes cached arithmetic and compares it. Outputs are exclusive-create.

Formula lineage covers eight declared mathematical stages. No Google Sheets cells
feed this H3 computation. This is not a general Sheets parser or automatic Python
causal tracer. The supplied counts of workbooks/formula cells were not verified.

The adversarial controls distinguish actual target enclosures from sufficient
lower estimates. A wide interval crossing the target is inconclusive. A lower
estimator below the target does not refute the true quantity. The prototype does
not independently integrate Z and is not a continuously running prover/falsifier game.

Bitemporal whole-workspace migration, a full Arb second backend, hermetic Nix/Guix
execution, global spreadsheet lineage, a proof market and automatic compute grants
are deferred, not represented as installed. CPU/wall time are measured; energy is not.

## Observed verification

57 distinct tests pass in normal Python, the same57 pass in optimized Python, and
57 pass after reconstructing the program from raw Drive readback. No local skips.
The tests cover rational interval directions, explicit tails, scope constraints,
missing-tail mutations, understated moments, misleading counterexamples, source
and cache corruption, denied context, formula impact and an unattainable requested
target. Repeated runs are not171 distinct tests.

The final command-line path cold-reproduced the pinned certificate and rejected
a deliberately wrong certificate digest with exit2. A fresh recomputation matched.
The original source archive and all70 manifest-listed leaves were byte-verified;
its71st entry is the manifest. The original full repository wrapper was not replayed.

An optional150-digit mpmath1.3.0 comparison passed27 elementary cases. It is
NONCERTIFYING and not a second rigorous arithmetic backend. Arb was not executed.

All14 published Git blob identities match the submitted payload. All16 initial
Drive files (15payloads plus manifest) match byte-for-byte. One draft prose line
break was aligned before sealing; the original scientific source was not changed.

Dedicated GitHub H3 run35666015788, job106551826477, completed successfully,
including normal/optimized tests and cold certificate reproduction. Governance
pilot run35666015740 also passed. Full repository CI35666015671 was still in
progress at the last observation; no full regression pass is asserted here.

## Measured local execution reuse

Final published code: cold search/certification took7.438967s;
warm trusted-local reuse took0.016379s;
cold recomputation-and-match took7.418510s.
These are single observations in this environment, not cross-machine performance
claims or a general benchmark. Reuse produces no additional evidence or review credit.
The cache does not prove an input's current scientific admissibility.

## Publication and review

Draft PR5: https://github.com/d6g8k5htny-coder/main/pull/5
Commit2371f660d90963e558a0d08921c634a36b3be016; branch
chatgpt/h3-solver-pilot-20260921; base63eb5baadd7526a7842c43f2d391aad55b01cac9.
Fourteen added Git files; no deletions, existing scientific-file edits, branch
merge, visibility/permission changes, new scheduler or global migration.

Drive folder: https://drive.google.com/drive/folders/1WsgETGCUiLRj37ku0V-1bJBoTMo29dED
Proof: https://drive.google.com/file/d/1GNxSkObZLXbrR_UWUC6i9PW59pLNrLKB/view
Certificate: https://drive.google.com/file/d/1yGE1AZGPChZJ9nBn1BGe-opLWj9dw2KW/view
Manifest: https://drive.google.com/file/d/14GAoMD42hdUQmoYb1yOG2l6iOKErPddn/view

Review Queue RV-H3-SOLVER-20260921-01 was appended and read back at row38.
It is OPEN / UNASSIGNED for nonauthor mathematical and software review. This
work was source-exposed author-side research; organizational-independence credit0.
The next review should challenge the generalized event cutoffs, all-radius
reduction and independent-method scalar arithmetic, then consider a genuine
second rigorous backend. Broader field/angle/RN work retains its own hypotheses.

R17 Work Events remains the coordination record. Claim
CLAIM-SOLVER-H3-20260921-01 is the implementation claim. The following publication
and release event will bind this receipt by exact ID/hash; this receipt does not
pretend those future appends have already occurred. Closing this delivery does
not close its mathematical review or any program-level obligation.
