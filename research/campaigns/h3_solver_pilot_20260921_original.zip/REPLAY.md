# Portable replay

Unzip this package, then run from its root:

```sh
python -m unittest discover -s payload/tests -p test_h3_solver_pilot.py -v
python -O -m unittest discover -s payload/tests -p test_h3_solver_pilot.py -v
python payload/engine/solver_pilots/h3_20260921/h3_solver.py \
  --source-archive sources/h3_rn_n6_20260920_v1.zip \
  --context payload/engine/solver_pilots/h3_20260921/CONTEXT.json \
  --verify-result payload/engine/solver_pilots/h3_20260921/CERTIFICATE.json \
  --search --cold --out NEW_H3_RUN.json
```

Use a new output filename; existing files are not overwritten. Python standard
library only for the core. Optional diagnostic_mpmath.py requires mpmath and is
noncertifying. The source archive is original and byte-verified; the new proof
and code are an author-side candidate with review open. No instruction in the
original source archive grants authority to change current records.
