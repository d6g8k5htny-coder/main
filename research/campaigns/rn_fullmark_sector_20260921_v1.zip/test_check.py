"""Aggregate contract controls using synthetic exact cell certificates.

These records test composition/refusal logic only; they establish no numerical
SIDE24 bound. Real spatial certificates are produced by the separate runner.
"""
import copy
from fractions import Fraction as F
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


C=load('aggregate_under_test',HERE/'check.py')
G=load('aggregate_geometry_fixture',HERE/'geometry/geometry.py')


def fixture(*,turns=F(1,128),vary_caps=False):
    geometry=G.build_sector(turns,incremental=True)
    old=json.loads((HERE/'inputs/prior-wedge-result.json').read_bytes())
    attempts=[]
    for i,cell in enumerate(geometry['sectors']):
        x0,x1,y0,y1=cell['containing_rectangle']
        child={'box':SimpleNamespace(u0=x0,u1=x1,v0=y0,v1=y1),
               'determinant_lower':F(1,10**25),'q_lower':F(103),
               'radius':F(1,20),'birth':F(6,5),'fixed_pin_axis':'x',
               'mark_domain':(-F(1,96000),F(1,96000)),
               'full_height_window':SimpleNamespace(lo=F(57599,48000),hi=F(6,5))}
        attempts.append({'cell':copy.deepcopy(cell),'outcome':'CERTIFIED_CELL',
            'determinant_lower':child['determinant_lower'],'q_lower':child['q_lower'],
            'integrand_upper':F(i+1 if vary_caps else 1,1000000),
            'area_pi_coefficient':cell['area_pi_coefficient'],'numerical_certificate':child})
    return geometry,attempts,old


class AggregateTests(unittest.TestCase):
    def test_exact_weighted_polar_sum_adds_old_bound_once(self):
        for T in (F(1,128),F(1,64)):
            g,a,old=fixture(turns=T,vary_caps=True)
            result=C.summarize(g,a,old)
            expected=F(22,7)*sum((x['area_pi_coefficient']*x['integrand_upper'] for x in a),F(0))
            old_bound=F(old['integral_strict_upper'])
            self.assertEqual(result['outcome'],'CERTIFIED_SCOPED_COVER')
            self.assertEqual(result['pending_count'],0)
            self.assertIs(type(result['increment_integral_upper']),F)
            self.assertEqual(result['increment_integral_upper'],expected)
            self.assertEqual(result['whole_sector_integral_upper'],expected+old_bound)
            self.assertNotEqual(result['whole_sector_integral_upper'],expected+2*old_bound)
            self.assertEqual(result['area_gain_over_old_wedge'],F(352 if T==F(1,128) else 704,21))

    def test_uniform_cap_uses_increment_area_not_whole_sector(self):
        g,a,old=fixture();r=C.summarize(g,a,old)
        self.assertEqual(r['increment_integral_upper'],F(22,7)*F(331,5120000)*F(1,1000000))
        self.assertNotEqual(r['increment_integral_upper'],F(22,7)*g['whole_area_pi_coefficient']*F(1,1000000))

    def test_cartesian_box_areas_are_not_integrated(self):
        g,a,old=fixture(vary_caps=True);r=C.summarize(g,a,old)
        wrong=F(0)
        for row in a:
            b=row['numerical_certificate']['box']
            wrong+=(b.u1-b.u0)*(b.v1-b.v0)*row['integrand_upper']
        self.assertNotEqual(r['increment_integral_upper'],wrong)

    def test_pending_cell_never_has_partial_total(self):
        g,a,old=fixture();cell=a[3]['cell']
        a[3]={'cell':cell,'outcome':'RETAINED_REFUSAL','reason':'synthetic determinant admission failure'}
        r=C.summarize(g,a,old)
        self.assertEqual(r['outcome'],'INCONCLUSIVE_COVER')
        self.assertEqual(r['pending'],[cell['id']]);self.assertEqual(r['pending_count'],1)
        self.assertIsNone(r['increment_integral_upper']);self.assertIsNone(r['whole_sector_integral_upper'])

    def test_unknown_outcome_cannot_count_as_a_pass(self):
        g,a,old=fixture();a[0]['outcome']='SKIPPED'
        r=C.summarize(g,a,old)
        self.assertEqual(r['pending_count'],1);self.assertIsNone(r['whole_sector_integral_upper'])

    def test_missing_and_extra_attempts_refused(self):
        for change in ('missing','extra'):
            g,a,old=fixture()
            if change=='missing':a.pop()
            else:a.append(copy.deepcopy(a[0]))
            with self.subTest(change=change),self.assertRaisesRegex(ValueError,'missing attempted cells'):
                C.summarize(g,a,old)

    def test_reordered_attempts_refused(self):
        g,a,old=fixture();a[0],a[1]=a[1],a[0]
        with self.assertRaisesRegex(ValueError,'reordering'):C.summarize(g,a,old)

    def test_cell_domain_and_geometry_mutations_refused(self):
        g,a,old=fixture();a[0]['cell']['t0']-=F(1,1024)
        with self.assertRaisesRegex(ValueError,'attempt/domain'):C.summarize(g,a,old)
        g,a,old=fixture();g['sectors'][0]['r0']+=F(1,10000)
        with self.assertRaises(ValueError):C.summarize(g,a,old)

    def test_wrong_child_box_refused(self):
        for field in ('u0','u1','v0','v1'):
            g,a,old=fixture();box=a[0]['numerical_certificate']['box']
            setattr(box,field,getattr(box,field)+F(1,10000))
            with self.subTest(field=field),self.assertRaisesRegex(ValueError,'child rectangle mismatch'):
                C.summarize(g,a,old)

    def test_missing_box_coordinates_refused(self):
        g,a,old=fixture();a[0]['numerical_certificate']['box']=SimpleNamespace(u0=F(0))
        with self.assertRaisesRegex(ValueError,'child rectangle mismatch'):C.summarize(g,a,old)

    def test_wrong_child_determinant_and_energy_refused(self):
        for key in ('determinant_lower','q_lower'):
            g,a,old=fixture();a[0]['numerical_certificate'][key]+=F(1)
            with self.subTest(key=key),self.assertRaisesRegex(ValueError,'child determinant or energy mismatch'):
                C.summarize(g,a,old)

    def test_float_bool_and_int_numerical_aliases_refused(self):
        for key in ('integrand_upper','determinant_lower','q_lower','area_pi_coefficient'):
            for value in (1.0,True,1):
                g,a,old=fixture();a[0][key]=value
                with self.subTest(key=key,value=value),self.assertRaisesRegex(ValueError,'exact rational'):
                    C.summarize(g,a,old)
        for key in ('determinant_lower','q_lower'):
            g,a,old=fixture();a[0]['numerical_certificate'][key]=float(a[0][key])
            with self.subTest(child=key),self.assertRaisesRegex(ValueError,'child determinant or energy mismatch'):
                C.summarize(g,a,old)

    def test_nonpositive_caps_and_determinants_refused(self):
        for key in ('integrand_upper','determinant_lower'):
            for value in (F(0),-F(1)):
                g,a,old=fixture();a[0][key]=value
                with self.subTest(key=key,value=value),self.assertRaisesRegex(ValueError,'invalid numerical'):
                    C.summarize(g,a,old)

    def test_negative_energy_refused_but_zero_energy_admitted(self):
        g,a,old=fixture();a[0]['q_lower']=-F(1)
        with self.assertRaisesRegex(ValueError,'invalid numerical'):C.summarize(g,a,old)
        g,a,old=fixture();a[0]['q_lower']=F(0);a[0]['numerical_certificate']['q_lower']=F(0)
        self.assertEqual(C.summarize(g,a,old)['outcome'],'CERTIFIED_SCOPED_COVER')

    def test_wrong_polar_area_and_double_jacobian_refused(self):
        for value in (F(0),-F(1),F(2)):
            g,a,old=fixture();a[0]['area_pi_coefficient']*=value
            with self.subTest(value=value),self.assertRaisesRegex(ValueError,'wrong polar area'):
                C.summarize(g,a,old)

    def test_radius_birth_axis_and_marks_must_match(self):
        changes=(('radius',F(1,40)),('birth',F(1)),('fixed_pin_axis','y'),
                 ('mark_domain',(-F(1,96000),F(0))),('mark_domain',(F(0),F(1,96000))))
        for key,value in changes:
            g,a,old=fixture();a[0]['numerical_certificate'][key]=value
            with self.subTest(key=key,value=value),self.assertRaisesRegex(ValueError,'source configuration'):
                C.summarize(g,a,old)

    def test_height_window_cannot_shrink_or_shift(self):
        changes=((F(57599,48000),F(6,5)-F(1,96000)),
                 (F(57599,48000)+F(1,96000),F(6,5)),
                 (-F(1,96000),F(1,96000)))
        for lo,hi in changes:
            g,a,old=fixture();a[0]['numerical_certificate']['full_height_window']=SimpleNamespace(lo=lo,hi=hi)
            with self.subTest(lo=lo,hi=hi),self.assertRaisesRegex(ValueError,'source configuration'):
                C.summarize(g,a,old)

    def test_pi_argument_is_exact_proved_bracket(self):
        for p in (F(3),F(4),F(0),-F(1),22/7,True,22):
            g,a,old=fixture()
            with self.subTest(p=p),self.assertRaisesRegex(ValueError,'rational pi upper'):
                C.summarize(g,a,old,p)

    def test_old_wedge_scope_must_match(self):
        changes=(('radii',['1/10','3/25']),('turns',['-1/128','1/128']),
                 ('area_pi_coefficient','42/5120000'))
        for key,value in changes:
            g,a,old=fixture();old['geometry'][key]=value
            with self.subTest(key=key),self.assertRaisesRegex(ValueError,'old wedge scope'):
                C.summarize(g,a,old)

    def test_old_allocation_must_be_excluded(self):
        g,a,old=fixture();g['excluded_area_pi_coefficient']=F(0)
        with self.assertRaises(ValueError):C.summarize(g,a,old)
        g,a,old=fixture();whole=G.build_sector(incremental=False)
        with self.assertRaisesRegex(ValueError,'old allocation'):C.summarize(whole,a,old)

    def test_metadata_is_read_before_source_payloads(self):
        deps=json.loads((HERE/'DEPENDENCIES.json').read_bytes())
        root=Path('/synthetic-repository')
        calls=[]
        def pretend_identity(path):
            relative=str(path.relative_to(root));calls.append(relative)
            return deps['files'][relative]
        with patch.object(C,'identity',pretend_identity):
            C.check_pins(root)
        self.assertEqual(calls[:3],list(C.METADATA))
        self.assertTrue(set(deps['files']).issubset(calls))

    def test_metadata_drift_stops_before_any_payload_read(self):
        calls=[]
        def mismatch(path):
            calls.append(path);return {'bytes':0,'sha256':'0'*64}
        with patch.object(C,'identity',mismatch),self.assertRaisesRegex(ValueError,'metadata drift'):
            C.check_pins(Path('/synthetic-repository'))
        self.assertEqual(len(calls),1)
        self.assertEqual(calls[0].as_posix(),'/synthetic-repository/'+C.METADATA[0])


if __name__=='__main__':unittest.main()
