"""Exact geometry for two bounded SIDE24 annular-sector extensions.

Pure standard-library Fraction arithmetic. This proves geometry only: no RN
integrand bound, full-annulus certificate or mathematical-status promotion.
"""
from fractions import Fraction as F

R_LO, R_HI = F(1, 10), F(3, 25)
OLD_R_HI, OLD_T = F(11, 100), F(1, 1024)
PI_LO, PI_HI = F(3), F(22, 7)
TURN_HALF_WIDTHS = (F(1, 128), F(1, 64))
MAX_CELLS, MAX_BITS = 32, 4096
SCHEMA = 'RN_EXACT_SECTOR_GEOMETRY_V1'
CELL_KEYS = {'id', 'r0', 'r1', 't0', 't1', 'containing_rectangle', 'area_pi_coefficient'}
REPORT_KEYS = {'schema', 'turn_halfwidth', 'incremental', 'sectors', 'cell_count',
               'whole_area_pi_coefficient', 'excluded_area_pi_coefficient',
               'area_pi_coefficient', 'area_strict_rational_upper',
               'source_range_caps', 'scope'}
SCOPE = {'geometry_only': True, 'fixed_pin_axis': 'x', 'fixed_separation': '1/20',
         'full_annulus_certified': False, 'integrand_certified': False,
         'scientific_status_changed': False, 'organizational_independence_credit': 0}


def _same_exact(left, right):
    if type(left) is not type(right):return False
    if type(right) is dict:
        return set(left)==set(right) and all(_same_exact(left[k],right[k]) for k in right)
    if type(right) in (list,tuple):
        return len(left)==len(right) and all(_same_exact(a,b) for a,b in zip(left,right))
    return left==right


def _fraction(value, name):
    if type(value) is not F:
        raise TypeError(name+' must be an exact Fraction; floats, bools and implicit conversions are refused')
    if max(abs(value.numerator).bit_length(), value.denominator.bit_length()) > MAX_BITS:
        raise ValueError(name+' exceeds the rational input budget')
    return value


def _candidate(turn_halfwidth, incremental):
    _fraction(turn_halfwidth, 'turn_halfwidth')
    if turn_halfwidth not in TURN_HALF_WIDTHS:
        raise ValueError('only the bounded 1/128 and 1/64 candidates are supported')
    if type(incremental) is not bool:
        raise TypeError('incremental must be a bool')


def _polar(r0, r1, t0, t1):
    for name, value in zip(('r0', 'r1', 't0', 't1'), (r0, r1, t0, t1)):
        _fraction(value, name)
    if not (R_LO <= r0 < r1 <= R_HI and -F(1,64) <= t0 < t1 <= F(1,64)):
        raise ValueError('positive polar cell within the bounded source domain required')
    if t0 < 0 < t1:
        raise ValueError('split an angular cell at zero before Cartesian containment')


def polar_area_pi(r0, r1, t0, t1):
    """Area divided by pi, not by 2*pi; radius Jacobian is integrated once."""
    _polar(r0, r1, t0, t1)
    return (r1*r1-r0*r0)*(t1-t0)


def containing_rectangle(r0, r1, t0, t1):
    """A rational x0,x1,y0,y1 box for the complete signed-turn polar cell.

    Uses only 3<pi<22/7 and elementary alternating Taylor inequalities for
    sine/cosine. No trigonometric float or point sampling enters the proof.
    """
    _polar(r0, r1, t0, t1)
    a, b = min(abs(t0), abs(t1)), max(abs(t0), abs(t1))
    lower_angle, upper_angle = 2*PI_LO*a, 2*PI_HI*b
    if not (0 <= lower_angle <= upper_angle < F(1, 10)):
        raise ValueError('elementary trigonometric range not established')
    cos_lo = 1-upper_angle**2/2
    cos_hi = 1-lower_angle**2/2+lower_angle**4/24
    sin_lo = lower_angle-lower_angle**3/6
    sin_hi = upper_angle
    if not (0 < cos_lo <= cos_hi <= 1 and 0 <= sin_lo <= sin_hi):
        raise ValueError('elementary trigonometric bounds inconsistent')
    x0, x1 = r0*cos_lo, r1*cos_hi
    y0, y1 = r0*sin_lo, r1*sin_hi
    if t1 <= 0:
        y0, y1 = -y1, -y0
    if not (x0 < x1 and y0 < y1):
        raise ValueError('containing rectangle has no interior')
    return x0, x1, y0, y1


def _check_partition(cells, turn_halfwidth, incremental):
    """Exact atom occupancy, checking coverage, overlap and excluded old wedge."""
    radial = {R_LO, R_HI}
    angular = {-turn_halfwidth, turn_halfwidth}
    if incremental:
        radial.add(OLD_R_HI)
        angular.update((-OLD_T, OLD_T))
    for cell in cells:
        radial.update((cell['r0'], cell['r1']))
        angular.update((cell['t0'], cell['t1']))
    radial, angular = sorted(radial), sorted(angular)
    for ra, rb in zip(radial, radial[1:]):
        for ta, tb in zip(angular, angular[1:]):
            expected = 0 if incremental and rb <= OLD_R_HI and -OLD_T <= ta < tb <= OLD_T else 1
            covering = sum(cell['r0'] <= ra < rb <= cell['r1'] and
                           cell['t0'] <= ta < tb <= cell['t1'] for cell in cells)
            if covering != expected:
                raise ValueError('polar partition gap, overlap or old-wedge double count')


def validate_partition(cells, *, turn_halfwidth, incremental):
    """Validate bounded geometry records; return their exact pi-area sum.

    This validator checks actual parameter-space coverage, not just area
    equality. Equal-area gaps and overlaps cannot cancel each other.
    """
    _candidate(turn_halfwidth, incremental)
    if type(cells) not in (tuple, list) or not 1 <= len(cells) <= MAX_CELLS:
        raise ValueError('bounded nonempty cell sequence required')
    names = set()
    total = F(0)
    for cell in cells:
        if type(cell) is not dict or set(cell) != CELL_KEYS:
            raise ValueError('cell keys do not match the exact geometry schema')
        name = cell['id']
        if type(name) is not str or not name or len(name) > 80 or name in names:
            raise ValueError('distinct bounded cell identifiers required')
        names.add(name)
        r0,r1,t0,t1 = (cell[k] for k in ('r0','r1','t0','t1'))
        _polar(r0,r1,t0,t1)
        if not -turn_halfwidth <= t0 < t1 <= turn_halfwidth:
            raise ValueError('cell extends beyond the requested angular domain')
        rectangle = cell['containing_rectangle']
        if type(rectangle) is not tuple or len(rectangle) != 4:
            raise TypeError('containing rectangle must be a four-Fraction tuple')
        for x in rectangle:
            _fraction(x, 'containing rectangle endpoint')
        if rectangle != containing_rectangle(r0,r1,t0,t1):
            raise ValueError('containing rectangle differs from the analytic formula')
        area = _fraction(cell['area_pi_coefficient'], 'cell area/pi')
        if area != polar_area_pi(r0,r1,t0,t1):
            raise ValueError('wrong polar area or duplicate Jacobian')
        total += area
    _check_partition(cells, turn_halfwidth, incremental)
    expected = (R_HI**2-R_LO**2)*2*turn_halfwidth
    if incremental:
        expected -= (OLD_R_HI**2-R_LO**2)*2*OLD_T
    if total != expected:
        raise ValueError('exact total area differs from the requested region')
    return total


def source_range_caps(cells):
    """Exact geometric bounds needed by the existing stationary N6 argument.

    These do not claim that LDL/determinant/energy/integrand certificates pass.
    """
    if type(cells) not in (list,tuple) or not 1<=len(cells)<=MAX_CELLS:
        raise ValueError('bounded nonempty cell sequence required')
    boxes = [c['containing_rectangle'] for c in cells]
    for box in boxes:
        if type(box) is not tuple or len(box)!=4:raise TypeError('exact rectangle tuple required')
        for x in box:_fraction(x,'rectangle endpoint')
        if not(box[0]<box[1] and box[2]<box[3]):raise ValueError('positive rectangle required')
    max_hx = max((x1-x0)/2 for x0,x1,y0,y1 in boxes)
    max_hy = max((y1-y0)/2 for x0,x1,y0,y1 in boxes)
    max_center_x = max(abs((x0+x1)/2) for x0,x1,y0,y1 in boxes)
    max_center_y = max(abs((y0+y1)/2) for x0,x1,y0,y1 in boxes)
    point_x = max(max(abs(x0),abs(x1)) for x0,x1,y0,y1 in boxes)
    point_y = max(max(abs(y0),abs(y1)) for x0,x1,y0,y1 in boxes)
    point_pin_displacement = max(point_x+F(1,40),point_y)
    minimum_x = min(x0 for x0,x1,y0,y1 in boxes)
    if not (max_hx < F(3,1000) and max_hy < F(1,500) and
            max_center_x < 17 and max_center_y < 17 and
            point_pin_displacement <= F(29,200) < 18 and
            minimum_x > F(1,40)):
        raise ValueError('bounded N6 geometry requirements not established')
    return {'max_halfwidth_x':max_hx,'max_halfwidth_y':max_hy,
            'strict_halfwidth_x_upper':F(3,1000),'strict_halfwidth_y_upper':F(1,500),
            'max_abs_center_x':max_center_x,'max_abs_center_y':max_center_y,
            'center_coordinate_limit':F(17),'remainder_halfwidth_limit':F(1),
            'max_coordinate_displacement_to_fixed_pins':point_pin_displacement,
            'coordinate_displacement_upper':F(29,200),'kernel_tail_radius_limit':F(18),
            'minimum_x':minimum_x,'right_fixed_pin_x':F(1,40),
            'centers_and_rectangles_avoid_fixed_pins':True,
            'derivative_order_budget':18,'taylor_order':6,
            'stationary_remainder_applicability':'GEOMETRY_VALID; source law and variance caps remain external premises'}


def build_sector(turn_halfwidth=F(1,128), *, incremental=True):
    _candidate(turn_halfwidth, incremental)
    nt = 4 if turn_halfwidth == F(1,128) else 8
    cells = []
    for i in range(4):
        r0,r1 = F(20+i,200),F(21+i,200)
        for j in range(nt):
            t0,t1 = -turn_halfwidth+F(j,256),-turn_halfwidth+F(j+1,256)
            if incremental and r1 <= OLD_R_HI:
                if t1 == 0:t1 = -OLD_T
                if t0 == 0:t0 = OLD_T
            cells.append({'id':f'r{i}-t{j}', 'r0':r0,'r1':r1,'t0':t0,'t1':t1,
                          'containing_rectangle':containing_rectangle(r0,r1,t0,t1),
                          'area_pi_coefficient':polar_area_pi(r0,r1,t0,t1)})
    area = validate_partition(cells,turn_halfwidth=turn_halfwidth,incremental=incremental)
    whole = (R_HI**2-R_LO**2)*2*turn_halfwidth
    excluded = (OLD_R_HI**2-R_LO**2)*2*OLD_T if incremental else F(0)
    return {'schema':SCHEMA,'turn_halfwidth':turn_halfwidth,'incremental':incremental,
            'sectors':cells,'cell_count':len(cells),'whole_area_pi_coefficient':whole,
            'excluded_area_pi_coefficient':excluded,'area_pi_coefficient':area,
            'area_strict_rational_upper':PI_HI*area,'source_range_caps':source_range_caps(cells),
            'scope':dict(SCOPE)}


def validate_report(report):
    if type(report) is not dict or set(report) != REPORT_KEYS or report['schema'] != SCHEMA:
        raise ValueError('geometry report schema mismatch')
    turn_halfwidth,incremental = report['turn_halfwidth'],report['incremental']
    area = validate_partition(report['sectors'],turn_halfwidth=turn_halfwidth,incremental=incremental)
    if type(report['cell_count']) is not int or report['cell_count'] != len(report['sectors']):
        raise ValueError('cell count mismatch')
    whole = (R_HI**2-R_LO**2)*2*turn_halfwidth
    excluded = (OLD_R_HI**2-R_LO**2)*2*OLD_T if incremental else F(0)
    for key,expected in (('whole_area_pi_coefficient',whole),('excluded_area_pi_coefficient',excluded),
                         ('area_pi_coefficient',area),('area_strict_rational_upper',PI_HI*area)):
        if _fraction(report[key],key) != expected:raise ValueError('wrong aggregate area: '+key)
    if not _same_exact(report['source_range_caps'],source_range_caps(report['sectors'])) or not _same_exact(report['scope'],SCOPE):
        raise ValueError('geometry caps or scope changed')
    return area
