import copy
from fractions import Fraction as F
from itertools import product
import unittest
import geometry as G


def remake(cell, **changes):
    c=copy.deepcopy(cell);c.update(changes)
    args=tuple(c[k] for k in ('r0','r1','t0','t1'))
    c['containing_rectangle']=G.containing_rectangle(*args)
    c['area_pi_coefficient']=G.polar_area_pi(*args)
    return c


class GeometryTests(unittest.TestCase):
    def test_all_four_constructions_exact_counts_and_areas(self):
        for T,incremental in product(G.TURN_HALF_WIDTHS,(False,True)):
            with self.subTest(T=T,incremental=incremental):
                report=G.build_sector(T,incremental=incremental)
                self.assertEqual(report['cell_count'],16 if T==F(1,128) else 32)
                expected=(F(11,160000) if T==F(1,128) else F(11,80000))
                if incremental:expected-=F(21,5120000)
                self.assertEqual(G.validate_report(report),expected)
                self.assertEqual(report['area_strict_rational_upper'],expected*F(22,7))

    def test_increment_matches_three_disjoint_components(self):
        for T in G.TURN_HALF_WIDTHS:
            r=G.build_sector(T)
            outer=(F(3,25)**2-F(11,100)**2)*2*T
            wings=(F(11,100)**2-F(1,10)**2)*(2*T-F(1,512))
            self.assertEqual(r['area_pi_coefficient'],outer+wings)
            self.assertEqual(r['excluded_area_pi_coefficient'],F(21,5120000))
            self.assertEqual(r['area_pi_coefficient'],F(331 if T==F(1,128) else 683,5120000))

    def test_complete_atom_partition_not_just_area_sum(self):
        r=G.build_sector();cells=copy.deepcopy(r['sectors'])
        # Same radial shell and equal angular width: replace a cell by another,
        # creating a same-area gap and overlap. Give it a distinct identifier.
        cells[1]=copy.deepcopy(cells[2]);cells[1]['id']='replacement'
        self.assertEqual(sum(c['area_pi_coefficient'] for c in cells),r['area_pi_coefficient'])
        with self.assertRaisesRegex(ValueError,'partition gap, overlap'):
            G.validate_partition(cells,turn_halfwidth=F(1,128),incremental=True)

    def test_missing_cell_refused(self):
        cells=G.build_sector()['sectors'][:-1]
        with self.assertRaisesRegex(ValueError,'partition gap'):
            G.validate_partition(cells,turn_halfwidth=F(1,128),incremental=True)

    def test_overlap_refused(self):
        cells=G.build_sector()['sectors'];c=copy.deepcopy(cells[0]);c['id']='duplicate';cells.append(c)
        with self.assertRaisesRegex(ValueError,'partition gap, overlap'):
            G.validate_partition(cells,turn_halfwidth=F(1,128),incremental=True)

    def test_old_wedge_double_count_refused(self):
        cells=G.build_sector()['sectors']
        for i,c in enumerate(cells):
            if c['r0']==F(1,10) and c['t1']==-F(1,1024):
                cells[i]=remake(c,t1=F(0));break
        with self.assertRaisesRegex(ValueError,'old-wedge double count'):
            G.validate_partition(cells,turn_halfwidth=F(1,128),incremental=True)

    def test_whole_region_cannot_be_labeled_incremental(self):
        cells=G.build_sector(incremental=False)['sectors']
        with self.assertRaises(ValueError):G.validate_partition(cells,turn_halfwidth=F(1,128),incremental=True)

    def test_increment_cannot_be_labeled_whole(self):
        cells=G.build_sector()['sectors']
        with self.assertRaises(ValueError):G.validate_partition(cells,turn_halfwidth=F(1,128),incremental=False)

    def test_sign_reflection_exact_for_every_cell(self):
        for T,incremental in product(G.TURN_HALF_WIDTHS,(False,True)):
            for c in G.build_sector(T,incremental=incremental)['sectors']:
                x0,x1,y0,y1=c['containing_rectangle']
                mirror=G.containing_rectangle(c['r0'],c['r1'],-c['t1'],-c['t0'])
                self.assertEqual(mirror,(x0,x1,-y1,-y0))
                if c['t1']<=0:self.assertLessEqual(y1,0)
                else:self.assertGreaterEqual(y0,0)

    def test_wrong_reflection_is_refused(self):
        r=G.build_sector();c=r['sectors'][0];x0,x1,y0,y1=c['containing_rectangle']
        c['containing_rectangle']=(x0,x1,-y1,-y0)
        with self.assertRaisesRegex(ValueError,'analytic formula'):G.validate_report(r)

    def test_area_has_one_radius_jacobian_and_one_pi(self):
        # Direct integral: integral 2*pi*r dr dt = pi*(r1²-r0²)*dt.
        self.assertEqual(G.polar_area_pi(F(1,10),F(3,25),F(0),F(1,128)),F(11,320000))
        r=G.build_sector();r['sectors'][0]['area_pi_coefficient']*=2
        with self.assertRaisesRegex(ValueError,'wrong polar area'):G.validate_report(r)

    def test_wrong_aggregate_area_refused(self):
        r=G.build_sector();r['area_pi_coefficient']*=2
        with self.assertRaisesRegex(ValueError,'aggregate area'):G.validate_report(r)

    def test_bounded_source_caps_for_every_cell(self):
        for T,incremental in product(G.TURN_HALF_WIDTHS,(False,True)):
            caps=G.build_sector(T,incremental=incremental)['source_range_caps']
            self.assertLess(caps['max_halfwidth_x'],F(3,1000));self.assertLess(caps['max_halfwidth_y'],F(1,500))
            self.assertLess(caps['max_abs_center_x'],17);self.assertLess(caps['max_abs_center_y'],17)
            self.assertLessEqual(caps['max_coordinate_displacement_to_fixed_pins'],F(29,200))
            self.assertGreater(caps['minimum_x'],F(1,40))

    def test_bad_candidates_and_mode_refused(self):
        for T in (1/128,True,1,F(1,256),F(1,2),F(-1,128)):
            with self.subTest(T=T),self.assertRaises((ValueError,TypeError)):G.build_sector(T)
        for mode in (1,0,'true',None):
            with self.assertRaises(TypeError):G.build_sector(incremental=mode)

    def test_bad_cell_parameters_refused(self):
        good=(F(1,10),F(11,100),F(0),F(1,256))
        bad=[(0.1,*good[1:]),(True,*good[1:]),(F(1,10),F(1,10),*good[2:]),
             (F(1,100),*good[1:]),(good[0],F(1),*good[2:]),
             (*good[:2],-F(1,256),F(1,256)),(*good[:2],F(1,256),F(0)),
             (*good[:2],F(0),F(1,32)),(F(1,2**4097),*good[1:])]
        for args in bad:
            with self.subTest(args=args),self.assertRaises((ValueError,TypeError)):G.containing_rectangle(*args)

    def test_empty_oversized_and_duplicate_identifiers_refused(self):
        cells=G.build_sector()['sectors']
        for bad in ([],cells*3):
            with self.assertRaises(ValueError):G.validate_partition(bad,turn_halfwidth=F(1,128),incremental=True)
        cells[1]['id']=cells[0]['id']
        with self.assertRaisesRegex(ValueError,'identifiers'):G.validate_partition(cells,turn_halfwidth=F(1,128),incremental=True)

    def test_scope_and_integer_float_aliases_refused(self):
        for key,value in (('center_coordinate_limit',17.),('derivative_order_budget',18.),
                          ('centers_and_rectangles_avoid_fixed_pins',1)):
            r=G.build_sector();r['source_range_caps'][key]=value
            with self.assertRaises(ValueError):G.validate_report(r)
        r=G.build_sector();r['cell_count']=True
        with self.assertRaises(ValueError):G.validate_report(r)
        r=G.build_sector();r['scope']['integrand_certified']=True
        with self.assertRaises(ValueError):G.validate_report(r)

    def test_pi_bounds_have_elementary_exact_witnesses(self):
        self.assertEqual(G.PI_LO,F(3));self.assertEqual(G.PI_HI,F(22,7))
        lower=4*sum((F((-1)**k,2*k+1) for k in range(8)),F(0))
        self.assertGreater(lower,3)
        # x^4(1-x)^4/(1+x²) has integral 22/7-pi. Its quotient is
        # x^6-4x^5+5x^4-4x²+4, remainder -4.
        quotient={6:F(1),5:-F(4),4:F(5),2:-F(4),0:F(4)}
        self.assertEqual(sum(c/F(k+1) for k,c in quotient.items()),F(22,7))
        coeff={}
        for k,c in quotient.items():
            coeff[k]=coeff.get(k,F(0))+c;coeff[k+2]=coeff.get(k+2,F(0))+c
        coeff[0]-=4
        coeff={k:v for k,v in coeff.items() if v}
        self.assertEqual(coeff,{4:F(1),5:-F(4),6:F(6),7:-F(4),8:F(1)})


if __name__=='__main__':unittest.main()
