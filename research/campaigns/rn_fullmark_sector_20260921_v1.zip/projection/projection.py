"""Full-mark constant rational three-jet projections on a bounded RN sector.

The caller freshly authenticates the injected N6 adapter and runtime inputs.
This module proves rectangle inequalities, not an integration cover or closure.
"""
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
from pathlib import Path
import sys

from research.cover import Box
from research.interval import Interval as I, sqrt
from research.rn import side24
from research.rn.conditioning import ConditioningInconclusive, interval_ldlt

HERE = Path(__file__).resolve().parent
SOURCE_FILES = {
    'bernstein.py': (5630, '16d40be878f743fcb6726befcf3bfa60042f893aac28b08323c908cad467947f'),
    'successor_wedge_v2.py': (13112, '3d02b0b3bb7893f605d8a774b24d94398fd45cfdea47da8d08bc10e4f6a884e0'),
}
BOUNDS = Box(F(99, 1000), F(3, 25), -F(33, 2800), F(33, 2800))
HEIGHT_WINDOW = I(F(57599, 48000), F(6, 5))
MAX_VECTOR_BITS = 4096


def source_fingerprints():
    records = {}
    for name, (size, digest) in SOURCE_FILES.items():
        path = HERE / name
        if path.is_symlink() or not path.is_file() or path.stat().st_size != size:
            raise ValueError('local source size/type mismatch: ' + name)
        raw = path.read_bytes()
        if sha256(raw).hexdigest() != digest:
            raise ValueError('local source digest mismatch: ' + name)
        records[name] = dict(bytes=size, sha256=digest)
    loaded = sys.modules.get('bernstein')
    if loaded is not None:
        path = Path(getattr(loaded, '__file__', '/'))
        if not path.is_file() or sha256(path.read_bytes()).hexdigest() != SOURCE_FILES['bernstein.py'][1]:
            raise ValueError('different Bernstein module already loaded')
    return records


def _load_sources():
    source_fingerprints()
    if 'bernstein' not in sys.modules:
        spec = importlib.util.spec_from_file_location('bernstein', HERE / 'bernstein.py')
        module = importlib.util.module_from_spec(spec)
        sys.modules['bernstein'] = module
        spec.loader.exec_module(module)
    spec = importlib.util.spec_from_file_location('_fullmark_source_wedge', HERE / 'successor_wedge_v2.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


base = _load_sources()


def _exact(value, name):
    if type(value) not in (int, F):
        raise TypeError(name + ': exact int/Fraction required')
    value = F(value)
    if max(abs(value.numerator).bit_length(), value.denominator.bit_length()) > MAX_VECTOR_BITS:
        raise ValueError(name + ': exact rational resource limit')
    return value


def _rectangle(box):
    if type(box) is not Box:
        raise TypeError('exact Box required')
    for x in (box.u0, box.u1, box.v0, box.v1):
        if type(x) is not F:
            raise TypeError('box endpoints must be Fractions')
        _exact(x, 'box endpoint')
    if not (BOUNDS.u0 <= box.u0 < box.u1 <= BOUNDS.u1 and
            BOUNDS.v0 <= box.v0 < box.v1 <= BOUNDS.v1):
        raise ValueError('positive-area box must lie in the explicit bounded sector rectangle')
    return ((box.u0 + box.u1) / 2, (box.v0 + box.v1) / 2), (
        (box.u1 - box.u0) / 2, (box.v1 - box.v0) / 2)


def _direction(value):
    if type(value) not in (tuple, list) or len(value) != 3:
        raise ValueError('three exact projection coordinates required')
    result = tuple(_exact(x, 'projection coordinate') for x in value)
    if not any(result):
        raise ValueError('projection direction must be nonzero')
    return result


def choose_direction(mean, covariance, *, bits):
    """Rational midpoint inverse applied to the center mark-midpoint residual.

    This selects a direction only. Every subsequent inequality uses its actual
    polynomial variance, not the inverse used by the selection heuristic.
    """
    residual = (I.exact(HEIGHT_WINDOW.mid()) - mean[0], -mean[1], -mean[2])
    factor = interval_ldlt(covariance, round_bits=bits)
    candidates = tuple(x.round_out(64).mid() for x in factor.solve(residual))
    scale = max(map(abs, candidates))
    if scale == 0:
        raise ConditioningInconclusive('center selection produced a zero direction')
    return _direction(tuple(x / scale for x in candidates))


def projection_polynomials(n6, direction, mean, covariance, *, bits, window=HEIGHT_WINDOW):
    """Preserve the same spatial coordinates, including the entire mark window."""
    direction = _direction(direction)
    if not isinstance(window, I) or window != HEIGHT_WINDOW:
        raise ValueError('the complete fixed source height window is required')
    residual = {g: -n6.dot(direction, values, bits) for g, values in mean.items()}
    residual[(0, 0)] = (residual.get((0, 0), I.exact(0)) + direction[0] * window).round_out(bits)
    variance = {g: sum((direction[i] * direction[j] * matrix[i][j]
                        for i in range(3) for j in range(3)), I.exact(0)).round_out(bits)
                for g, matrix in covariance.items()}
    return residual, variance


def projection_energy(n6, direction, mean, covariance, halfwidths, eps,
                      conditioning_energy, energy_target, *, bits=256):
    direction = _direction(direction)
    target = _exact(energy_target, 'energy target')
    if target < 0:
        raise ValueError('energy target must be nonnegative')
    residual, variance = projection_polynomials(n6, direction, mean, covariance, bits=bits)
    p_residual = base._evaluate(residual, halfwidths, bits=bits)
    p_variance = base._evaluate(variance, halfwidths, bits=bits)
    if p_variance.hi < 0 or conditioning_energy.lo < 0:
        raise ConditioningInconclusive('negative upper variance or conditioning energy')
    epsilon = sum((abs(a) * e for a, e in zip(direction, eps)), F(0))
    if epsilon < 0 or any(e < 0 for e in eps):
        raise ValueError('nonnegative L2 remainder bounds required')
    mean_error = sqrt(conditioning_energy, n6.options(bits)).hi * epsilon
    sigma = sqrt(I(0, p_variance.hi), n6.options(bits)).hi
    variance_error = 2 * sigma * epsilon + epsilon**2
    actual_residual = (p_residual + I(-mean_error, mean_error)).round_out(bits)
    actual_variance = (p_variance + I(-variance_error, variance_error)).round_out(bits)
    if actual_variance.hi <= 0:
        raise ConditioningInconclusive('projection variance upper bound is not positive')
    # The returned quotient is valid once the caller establishes actual G>0.
    quotient = (actual_residual**2).lo / actual_variance.hi
    polynomial = base._polyadd(base._polymul(residual, residual, bits=bits), variance,
                               -target, bits=bits)
    energy_range = base._evaluate(polynomial, halfwidths, bits=bits)
    from bernstein import energy_margin
    margin, error = energy_margin(energy_range, p_residual.mag(), mean_error,
                                  variance_error, target)
    established = margin >= 0
    return dict(direction=direction, full_height_window=HEIGHT_WINDOW,
        target=target, target_established=established, margin=margin,
        polynomial_range=energy_range, energy_error_upper=error,
        residual_polynomial_range=p_residual, variance_polynomial_range=p_variance,
        actual_residual_range=actual_residual, actual_variance_range=actual_variance,
        l2_remainder=epsilon, mean_remainder=mean_error,
        variance_remainder=variance_error, separate_quotient=quotient,
        q_lower=max(quotient, target) if established else quotient,
        selection_is_proof=False, spatial_premise='actual common-law covariance G is positive definite')


def _adjugate_polynomials(covariance, *, bits):
    entries = [[{g:m[i][j] for g,m in covariance.items()} for j in range(3)] for i in range(3)]
    out = [[None]*3 for _ in range(3)]
    for i in range(3):
        for j in range(3):
            rows = [k for k in range(3) if k != j]
            cols = [k for k in range(3) if k != i]
            first = base._polymul(entries[rows[0]][cols[0]],entries[rows[1]][cols[1]],bits=bits)
            second = base._polymul(entries[rows[0]][cols[1]],entries[rows[1]][cols[0]],bits=bits)
            minor = base._polyadd(first,second,-1,bits=bits)
            out[i][j] = {g:x*((-1)**(i+j)) for g,x in minor.items()}
    return out


def _adjugate_errors(evaluated, errors):
    result = []
    for i in range(3):
        row = []
        for j in range(3):
            rows = [k for k in range(3) if k != j]
            cols = [k for k in range(3) if k != i]
            total = F(0)
            for a,b,c,d in ((rows[0],cols[0],rows[1],cols[1]),
                            (rows[0],cols[1],rows[1],cols[0])):
                total += evaluated[a][b].mag()*errors[c][d] + errors[a][b]*evaluated[c][d].mag() + errors[a][b]*errors[c][d]
            row.append(total)
        result.append(tuple(row))
    return tuple(result)


def full_mark_polynomial_range(polynomials, halfwidths, *, mark_halfwidth, bits):
    """Tensor Bernstein enclosure for R0(x,y)+s R1(x,y)+s² R2(x,y)."""
    import bernstein
    if len(polynomials) != 3 or type(mark_halfwidth) is not F or mark_halfwidth <= 0:
        raise ValueError('three polynomials and positive exact mark halfwidth required')
    degrees = tuple(max((g[k] for p in polynomials for g,x in p.items() if x != I.exact(0)),default=0)
                    for k in range(2))
    nets = [bernstein.control_net(p,halfwidths,bits=bits,degrees=degrees)[0] for p in polynomials]
    lo = hi = None
    h = mark_halfwidth
    for i in range(degrees[0]+1):
        for j in range(degrees[1]+1):
            a,b,c = (net[i][j] for net in nets)
            for value in (a-h*b+h*h*c, a-h*h*c, a+h*b+h*h*c):
                value = value.round_out(bits)
                lo = value.lo if lo is None else min(lo,value.lo)
                hi = value.hi if hi is None else max(hi,value.hi)
    return I(lo,hi),dict(spatial_degrees=degrees,mark_degree=2,
                         controls=3*(degrees[0]+1)*(degrees[1]+1))


def _affine_mark_abs(constant, linear, halfwidths, mark_halfwidth, *, bits):
    """Absolute value of an affine mark polynomial is maximized at an endpoint."""
    return max(base._evaluate(base._polyadd(constant,linear,sign*mark_halfwidth,bits=bits),
                              halfwidths,bits=bits).mag() for sign in (-1,1))


def full_adjugate_energy(n6, transform, mean, transformed_covariance, evaluated,
                         covariance_errors, determinant_error, halfwidths, eta,
                         conditioning_energy, target, *, bits):
    """Full q>=Q via d^T adj(P)d-Q det(P), with actual-G SPD supplied by caller."""
    target = _exact(target,'energy target')
    if target < 0:
        raise ValueError('energy target must be nonnegative')
    adj = _adjugate_polynomials(transformed_covariance,bits=bits)
    mark_h = F(1,96000)
    t = tuple(row[0] for row in transform)
    delta0 = []
    for i,row in enumerate(transform):
        p = {g:-n6.dot(row,m,bits) for g,m in mean.items()}
        p[(0,0)] = (p.get((0,0),I.exact(0))+t[i]*HEIGHT_WINDOW.mid()).round_out(bits)
        delta0.append(p)
    ad0, at = [], []
    for i in range(3):
        first,second = {},{}
        for j in range(3):
            first = base._polyadd(first,base._polymul(adj[i][j],delta0[j],bits=bits),bits=bits)
            second = base._polyadd(second,adj[i][j],t[j],bits=bits)
        ad0.append(first);at.append(second)
    R0,R1,R2 = {},{},{}
    for i in range(3):
        R0 = base._polyadd(R0,base._polymul(delta0[i],ad0[i],bits=bits),bits=bits)
        R1 = base._polyadd(R1,ad0[i],2*t[i],bits=bits)
        R2 = base._polyadd(R2,at[i],t[i],bits=bits)
    R0 = base._polyadd(R0,base._determinant_polynomial(transformed_covariance,bits=bits),-target,bits=bits)
    joint_range,cost = full_mark_polynomial_range((R0,R1,R2),halfwidths,mark_halfwidth=mark_h,bits=bits)
    C = _adjugate_errors(evaluated,covariance_errors)
    L = tuple(_affine_mark_abs(delta0[i],{(0,0):I.exact(t[i])},halfwidths,mark_h,bits=bits) for i in range(3))
    F_bounds = tuple(_affine_mark_abs(ad0[i],at[i],halfwidths,mark_h,bits=bits) for i in range(3))
    energy_root = sqrt(conditioning_energy,n6.options(bits)).hi
    mean_errors = tuple(energy_root*x for x in eta)
    adj_error = sum((C[i][j]*L[i]*L[j] for i in range(3) for j in range(3)),F(0))
    mean_linear_error = 2*sum((mean_errors[i]*F_bounds[i] for i in range(3)),F(0))
    mixed_error = 2*sum((mean_errors[i]*C[i][j]*L[j] for i in range(3) for j in range(3)),F(0))
    det_error = target*determinant_error
    total = adj_error+mean_linear_error+mixed_error+det_error
    margin = joint_range.lo-total
    return dict(target=target,target_established=margin>=0,margin=margin,
        full_height_window=HEIGHT_WINDOW,mark_midpoint=HEIGHT_WINDOW.mid(),mark_halfwidth=mark_h,
        transformed_height_direction=t,joint_polynomial_range=joint_range,bernstein_cost=cost,
        transformed_covariance_determinant_error=determinant_error,
        adjugate_error_bounds=C,delta_absolute_bounds=L,adjugate_delta_absolute_bounds=F_bounds,
        transformed_mean_error_bounds=mean_errors,adjugate_perturbation_error=adj_error,
        mean_linear_error=mean_linear_error,mixed_error=mixed_error,
        determinant_penalty=det_error,total_error_upper=total,
        nonnegative_mean_error_quadratic_discarded=True,
        required_premise='actual common-law transformed covariance G is positive definite',
        coordinates='all energy and determinant-error terms in same transformed coordinates')


def certify_rectangle(n6, box, *, energy_target=F(103), direction=None, order=6, bits=256,
                      full_adjugate=True):
    """Return actual determinant and full-mark energy bounds on one rectangle.

    A nonpositive determinant refuses. An unproved requested Q returns an
    explicit failed target margin with only the proved separate quotient.
    Neither outcome claims an area budget or a complete cover.
    """
    base._settings(order, bits)
    if type(full_adjugate) is not bool:
        raise TypeError('full_adjugate must be Boolean')
    center, h = _rectangle(box)
    target = _exact(energy_target, 'energy target')
    if target < 0:
        raise ValueError('energy target must be nonnegative')
    if direction is not None:
        direction = _direction(direction)
    before = source_fingerprints()
    if side24.R != F(1, 20) or side24.HEIGHT != F(6, 5) or side24.MARK_DOMAIN != (-F(1, 96000), F(1, 96000)):
        raise ValueError('source radius/birth/mark contract changed')
    lift, transform, mean, covariance, transformed = base._polynomials(n6, center, order, bits)
    determinant_polynomial = base._evaluate(base._determinant_polynomial(transformed, bits=bits), h, bits=bits)
    eps = tuple(n6.remainder_bound(beta, h, order) for beta in side24.JETS)
    eta = tuple(sum((abs(x)*e for x,e in zip(row,eps)), F(0)) for row in transform)
    evaluated = tuple(tuple(base._evaluate({g:m[i][j] for g,m in transformed.items()}, h, bits=bits)
                            for j in range(3)) for i in range(3))
    if any(evaluated[i][i].hi < 0 for i in range(3)):
        raise ConditioningInconclusive('negative upper transformed variance')
    sigma = tuple(sqrt(I(0,evaluated[i][i].hi),n6.options(bits)).hi for i in range(3))
    errors = tuple(tuple(sigma[i]*eta[j]+sigma[j]*eta[i]+eta[i]*eta[j]
                        for j in range(3)) for i in range(3))
    error = base._determinant_error(evaluated, errors)
    jacobian = transform[0][0]*transform[1][1]*transform[2][2]
    if jacobian == 0:
        raise ConditioningInconclusive('singular exact preconditioner')
    determinant = ((determinant_polynomial+I(-error,error))/(jacobian**2)).round_out(bits)
    if determinant.lo <= 0:
        raise ConditioningInconclusive('three-jet determinant lower bound is not positive')
    automatic = direction is None
    if automatic:
        direction = choose_direction(mean[(0,0)], covariance[(0,0)], bits=bits)
    energy = projection_energy(n6,direction,mean,covariance,h,eps,
                               lift['conditioning_energy'],target,bits=bits)
    full_energy = None
    q_lower = energy['q_lower']
    if full_adjugate and not energy['target_established']:
        full_energy = full_adjugate_energy(n6,transform,mean,transformed,evaluated,errors,error,h,eta,
                                          lift['conditioning_energy'],target,bits=bits)
        if full_energy['target_established']:
            q_lower = max(q_lower,target)
    if source_fingerprints() != before:
        raise ValueError('local source identities changed during calculation')
    return dict(box=box,center=center,halfwidths=h,order=order,bits=bits,
        determinant=determinant,determinant_lower=determinant.lo,
        q_lower=q_lower,projection_evidence=energy,full_adjugate_evidence=full_energy,
        direction_selection='RATIONAL_MIDPOINT_FULL_INVERSE' if automatic else 'CALLER_FIXED_RATIONAL',
        determinant_polynomial_interval=determinant_polynomial,
        determinant_error_upper=error,determinant_transform=jacobian,
        l2_remainders=eps,transformed_l2_remainders=eta,covariance_error_upper=errors,
        conditioning_energy=lift['conditioning_energy'],six_pin_pivots=lift['six_pin_pivots'],
        source_binding=lift['source_binding'],local_sources=before,
        radius=side24.R,birth=side24.HEIGHT,fixed_pin_axis='x',
        mark_domain=side24.MARK_DOMAIN,full_height_window=HEIGHT_WINDOW,
        allowed_box_domain=BOUNDS,
        statement='BOUNDED_RECTANGLE_ACTUAL_LAW_FULL_MARK_PROJECTION_LOWER_BOUND',
        spatial_cover=False,full_annulus_certified=False,all_radii_certified=False,
        all_pin_orientations_certified=False,scientific_status_changed=False,
        original_prize_closed=False,authority='NONE',organizational_independence_credit=0)
