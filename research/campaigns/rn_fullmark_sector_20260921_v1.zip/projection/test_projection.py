"""Exact synthetic adversarial controls; no new spatial-region probe grid."""
import argparse
from fractions import Fraction as F
from itertools import permutations, product
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

sys.dont_write_bytecode = True
parser=argparse.ArgumentParser(add_help=False)
parser.add_argument('--repo',type=Path,required=True)
args,rest=parser.parse_known_args()
sys.path.insert(0,str(args.repo.resolve(strict=True)))
import projection as p
from research.interval import Interval as I
from research.cover import Box

ZERO=I.exact(0)
IDENTITY=tuple(tuple(I.exact(i==j) for j in range(3)) for i in range(3))
RATIONAL_IDENTITY=tuple(tuple(F(i==j) for j in range(3)) for i in range(3))
ZERO_ERRORS=((F(0),)*3,)*3


class Arithmetic:
    @staticmethod
    def dot(a,b,bits):
        return sum((x*y for x,y in zip(a,b)),ZERO).round_out(bits)
    @staticmethod
    def options(bits):
        return 110


def det(matrix):
    result=F(0)
    for order in permutations(range(3)):
        inv=sum(order[i]>order[j] for i in range(3) for j in range(i+1,3))
        term=F((-1)**inv)
        for i,j in enumerate(order):term*=matrix[i][j]
        result+=term
    return result


def full(delta=(F(1),F(0),F(0)), errors=ZERO_ERRORS, eta=(F(0),)*3, determinant_error=F(0), target=F(3,4)):
    mean={(0,0):(I.exact(p.HEIGHT_WINDOW.mid()-delta[0]),I.exact(-delta[1]),I.exact(-delta[2]))}
    return p.full_adjugate_energy(Arithmetic,RATIONAL_IDENTITY,mean,{(0,0):IDENTITY},
        IDENTITY,errors,determinant_error,(F(1),F(1)),eta,I.exact(1),target,bits=256)


class ProjectionTests(unittest.TestCase):
    def test_exact_source_copies(self):
        self.assertEqual(set(p.source_fingerprints()),set(p.SOURCE_FILES))

    def test_mutated_source_digest_fails(self):
        changed=dict(p.SOURCE_FILES)
        size,_=changed['bernstein.py'];changed['bernstein.py']=(size,'0'*64)
        with patch.object(p,'SOURCE_FILES',changed):
            with self.assertRaisesRegex(ValueError,'digest mismatch'):p.source_fingerprints()

    def test_domain_is_explicit_and_h_caps_fit_original_remainders(self):
        c,h=p._rectangle(p.BOUNDS)
        self.assertTrue(all(abs(x)<17 for x in c))
        self.assertTrue(all(0<x<1 for x in h))
        self.assertLess(max(abs(c[0]-F(1,40)),abs(c[0]+F(1,40)),abs(c[1])),18)
        with self.assertRaises(ValueError):p._rectangle(Box(F(98,1000),F(1,10),-F(1,1000),F(1,1000)))
        with self.assertRaises(ValueError):p._rectangle(Box(F(1,10),F(11,100),F(0),F(1,50)))
        with self.assertRaises(TypeError):p._rectangle((F(1,10),F(11,100),F(0),F(1,100)))

    def test_bad_direction_and_target_inputs(self):
        for value in ((0,0,0),(1,0),(True,0,1),(1.0,0,1),(F(1,2**4097),0,1)):
            with self.subTest(value=str(value)[:50]):
                with self.assertRaises((ValueError,TypeError)):p._direction(value)
        self.assertEqual(p._direction((1,0,-F(1,3))),(F(1),F(0),-F(1,3)))

    def test_midpoint_inverse_only_selects_a_nonzero_exact_direction(self):
        direction=p.choose_direction((I.exact(p.HEIGHT_WINDOW.mid()-2),I.exact(-1),ZERO),IDENTITY,bits=256)
        self.assertTrue(all(type(x) is F for x in direction))
        self.assertEqual(direction,(F(1),F(1,2),F(0)))

    def test_full_mark_is_not_replaceable_by_its_midpoint(self):
        mean={(0,0):(I.exact(p.HEIGHT_WINDOW.lo),ZERO,ZERO)}
        covariance={(0,0):IDENTITY}
        with self.assertRaisesRegex(ValueError,'complete fixed'):
            p.projection_polynomials(Arithmetic,(1,0,0),mean,covariance,bits=256,
                                     window=I.exact(p.HEIGHT_WINDOW.mid()))
        q=F(1,96000)**2/2
        result=p.projection_energy(Arithmetic,(1,0,0),mean,covariance,(F(1),F(1)),
                                    (F(0),)*3,I.exact(1),q,bits=256)
        self.assertGreater((p.HEIGHT_WINDOW.mid()-p.HEIGHT_WINDOW.lo)**2,q)
        self.assertFalse(result['target_established'])
        self.assertEqual(result['q_lower'],0)

    def test_projection_cross_covariances_are_retained(self):
        mean={(0,0):(ZERO,ZERO,ZERO)}
        mat=((I.exact(2),I.exact(1),ZERO),(I.exact(1),I.exact(2),ZERO),(ZERO,ZERO,I.exact(1)))
        _,variance=p.projection_polynomials(Arithmetic,(1,-1,0),mean,{(0,0):mat},bits=256)
        self.assertEqual(variance[(0,0)],I.exact(2))
        self.assertNotEqual(variance[(0,0)],I.exact(4))

    def test_projection_errors_are_nonzero_when_tail_is_nonzero(self):
        mean={(0,0):(ZERO,ZERO,ZERO)}
        result=p.projection_energy(Arithmetic,(1,0,0),mean,{(0,0):IDENTITY},(F(1),F(1)),
                                  (F(1,100),F(0),F(0)),I.exact(4),F(1),bits=256)
        self.assertGreaterEqual(result['mean_remainder'],F(1,50))
        self.assertLess(result['mean_remainder'],F(20000001,1000000000))
        self.assertGreaterEqual(result['variance_remainder'],F(201,10000))
        self.assertLess(result['variance_remainder'],F(20100001,1000000000))
        self.assertGreater(result['energy_error_upper'],0)

    def test_adjugate_orientation_on_nonsymmetric_matrix(self):
        m=((F(3),F(2),F(1)),(F(0),F(4),F(2)),(F(1),F(0),F(5)))
        ints=tuple(tuple(I.exact(x) for x in row) for row in m)
        adj=p._adjugate_polynomials({(0,0):ints},bits=256)
        a=[[adj[i][j].get((0,0),ZERO).lo for j in range(3)] for i in range(3)]
        for i in range(3):
            for j in range(3):self.assertEqual(sum(m[i][k]*a[k][j] for k in range(3)),det(m)*F(i==j))

    def test_adjugate_perturbation_keeps_quadratic_terms(self):
        errors=((F(0),F(0),F(0)),(F(0),F(1),F(0)),(F(0),F(0),F(1)))
        C=p._adjugate_errors(IDENTITY,errors)
        self.assertEqual(C[0][0],3)  # (1+1)(1+1)-1=3; linear-only gives2.
        self.assertGreater(C[0][0],2)

    def test_all_symmetric_perturbation_corners_fit_minor_errors(self):
        radii=((F(1,4),F(1,7),F(1,9)),(F(1,7),F(1,5),F(1,11)),(F(1,9),F(1,11),F(1,6)))
        C=p._adjugate_errors(IDENTITY,radii)
        positions=((0,0),(0,1),(0,2),(1,1),(1,2),(2,2))
        for signs in product((-1,1),repeat=6):
            G=[[F(i==j) for j in range(3)] for i in range(3)]
            for (i,j),s in zip(positions,signs):G[i][j]=G[j][i]=F(i==j)+s*radii[i][j]
            A=p._adjugate_polynomials({(0,0):tuple(tuple(I.exact(x) for x in row) for row in G)},bits=256)
            for i in range(3):
                for j in range(3):
                    rows=[k for k in range(3) if k!=j];cols=[k for k in range(3) if k!=i]
                    actual=(-1)**(i+j)*(G[rows[0]][cols[0]]*G[rows[1]][cols[1]]-G[rows[0]][cols[1]]*G[rows[1]][cols[0]])
                    self.assertLessEqual(abs(actual-F(i==j)),C[i][j])
                    self.assertLessEqual(A[i][j].get((0,0),ZERO).lo,actual)
                    self.assertGreaterEqual(A[i][j].get((0,0),ZERO).hi,actual)

    def test_missing_adjugate_perturbation_would_falsely_pass(self):
        # P=I,G=diag(1/2,2,1),d=e2,Q=3/4, actual determinant change zero.
        errors=((F(1,2),F(0),F(0)),(F(0),F(1),F(0)),(F(0),F(0),F(0)))
        result=full(delta=(F(0),F(1),F(0)),errors=errors)
        self.assertFalse(result['target_established'])
        self.assertGreater(result['joint_polynomial_range'].lo,0)
        self.assertEqual(F(1,2)-F(3,4),-F(1,4))
        self.assertGreater(result['adjugate_perturbation_error'],0)

    def test_missing_mean_linear_cross_term_would_falsely_pass(self):
        # P=G=I,d=e1,e=-e1/4,Q=3/4. True margin=9/16-3/4<0.
        result=full(eta=(F(1,4),F(0),F(0)))
        self.assertFalse(result['target_established'])
        self.assertGreater(result['joint_polynomial_range'].lo,0)
        self.assertEqual(F(3,4)**2-F(3,4),-F(3,16))
        self.assertGreater(result['mean_linear_error'],0)

    def test_height_endpoint_counterexample_is_retained(self):
        polys=({(0,0):I.exact(F(1,4))},{(0,0):I.exact(2)},{(0,0):I.exact(1)})
        interval,cost=p.full_mark_polynomial_range(polys,(F(1),F(1)),mark_halfwidth=F(1,4),bits=256)
        self.assertEqual(interval,I(-F(3,16),F(13,16)))
        self.assertGreater(F(1,4),0)  # Midpoint-only mutant passes.
        self.assertEqual(cost['mark_degree'],2)

    def test_common_spatial_degree_elevation_and_mark_values(self):
        polys=({(0,0):I.exact(1),(2,0):I.exact(1)},
               {(0,1):I.exact(2)},{(0,0):I.exact(-3)})
        interval,cost=p.full_mark_polynomial_range(polys,(F(1),F(1)),mark_halfwidth=F(1,4),bits=256)
        self.assertEqual(cost['spatial_degrees'],(2,1))
        for x,y,s in product((F(-1),F(0),F(1)),(F(-1),F(0),F(1)),(-F(1,4),F(0),F(1,4))):
            value=1+x*x+2*s*y-3*s*s
            self.assertLessEqual(interval.lo,value);self.assertGreaterEqual(interval.hi,value)

    def test_full_adjugate_positive_baseline(self):
        result=full(delta=(F(2),F(0),F(0)),target=F(1))
        self.assertTrue(result['target_established'])
        self.assertGreater(result['margin'],2)
        self.assertEqual(result['total_error_upper'],0)

    def test_transformed_height_enters_every_coordinate(self):
        T=((F(1),F(0),F(0)),(F(2),F(1),F(0)),(F(3),F(0),F(1)))
        mean={(0,0):(I.exact(p.HEIGHT_WINDOW.mid()-1),ZERO,ZERO)}
        result=p.full_adjugate_energy(Arithmetic,T,mean,{(0,0):IDENTITY},IDENTITY,ZERO_ERRORS,F(0),
            (F(1),F(1)),(F(0),)*3,I.exact(1),F(1),bits=256)
        self.assertEqual(result['transformed_height_direction'],(F(1),F(2),F(3)))
        self.assertGreater(result['joint_polynomial_range'].lo,12)

    def test_determinant_error_penalty_is_not_rescaled_or_dropped(self):
        result=full(delta=(F(1),F(0),F(0)),determinant_error=F(2),target=F(3,4))
        self.assertEqual(result['determinant_penalty'],F(3,2))
        self.assertFalse(result['target_established'])

    def test_affine_height_absolute_bound_uses_endpoints(self):
        val=p._affine_mark_abs({(0,0):I.exact(2)},{(0,0):I.exact(-3)},
                              (F(1),F(1)),F(1,4),bits=256)
        self.assertEqual(val,F(11,4))


if __name__=='__main__':
    unittest.main(argv=[sys.argv[0],*rest],verbosity=2)
