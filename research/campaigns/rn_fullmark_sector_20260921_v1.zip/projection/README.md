# Full-mark RN energy module

`projection.py` supplies full-height-window lower bounds for Mahalanobis energy
on exact rectangles inside x in[99/1000,3/25], |y|<=33/2800, with unchanged
SIDE24 pins, r=1/20 and b=6/5. It first tries a fixed rational projection, then
a common full-adjugate polynomial with a joint spatial/height Bernstein bound.
The adjugate path preserves cancellation that a constant projection can lose.

The frozen adjacent `bernstein.py` and `successor_wedge_v2.py` are exact copies;
their embedded source hashes are checked on entry and exit. Add this directory
and the verified repository to the Python import path, then use:

```python
from fractions import Fraction as F
from research.rn.n6_inputs import checked_n6
import projection

n6, before = checked_n6(repo)
result = projection.certify_rectangle(
    n6, box, energy_target=F(103), order=6, bits=256,
    full_adjugate=True)
_, after = checked_n6(repo)
if before != after:
    raise ValueError("runtime input identity changed")
```

The caller must verify `DEPENDENCIES.json` before importing repository modules,
and verify runtime identities after its whole calculation. The module cannot
authenticate a caller-injected adapter by trusting its returned labels alone.

Results contain `determinant_lower`, `q_lower`, `projection_evidence`, optional
`full_adjugate_evidence`, original source binding, explicit full mark window,
radius, birth, axis, domain and scope flags. A nonpositive determinant raises
`ConditioningInconclusive`. A negative requested-energy margin retains only the
proved separate projection quotient; the requested threshold is not granted.
No spatial cover or area integral is asserted by this module.

Run exact synthetic controls with:

```sh
python -B test_projection.py --repo /path/to/research-main
python -B -O test_projection.py --repo /path/to/research-main
```

`PROOF.md` contains both analytic inequalities and the original derivative-domain
justification. `PROBES.json` preserves the eight initial region diagnostics,
including determinant and projection failures, as noncertifying history. The
parent's separate cover runner owns successful spatial certificates, partitions,
source-bound majorant composition and budget comparisons. Same-provider technical
review has zero organizational-independence credit; scientific status is unchanged.
