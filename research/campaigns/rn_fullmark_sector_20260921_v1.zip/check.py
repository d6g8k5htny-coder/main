#!/usr/bin/env python3
"""Certify a bounded polar increment of the existing RN wedge, or retain refusals."""
import argparse
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
PRIOR_SHA = '5adac11684157b9f2035c73101fd3f701b26206461dcd704376b3f9cc79cb649'
METADATA = ('quarantine/EXCLUSIONS.json', 'drive/inventory.jsonl', 'drive/source_map/Payloads.csv')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def identity(path):
    require(not path.is_symlink() and path.is_file(), 'regular file required: '+str(path))
    raw = path.read_bytes()
    return {'bytes':len(raw),'sha256':sha256(raw).hexdigest()}


def check_pins(repo):
    data = json.loads((HERE/'DEPENDENCIES.json').read_bytes())
    require(data['schema'] == 'RN_SECTOR_REPOSITORY_DEPENDENCIES_V1', 'wrong dependency schema')
    pins = data['files']
    # Check current exclusion/eligibility metadata before any source payload.
    for p in METADATA:
        require(p in pins and identity(repo/p) == pins[p], 'current source metadata drift: '+p)
    for p, expected in pins.items():
        require(not Path(p).is_absolute() and '..' not in Path(p).parts, 'unsafe dependency path')
        require((repo/p).resolve() == repo/p and identity(repo/p) == expected, 'source/code drift: '+p)
    return data


def local_identities():
    paths = [HERE/'check.py', HERE/'DEPENDENCIES.json', HERE/'geometry/geometry.py',
             HERE/'inputs/prior-wedge-result.json', HERE/'inputs/sharp_variance/check.py',
             HERE/'inputs/sharp_variance/DEPENDENCIES.json', HERE/'inputs/sharp_variance/PROOF.md']
    paths += sorted((HERE/'projection').glob('*.py'))
    return {str(p.relative_to(HERE)):identity(p) for p in paths if not p.name.startswith('test_')}


def load(name, path):
    spec = importlib.util.spec_from_file_location(name,path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def encode(value):
    if isinstance(value,F):return str(value)
    if hasattr(value,'lo') and hasattr(value,'hi'):return [str(value.lo),str(value.hi)]
    if hasattr(value,'as_json'):return value.as_json()
    if type(value) is dict:return {str(k):encode(v) for k,v in value.items()}
    if isinstance(value,(tuple,list)):return [encode(v) for v in value]
    return value


def canonical(value):
    return (json.dumps(encode(value),sort_keys=True,indent=2)+'\n').encode()


def summarize(geometry, attempts, old, pi_upper=F(22,7)):
    """Only complete, domain-matched accepted cells contribute a total."""
    geo = load('sector_geometry_summary',HERE/'geometry/geometry.py')
    geo.validate_report(geometry)
    require(type(pi_upper) is F and pi_upper==F(22,7), 'use the proved rational pi upper bound')
    require(old['schema']=='RN_LOCAL_WEDGE_COMPOSITION_V1' and
            old['geometry']['radii']==['1/10','11/100'] and
            old['geometry']['turns']==['-1/1024','1/1024'] and
            old['geometry']['area_pi_coefficient']=='21/5120000', 'old wedge scope mismatch')
    require(geometry['incremental'] is True and geometry['excluded_area_pi_coefficient']==F(21,5120000),
            'old allocation must be excluded from the increment')
    require(len(attempts)==geometry['cell_count'], 'missing attempted cells')
    for cell, attempt in zip(geometry['sectors'],attempts):
        require(attempt['cell']==cell, 'attempt/domain mismatch or reordering')
    pending = [a['cell']['id'] for a in attempts if a['outcome']!='CERTIFIED_CELL']
    result = {'pending':pending,'pending_count':len(pending),'increment_integral_upper':None,
              'whole_sector_integral_upper':None,'outcome':'INCONCLUSIVE_COVER'}
    if pending:return result
    total = F(0)
    for a in attempts:
        require(all(type(a[k]) is F for k in ('integrand_upper','determinant_lower','q_lower','area_pi_coefficient')),
                'exact rational numerical values required')
        require(a['integrand_upper']>0 and a['determinant_lower']>0 and a['q_lower']>=0,
                'invalid numerical upper-bound premise')
        require(a['area_pi_coefficient']==a['cell']['area_pi_coefficient'], 'wrong polar area')
        child = a['numerical_certificate']
        box = child['box']
        require(all(hasattr(box,k) for k in ('u0','u1','v0','v1')) and
                (box.u0,box.u1,box.v0,box.v1)==a['cell']['containing_rectangle'], 'child rectangle mismatch')
        require(type(child['determinant_lower']) is F and type(child['q_lower']) is F and
                child['determinant_lower']==a['determinant_lower'] and child['q_lower']==a['q_lower'],
                'child determinant or energy mismatch')
        window = child['full_height_window']
        require(child['radius']==F(1,20) and child['birth']==F(6,5) and child['fixed_pin_axis']=='x' and
                child['mark_domain']==(-F(1,96000),F(1,96000)) and
                (window.lo,window.hi)==(F(57599,48000),F(6,5)), 'child source configuration mismatch')
        total += a['cell']['area_pi_coefficient']*a['integrand_upper']
    increment = pi_upper*total
    whole = increment+F(old['integral_strict_upper'])
    result.update(outcome='CERTIFIED_SCOPED_COVER',increment_integral_upper=increment,
                  whole_sector_integral_upper=whole,
                  increment_below_1e_minus_6=increment<F(1,1000000),
                  full_annulus_reference_budget=F(44201,20000000),
                  full_annulus_reference_budget_is_not_closed=True,
                  area_gain_over_old_wedge=geometry['whole_area_pi_coefficient']/F(21,5120000))
    return result


def run(repo, output, turn_halfwidth, energy_target):
    repo = repo.resolve(strict=True)
    require(not output.exists() and not output.is_symlink(), 'output must be fresh')
    output = output.parent.resolve(strict=True)/output.name
    require(not output.is_relative_to(repo) and not output.is_relative_to(HERE), 'output must be external')
    require(turn_halfwidth in (F(1,128),F(1,64)), 'unbounded sector request')
    require(type(energy_target) is F and 0<=energy_target<=2048, 'invalid energy target')
    deps = check_pins(repo)
    local = local_identities()
    prior_raw = (HERE/'inputs/prior-wedge-result.json').read_bytes()
    require(sha256(prior_raw).hexdigest()==PRIOR_SHA, 'prior result identity mismatch')
    old = json.loads(prior_raw)
    sys.path.insert(0,str(repo));sys.path.insert(0,str(HERE/'projection'))
    geo = load('sector_geometry',HERE/'geometry/geometry.py')
    sharp = load('sector_sharp',HERE/'inputs/sharp_variance/check.py')
    projection = load('sector_projection',HERE/'projection/projection.py')
    from research.rn.n6_inputs import checked_n6
    from research.rn.conditioning import ConditioningInconclusive
    from research.cover import Box
    api = sharp.load_api(repo,sharp.dependency_rows())
    # Repository code reachable only through the declared exact dependency set.
    for module in list(sys.modules.values()):
        path = getattr(module,'__file__',None)
        if path and Path(path).resolve().is_relative_to(repo):
            require(str(Path(path).resolve().relative_to(repo)) in deps['files'], 'unlisted imported repository code')
    binding = api[2].source_binding(repo)
    require(binding==old['source_binding'], 'old/new source binding differs')
    caps = sharp.stationary_caps(api[1])
    n6, source_before = checked_n6(repo)
    geometry = geo.build_sector(turn_halfwidth,incremental=True)
    geo.validate_report(geometry)
    output.mkdir()
    attempts, timings = [], []
    for index, cell in enumerate(geometry['sectors']):
        started = time.monotonic()
        try:
            # Admission is refreshed before each new source-dependent rectangle.
            _, current_sources = checked_n6(repo)
            require(current_sources==source_before, 'source drift between cells')
            result = projection.certify_rectangle(n6,Box(*cell['containing_rectangle']),
                energy_target=energy_target,order=6,bits=256)
            D,Q = result['determinant_lower'],result['q_lower']
            require(result['mark_domain']==(-F(1,96000),F(1,96000)), 'mark scope changed')
            cap = sharp.majorant(api,D,Q)['integrand_upper']
            entry = {'cell':cell,'outcome':'CERTIFIED_CELL','determinant_lower':D,'q_lower':Q,
                     'integrand_upper':cap,'area_pi_coefficient':cell['area_pi_coefficient'],
                     'numerical_certificate':result}
        except ConditioningInconclusive as error:
            entry = {'cell':cell,'outcome':'RETAINED_REFUSAL','reason':str(error)}
        attempts.append(entry)
        timings.append({'cell':cell['id'],'elapsed_seconds':time.monotonic()-started})
        (output/f'cell-{index:02d}.json').write_bytes(canonical(entry))
        print(f'{index+1}/{len(geometry["sectors"])} {cell["id"]} {entry["outcome"]}',flush=True)
    _, source_after = checked_n6(repo)
    require(source_before==source_after and api[2].source_binding(repo)==binding, 'runtime source drift')
    require(check_pins(repo)==deps and local_identities()==local, 'input or implementation drift')
    totals = summarize(geometry,attempts,old)
    report = {'schema':'RN_FULLMARK_SECTOR_INCREMENT_V1','geometry':geometry,'attempts':attempts,
              'totals':totals,'energy_target':energy_target,'stationary_caps':caps,
              'source_binding':binding,'runtime_sources':source_before,'repository_inputs':deps,
              'implementation':local,'inputs_unchanged':True,'prior_wedge_result_sha256':PRIOR_SHA,
              'scope':{'fixed_r':'1/20','fixed_b':'6/5','fixed_pin_axis':'x',
                       'full_height_window':['57599/48000','6/5'],'old_wedge_counted_once':True,
                       'full_annulus_closed':False,'all_radii_closed':False,
                       'all_pin_orientations_closed':False,'q0_closed':False,
                       'scientific_status_changed':False,'organizational_independence_credit':0,
                       'authority':'NONE','imported_h3_and_pin_energy_reproved':False}}
    (output/'result.json').write_bytes(canonical(report))
    (output/'timings.json').write_bytes(canonical({'timings':timings,'meaning':'Local wall observations only; not certificate or independent benchmark.'}))
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--turns',choices=['1/128','1/64'],default='1/128')
    parser.add_argument('--energy-target',choices=['20','64','80','103','128'],default='103')
    args = parser.parse_args()
    report = run(args.repo,args.output,F(args.turns),F(args.energy_target))
    print(report['totals']['outcome'],flush=True)
    return 0 if report['totals']['pending_count']==0 else 2


if __name__=='__main__':
    raise SystemExit(main())
