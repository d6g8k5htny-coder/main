# One rectangle replaces twelve for the existing RN wedge

The same fixed-axis SIDE24 wedge at `r=1/20` now has a complete certificate
using **one auxiliary containing rectangle instead of twelve strips**.
The original source law, height window, H3 normalization, wedge area and all
Taylor/covariance/determinant remainders are retained.

Exact replay proves:

- `det(G) > 8/10^25` throughout the containing rectangle.
- Full-mark Mahalanobis energy `q >= 103` by a common mean-square/variance polynomial.
- Typed RN integrand `< 1/100000` and wedge integral `< 33/256000000000`.

The computed integrand upper is approximately `5.4542e-6`; this decimal is a
display only. Exact rational endpoints are in `result.json`. The entire
outer rectangle was refused by the original determinant enclosure. Bernstein
alone fixes determinant positivity but remains too loose for the existing
integrand budget at1,2 or4strips. The common polynomial
`P_mu^2 - 103 P_var` supplies the additional energy inequality that makes a
single rectangle sufficient. Its error allowance retains
`2*max|P_mu|*mean_error + 103*variance_error`.

The result covers the existing wedge only. It does not enlarge the annulus
coverage, prove an all-radius/all-orientation result, reprove imported H3 or
pin-energy premises, establish event transfer, change canonical status or
earn organizational independence credit. See `PROOF.md` for the derivation.

## Reproduction

From this bundle, with Python3.11 and a repository checkout matching
`DEPENDENCIES.json`:

```sh
python -B check_v2.py --repo /absolute/repository --output /absolute/new-output --verify result.json
python -B -O check_v2.py --repo /absolute/repository --output /absolute/another-new-output --verify result.json
PYTHONPATH=/absolute/repository python -B -m unittest -v test_bernstein test_energy
PYTHONPATH=/absolute/repository python -B -O -m unittest -v test_bernstein test_energy
```

Output destinations must be fresh and outside both the repository and this
bundle. The runner checks repository input hashes before imports and after
numerical work, authenticates the original N6 archive/data through the
existing source-eligibility binder before and after work, checks the copied
original source identity, and verifies the final result byte for byte when
`--verify` is supplied. It writes no repository file.

Twenty-one tests passed in each Python mode. Normal and optimized results
matched exactly, including the retained original one-box refusal. This is
deterministic computation evidence alongside the written proof, not an
automatic scientific promotion.

## Files and evidence classification

`bernstein.py` implements the exact tensor transform and energy error bound.
`source_side24_wedge.py` preserves the pinned original.
`successor_wedge.py` is a range-only comparison module used in controls.
`successor_wedge_v2.py` adds the common energy polynomial; it is the final
mathematical successor. `check_v2.py` is the sole final replay entry point.

`result.json`, `VALIDATION.json` and the two test logs record the final proof
replay. `controls/` retains two development numerical records: the range-only
one-box budget failure and the original twelve-strip success. These explain
the mathematical change but are not substituted for the final replay.
`timings-*.json` contains nondeterministic local wall timings separately from
the certificate; order and warm caches affect them. No independent speedup
claim is made from these observations.

`MANIFEST.json` is the exact delivery allowlist. Unlisted scratch probes,
older runs and superseded runners are excluded. The R17 claim is
`3371117b-0d32-4787-b46f-fa9243ff85e1`, target
`Q0-RN-BERNSTEIN-RANGE-20260921-v1`. Release is coordinated by the parent task.
