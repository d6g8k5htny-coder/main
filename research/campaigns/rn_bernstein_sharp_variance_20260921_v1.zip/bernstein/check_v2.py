"""Replay bounded RN Bernstein comparison in a fresh external directory."""
import argparse
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import sys
import time

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent


def identity(path):
    raw=path.read_bytes()
    return {'bytes':len(raw),'sha256':sha256(raw).hexdigest()}


def check_pins(repo):
    pins=json.loads((HERE/'DEPENDENCIES.json').read_text())
    for relative, expected in pins['files'].items():
        path=repo/relative
        if path.is_symlink() or identity(path)!=expected:
            raise ValueError('repository input changed: '+relative)
    return pins


def encode(value):
    from research.interval import Interval as I
    from research.cover import Box
    if isinstance(value,F):return str(value)
    if isinstance(value,I):return [str(value.lo),str(value.hi)]
    if isinstance(value,Box):return value.as_json()
    if type(value) is dict:return {str(k):encode(v) for k,v in value.items()}
    if isinstance(value,(tuple,list)):return [encode(v) for v in value]
    return value


def canonical(value):return (json.dumps(encode(value),sort_keys=True,indent=2)+'\n').encode()


def load(name):
    spec=importlib.util.spec_from_file_location(name,HERE/(name+'.py'))
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


def destination(path,repo):
    if path.exists() or path.is_symlink():raise ValueError('output must not exist')
    resolved=path.resolve()
    if any(resolved.is_relative_to(p) for p in (repo,HERE)):
        raise ValueError('output must be outside the repository and bundle')
    if not resolved.parent.is_dir():raise ValueError('output parent must exist')
    return resolved


def run(repo,output,pieces):
    repo=repo.resolve();output=destination(output,repo)
    if not pieces or any(type(p) is not int or p not in (1,2,4,12) for p in pieces) or len(set(pieces))!=len(pieces):
        raise ValueError('distinct bounded piece counts 1,2,4,12 required')
    before=check_pins(repo)
    if identity(HERE/'source_side24_wedge.py') != before['files']['research/rn/side24_wedge.py']:
        raise ValueError('copied original wedge source does not match its pinned repository bytes')
    local={p.name:identity(p) for p in (HERE/'bernstein.py',HERE/'source_side24_wedge.py',HERE/'successor_wedge_v2.py',HERE/'check_v2.py')}
    sys.path.insert(0,str(repo));sys.path.insert(0,str(HERE))
    from research.rn.n6_inputs import checked_n6
    from research.rn.conditioning import ConditioningInconclusive
    from research.rn.density_majorant import density_moment_majorant
    from research.interval import pi,Interval as I
    from research.cover.ledger import check_exact_partition
    original=load('source_side24_wedge');successor=load('successor_wedge_v2')
    n6,sources_before=checked_n6(repo)
    output.mkdir()
    attempts=[];timings=[]
    try:
        for count in pieces:
            for label,module in (('original',original),('bernstein',successor)):
                started=time.monotonic()
                try:
                    result=module.certify_wedge(n6,pieces=count)
                    check_exact_partition(module.OUTER_BOX,[r['box'] for r in result['pieces']],what='Bernstein scratch auxiliary strips')
                    D,Q=result['determinant_lower'],result['q_lower']
                    majorant=density_moment_majorant(D,Q,repo_root=repo,bits=256)
                    area=I.exact(module.containment()['area_pi_coefficient'])*pi(110)
                    value=majorant['integrand_upper']
                    entry={'pieces':count,'method':label,'outcome':'CERTIFIED_SCOPED_BOUND','report':result,
                           'majorant':majorant,'polar_area':area,'integral':area*I(0,value),
                           'meets_original_budget':value<F(1,100000),'cover_pending':0}
                except ConditioningInconclusive as error:
                    entry={'pieces':count,'method':label,'outcome':'RETAINED_REFUSAL','reason':str(error),
                           'meets_original_budget':False,'cover_pending':count}
                attempts.append(entry)
                timings.append({'pieces':count,'method':label,'elapsed_seconds':time.monotonic()-started})
                (output/('attempt_'+str(count)+'_'+label+'.json')).write_bytes(canonical(entry))
                print(label+' pieces='+str(count)+' '+entry['outcome']+' budget='+str(entry['meets_original_budget']),flush=True)
            if attempts[-1]['meets_original_budget']:
                break
        _,sources_after=checked_n6(repo)
        if sources_before!=sources_after or check_pins(repo)!=before:
            raise ValueError('source identity changed during execution')
        if local!={p:identity(HERE/p) for p in local}:
            raise ValueError('scratch implementation changed during execution')
        report={'schema':'RN_BIVARIATE_BERNSTEIN_ENERGY_SUCCESSOR_V2','attempts':attempts,
                'repository_inputs':before,'runtime_sources':sources_before,'implementation':local,
                'source_and_implementation_unchanged':True,
                'scope':{'fixed_r':'1/20','fixed_pin_axis':'x','existing_wedge_only':True,
                         'imported_H3_and_pin_energy':True,'all_remainders_retained':True,
                         'full_annulus_closed':False,'all_radius_closed':False,'scientific_status_changed':False,
                         'organizational_independence_credit':0,'authority':'NONE'}}
        (output/'result.json').write_bytes(canonical(report))
        (output/'timings.json').write_bytes(canonical({'timings':timings,'python':sys.version,'optimize':sys.flags.optimize,
            'scope':'Local observed wall time only; includes warm-cache effects, not an independent compute-cost experiment.'}))
        return report
    finally:
        check_pins(repo)


def main():
    p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--pieces',type=int,nargs='+',default=[1]);p.add_argument('--verify',type=Path)
    args=p.parse_args()
    result=run(args.repo,args.output,args.pieces)
    if args.verify and args.verify.read_bytes()!=canonical(result):raise ValueError('frozen result differs from replay')


if __name__=='__main__':main()
