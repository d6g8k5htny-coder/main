import unittest
from fractions import Fraction as F
from itertools import product
from unittest.mock import patch
from research.interval import Interval as I
from research.rn.n6_inputs import checked_n6
from research.rn.density_majorant import density_moment_majorant
from research.cover.ledger import check_exact_partition
import bernstein as B
import check_v2 as C
import successor_wedge_v2 as W


class EnergyTests(unittest.TestCase):
    def test_energy_error_contains_exact_perturbations(self):
        target=F(3,2); dm=F(1,7);dv=F(1,11)
        for m,v in product((F(-2),F(0),F(3)),(F(1),F(4))):
            margin,_=B.energy_margin(I.exact(m*m-target*v),abs(m),dm,dv,target)
            for em,ev in product((-dm,F(0),dm),(-dv,F(0),dv)):
                self.assertLessEqual(margin,(m+em)**2-target*(v+ev))

    def test_mean_error_cross_term_is_load_bearing(self):
        margin,_=B.energy_margin(I.exact(F(1,10)),F(1),F(1,10),F(0),F(9,10))
        self.assertLess(margin,0)
        self.assertGreater(F(1,10),0)  # erroneous omitted-error certificate
        self.assertLess((F(1)-F(1,10))**2-F(9,10),0)

    def test_variance_error_term_is_load_bearing(self):
        margin,_=B.energy_margin(I.exact(F(1,10)),F(1),F(0),F(1),F(9,10))
        self.assertLess(margin,0)

    def test_bad_energy_inputs_refused(self):
        for args in ((I(0,1),1.,F(0),F(0),F(1)),(I(0,1),F(1),-F(1),F(0),F(1)),
                     (I(0,1),F(1),F(0),F(0),-F(1)),(None,F(1),F(0),F(0),F(1))):
            with self.assertRaises((TypeError,ValueError)):B.energy_margin(*args)

    def test_output_overwrite_and_repo_destination_refused(self):
        from pathlib import Path
        repo=Path(W.side24.__file__).resolve().parents[2]
        with self.assertRaises(ValueError):C.destination(repo/'new_bernstein_output',repo)
        with self.assertRaises(ValueError):C.destination(C.HERE/'new_bernstein_output',repo)
        with self.assertRaises(ValueError):C.destination(C.HERE/'bernstein.py',repo)


class ActualWedgeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.n6,cls.identities=checked_n6()
        cls.report=W.certify_wedge(cls.n6,pieces=1)

    @classmethod
    def tearDownClass(cls):
        _,after=checked_n6()
        if after!=cls.identities:raise ValueError('input identity drift during actual controls')

    def test_one_rectangle_certifies_original_budget(self):
        r=self.report
        self.assertEqual(r['piece_count'],1);self.assertEqual(r['pending_pieces'],0)
        check_exact_partition(W.OUTER_BOX,[x['box'] for x in r['pieces']])
        self.assertGreater(r['determinant_lower'],F(8,10**25))
        self.assertGreaterEqual(r['q_lower'],103)
        cap=density_moment_majorant(r['determinant_lower'],r['q_lower'])['integrand_upper']
        self.assertLess(cap,F(1,100000))
        self.assertGreater(r['pieces'][0]['shared_energy_proof']['margin'],0)
        self.assertFalse(r['full_annulus_certified']);self.assertFalse(r['all_radii_certified'])
        self.assertFalse(r['scientific_status_changed'])

    def test_negative_common_energy_margin_does_not_grant_target(self):
        original_add=W._polyadd
        def mutated(a,b,scale=1,*,bits):
            return {(0,0):I.exact(-1)} if scale==-103 else original_add(a,b,scale,bits=bits)
        with patch.object(W,'_polyadd',mutated):
            r=W.certify_rectangle(self.n6,W.OUTER_BOX)
        self.assertLess(r['q_lower'],103)
        self.assertFalse(r['shared_energy_proof']['target_established'])

    def test_fixed_domain_still_refused(self):
        from research.cover import Box
        b=W.OUTER_BOX
        with self.assertRaises(ValueError):W.certify_rectangle(None,Box(b.u0-F(1,100),b.u1,b.v0,b.v1))


if __name__=='__main__':unittest.main()
