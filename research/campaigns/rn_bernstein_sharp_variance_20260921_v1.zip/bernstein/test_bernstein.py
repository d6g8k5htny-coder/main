import unittest
from fractions import Fraction as F
from itertools import product
from math import comb

from research.interval import Interval as I
import bernstein as B
import source_side24_wedge as original
import successor_wedge as successor


def evaluate_net(net, t, u):
    n, m = len(net)-1, len(net[0])-1
    return sum((net[k][l]*comb(n,k)*t**k*(1-t)**(n-k)*comb(m,l)*u**l*(1-u)**(m-l)
                for k in range(n+1) for l in range(m+1)), I.exact(0))


class BernsteinTests(unittest.TestCase):
    def test_integer_convolution_matches_independent_power_conversion(self):
        for n in range(11):
            weights = B.centered_weights(n)
            for k in range(n+1):
                for a in range(n+1):
                    expected = sum((F(comb(a,j)*2**j*(-1)**(a-j)*comb(k,j), comb(n,j))
                                    for j in range(min(a,k)+1)), F(0))
                    self.assertEqual(weights[k][a], expected)

    def test_exact_polynomial_reconstruction(self):
        p = {(0,0): I.exact(F(7,3)), (3,1): I.exact(-2), (2,2): I.exact(5), (0,3): I.exact(-1)}
        h = F(2,3), F(5,7)
        net, _ = B.control_net(p,h,bits=256)
        for t,u in product((F(0), F(1,5), F(1,2), F(1)),repeat=2):
            x,y = h[0]*(2*t-1),h[1]*(2*u-1)
            expected = sum((v.lo*x**a*y**b for (a,b),v in p.items()), F(0))
            out=evaluate_net(net,t,u)
            self.assertLessEqual(out.lo,expected)
            self.assertGreaterEqual(out.hi,expected)

    def test_constants_zero_axes_and_zero_polynomial(self):
        for p,want in (({},I.exact(0)), ({(0,0):I(2,3)},I(2,3)), ({(0,0):I.exact(-7)},I.exact(-7))):
            self.assertEqual(B.enclosure(p,(F(2),F(3)))[0],want)
        net,_=B.control_net({(0,2):I.exact(1)},(F(2),F(3)))
        self.assertEqual(len(net),1)
        self.assertEqual(net[0],(I.exact(9),I.exact(-9),I.exact(9)))

    def test_degree_elevation_reconstruction(self):
        p={(2,0):I.exact(1),(1,1):I.exact(-2),(0,2):I.exact(1),(0,0):I.exact(2)}
        for degree in ((2,2),(4,5),(9,8)):
            net,_=B.control_net(p,(F(1),F(1)),degrees=degree)
            for t,u in product((F(1,7),F(1,2),F(1)),repeat=2):
                expected=(2*t-2*u)**2+2
                out=evaluate_net(net,t,u)
                self.assertLessEqual(out.lo,expected)
                self.assertGreaterEqual(out.hi,expected)

    def test_interval_coefficients_enclose_all_corner_polynomials(self):
        p={(0,0):I(1,2),(2,0):I(-2,1),(1,1):I(-1,3)}
        h=(F(3,5),F(2,7));bound,_=B.enclosure(p,h)
        for coefficients in product(*((v.lo,v.hi) for v in p.values())):
            for t,u in product((F(0),F(1,3),F(1,2),F(1)),repeat=2):
                x,y=h[0]*(2*t-1),h[1]*(2*u-1)
                value=sum(c*x**a*y**b for c,(a,b) in zip(coefficients,p))
                self.assertLessEqual(bound.lo,value); self.assertGreaterEqual(bound.hi,value)

    def test_endpoint_controls_are_endpoint_values(self):
        p={(0,0):I.exact(1),(2,1):I.exact(3),(0,2):I.exact(-2)}
        net,_=B.control_net(p,(F(2),F(3)))
        for i,j in product((0,1),repeat=2):
            x,y=F(2)*(2*i-1),F(3)*(2*j-1)
            value=1+3*x*x*y-2*y*y
            self.assertEqual(net[(len(net)-1)*i][(len(net[0])-1)*j],I.exact(value))

    def test_correlations_can_prove_positive_when_monomials_do_not(self):
        # p=(x+1)^2+1 on [-1,1]: degree-two controls [1,1,5].
        p={(0,0):I.exact(2),(1,0):I.exact(2),(2,0):I.exact(1)};h=(F(1),F(1))
        old=original._evaluate(p,h,bits=256)
        new=successor._evaluate(p,h,bits=256)
        self.assertEqual(old.lo,0);self.assertEqual(new.lo,1);self.assertEqual(new.hi,5)

    def test_intersection_never_widens(self):
        p={(4,0):I.exact(1),(0,0):I.exact(1)};h=(F(2),F(3))
        old=original._evaluate(p,h,bits=256);new,detail=B.intersect_range(p,h,monomial=old)
        self.assertGreaterEqual(new.lo,old.lo);self.assertLessEqual(new.hi,old.hi)
        self.assertGreaterEqual(new.lo,detail['bernstein'].lo);self.assertLessEqual(new.hi,detail['bernstein'].hi)

    def test_inconsistent_intersection_is_hard_failure(self):
        with self.assertRaises(ArithmeticError):
            B.intersect_range({(0,0):I.exact(2)},(F(1),F(1)),monomial=I(0,1))

    def test_mutant_missing_center_shift_is_detected(self):
        weights=B.centered_weights(1)
        self.assertEqual(weights[0][1],-1)
        self.assertNotEqual(weights[0][1],F(0))  # t^1 mistaken for (2t-1)^1

    def test_mutant_missing_binomial_denominator_is_detected(self):
        self.assertEqual(B.centered_weights(4)[1][1],-F(1,2))
        self.assertNotEqual(B.centered_weights(4)[1][1],-2)

    def test_source_successor_has_only_evaluator_change(self):
        import inspect
        for name in ('_determinant_error','_rectangle','_settings','_determinant_polynomial','_polynomials','certify_rectangle','certify_wedge','containment'):
            self.assertEqual(inspect.getsource(getattr(original,name)),inspect.getsource(getattr(successor,name)))

    def test_malformed_inputs_and_resource_limits(self):
        valid={(0,0):I.exact(1)};h=(F(1),F(1))
        bad=[({'x':I.exact(1)},h,256),({(True,0):I.exact(1)},h,256),({(1.0,0):I.exact(1)},h,256),
             ({(-1,0):I.exact(1)},h,256),({(37,0):I.exact(1)},h,256),({(0,0):1},h,256),
             (valid,(1.0,F(1)),256),(valid,(F(0),F(1)),256),(valid,h,True),(valid,h,63),
             (valid,h,1025),(valid,(F(1,2**8193),F(1)),256)]
        for p,width,bits in bad:
            with self.subTest(p=p,width=width,bits=bits), self.assertRaises((ValueError,TypeError)):
                B.enclosure(p,width,bits=bits)
        for degrees in ((-1,0),(37,1),(True,1),(0,0)):
            with self.subTest(degrees=degrees), self.assertRaises(ValueError):
                B.enclosure({(1,0):I.exact(1)},h,degrees=degrees)


if __name__=='__main__': unittest.main()
