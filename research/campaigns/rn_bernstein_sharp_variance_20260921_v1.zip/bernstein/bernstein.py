"""Exact tensor Bernstein enclosure on a centered rational rectangle.

Uses the repository's outward rational Interval implementation. This proves
polynomial containment only, not applicability or any full RN/q0 theorem.
"""
from fractions import Fraction as F
from math import comb

from research.interval import Interval as I

MAX_DEGREE = 36
MAX_COEFFICIENTS = 1369
MAX_INPUT_BITS = 8192
ZERO = I.exact(0)


def _fraction(x, name, *, positive=False):
    if type(x) is not F:
        raise TypeError(name + ' must be an exact Fraction')
    if max(abs(x.numerator).bit_length(), x.denominator.bit_length()) > MAX_INPUT_BITS:
        raise ValueError(name + ' exceeds input bit budget')
    if positive and x <= 0:
        raise ValueError(name + ' must be positive')


def _validate(coefficients, halfwidths, bits, degrees):
    if type(bits) is not int or not 64 <= bits <= 1024:
        raise ValueError('bits must be an integer in 64..1024')
    if type(coefficients) is not dict or len(coefficients) > MAX_COEFFICIENTS:
        raise ValueError('bounded polynomial dictionary required')
    if type(halfwidths) is not tuple or len(halfwidths) != 2:
        raise ValueError('two exact halfwidths required')
    for x in halfwidths:
        _fraction(x, 'halfwidth', positive=True)
    degree = [0, 0]
    for key, value in coefficients.items():
        if (type(key) is not tuple or len(key) != 2 or
                any(type(x) is not int or not 0 <= x <= MAX_DEGREE for x in key)):
            raise ValueError('bounded exact integer exponent pair required')
        if type(value) is not I:
            raise TypeError('interval coefficients required')
        _fraction(value.lo, 'coefficient lower endpoint')
        _fraction(value.hi, 'coefficient upper endpoint')
        if value != ZERO:
            degree = [max(a, b) for a, b in zip(degree, key)]
    if degrees is not None:
        if (type(degrees) is not tuple or len(degrees) != 2 or
                any(type(n) is not int or n < d or n > MAX_DEGREE
                    for n, d in zip(degrees, degree))):
            raise ValueError('degrees must dominate polynomial degrees within budget')
        degree = list(degrees)
    return tuple(degree)


def centered_weights(n):
    """w[k,a] expands (2t-1)^a in the degree-n Bernstein basis.

    Elevating the degree-a coefficients (-1)^(a-j) gives the exact
    convolution below. Computing signed sums as integers retains cancellation.
    """
    if type(n) is not int or not 0 <= n <= MAX_DEGREE:
        raise ValueError('degree outside bounded integer range')
    return tuple(tuple(F(sum((-1)**(a-j)*comb(a, j)*comb(n-a, k-j)
                            for j in range(max(0, k-(n-a)), min(a, k)+1)), comb(n, k))
                       for a in range(n+1)) for k in range(n+1))


def control_net(coefficients, halfwidths, *, bits=256, degrees=None):
    """Return an outward interval tensor control net and integer work counts."""
    nx, ny = _validate(coefficients, halfwidths, bits, degrees)
    wx, wy = centered_weights(nx), centered_weights(ny)
    hx, hy = halfwidths
    scaled = {(a, b): (value*(hx**a*hy**b)).round_out(bits)
              for (a, b), value in coefficients.items() if value != ZERO}
    stage = [[ZERO for _ in range(ny+1)] for _ in range(nx+1)]
    operations = 0
    for (a, b), value in scaled.items():
        for k in range(nx+1):
            if wx[k][a]:
                stage[k][b] = (stage[k][b]+value*wx[k][a]).round_out(bits)
                operations += 1
    net = []
    for k in range(nx+1):
        row = []
        for l in range(ny+1):
            value = ZERO
            for b in range(ny+1):
                if wy[l][b] and stage[k][b] != ZERO:
                    value = (value+stage[k][b]*wy[l][b]).round_out(bits)
                    operations += 1
            row.append(value)
        net.append(tuple(row))
    return tuple(net), {'degrees': (nx, ny), 'controls': (nx+1)*(ny+1),
                        'interval_accumulations': operations}


def enclosure(coefficients, halfwidths, *, bits=256, degrees=None):
    net, cost = control_net(coefficients, halfwidths, bits=bits, degrees=degrees)
    return I(min(x.lo for row in net for x in row),
             max(x.hi for row in net for x in row)), cost


def intersect_range(coefficients, halfwidths, *, bits=256, monomial):
    """Intersect two valid ranges; inconsistent ranges are a hard error."""
    if type(monomial) is not I:
        raise TypeError('monomial enclosure must be an Interval')
    result, cost = enclosure(coefficients, halfwidths, bits=bits)
    lo, hi = max(monomial.lo, result.lo), min(monomial.hi, result.hi)
    if lo > hi:
        raise ArithmeticError('inconsistent polynomial enclosures')
    return I(lo, hi), {'bernstein': result, 'monomial': monomial, **cost}


def energy_margin(polynomial_range, mean_absolute_upper, mean_error, variance_error, target):
    """Lower bound mu²-target*Var from the range of P_mu²-target*P_var.

    |mu-P_mu|<=mean_error and |Var-P_var|<=variance_error. The discarded
    mean-error square is nonnegative; the linear mean-error term is retained.
    """
    if type(polynomial_range) is not I:
        raise TypeError('polynomial range must be an Interval')
    for name, value in (('mean upper',mean_absolute_upper),('mean error',mean_error),
                        ('variance error',variance_error),('target',target)):
        _fraction(value,name)
        if value < 0:raise ValueError(name+' must be nonnegative')
    error=2*mean_absolute_upper*mean_error+target*variance_error
    return polynomial_range.lo-error,error
