# One-rectangle RN wedge certificate by Bernstein and a coupled energy inequality

This is an author-side mathematical successor for the same normalized SIDE24
law, fixed six pins, fixed `r=1/20`, `b=6/5`, and complete height window as the
original twelve-strip certificate. No scientific status, admission rule or
independence credit changes. It does not prove a full annulus, all radii,
all pin orientations, q0 or event-transfer theorem.

## Exact scope and inherited inputs

The integration region remains
`1/10 <= rho <= 11/100`, `-1/1024 <= turns <= 1/1024`.
The unchanged trigonometric containment argument places it in the single
rectangle `[9999/100000,11/100] x [-7/10000,7/10000]`.
The exact wedge area is `21*pi/5120000`. The Cartesian containing rectangle
is auxiliary; its area is never substituted for the wedge area.

`source_side24_wedge.py` is an exact copy of the repository input SHA-256
`70fa2563564a0601e4ae342e5293e982c13131f25ca6b37ebe28050698216a34`.
The successor keeps its original normalized kernel, six-pin conditioning,
degree-six Taylor polynomials, rational preconditioner, original-coordinate
mean/covariance, L2 remainder bounds and determinant perturbation formula.
The authored N6 module and every original dependency are freshly authenticated
by the existing repository binder, including before warm-cache reuse.
The fixed-radius H3 floor `Z>=0.0077592917375327855` and six-pin energy below8
remain explicit imported premises; this successor does not reprove them.

## 1. Tensor Bernstein containment

For an exact centered coordinate `x=h(2t-1)`, `0<=t<=1`, let
`B(k,n,t)=binom(n,k)t^k(1-t)^(n-k)`. For `0<=a<=n`,

`(2t-1)^a = sum_k w(n,k,a) B(k,n,t)`,

where

`w(n,k,a) = [sum_j (-1)^(a-j) binom(a,j) binom(n-a,k-j)] / binom(n,k)`.

Here `max(0,k-(n-a))<=j<=min(a,k)`. To prove the formula, first expand
`(t-(1-t))^a` in the degree-a Bernstein basis, whose coefficients are
`(-1)^(a-j)`. Multiply by `(t+(1-t))^(n-a)=1` and collect degree-n terms.
The implementation performs the signed numerator convolution as exact integers.

Apply this identity separately in both coordinates to a polynomial
`P(x,y)=sum_ab c_ab x^a y^b`. Its tensor coefficients are

`b_kl = sum_ab c_ab hx^a hy^b w(nx,k,a) w(ny,l,b)`.

If each `c_ab` belongs to an outward rational interval, the two successive
interval linear transforms enclose each actual `b_kl`. Interval arithmetic
and every explicit `round_out` operation preserve containment. Because the
tensor basis functions are nonnegative and sum to1 on the rectangle,
`min_kl lower(b_kl) <= P <= max_kl upper(b_kl)` throughout it. This assertion
requires neither coefficient independence nor a probabilistic sampling rule.

Intersect that range with the original parity-aware monomial range. Both
contain the same exact polynomial values, so the intersection remains valid
and cannot be wider than either one. An empty intersection is a hard
implementation inconsistency, never a mathematical counterexample certificate.
Zero polynomials, constant axes and optional degree elevation are included.
Input degrees and rational sizes are checked before allocation.

## 2. Determinant and covariance errors are retained

The original code forms the full symmetric determinant polynomial before
range evaluation. Bernstein changes only this polynomial range and the
polynomial mean/covariance entry ranges. It leaves the exact preconditioner
and its determinant-square conversion unchanged.

For each transformed coordinate i, let eta_i be the original L2 remainder
bound, and sigma_i the square root of the polynomial covariance diagonal's
upper bound. The retained covariance entry error is

`e_ij = sigma_i eta_j + sigma_j eta_i + eta_i eta_j`.

The determinant error remains the sum over all six permutations of
`product_i(M_i,perm(i)+e_i,perm(i)) - product_i M_i,perm(i)`, retaining all
linear, quadratic and cubic error products. Tighter valid polynomial ranges
can reduce M and sigma, but cannot delete any remainder contribution.

The resulting actual conditional three-jet determinant is strictly positive.
The common normalized Gaussian source law and conditioning make the actual
covariance positive semidefinite. A positive determinant therefore makes it
positive definite at every point. No positive-definiteness claim is made
about the independent-entry interval hull.

## 3. Coupled scalar energy lower bound

Let `P_mu(h)` and `P_v(h)` denote the original-coordinate fx mean and variance
polynomials from the same six-pin law. They are taken from `mean[g][1]` and
`covariance[g][1][1]`, not the transformed covariance. The original N6 argument
provides `|mu-P_mu|<=e_mu`, `|v-P_v|<=e_v`, and a range bounding `|P_mu|<=M`.

For a fixed nonnegative rational Q, form the common polynomial
`R(h)=P_mu(h)^2-Q P_v(h)` before substituting spatial intervals. If its certified
lower bound is L, then

`mu^2-Q v >= L - 2 M e_mu - Q e_v`.

Indeed, writing `mu=P_mu+delta`, `v=P_v+epsilon`, the difference is
`R+2 P_mu delta+delta^2-Q epsilon`. The linear cross term is bounded below by
`-2M e_mu`; **delta^2 is nonnegative and is discarded only from a lower bound**;
the variance error contributes `-Q e_v`. This is why omitting the cross term
would be unsound. The exact candidate uses Q=103 and proves the residual
margin strictly positive on the single whole rectangle.

Actual three-jet positive definiteness implies `v>0`, so this proves
`mu_fx^2/v_fx >=103`. Covariance Cauchy–Schwarz for the same actual law gives
`q=(target-mu)^T G^-1(target-mu) >= mu_fx^2/v_fx`, since the fx observation
target is zero. Thus q>=103 holds for every height, including the entire
source height window. A negative margin does not grant Q: the implementation
retains only the previously valid separate-range quotient in that case.

## 4. Complete unchanged wedge budget

The exact one-rectangle replay establishes `det(G)>8/10^25` and `q>=103`.
Apply the existing source-bound density-weighted determinant majorant with
these original-coordinate determinant/energy bounds and density Jacobian1.
It retains the original H3 normalization, full height-window length and
Hölder moment argument. Its computed upper is strictly below `1/100000`.
The pointwise integrand bound holds on the whole containing rectangle and
hence on the entire wedge. Multiplication by the exact wedge area once gives

`integral_W I(y)dy < (1/100000)*(21*pi/5120000) < 33/256000000000`,

using `pi<22/7`. One auxiliary rectangle has no missing boundary or pending
piece; partition checking and all source identities are verified explicitly.

## Evidence and limits

The original one-rectangle method is a retained determinant refusal.
Bernstein polynomial ranges alone admit that rectangle, but the separate
mean/variance quotient does not meet the existing integrand budget at1,2 or4
strips. The shared-energy polynomial is the substantive additional inequality
that makes one rectangle sufficient. Twelve strips already certified this
wedge; this is a more efficient proof of the same region and budget, not an
enlarged annulus result or an automatic canonical promotion.

Exact certificate bytes and normal/optimized replay are separated from wall
timings. Local wall times include ordering and warm-cache effects and are not
independent performance evidence. Tests exercise independent coefficient
conversion, rational reconstruction, coefficient uncertainty, degree
elevation, errors that break positivity, original domain retention, actual
one-box reproduction and failed-energy fallback. Technical same-provider
review earns zero organizational independence credit.
