"""Reject genuine composition errors between the two scoped certificates."""
import argparse
import copy
import json
from pathlib import Path
import sys
import unittest

import close_local_wedge as close

SPATIAL = SHARP = None


class CompositionTests(unittest.TestCase):
    def setUp(self):
        self.b, self.s = copy.deepcopy(SPATIAL), copy.deepcopy(SHARP)

    def attempt(self):
        return next(a for a in self.b['attempts'] if a['method'] == 'bernstein')

    def refused(self):
        with self.assertRaises(ValueError):
            close.compose(self.b, self.s)

    def test_scoped_composition(self):
        r = close.compose(self.b, self.s)
        self.assertEqual(r['integrand_strict_upper'], '1/1000000')
        self.assertEqual(r['spatial_auxiliary_rectangles'], 1)
        self.assertFalse(r['scope']['q0_closed'])

    def test_unresolved_spatial_cover(self):
        self.attempt()['cover_pending'] = 1
        self.refused()

    def test_source_drift(self):
        self.b['source_and_implementation_unchanged'] = False
        self.refused()

    def test_distinct_field_source(self):
        self.s['source_binding']['h3_floor'] = 'another normalization'
        self.refused()

    def test_weaker_energy(self):
        self.attempt()['report']['q_lower'] = '102'
        self.refused()

    def test_weaker_determinant(self):
        self.attempt()['report']['determinant_lower'] = '1/10000000000000000000000000'
        self.refused()

    def test_different_pin_axis(self):
        self.s['conditional_wedge_application']['fixed_pin_axis'] = 'arbitrary'
        self.refused()

    def test_height_window_narrowing(self):
        self.attempt()['report']['mark_domain'] = ['0', '0']
        self.refused()

    def test_full_annulus_substitution(self):
        self.s['conditional_wedge_application']['radii'] = ['1/10', '5']
        self.refused()

    def test_wrong_area(self):
        self.s['conditional_wedge_application']['area_pi_coefficient'] = '21/10240000'
        self.refused()

    def test_dropped_error_allowance(self):
        self.b['scope']['all_remainders_retained'] = False
        self.refused()

    def test_double_density_jacobian(self):
        self.s['conditional_wedge_application']['density_coordinate_jacobian'] = 2
        self.refused()

    def test_shared_code_disagrees(self):
        self.b['repository_inputs']['files']['research/rn/side24.py']['sha256'] = '0'*64
        self.refused()

    def test_insufficient_imported_energy(self):
        self.attempt()['report']['conditioning_energy_upper'] = '9'
        self.refused()

    def test_positive_integrand_lower_is_not_a_consequence(self):
        self.s['conditional_wedge_application']['bound']['typed_integrand_range'][0] = '1/1000000000'
        self.refused()

    def test_failed_shared_energy_margin(self):
        self.attempt()['report']['pieces'][0]['shared_energy_proof']['margin'] = '-1'
        self.refused()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--spatial', type=Path, required=True)
    parser.add_argument('--sharp', type=Path, required=True)
    args, other = parser.parse_known_args()
    SPATIAL = json.loads(args.spatial.read_bytes())
    SHARP = json.loads(args.sharp.read_bytes())
    unittest.main(argv=[sys.argv[0]]+other)
