"""Focused proof-identity, mutant, source and portable-CLI controls.

Run with Python -B or Python -B -O; unittest assertions remain enabled.
"""
import argparse
import copy
from fractions import Fraction as F
from hashlib import sha256
import importlib.util
import json
from math import comb
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('sharp_variance_checker', HERE / 'check.py')
check = importlib.util.module_from_spec(spec)
spec.loader.exec_module(check)
REPO = None


def sixth(mean, variance):
    return sum(F(comb(6, 2*j)) * mean**(6-2*j) * variance**j * moment
               for j, moment in enumerate((1, 1, 3, 15)))


class SharpVarianceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rows = check.dependency_rows()
        cls.api = check.load_api(REPO, cls.rows)
        cls.report = check.build_report(REPO)

    def test_bernstein_identity_and_controls(self):
        for T in (F(8), F(9), F(99, 8)):
            for lam in (F(0), F(1, 7), F(1, 2), F(1)):
                direct = (15*(1-lam)**3 + 45*T*lam*(1-lam)**2
                          + 15*T*T*lam*lam*(1-lam) + T**3*lam**3)
                controls = (F(15), 15*T, 5*T*T, T**3)
                bernstein = sum(comb(3,j)*controls[j]*lam**j*(1-lam)**(3-j) for j in range(4))
                self.assertEqual(direct, bernstein)
                self.assertLessEqual(bernstein, T**3)

    def test_exact_noncentral_sixth_moment_expansion(self):
        for mean, variance in ((F(0),F(3)),(F(2),F(0)),(F(3,2),F(5,7))):
            self.assertEqual(sixth(mean,variance),mean**6+15*mean**4*variance+
                             45*mean**2*variance**2+15*variance**3)

    def test_uncoupled_maxima_are_a_real_counterexample(self):
        # Actual allowed deterministic conditional endpoint: s=a=4,T=9,mu=6.
        self.assertEqual(sixth(F(6),F(0)), F(4)**3*F(9)**3)
        # Illegally retaining all residual variance with that same maximal mean fails.
        self.assertGreater(sixth(F(6),F(4)), F(4)**3*F(9)**3)
        self.assertEqual(sixth(F(0),F(0)),0)

    def test_energy_threshold_cannot_be_dropped(self):
        self.assertGreater(sixth(F(0),F(1)),1**3)

    def test_determinant_bound_retains_absolute_value_and_mixed_weight(self):
        for a,b,c in ((F(-2),F(3),F(4)),(F(5),F(5),F(0)),(F(0),F(0),F(3))):
            self.assertLessEqual(abs(a*b-c*c),(a*a+b*b)/2+c*c)
        self.assertGreater(abs(F(0)*0-3*3),F(3*3,2))  # Half-weight xy mutant.
        self.assertLess(F(0)*0-3*3,0)                 # Dropped-absolute-value mutant.

    def test_stationary_coefficient_uses_separate_variances(self):
        pure,mixed=F(3),F(1)
        self.assertEqual((pure/2+pure/2+mixed)**3,64)
        self.assertEqual((F(4)/2+F(4)/2+F(4))**3,512)
        self.assertNotEqual((pure/2+pure/2+mixed/2)**3,64)

    def test_normalized_torus_caps_and_exact_expression(self):
        caps=check.stationary_caps(self.api[1])
        self.assertGreater(caps['m2'].lo,0)
        self.assertLessEqual(caps['m2'].hi,1)
        self.assertLess(caps['m4'].hi,F(3000000001,1000000000))
        self.assertEqual(caps['mixed_variance'],caps['m2']**2)
        self.assertEqual(caps['exact_factor_interval'],(caps['m4']+caps['m2']**2)**3)
        self.assertLess(caps['exact_factor_interval'].hi,check.SHARP_FACTOR)
        self.assertLess(check.SHARP_FACTOR,65)

    def test_exactly_64_is_not_certified(self):
        with self.assertRaisesRegex(ValueError,'strictly above'):
            check.stationary_caps(self.api[1],F(64))

    def test_loose_printed_moment_caps_do_not_imply_tight_factor(self):
        self.assertGreater((F(3000001,1000000)+1)**3,check.SHARP_FACTOR)
        self.assertLess((F(3000000001,1000000000)+1)**3,check.SHARP_FACTOR)

    def test_majorant_arithmetic_matches_rearranged_formula(self):
        iv=self.api[3]
        result=check.majorant(self.api,F(1,16),F(3),jacobian=2)
        oracle=(F(2)*check.ELL*check.SHARP_FACTOR*11**3/check.Z_LO
                *iv.exp(iv.Interval.exact(F(-3,2)),130)
                /(2*iv.pi(130)*iv.sqrt(2*iv.pi(130)*F(1,16),130)))
        self.assertLessEqual(result['majorant_interval'].lo,oracle.lo)
        self.assertGreaterEqual(result['majorant_interval'].hi,oracle.hi)

    def test_large_energy_cap_weakens_whole_expression(self):
        low=check.majorant(self.api,1,2048)
        high=check.majorant(self.api,1,10**100)
        self.assertEqual(low,high)
        self.assertGreater(high['integrand_upper'],0)

    def test_jacobian_once_and_inverse_square_root_scaling(self):
        base=check.majorant(self.api,1,0)['majorant_interval']
        twice=check.majorant(self.api,1,0,jacobian=2)['majorant_interval']
        quarter=check.majorant(self.api,F(1,4),0)['majorant_interval']
        for interval in (twice,quarter):
            self.assertLessEqual(interval.lo,2*base.hi)
            self.assertGreaterEqual(interval.hi,2*base.lo)
        self.assertGreater(twice.lo,base.hi)

    def test_invalid_inputs_fail_closed(self):
        cases=((0,0,{}),(-1,0,{}),(1,-1,{}),(True,0,{}),(1,0.0,{}),
               (1,0,{'jacobian':0}),(1,0,{'jacobian':True}),
               (1,0,{'coefficient':64}),(1,0,{'coefficient':True}),
               (F(1,2**4097),0,{}))
        for D,Q,kwargs in cases:
            with self.subTest(D=str(D)[:24],Q=Q,kwargs=kwargs):
                with self.assertRaises((ValueError,TypeError)):
                    check.majorant(self.api,D,Q,**kwargs)

    def test_changed_imported_window_floor_energy_are_refused(self):
        dm=self.api[2]
        for attr,value in (('WINDOW_LENGTH',2*check.ELL),('Z_LO',1),('PIN_ENERGY_UPPER',8)):
            with self.subTest(attr=attr),patch.object(dm,attr,value):
                with self.assertRaisesRegex(ValueError,'contract changed'):
                    check.majorant(self.api,1,0)

    def test_conditional_wedge_cap_and_exact_area_factor(self):
        app=self.report['conditional_wedge_application']
        self.assertEqual(F(app['area_pi_coefficient']),F(21,5120000))
        self.assertEqual(F(app['window_length']),F(1,48000))
        self.assertLess(F(app['bound']['integrand_upper']),F(13,10240000))
        self.assertLess(F(app['integral_interval'][1]),F(429,26214400000000))
        self.assertLess(F(app['bound']['integrand_upper']),F(1,1000000))
        self.assertLess(F(app['integral_interval'][1]),F(33,2560000000000))
        self.assertEqual(F(app['integral_interval'][0]),0)

    def test_no_positive_integrand_lower_or_unearned_coverage(self):
        app=self.report['conditional_wedge_application']
        self.assertGreater(F(app['bound']['majorant_interval'][0]),0)
        self.assertEqual(F(app['bound']['typed_integrand_range'][0]),0)
        self.assertFalse(app['coverage_certified_here'])
        self.assertTrue(app['pending_cells_not_evaluated'])
        for key in ('scientific_status_changed','original_prize_closed',
                    'external_spatial_premises_checked','full_annulus_certified',
                    'all_radii_certified','all_pin_orientations_certified','q0_closed'):
            self.assertIs(self.report['scope'][key],False)

    def test_repository_source_hash_mutant_is_refused_before_import(self):
        rows=copy.deepcopy(self.rows)
        rows[0]['sha256']='0'*64
        with self.assertRaisesRegex(ValueError,'hash mismatch'):
            check.load_api(REPO,rows)

    def test_source_drift_during_calculation_is_refused(self):
        original=self.api[2].source_binding
        calls=0
        def changed(*args):
            nonlocal calls
            result=original(*args)
            calls+=1
            if calls==2: result['drift_control']='changed'
            return result
        with patch.object(self.api[2],'source_binding',changed):
            with self.assertRaisesRegex(ValueError,'changed during'):
                check.build_report(REPO)

    def test_json_duplicate_keys_and_source_manifest_paths_refused(self):
        with tempfile.TemporaryDirectory() as t:
            path=Path(t)/'data.json'
            path.write_text('{"x":1,"x":2}')
            with self.assertRaisesRegex(ValueError,'duplicate'):
                check.read_json(path)
            for bad in ('../escape','/absolute','a//b','a/./b','a\\b'):
                rows=copy.deepcopy(self.rows)
                rows[0]['path']=bad
                path.write_bytes(check.canonical(dict(schema='sharp-variance-repository-dependencies-v1',files=rows)))
                with self.assertRaisesRegex(ValueError,'unsafe'):
                    check.dependency_rows(path)

    def run_cli(self,*args):
        return subprocess.run([sys.executable,'-B']+(['-O'] if sys.flags.optimize else [])+
            [str(HERE/'check.py'),'--repo',str(REPO),*map(str,args)],
            capture_output=True,text=True,timeout=45)

    def test_cli_fresh_exact_replay(self):
        with tempfile.TemporaryDirectory() as t:
            original=Path(t)/'expected.json'; output=Path(t)/'fresh.json'
            original.write_bytes(check.canonical(self.report))
            result=self.run_cli('--verify',original,'--output',output)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            self.assertEqual(original.read_bytes(),output.read_bytes())

    def test_cli_existing_output_is_preserved(self):
        with tempfile.TemporaryDirectory() as t:
            output=Path(t)/'existing.json'; output.write_bytes(b'original')
            result=self.run_cli('--output',output)
            self.assertNotEqual(result.returncode,0)
            self.assertEqual(output.read_bytes(),b'original')

    def test_cli_repo_output_is_refused(self):
        result=self.run_cli('--output',REPO/'SHARP_VARIANCE_UNAUTHORIZED_OUTPUT.json')
        self.assertNotEqual(result.returncode,0)
        self.assertIn('outside the repository',result.stdout)
        self.assertFalse((REPO/'SHARP_VARIANCE_UNAUTHORIZED_OUTPUT.json').exists())

    def test_cli_symlink_output_leaf_is_preserved(self):
        with tempfile.TemporaryDirectory() as t:
            target=Path(t)/'target'; target.write_bytes(b'original')
            output=Path(t)/'link'; output.symlink_to(target)
            result=self.run_cli('--output',output)
            self.assertNotEqual(result.returncode,0)
            self.assertEqual(target.read_bytes(),b'original')
            self.assertTrue(output.is_symlink())

    def test_cli_planar_equality_mutant_is_refused(self):
        with tempfile.TemporaryDirectory() as t:
            mutant=copy.deepcopy(self.report)
            mutant['moments']['m4']=['3','3']
            mutant['coefficient']='64'
            source=Path(t)/'mutant.json'; output=Path(t)/'new.json'
            source.write_bytes(check.canonical(mutant))
            result=self.run_cli('--verify',source,'--output',output)
            self.assertNotEqual(result.returncode,0)
            self.assertIn('differs from exact replay',result.stdout)
            self.assertFalse(output.exists())

    def test_cli_full_annulus_promotion_mutant_is_refused(self):
        with tempfile.TemporaryDirectory() as t:
            mutant=copy.deepcopy(self.report)
            mutant['scope']['full_annulus_certified']=True
            source=Path(t)/'mutant.json'; output=Path(t)/'new.json'
            source.write_bytes(check.canonical(mutant))
            result=self.run_cli('--verify',source,'--output',output)
            self.assertNotEqual(result.returncode,0)
            self.assertFalse(output.exists())


if __name__=='__main__':
    p=argparse.ArgumentParser(add_help=False)
    p.add_argument('--repo',type=Path,required=True)
    args,rest=p.parse_known_args()
    REPO=args.repo.resolve(strict=True)
    unittest.main(argv=[sys.argv[0],*rest],verbosity=2)
