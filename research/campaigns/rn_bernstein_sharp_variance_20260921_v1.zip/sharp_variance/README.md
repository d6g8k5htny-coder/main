# Sharp stationary-variance RN majorant

The proved determinant-product coefficient is **64000001/1000000<65**, improving
the original512 while preserving its regression-energy and field-law assumptions.
The exact normalized torus moments include image tails and the full denominator.

For the already supplied wedge premises det(Sigma)>=8/10^25 and q>=103,
the new conditional bound is I(y)<1/1000000 and the corresponding wedge
integral is <33/2560000000000. The sharper exact rational endpoints are in
`result-v2.json`. This calculation does not replay the spatial premises or create
additional coverage. Its H3 floor and six-pin energy remain imported proofs.

Replay from any directory with Python3.11 and the exact pinned repository:

```sh
python -B check.py --repo /path/to/research-main --verify result-v2.json --output /fresh/output.json
python -B -O check.py --repo /path/to/research-main --verify result-v2.json --output /fresh/output-O.json
python -B test_sharp_variance.py --repo /path/to/research-main
python -B -O test_sharp_variance.py --repo /path/to/research-main
```

`DEPENDENCIES.json` pins every imported repository module and original source
dependency before imports and after calculation. Source eligibility and exact
historical member custody are checked twice; no archived program is executed.
`PROOF.md` gives the analytic statement and remaining assumptions. The manifest
allowlist excludes draft runs and temporary test data. Author review remains
same-provider with zero organizational-independence credit; no scientific status
or original prize status changes.
