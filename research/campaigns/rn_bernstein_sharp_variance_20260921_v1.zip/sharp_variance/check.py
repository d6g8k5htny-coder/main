#!/usr/bin/env python3
"""Exact sharp-variance RN majorant; supplied spatial premises stay conditional.

Source code and source data are pinned before repository imports and after the
calculation. No archived program is executed. See PROOF.md for the theorem.
"""
import argparse
from fractions import Fraction as F
from hashlib import sha256
import importlib
import json
from pathlib import Path
import re
import stat
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
SOURCE_SHA = '96e680e47b6484e1e77784218b021559e200326d8043618376470255c5ad1445'
SHARP_FACTOR = F(64000001, 1000000)
COARSE_FACTOR = F(65)
EXPECTED_ENERGY = F(1266466, 160083)
Z_LO = F(15518583475065571, 2000000000000000000)
ELL = F(1, 48000)
WEDGE_D, WEDGE_Q = F(8, 10**25), F(103)
WEDGE_AREA_PI = F(21, 5120000)
INPUT_BITS, MAX_FILE = 4096, 16 * 1024 * 1024


def canonical(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True) + '\n').encode()


def _object(pairs):
    out = {}
    for key, value in pairs:
        if key in out:
            raise ValueError('duplicate JSON key')
        out[key] = value
    return out


def read_json(path):
    path = Path(path)
    if path.is_symlink() or not path.is_file() or path.stat().st_size > MAX_FILE:
        raise ValueError('JSON source must be a bounded regular file')
    return json.loads(path.read_bytes(), object_pairs_hook=_object,
                      parse_constant=lambda x: (_ for _ in ()).throw(ValueError('nonfinite JSON')))


def dependency_rows(path=HERE / 'DEPENDENCIES.json'):
    record = read_json(path)
    if set(record) != {'schema', 'files'} or record['schema'] != 'sharp-variance-repository-dependencies-v1':
        raise ValueError('dependency schema mismatch')
    rows = record['files']
    if not isinstance(rows, list) or not rows or len(rows) > 128:
        raise ValueError('dependency count invalid')
    seen = set()
    for row in rows:
        if not isinstance(row, dict) or set(row) != {'path', 'bytes', 'sha256'}:
            raise ValueError('dependency row schema mismatch')
        p = row['path']
        if (not isinstance(p, str) or not p or Path(p).is_absolute() or '\\' in p or
                any(part in ('', '.', '..') for part in p.split('/')) or p in seen):
            raise ValueError('unsafe or duplicate dependency path')
        seen.add(p)
        if (type(row['bytes']) is not int or not 0 <= row['bytes'] <= MAX_FILE or
                not isinstance(row['sha256'], str) or not re.fullmatch('[0-9a-f]{64}', row['sha256'])):
            raise ValueError('dependency identity invalid')
    source = [x for x in rows if x['path'] == 'research/rn/density_majorant.py']
    if len(source) != 1 or source[0]['sha256'] != SOURCE_SHA:
        raise ValueError('original majorant source pin absent or changed')
    return rows


def check_dependencies(root, rows):
    root = Path(root).resolve(strict=True)
    if not root.is_dir():
        raise ValueError('repository root is not a directory')
    for row in rows:
        p = root / row['path']
        if p.resolve() != p or not stat.S_ISREG(p.lstat().st_mode):
            raise ValueError('dependency symlink/nonregular file: ' + row['path'])
        if p.stat().st_size != row['bytes']:
            raise ValueError('dependency size mismatch: ' + row['path'])
        with p.open('rb') as stream:
            raw = stream.read(row['bytes'] + 1)
        if len(raw) != row['bytes'] or sha256(raw).hexdigest() != row['sha256']:
            raise ValueError('dependency hash mismatch: ' + row['path'])
    return root


def load_api(root, rows):
    root = check_dependencies(root, rows)
    for name, module in list(sys.modules.items()):
        if name == 'research' or name.startswith(('research.', 'engine.', 'tools.')):
            filename = getattr(module, '__file__', None)
            if filename and not Path(filename).resolve().is_relative_to(root):
                raise ValueError('repository modules already loaded from a different checkout')
    sys.path.insert(0, str(root))
    side24 = importlib.import_module('research.rn.side24')
    dm = importlib.import_module('research.rn.density_majorant')
    interval = importlib.import_module('research.interval')
    pin_paths = {row['path'] for row in rows}
    for module in list(sys.modules.values()):
        filename = getattr(module, '__file__', None)
        if filename:
            p = Path(filename).resolve()
            if p.is_relative_to(root) and str(p.relative_to(root)) not in pin_paths:
                raise ValueError('unlisted imported repository module: ' + str(p.relative_to(root)))
    check_dependencies(root, rows)
    return root, side24, dm, interval


def exact(value, name):
    if type(value) not in (int, F):
        raise TypeError(name + ': exact int/Fraction required')
    value = F(value)
    if max(abs(value.numerator).bit_length(), value.denominator.bit_length()) > INPUT_BITS:
        raise ValueError(name + ': rational resource limit')
    return value


def stationary_caps(side24, coefficient=SHARP_FACTOR):
    """Normalized torus moments, including the nonzero images and tail."""
    coefficient = exact(coefficient, 'coefficient')
    m2 = -side24.kernel_derivative(2, F(0), prec=110, bits=256)
    m4 = side24.kernel_derivative(4, F(0), prec=110, bits=256)
    normalizer = side24.normalizer(prec=110, bits=256)
    if not (normalizer.lo > 0 and 0 < m2.lo <= m2.hi <= 1 and 0 < m4.lo):
        raise ValueError('normalized stationary moment positivity/cap failed')
    mixed = m2 ** 2
    factor_interval = (m4 + mixed) ** 3
    if factor_interval.hi >= coefficient:
        raise ValueError('declared coefficient is not strictly above the proved stationary cap')
    return dict(m2=m2, m4=m4, mixed_variance=mixed, normalizer=normalizer,
                exact_factor_interval=factor_interval, coefficient=coefficient)


def majorant(api, D, Q, *, coefficient=SHARP_FACTOR, jacobian=1):
    """Given common-law det>=D>0 and full-mark q>=Q>=0, enclose an upper bound."""
    _, _, dm, iv = api
    D, Q = exact(D, 'determinant'), exact(Q, 'energy')
    C, J = exact(coefficient, 'coefficient'), exact(jacobian, 'jacobian')
    if D <= 0 or Q < 0 or C < SHARP_FACTOR or J <= 0:
        raise ValueError('invalid determinant/energy/coefficient/Jacobian premise')
    if dm.Z_LO != Z_LO or dm.WINDOW_LENGTH != ELL or dm.PIN_ENERGY_UPPER != EXPECTED_ENERGY:
        raise ValueError('imported floor/window/energy contract changed')
    q = min(Q, F(2048))  # Lowering Q weakens the decreasing whole expression.
    I = iv.Interval
    decay = iv.exp(I.exact(-q / 2), 110).round_out(256)
    denominator = iv.sqrt((2 * iv.pi(110)) ** 3 * I.exact(D), 110).round_out(256)
    if denominator.lo <= 0:
        raise ValueError('density denominator positivity unresolved')
    result = (I.exact(J * ELL * C * (8 + q) ** 3 / Z_LO) * decay / denominator).round_out(256)
    if result.lo < 0 or result.hi <= 0:
        raise ValueError('positive finite majorant not established')
    return dict(majorant_interval=result, integrand_upper=result.hi,
                typed_integrand_range=I(0, result.hi), q_used=q)


def encode(value):
    if isinstance(value, F):
        return str(value)
    if hasattr(value, 'lo') and hasattr(value, 'hi'):
        return [str(value.lo), str(value.hi)]
    if isinstance(value, dict):
        return {k: encode(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [encode(v) for v in value]
    return value


def build_report(repo):
    rows = dependency_rows()
    own_paths = [HERE / name for name in ('check.py', 'DEPENDENCIES.json', 'PROOF.md')]
    own_before = [{'path': p.name, 'bytes': p.stat().st_size,
                   'sha256': sha256(p.read_bytes()).hexdigest()} for p in own_paths]
    api = load_api(repo, rows)
    root, side24, dm, iv = api
    binding = dm.source_binding(root)
    if binding['source_programs_executed'] or not binding['current_eligibility_checked']:
        raise ValueError('source binding does not meet the stated contract')
    caps = stationary_caps(side24)
    result = majorant(api, WEDGE_D, WEDGE_Q)
    coarse = majorant(api, WEDGE_D, WEDGE_Q, coefficient=COARSE_FACTOR)
    area = WEDGE_AREA_PI * iv.pi(110).round_out(256)
    integral = area * result['typed_integrand_range']
    coarse_integrand = F(13, 10240000)
    coarse_integral = F(429, 26214400000000)
    simple_integrand = F(1, 1000000)
    simple_integral = F(33, 2560000000000)
    if coarse['integrand_upper'] >= coarse_integrand or integral.hi >= coarse_integral:
        raise ValueError('conditional simple wedge caps not reached')
    if (result['integrand_upper'] >= simple_integrand or integral.hi >= simple_integral or
            simple_integral != simple_integrand * WEDGE_AREA_PI * F(22, 7)):
        raise ValueError('sharper conditional wedge headlines not proved')
    if dm.source_binding(root) != binding:
        raise ValueError('source identities changed during calculation')
    check_dependencies(root, rows)
    own_after = [{'path': p.name, 'bytes': p.stat().st_size,
                  'sha256': sha256(p.read_bytes()).hexdigest()} for p in own_paths]
    if own_before != own_after:
        raise ValueError('local proof/code/dependency identities changed during calculation')
    return encode(dict(
        schema='RN_SHARP_STATIONARY_VARIANCE_MAJORANT_V1',
        target='Q0-RN-SHARP-VARIANCE-MAJORANT-20260921-v1',
        original_majorant_source_sha256=SOURCE_SHA,
        coefficient=SHARP_FACTOR, simple_coefficient=COARSE_FACTOR,
        original_coefficient=F(512), improvement_ratio=F(512)/SHARP_FACTOR,
        moments=caps,
        theorem='product determinant absolute moment <= (m4+m2^2)^3*(8+q)^3 < (64000001/1000000)*(8+q)^3',
        imported=dict(pin_energy_upper=EXPECTED_ENERGY, h3_floor=Z_LO,
                      h3_floor_reproved=False, pin_energy_reproved=False),
        conditional_wedge_application=dict(
            spatial_premises='ASSUMED_EXISTING_SCOPE; NOT_SPATIALLY_REPLAYED_HERE',
            determinant_lower=WEDGE_D, mahalanobis_lower=WEDGE_Q,
            fixed_r='1/20', fixed_b='6/5', fixed_pin_axis='x',
            full_height_window=['57599/48000', '6/5'], window_length=ELL,
            radii=['1/10', '11/100'], signed_turns=['-1/1024', '1/1024'],
            area_pi_coefficient=WEDGE_AREA_PI, area_interval=area,
            density_coordinate_jacobian=1, bound=result,
            coefficient65_bound=coarse, integral_interval=integral,
            conservative_integrand_strict_upper=coarse_integrand,
            conservative_integral_strict_upper=coarse_integral,
            integrand_strict_upper=simple_integrand, integral_strict_upper=simple_integral,
            coverage_certified_here=False, pending_cells_not_evaluated=True),
        source_binding=binding, repository_dependencies=rows, local_inputs=own_before,
        inputs_unchanged=True,
        scope=dict(authority='NONE', organizational_independence_credit=0,
                   scientific_status_changed=False, original_prize_closed=False,
                   external_spatial_premises_checked=False, spatial_cover=False,
                   full_annulus_certified=False, all_radii_certified=False,
                   all_pin_orientations_certified=False, q0_closed=False,
                   event_identification_established=False),
        not_established=[
            'validity of the supplied D,Q over the wedge; existing spatial certificate is an explicit premise',
            'new spatial coverage, full annulus, all radii or all pin orientations',
            'RN uniform closure, q0, weighted-Palm or event identification',
            'reproof or canonical promotion of imported H3 floor or pin-energy result',
            'organizational independence or automatic status change']
    ))


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--verify', type=Path)
    args = p.parse_args(argv)
    try:
        # Resolve parent aliases (notably macOS /var -> /private/var) before
        # applying the repository boundary. Never resolve an existing leaf:
        # it must remain an exclusive-create target, including symlink leaves.
        requested = args.output.absolute()
        if requested.exists() or requested.is_symlink():
            raise ValueError('output must be fresh and outside the repository')
        output = requested.parent.resolve(strict=True) / requested.name
        repo = args.repo.resolve(strict=True)
        if output.exists() or output.is_symlink() or output.resolve().is_relative_to(repo):
            raise ValueError('output must be fresh and outside the repository')
        if not output.parent.is_dir():
            raise ValueError('output requires an existing nonsymlink parent directory')
        report = build_report(repo)
        raw = canonical(report)
        if args.verify is not None and canonical(read_json(args.verify)) != raw:
            raise ValueError('report differs from exact replay')
        with output.open('xb') as stream:
            stream.write(raw)
        print('sharp variance: coefficient <64.000001<65; conditional wedge bounds PASS; spatial premises NOT replayed; no status change')
        return 0
    except Exception as e:
        print('sharp variance: REJECTED: ' + str(e))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
