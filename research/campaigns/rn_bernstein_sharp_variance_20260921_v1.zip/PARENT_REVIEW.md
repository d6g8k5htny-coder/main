# Technical review, 21 September 2026

The parent read both proofs and implementations and the original wedge and
density-majorant sources. The generalized moment proof retains the coupling
`conditional variance=s-a`, `conditional mean²<=a(8+q)`. Its cubic Bernstein
controls imply the sixth-moment bound. Minkowski and Hölder then give the
coefficient `(m4+m2²)^3` without any inter-site independence assumption.
The exact torus moment expression was compared directly with64.000001;
coefficient64 and the planar substitution were refused. Multiplication by
the density occurs before use of the decreasing energy envelope.

The tensor Bernstein transform follows exact degree elevation. A separate
read-only agent reported17,575 exact conversion identities covering every
degree through36 and405 signed mean/variance perturbation inequalities.
Its reviewed SHA-256 identities match this delivery:

- bernstein.py: `16d40be878f743fcb6726befcf3bfa60042f893aac28b08323c908cad467947f`
- successor_wedge_v2.py: `3d02b0b3bb7893f605d8a774b24d94398fd45cfdea47da8d08bc10e4f6a884e0`
- check_v2.py: `36407821c633c5be1c7ae10aafb6220f107aa6e7015ffad86f63c8cb3f9a31e2`
- PROOF.md: `996a1f5314d0f8b9bf7bb6915d742cf1c1610062a66d6c584f05f0f33630a364`

The coupled energy lower bound correctly subtracts `2 M e_mu + Q e_v` and
discards only a nonnegative error square. Positive actual determinant together
with actual covariance PSD supplies positive variance for the quotient; no
SPD statement is inferred for an independent-entry interval hull. The
determinant coordinate restoration, original fx coordinates, full height
window, covariance errors and polar area are unchanged.

The combined runner supplies the sharper majorant's assumed D/Q values from
the one-box spatial proof. It checks exact shared source identities and refuses
domain, mark, normalization, Jacobian, code, remainder, energy and area
mismatches. It does not turn the positive lower endpoint of a majorant into
a positive integrand lower bound. The12-to1 gain is in auxiliary rectangles;
the region is unchanged and no12-fold runtime claim follows.

Parent fresh normal/optimized replays matched each other and the two authors'
final results byte for byte. Parent also reran all62 targeted tests per mode.
No blocking defect was found at this scope. These are technical checks by
the same provider, with zero organizational independence credit. This is not
a formal proof-assistant verification or canonical scientific acceptance.
