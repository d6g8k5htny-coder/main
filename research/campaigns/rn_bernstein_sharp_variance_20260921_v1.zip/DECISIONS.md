# Research solver improvements — 21 September 2026

The user's two images identify the task **Abandonment Criteria Analysis**.
The task was read directly, including its completed 21 September H3 delivery;
the images alone show an in-progress response, not the completed result.
The current Drive Work Events, compact Start Here view and scoped rollout
correction were also read. This assessment does not claim to audit all Drive
objects or every past conversation.

## Reuse the work that now exists

[Draft PR5](https://github.com/d6g8k5htny-coder/main/pull/5), at commit
`2371f660d90963e558a0d08921c634a36b3be016`, contains an H3 search-and-certify
pilot. Its author reports the whole-band fixed-axis lower candidate
`Z(r) >= (1747/1000) r²`, for `0<r<=1/20`, with the original normalized SIDE24
six-pin law. The exact proof and scalar-certificate implementation were read
in this task. This read is not a complete independent re-verification or a
scientific acceptance decision. The stronger fixed-radius RN floor is retained.

That pilot already implements a local content-addressed cache, cold replay,
declared formula dependency hashes, measured execution costs and adversarial
controls. Its 57-test evidence is the other author's delivery, not a new test
run credited to this task. Its formulas do not consume Sheets cells. General
spreadsheet lineage, a full-Z counterexample evaluator and a second rigorous
arithmetic backend remain separate work.

The repository writer subsequently reproduced the H3 candidate and reported
an admission-order gap: `h3_solver.py` reads every manifest leaf before the
static context check, without a current exclusion/admissibility gate. The
relevant source at the pinned PR5 head was also read here. Its author has been
asked to repair this in PR5 before production reuse, with refusal tests before
disallowed reads and the same checks on cache paths. No live cache integration
is justified merely by the successful scalar certificate.

The repository writer is separately delivering a twelve-strip proof for one
finite-width RN inner wedge, using a density-weighted determinant majorant.
Our successors preserve that original delivery and operate in scratch under
two distinct live claims. They target actual numerical losses in its proof.

## Disposition of the six suggestions

| Suggestion | Decision |
| --- | --- |
| Bitemporal Merkle claims | Reuse exact source identities and the new formula dependency graph. Defer a global claim migration. Merkle inclusion authenticates recorded dependencies, not mathematical implication; time fields should describe assertions and recording events, not when a timeless theorem became true. |
| Prover/falsifier lanes | Keep bounded search followed by a proved enclosure, exact scope matching and adversarial controls. An enclosure crossing a threshold is inconclusive. A bound on a sufficient lower-bound formula is not a full enclosure of Z. Failed sampling never certifies a universal claim or earns automatic acceptance. |
| Content-addressed cache | Reuse PR5's scoped local cache and cold replay. Extend only when measured repeated computation justifies it. A key needs all numerical, source, code, context and runtime dependencies; current source admissibility must still be checked. A cache remains an optimization. |
| Shadow arithmetic | Retain diagnostic/certifying distinctions. Overlap is a consistency check, not proof of either implementation. Disjoint certified enclosures of the same exact quantity signal an inconsistency. A future Arb implementation should reproduce the law and all truncation bounds, not merely wrap a floating result in an interval. |
| Formula-cell lineage | Trace actual consumed inputs. No Sheets cells feed the inspected H3/RN calculations. A general tracer must resolve cross-sheet/named/external/dynamic dependencies and fail explicitly when unsupported; hashing formula text alone is insufficient. The quoted workbook/formula counts were not newly verified here. |
| Proof market / energy | Use the existing dependency ranking and measured experiment costs. Compare work saved or stronger bounds at fixed scope. CPU/wall time is not energy; do not invent forecasts, prices or automatic budgets. |

The numerical distinction is supported by the libraries' own contracts:
[mpmath contexts](https://mpmath.org/doc/current/contexts.html) distinguish
ordinary multiprecision arithmetic from experimental interval support;
[python-flint Arb](https://python-flint.readthedocs.io/en/latest/arb.html)
represents a real value by a midpoint and a containing radius. Neither backend
by itself supplies the application's analytic tail, conditioning or domain proof.

## The two new experiments

**Sharp stationary variances.** The current density majorant bounds every
Hessian coordinate variance by4, producing a three-determinant factor512.
Retain the actual normalized moments instead:
`Var(fxx)=Var(fyy)=m4`, `Var(fxy)=m2²`. The same coupled Gaussian regression
argument yields a factor `(m4+m2²)^3`, close to64. The successor must certify
the nonzero torus-image corrections, preserve the density Jacobian and full
mark window, and state its imported determinant/energy/H3 premises explicitly.

**Bernstein polynomial bounds.** The current wedge proof already forms its
covariance determinant polynomial before spatial evaluation. A tensor-product
Bernstein enclosure can retain more spatial dependence than independent
monomial bounds. The successor intersects two proved ranges and preserves
every existing covariance/Taylor determinant remainder. Benchmarks use the
same law and bounded domain; retained refusals remain inconclusive, never false
claims. The implementation is adopted only at the scope actually checked.

Both experiments produce proofs, exact certificates, normal/optimized tests,
source identities and measured comparisons. No new global scheduler, installed
authority service, additional governing register or scientific status change
is introduced. They follow the currently authorized research workflow and the
[scoped rollout correction](https://drive.google.com/file/d/1cKPOpv1foB7F7aBA-N0O8vtzetPWKjyR/view).

The full RN annulus, all-separation and all-pin-orientation bounds, weighted
event interfaces and q0 theorem remain open. Tighter local arithmetic is useful
only as a contribution to those existing mathematical obligations.
