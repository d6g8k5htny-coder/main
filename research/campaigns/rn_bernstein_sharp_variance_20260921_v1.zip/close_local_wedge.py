#!/usr/bin/env python3
"""Freshly replay and compose the two scoped RN successors; never alter status."""
import argparse
from fractions import Fraction as F
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
BOX = {'u0': '9999/100000', 'u1': '11/100', 'v0': '-7/10000', 'v1': '7/10000'}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def canonical(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()


def compose(bernstein, sharp):
    """Compose freshly produced reports, not arbitrary unverified input files."""
    require(bernstein['schema'] == 'RN_BIVARIATE_BERNSTEIN_ENERGY_SUCCESSOR_V2', 'wrong spatial schema')
    require(sharp['schema'] == 'RN_SHARP_STATIONARY_VARIANCE_MAJORANT_V1', 'wrong majorant schema')
    require(bernstein['source_and_implementation_unchanged'] is True and sharp['inputs_unchanged'] is True,
            'source drift or incomplete run')
    require(bernstein['scope']['all_remainders_retained'] is True, 'missing remainder contract')
    attempts = [a for a in bernstein['attempts'] if a['method'] == 'bernstein' and a['pieces'] == 1]
    require(len(attempts) == 1, 'exactly one whole-box result required')
    a = attempts[0]
    require(a['outcome'] == 'CERTIFIED_SCOPED_BOUND' and a['cover_pending'] == 0, 'spatial result unresolved')
    spatial, old = a['report'], a['majorant']
    app = sharp['conditional_wedge_application']
    require(spatial['pending_pieces'] == 0 and spatial['piece_count'] == 1 and len(spatial['pieces']) == 1,
            'incomplete or changed spatial partition')
    geometry = spatial['geometry']
    require(geometry['containing_rectangle'] == BOX and spatial['pieces'][0]['box'] == BOX,
            'containing rectangle mismatch')
    require(geometry['radii'] == app['radii'] == ['1/10', '11/100'], 'radial domain mismatch')
    require(geometry['turns'] == app['signed_turns'] == ['-1/1024', '1/1024'], 'angle domain mismatch')
    require(geometry['area_pi_coefficient'] == app['area_pi_coefficient'] == '21/5120000', 'wrong spatial area')
    require(spatial['mark_domain'] == ['-1/96000', '1/96000'] and
            app['full_height_window'] == ['57599/48000', '6/5'], 'full mark window mismatch')
    require(old['radius'] == app['fixed_r'] == '1/20' and old['birth'] == app['fixed_b'] == '6/5' and
            old['fixed_pin_axis'] == app['fixed_pin_axis'] == 'x', 'pin configuration mismatch')
    require(old['window_length'] == app['window_length'] == '1/48000' and
            F(old['jacobian_upper']) == F(app['density_coordinate_jacobian']) == 1, 'window or Jacobian mismatch')
    require(old['source_binding'] == sharp['source_binding'], 'source law or provenance mismatch')
    require(old['normalization_floor'] == sharp['imported']['h3_floor'] and
            old['pin_energy_upper'] == sharp['imported']['pin_energy_upper'], 'imported premise mismatch')
    pins = bernstein['repository_inputs']['files']
    for row in sharp['repository_dependencies']:
        if row['path'] in pins:
            require(pins[row['path']] == {'bytes': row['bytes'], 'sha256': row['sha256']},
                    'incompatible shared code: ' + row['path'])
    D, Q = F(spatial['determinant_lower']), F(spatial['q_lower'])
    require(D >= F(app['determinant_lower']) > 0 and Q >= F(app['mahalanobis_lower']) >= 0,
            'spatial result does not supply required determinant/energy')
    require(F(spatial['conditioning_energy_upper']) <= F(sharp['imported']['pin_energy_upper']),
            'six-pin conditioning energy exceeds imported allowance')
    piece = spatial['pieces'][0]
    energy = piece['shared_energy_proof']
    require(energy['target_established'] is True and F(energy['target']) == 103 and F(energy['margin']) > 0,
            'shared energy inequality unresolved')
    require(F(piece['determinant_lower']) == D and F(piece['q_lower']) == Q,
            'aggregate result differs from its only piece')
    integrand_upper = F(app['bound']['integrand_upper'])
    integral_upper = F(app['integral_interval'][1])
    require(app['bound']['typed_integrand_range'][0] == app['integral_interval'][0] == '0',
            'positive lower bound cannot be inferred from a majorant')
    require(0 < integrand_upper < F(1, 1000000) and 0 < integral_upper < F(33, 2560000000000),
            'new simple local bound not established')
    require(F(sharp['coefficient']) == F(64000001, 1000000), 'unexpected moment coefficient')
    return {
        'schema': 'RN_LOCAL_WEDGE_COMPOSITION_V1',
        'statement': 'Same fixed-r positive-x wedge, full mark window: I(y)<1/1000000 and integral_W I<33/2560000000000.',
        'spatial_auxiliary_rectangles': 1,
        'original_spatial_auxiliary_rectangles': 12,
        'geometry': geometry,
        'fixed_r': '1/20', 'fixed_b': '6/5', 'fixed_pin_axis': 'x',
        'height_window': app['full_height_window'],
        'determinant_lower_certified': str(D), 'mahalanobis_lower_certified': str(Q),
        'moment_coefficient': sharp['coefficient'],
        'typed_integrand_range': app['bound']['typed_integrand_range'],
        'integral_interval': app['integral_interval'],
        'integrand_strict_upper': '1/1000000', 'integral_strict_upper': '33/2560000000000',
        'original_simple_integrand_upper': '1/100000',
        'original_simple_integral_upper': '33/256000000000',
        'simple_bound_improvement_factor': 10,
        'spatial_premises_freshly_supplied_by': 'one-box Bernstein and shared-energy certificate',
        'imported_h3_and_pin_energy_reproved': False,
        'source_binding': sharp['source_binding'],
        'inputs': {'bernstein_report_sha256': sha256(canonical(bernstein)).hexdigest(),
                   'sharp_variance_report_sha256': sha256(canonical(sharp)).hexdigest()},
        'scope': {'full_annulus_closed': False, 'all_radii_closed': False,
                  'all_pin_orientations_closed': False, 'q0_closed': False,
                  'weighted_palm_or_event_interface_closed': False,
                  'scientific_status_changed': False, 'organizational_independence_credit': 0,
                  'authority': 'NONE'},
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    repo = args.repo.resolve(strict=True)
    requested = args.output.absolute()
    require(not requested.exists() and not requested.is_symlink(), 'output must be fresh')
    output = requested.parent.resolve(strict=True) / requested.name
    require(not output.is_relative_to(repo) and not output.is_relative_to(HERE),
            'output must be outside the repository and frozen bundle')
    output.mkdir()
    own_sha = sha256(Path(__file__).read_bytes()).hexdigest()
    launcher = [sys.executable, '-B'] + (['-O'] if sys.flags.optimize else [])
    commands = [
        launcher + [str(HERE/'bernstein/check_v2.py'), '--repo', str(repo), '--output', str(output/'spatial'), '--pieces', '1'],
        launcher + [str(HERE/'sharp_variance/check.py'), '--repo', str(repo), '--output', str(output/'sharp.json')],
    ]
    for index, command in enumerate(commands):
        with (output/f'replay-{index}.stdout').open('xb') as stdout, (output/f'replay-{index}.stderr').open('xb') as stderr:
            subprocess.run(command, check=True, stdout=stdout, stderr=stderr)
    spatial = json.loads((output/'spatial/result.json').read_bytes())
    sharp = json.loads((output/'sharp.json').read_bytes())
    result = compose(spatial, sharp)
    require(own_sha == sha256(Path(__file__).read_bytes()).hexdigest(), 'composition code changed during replay')
    result['composition_code_sha256'] = own_sha
    with (output/'result.json').open('xb') as stream:
        stream.write(canonical(result))
    print(result['statement'])


if __name__ == '__main__':
    main()
