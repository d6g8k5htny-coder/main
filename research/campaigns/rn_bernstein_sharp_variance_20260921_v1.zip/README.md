# Two RN improvements and one reproducible composition

The existing fixed-radius RN wedge now has a **one-rectangle certificate**
instead of twelve auxiliary strips, and its clean pointwise/integral upper
bounds improve by **a factor of ten**. These are mathematical successors to
the original result; its source files and historical proof remain unchanged.

For the normalized SIDE24 field, the same six pins, `r=1/20`, `b=6/5`, the
fixed x-axis pin direction, and the full height interval `[57599/48000,6/5]`,
the integration wedge remains

`1/10 <= rho <= 11/100`, `-1/1024 <= signed turns <= 1/1024`.

On this wedge the combined certificate gives

`I(y) < 1/1000000`, and `integral_W I(y)dy < 33/2560000000000`.

The previous clean bounds were `1/100000` and `33/256000000000` respectively.
This is the same small region, not additional annulus coverage. It occupies
`1/6092800` of the area of the full annulus from radius1/10 to5.

## What changed mathematically

1. **Bernstein ranges and a shared energy polynomial.** Exact tensor Bernstein
   coefficients retain spatial dependence. In addition to the determinant
   polynomial, the successor encloses `mu_fx² - 103 Var(fx)` before evaluating
   spatial intervals, then subtracts the proved mean/variance error allowances.
   This certifies `det(G)>8/10^25` and `q>=103` over the entire original
   containing rectangle. The original single-rectangle attempt is retained
   as a refusal. Every Taylor and determinant remainder is preserved.
2. **Actual stationary variances.** The determinant moment factor is
   `(m4+m2²)^3 < 64000001/1000000`, replacing512. Nonzero torus images and the
   normalizing denominator remain in the exact enclosure. The underlying
   coefficient improves by almost8; the tenfold headline compares the clean
   rounded final bounds, not an asserted tenfold coefficient or time gain.
3. **A checked composition.** `close_local_wedge.py` runs both numerical
   certificates afresh, verifies their source, domain, height-window, density
   Jacobian and premise compatibility, and supplies the spatial D/Q premises
   of the sharper majorant. It writes no scientific status and accepts no
   precomputed unverified report as its command-line input.

The proofs are in `bernstein/PROOF.md` and `sharp_variance/PROOF.md`.
`combined-result.json` records the exact rational endpoints and source custody.
The imported fixed-radius H3 floor and six-pin energy proof are explicit
premises; this delivery does not reprove them.

## Replay

Use Python3.11 and a checkout containing the exact pinned dependencies. The
original wedge is now in PR3 commit `dca27f77eaad7453b95c53933069955669ad8b65`.
Supply a fresh output directory outside both the repository and this bundle:

```sh
python -B close_local_wedge.py --repo /path/to/research-main --output /fresh/run-normal
python -B -O close_local_wedge.py --repo /path/to/research-main --output /fresh/run-optimized
python -B test_composition.py --spatial /fresh/run-normal/spatial/result.json --sharp /fresh/run-normal/sharp.json
```

All62 targeted tests passed in each mode:21 polynomial/energy tests,25 sharp
moment tests and16 composition controls. Parent fresh numerical replays were
byte-identical across normal/optimized Python and matched both authors'
frozen results. A separate same-provider reviewer checked the Bernstein
identity through degree36 and the mean-error inequality; this earns no
organizational independence credit. See `PARENT_VALIDATION.json` and
`PARENT_REVIEW.md` for evidence and limits.

Each subdirectory manifest has an exact allowlist. The root manifest also
pins all delivered files and excludes scratch probes and obsolete draft
results. Refused attempts remain distinguishable from certified bounds.
Local timings are observations, not a cross-machine performance claim.

## Relation to the screenshots and suggested architecture

The task **Abandonment Criteria Analysis** was read directly, including its
completed H3 delivery in [draft PR5](https://github.com/d6g8k5htny-coder/main/pull/5).
Its `1.747 r²` whole-band lower candidate, search/certification separation,
formula dependency hashes and local cache informed the review. Those results
are attributed to that task and are not relabeled as this delivery's work.

`DECISIONS.md` evaluates all six suggestions. Failed sampling is not proof;
overlapping numerical intervals are not independent verification; formula
hashes do not establish mathematical implication. General Sheets lineage,
hermetic builds and a second rigorous arithmetic backend are not claimed.
The H3 author's source-admission ordering repair has been requested separately.

Full-annulus RN, all radii and orientations, weighted-Palm/event interfaces,
q0 and independent acceptance remain open. Publication/integration is assigned
to **Connect local research repository**, the current sole repository writer.
No branch, source archive or governing scientific status was changed by this
scratch delivery.
