# Explicit H3 lower floor on the full small-radius band

For the actual normalized two-dimensional SIDE24 field, fixed x axis and
six pins at height `6/5`, this candidate proves

**`Z(r) >= (17/10) r²` for every `0 < r <= 1/20`.**

`Z` is the original conditional expectation of the absolute product of the
two Hessian determinants, restricted to a maximum at `M` and saddle at `S`.
The earlier P01 candidate established a positive rescaled limit but no explicit
radius. This successor supplies a complete quantitative proof on the full band.
The new endpoint floor is `17/4000 = 0.00425`; the separate historical
fixed-r numerical floor remains stronger at the endpoint.

The actual unrounded certificate yields a uniform lower endpoint above
`1.7051902641` for `Z(r)/r²`, which implies the displayed exact rational `17/10`.
Those decimals are only a reading aid. Every numerical enclosure is computed
with exact rational repository intervals, including the full periodized kernel
tails and normalization.

Read `PROOF.md`; replay `check_midpoint_floor.py --verify result_midpoint.json`.
`RUN.json` provides portable command templates. The separate baseline
`check_explicit_floor.py` and `result.json` prove `Z(r) >= r²/4` with a different
transverse event. `test_explicit_floor.py` has 27 mathematical and verification
negative controls, including normal/optimized byte-identity replays.

The key actual-law structure is three independent Gaussian line sectors
`f`, `fy` and `fyy+m2*f`. Within the transverse sector, midpoint and difference
are also independent. Pin energy below `8`, fourth-derivative Peano kernels,
Gaussian one-sided tails and truncated Gaussian moments control the entire
radius continuum and preserve the maximum/saddle event exactly.

**Scope:** fixed x axis only. No all-angle H3 result, full RN/q0 closure,
event transfer, theorem assembly, 3D composition or prize result is claimed.
Historical constants and RN budgets are not silently replaced. Canonical
scientific statuses are unchanged; independent external review remains open.
Organizational independence credit is zero.

The target is `Q0-H3-FLOOR-EXPLICIT-20260920-v1`, R17 claim
`323de6f0-4d01-4cbd-9ddb-e522c591aca0`, row100. Root coordinates the claim.
The repo was read only throughout this work. The final `MANIFEST.json`
allowlist excludes the retained `*.draft-target-order` pre-correction reports.
