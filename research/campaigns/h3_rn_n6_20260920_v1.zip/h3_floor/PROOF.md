# An explicit whole-band H3 lower floor for the actual fixed-axis SIDE24 law

**Author-side proved candidate.** For the normalized two-dimensional side-24
periodized Gaussian field, the original six-pin H3 expectation satisfies

\[
 Z(r)\ge \frac{17}{10}r^2,\qquad 0<r\le\frac1{20}.
\]

At the endpoint the new bound is `17/4000 = 0.00425`. This is weaker than
the previous, separate fixed-r numerical floor, but holds on the entire
continuum down to zero. It replaces the previous existential-radius argument
at this **fixed x-axis geometry** with an explicit finite-r proof. The simpler
baseline checker independently proves `Z(r) >= r²/4` on the same band.

This is an author-side mathematical result, not an operator status change.
It does not establish the all-angle H3 statement, the full 24-jet chart,
spatial RN integrals, event transfer, q0 closure, any 3D composition or any
prize result. Historical H3 constants and their consumption in RN budgets
are not reclassified. The parent supplied the midpoint/difference refinement
and independently checked its interval arithmetic; all authors/reviewers are
OpenAI and organizational independence credit is **zero**.

## 1. Exact law and conditioning

Let

\[
 k(s)=\frac{\sum_{j\in\mathbb Z}e^{-(s+24j)^2/2}}
             {\sum_{j\in\mathbb Z}e^{-(24j)^2/2}},\qquad
 K(x,y)=k(x)k(y),\qquad m_{2a}=(-1)^a k^{(2a)}(0).
\]

The pins are `M=(-r/2,0)`, `S=(r/2,0)` and

\[
 f(M)=6/5,\quad f(S)=6/5-r^3/6,\quad
 \nabla f(M)=\nabla f(S)=0.
\]

The source is the hash-bound, nonexcluded RN5 member `closure_round2/rn_field.py`
and its H3 source member. Their bytes are checked but never executed. The
copied P01 author checker is bound by SHA before import; it evaluates the full
normalized image sums with certified tails, using `research/interval/` exact
rational arithmetic. `result_midpoint.json` records source identities,
computational dependency hashes and exact interval endpoints.

Use P01's nonsingular six-vector

\[
 V=(f_M,f_{x,M},f_{y,M},(f_{x,S}-f_{x,M})/r,
       (f_{y,S}-f_{y,M})/r,
       (f_S-f_M)/r^3-(f_{x,S}+f_{x,M})/(2r^2)).
\]

Its conditioned value is `v=(6/5,0,0,0,0,-1/6)`. Write `G(r)=Cov(V(r))`.
The P01 integral identities and exact six-dimensional interval LDL proof give

\[
 G(0)\succ(3/80)I,\qquad
 \|a\cdot(V(r)-V(0))\|_2\le(31/20)r\|a\|_2.
\]

The checker re-evaluates both inequalities, including all kernel tails.
Since `(193/1000)^2 < 3/80`, reverse triangle inequality gives

\[
 G(r)\succeq[1-(31/20)r/(193/1000)]^2G(0).
\]

The block-diagonal limiting covariance has only `(f,fxx)` and
`(fx,-fxxx/12)` nontrivial blocks. Therefore its exact pin energy is

\[
 Q(0)=v^TG(0)^{-1}v
 =\frac{36m_4}{25(m_4-m_2^2)}
   +\frac{4m_2}{m_2m_6-m_4^2}<17/6.
\]

Loewner inversion then yields, for the entire band,

\[
 Q(r)=v^TG(r)^{-1}v
 \le\frac{17/6}{[1-(31/20)(1/20)/(193/1000)]^2}
 =\frac{1266466}{160083}<8. \tag{1}
\]

All conditional distributions below mean the canonical Gaussian regression
law at the displayed exact pin value. The positive covariance bound makes
this law well-defined even though the conditioning event has probability zero.

## 2. Three independent Gaussian line sectors

Define `X(x)=f(x,0)`, `Y(x)=fy(x,0)` and
`E(x)=fyy(x,0)+m2*f(x,0)`. Separability and parity imply, for every `x,z`,

\[
 \operatorname{Cov}(X(x),Y(z))=0,\quad
 \operatorname{Cov}(X(x),E(z))=(-m_2+m_2)k(x-z)=0,
 \quad\operatorname{Cov}(Y(x),E(z))=0.
\]

Thus the three complete Gaussian processes, including their derivatives, are
mutually independent. The pins split into four constraints on `X,X'` and two
zero constraints on `Y`. Conditional on these pins, the three sectors stay
independent and `E` retains its unconditioned law,

\[
 \operatorname{Cov}(E(x),E(z))=\sigma_e^2 k(x-z),\qquad
 \sigma_e^2=m_4-m_2^2>0.
\]

Consequently the **actual finite-r** transverse Hessians are

\[
 q_M=f_{yy}(M)=-\tfrac65m_2+E(M),\qquad
 q_S=-m_2(\tfrac65-r^3/6)+E(S). \tag{2}
\]

This is a structural identity for the stipulated field, not an imported
generic covariance hypothesis or an unconditional substitution into a
conditional law.

## 3. Axial error kernels and a uniform event probability

Set `A_M=fxx(M)/r`, `A_S=fxx(S)/r` in the conditioned law. Before
conditioning these are represented by the pin-subtracted forms

\[
 A_M=-\int_{-1/2}^{1/2}(1/2-t)X'''(rt)\,dt,\qquad
 A_S= \int_{-1/2}^{1/2}(1/2+t)X'''(rt)\,dt.
\]

P01 gives `V5=-(1/2) integral (1/4-t²)X'''(rt)dt`. Subtract `6V5`
from `A_M` and add it to `A_S`. Integrating by parts, with the antiderivatives
vanishing at both endpoints, gives the exact linear random-variable identities

\[
 R_M:=A_M-6V_5=r\int K_M(t)X''''(rt)dt,\quad
 R_S:=A_S+6V_5=r\int K_S(t)X''''(rt)dt,
\]

where

\[
 K_M=(1/2-t)^2(1/2+t),\qquad
 K_S=(1/2+t)^2(1/2-t).
\]

Both kernels are nonnegative and have integral `1/12`. After conditioning,
`R_M=A_M+1` and `R_S=A_S-1`. Minkowski gives the unconditional variance
bound `Var(R_i)<=s(r)²`, where `s(r)=r sqrt(m8)/12`.

For any centered jointly Gaussian linear variable `R`, regression gives
`mean(R|V=v)=cG^-1 v` and conditional variance `Var(R)-cG^-1c^T`.
Cauchy–Schwarz in the `G^-1` metric and the Schur complement imply

\[
 |\mathbb E(R\mid V=v)|\le\sqrt{Q(r)}\sqrt{\operatorname{Var}R},
 \qquad \operatorname{Var}(R\mid V=v)\le\operatorname{Var}R.
\]

Using (1), the upper tail of `R_M` above `1/5` and the lower tail of `R_S`
below `-1/5` are each at most

\[
 \overline\Phi\left(\frac{1/5}{(1/20)\sqrt{m_8}/12}-\sqrt8\right)
 <1/30. \tag{3}
\]

The argument is certified positive. For smaller `r` the same bound holds
because `s(r)` is smaller. If a conditional variance vanishes the variable
is deterministic and the same tail bound follows from the mean bound.
No independence between `R_M` and `R_S` is asserted or needed. A union bound
proves

\[
 \mathbb P(\mathcal A)\ge14/15,\qquad
 \mathcal A=\{A_M\le-4/5,\ A_S\ge4/5\}. \tag{4}
\]

## 4. Mixed derivatives cost only one second moment

The conditioned mixed Hessian entry is `fxy(M)=r B_M`, with

\[
 B_M=-\int_{-1/2}^{1/2}(1/2-t)Y''(rt)dt.
\]

Both `Y` pin values are zero, so the conditional mean of `B_M` is zero.
Conditioning reduces covariance, and the nonnegative kernel has mass `1/2`;
therefore

\[
 \mathbb E B_M^2\le m_4m_2/4=:\beta. \tag{5}
\]

`B_M` belongs to the independent `Y` sector. No bound on `B_S` is needed:
its square enters the saddle determinant with a favorable negative sign.

## 5. Transverse midpoint and difference

Put `Qbar=(q_M+q_S)/2`, `Delta=q_S-q_M`. Equal endpoint variances of the
stationary `E` process give

\[
 \operatorname{Cov}((E_M+E_S)/2,E_S-E_M)=0.
\]

These two Gaussian variables are independent, including under the pins by
Section 2. Their exact means and variances are

\[
 \mu_{\bar Q}=-m_2(6/5-r^3/12),\quad
 \sigma_{\bar Q}^2=\sigma_e^2(1+k(r))/2,
\]
\[
 \mu_\Delta=m_2r^3/6,\qquad
 \sigma_\Delta^2=2\sigma_e^2(1-k(r)). \tag{6}
\]

The mean-square fundamental theorem of calculus gives
`2(1-k(r))=E[(X(S)-X(M))²]<=m2*r²`, while covariance positivity gives
`k(r)<=1`. Hence throughout the band

\[
 \sigma_e^2(1-m_2r_{max}^2/4)\le\sigma_{\bar Q}^2\le\sigma_e^2,
 \qquad \sigma_\Delta\le r_{max}\sqrt{\sigma_e^2m_2}.
\]

Choose `d=3/25` and `D={|Delta|<=2d}`. Bounding **both** Gaussian tails,

\[
 \mathbb P(D)\ge p_D:=1-2\overline\Phi\left(
 \frac{2d-m_2r_{max}^3/6}{r_{max}\sqrt{\sigma_e^2m_2}}\right)>0. \tag{7}
\]

The negative tail is no larger than this positive-tail envelope because the
mean of `Delta` is nonnegative. The checker retains both tails and the
nonzero mean. The event `D` is independent of `Qbar`, `A` and `B_M`.

Let `T=(-Qbar-d)_+`. If `T>0` and `D` occurs, both transverse entries are
at most `-T`. If `W=-Qbar-d~N(mu,sigma²)`, its positive-part moments are

\[
 M_1=\mathbb E W_+=\sigma\phi(\mu/\sigma)+\mu\Phi(\mu/\sigma),
\]
\[
 M_2=\mathbb E W_+^2=(\sigma^2+\mu^2)\Phi(\mu/\sigma)
                       +\mu\sigma\phi(\mu/\sigma). \tag{8}
\]

They follow by integrating `z phi(z)` and `z² phi(z)` over the half-line.
The checker evaluates these identities with an interval for the actual
`mu=m2*(6/5-r³/12)-d` and the variance interval in (6). Correlation between
the parameter intervals is retained conservatively by interval arithmetic;
no monotonicity or independence of those parameters is assumed.

## 6. Typed determinant inequality and explicit lower coefficient

Write each Hessian as `[[r A,r B],[r B,q]]` and its determinant as `r D_i`,
where `D_i=A_i q_i-r B_i²`. Put `a=4/5`. On `A` and `D`, when `T>0`,

\[
 D_M\ge aT-rB_M^2,\qquad D_S\le-aT-rB_S^2\le-aT.
\]

When `aT-rB_M²>0`, `A_M<0` and `D_M>0`, so `M` is a strict maximum;
`D_S<0`, so `S` is a strict saddle. If the positive part is zero the desired
lower bound is zero. Thus, for all outcomes, the rescaled typed integrand is
at least

\[
 1_{\mathcal A}1_D\,aT(aT-rB_M^2)_+.
\]

Using `x_+>=x`, independence of all the stated factors, and (5), gives

\[
 \frac{Z(r)}{r^2}
 \ge\mathbb P(\mathcal A)\mathbb P(D)
      [a^2 M_2-ar\beta M_1]. \tag{9}
\]

The bracket is certified strictly positive before multiplying lower
probability bounds. This order matters: multiplying a negative bracket by a
smaller probability would not preserve the required direction.

The fully retained interval bounds in `result_midpoint.json` give a lower
endpoint exceeding **17/10** (approximately 1.70519, displayed only for
orientation). In particular (9) proves the asserted exact rational floor
on every `0<r<=1/20`, not on a sampled grid. Gaussian CDF/density values,
kernel normalization, all image tails, moment bounds, pin inversion and
transport are enclosed through exact rational repository intervals.

## 7. Baseline route and verification scope

`check_explicit_floor.py` separately proves the weaker `r²/4` bound by
`P(q_M<=-1)>=5/9` and `P(q_S-q_M>1/6)<=1/100`, so
`P(q_M<=-1,q_S<=-5/6)>=491/900`. Together with (4) and (5), this gives

\[
 (14/15)(491/900)(2/3)(4/5-r_{max}\beta)>1/4.
\]

This additional route is a check on typing, signs and sector separation;
it is not an independently authored scientific review. The tests exercise
mutated covariance-energy margins, omitted difference tails, an understated
beta variance, reversed Peano signs, overstated probabilities/floors, typed
report corruption, forbidden output and altered source identities. Normal
and optimized Python must reproduce the same reports byte for byte.
