#!/usr/bin/env python3
"""Actual fixed-axis SIDE24 H3: Z(r)>=(17/10)r² for 0<r<=1/20.

Gaussian midpoint/difference independence upgrades the fully replayed
baseline floor. Author-side proof candidate, no scientific-status changes.
"""
from fractions import Fraction as F
from pathlib import Path
import argparse
import hashlib
import json
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
BASE=HERE/'check_explicit_floor.py'
BASE_SHA='36010fd2d0cbede787cd363318e961d0243208f69e3d1a3ec92bdc4bcd7ec77e'
if hashlib.sha256(BASE.read_bytes()).hexdigest()!=BASE_SHA:
    raise SystemExit('FAIL: baseline checker identity mismatch before import')
sys.path.insert(0,str(HERE))
import check_explicit_floor as b
from research.interval import Interval as I, sqrt, Phi, normal_pdf, normal_sf

need,encode,canonical,digest=b.need,b.encode,b.canonical,b.digest


def prove(*,radius=F(1,20),floor=F(17,10),gap_half=F(3,25),
          difference_tail_factor=F(2),variance_loss_factor=F(1,4)):
    need(all(type(x) is F for x in (radius,floor,gap_half,difference_tail_factor,
                                  variance_loss_factor)), 'exact Fraction parameters required')
    need(0<radius<=F(1,20),'radius in (0,1/20]')
    need(0<gap_half<1 and floor>0,'positive midpoint event parameters')
    need(difference_tail_factor>=2,'two-sided difference needs both Gaussian tails')
    need(variance_loss_factor>=F(1,4),'midpoint variance loss includes factor 1/4')
    baseline=b.prove(radius=radius)
    m,z=b.h.moments()
    sigma2=(m[4]-m[2]**2).round_out(b.h.BITS)
    # k(r) in [1-m2*r²/2,1] on the whole band; actual S,D independent.
    midpoint_variance=(sigma2*I(1-variance_loss_factor*m[2].hi*radius**2,1)).round_out(b.h.BITS)
    need(midpoint_variance.lo>0,'midpoint variance uniformly positive')
    positive_part_mean=I(m[2].lo*(F(6,5)-radius**3/12)-gap_half,
                         m[2].hi*F(6,5)-gap_half).round_out(b.h.BITS)
    need(positive_part_mean.lo>0,'positive-part mean positive in chosen event')
    sd=sqrt(midpoint_variance,b.h.PREC).round_out(b.h.BITS)
    standardized=(positive_part_mean/sd).round_out(b.h.BITS)
    cdf=Phi(standardized,b.h.PREC).round_out(b.h.BITS)
    pdf=normal_pdf(standardized,b.h.PREC).round_out(b.h.BITS)
    first=(sd*pdf+positive_part_mean*cdf).round_out(b.h.BITS)
    second=((midpoint_variance+positive_part_mean**2)*cdf+
            positive_part_mean*sd*pdf).round_out(b.h.BITS)
    need(first.lo>0 and second.lo>0,'positive truncated Gaussian moments')

    difference_mean=(m[2]*radius**3/6).round_out(b.h.BITS)
    difference_sd=(radius*sqrt(sigma2*m[2],b.h.PREC)).round_out(b.h.BITS)
    difference_argument=((2*gap_half-difference_mean)/difference_sd).round_out(b.h.BITS)
    need(difference_argument.lo>0,'two-sided difference threshold exceeds its mean')
    one_tail=normal_sf(difference_argument,b.h.PREC).round_out(b.h.BITS)
    p_difference=(1-difference_tail_factor*one_tail).round_out(b.h.BITS)
    need(p_difference.lo>0,'difference-event probability positive')
    p_axial=F(baseline['axial']['good_event_probability_floor'])
    alpha=1-F(baseline['axial']['tolerance'])
    beta_variance=(m[4]*m[2]/4).round_out(b.h.BITS)
    positive_part_weight=(alpha**2*second-alpha*radius*beta_variance*first).round_out(b.h.BITS)
    need(positive_part_weight.lo>0,'averaged determinant budget positive before probability product')
    lower=(p_axial*p_difference*positive_part_weight).round_out(b.h.BITS)
    need(lower.lo>=floor,'requested uniform H3 coefficient is proved')
    return encode({'schema':'actual-side24-midpoint-h3-floor-v1',
        'status':'PROVED_CANDIDATE','target':'Q0-H3-FLOOR-EXPLICIT-20260920-v1',
        'domain':baseline['domain'],
        'conclusion':{'quantity':baseline['conclusion']['quantity'],
                      'uniform_lower_bound':f'Z(r) >= {floor} * r²',
                      'coefficient':floor,'explicit_radius':radius,
                      'endpoint_at_rmax':floor*radius**2},
        'baseline_payload_sha256':digest(canonical(baseline).encode()),
        'source_binding':baseline['source_binding'],'moments':m,
        'pin_energy_upper':baseline['pin_proof']['energy_upper'],
        'axial_probability_floor':p_axial,'axial_absolute_floor':alpha,
        'midpoint':{'gap_half':gap_half,'variance':midpoint_variance,
                    'positive_part_mean':positive_part_mean,
                    'standardized_mean':standardized,'first_positive_part_moment':first,
                    'second_positive_part_moment':second},
        'difference':{'mean_upper':difference_mean,'sd_upper':difference_sd,
                      'tail_argument':difference_argument,'one_sided_tail':one_tail,
                      'tail_factor':difference_tail_factor,'event_probability':p_difference},
        'beta_variance_upper':beta_variance,
        'averaged_determinant_budget':positive_part_weight,
        'derived_uniform_lower_coefficient':lower,
        'independence':'X,Y,E sectors mutually independent under split conditioning; Gaussian E midpoint and difference independent',
        'finite_r_rescaled_h3_floor_established':True,
        'scientific_status_changed':False,'original_prize_closed':False,
        'organizational_independence_credit':0,'external_review':'OPEN',
        'remaining':['Fixed-axis normalized SIDE24 six-pin law only; no all-angle result.',
                     'Historical theorem constants are not reclassified or silently substituted into RN budgets.',
                     'Full RN/q0 event transfer, theorem assembly and independent review remain open.']})


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=b.h.DEFAULT_REPO)
    p.add_argument('--output',type=Path)
    p.add_argument('--verify',type=Path)
    p.add_argument('--radius',type=F,default=F(1,20))
    p.add_argument('--floor',type=F,default=F(17,10))
    p.add_argument('--gap-half',type=F,default=F(3,25))
    p.add_argument('--difference-tail-factor',type=F,default=F(2))
    p.add_argument('--variance-loss-factor',type=F,default=F(1,4))
    args=p.parse_args()
    before=b.h.dependencies()
    result=prove(**{k:v for k,v in vars(args).items() if k not in ('repo','output','verify')})
    need(before==b.h.dependencies(),'repository dependencies stable during replay')
    result['dependencies']={'repository':before,
                            'author_support':{str(b.SUPPORT.relative_to(HERE)):b.h.identity(b.SUPPORT),
                                              str(BASE.relative_to(HERE)):b.h.identity(BASE)},
                            'checker':b.h.identity(Path(__file__))}
    envelope={'payload':result,'payload_sha256':digest(canonical(result).encode())}
    if args.verify:
        need(canonical(json.loads(args.verify.read_text()))==canonical(envelope),
             'candidate must equal fully recomputed typed report')
    if args.output:
        target=args.output.resolve()
        need(not target.is_relative_to(b.h.REPO),'output must be outside read-only repository')
        with target.open('x') as f:
            f.write(json.dumps(envelope,sort_keys=True,indent=2)+'\n')
    print(f'PASS: actual fixed-axis SIDE24 Z(r)>={args.floor}*r² for 0<r<={args.radius}; midpoint proof, no status promotion')


if __name__=='__main__':
    try:
        main()
    except (ValueError,OSError,KeyError,TypeError) as error:
        print('FAIL: '+str(error),file=sys.stderr)
        sys.exit(1)
