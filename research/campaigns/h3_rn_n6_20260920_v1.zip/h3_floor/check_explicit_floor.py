#!/usr/bin/env python3
"""Actual fixed-axis SIDE24 H3 floor Z(r)>=r²/4, 0<r<=1/20.

Exact author-side interval candidate; no canonical status changes, zero
organizational independence, no all-angle, RN, q0 or prize closure.
"""
from fractions import Fraction as F
from pathlib import Path
import argparse
import hashlib
import json
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
SUPPORT = HERE / 'support/check_h3_uniform.py'
SUPPORT_SHA = 'ff61ec0785da6abb3190aa77626fdbe8d43988c21ae3470cca113af381a4ccbc'
if hashlib.sha256(SUPPORT.read_bytes()).hexdigest() != SUPPORT_SHA:
    raise SystemExit('FAIL: prior author checker identity mismatch before import')
sys.path.insert(0, str(HERE / 'support'))
import check_h3_uniform as h
from research.interval import Interval as I, sqrt, Phi, normal_sf

need, encode, canonical, digest = h.need, h.encode, h.canonical, h.digest
RMAX = F(1,20)


def integral_poly(coefficients):
    """Integral on [-1/2,1/2], coefficients in increasing powers."""
    return sum((c * 2 * F(1,2)**(j+1) / (j+1)
                for j,c in enumerate(coefficients) if j%2 == 0), F(0))


def verify_peano(kernel_sign=1):
    # K_M=(1/2-t)^2(1/2+t); K_S=(1/2+t)^2(1/2-t).
    km = (F(1,8),F(-1,4),F(-1,2),F(1))
    ks = (F(1,8),F(1,4),F(-1,2),F(-1))
    need(integral_poly(km)==F(1,12), 'left Peano mass is 1/12')
    need(integral_poly(ks)==F(1,12), 'right Peano mass is 1/12')
    x, y = F(-1,2), F(1,2)
    for n in range(17):
        derivative = lambda z,k: (F(0) if n<k else
            F(__import__('math').prod(range(n-k+1,n+1))) * z**(n-k))
        v3 = derivative(y,1)-derivative(x,1)
        v5 = y**n-x**n-(derivative(y,1)+derivative(x,1))/2
        left = derivative(x,2)-v3-6*v5
        right = derivative(y,2)-v3+6*v5
        if n<4:
            pl = pr = F(0)
        else:
            multiplier = __import__('math').prod(range(n-3,n+1))
            pl = kernel_sign*multiplier*integral_poly((F(0),)*(n-4)+km)
            pr = kernel_sign*multiplier*integral_poly((F(0),)*(n-4)+ks)
        need(left==pl and right==pr, 'fourth-order Peano identity degree '+str(n))
    return {'left_kernel':km,'right_kernel':ks,'mass':F(1,12),
            'monomials_checked':list(range(17)),
            'analytic_proof':'Two integrations by parts in PROOF.md; monomials are negative controls.'}


def prove(*,radius=RMAX,floor=F(1,4),energy_bound=F(8),
          sv_bound=F(193,1000),initial_energy_bound=F(17,6),
          axial_tolerance=F(1,5),axial_tail_budget=F(1,30),
          q_difference=F(1,6),q_tail_budget=F(1,100),
          q_marginal_floor=F(5,9),beta_variance_factor=F(1,4),
          kernel_sign=1):
    values=(radius,floor,energy_bound,sv_bound,initial_energy_bound,
            axial_tolerance,axial_tail_budget,q_difference,q_tail_budget,
            q_marginal_floor,beta_variance_factor)
    need(all(type(x) is F for x in values),'all numerical bounds must be exact Fractions')
    need(0<radius<=RMAX,'radius in (0,1/20]')
    need(0<axial_tolerance<1 and 0<q_difference<1,'positive event margins below one')
    need(floor>0 and energy_bound>0 and initial_energy_bound>0 and sv_bound>0,
         'positive requested proof constants')
    source = h.custody()
    peano = verify_peano(kernel_sign)
    h.verify_identities()
    m,z = h.moments()
    gram=h.limiting_gram(m)
    shifted=tuple(tuple(x-(h.LIMIT_FLOOR if i==j else 0)
                        for j,x in enumerate(row)) for i,row in enumerate(gram))
    ldlt=h.interval_ldlt(shifted,round_bits=h.BITS)
    need(all(d.lo>0 for d in ldlt.pivots),'G(0) exceeds 3/80 I')
    transport_sq=(m[2]/4+m[4]/4+m[2]**2/4+m[6]/16+
                  m[4]*m[2]/16+m[8]/4096).round_out(h.BITS)
    need(transport_sq.hi<=h.TRANSPORT**2,'31/20 bounds pin transport')
    need(sv_bound**2<=h.LIMIT_FLOOR,'singular-value lower bound justified')
    relative_gap=1-h.TRANSPORT*radius/sv_bound
    need(relative_gap>0,'relative covariance gap positive')
    q0=(F(36,25)*m[4]/(m[4]-m[2]**2)+
        4*m[2]/(m[2]*m[6]-m[4]**2)).round_out(h.BITS)
    need(q0.hi<=initial_energy_bound,'initial pin energy upper bound justified')
    energy_transport=initial_energy_bound/relative_gap**2
    need(energy_transport<=energy_bound,'uniform pin energy upper bound justified')

    # R_M=A_M+1, R_S=A_S-1 after conditioning. Their unconditional
    # variances are <= m8*r²/144 by their nonnegative Peano kernels.
    smax=(radius*sqrt(m[8],h.PREC)/12).round_out(h.BITS)
    root_energy=sqrt(I.exact(energy_bound),h.PREC).round_out(h.BITS)
    axial_arg=(axial_tolerance/smax-root_energy).round_out(h.BITS)
    need(axial_arg.lo>0,'one-sided axial Gaussian margin positive')
    axial_tail=normal_sf(axial_arg,h.PREC).round_out(h.BITS)
    need(0<axial_tail_budget<F(1,2) and axial_tail.hi<=axial_tail_budget,
         'axial one-sided Gaussian tail budget justified')
    p_axial=1-2*axial_tail_budget

    # E(x)=fyy(x,0)+m2*f(x,0) is independent of BOTH other line sectors
    # and all six pins. These are actual finite-r marginal laws.
    sigma2=(m[4]-m[2]**2).round_out(h.BITS)
    need(sigma2.lo>0,'transverse residual variance positive')
    marginal_arg=((F(6,5)*m[2]-1)/sqrt(sigma2,h.PREC)).round_out(h.BITS)
    marginal_probability=Phi(marginal_arg,h.PREC).round_out(h.BITS)
    need(0<q_marginal_floor<1 and marginal_probability.lo>=q_marginal_floor,
         'actual transverse Gaussian marginal probability justified')
    # 2(1-k(r))<=m2*r² from mean-square fundamental theorem of calculus.
    difference_sd=(radius*sqrt(sigma2*m[2],h.PREC)).round_out(h.BITS)
    difference_mean=m[2]*radius**3/6
    difference_arg=((q_difference-difference_mean)/difference_sd).round_out(h.BITS)
    need(difference_arg.lo>0,'one-sided transverse difference margin positive')
    difference_tail=normal_sf(difference_arg,h.PREC).round_out(h.BITS)
    need(0<q_tail_budget<1 and difference_tail.hi<=q_tail_budget,
         'transverse difference Gaussian tail budget justified')
    p_transverse=q_marginal_floor-q_tail_budget
    need(p_transverse>0,'transverse event probability positive')

    # B_M=-integral(1/2-t)Y''(rt)dt. Kernel mass is exactly1/2.
    need(beta_variance_factor>=F(1,4),'beta variance includes squared kernel mass 1/4')
    beta_variance=(beta_variance_factor*m[4]*m[2]).round_out(h.BITS)
    alpha=1-axial_tolerance
    left_determinant_budget=I.exact(alpha)-radius*beta_variance
    need(left_determinant_budget.lo>0,'positive expected left determinant margin')
    raw_lower=(p_axial*p_transverse*alpha*(1-q_difference)*
               left_determinant_budget).round_out(h.BITS)
    need(raw_lower.lo>=floor,'requested H3 floor follows from event/product bound')
    return encode({
        'schema':'actual-side24-explicit-h3-floor-v1','status':'PROVED_CANDIDATE',
        'target':'Q0-H3-FLOOR-EXPLICIT-20260920-v1',
        'domain':{'side':24,'dimension':2,'orientation':'fixed x axis',
                  'height':'6/5','radius':f'(0,{radius}]',
                  'six_pins':'f(M)=6/5,f(S)=6/5-r³/6,grad f(M)=grad f(S)=0'},
        'conclusion':{'quantity':'E[abs(det H_M det H_S) 1{M maximum,S saddle}|six pins]',
                      'uniform_lower_bound':f'Z(r) >= {floor} * r²',
                      'coefficient':floor,'explicit_radius':radius,
                      'endpoint_at_rmax':floor*radius**2},
        'source_binding':source,'moments':m,'normalizer':z,
        'pin_proof':{'limiting_covariance_floor':h.LIMIT_FLOOR,
                     'ldlt_pivots':ldlt.pivots,'transport_squared':transport_sq,
                     'transport':h.TRANSPORT,'singular_value_floor':sv_bound,
                     'relative_gap':relative_gap,'initial_energy':q0,
                     'initial_energy_upper':initial_energy_bound,
                     'transported_energy_upper':energy_transport,'energy_upper':energy_bound},
        'fourth_derivative_peano':peano,
        'axial':{'tolerance':axial_tolerance,'unconditional_sd_upper':smax,
                 'mean_sd_factor':root_energy,'tail_argument':axial_arg,
                 'one_sided_tail':axial_tail,'one_sided_budget':axial_tail_budget,
                 'good_event_probability_floor':p_axial},
        'transverse':{'residual_variance':sigma2,'marginal_argument':marginal_arg,
                      'marginal_probability':marginal_probability,
                      'marginal_probability_floor':q_marginal_floor,
                      'difference_tolerance':q_difference,'difference_mean_upper':difference_mean,
                      'difference_sd_upper':difference_sd,'difference_argument':difference_arg,
                      'difference_tail':difference_tail,'difference_tail_budget':q_tail_budget,
                      'good_event_probability_floor':p_transverse},
        'beta_variance_upper':beta_variance,
        'determinant_budget':left_determinant_budget,
        'derived_lower_coefficient':raw_lower,
        'sector_independence':'X=f(x,0), Y=fy(x,0), E=fyy(x,0)+m2*f(x,0); Gaussian and mutually independent',
        'typed_event':'A_M<0 and D_M>0 imply maximum; D_S<0 implies saddle',
        'finite_r_rescaled_h3_floor_established':True,
        'scientific_status_changed':False,'original_prize_closed':False,
        'organizational_independence_credit':0,'external_review':'OPEN',
        'remaining':['Fixed x-axis law only; all-angle H3 bound is not established.',
                     'This smaller coefficient does not reproduce historical H3 constants or license their RN budgets.',
                     'Full RN, q0, event transfer, theorem assembly and independent review remain open.']})


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=h.DEFAULT_REPO)
    p.add_argument('--output',type=Path)
    p.add_argument('--verify',type=Path)
    for name,default in [('radius',RMAX),('floor',F(1,4)),('energy-bound',F(8)),
                         ('sv-bound',F(193,1000)),('initial-energy-bound',F(17,6)),
                         ('axial-tolerance',F(1,5)),('axial-tail-budget',F(1,30)),
                         ('q-difference',F(1,6)),('q-tail-budget',F(1,100)),
                         ('q-marginal-floor',F(5,9)),('beta-variance-factor',F(1,4))]:
        p.add_argument('--'+name,type=F,default=default)
    p.add_argument('--kernel-sign',type=int,default=1)
    args=p.parse_args()
    before=h.dependencies()
    result=prove(**{k:v for k,v in vars(args).items() if k not in ('repo','output','verify')})
    need(h.dependencies()==before,'repository dependencies stable during replay')
    result['dependencies']={'repository':before,
                            'author_support':{str(SUPPORT.relative_to(HERE)):h.identity(SUPPORT)},
                            'checker':h.identity(Path(__file__))}
    envelope={'payload':result,'payload_sha256':digest(canonical(result).encode())}
    if args.verify:
        need(canonical(json.loads(args.verify.read_text()))==canonical(envelope),
             'candidate must equal fully recomputed typed report')
    if args.output:
        target=args.output.resolve()
        need(not target.is_relative_to(h.REPO),'output must be outside read-only repository')
        with target.open('x') as f:
            f.write(json.dumps(envelope,sort_keys=True,indent=2)+'\n')
    print(f'PASS: actual fixed-axis SIDE24 Z(r)>={args.floor}*r² for 0<r<={args.radius}; no status promotion')


if __name__=='__main__':
    try:
        main()
    except (ValueError,OSError,KeyError,TypeError) as error:
        print('FAIL: '+str(error),file=sys.stderr)
        sys.exit(1)
