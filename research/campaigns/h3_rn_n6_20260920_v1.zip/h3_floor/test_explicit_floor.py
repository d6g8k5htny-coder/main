"""Falsification controls for the explicit actual-law H3 candidate."""
from fractions import Fraction as F
from pathlib import Path
import copy
import json
import os
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

import check_explicit_floor as b
import check_midpoint_floor as m

HERE=Path(__file__).resolve().parent


class FloorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.report=json.loads((HERE/'result_midpoint.json').read_text())

    def cli(self,script,args,optimized=None):
        if optimized is None:
            optimized=bool(sys.flags.optimize)
        return subprocess.run([sys.executable,'-B',*(['-O'] if optimized else []),
            str(HERE/script),*map(str,args)],capture_output=True,text=True,timeout=60,
            env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})

    def fail_cli(self,script,args,message):
        result=self.cli(script,args)
        self.assertEqual(result.returncode,1,result.stdout+result.stderr)
        self.assertIn(message,result.stderr)
        self.assertNotIn('PASS:',result.stdout)

    def test_peano_kernel_mass(self):
        result=b.verify_peano()
        self.assertEqual(result['mass'],F(1,12))
        # Quartic f=x^4 has both axial errors exactly2 at r=1.
        self.assertEqual(F(24)*result['mass'],2)

    def test_reversed_fourth_derivative_sign_fails(self):
        self.fail_cli('check_explicit_floor.py',['--kernel-sign','-1'],
                      'fourth-order Peano identity degree 4')

    def test_understated_pin_energy_fails(self):
        self.fail_cli('check_explicit_floor.py',['--energy-bound','7'],
                      'uniform pin energy upper bound justified')

    def test_understated_initial_energy_fails(self):
        with self.assertRaisesRegex(ValueError,'initial pin energy upper'):
            b.prove(initial_energy_bound=F(14,5))

    def test_unjustified_singular_value_fails(self):
        with self.assertRaisesRegex(ValueError,'singular-value lower'):
            b.prove(sv_bound=F(1,5))

    def test_oversized_baseline_floor_fails(self):
        self.fail_cli('check_explicit_floor.py',['--floor','1/3'],
                      'requested H3 floor follows')

    def test_oversized_midpoint_floor_fails(self):
        self.fail_cli('check_midpoint_floor.py',['--floor','9/5'],
                      'requested uniform H3 coefficient is proved')

    def test_understated_axial_gaussian_tail_fails(self):
        with self.assertRaisesRegex(ValueError,'axial one-sided Gaussian tail'):
            b.prove(axial_tail_budget=F(1,40))

    def test_understated_difference_tail_fails(self):
        with self.assertRaisesRegex(ValueError,'transverse difference Gaussian tail'):
            b.prove(q_tail_budget=F(1,200))

    def test_overstated_marginal_probability_fails(self):
        with self.assertRaisesRegex(ValueError,'actual transverse Gaussian marginal'):
            b.prove(q_marginal_floor=F(3,5))

    def test_missing_beta_squared_kernel_mass_fails(self):
        with self.assertRaisesRegex(ValueError,'beta variance includes'):
            b.prove(beta_variance_factor=F(1,8))

    def test_missing_second_difference_tail_fails(self):
        self.fail_cli('check_midpoint_floor.py',['--difference-tail-factor','1'],
                      'two-sided difference needs both Gaussian tails')

    def test_understated_midpoint_variance_loss_fails(self):
        self.fail_cli('check_midpoint_floor.py',['--variance-loss-factor','0'],
                      'midpoint variance loss includes factor 1/4')

    def test_radius_outside_band_fails(self):
        self.fail_cli('check_midpoint_floor.py',['--radius','1/10'],'radius in (0,1/20]')

    def test_zero_radius_rejected(self):
        with self.assertRaisesRegex(ValueError,'radius in'):
            m.prove(radius=F(0))

    def test_float_and_bool_rejected(self):
        for bad in (0.05,True):
            with self.subTest(bad=bad), self.assertRaisesRegex(ValueError,'exact Fraction'):
                m.prove(radius=bad)

    def test_typed_determinant_lower_inequality_grid(self):
        # This detects determinant-sign and missing-positive-part mutations;
        # the proof treats all real values, not merely this exact grid.
        a,r,d=F(4,5),F(1,20),F(3,25)
        checked=0
        for am in (-2,-1,-a):
            for ass in (a,1,2):
                for qbar in (-3,-1,-d,F(1)):
                    for delta in (-2*d,F(0),2*d):
                        qm,qs=qbar-delta/2,qbar+delta/2
                        t=max(F(0),-qbar-d)
                        for bm in (F(0),F(1),F(5)):
                            for bs in (F(0),F(2)):
                                dm=am*qm-r*bm**2; ds=ass*qs-r*bs**2
                                actual=abs(dm*ds) if am<0 and dm>0 and ds<0 else F(0)
                                lower=a*t*max(F(0),a*t-r*bm**2)
                                self.assertGreaterEqual(actual,lower)
                                checked+=1
        self.assertEqual(checked,648)

    def test_absolute_value_cannot_replace_typed_positive_part(self):
        a,r,beta=F(4,5),F(1,20),F(5)
        dm=a-r*beta**2
        self.assertLess(dm,0)
        actual_typed=F(0)
        incorrect=a*abs(dm)
        correct=a*max(F(0),dm)
        self.assertGreater(incorrect,actual_typed)
        self.assertEqual(correct,actual_typed)

    def test_midpoint_difference_independence_needs_equal_endpoint_variances(self):
        cov=lambda va,vb,c:(vb-va)/2
        self.assertEqual(cov(F(2),F(2),F(1,3)),0)
        self.assertNotEqual(cov(F(1),F(2),F(1,3)),0)

    def test_regression_second_moment_factor_needs_energy(self):
        # V standard normal, R=V, condition V=3: E[R²|V=3]=9, not Var(R)=1.
        variance,energy,conditional_second=F(1),F(9),F(9)
        self.assertGreater(conditional_second,variance)
        self.assertLessEqual(conditional_second,max(F(1),energy)*variance)

    def test_source_exclusion_precedes_archive_read(self):
        with tempfile.TemporaryDirectory(dir=HERE) as temp:
            root=Path(temp);(root/'quarantine').mkdir()
            (root/'quarantine/EXCLUSIONS.json').write_text(json.dumps({'exclusions':[
                {'payload_sha256':b.h.MEMBER_SHA}]}))
            with patch.object(b.h,'REPO',root),self.assertRaisesRegex(ValueError,'logically excluded'):
                b.h.custody()

    def test_source_archive_hash_drift_fails(self):
        with tempfile.TemporaryDirectory(dir=HERE) as temp:
            root=Path(temp);(root/'quarantine').mkdir()
            (root/'quarantine/EXCLUSIONS.json').write_text('{"exclusions":[]}')
            archive=root/b.h.ARCHIVE;archive.parent.mkdir(parents=True);archive.write_bytes(b'wrong')
            with patch.object(b.h,'REPO',root),self.assertRaisesRegex(ValueError,'archive SHA'):
                b.h.custody()

    def test_rehashed_false_floor_report_rejected(self):
        with tempfile.TemporaryDirectory(dir=HERE) as temp:
            changed=copy.deepcopy(self.report)
            changed['payload']['conclusion']['coefficient']='2'
            changed['payload_sha256']=m.digest(m.canonical(changed['payload']).encode())
            path=Path(temp)/'candidate.json';path.write_text(json.dumps(changed))
            self.fail_cli('check_midpoint_floor.py',['--verify',path],'fully recomputed typed report')

    def test_rehashed_missing_scope_rejected(self):
        with tempfile.TemporaryDirectory(dir=HERE) as temp:
            changed=copy.deepcopy(self.report);changed['payload']['remaining']=[]
            changed['payload_sha256']=m.digest(m.canonical(changed['payload']).encode())
            path=Path(temp)/'candidate.json';path.write_text(json.dumps(changed))
            self.fail_cli('check_midpoint_floor.py',['--verify',path],'fully recomputed typed report')

    def test_output_overwrite_rejected_and_existing_retained(self):
        with tempfile.TemporaryDirectory(dir=HERE) as temp:
            path=Path(temp)/'existing.json';path.write_bytes(b'keep')
            self.fail_cli('check_midpoint_floor.py',['--output',path],'File exists')
            self.assertEqual(path.read_bytes(),b'keep')

    def test_repository_output_rejected(self):
        self.fail_cli('check_midpoint_floor.py',['--output',b.h.REPO/'must-not-write-h3.json'],
                      'outside read-only repository')

    def test_normal_and_optimized_replays_byte_identical(self):
        with tempfile.TemporaryDirectory(dir=HERE) as temp:
            for script,result in [('check_explicit_floor.py','result.json'),
                                  ('check_midpoint_floor.py','result_midpoint.json')]:
                paths=[]
                for optimized in (False,True):
                    path=Path(temp)/(script+str(optimized)+'.json');paths.append(path)
                    run=self.cli(script,['--verify',HERE/result,'--output',path],optimized=optimized)
                    self.assertEqual(run.returncode,0,run.stderr)
                self.assertEqual(paths[0].read_bytes(),paths[1].read_bytes())
                self.assertEqual(paths[0].read_bytes(),(HERE/result).read_bytes())


if __name__=='__main__':
    unittest.main(verbosity=2)
