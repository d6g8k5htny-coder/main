"""Replay frozen mathematical candidates without promoting any obligation.

Inputs are pinned before and after five explicit jobs in both Python modes.
Every newly emitted report/witness must reproduce the retained bytes.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

def need(ok,message):
    if not ok:raise ValueError(message)

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def child(root,name):
    p=Path(name)
    need(not p.is_absolute() and '..' not in p.parts,'unsafe relative input path')
    q=(root/p).resolve()
    need(q.is_relative_to(root.resolve()) and q.is_file(),'input missing or escapes root')
    return q

def pins(root,records):
    need(isinstance(records,list) and len(records)>0,'empty or invalid input identity list')
    need(len({r['path'] for r in records})==len(records),'duplicate input identity')
    for r in records:
        p=child(root,r['path'])
        need(p.stat().st_size==r['bytes'] and sha(p)==r['sha256'],
             'input identity changed: '+r['path'])

def validate_jobs(bundle,plan):
    expected={
      'h3_baseline':('h3_floor','check_explicit_floor.py','result.json','--verify','--output'),
      'h3_floor':('h3_floor','check_midpoint_floor.py','result_midpoint.json','--verify','--output'),
      'h3_ceiling':('h3_ceiling','check_uniform_ceiling.py','certificate.json','--certificate','--output'),
      'pin_energy':('pin_energy','check_energy.py','result-v2.json','--verify','--write')}
    keys={r['path'] for r in plan['bundle_inputs']}
    need({'verify_closure.py','h3_ceiling/DEPENDENCIES.json',
          'h3_floor/support/check_h3_uniform.py'}<=keys,
         'runner, consumed dependency manifest or executed helper not pinned')
    for job in plan['jobs']:
        name=job['name']
        if name=='rn_n6':
            need(job['project']=='rn_n6','wrong RN project')
            required={'rn_n6/check.py','rn_n6/side24_taylor.py','rn_n6/DEPENDENCIES.json'}
            names={'RUN.json'}|{case+'_'+site+'.json' for case in
                ('original_pilot_admitted','pilot_admitted','x_inner_admitted','y_inner_admitted')
                for site in ('M','S','y')}
            outputs=[{'original':'rn_n6/results_final/'+f,'generated':f} for f in sorted(names)]
        else:
            fields=('project','checker','report','verify_flag','output_flag')
            need(tuple(job[k] for k in fields)==expected[name],'unexpected replay command')
            project,checker,report,_,_=expected[name]
            required={project+'/'+checker,project+'/'+report}
            outputs=[{'original':project+'/'+report,'generated':'report.json'}]
        need(job['outputs']==outputs,'missing, duplicate or unexpected output comparison')
        required.update(x['original'] for x in outputs)
        need(required<=keys,'executed checker or compared report not pinned')
        for path in required:child(bundle,path)
    required_repo=set()
    for record in json.loads(child(bundle,'rn_n6/DEPENDENCIES.json').read_text())['files']:
        required_repo.add(record['path'])
    required_repo.update(json.loads(child(bundle,'h3_ceiling/DEPENDENCIES.json').read_text())['repository_python'])
    required_repo.add('quarantine/EXCLUSIONS.json')
    need(required_repo<={r['path'] for r in plan['repository_inputs']},'repository dependency omitted')

def execute(bundle,repo,out,job,optimized):
    name=job['name'];mode='optimized' if optimized else 'normal'
    dest=out/(name+'-'+mode)
    dest.mkdir()
    project=child(bundle,job['project']+'/'+('check.py' if name=='rn_n6' else job['checker'])).parent
    args=[sys.executable,'-B']+(['-O'] if optimized else [])
    if name=='rn_n6':
        generated=dest/'results'
        args += [str(project/'check.py'),'--repo',str(repo),'--output',str(generated)]
    else:
        generated=dest
        args += [str(project/job['checker']),'--repo',str(repo)]
        args += [job['verify_flag'],str(project/job['report'])]
        args += [job['output_flag'],str(dest/'report.json')]
    started=time.monotonic()
    process=subprocess.run(args,cwd=project,text=True,capture_output=True,timeout=180)
    (dest/'stdout.txt').write_text(process.stdout)
    (dest/'stderr.txt').write_text(process.stderr)
    need(process.returncode==0,f'{name}/{mode} replay failed: {process.stderr[-1500:]}')
    matched=[]
    for expected in job['outputs']:
        original=child(bundle,expected['original'])
        actual=child(generated,expected['generated'])
        need(original.read_bytes()==actual.read_bytes(),f'{name}/{mode} report differs: {actual.name}')
        matched.append({'name':actual.name,'bytes':actual.stat().st_size,'sha256':sha(actual)})
    return {'job':name,'mode':mode,'exit_code':0,'byte_identical_outputs':matched,
            'elapsed_seconds':round(time.monotonic()-started,3),
            'stdout':process.stdout.strip()}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo',required=True,type=Path)
    p.add_argument('--output',type=Path)
    p.add_argument('--validate-only',action='store_true')
    args=p.parse_args()
    bundle=Path(__file__).resolve().parent; repo=args.repo.resolve()
    plan_path=child(bundle,'verification_plan.json')
    plan_sha=sha(plan_path);runner_sha=sha(Path(__file__))
    plan=json.loads(plan_path.read_text())
    need(plan['schema']=='existing-math-replay-plan-v1','wrong plan schema')
    need({j['name'] for j in plan['jobs']}=={'h3_baseline','h3_floor','h3_ceiling','pin_energy','rn_n6'}
         and len(plan['jobs'])==5,'incomplete mathematical replay jobs')
    pins(bundle,plan['bundle_inputs']);pins(repo,plan['repository_inputs'])
    validate_jobs(bundle,plan)
    if args.validate_only:
        print('PASS: all candidate and repository input identities match');return
    need(args.output is not None,'fresh output directory required')
    output=args.output.resolve()
    need(not args.output.exists() and not args.output.is_symlink(),'output already exists')
    need(not output.is_relative_to(repo) and not output.is_relative_to(bundle),
         'outputs must be outside repository and frozen bundle')
    output.mkdir(parents=True)
    with ThreadPoolExecutor(max_workers=3) as pool:
        futures=[pool.submit(execute,bundle,repo,output,j,o) for j in plan['jobs'] for o in (False,True)]
        results=[future.result() for future in futures]
    pins(bundle,plan['bundle_inputs']);pins(repo,plan['repository_inputs'])
    need(sha(plan_path)==plan_sha and sha(Path(__file__))==runner_sha,'plan or runner changed during replay')
    receipt={'schema':'existing-math-replay-receipt-v1','jobs':results,
             'verification_plan_sha256':plan_sha,'runner_sha256':runner_sha,
             'bundle_inputs_unchanged':len(plan['bundle_inputs']),
             'repository_inputs_unchanged':len(plan['repository_inputs']),
             'all_outputs_byte_identical':True,'scientific_status_changed':False,
             'organizational_independence_credit':0,
             'scope':'Exact candidate replay only; no full q0/RN or all-angle closure.'}
    (output/'VERIFICATION.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
    print('PASS: five exact mathematical replays in both modes; all output bytes reproduced; no status promotion')

if __name__=='__main__':
    try:main()
    except (ValueError,OSError,KeyError,TypeError,subprocess.TimeoutExpired) as error:
        print('FAIL: '+str(error),file=sys.stderr);raise SystemExit(1)
