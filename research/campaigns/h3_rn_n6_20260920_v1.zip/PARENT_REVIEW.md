# Parent mathematical review

The parent reviewed the H3 floor, H3 ceiling and RN N6 derivations against the
actual normalized SIDE24 law and their authored implementations. All work is
source-exposed OpenAI work with zero organizational independence credit.
This document is a technical review record; it does not promote a canonical
claim or supply organizationally independent acceptance.

## H3 floor

The covariance transport inequality gives a relative Loewner lower bound,
so its inverse scales in the opposite direction. The parent independently
replayed limiting pin energy by both block inversion and a six-coordinate
LDL solve, obtaining uniform Q<8. Gaussian regression then controls the
means and variances of the axial fourth-derivative remainders.

The processes f(x,0), fy(x,0), and fyy(x,0)+m2 f(x,0) are independent because
their cross covariances vanish at every pair of x coordinates. Conditioning
splits by these processes and preserves the required independence. Within
the transverse process, equal endpoint variances make the midpoint and
difference independent Gaussian variables. No endpoint independence is used.

The parent supplied and independently evaluated the midpoint refinement. On
the axial and small-difference events, the typed determinant product is
bounded below by aT(aT-r B_M²)_+. Replacing the positive part by its argument
is valid, and the resulting expected bracket is proved positive before
probability lower bounds are multiplied. Exact interval evaluation exceeds
17/10 on the entire radius band. The baseline 1/4 proof is retained as a
separate, weaker check, not mislabelled an independent scientific review.

## H3 ceiling

The even and odd axial conditioning blocks match an invertible transform of
the four actual axial pins. Their parity makes the blocks independent.
Signed coefficients with a common radius power are aggregated before interval
evaluation, and negative powers cancel exactly. The positive Fourier measure
bounds every required even kernel derivative uniformly by its zero-distance
spectral moment, which supplies a continuum Taylor remainder.

The typed event implies q_M<0. The proof retains this same halfspace in both
determinant square moments. The M cross term is nonpositive and may be
discarded for an upper bound; the S cross term is bounded in absolute value.
The odd-y pins are zero, giving centered beta variables and Gaussian fourth
moments 3 Var(beta)². The twenty closed radius cells are checked for exact
adjacency and full endpoint coverage. The upper coefficient is below349/100.

## RN N6

The parent inspected the bounded high-order kernel, 51-target lift,
preconditioner, signed polynomial aggregation, Taylor remainder, unwhitening,
mark law and density code. The preconditioner is an exact invertible rational
matrix; its measured covariance is retained. There is no replacement of that
covariance by an identity matrix and no assumption that Hessian sites are
independent. Only the six-pin covariance and the required small marginal
blocks are factored.

Order-seven remainder variances follow from full normalized derivative
moment caps. The conditional mean remainder includes the pin-energy factor.
The covariance remainder uses the polynomial variance before enlargement.
Unwhitening includes A*w(t), and the original density includes the transform
Jacobian exactly once. A proved positive density upper bound is never rounded
to zero when its magnitude is tiny. Positive transformed marginal pivots
give original covariance positivity by an invertible congruence; the proof
does not assert that every independent entry selection from an interval hull
is positive definite.

The four admitted local squares and all three failed larger attempts remain distinct.
Rectangles centered at the inner radius can cross the annulus boundary; they
are local law certificates, not a complete annulus partition. Full RN and
all-small-r closure remain unproved.

The cross-review found that cached exact-argument calls could accept warmed
float or boolean aliases before validation. The author moved validation ahead
of the private cache and added regression tests. The checker now also refuses
existing output directories and outputs inside the source repository, and
verifies dependency identities before importing repository modules. These
repairs do not change the mathematical reports. The scoped reviewer verified
the repaired guards in both Python modes; see `reviews/rn_n6_review.md`.

Fresh final-artifact replay results are recorded separately in
`VERIFICATION.json`; that receipt, rather than this prose alone, records
which frozen outputs were actually reproduced.
