#!/usr/bin/env python3
"""Candidate continuum H3 ceiling; no canonical closure or independence."""
from fractions import Fraction as F
from functools import lru_cache
from math import factorial
from pathlib import Path
import argparse, hashlib, json, sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
DEFAULT_REPO=Path('/Users/dylanroy/Documents/Codex/research-main')
early=argparse.ArgumentParser(add_help=False);early.add_argument('--repo',type=Path,default=DEFAULT_REPO)
REPO=early.parse_known_args()[0].repo.resolve();sys.path.insert(0,str(REPO))
from research.interval import Interval as I,exp,sqrt,Phi,normal_pdf
from research.bands.hermite_gaussian import hermite_coefficients
from research.rn import side24
from research.rn.conditioning import interval_ldlt
BITS,PREC=256,90
RMAX,HEIGHT=F(1,20),F(6,5)
# (coefficient, power of r, x derivative order, location/r)
FVAR=((F(1,2),0,0,F(-1,2)),(F(1,2),0,0,F(1,2)))
DVAR=((-F(1),-1,1,F(-1,2)),(F(1),-1,1,F(1,2)))
GVAR=((F(1,2),0,1,F(-1,2)),(F(1,2),0,1,F(1,2)))
HVAR=((-F(1),-3,0,F(-1,2)),(F(1),-3,0,F(1,2)),(-F(1,2),-2,1,F(-1,2)),(-F(1,2),-2,1,F(1,2)))
EVAR=((F(1,2),-1,2,F(-1,2)),(F(1,2),-1,2,F(1,2)),(F(1),-2,1,F(-1,2)),(-F(1),-2,1,F(1,2)))
OVAR=((-F(1,2),-1,2,F(-1,2)),(F(1,2),-1,2,F(1,2)))
VARS=(FVAR,DVAR,GVAR,HVAR,EVAR,OVAR)

def need(x,m):
    if not x:raise ValueError(m)
def rnd(x):return x.round_out(BITS)
def enc(x):
    if isinstance(x,I):return {'lo':str(x.lo),'hi':str(x.hi)}
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {str(k):enc(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [enc(v) for v in x]
    return x
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def sha(b):return hashlib.sha256(b).hexdigest()

def polynomial(cs,x):
    result=F(0)
    for c in reversed(cs):result=result*x+c
    return result

def moments():
    # Full image tail |j|>=2; successive ratios decrease for j>=2.
    ee=exp(I.exact(-288),PREC)
    def tail(n):
        c=sum(abs(v) for v in hermite_coefficients(n))
        ratio=F(3,2)**n*exp(I.exact(-1440),PREC)
        need(ratio.hi<1,'image tail ratio')
        return (2*c*48**n*exp(I.exact(-1152),PREC)/(1-ratio)).hi
    z=rnd(1+2*ee+I(0,tail(0)));m={0:I.exact(1)}
    for n in range(2,21,2):
        cs=hermite_coefficients(n);t=tail(n)
        m[n]=rnd((-1)**(n//2)*(cs[0]+2*polynomial(cs,F(24))*ee+I(-t,t))/z)
        need(m[n].lo>0,'positive spectral moment')
    return m,z

def series_spec(a,b,cutoff=12):
    da={k-p for _,p,k,_ in a};db={k-p for _,p,k,_ in b}
    need(len(da)==len(db)==1,'homogeneous rescaled jets required')
    degree=next(iter(da))+next(iter(db));e_rem=cutoff+(cutoff+degree)%2
    D=e_rem+degree;need(D%2==0 and D<=20,'even remainder moment available')
    cs={};rem=F(0)
    for ca,pa,ka,ta in a:
        for cb,pb,kb,tb in b:
            J=e_rem-pa-pb;need(J>0,'positive Taylor order')
            n=ka+kb;need(n+J==D,'shared derivative order')
            c=ca*cb*(-1)**kb;t=ta-tb
            for j in range(J):
                e=j+pa+pb
                if (n+j)%2:continue
                cs[e]=cs.get(e,F(0))+c*t**j/F(factorial(j))*(-1)**((n+j)//2)
            rem+=abs(c)*abs(t)**J/F(factorial(J))
    for e,c in cs.items():need(e>=0 or c==0,'uncancelled negative radius power')
    return {e:c for e,c in cs.items() if c},rem,D,e_rem,degree

def covariance(a,b,r,m,cutoff=12,omit_remainder=False):
    cs,rem,D,e_rem,degree=series_spec(a,b,cutoff)
    out=I.exact(0)
    for e,c in cs.items():out=rnd(out+c*m[e+degree]*r**e)
    delta=rem*m[D].hi*r.hi**e_rem
    need(not omit_remainder,'Taylor remainder must be retained')
    return rnd(out+I(-delta,delta)),delta

def block_law(pin,target,values,r,m):
    G=[[covariance(a,b,r,m)[0] for b in pin] for a in pin]
    C=[covariance(target,a,r,m)[0] for a in pin]
    W=covariance(target,target,r,m)[0]
    fac=interval_ldlt(G,round_bits=BITS)
    solved=fac.solve(values)
    mu=rnd(sum((a*b for a,b in zip(C,solved)),I.exact(0)))
    cov_solved=fac.solve(C)
    variance=rnd(W-sum((a*b for a,b in zip(C,cov_solved)),I.exact(0)))
    # Actual covariance is PSD, so a negative lower endpoint may be clipped.
    need(variance.hi>=0,'conditional variance upper nonnegative')
    variance=I(max(F(0),variance.lo),variance.hi)
    return mu,variance,{'pin_covariance':G,'cross':C,'unconditional_variance':W,'pin_pivots':fac.pivots}

def positive(x):return I(max(F(0),x.lo),max(F(0),x.hi))

def verify_moment_coefficients(cross_factor,quartic_factor):
    # Independently expand (alpha*q-r*beta²)^2 in four formal variables.
    determinant={(1,1,0,0):F(1),(0,0,2,1):F(-1)}
    squared={}
    for a,x in determinant.items():
        for b,y in determinant.items():
            index=tuple(i+j for i,j in zip(a,b))
            squared[index]=squared.get(index,F(0))+x*y
    # Gaussian integration by parts gives E[U^n]=(n-1)E[U^(n-2)].
    fourth=F(1)
    for n in (2,4):fourth*=n-1
    need(cross_factor>=abs(squared[(1,1,2,1)]),'cross factor must majorize exact determinant expansion')
    need(quartic_factor>=squared[(0,0,4,2)]*fourth,'beta fourth moment must majorize Gaussian Wick factor')

def evaluate_cell(r,m,cross_factor=F(2),quartic_factor=F(3)):
    verify_moment_coefficients(cross_factor,quartic_factor)
    HEIGHT=F(6,5)
    mean_e,var_e,even=block_law((FVAR,DVAR),EVAR,(HEIGHT-r**3/12,I.exact(0)),r,m)
    mean_o,var_o,odd=block_law((GVAR,HVAR),OVAR,(I.exact(0),I.exact(F(-1,6))),r,m)
    mus=(rnd(mean_e-mean_o),rnd(mean_e+mean_o));va=rnd(var_e+var_o)
    means_q=(-HEIGHT*m[2],-(HEIGHT-r**3/6)*m[2]);vq=rnd(m[4]-m[2]**2)
    sigma=rnd(sqrt(vq,PREC));h=rnd(-means_q[0]/sigma)
    prob=rnd(Phi(h,PREC));phi=rnd(normal_pdf(h,PREC))
    h1=rnd(means_q[0]*prob-sigma*phi)
    h2=rnd((vq+means_q[0]**2)*prob-means_q[0]*sigma*phi)
    q_increment=rnd(m[2]*r**3/6+sqrt(vq*m[2],PREC)*r)
    qs2=rnd((sqrt(h2,PREC)+q_increment)**2)
    vb=rnd(m[4]*m[2]/4)
    second_a=[rnd(mu**2+va) for mu in mus]
    need(mus[0].hi<0 and mus[1].lo>0 and h1.hi<0,'cross-sign proof')
    squareM=rnd(second_a[0]*h2+quartic_factor*r**2*vb**2*prob)
    squareS=rnd(second_a[1]*qs2+cross_factor*r*mus[1]*vb*sqrt(qs2*prob,PREC)+quartic_factor*r**2*vb**2*prob)
    coefficient=rnd(sqrt(squareM*squareS,PREC))
    return {'radius':r,'even':even,'odd':odd,'mean_E':mean_e,'variance_E':var_e,'mean_O':mean_o,'variance_O':var_o,'alpha_means':mus,'alpha_variance':va,'alpha_second_moments':second_a,'transverse_mean_M':means_q[0],'transverse_variance':vq,'transverse_halfspace_first_moment_M':h1,'transverse_halfspace_second_moments':(h2,qs2),'beta_variance_upper':vb,'q_increment_L2_upper':q_increment,'determinant_square_upper':(squareM,squareS),'ceiling_interval':coefficient}

def source_binding():
    exclusions=json.loads((REPO/'quarantine/EXCLUSIONS.json').read_text())['exclusions']
    for member,digest in side24.MEMBERS.items():
        need(not any(e.get('payload_sha256')==digest or e.get('member_path')==member for e in exclusions),'excluded source member')
    binding=side24.source_binding()
    return {'kernel':binding,'imported_scope':'normalized field kernel only; variable-r six-pin argument derived here','historical_code_executed':False,'quarantine_metadata_sha256':sha((REPO/'quarantine/EXCLUSIONS.json').read_bytes())}

def dependencies():
    result={}
    for module in tuple(sys.modules.values()):
        name=getattr(module,'__file__',None)
        if not name:continue
        path=Path(name).resolve()
        if path.suffix=='.py' and path.is_relative_to(REPO):
            b=path.read_bytes();result[str(path.relative_to(REPO))]={'bytes':len(b),'sha256':sha(b)}
    return dict(sorted(result.items()))

def validate_cover(cells):
    need(cells and cells[0].lo==0 and cells[-1].hi==RMAX,'complete radius endpoints')
    for i,c in enumerate(cells):
        need(c.lo<c.hi,'positive cell width')
        if i:need(cells[i-1].hi==c.lo,'gap-free nonoverlapping closed radius cells')

def apply_coordinate(coordinate,degree,r):
    value=F(0)
    for c,p,k,t in coordinate:
        if degree>=k:value+=c*r**p*F(factorial(degree),factorial(degree-k))*(t*r)**(degree-k)
    return value

def verify_basis(hsign=1):
    # Algebraic checks on enough monomials to detect wrong endpoint signs.
    # General smooth-field identities are proved analytically in PROOF.md.
    r=F(1,20)
    for n in range(9):
        v=[apply_coordinate(c,n,r) for c in VARS]
        FM,FS=(-r/2)**n,(r/2)**n
        dx=lambda x: F(0) if n==0 else n*x**(n-1)
        dxx=lambda x:F(0) if n<2 else n*(n-1)*x**(n-2)
        need(v[0]==(FM+FS)/2 and v[1]==(dx(r/2)-dx(-r/2))/r,'even pin identities')
        need(v[2]==(dx(r/2)+dx(-r/2))/2,'odd first pin identity')
        need(hsign*v[3]==(FS-FM)/r**3-(dx(r/2)+dx(-r/2))/(2*r**2),'cubic pin sign')
        need(v[4]-v[5]+v[1]/r==dxx(-r/2)/r and v[4]+v[5]+v[1]/r==dxx(r/2)/r,'alpha reconstruction')
    need(apply_coordinate(HVAR,3,r)==-F(1,2),'cubic pin scaling')

def evaluate(cap=F(349,100),mutation=None):
    need(type(cap)is F and cap>0,'positive exact cap')
    before=dependencies()
    binding=source_binding();m,z=moments()
    cross_factor=F(1) if mutation=='wrong_cross_factor' else F(2)
    quartic_factor=F(2) if mutation=='wrong_beta_fourth' else F(3)
    cells=[evaluate_cell(I(F(j,400),F(j+1,400)),m,cross_factor,quartic_factor) for j in range(20)]
    if mutation=='missing_cell':cells.pop(10)
    validate_cover([c['radius'] for c in cells])
    if mutation=='omit_remainder':covariance(HVAR,HVAR,I(0,RMAX),m,omit_remainder=True)
    if mutation=='wrong_H_sign':verify_basis(-1)
    verify_basis()
    upper=max(c['ceiling_interval'].hi for c in cells)
    if mutation=='too_small_cap':cap=F(3)
    need(upper<=cap,'computed ceiling exceeds requested cap')
    need(dependencies()==before,'repository dependency bytes changed during run')
    need(source_binding()==binding,'bound source bytes changed during run')
    return enc({'schema':'H3_UNIFORM_CEILING_V1','target':'Q0-H3-CEILING-UNIFORM-20260920-v1','claim_id':'93f76505-2fdb-413e-8b75-11ffd9cff294','status':'PROVED_CANDIDATE','domain':{'radius':'0<r<=1/20','height':HEIGHT,'dimension':2,'side':24,'orientation':'fixed x axis'},'source_binding':binding,'repository_dependencies':before,'checker_sha256':sha(Path(__file__).read_bytes()),'moments':m,'normalizer':z,'cells':cells,'ceiling_upper':upper,'cap':cap,'uniform_radius':True,'scientific_status_changed':False,'original_prize_closed':False,'external_independence_credit':0,'does_not_establish':['All-angle bound, full q0 theorem, RN closure, event transfer, canonical promotion, external independence.']})

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,default=REPO);p.add_argument('--output',type=Path);p.add_argument('--certificate',type=Path);p.add_argument('--cap',type=F,default=F(349,100));p.add_argument('--mutation',choices=('too_small_cap','missing_cell','omit_remainder','wrong_H_sign','wrong_cross_factor','wrong_beta_fourth'));args=p.parse_args()
    try:
        result=evaluate(args.cap,args.mutation)
        if args.certificate:need(canon(json.loads(args.certificate.read_text()))==canon(result),'fresh certificate equality')
        if args.output:
            need(not args.output.resolve().is_relative_to(REPO),'output outside repository')
            with args.output.open('x')as f:f.write(json.dumps(result,sort_keys=True,indent=2)+'\n')
        print('PASS: H3 uniform ceiling '+str(result['cap'])+' on (0,1/20]; candidate only')
    except (ValueError,OSError,KeyError,TypeError) as e:
        print('FAIL: '+str(e),file=sys.stderr);sys.exit(1)
