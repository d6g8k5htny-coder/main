"""Identity, independent kernel, continuum coverage, and adversarial tests."""
import copy, importlib.util, json, subprocess, sys, tempfile, unittest
from fractions import Fraction as F
from pathlib import Path
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('uniform_ceiling',HERE/'check_uniform_ceiling.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
I=c.I

class MathTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.m,cls.z=c.moments()
    def test_gaussian_fourth_factor_falsifier(self):
        c.verify_moment_coefficients(F(2),F(3))
        with self.assertRaisesRegex(ValueError,'fourth moment'):c.verify_moment_coefficients(F(2),F(2))
    def test_missing_cross_factor_falsifier(self):
        with self.assertRaisesRegex(ValueError,'cross factor'):c.verify_moment_coefficients(F(1),F(3))
    def test_exact_pin_and_target_identities(self):c.verify_basis()
    def test_cubic_sign_falsifier(self):
        with self.assertRaisesRegex(ValueError,'cubic pin sign'):c.verify_basis(-1)
    def test_limiting_covariance_blocks(self):
        # Actual periodized m's, not substituted unperiodized integers.
        expected={(0,0):self.m[0],(0,1):-self.m[2],(1,1):self.m[4],
                  (2,2):self.m[2],(2,3):self.m[4]/12,(3,3):self.m[6]/144,
                  (4,4):I.exact(0),(5,5):self.m[6]/4,(3,5):-self.m[6]/24}
        for (a,b),target in expected.items():
            got,_=c.covariance(c.VARS[a],c.VARS[b],I.exact(0),self.m)
            self.assertIsNotNone(got.intersect(target),(a,b))
    def test_exact_zero_parity_cross_blocks(self):
        for a in (c.FVAR,c.DVAR,c.EVAR):
            for b in (c.GVAR,c.HVAR,c.OVAR):
                cs,rem,*_=c.series_spec(a,b)
                self.assertEqual(cs,{})
                # Independent analytic reflection establishes exact zero;
                # this series routine retains a harmless positive remainder.
    def test_all_negative_powers_cancel(self):
        for a in c.VARS:
            for b in c.VARS:
                cs,_,_,_,_=c.series_spec(a,b)
                self.assertTrue(all(e>=0 for e in cs))
    def test_bad_coordinate_negative_power_rejected(self):
        bad=((F(1),-1,0,F(1,2)),)
        with self.assertRaisesRegex(ValueError,'negative radius'):c.series_spec(bad,bad)
    def test_direct_kernel_independent_path(self):
        # A finite test of implementation, not the continuum proof.
        for r in (F(1,20),F(1,37)):
            for ai in range(6):
                for bi in range(ai+1):
                    a,b=c.VARS[ai],c.VARS[bi];direct=I.exact(0)
                    for ca,pa,ka,ta in a:
                        for cb,pb,kb,tb in b:
                            value=c.side24.kernel_derivative(ka+kb,(ta-tb)*r,prec=100,bits=256)
                            direct=c.rnd(direct+ca*cb*r**(pa+pb)*(-1)**kb*value)
                    series,_=c.covariance(a,b,I.exact(r),self.m)
                    self.assertIsNotNone(series.intersect(direct),(r,ai,bi))
    def test_covariance_symmetry(self):
        r=I(F(1,100),F(1,80))
        for a in c.VARS:
            for b in c.VARS:self.assertEqual(c.covariance(a,b,r,self.m),c.covariance(b,a,r,self.m))
    def test_missing_remainder_rejected(self):
        with self.assertRaisesRegex(ValueError,'remainder'):c.covariance(c.HVAR,c.HVAR,I(0,c.RMAX),self.m,omit_remainder=True)
    def test_entire_cell_coverage(self):c.validate_cover([I(F(j,400),F(j+1,400)) for j in range(20)])
    def test_gap_rejected(self):
        cells=[I(F(j,400),F(j+1,400)) for j in range(20)];cells.pop(5)
        with self.assertRaisesRegex(ValueError,'gap-free'):c.validate_cover(cells)
    def test_wrong_endpoint_rejected(self):
        with self.assertRaisesRegex(ValueError,'endpoints'):c.validate_cover([I(F(1,400),F(1,20))])
    def test_float_cap_refused(self):
        with self.assertRaisesRegex(ValueError,'exact cap'):c.evaluate(3.49)
    def test_zero_limit_alpha_means(self):
        got=c.evaluate_cell(I.exact(0),self.m)
        self.assertIn(F(-1),got['alpha_means'][0]);self.assertIn(F(1),got['alpha_means'][1])
        self.assertIn(F(0),got['alpha_variance'])
    def test_actual_cell_signs_and_positive_upper(self):
        got=c.evaluate_cell(I(F(19,400),F(1,20)),self.m)
        self.assertLess(got['alpha_means'][0].hi,0);self.assertGreater(got['alpha_means'][1].lo,0)
        self.assertLess(got['ceiling_interval'].hi,F(349,100))
        self.assertGreater(got['ceiling_interval'].lo,3)

class CLITests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory(prefix='tests-',dir=HERE);cls.folder=Path(cls.temp.name);cls.seq=0
        cls.baseline=json.loads((HERE/'certificate.json').read_text())
    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()
    def run_cli(self,*args):
        type(self).seq+=1;out=self.folder/f'out-{self.seq}.json'
        # unittest itself runs in both modes; propagate optimized mode.
        argv=[sys.executable,'-B']+(['-O'] if sys.flags.optimize else [])+[str(HERE/'check_uniform_ceiling.py'),'--output',str(out),*args]
        result=subprocess.run(argv,text=True,capture_output=True)
        return result,out
    def test_exact_report_replay(self):
        r,out=self.run_cli('--certificate',str(HERE/'certificate.json'))
        self.assertEqual(r.returncode,0,r.stderr);self.assertEqual(out.read_bytes(),(HERE/'certificate.json').read_bytes())
    def test_real_negative_mutations(self):
        for flag in ('too_small_cap','missing_cell','omit_remainder','wrong_H_sign','wrong_cross_factor','wrong_beta_fourth'):
            r,out=self.run_cli('--mutation',flag)
            self.assertNotEqual(r.returncode,0,flag);self.assertFalse(out.exists());self.assertIn('FAIL',r.stderr)
    def test_forged_mathematical_bound(self):
        data=copy.deepcopy(self.baseline);data['cap']='3'
        p=self.folder/'forged-bound.json';p.write_text(json.dumps(data))
        r,out=self.run_cli('--certificate',str(p));self.assertNotEqual(r.returncode,0);self.assertFalse(out.exists())
    def test_status_bool_integer_alias_rejected(self):
        data=copy.deepcopy(self.baseline);data['scientific_status_changed']=0
        p=self.folder/'forged-status.json';p.write_text(json.dumps(data))
        r,out=self.run_cli('--certificate',str(p));self.assertNotEqual(r.returncode,0);self.assertFalse(out.exists())
    def test_false_independence_rejected(self):
        data=copy.deepcopy(self.baseline);data['external_independence_credit']=1
        p=self.folder/'forged-independence.json';p.write_text(json.dumps(data))
        r,out=self.run_cli('--certificate',str(p));self.assertNotEqual(r.returncode,0);self.assertFalse(out.exists())
    def test_report_overwrite_refused(self):
        p=self.folder/'exists.json';p.write_text('sentinel')
        r=subprocess.run([sys.executable,'-B',str(HERE/'check_uniform_ceiling.py'),'--output',str(p)],text=True,capture_output=True)
        self.assertNotEqual(r.returncode,0);self.assertEqual(p.read_text(),'sentinel')
    def test_output_inside_repo_refused(self):
        r=subprocess.run([sys.executable,'-B',str(HERE/'check_uniform_ceiling.py'),'--output',str(c.REPO/'nonexistent-uniform-ceiling-output.json')],text=True,capture_output=True)
        self.assertNotEqual(r.returncode,0);self.assertIn('outside repository',r.stderr)

if __name__=='__main__':unittest.main()
