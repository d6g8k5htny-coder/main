# Uniform fixed-axis H3 ceiling on the full radius interval

Author-side candidate, 2026-09-20. Target `Q0-H3-CEILING-UNIFORM-20260920-v1`,
R17 claim `93f76505-2fdb-413e-8b75-11ffd9cff294`. Organizational independence
credit is zero; no canonical status is changed.

For the normalized SIDE24 field, the fixed x axis, height `b=6/5`, and the
six observations

\[
(f_M,f_{x,M},f_{y,M},f_S,f_{x,S},f_{y,S})
=(b,0,0,b-r^3/6,0,0),\qquad M=(-r/2,0),\ S=(r/2,0),
\]

this candidate proves the explicit continuum bound

\[
\boxed{0\le Z_r\le \frac{349}{100}r^2\quad(0<r\le1/20).}
\]

Here `Z_r` is the expectation of `|det H_M det H_S|` times maximum typing at
M and saddle typing at S under that six-pin Gaussian conditional law.
This improves the coefficient `3.74767948915996` used in the historical
uniform ceiling at the same fixed-axis scope. It does not replay the
historical proof, inherit its status, or assert a bound for other angles.

The previous P02 candidate supplied a sharper coefficient at the single
radius `1/20`; this successor supplies one explicit bound at **every** radius
in the interval. Its numerical certificate consists of twenty closed radius
cells covering `[0,1/20]`, not twenty samples. The removable endpoint zero
is used only for interval calculation; the theorem concerns positive radii.

## Independent Gaussian sectors

Put `F(x)=f(x,0)`, `Y(x)=f_y(x,0)`, and
`e(x)=f_yy(x,0)+m2 F(x)`, where `m2=-k''(0)`. The covariance is

\[
K(x,y)=k(x)k(y),\qquad
k(t)=\frac{\sum_{j\in\mathbb Z}e^{-(t+24j)^2/2}}
{\sum_{j\in\mathbb Z}e^{-(24j)^2/2}}.
\]

Separability and the vanishing odd derivatives of k at zero imply that F,
Y, and e are mutually independent centered Gaussian processes on the x axis.
Their covariance kernels are respectively `k`, `m2 k`, and `(m4-m2²)k`, with
`m4=k''''(0)`. The six pins condition F and Y separately and leave e
independent. Thus

\[
q_M=f_{yy}(M)=-b m_2+e(M),\quad
q_S=-m_2(b-r^3/6)+e(S),\quad v_q=m_4-m_2^2>0.
\]

The axial variables `alpha_i=f_xx(i)/r` depend only on conditioned F; the
variables `beta_i=f_xy(i)/r` depend only on conditioned Y. Therefore the
alpha pair, beta pair, and q pair are independent under the conditional law.
This independence concerns the three pairs, not the two sites in a pair.

The Fourier coefficients of the periodized Gaussian are positive multiples
of `exp(-(2*pi*n/24)^2/2)`. Consequently all joint derivative covariances are
positive semidefinite, `|k(r)|<1` for `0<r<24`, and the two Y pins are
nondegenerate. The axial conditioning blocks below have certified positive
LDL pivots at every radius. Thus the six-pin conditional law exists
throughout the stated open-at-zero domain.

## Nonsingular axial coordinates

Use the even pair of conditioning variables

\[
F_+=(F(M)+F(S))/2,\qquad D=(F'(S)-F'(M))/r
\]

and the odd pair

\[
G=(F'(M)+F'(S))/2,\qquad
H=(F(S)-F(M))/r^3-(F'(S)+F'(M))/(2r^2).
\]

Their conditioning values are `(b-r³/12,0)` and `(0,-1/6)`. Reflection in
x makes the two pairs independent. The transform from the four raw F pins
is invertible for positive r: recover `F'(M)=G-rD/2`, `F'(S)=G+rD/2`,
`F(S)-F(M)=r³H+rG`, and use their mean `F_+`.

For targets use

\[
E=\frac{F''(M)+F''(S)-2D}{2r},\qquad
O=\frac{F''(S)-F''(M)}{2r}.
\]

E is even and O odd, hence independent after conditioning; since D is
pinned to zero, `alpha_M=E-O` and `alpha_S=E+O`. Conditional means and
variances of E and O follow from separate 2-by-2 Gaussian regressions.
For each cell the checker encloses the covariance blocks G, cross row C,
and target variance W, certifies positive interval LDL pivots, and evaluates

\[
\mu=C G^{-1}v,\qquad s^2=W-CG^{-1}C^T.
\]

A negative *lower interval endpoint* for s² is clipped to zero using positive
semidefiniteness of the actual Gaussian conditional law. The upper endpoint
is never clipped downward. It follows that
`E[alpha_i²]=mu_i²+s_E²+s_O²`. The checker proves `mu_M<0` and `mu_S>0`
on every cell. These signs are used in the determinant estimate below.

## Cancellation-free covariance series and a continuum remainder

A rescaled coordinate is stored as a finite sum of terms
`c r^p F^(a)(t r)`, where `t` is `-1/2` or `1/2`. All terms of each
coordinate have the same integer degree `d=a-p`. For two coordinates with
degrees d1,d2, a covariance term is

\[
c_1c_2(-1)^{a_2}r^{p_1+p_2}
 k^{(a_1+a_2)}((t_1-t_2)r).
\]

Choose `e_rem=12` or `13` so `D=e_rem+d1+d2` is even. Apply Taylor's theorem
to this kernel derivative through order `J-1`, where
`J=e_rem-p1-p2`; then the derivative order in the remainder is exactly D.
All covariance entries needed here have `D<=20`.

With the positive Fourier law, `m_D=E[omega^D]` for even D, so
`sup_x |k^(D)(x)| <= m_D`. Taylor's theorem gives the **full** remainder
bound

\[
\left|R_{12}(r)\right|\le
 m_D r^{e_{rem}}\sum_{\text{term pairs}}
 \frac{|c_1c_2|\,|t_1-t_2|^J}{J!}.
\]

This holds simultaneously for every r in a cell. Its endpoints are added
as a symmetric interval. The checker refuses an omitted remainder.

For each exponent e, all retained terms contain the *same* derivative
`k^(e+d1+d2)(0)`. The rational coefficients are collected **before**
multiplication by its interval. Every negative power of r cancels exactly;
the checker rejects any uncancelled negative-power coefficient. Thus there
is no interval division by r, even in the first cell containing zero.
Odd derivative coefficients vanish exactly. Even coefficients use
`k^(2a)(0)=(-1)^a m_(2a)` with the correct derivative sign at the second
endpoint.

The resulting polynomial and its remainder are evaluated by inclusion
interval operations on each of the twenty exact cells
`[j/400,(j+1)/400]`, j=0,...,19. The checker verifies the endpoints, positive
widths, and adjacent equality; missing a cell fails the coverage gate.

## Full periodized moments

For n even, the unnormalized derivative at zero is computed using the
Hermite polynomial `He_n`:

\[
He_n(0)+2 He_n(24)e^{-288}+\text{signed omitted tail}.
\]

If `C_n` is the sum of absolute Hermite coefficients, then
`|He_n(u)|<=C_n u^n` for u>=1. For omitted image pairs j>=2, the initial
majorant is `2 C_n 48^n e^-1152` and the consecutive ratio is at most
`(3/2)^n e^-1440<1`; later ratios decrease. Therefore the omitted absolute
sum is at most

\[
\frac{2 C_n48^n e^{-1152}}{1-(3/2)^n e^{-1440}}.
\]

The denominator retains the corresponding entire positive order-zero tail.
After normalization the derivative is multiplied by `(-1)^(n/2)` to obtain
m_n. All moments through order 20 are enclosed with exact rational interval
arithmetic. No ordinary floating-point conversion is used. Repository exp,
sqrt, Phi, and normal_pdf provide the transcendental enclosures, and
outward rounding is to 256 binary bits.

## Determinant bound and the correct typed halfspace

Write `D_i=alpha_i q_i-r beta_i²`. Then `det H_i=rD_i`, and maximum/saddle
typing is `T={q_M<0,D_M>0,D_S<0}`. In particular **T only implies q_M<0**;
we never replace that event by `q_S<0`.

Let A be `{q_M<0}`. Nonnegativity and Cauchy–Schwarz give

\[
Z_r/r^2\le\sqrt{E[D_M^2 1_A]E[D_S^2 1_A]}.
\]

Set mu=-b*m2, sigma²=vq, h=-mu/sigma. The exact scalar halfspace moments are

\[
P=\Phi(h),\quad H_1=\mu P-\sigma\phi(h)<0,\quad
H_2=(v_q+\mu^2)P-\mu\sigma\phi(h).
\]

For S, stationarity and the fundamental theorem in Gaussian L² imply
`||e(S)-e(M)||2 <= r sqrt(vq*m2)`. The triangle inequality, including the
conditional deterministic drift, gives

\[
L= m_2r^3/6+r\sqrt{v_qm_2},\qquad
E[q_S^2 1_A]\le H_S=(\sqrt{H_2}+L)^2.
\]

For beta, conditioning `Y(M)=Y(S)=0` identifies

\[
\beta_M=-\int_{-1/2}^{1/2}(1/2-t)Y''(rt)dt,\qquad
\beta_S= \int_{-1/2}^{1/2}(1/2+t)Y''(rt)dt.
\]

Each weight has absolute integral 1/2. Since `Var(Y'')=m4*m2`, Minkowski and
the fact that Gaussian conditioning decreases variance imply
`v_beta_i<=B=m4*m2/4`. Their conditional means are zero, so the fourth
moments are `3v_beta_i²<=3B²`.

Independence of the three sectors gives, with `a_i=E[alpha_i²]`,

\[
E[D_i^2 1_A]=a_iE[q_i^2 1_A]
 -2r\mu_i v_{\beta_i}E[q_i1_A]+3r^2v_{\beta_i}^2P.
\]

For M the cross term is nonpositive because both mu_M and H1 are negative;
discard it for an upper bound. For S, use
`|E[q_S1_A]|<=sqrt(H_S P)`. Thus safe upper bounds are

\[
U_M=a_MH_2+3r^2B^2P,\qquad
U_S=a_SH_S+2r\mu_SB\sqrt{H_SP}+3r^2B^2P.
\]

Every factor used in these bounds is enclosed on the same full radius cell;
no monotonicity in r is presumed. The final interval calculation certifies
`sqrt(U_M U_S)<349/100` on all twenty cells. The largest upward endpoint is
less than the exact rational `3488355/1000000=3.488355`; the published
coefficient 349/100 leaves additional slack. The complete rational endpoints
and positive pivot bounds are in `certificate.json`.

## Scope and reproduction

`check_uniform_ceiling.py` regenerates the entire certificate. It rechecks
the RN5 field carrier identities, refuses excluded member paths/hashes,
records all loaded repository Python dependency hashes, and verifies those
bytes are unchanged after calculation. Source archive members are hashed,
never executed. The source adapter's original fixed-radius scope is retained
in provenance; only its normalized kernel is imported, and this note supplies
the variable-radius derivation.

`RUN.json` lists exact replay and normal/optimized test commands. Tests include
comparison against the repository's independently implemented direct kernel
at rational nonzero radii, explicit zero-limit covariance identities, pin
and target transform identities, covariance symmetry, full interval coverage,
a missing cell, a false cubic-pin sign, an omitted remainder, altered cross
and Gaussian fourth-moment factors, a cap below
the limiting coefficient, and forged report/status mutations. Report replay
compares typed canonical JSON, so `false` and `0` cannot be interchanged.

This candidate does not establish the all-angle upper band, a lower H3 band,
the full 24-jet definitions, RN near-annulus closure, elder/adjacency event
transfer, the full q0 theorem, any 3D composition, canonical promotion,
external independence, or an original prize closure. Ordinary mathematical
review of this new proof and the interval implementation remains required.
