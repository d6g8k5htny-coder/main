# Explicit two-sided H3 bound on the whole fixed-axis radius band

For the normalized two-dimensional SIDE24 periodized Gaussian field, let
M=(-r/2,0), S=(r/2,0), and condition on

    f(M)=6/5, f(S)=6/5-r³/6, ∇f(M)=∇f(S)=0.

Define Z(r) as the conditional expectation of |det H_M det H_S| multiplied
by the indicator that M is a maximum and S is a saddle. The two new proofs
establish, on the same law and event,

    (17/10) r² <= Z(r) <= (349/100) r²,    for every 0<r<=1/20.

Both statements cover a continuum of radii. The lower proof uses Gaussian
sector independence, a uniform bound on the energy of the conditioning
values, fourth-derivative integral remainders, and independent transverse
midpoint/difference variables. The upper proof uses cancellation-free
covariance polynomials with proved remainders on twenty complete radius
intervals, Gaussian regression, and restricted determinant second moments.
Neither conclusion is inferred from point sampling or fitted exponents.

Since the lower bound is positive, the same theorem also gives the exact
reciprocal bracket

    100/(349 r²) <= 1/Z(r) <= 10/(17 r²).

The Gaussian conditioning law itself is nonsingular throughout this band;
the separately checked energy bound is vᵀG(r)⁻¹v<=1266466/160083<8 for the
cancellation-free six-pin vector v=(6/5,0,0,0,0,-1/6).

The lower and upper proofs are in `h3_floor/PROOF.md` and
`h3_ceiling/PROOF.md`. Their exact source identities, interval certificates
and checker instructions accompany them. `pin_energy/PROOF_v2.md` records
the separately replayed energy estimate. All numerical proof operations use
exact rational intervals, including complete image tails and normalization.

This resolves the preceding candidates' missing explicit radius in the H3
lower-bound argument and missing continuum extension in the H3 upper-bound
argument, at the stated fixed-axis scope. It does not establish an all-angle
bound, the full 24-jet chart, the complete RN spatial integral, transfer
between elder pairing and branch adjacency, or the full q0 theorem. The
previous stronger fixed-radius bounds remain separate. No existing RN budget
is changed by silently substituting these coefficients. Canonical scientific
status is unchanged; external review remains open and same-provider
organizational independence credit is zero.
