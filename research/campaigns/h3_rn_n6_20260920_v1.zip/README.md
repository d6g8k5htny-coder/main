# Existing mathematical closure: H3 band and RN N6

This successor resolves the two existing H3 candidate gaps at their stated
fixed-axis scope and implements the previously designed degree-six RN
transport. It contains exact proofs, executable certificates and retained
failure cases. It is source-exposed author work, with external acceptance
still open and zero organizational independence credit.

## Results

For the normalized two-dimensional SIDE24 field, height 6/5 and the actual
six-pin fixed-x-axis maximum/saddle law,

\[
\frac{17}{10}r^2\le Z(r)\le\frac{349}{100}r^2,
\qquad 0<r\le\frac1{20}.
\]

These are continuum bounds, with complete kernel normalization and image
tails. The previous lower candidate lacked an explicit positive radius; the
previous upper candidate was limited to one radius. Both gaps are resolved
here. The exact lower coefficient exceeds 1.7051902641 and the upper is below
3.488355 before rounding outward to the displayed rational constants.
See [the combined theorem](H3_BAND_THEOREM.md) and both H3 proof folders.
The companion calculation establishes pin energy at most
1266466/160083 < 8 on the same band.

The RN N6 successor certifies four whole squares at r=1/20 and the full
centered mark interval. On the original pilot, its integrand upper drops
from approximately 5.589e-6 to below 3.81e-6, an improvement exceeding 30%.
The larger pilot has 200 times the original half-width and a whole-square
integral below 3.07e-7. Two inner-axis cells also pass. Twelve exact moment
witnesses accompany these bounds; three larger-cell refusals remain explicit.
See [RN results and scope](rn_n6/README.md).

The RN calculation still uses its separately pinned, stronger fixed-radius
H3 floor. The new uniform H3 constants are not silently substituted into
that budget. Inner-edge squares cross the annulus boundary, so these local
certificates do not constitute an annulus allocation or a complete spatial sum.

## Verification

- H3 floor: 27 tests in normal Python and 27 under `-O`.
- H3 ceiling: 24 tests in each mode.
- RN N6: 59 tests in each mode, including warm-cache and output-path guards.
- Pin energy: 8 tests in each mode.

That is **118 passing tests per mode**. The combined runner separately
replayed five mathematical jobs in both modes from a relocated copy. All
34 output comparisons were byte-identical. Its 62 bundle input identities
and 25 repository code/source identities remained unchanged. The exact
plan and runner hashes are recorded in [VERIFICATION.json](VERIFICATION.json).
Reviewer findings and repairs are recorded in [PARENT_REVIEW.md](PARENT_REVIEW.md)
and [the RN review](reviews/rn_n6_review.md).

Run with Python 3.11 and the existing repository dependencies:

```sh
python -B verify_closure.py --repo /absolute/path/to/research-main --validate-only
python -B verify_closure.py --repo /absolute/path/to/research-main --output /new/external/output-directory
```

The output directory must be fresh and outside both the bundle and repository.
The runner executes both Python modes, checks declared inputs before and
afterward, and compares the complete expected output set. Author test entry
points are also retained. Some standalone author test defaults name the
original local repository; the combined replay supports an explicit relocated
repository path and does not depend on the original scratch path.

## Remaining existing obligations

1. Extend the RN transport to a certified spatial cover and integral budget,
   including difficult near-axis cells; prove any annulus clipping/allocation.
2. Extend the required estimates beyond the fixed-axis/radius scopes and
   complete the outstanding full 24-jet and weighted-field interfaces.
3. Resolve the elder-pairing/branch-adjacency transfer and obtain required
   external acceptance before any canonical q0 closure.

These remaining obligations are open. Local numerical success does not close
them. No canonical scientific status was changed in this delivery.

## Integration

Copy only files in the aggregate `MANIFEST.json` from the immutable delivery
ZIP. Per-project manifests retain the authors' exact allowlists. Preliminary
probes, superseded reports and duplicate output directories are excluded.
The designated repository writer owns integration and private publication;
this task authored scratch files only. R17 claims 100–102 identify these three
bounded research tasks. Their append-only releases follow delivery separately.
