# RN N6 scoped technical review

Reviewer: H3 uniform-ceiling agent, reading the RN N6 work as a separate
technical reviewer. Same provider; organizational independence credit **0**.
No canonical status changes. Review date: 2026-09-20.

## Verdict

**PASS at the stated local mathematical scope. The one identified
strict-input/cache defect was repaired and its repair was independently
checked in normal and optimized modes.** No counterexample to the reported local
rectangle bounds was found. This review is neither a complete code audit nor
an annulus-coverage certificate, and it does not discharge an RN obligation.

The author declared the computational files stable before this final review.
The identities below pin that state; any changed file requires a successor
review or an explicit review of its diff. I did not run the broad test suite
or regenerate the expensive N6 witnesses. Author validation is distinguished
from the reviewer's own bounded checks below.

## Finding R1, resolved: cached calls bypassed strict input guards

The initially inspected `side24_taylor.py`, SHA256
`55004b287e450dd7d8f924931b15d693d2539f0a2cb24e192508d8b6a15cdd81`,
decorated `prepared_center` directly with an untyped `lru_cache`. Its type validation occurred only inside the uncached
`center_jet_lift` call. Once an exact `(center,6,192)` entry is present,
`order=6.0` compares equal and returns the cached value without reaching the
order validator. A tuple of floating-point center coordinates likewise
aliases an equal tuple of Fractions. An order-one entry also aliases True.
`transported_law` validates its Box and precision before this call, but does
not validate `order` before the cache, so the order alias reaches its public
path too.

I reproduced this cache behavior in a fresh Python -B process, replacing only
the expensive child computations by test doubles whose lift validator
rejects non-integer orders and non-Fraction centers. Seeding the exact entry
then calling both float aliases returned the seeded tuple; the validator ran
only once. This demonstrates the cache bypass, not a false mathematical cap.
The existing `test_cached_float_bool_inputs_cannot_alias_exact_entries`
checks `kernel_derivative` and uncached `center_jet_lift`, so it does not cover
this entry point.

The recommended repair was to put validation in a public `prepared_center` wrapper
**before** delegating to a private cached function, including all coordinates,
order, and precision. Adding `typed=True` alone does not distinguish numeric
types nested in the center tuple. Add tests that prime exact valid entries,
then reject matching float/bool orders and float center tuples through the
cached public path. The resulting local numeric laws currently remain those
for the valid seeded order; this finding concerns the strict-input contract.

### Repair verification

The final `prepared_center` is an uncached validating wrapper. It validates
precision and the exact integer order, rejects nonexact center coordinates,
normalizes accepted coordinates, checks the bounded domain and pin collision,
and only then enters private `_prepared_center_cached`. The numerical Taylor,
conditioning, and determinant computation is unchanged by this repair.

In separate normal and python -O processes I primed private caches for valid
orders 6 and 1, then checked float 6.0, bool/float 1, float/bool center coordinates,
and float precision. Every invalid input raised before the expensive child
functions ran. The public `transported_law` path also rejected all tested
order aliases. The child-function call counter stayed at the two valid cache
primes. These bounded checks used test doubles for expensive children; they
tested the actual production validation wrapper and cache entry structure.
This resolves R1 at the final hash below.

The standalone CLI now rejects an existing output path and any path inside
the source repository before constructing output. It verifies dependency
hashes before importing repository modules, and verifies them again after
replay. I inspected these guards but did not run another full replay.

## Mathematical checks performed

1. **Full kernel and tails.** The derivative sign at the second covariance
   endpoint is `(-1)^|b|`. The paired-image polynomial/exponential majorant
   decreases geometrically with the stated first omitted pair. The full
   normalization is retained. The simple moment-cap argument gives
   `2*2^56*2^90*2^-288 = 2^-141` for the first nonzero pair and ratio at most
   `2^18*2^-864`; thus the complete nonzero tail is below one. This supports
   all derivative-variance caps through order 18, including the remainder's
   order-nine derivatives.
2. **Taylor remainder.** The Hilbert-space integral remainder, directional
   multinomial, and integral weight yield exactly `1/alpha!` at total order 7.
   Stationary variance bounds and Minkowski provide a valid unconditional
   L2 remainder. Orthogonal projection off fixed observations contracts it.
   Mean error separately uses `sqrt(c^T G^-1 c)*epsilon`; the full polynomial
   conditional mean is retained. Covariance error correctly contains both
   polynomial/remainder cross terms and the remainder/remainder product.
3. **Signed covariance assembly.** Equal multi-indices are combined before
   taking magnitudes. Both mixed contributions occur in the coefficient
   loops, and factorials match the Taylor extraction. Each congruence and
   symmetric intersection contains the same actual covariance member.
4. **Preconditioning and restoration.** Rational approximate whitening is
   only an invertible coordinate change. The measured covariance remains
   present. Undoing gives `H=LH*ZH+A0*w(t)`, including its intercept and slope
   at the same mark. No independence of Hessian sites is introduced.
   Positive transformed marginal pivots imply positive actual original
   marginals by invertible block congruence; the proof correctly avoids
   claiming every entrywise-hull matrix is SPD.
5. **Density and normalization.** The physical three-jet density includes
   `abs(det TY)` exactly once, and its denominator equals
   `(2*pi)^(3/2)*sqrt(det Gz)`. The LDL square sum gives a lower bound for
   Mahalanobis distance throughout the full mark and rectangle. Replacing
   the exponential by positive `2^-k` when `q/2>=k` is conservative, including
   the cap k=1024. Window length is ell exactly. Hölder exponents
   1/4,1/4,1/2 require no site independence. Dividing by H3 retains the
   explicitly imported source-floor premise.
6. **Scope.** The inspected current RUN report records four admitted whole
   squares and three retained larger refusals. Inner-edge squares cross the
   circle; the proof does not allocate their whole areas to an annulus or
   claim a full cover. All-r, remote-budget, canonical closure, and external
   review remain outside the result. The generic moment engine quantifies
   PSD members and does not silently turn an entrywise hull into a physical
   law; the Gaussian field/projection construction supplies that member.

## Author validation evidence, separately identified

I read the author logs `tests-normal-v2.log` and `tests-optimized-v2.log`:
59 tests passed in each mode. The optimized log includes the standard pytest
warning about assertions outside test modules; this is recorded, not hidden.
I did not personally rerun those 59 tests. I also read both final replay logs,
which report four local caps, three retained refusals, and twelve moment
witnesses. I compared the normal and optimized final RUN files directly:
their bytes match exactly. This comparison is an artifact-integrity check,
not a new mathematical replay or independence credit.

## Final inspected file identities

| File, relative to rn_n6 | Bytes | SHA256 |
|---|---:|---|
| side24_taylor.py | 23681 | `32c4933c2ab543f738bd54f98066b351a334e377277e8ebcab5879438f418598` |
| PROOF.md | 10662 | `850291813ff1e0c83cf85987b8132a756dfe3bf83fda2731b5c2bdc0ebe7e3df` |
| test_n6.py | 13773 | `c2d5deed47708f6d8fb3a49acb295e73e73aed37f16214867b3526d53c1d8d9a` |
| check.py | 6071 | `12a3ded74fbc9e047bc75f2fa523db448dd0cc77466106db9d87e2488a85ef97` |
| DEPENDENCIES.json | 4119 | `028bd2ad9b55778f07d10c1a8ede97ddc51346ec35178a0d04bb3d3baed62f88` |
| results_final/RUN.json | 127095 | `6e92e4e84500d66dddb6f3fc1ba7174799322a9748fdb36c049482ae1cdb98e6` |
| replay_optimized_final/RUN.json | 127095 | `6e92e4e84500d66dddb6f3fc1ba7174799322a9748fdb36c049482ae1cdb98e6` |
| tests-normal-v2.log | 100 | `f14c5b729bebe4d7fb9556174851f1dd2a6d7517d5408a2350ee9cb1808945c0` |
| tests-optimized-v2.log | 755 | `9e9777f7c75ecabc9f2c7cef6fa4c108bdb580c1bf10c36894fa31d3e44bc304` |

Supporting implementation reads included repository Gaussian conditioning,
SIDE24 cell and density code, the Gaussian moment-family feasibility
contract, and the source-bound portable witness interface. Their identities
are already enumerated in the candidate dependency manifest. The review
relied on no quarantined source body and executed no frozen source program.
