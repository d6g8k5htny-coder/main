# RN N6 local mathematical advance

Implemented a rigorous degree-six Taylor successor for the existing fixed-r
RN work. Four nonzero whole-square/full-mark bounds now replay, including a
strictly better bound on the original pilot. Three larger failed cells remain
explicitly pending. These are local mathematical results, conditional on the
original pinned H3 floor; the complete annulus and D3-LEMMA-RN-UNIF remain open.

| Center | Square half-width | Exact short upper for the integrand | Older N0 on the same square |
|---|---:|---:|---|
| (1,1), original pilot | 1/4000 | < 0.00000381 | Admits, upper approximately 0.000005589 |
| (1,1), wider pilot | 1/20 | < 0.0000307 | Refuses |
| (1/10,0), inner x-axis | 1/10000000 | < 1.18 × 10^-303 | Refuses |
| (0,1/10), inner y-axis | 1/100000 | < 0.0000338 | Refuses |

All displayed new short uppers were checked against the exact rational
outputs. The original pilot improves the upper by more than 30% on the same
square. The wider pilot has 200 times the old pilot's half-width; its whole
square integral is below 3.07 × 10^-7. The two inner-edge squares cross the
annulus boundary. Their entire-square bounds do not allocate any annulus
area, establish coverage, or justify a complete spatial sum.

The larger tested half-widths 1/10 at (1,1), 1/1000000 at (1/10,0), and
1/10000 at (0,1/10) fail sufficient pivot tests and retain their refusal
reasons. Near the x-axis, useful cell size remains a practical limitation.

The mathematical machinery is in `side24_taylor.py`; the complete containment
argument is in `PROOF.md`. It includes normalized torus kernel derivatives
0 through 18, a 51-target six-pin lift, exact rational preconditioning,
signed common-monomial aggregation, the order-seven L2 and conditional-mean
remainders, original-Hessian unwhitening including +A*w, and the full
three-jet density Jacobian. A proved short positive density upper avoids
floating underflow or huge-denominator output. It retains every relevant
correlation and proves original marginal SPD by invertible congruence, not
by assuming the entire independent interval-entry hull is SPD.

`results_final/RUN.json` carries the exact bounds, pins, scope flags, retained
refusals and witness hashes. Twelve portable moment witnesses replay.
`DEPENDENCIES.json` pins 24 repository code/source inputs; no frozen source
program executes. `VALIDATION.json` records 59 passing tests in normal Python
and 59 under `-O`, with all 13 normal/optimized output files byte-identical.
The pytest optimized-mode warning is retained in the log; the authored checker
uses explicit exceptions rather than assertion guards.

To reproduce from this folder with Python 3.11 and the existing repository:

```sh
python -B check.py --repo /absolute/path/to/research-main --output /new/output/directory
PYTHONPATH=/absolute/path/to/research-main python -B -m pytest -q -p no:cacheprovider test_n6.py
```

Repeat the commands with `-O` to check optimized Python. The checker requires a fresh output directory outside the repository, refuses
changed dependency identities before repository imports, and checks them again
afterward. Its deterministic output is `RUN.json` plus twelve witness JSONs.

Authored in scratch only under claim
85279215-fdbb-4b77-9ab4-181d64a56f3c. No repository edits by this author.
No full-cover, all-r, remote-budget or canonical closure claim; same-provider
organizational independence credit is zero. `MANIFEST.json` is the delivery
allowlist; optimized duplicate outputs and pre-freeze drafts are retained locally but
excluded from that allowlist. `PREFREEZE_FINDINGS.md` records the corrected
cache type-alias and output-path defects; no mathematical output changed.
