#!/usr/bin/env python3
"""Fresh bounded RN N6 replay; output never asserts an obligation closure."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
from fractions import Fraction as F


def encode(x):
    from research.interval import Interval
    from research.cover import Box
    if isinstance(x,F): return str(x)
    if isinstance(x,Interval): return [str(x.lo),str(x.hi)]
    if isinstance(x,Box): return [str(x.u0),str(x.u1),str(x.v0),str(x.v1)]
    if isinstance(x,dict): return {str(k):encode(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)): return [encode(v) for v in x]
    return x


def write(path,value):
    path.write_text(json.dumps(encode(value),sort_keys=True,indent=2)+'\n')


def verify_dependencies(repo):
    manifest=Path(__file__).with_name('DEPENDENCIES.json')
    if not manifest.exists(): raise ValueError('dependency manifest required')
    rows=json.loads(manifest.read_text())['files']
    for row in rows:
        p=(repo/row['path']).resolve()
        if not p.is_relative_to(repo.resolve()): raise ValueError('dependency escapes repository')
        raw=p.read_bytes()
        if len(raw)!=row['bytes'] or hashlib.sha256(raw).hexdigest()!=row['sha256']:
            raise ValueError('dependency identity changed: '+row['path'])
    return rows


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--repo',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args()
    args.repo=args.repo.resolve()
    args.output=args.output.resolve()
    if args.output.exists():
        parser.error('output must be a new directory; existing paths are never overwritten')
    if args.output.is_relative_to(args.repo):
        parser.error('output must be outside the source repository')
    dependencies=verify_dependencies(args.repo)
    sys.path.insert(0,str(args.repo.resolve()))
    from research.cover import Box
    from research.rn import side24_cell
    from research.rn.conditioning import ConditioningInconclusive
    from research.rn.certificate import canonical_bytes
    import side24_taylor as n6
    args.output.mkdir(parents=True,exist_ok=False)
    cases=(('original_pilot_admitted',(F(1),F(1)),F(1,4000),True),
           ('pilot_refused',(F(1),F(1)),F(1,10),False),
           ('pilot_admitted',(F(1),F(1)),F(1,20),True),
           ('x_inner_refused',(F(1,10),F(0)),F(1,10**6),False),
           ('x_inner_admitted',(F(1,10),F(0)),F(1,10**7),True),
           ('y_inner_refused',(F(0),F(1,10)),F(1,10**4),False),
           ('y_inner_admitted',(F(0),F(1,10)),F(1,10**5),True))
    attempts=[]
    for name,center,h,expected in cases:
        box=Box(center[0]-h,center[0]+h,center[1]-h,center[1]+h)
        row=dict(case=name,center=center,halfwidth=h,box=box,expected_admissible=expected)
        try:
            r=n6.spatial_cell(box)
        except ConditioningInconclusive as e:
            if expected: raise
            row.update(admitted=False,refusal_type=type(e).__name__,reason=str(e),pending=True)
        else:
            if not expected: raise ValueError('declared refusal changed; review successor scope')
            files=[]
            for label,cert in r['moment_certificates'].items():
                path=args.output/(name+'_'+label+'.json'); raw=canonical_bytes(cert)
                path.write_bytes(raw)
                files.append(dict(path=path.name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
            row.update(admitted=True,integrand_upper=r['integrand_upper'],whole_square_area=(2*h)**2,
                whole_square_integral_upper=(2*h)**2*r['integrand_upper'],target_count=r['target_count'],
                mean_monomials=r['polynomials']['mean_monomials'],covariance_monomials=r['polynomials']['covariance_monomials'],
                jet_pivots=r['jet_pivots'],marginal_pivots=r['marginal_pivots'],
                marginal_pivot_basis=r['marginal_pivot_basis'],moment_caps=r['moment_caps'],
                moment_replays=r['moment_replays'],density=r['density'],holder_upper=r['holder_upper'],
                source_binding=r['source_binding'],imported_h3_floor=r['imported_h3_floor'],
                raw_remainder_upper=r['raw_remainder_upper'],transformed_remainder_upper=r['transformed_remainder_upper'],
                mean_remainder_upper=r['mean_remainder_upper'],witnesses=files,
                crosses_inner_annulus_boundary=(name.startswith(('x_inner','y_inner'))),pending=False)
        try:
            old=side24_cell.cell_laws(box)
        except ConditioningInconclusive as e:
            row['N0_same_box']=dict(admitted=False,refusal_type=type(e).__name__,reason=str(e))
        else: row['N0_same_box']=dict(admitted=True)
        attempts.append(row)
    h=F(1,4000)
    old=side24_cell.spatial_cell(Box(1-h,1+h,1-h,1+h))
    report=dict(schema='RN_N6_LOCAL_TAYLOR_CANDIDATE_V1',claim='85279215-fdbb-4b77-9ab4-181d64a56f3c',
        quantifier='FOR_EVERY_Y_IN_EACH_ADMITTED_CLOSED_RECTANGLE_AND_EVERY_MARK_IN_FULL_WINDOW',
        attempts=attempts,old_pilot=dict(center=(F(1),F(1)),halfwidth=h,integrand_upper=old['integrand_upper']),
        fixed_r=F(1,20),fixed_b=F(6,5),full_mark_domain=n6.side24.MARK_DOMAIN,
        moment_cap_proof=n6.moment_cap_certificate(),dependencies=dependencies,
        admitted_count=sum(x['admitted'] for x in attempts),retained_refusals=sum(not x['admitted'] for x in attempts),
        **n6.FLAGS,
        does_not_establish='No complete annulus, boundary allocation, remote assembly, all-r theorem, original prize closure, canonical status change or organizational independence; imported original H3 floor.')
    if report['admitted_count']!=4 or report['retained_refusals']!=3:
        raise ValueError('unexpected bounded pilot accounting')
    verify_dependencies(args.repo)
    write(args.output/'RUN.json',report)
    print('RN N6: 4 whole-rectangle/full-mark caps replayed; 3 larger refusals retained; 12 moment witnesses; no full-cover or status claim')

if __name__=='__main__': main()
