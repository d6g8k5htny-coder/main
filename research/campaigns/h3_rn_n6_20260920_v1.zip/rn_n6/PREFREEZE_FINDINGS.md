# Defects found and corrected before delivery freeze

The initial mathematical pilot found no containment failure. Validation did
find input and file-output guards that needed correction:

1. The initial kernel cache could return an integer-order cache entry for an
   equal-valued float or bool before the body rejected that type. The kernel
   cache now distinguishes types, and its regression test warms valid entries
   before attempting invalid aliases. Direct lift inputs validate uncached.
2. A same-provider read-only reviewer found the analogous alias in the cached
   prepared center: order 6.0 could reuse order 6, and nested float coordinates
   could reuse Fraction coordinates. The public prepared-center wrapper now
   validates every input before the private typed cache lookup. Tests exercise
   the public transport route as well as the prepared-center entrypoint.
3. The initial checker allowed an existing output directory, creating a risk
   of overwriting prior evidence. It now refuses every existing output path
   and every resolved output path inside the source repository, before any
   mathematics. Subprocess tests verify refusal without modifying a sentinel
   or creating the forbidden path. Dependency hashes verify before repository
   imports and again after the bounded replay.

The initial test expectations also confused an outward dyadic interval with
an exact decimal-endpoint equality, and guessed an x-axis short bound too
small. They were corrected to test containment/tightness and an actually
proved rational upper. The final x-axis integrand upper is strictly below
1.18 × 10^-303, remains positive, and uses a proved 2^-1024 exponential cap.

The final mathematical outputs are byte-identical to the pre-guard numerical
outputs. This is same-provider technical validation, independence credit 0;
no canonical claim status changes. Pre-freeze draft outputs and logs remain
locally available, but only the final manifest allowlist is delivered.
