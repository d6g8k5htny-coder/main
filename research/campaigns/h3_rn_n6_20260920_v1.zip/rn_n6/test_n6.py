"""Exact mathematical controls, not a full-cover or independence certificate."""
from fractions import Fraction as F
from math import factorial
import pytest
from research.interval import Interval as I, exp
from research.cover import Box
from research.rn import side24, side24_cell
from research.rn.conditioning import ConditioningInconclusive
import side24_taylor as n6


def square(center,h):
    return Box(center[0]-h,center[0]+h,center[1]-h,center[1]+h)


def overlap(a,b): return max(a.lo,b.lo)<=min(a.hi,b.hi)
def contains(a,b): return a.lo<=b.lo<=b.hi<=a.hi


@pytest.fixture(scope='module')
def pilot(): return n6.spatial_cell(square((F(1),F(1)),F(1,20)))


@pytest.mark.parametrize('n',range(19))
def test_hermite_coefficients_against_independent_factorial_formula(n):
    direct=[0]*(n+1)
    for k in range(n//2+1): direct[n-2*k]=(-1)**k*factorial(n)//(2**k*factorial(k)*factorial(n-2*k))
    assert n6.hermite_coefficients(n)==tuple(direct)
    assert sum(abs(x) for x in direct)<2**56


@pytest.mark.parametrize('n',range(5))
def test_existing_low_order_kernel_overlap(n):
    for x in (F(0),F(1,10),F(7,3)):
        assert overlap(n6.kernel_derivative(n,x),side24.kernel_derivative(n,x))


@pytest.mark.parametrize('n',range(1,10))
def test_high_order_normalized_variance_caps(n):
    v=(-1)**n*n6.kernel_derivative(2*n,F(0),bits=512)
    assert 0<v.lo<=v.hi<n6.MOMENT_CAPS[n]


def test_torus_image_and_normalization_mutants_excluded():
    # Planar substitution and zero-image-only changes fail at resolvable precision.
    v=n6.kernel_derivative(6,F(0),bits=512)
    assert v.lo> -15
    assert F(-15) not in v
    raw=I.exact(-15)+2*(24**6-15*24**4+45*24**2-15)*exp(I.exact(-288),200)
    # Correct normalizer is not interchangeable with one: finite numerator alone
    # lies below the normalized derivative, by a resolvable nonzero gap.
    assert raw.hi<v.lo
    assert n6.tail(18,F(18),192)>0
    assert n6.kernel_derivative(17,F(0))==I.exact(0)


def test_exact_remainder_combinatorics_and_uniform_bound():
    h=(F(1),F(1))
    assert n6.remainder_bound((2,0),h,6)==F(71049,5040)
    assert n6.remainder_bound((1,1),h,6)==F(53658,5040)
    for b in side24.JETS+side24.HJETS:
        assert 0<n6.remainder_bound(b,h,6)<15
    # A 7th derivative 7! makes x^7's order-six remainder exactly h^7.
    # The multinomial/factorial and mixed term cannot be silently omitted.
    assert sum(F(1,factorial(k)*factorial(7-k)) for k in range(8))==F(2**7,factorial(7))
    assert F(1,factorial(3)*factorial(4))*factorial(3)*factorial(4)==1
    assert n6.remainder_bound((0,0),(F(0),F(0)),6)==0


def test_signed_aggregation_cancellation_and_mixed_term():
    # Polynomial (U+delta V)^2 covariance: sum both cross terms BEFORE abs.
    uv=I.exact(-2); coeff={(0,0):I.exact(7),(1,0):uv+uv,(2,0):I.exact(3)}
    got=n6.eval_signed_poly(coeff,(F(1,10),F(0)),192)
    assert contains(got,I(F(657,100),F(743,100)))
    assert got.width()-F(86,100)<F(1,10**50)
    cancelling={(0,0):I.exact(1),(1,0):I.exact(5)+I.exact(-5)}
    assert n6.eval_signed_poly(cancelling,(F(1),F(1)),192)==I.exact(1)
    # Taking abs first gives width20; deleting one mixed contribution gives
    # a false enclosure of the actual value at delta=-1/10.
    bad=I.exact(7)+I(-F(23,100),F(23,100))
    actual=F(7)+F(4,10)+F(3,100)
    assert actual in got and actual not in bad


def test_lift_dimensions_and_exact_transform_inverse(pilot):
    lift,tr,poly=n6.prepared_center((F(1),F(1)),6,192)
    assert lift['target_count']==51 and len(lift['jets'])==45
    assert poly['mean_monomials']==28 and poly['covariance_monomials']==91
    assert all(p.lo>0 for p in lift['six_pin_pivots'])
    for i in range(12):
        for j in range(12):
            assert sum((tr['T'][i][k]*tr['T_inverse'][k][j] for k in range(12)),F(0))==F(i==j)
    # Approximate whitening retains measured central intervals rather than I.
    assert any(tr['center_covariance'][i][i]!=I.exact(1) for i in range(12))


def test_zero_width_laws_match_direct_point_and_undo_A_is_essential():
    result=n6.cell_laws(square((F(1),F(1)),F(0)))
    direct=side24.point_laws()
    assert result['raw_remainder_upper']==(F(0),)*12
    assert result['mean_remainder_upper']==(F(0),)*12
    for name,law in result['laws'].items():
        other=direct['laws'][name]
        assert all(overlap(x,y) for x,y in zip(law.intercept+law.slope,other.intercept+other.slope))
        assert all(overlap(x,y) for row,otherrow in zip(law.covariance,other.covariance) for x,y in zip(row,otherrow))
    tr=result['transform']
    missing_A=tuple(n6.dot(row,result['transformed_conditional_intercept'],192) for row in tr['L_H'])
    assert any(not overlap(x,y) for x,y in zip(missing_A,direct['joint_intercept']))
    assert any(not x.contains_zero() for i,row in enumerate(result['joint_hessian_covariance']) for j,x in enumerate(row) if i//3!=j//3)


def test_full_mark_witnesses_and_local_integral(pilot):
    assert all(v['certificate_valid'] and v['requested_checks_passed'] for v in pilot['moment_replays'].values())
    assert all(l.context.domain==side24.MARK_DOMAIN for l in pilot['laws'].values())
    assert pilot['density']['window_length']==side24.ELL
    assert pilot['holder_upper']**4>=pilot['holder_fourth_power_upper']
    assert 0<pilot['integrand_upper']<F(307,10**7)
    assert pilot['integrand_upper']*F(1,100)<F(307,10**9)
    assert pilot['authority']=='NONE' and pilot['independence_credit']==0
    assert not any(pilot[k] for k in ('lemma_closed','spatial_cover_certified','all_small_r_certified','scientific_status_changed','original_prize_closed'))


def test_members_enclosed_by_continuum_law(pilot):
    for point in ((F(1),F(1)),(F(19,20),F(21,20)),(F(21,20),F(19,20))):
        direct=side24.point_laws(point)
        for name,law in pilot['laws'].items():
            other=direct['laws'][name]
            assert all(contains(x,y) for x,y in zip(law.intercept+law.slope,other.intercept+other.slope))
            assert all(contains(x,y) for row,otherrow in zip(law.covariance,other.covariance) for x,y in zip(row,otherrow))


def test_density_jacobian_scaling_and_full_window():
    one=I.exact(1); zero=I.exact(0)
    identity=tuple(tuple(F(i==j) for j in range(3)) for i in range(3))
    cov=tuple(tuple(I.exact(int(i==j)) for j in range(3)) for i in range(3))
    base=n6.density_cap((zero,)*3,cov,{'T_Y':identity,'determinant_T_Y':F(1)},192)
    scaled=n6.density_cap((zero,)*3,tuple(tuple(4*v for v in row) for row in cov),
        {'T_Y':tuple(tuple(2*v for v in row) for row in identity),'determinant_T_Y':F(8)},192)
    a,b=base['density_mass_upper'],scaled['density_mass_upper']
    assert F(999,1000)<a/b<F(1001,1000)
    assert b/8<a*F(1,2)  # Omitting determinant changes the claimed physical cap.
    assert base['density_jacobian_multiplicity']==scaled['density_jacobian_multiplicity']==1
    assert base['full_mark_domain']==side24.MARK_DOMAIN


def test_center_only_mutant_does_not_enclose_endpoint(monkeypatch):
    monkeypatch.setattr(n6,'eval_signed_poly',lambda coeffs,h,bits:coeffs.get((0,0),I.exact(0)))
    center=(F(1),F(1)); h=F(1,100)
    result=n6.transported_law(square(center,h))
    endpoint=(center[0]+h,center[1]+h)
    direct=side24_cell.transported_law(square(endpoint,F(0)))
    # Existing raw order fixed pair H,Y,H_y -> new raw order Y,pair H,H_y.
    raw=direct['mean'][6:9]+direct['mean'][:6]+direct['mean'][9:]
    transformed=tuple(n6.dot(row,raw,192) for row in result['transform']['T'])
    assert any(not overlap(x,y) for x,y in zip(result['mean'],transformed))


def test_remainder_cannot_be_dropped_from_affine_mean(pilot):
    assert pilot['conditioning_energy'].lo>0
    for poly,full,error in zip(pilot['mean_polynomial'],pilot['mean'],pilot['mean_remainder_upper']):
        assert error>0
        assert full.lo<=poly.lo-error and full.hi>=poly.hi+error
    # The deterministic Gaussian regression example X(z)=z^7 O, O=1 has
    # zero center polynomial but nonzero conditional mean at every z != 0.
    h=F(1,2); exact_remainder=h**7
    assert exact_remainder not in I.exact(0)
    assert exact_remainder in I(-exact_remainder,exact_remainder)


@pytest.mark.parametrize('center,h',[((F(1,10),F(0)),F(1,10**7)),((F(0),F(1,10)),F(1,10**5))])
def test_inner_axis_cells_full_certificates_improve_admission(center,h):
    box=square(center,h); result=n6.spatial_cell(box)
    assert all(x.lo>0 for x in result['jet_pivots'])
    assert all(x.lo>0 for v in result['marginal_pivots'].values() for x in v)
    assert all(x['certificate_valid'] and x['requested_checks_passed'] for x in result['moment_replays'].values())
    assert result['integrand_upper']>0
    with pytest.raises(ConditioningInconclusive): side24_cell.cell_laws(box)
    if center[1]==0:
        assert result['density']['exponential_power']==1024
        assert result['density']['mahalanobis'].lo/2>=1024
        assert result['density']['exponential_upper']==F(1,2**1024)
        assert result['integrand_upper']<F(1,10**280)


@pytest.mark.parametrize('center,h',[((F(1),F(1)),F(1,10)),((F(1,10),F(0)),F(1,10**6)),((F(0),F(1,10)),F(1,10**4))])
def test_larger_cells_remain_refusals(center,h):
    with pytest.raises(ConditioningInconclusive): n6.cell_laws(square(center,h))


@pytest.mark.parametrize('order',[-1,19,True,1.0])
def test_kernel_order_guards(order):
    with pytest.raises(ValueError): n6.kernel_derivative(order,F(0))


def test_input_resource_guards():
    with pytest.raises(TypeError): n6.center_jet_lift((0.1,F(0)))
    with pytest.raises(ValueError): n6.center_jet_lift((F(1),F(1)),order=7)
    with pytest.raises(ValueError): n6.center_jet_lift((F(1),F(1)),bits=64)
    with pytest.raises(ConditioningInconclusive): n6.cell_laws(square((F(1,40),F(0)),F(1,1000)))
    with pytest.raises(ValueError): n6.tail(18,F(19),192)
    with pytest.raises(ValueError): n6.inverse_lower(((F(0),),))
    with pytest.raises(TypeError): n6.remainder_bound((0,0),(0.1,F(0)),6)
    with pytest.raises(ValueError): n6.remainder_bound((0,0),(F(-1),F(0)),6)


def test_symbolic_moment_cap_theorem_and_bad_cap_mutant():
    proof=n6.moment_cap_certificate()
    assert proof['paired_tail_strict_upper']<F(1,2**140)<1
    assert proof['ratio_upper']<F(1,2)
    bad=list(n6.MOMENT_CAPS); bad[9]=34459425
    with pytest.raises(ValueError): n6.moment_cap_certificate(tuple(bad))
    bad[9]=-1
    with pytest.raises(ValueError): n6.moment_cap_certificate(tuple(bad))


def test_cached_float_bool_inputs_cannot_alias_exact_entries():
    n6.kernel_derivative(1,F(0))
    for order in (True,1.0):
        with pytest.raises(ValueError): n6.kernel_derivative(order,F(0))
    n6.kernel_derivative(0,F(1))
    with pytest.raises(TypeError): n6.kernel_derivative(0,1.0)
    n6.center_jet_lift((F(1),F(1)),order=1)
    with pytest.raises(TypeError): n6.center_jet_lift((1.0,F(1)),order=1)


def test_sparse_assembly_preserves_covariance_cancellation_and_factorials():
    jets=n6.indices(4); count=6+len(jets); lookup={a:6+i for i,a in enumerate(jets)}
    c=[[I.exact(0)]*count for _ in range(count)]
    f,fx,fxx=lookup[(0,0)],lookup[(1,0)],lookup[(2,0)]
    c[f][f]=I.exact(7);c[fx][fx]=I.exact(3);c[fxx][fxx]=I.exact(2)
    c[f][fx]=c[fx][f]=I.exact(-2)
    c[f][fxx]=c[fxx][f]=I.exact(-3)
    mean=[I.exact(0)]*count;mean[fxx]=I.exact(2);mean[lookup[(1,1)]]=I.exact(7)
    lift={'bits':192,'order':2,'jets':jets,'covariance':tuple(tuple(row) for row in c),'mean':tuple(mean)}
    transform={'T':tuple(tuple(F(i==j) for j in range(12)) for i in range(12))}
    p=n6.aggregate_coefficients(lift,transform)
    assert p['covariance'][(1,0)][0][0]==I.exact(-4)
    assert p['covariance'][(2,0)][0][0]==I.exact(0)
    assert p['mean'][(2,0)][0]==I.exact(1)
    assert p['mean'][(1,1)][0]==I.exact(7)


def test_same_original_pilot_improves_actual_integrand_cap():
    h=F(1,4000);box=square((F(1),F(1)),h)
    new=n6.spatial_cell(box);old=side24_cell.spatial_cell(box)
    assert new['integrand_upper']<F(381,10**8)<old['integrand_upper']
    assert new['integrand_upper']<F(7,10)*old['integrand_upper']


def test_prepared_center_validates_before_warmed_cache_lookup():
    center=(F(1),F(1))
    n6.prepared_center(center,6,192)
    for order in (6.0,):
        with pytest.raises(ValueError): n6.prepared_center(center,order,192)
        with pytest.raises(ValueError): n6.transported_law(square(center,F(1,4000)),order=order)
    n6.prepared_center(center,1,192)
    for order in (True,1.0):
        with pytest.raises(ValueError): n6.prepared_center(center,order,192)
        with pytest.raises(ValueError): n6.transported_law(square(center,F(1,4000)),order=order)
    for malformed in ((1.0,F(1)),(True,F(1))):
        with pytest.raises(TypeError): n6.prepared_center(malformed,6,192)
    with pytest.raises(ValueError): n6.prepared_center(center,6,192.0)


def test_checker_refuses_existing_or_repository_output(tmp_path):
    import subprocess,sys
    from pathlib import Path
    checker=Path(__file__).with_name('check.py')
    existing=tmp_path/'existing';existing.mkdir()
    sentinel=existing/'sentinel';sentinel.write_text('retain original bytes')
    run=subprocess.run([sys.executable,'-B',str(checker),'--repo',str(side24.ROOT),'--output',str(existing)],capture_output=True,text=True)
    assert run.returncode==2 and 'output must be a new directory' in run.stderr
    assert sentinel.read_text()=='retain original bytes'
    forbidden=side24.ROOT/'rn_n6_test_must_never_be_created_85279215'
    assert not forbidden.exists()
    run=subprocess.run([sys.executable,'-B',str(checker),'--repo',str(side24.ROOT),'--output',str(forbidden)],capture_output=True,text=True)
    assert run.returncode==2 and 'outside the source repository' in run.stderr
    assert not forbidden.exists()
