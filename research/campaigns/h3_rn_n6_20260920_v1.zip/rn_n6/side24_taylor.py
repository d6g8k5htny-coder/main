"""Bounded N6 SIDE24 cell candidate; see PROOF.md. No claim promotion/cover.

Only authored code executes. Frozen RN5 inputs are read and authenticated by
side24.source_binding. All claimed arithmetic is exact interval arithmetic.
"""
from fractions import Fraction as F
from functools import lru_cache
from math import factorial, isqrt
from dataclasses import asdict

from research.interval import Interval as I, exp, sqrt, pi
from research.bands.hermite_gaussian import hermite_coefficients
from research.rn import side24, side24_cell
from research.rn.conditioning import interval_ldlt, condition_gaussian, ConditioningInconclusive, ConditioningResourceLimit
from research.rn.side24_density import imported_h3_floor
from engine.operations.rn_applicability import Context, RN5_ID, RN5_SHA
from engine.operations.rn_family_applicability import FamilyLaw

ZERO = I.exact(0)
MOMENT_CAPS = (1,2,4,16,106,946,10396,135136,2027026,34459426)
FLAGS = dict(authority='NONE', independence_credit=0, field_certified=False,
    spatial_cover_certified=False, scientific_status_changed=False,
    all_small_r_certified=False, h3_reproved=False, original_prize_closed=False,
    lemma_closed=False)


def options(bits):
    return side24_cell._options(bits)


def dot(a, b, bits):
    if len(a) != len(b):
        raise ValueError('dot-product dimension mismatch')
    r = ZERO
    for x, y in zip(a,b):
        if x == 0 or y == 0 or x == ZERO or y == ZERO:
            continue
        r = (r+(x*y).round_out(bits) if isinstance(x*y,I) else r+x*y).round_out(bits)
    return r


def indices(n):
    return tuple((a,d-a) for d in range(n+1) for a in range(d+1))


def tail(order, radius, bits):
    """All images |j|>=2, for 0<=order<=18 and |s|<=18."""
    prec=options(bits)
    if type(order) is not int or not 0 <= order <= 18:
        raise ValueError('bounded derivative order must be 0..18')
    radius=side24._rational(radius)
    if not 0 <= radius <= 18:
        raise ValueError('image-tail radius must be 0..18')
    c=sum(abs(x) for x in hermite_coefficients(order))
    first=c*(48+radius)**order*exp(I.exact(-(48-radius)**2/2),prec)
    ratio=F(72+radius,48+radius)**order*exp(I.exact(-((72-radius)**2-(48-radius)**2)/2),prec)
    if ratio.hi >= 1:
        raise ConditioningInconclusive('high-order image tail does not contract')
    return (2*first/(1-ratio)).hi


@lru_cache(maxsize=4096, typed=True)
def kernel_derivative(order, displacement, *, bits=192):
    prec=options(bits)
    if type(order) is not int or not 0 <= order <= 18:
        raise ValueError('bounded derivative order must be 0..18')
    s=side24._displacement(displacement)
    if s.lo == s.hi == 0:
        if order==0: return I.exact(1)
        if order%2: return ZERO
    total=ZERO
    for j in (-1,0,1):
        x=s+24*j
        p=ZERO
        for c in reversed(hermite_coefficients(order)):
            p=(p*x+c).round_out(bits)
        total=(total+(-1)**order*p*exp(-x**2/2,prec)).round_out(bits)
    t=tail(order,max(abs(s.lo),abs(s.hi)),bits)
    return ((total+I(-t,t))/side24.normalizer(prec=prec,bits=bits)).round_out(bits)


def covariance(p,a,q,b,*,bits=192):
    if len(a)!=2 or len(b)!=2 or any(type(n) is not int or n<0 for n in (*a,*b)):
        raise ValueError('nonnegative two-axis derivative indices required')
    if any(a[k]+b[k]>18 for k in (0,1)):
        raise ValueError('derivative order exceeds 18')
    ans=I.exact((-1)**sum(b))
    for k in (0,1):
        s=side24._rational(p[k])-side24._rational(q[k])
        ans=(ans*kernel_derivative(a[k]+b[k],s,bits=bits)).round_out(bits)
    return ans


def center_jet_lift(center, *, order=6, bits=192):
    """Six-pin projection of at most 51 targets, factoring only a 6x6 block."""
    options(bits)
    if type(order) is not int or not 1<=order<=6:
        raise ValueError('Taylor order must be 1..6')
    if len(center)!=2:
        raise ValueError('two center coordinates required')
    center=tuple(side24._rational(x) for x in center)
    if any(abs(x)>17 for x in center):
        raise ValueError('center outside bounded domain')
    pins=((-side24.R/2,F(0)),(side24.R/2,F(0)))
    if center in pins:
        raise ConditioningInconclusive('center collides with fixed pin')
    obs=tuple((p,a) for p in pins for a in side24.JETS)
    jets=indices(order+2)
    targets=tuple((p,a) for p in pins for a in side24.HJETS)+tuple((center,a) for a in jets)
    g=[[ZERO]*6 for _ in range(6)]
    for i,(p,a) in enumerate(obs):
        for j in range(i+1):
            q,b=obs[j]
            g[i][j]=g[j][i]=covariance(p,a,q,b,bits=bits)
    g=tuple(tuple(row) for row in g)
    factor=interval_ldlt(g,round_bits=bits)
    k=tuple(tuple(covariance(p,a,q,b,bits=bits) for q,b in obs) for p,a in targets)
    solves=tuple(factor.solve(row) for row in k)
    c=(side24.HEIGHT,F(0),F(0),side24.HEIGHT-side24.ELL,F(0),F(0))
    m=tuple(dot(row,c,bits) for row in solves)
    n=len(targets)
    cov=[[ZERO]*n for _ in range(n)]
    for i,(p,a) in enumerate(targets):
        for j in range(i+1):
            q,b=targets[j]
            raw=covariance(p,a,q,b,bits=bits)
            left=(raw-dot(solves[i],k[j],bits)).round_out(bits)
            right=(raw-dot(solves[j],k[i],bits)).round_out(bits)
            v=left.intersect(right)
            if v is None or (i==j and v.hi<0):
                raise ConditioningInconclusive('lift Schur enclosure excludes covariance')
            cov[i][j]=cov[j][i]=v
    white=[]
    energy=ZERO
    for i,x in enumerate(c):
        w=(I.exact(x)-dot(factor.lower[i][:i],white,bits)).round_out(bits)
        white.append(w)
        energy=(energy+w**2/factor.pivots[i]).round_out(bits)
    return dict(center=center,order=order,bits=bits,targets=targets,jets=jets,
        covariance=tuple(tuple(row) for row in cov),mean=m,
        six_pin_pivots=factor.pivots,conditioning_energy=energy,
        source_binding=side24.source_binding(),target_count=n)


def matrix_product(a,b,bits):
    bt=tuple(zip(*b))
    return tuple(tuple(dot(row,col,bits) for col in bt) for row in a)


def congruence(t,c,bits):
    left=matrix_product(t,c,bits)
    n=len(t)
    out=[[ZERO]*n for _ in range(n)]
    for i in range(n):
        for j in range(i+1):
            x=dot(left[i],t[j],bits)
            y=dot(left[j],t[i],bits)
            v=x.intersect(y)
            if v is None:
                raise ConditioningInconclusive('congruence symmetry enclosures disjoint')
            out[i][j]=out[j][i]=v
    return tuple(tuple(row) for row in out)


def inverse_lower(a):
    n=len(a)
    if any(a[i][j] for i in range(n) for j in range(i+1,n)) or any(a[i][i]==0 for i in range(n)):
        raise ValueError('exact nonsingular lower triangular matrix required')
    out=[[F(0)]*n for _ in range(n)]
    for j in range(n):
        for i in range(j,n):
            out[i][j]=(F(i==j)-sum((a[i][k]*out[k][j] for k in range(i)),F(0)))/a[i][i]
    if any(max(abs(x.numerator).bit_length(),x.denominator.bit_length())>8192 for row in out for x in row):
        raise ConditioningResourceLimit('exact preconditioner rational size limit')
    return tuple(tuple(row) for row in out)


def approximate_cholesky(c,bits):
    f=interval_ldlt(c,round_bits=bits)
    roots=tuple(sqrt(d,options(bits)).round_out(64).mid() for d in f.pivots)
    out=tuple(tuple((f.lower[i][j].round_out(64).mid()*roots[j] if j<=i else F(0))
                    for j in range(len(c))) for i in range(len(c)))
    if any(out[i][i]<=0 for i in range(len(c))):
        raise ConditioningInconclusive('rational Cholesky approximation singular')
    return out


def center_transform(lift):
    """Exact rational approximate whitening, never replacing covariance by I."""
    bits=lift['bits']
    index={a:6+i for i,a in enumerate(lift['jets'])}
    raw_indices=tuple(index[a] for a in side24.JETS)+tuple(range(6))+tuple(index[a] for a in side24.HJETS)
    c=tuple(tuple(lift['covariance'][i][j] for j in raw_indices) for i in raw_indices)
    d=tuple(tuple(row[:3]) for row in c[:3])
    j=tuple(tuple(row[:3]) for row in c[3:])
    f=interval_ldlt(d,round_bits=bits)
    a=tuple(tuple(x.round_out(64).mid() for x in f.solve(row)) for row in j)
    ly=approximate_cholesky(d,bits)
    ty=inverse_lower(ly)
    # Exact rational residual transform R=[-A,I]; retain its measured covariance.
    residual=tuple(tuple(-x for x in a[i])+tuple(F(i==k) for k in range(9)) for i in range(9))
    residual_cov=congruence(residual,c,bits)
    lh=[[F(0)]*9 for _ in range(9)]
    for start in (0,3,6):
        block=tuple(tuple(residual_cov[i][j] for j in range(start,start+3)) for i in range(start,start+3))
        chol=approximate_cholesky(block,bits)
        for i in range(3):
            for j in range(3): lh[start+i][start+j]=chol[i][j]
    lh=tuple(tuple(row) for row in lh)
    w=inverse_lower(lh)
    wa=tuple(tuple(sum((w[i][k]*a[k][j] for k in range(9)),F(0)) for j in range(3)) for i in range(9))
    t=tuple(tuple(ty[i])+tuple(F(0) for _ in range(9)) for i in range(3))+tuple(tuple(-x for x in wa[i])+w[i] for i in range(9))
    # T inverse has raw Y=LY ZY, raw H=LH ZH+A LY ZY.
    aly=tuple(tuple(sum((a[i][k]*ly[k][j] for k in range(3)),F(0)) for j in range(3)) for i in range(9))
    tinv=tuple(tuple(ly[i])+tuple(F(0) for _ in range(9)) for i in range(3))+tuple(aly[i]+lh[i] for i in range(9))
    for i in range(12):
        for j in range(12):
            if sum((t[i][k]*tinv[k][j] for k in range(12)),F(0))!=F(i==j):
                raise ValueError('exact transform roundtrip failed')
    return dict(T=t,T_inverse=tinv,T_Y=ty,L_Y=ly,L_H=lh,A=a,
        center_covariance=congruence(t,c,bits),raw_indices=raw_indices,
        determinant_T_Y=ty[0][0]*ty[1][1]*ty[2][2],
        method='EXACT_RATIONAL_APPROXIMATE_PRECONDITIONER_MEASURED_COVARIANCE')


def extraction(lift):
    lookup={a:6+i for i,a in enumerate(lift['jets'])}
    support=indices(lift['order'])
    # Raw order Y,H_M,H_S,H_y.
    rows=[]
    for b in side24.JETS:
        rows.append(tuple((alpha,lookup[(b[0]+alpha[0],b[1]+alpha[1])],F(1,factorial(alpha[0])*factorial(alpha[1]))) for alpha in support))
    rows.extend((((0,0),j,F(1)),) for j in range(6))
    for b in side24.HJETS:
        rows.append(tuple((alpha,lookup[(b[0]+alpha[0],b[1]+alpha[1])],F(1,factorial(alpha[0])*factorial(alpha[1]))) for alpha in support))
    return tuple(rows)


def aggregate_coefficients(lift,transform):
    """Sum equal powers with signs intact BEFORE rectangle evaluation."""
    bits=lift['bits']; rows=extraction(lift); support=indices(lift['order'])
    mean={a:[ZERO]*12 for a in support}
    for i,row in enumerate(rows):
        for a,j,w in row: mean[a][i]=(lift['mean'][j]*w).round_out(bits)
    mean={a:tuple(dot(t,m,bits) for t in transform['T']) for a,m in mean.items()}
    polys={g:[[ZERO]*12 for _ in range(12)] for g in indices(2*lift['order'])}
    for i,row in enumerate(rows):
        for j in range(i+1):
            agg={}
            for a,u,x in row:
                for b,v,y in rows[j]:
                    g=(a[0]+b[0],a[1]+b[1])
                    term=(lift['covariance'][u][v]*(x*y)).round_out(bits)
                    agg[g]=(agg.get(g,ZERO)+term).round_out(bits)
            for g,val in agg.items(): polys[g][i][j]=polys[g][j][i]=val
    covariance={g:congruence(transform['T'],c,bits) for g,c in polys.items()}
    return dict(mean=mean,covariance=covariance,mean_monomials=len(mean),covariance_monomials=len(covariance))


def prepared_center(center,order,bits):
    """Validate BEFORE cache lookup so equal-valued invalid types cannot alias."""
    options(bits)
    if type(order) is not int or not 1<=order<=6:
        raise ValueError('Taylor order must be 1..6')
    if not isinstance(center,(tuple,list)) or len(center)!=2:
        raise ValueError('two exact center coordinates required')
    center=tuple(side24._rational(x) for x in center)
    if any(abs(x)>17 for x in center):
        raise ValueError('center outside bounded domain')
    if center in ((-side24.R/2,F(0)),(side24.R/2,F(0))):
        raise ConditioningInconclusive('center collides with fixed pin')
    return _prepared_center_cached(center,order,bits)


@lru_cache(maxsize=8,typed=True)
def _prepared_center_cached(center,order,bits):
    lift=center_jet_lift(center,order=order,bits=bits)
    transform=center_transform(lift)
    polys=aggregate_coefficients(lift,transform)
    return lift,transform,polys


def eval_signed_poly(coeffs,h,bits):
    """Centered absolute nonconstant monomial bound, only after aggregation."""
    result=coeffs.get((0,0),ZERO)
    radius=F(0)
    for (a,b),v in coeffs.items():
        if a+b:
            radius+=v.mag()*h[0]**a*h[1]**b
    return (result+I(-radius,radius)).round_out(bits)


def moment_cap_certificate(caps=None):
    """Exact proof of all normalized derivative variance caps through order 18.

    For image j>=1, |He_n(24j)| <= C_n (24j)^n. e>2, C_n<2^56,
    24^n<2^90 give first paired image <2^-141. Consecutive ratio
    <=2^18*2^-864=2^-846, hence complete paired tail <2^-140<1.
    The normalizer is >=1. k(0)=1 handles the zeroth variance exactly.
    """
    caps=MOMENT_CAPS if caps is None else caps
    if not isinstance(caps,tuple) or len(caps)!=10 or any(type(x) is not int for x in caps):
        raise ValueError('ten integer stationary derivative caps required')
    zero=tuple([1]+[factorial(2*k)//(2**k*factorial(k)) for k in range(1,10)])
    if caps[0]!=1 or any(caps[k]<zero[k]+1 for k in range(1,10)):
        raise ValueError('stationary cap omits proved nonzero image allowance')
    sums=tuple(sum(abs(x) for x in hermite_coefficients(n)) for n in range(19))
    if not max(sums)<=10*factorial(18)<2**56 or not 24**18<2**90:
        raise ValueError('high-order Hermite integer majorant failed')
    ratio=F(1,2**846); first=F(1,2**141); total=first/(1-ratio)
    if not ratio<F(1,2) or not total<F(1,2**140)<1:
        raise ValueError('moment image tail proof failed')
    return dict(caps=caps,zero_image=zero,hermite_coefficient_sums=sums,
        paired_first_image_strict_upper=first,ratio_upper=ratio,
        paired_tail_strict_upper=total,normalizer_lower=F(1),
        premise='exp(1)>2 from positive power series; all image pairs retained')


def remainder_bound(b,h,order):
    if type(order) is not int or not 1<=order<=6 or len(b)!=2 or sum(b)>2 or any(type(x) is not int or x<0 for x in b):
        raise ValueError('bounded remainder order or derivative invalid')
    if not isinstance(h,(tuple,list)) or len(h)!=2:
        raise ValueError('two exact remainder halfwidths required')
    h=tuple(side24._rational(x) for x in h)
    if any(x<0 or x>1 for x in h):
        raise ValueError('remainder halfwidths must be in [0,1]')
    caps=moment_cap_certificate()['caps']
    ans=F(0)
    for a in indices(order+1):
        if sum(a)!=order+1: continue
        radicand=caps[b[0]+a[0]]*caps[b[1]+a[1]]
        root=isqrt(radicand)
        if root*root<radicand: root+=1
        ans+=F(root,factorial(a[0])*factorial(a[1]))*h[0]**a[0]*h[1]**a[1]
    return ans


def transported_law(box,*,order=6,bits=192):
    center,h=side24_cell._box(box); prec=options(bits)
    lift,transform,polys=prepared_center(center,order,bits)
    m=tuple(eval_signed_poly({a:v[i] for a,v in polys['mean'].items()},h,bits) for i in range(12))
    c=tuple(tuple(eval_signed_poly({g:v[i][j] for g,v in polys['covariance'].items()},h,bits) for j in range(12)) for i in range(12))
    eps=tuple(remainder_bound(b,h,order) for b in side24.JETS)+(F(0),)*6+tuple(remainder_bound(b,h,order) for b in side24.HJETS)
    eta=tuple(sum((abs(t)*e for t,e in zip(row,eps)),F(0)) for row in transform['T'])
    sig=[]
    for i in range(12):
        if c[i][i].hi<0: raise ConditioningInconclusive('negative polynomial variance upper')
        sig.append(sqrt(I(0,c[i][i].hi),prec).round_out(bits).hi)
    errors=tuple(tuple(sig[i]*eta[j]+sig[j]*eta[i]+eta[i]*eta[j] for j in range(12)) for i in range(12))
    energyroot=sqrt(lift['conditioning_energy'],prec).round_out(bits).hi
    mean=tuple((m[i]+I(-energyroot*eta[i],energyroot*eta[i])).round_out(bits) for i in range(12))
    cov=tuple(tuple((c[i][j]+I(-errors[i][j],errors[i][j])).round_out(bits) for j in range(12)) for i in range(12))
    return dict(box=box,center=center,halfwidths=h,order=order,bits=bits,mean=mean,covariance=cov,
        mean_polynomial=m,covariance_polynomial=c,polynomials=polys,transform=transform,
        raw_remainder_upper=eps,transformed_remainder_upper=eta,covariance_error_upper=errors,
        mean_remainder_upper=tuple(energyroot*e for e in eta),
        conditioning_energy=lift['conditioning_energy'],six_pin_pivots=lift['six_pin_pivots'],
        source_binding=lift['source_binding'],target_count=lift['target_count'])


def density_cap(mean,cov,transform,bits):
    """Full transformed 3-jet density, whole original mark, Jacobian once."""
    prec=options(bits); factor=interval_ldlt(cov,round_bits=bits)
    mark=I(*side24.MARK_DOMAIN)
    raw=(side24.MID+mark,ZERO,ZERO)
    target=tuple(dot(row,raw,bits) for row in transform['T_Y'])
    delta=tuple((x-y).round_out(bits) for x,y in zip(target,mean))
    white=[]; q=ZERO; det=I.exact(1)
    for i in range(3):
        w=(delta[i]-dot(factor.lower[i][:i],white,bits)).round_out(bits)
        white.append(w)
        q=(q+w**2/factor.pivots[i]).round_out(bits)
        det=(det*factor.pivots[i]).round_out(bits)
    if q.lo<0 or det.lo<=0: raise ConditioningInconclusive('density positivity failed')
    # For q/2 >= k, e^{-q/2} <= 2^{-k}. Avoid enormous-denominator exp.
    k=min(1024,int(q.lo//2))
    if k>=128:
        exponential=I(0,F(1,2**k)); method='EXP_NEG_Q_OVER_TWO_LE_2_POW_NEG_FLOOR_Q_OVER_TWO'
    else:
        exponential=exp(I.exact(-q.lo/2),prec); method='CERTIFIED_EXP_AT_QUADRATIC_LOWER'
    jac=abs(transform['determinant_T_Y'])
    denom=(2*pi(prec)*sqrt(2*pi(prec)*det,prec)).round_out(bits)
    density=(jac*exponential/denom).round_out(bits)
    mass=(I.exact(side24.ELL)*density).round_out(bits)
    return dict(density_mass_upper=mass.hi,three_jet_density_upper=density.hi,
        mahalanobis=q,determinant=det,pivots=factor.pivots,
        determinant_T_Y=jac,density_jacobian_multiplicity=1,
        full_mark_domain=side24.MARK_DOMAIN,window_length=side24.ELL,
        exponential_upper=exponential.hi,exponential_method=method,exponential_power=k)


def cell_laws(box,*,order=6,bits=192):
    result=transported_law(box,order=order,bits=bits)
    mean,cov=result['mean'],result['covariance']; tr=result['transform']
    ymean=mean[:3]; ycov=tuple(tuple(row[:3]) for row in cov[:3])
    cross=tuple(tuple(row[:3]) for row in cov[3:]); hcov=tuple(tuple(row[3:]) for row in cov[3:])
    rhs0=tuple(row[0]*side24.MID for row in tr['T_Y']); rhs1=tuple(row[0] for row in tr['T_Y'])
    law=f'RN5:SIDE24:r=1/20:b=6/5:N{order}:cell=({box.u0},{box.u1},{box.v0},{box.v1}):original-Hessian:full-centered-mark'
    cond=condition_gaussian(ycov,cross,hcov,rhs0,rhs1,
        conditioning_order=('ZY:f','ZY:fx','ZY:fy'),target_order=tuple(f'ZH:{j}' for j in range(9)),
        covariance_law=law,mean_law=law,conditioning_law=law,mark_domain=side24.MARK_DOMAIN,
        prior_conditioning_intercept=ymean,prior_target_intercept=mean[3:],round_bits=bits)
    # Undo exact residual transformation: original H = LH ZH + A w(t).
    hc=[list(row) for row in congruence(tr['L_H'],cond.covariance,bits)]
    transformed_marginal_pivots={}
    # Certify SPD in the well-conditioned residual basis. A rational invertible
    # block congruence transports SPD; the independent original-entry hull
    # need not consist entirely of SPD matrices. Positive LDL square sums
    # also sharpen each original diagonal without cancellation.
    for label,start in (('M',0),('S',3),('y',6)):
        marginal=tuple(tuple(cond.covariance[i][j] for j in range(start,start+3)) for i in range(start,start+3))
        fac=interval_ldlt(marginal,round_bits=bits)
        transformed_marginal_pivots[label]=fac.pivots
        chol_image=matrix_product(tuple(tuple(tr['L_H'][i][j] for j in range(start,start+3)) for i in range(start,start+3)),fac.lower,bits)
        for i in range(3):
            for j in range(i+1):
                value=ZERO
                for k in range(3):
                    pair=chol_image[i][k]**2 if i==j else chol_image[i][k]*chol_image[j][k]
                    value=(value+pair*fac.pivots[k]).round_out(bits)
                refined=hc[start+i][start+j].intersect(value)
                if refined is None: raise ConditioningInconclusive('unwhitening LDL enclosure disjoint')
                hc[start+i][start+j]=hc[start+j][start+i]=refined
    hc=tuple(tuple(row) for row in hc)
    h0=tuple((dot(row,cond.intercept,bits)+tr['A'][i][0]*side24.MID).round_out(bits) for i,row in enumerate(tr['L_H']))
    h1=tuple((dot(row,cond.slope,bits)+tr['A'][i][0]).round_out(bits) for i,row in enumerate(tr['L_H']))
    context=Context(RN5_ID,RN5_SHA,2,('xx','yy','xy'),
        'SIDE24 normalized K(0)=1; original Hessian units',law,side24.MARK_DOMAIN)
    laws={}; pivots={}
    for name,start in (('M',0),('S',3),('y',6)):
        block=tuple(tuple(hc[i][j] for j in range(start,start+3)) for i in range(start,start+3))
        pivots[name]=transformed_marginal_pivots[name]
        laws[name]=FamilyLaw(context,h0[start:start+3],h1[start:start+3],block,law,law)
    return dict(result,laws=laws,marginal_pivots=pivots,jet_pivots=cond.pivots,
        joint_hessian_covariance=hc,joint_hessian_intercept=h0,joint_hessian_slope=h1,
        marginal_pivot_basis='TRANSFORMED_RESIDUAL; ORIGINAL_SPD_BY_INVERTIBLE_BLOCK_CONGRUENCE',
        transformed_conditional_intercept=cond.intercept,transformed_conditional_slope=cond.slope,
        transformed_conditional_covariance=cond.covariance,
        density=density_cap(ymean,ycov,tr,bits),imported_h3_floor=imported_h3_floor(),
        **FLAGS)


def spatial_cell(box,*,order=6,bits=192):
    from research.rn.certificate import ResourceLimit,canonical_bytes,produce,verify_bytes
    result=cell_laws(box,order=order,bits=bits)
    source=(side24.MIRROR/'RN5_NEAR_MOMENT_REPAIR.md').read_bytes()
    certs={}; replays={}; caps={}
    for name,degree in (('M',4),('S',4),('y',2)):
        law=result['laws'][name]; context=asdict(law.context)
        context['order']=list(context['order']); context['domain']=list(map(str,context['domain']))
        try: cert=produce(law,degree=degree,depth=2)
        except ResourceLimit as e: raise ConditioningResourceLimit('N6 moment resource limit: '+str(e)) from e
        replay=verify_bytes(canonical_bytes(cert),source_bytes=source,expected_context=context)
        if not replay['certificate_valid'] or not replay['requested_checks_passed']:
            raise ConditioningInconclusive('N6 moment replay failed: '+replay['reason'])
        certs[name]=cert; replays[name]=replay; caps[name]=F(cert['proof']['upper'])
    fourth=caps['M']*caps['S']*caps['y']**2
    holder=sqrt(sqrt(I.exact(fourth),options(bits)),options(bits)).round_out(bits)
    if holder.lo<0 or holder.hi**4<fourth: raise ValueError('Holder root failed')
    upper=(holder.hi*I.exact(result['density']['density_mass_upper'])/result['imported_h3_floor']['value']).round_out(bits).hi
    return dict(result,moment_certificates=certs,moment_replays=replays,moment_caps=caps,
        holder_fourth_power_upper=fourth,holder_upper=holder.hi,integrand_upper=upper,integrand_range=I(0,upper),
        spatial_method='SIGNED_N6_CENTER_JET_TAYLOR_WITH_EXACT_RATIONAL_PRECONDITIONING',
        quantifier='FOR_EVERY_Y_IN_CLOSED_RECTANGLE_AND_EVERY_MARK_IN_FULL_WINDOW')
