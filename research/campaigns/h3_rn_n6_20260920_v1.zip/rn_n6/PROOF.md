# RN N6 local Taylor transport candidate

This is an author-side mathematical successor, at fixed r=1/20, b=6/5 and
axis orientation. It proves local rectangle bounds conditional on the pinned
original H3 floor. It does not close D3-LEMMA-RN-UNIF, certify a complete
annulus or remote budget, provide an all-r theorem, promote a source claim,
solve any original prize problem, or earn organizational independence credit.
The two inner-edge squares cross the circle |y|=1/10; their entire-square
bounds remain valid, but no area allocation to an annulus is asserted.

## Field and conditioning

Use exactly the normalized SIDE24 covariance
K(x)=k(x1)k(x2), k(s)=sum_j exp(-(s+24j)^2/2)/Z, Z=sum_j exp(-(24j)^2/2).
The six fixed observations are (f,fx,fy) at M=(-1/40,0), S=(1/40,0), with
values c=(6/5,0,0,6/5-1/48000,0,0). The moving three-jet is prescribed as
w(t)=(MID+t,0,0), MID=6/5-1/96000, |t|<=1/96000. Hessians always have the
original units and order (xx,yy,xy). All archived inputs are authenticated as
bytes by the existing source binder; none of their programs executes.

For a rational center z, the targets comprise the six fixed Hessian entries
and D^a f(z), |a|<=8: 6+45=51 targets. With observation covariance G,
raw target covariance B and target/observation covariance K, form
C=B-K G^-1 K^T and m=K G^-1 c using one certified 6-by-6 LDL factor and
51 solves. No 51-by-51 inverse, or nonsingularity of the complete target
covariance, is needed. The derivative Gram representation of the normalized
Gaussian field and orthogonal projection off the observation span identify
a coherent joint PSD member. Independent interval entries are only enclosures.

The cross derivative sign is (-1)^|b| in
Cov(D^a f(p),D^b f(q))=(-1)^|b| product_i k^(a_i+b_i)(p_i-q_i).
Every individual evaluation has exact rational interval endpoints.

## Kernel orders 0 through 18, and the moment-cap theorem

Probabilists' Hermite polynomials satisfy
He_n(x)=n! sum_{j=0}^{floor(n/2)} (-1)^j x^(n-2j)/(2^j j! (n-2j)!),
and the Gaussian derivative is (-1)^n He_n(x) exp(-x^2/2).
The new evaluator uses the three images j=-1,0,1 and retains a symmetric
bound on every omitted image, then divides by the full positive Z. At zero,
k(0)=1 and odd derivatives vanish by exact normalization/evenness.

For |s|<=B<=18, C_n=sum of absolute Hermite coefficients and j>=2,
the jth paired image is at most
2 C_n (24j+B)^n exp(-(24j-B)^2/2).
Consecutive ratios decrease: both (24(j+1)+B)/(24j+B) and the exponential
ratio decrease. The ratio at j=2 is strictly below 1, verified with exact
interval exponential bounds. Thus the first omitted pair divided by one
minus that ratio bounds the whole tail. This proof applies uniformly for
every n=0,...,18; all numerator and normalization tails are retained.

For the order-seven Taylor remainder, an exact simpler stationary variance
bound suffices. For all n<=18, the exact coefficient sums satisfy
C_n<=10*18!<2^56, and 24^18<2^90. Since exp(1)>2 (its positive series already
starts 1+1), the first nonzero image pair at zero is less than 2^-141.
For j>=1 its consecutive ratio is at most 2^18*2^-864=2^-846<1/2.
The full nonzero-image tail is therefore less than 2^-140<1. Since Z>=1,
Var(D_x^k f)<(2k-1)!!+1 for k=1,...,9, while Var(f)=1 exactly.
`moment_cap_certificate` checks these integer/rational inequalities and
refuses a cap lacking the image allowance. The caps are
(1,2,4,16,106,946,10396,135136,2027026,34459426).
These are torus bounds, not substitutions of planar moments. Tests at 512
bits distinguish the normalized sixth derivative from both -15 and the
unnormalized three-image numerator.

## Exact rational transform, not an identity assumption

Use raw order (Y,H_M,H_S,H_y), Y=(f,fx,fy). At the center, approximate the
regression A=Cov(H,Y) Cov(Y)^-1 by an **exact rational matrix** A0.
Take exact rational nonsingular lower triangular matrices LY and LH from
rounded interval Cholesky approximations, LH block diagonal in the three
Hessian marginals. Define TY=LY^-1, W=LH^-1 and the exact rational transform

    ZY=TY Y, ZH=W(H-A0 Y), T=[[TY,0],[-W A0,W]].

The program verifies the exact rational identity T*T_inverse=I. It retains
the measured covariance T C T^T, including all cross-Hessian correlations;
no approximate whitening result is replaced by an exact identity matrix.
There is no assumption that the Hessian blocks are independent. The exact
choice of rational approximation affects tightness only, not the algebra.

## Signed coefficient aggregation

Let P_alpha select the lifted derivatives of the moving raw coordinates,
with weight 1/(alpha1! alpha2!), for |alpha|<=6. Fixed Hessian rows occur
only at alpha=0. The polynomial is P(delta)=sum_alpha P_alpha delta^alpha.
The transformed mean coefficients are T P_alpha m. Covariance coefficients
are

    C_gamma = T [sum_(alpha+beta=gamma) P_alpha C P_beta^T] T^T.

All terms of the same gamma are added **with their signs before** applying
spatial interval or absolute-value bounds. Both mixed terms are included.
This is a finite identity: 28 mean monomials, 91 covariance monomials, and
51 target functionals. On |delta_i|<=h_i, each polynomial lies in its
constant coefficient plus/minus the sum, over nonconstant gamma, of
|C_gamma| h1^gamma1 h2^gamma2. This may be conservative but preserves the
coefficient cancellations that the older O(h) covariance bound discards.

## Hilbert-space Taylor remainder and conditional mean

For a moving derivative D^b f, |b|<=2, apply one-dimensional integral Taylor
to the Hilbert-space-valued function s -> D^b f(z+s delta). The degree-six
remainder is (1/6!) integral_0^1 (1-s)^6 (delta dot D)^7 D^b f(z+s delta) ds.
Expanding the directional derivative and integrating gives exactly the
coefficient 1/alpha!, |alpha|=7. Minkowski and stationarity give

    ||R_b||_2 <= sum_(|alpha|=7) h^alpha/alpha!
                  sqrt(M_(2(b1+alpha1)) M_(2(b2+alpha2))).

Orthogonal projection off the six-pin span contracts this centered L2 norm.
For h1=h2=h, the exact integer square-root caps give, for b=(2,0),
71049/5040 h^7, and for b=(1,1), 53658/5040 h^7. Both are below 15h^7;
symmetry and monotonicity cover every moving value/gradient/Hessian row.
The implementation also supports orders 1 through 6 with the corresponding
order+1 remainder and bounded lifted derivative range.

Write Q=c^T G^-1 c, evaluated as a positive LDL square sum. Cauchy-Schwarz
with U=c^T G^-1 O proves |conditional mean remainder|<=sqrt(Q)*epsilon_b.
This is added **after** evaluation of the actual center mean polynomial;
it is O(h^7), not a replacement of that mean polynomial by a center constant.
Fixed raw Hessian rows have zero remainder. In transformed coordinates,
eta_i=sum_j |T_ij| epsilon_j. If sigma_i^2 bounds the complete polynomial
variance before remainder enlargement, then expanding the centered covariance
and applying Cauchy-Schwarz gives the extra symmetric error
sigma_i eta_j+sigma_j eta_i+eta_i eta_j. A negative purported upper variance
is refused. The mean gets the distinct error sqrt(Q)*eta_i.

## Conditioning, original units, and positivity

Partition the transported transformed covariance into Gz=Cov(ZY),
Bz=Cov(ZH,ZY), Vz=Cov(ZH), with means muY,muH. Certified positive Gz pivots
permit the usual Gaussian conditional law at ZY=TY*w(t):

    mZH(t)=muH+Bz Gz^-1 (TY*w(t)-muY),
    SZH=Vz-Bz Gz^-1 Bz^T.

The original Hessian law is exactly

    mH(t)=LH*mZH(t)+A0*w(t),   SH=LH*SZH*LH^T.

The +A0*w term is indispensable; an explicit mutant omitting it fails the
zero-width comparison with the existing direct nine-pin conditional law.
The mean remains affine in the **same full mark**. No separate extrema of
unrelated marks are silently identified.

Positive pivots are required for each of the three conditional **transformed
residual marginals**. The nonsingular blockwise congruence by LH proves SPD
of each actual original marginal. This does NOT prove every independent
matrix in the original entrywise hull SPD. To avoid cancellation in original
diagonal bounds, the implementation also transports the transformed marginal
LDL factors: each original variance is a sum of positive pivot-weighted
squares. Intersection with the ordinary congruence enclosure is valid because
both enclose the identical exact covariance. Cross-Hessian blocks remain.
The generic moment engine quantifies PSD members of an entrywise hull as
needed; the actual member is PSD by the field/projection/congruence proof.

## Density, finite representation, and moments

The physical density at the full three-jet w is

    pY(w)=|det TY| exp(-q/2) / ((2*pi)^(3/2) sqrt(det Gz)),
    q=(TY*w-muY)^T Gz^-1 (TY*w-muY).

An LDL sum of interval squares supplies a uniform nonnegative lower bound
for q over the rectangle and full mark. The density Jacobian occurs exactly
once. Multiply the supremum by ell=1/48000. For q_lower/2>=k>=128, k capped
at 1024, use the **larger** short rational 2^-k as exponential upper, justified
by exp(1)>2. This never changes an unrepresented positive bound to zero.
The x-axis pilot exercises this route with k=1024 and a strictly positive
final result. Other cases use the certified interval exponential.

The three source-bound portable witnesses enclose the fourth moments of the
M and S Hessian determinants and the second moment of the moving determinant
throughout the full mark. The existing generic verifier replays all three.
Hölder gives their product upper with exponents 1/4,1/4,1/2. Multiplying by
the density/window upper and dividing by the separately pinned original
H3 floor 0.0077592917375327855 gives a uniform typed-integrand upper.
No independence assumption is needed by Hölder. Area enters only when
reporting an integral over one explicitly declared whole square.

## Bounded validation and remaining gap

The deterministic replay tries only six predeclared N6 squares: one admitted
and one larger refused square at (1,1), (1/10,0), and (0,1/10). It compares
admission with the existing N0 method on these exact same squares, and
replays both N6 and the earlier N0 pilot at half-width 1/4000. Refusals stay in the
report. No search over an annulus, adaptive sweep, or coverage inference is
performed. Corners and centers are diagnostic cross-checks; the preceding
Taylor and interval argument supplies the continuum quantifier.

The remaining annulus needs a complete partition, exact boundary accounting,
zero pending cells, and remote-budget assembly. Narrow x-axis admission remains
a practical limitation. All-r transport and scientific review remain separate.
The same-provider technical tests carry organizational independence credit 0.
