import unittest
from fractions import Fraction as F
import check_energy as c

class EnergyTests(unittest.TestCase):
    def test_actual_law(self):
        self.assertEqual(c.prove()['uniform_energy_upper'],'1266466/160083')

    def test_scalar_inverse_order(self):
        a=F(231,386); g0=F(3,80); g=a*a*g0
        self.assertEqual(1/g,(1/g0)/(a*a))
        self.assertGreater(1/g,(1/g0)*(a*a))

    def test_cubic_observation_cannot_be_dropped(self):
        m,_=c.prior.moments()
        full=c.energy_formula(m);mutant=c.energy_formula(m,False)
        self.assertGreater(full.lo,mutant.hi+F(3,5))

    def test_negative_unsquared_margin_rejected(self):
        with self.assertRaisesRegex(ValueError,'positive before squaring'):
            c.contraction(F(1,20),F(100),F(19,100))

    def test_unproved_improved_constants_rejected(self):
        for args in [(F(1,20),F(1),F(19,100)),(F(1,20),F(31,20),F(1))]:
            with self.assertRaises(ValueError):c.contraction(*args)

    def test_scope_and_float_rejected(self):
        for r in [F(-1),F(1,19),0.05,True]:
            with self.assertRaises(ValueError):c.contraction(r)

    def test_nonzero_conditional_mean(self):
        # E=V, V variance1, observation2: Var(E|V)=0 but second moment4.
        self.assertGreater(F(2)**2,F(0))
        self.assertEqual(F(2)**2,F(1)*F(4))

    def test_second_moment_projection_extrema(self):
        # Exact worst case over removed variance x in [0,sigma²] occurs
        # at one endpoint; the wrong 'min' choice fails for Q>1 and Q<1.
        for q in [F(1,4),F(1),F(8)]:
            endpoints=[F(1),q]
            self.assertEqual(max(endpoints),max(F(1),q))
            if q!=1:self.assertGreater(max(endpoints),min(F(1),q))

if __name__=='__main__':unittest.main()
