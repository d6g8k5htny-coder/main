# Uniform energy of the actual six-pin values

For the normalized SIDE24 field and the fixed x-axis six-pin transform V from
the preceding H3 proof, let G(r)=Cov(V(r)) and v=(6/5,0,0,0,0,-1/6).
On the entire continuum 0<=r<=1/20,

    v^T G(r)^(-1) v < 3(76/45)^2 < 9.

This is a proved companion bound; it is not by itself an H3 or RN closure.
The law, full lattice tails and source identities are inherited through a
hash-checked replay of the preceding exact checker, not from a planar substitute.
Same-provider organizational independence credit is zero.

The preceding proof establishes G(0)>=(3/80)I and
||a·(V(r)-V(0))||_2 <= (31/20) r ||a|| for every vector a. Since
(19/100)^2<3/80, reverse triangle inequality gives

    ||a·V(r)||_2 >= [1-(155/19)r] ||a·V(0)||_2.

The bracket is positive throughout the stated domain and at its upper end
equals 45/76. Squaring proves the Loewner inequality
G(r)>=(45/76)^2 G(0). Inversion reverses the order for positive definite
matrices, hence G(r)^(-1)<=(76/45)^2 G(0)^(-1).

Write m_j for the exact normalized one-axis derivative moments. The two
nontrivial blocks of G(0) give the exact expression

    v^T G(0)^(-1)v
      = (36/25)m4/(m4-m2^2) + 4m2/(m2*m6-m4^2).

The first summand comes from the (f,fxx) block; the second comes from
(fx,-fxxx/12), whose observation is (0,-1/6). Its factor four includes
both the 1/12 coordinate scale and the nonzero cubic pin. The checker
independently computes the full six-dimensional LDL solve and checks
agreement. The exact torus value lies between 2.826 and 2.827, thus below3.

For any centered Gaussian functional E jointly distributed with V(r),
conditional regression and covariance Cauchy–Schwarz imply

    |E[E | V(r)=v]| <= ||E||_2 sqrt(v^T G(r)^(-1)v) <= 3||E||_2,
    Var(E | V(r)=v) <= ||E||_2^2,
    E[E^2 | V(r)=v] <= 10||E||_2^2.

Indeed, Cov(E,V)G^(-1)Cov(V,E)<=Var(E) by orthogonal projection, and
Cauchy–Schwarz in the G^(-1) inner product supplies the first bound.
These formulas apply to r-dependent linear remainders as well. They do not
require independence of different remainders, and make no assertion about
the nonlinear determinant or typed event without further proof.
