"""Exact uniform pin energy; companion to the actual SIDE24 H3 candidates."""
from fractions import Fraction as F
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
PRIOR = HERE.parent / 'h3_floor/support/check_h3_uniform.py'
PIN = 'ff61ec0785da6abb3190aa77626fdbe8d43988c21ae3470cca113af381a4ccbc'

def require(ok, message):
    if not ok:
        raise ValueError(message)

require(hashlib.sha256(PRIOR.read_bytes()).hexdigest() == PIN, 'prior checker changed')
spec = importlib.util.spec_from_file_location('energy_prior', PRIOR)
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
I = prior.I

def contraction(radius, transport=F(31,20), norm_floor=F(193,1000)):
    require(type(radius) is F and type(transport) is F and type(norm_floor) is F,
            'exact rational constants required')
    require(0 <= radius <= F(1,20), 'radius outside proved continuum')
    require(transport >= F(31,20) and 0 < norm_floor <= F(193,1000),
            'unproved transport or norm margin')
    a = 1 - transport * radius / norm_floor
    require(a > 0, 'relative covariance factor must be positive before squaring')
    return a

def energy_formula(m, include_axial_cubic=True):
    out = F(36,25)*m[4]/(m[4]-m[2]*m[2])
    if include_axial_cubic:
        out += 4*m[2]/(m[2]*m[6]-m[4]*m[4])
    return out.round_out(prior.BITS)

def prove():
    source = prior.custody()
    prior.prove()
    m, _ = prior.moments()
    gram = prior.limiting_gram(m)
    factor = prior.interval_ldlt(gram, round_bits=prior.BITS)
    v = (F(6,5), F(0), F(0), F(0), F(0), F(-1,6))
    solved = factor.solve(v)
    direct = sum((v[i]*solved[i] for i in range(6)), I.exact(0)).round_out(prior.BITS)
    formula = energy_formula(m)
    require(max(direct.lo,formula.lo) <= min(direct.hi,formula.hi),
            'independent block and six-pin energy formulas disagree')
    require(F(2826,1000) < formula.lo < formula.hi < F(2827,1000),
            'actual normalized energy not inside explicit bracket')
    require(F(193,1000)**2 < F(3,80), 'improved norm margin invalid')
    require(formula.hi < F(17,6), 'limiting energy ceiling17/6 failed')
    a = contraction(F(1,20))
    require(a == F(231,386), 'relative covariance factor mismatch')
    cap = F(17,6)/(a*a)
    require(cap < 8, 'whole-band pin energy not below8')
    return prior.encode({'schema':'side24-uniform-pin-energy-v1',
        'radius':'0 <= r <= 1/20', 'fixed_axis':'x', 'birth':F(6,5),
        'limiting_energy':formula, 'limiting_energy_direct_ldlt':direct,
        'relative_covariance_factor':a*a,'uniform_energy_upper':cap,
        'conditional_mean_multiplier_upper':F(3),
        'conditional_residual_second_moment_multiplier_upper':F(8),
        'source':source, 'prior_checker_sha256':PIN,
        'scientific_status_changed':False,'organizational_independence_credit':0,
        'not_established':['H3 floor or ceiling by this companion alone',
            'all-angle law','RN uniform closure','q0 closure','independent review']})

def encoded():
    return json.dumps(prove(), sort_keys=True, indent=2)+'\n'

if __name__ == '__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--repo',type=Path,default=prior.REPO)
    p.add_argument('--write',type=Path)
    p.add_argument('--verify',type=Path)
    args=p.parse_args()
    content=encoded()
    if args.write:
        with args.write.open('x') as out:out.write(content)
    if args.verify:
        require(args.verify.read_text()==content,'report differs from exact recomputation')
    print('PASS: uniform pin energy < 8; conditional residual second moment <= 8 epsilon squared')
