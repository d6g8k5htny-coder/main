# Sharper uniform pin energy and conditional second moments

This refines the companion derivation in PROOF.md. On the same actual
normalized SIDE24 six-pin, fixed-axis law, for every 0<=r<=1/20,

    Q(r)=v^T G(r)^(-1)v <= 1266466/160083 < 8.

The preceding exact replay shows G(0)>=(3/80)I and limiting pin energy
Q(0)<17/6. Choose the stronger norm margin 193/1000, whose square is
37249/1000000 < 3/80. The same Hilbert-space reverse triangle inequality
then gives

    G(r) >= [1-(1550/193)r]^2 G(0) >= (231/386)^2 G(0).

Inversion gives Q(r)<=(17/6)(386/231)^2=1266466/160083<8. Every comparison
and the limiting torus energy are replayed as exact rational intervals.

For a centered linear Gaussian functional E, put sigma²=Var(E) and
x=Cov(E,V)G^(-1)Cov(V,E). Orthogonal projection gives 0<=x<=sigma²,
conditional variance sigma²-x, and squared conditional mean at most Q(r)x.
Consequently

    E[E² | V=v] <= sigma² + (Q(r)-1)x
                <= max(1,Q(r)) sigma² <= 8 sigma².

This is sharper than adding separate variance and squared-mean ceilings,
which would give9. It permits no independence inference between remainders.
The mean bound |E[E|V=v]|<=sqrt(8)||E||₂<3||E||₂ also holds.

The checker independently compares block inversion to a full six-coordinate
LDL solve and replays the preceding full-tail H3 covariance proof. The report
result-v2.json is the current companion; result.json retains the preceding
weaker calculation for traceability. No H3 event bound, RN closure, all-angle
extension, canonical promotion or external-independent acceptance follows
from this lemma alone. Same-provider independence credit remains zero.
