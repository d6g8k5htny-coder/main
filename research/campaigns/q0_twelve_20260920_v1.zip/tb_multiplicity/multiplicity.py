"""Exact finite H0 merge filtration, with a separate rational rank oracle.

New author-side conditional lemma: this is not a verifier of Gaussian
genericity, continuum Morse reduction, or canonical Theorem B.
"""
from __future__ import annotations

import argparse
from fractions import Fraction as Q
import hashlib
import itertools
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
SOURCE_KEYS = ('LS-DER-037', 'LS-DER-039', 'LS-DER-040')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=False)


def rational(value):
    require(type(value) is str, 'levels must be exact rational strings')
    return Q(value)


def events(model):
    require(type(model) is dict and set(model) == {'vertices', 'edges'}, 'model schema')
    require(type(model['vertices']) is list and model['vertices'], 'nonempty vertex list')
    require(type(model['edges']) is list, 'edge list')
    ids, vertices, result = set(), {}, []
    for vertex in model['vertices']:
        require(type(vertex) is dict and set(vertex) == {'id', 'level'}, 'vertex schema')
        i = vertex['id']
        require(type(i) is str and i and i not in ids, 'unique nonempty event IDs')
        ids.add(i)
        vertices[i] = rational(vertex['level'])
        result.append((vertices[i], i, 'birth', None))
    for edge in model['edges']:
        require(type(edge) is dict and set(edge) == {'id', 'level', 'ends'}, 'edge schema')
        i, uv = edge['id'], edge['ends']
        require(type(i) is str and i and i not in ids, 'unique nonempty event IDs')
        ids.add(i)
        require(type(uv) is list and len(uv) == 2 and all(type(v) is str and v in vertices for v in uv), 'binary edge endpoints')
        level = rational(edge['level'])
        require(all(vertices[v] > level for v in uv), 'edge before endpoint birth')
        result.append((level, i, 'edge', tuple(uv)))
    require(len({e[0] for e in result}) == len(result), 'distinct event levels required')
    return sorted(result, reverse=True)


def analyze(model):
    schedule = events(model)
    values = {v['id']: rational(v['level']) for v in model['vertices']}
    parent, born, dead, pairs, loops = {}, {}, {}, [], []

    def find(v):
        while parent[v] != v:
            v = parent[v]
        return v

    for step, (level, event_id, kind, ends) in enumerate(schedule, 1):
        if kind == 'birth':
            parent[event_id] = event_id
            born[event_id] = step
            continue
        a, b = map(find, ends)
        if a == b:
            loops.append(event_id)
            continue
        elder, younger = sorted((a, b), key=values.__getitem__, reverse=True)
        require(younger not in dead, 'a representative cannot die twice')
        dead[younger] = step
        pairs.append({'maximum': younger, 'saddle': event_id,
                      'birth': str(values[younger]), 'death': str(level),
                      'lifetime': str(values[younger] - level),
                      'adjacent_in_graph': younger in ends})
        parent[younger] = elder
    essential = sorted(v for v in values if find(v) == v)
    require(len(pairs) == len(values) - len(essential), 'merge count identity')
    require(len({p['maximum'] for p in pairs}) == len(pairs), 'unit maximum multiplicity')
    require(len({p['saddle'] for p in pairs}) == len(pairs), 'unit saddle multiplicity')
    require(set(p['maximum'] for p in pairs).isdisjoint(essential), 'essential class excluded')
    return {'pairs': pairs, 'loop_edges': loops, 'essential_maxima': essential,
            'birth_steps': born, 'death_steps': dead, 'event_count': len(schedule)}


def matrix_rank(columns, rows):
    """Rational Gaussian elimination; no union-find or elder labels used."""
    if not columns:
        return 0
    a = [[Q(c[i]) for c in columns] for i in range(rows)]
    rank = 0
    for col in range(len(columns)):
        pivot = next((i for i in range(rank, rows) if a[i][col]), None)
        if pivot is None:
            continue
        a[rank], a[pivot] = a[pivot], a[rank]
        pivot_value = a[rank][col]
        a[rank] = [x / pivot_value for x in a[rank]]
        for i in range(rows):
            if i != rank and a[i][col]:
                factor = a[i][col]
                a[i] = [x - factor * y for x, y in zip(a[i], a[rank])]
        rank += 1
        if rank == rows:
            break
    return rank


def rank_oracle(model, i, j):
    """Rank H0(G_i)->H0(G_j) as rank[B_j,E_i]-rank B_j."""
    schedule = events(model)
    require(0 <= i <= j <= len(schedule), 'rank indices')
    labels = [e[1] for e in schedule[:j] if e[2] == 'birth']
    indices = {v: k for k, v in enumerate(labels)}
    boundary, earlier = [], []
    for _, event_id, kind, ends in schedule[:j]:
        if kind == 'edge':
            col = [0] * len(labels)
            col[indices[ends[0]]] += 1
            col[indices[ends[1]]] -= 1
            boundary.append(col)
    for _, event_id, kind, _ in schedule[:i]:
        if kind == 'birth':
            col = [0] * len(labels)
            col[indices[event_id]] = 1
            earlier.append(col)
    return matrix_rank(boundary + earlier, len(labels)) - matrix_rank(boundary, len(labels))


def verify_rank_identity(model, result=None):
    result = analyze(model) if result is None else result
    n = len(events(model))
    checked = 0
    for i in range(n + 1):
        for j in range(i, n + 1):
            barcode_rank = sum(birth <= i and result['death_steps'].get(v, n + 1) > j
                               for v, birth in result['birth_steps'].items())
            require(barcode_rank == rank_oracle(model, i, j), f'barcode rank mismatch at {i},{j}')
            checked += 1
    return checked


def fixture_nonadjacent():
    return {'vertices': [{'id': v, 'level': str(h)} for v, h in zip('abcd', (10, 9, 8, 7))],
            'edges': [{'id': 's6', 'level': '6', 'ends': ['c', 'd']},
                      {'id': 's5', 'level': '5', 'ends': ['b', 'c']},
                      {'id': 's4', 'level': '4', 'ends': ['a', 'd']},
                      {'id': 's3loop', 'level': '3', 'ends': ['a', 'a']}]}


def fixture_disconnected():
    return {'vertices': [{'id': 'a', 'level': '3'}, {'id': 'b', 'level': '2'}], 'edges': []}


def fixture_two():
    return {'vertices': [{'id': 'a', 'level': '3'}, {'id': 'b', 'level': '2'}],
            'edges': [{'id': 's', 'level': '1', 'ends': ['a', 'b']}]}


def family_models():
    """All 6 edge orders of a labelled triangle; all legal interleavings of a 3-leaf tree."""
    triangle = [('a', 'b'), ('b', 'c'), ('a', 'c')]
    for order in itertools.permutations(triangle):
        yield {'vertices': [{'id': v, 'level': str(h)} for v, h in zip('abc', (6, 5, 4))],
               'edges': [{'id': f's{k}', 'level': str(3-k), 'ends': list(uv)} for k, uv in enumerate(order)]}
    for order in itertools.permutations(('a', 'b', 'c', 's', 't')):
        rank = {v: k for k, v in enumerate(order)}
        if not (rank['s'] > max(rank['a'], rank['b']) and rank['t'] > max(rank['b'], rank['c'])):
            continue
        yield {'vertices': [{'id': v, 'level': str(5-rank[v])} for v in 'abc'],
               'edges': [{'id': e, 'level': str(5-rank[e]), 'ends': uv}
                         for e, uv in [('s', ['a', 'b']), ('t', ['b', 'c'])]]}


def verify_sources(source_root):
    records = []
    binding = json.loads((ROOT / 'SOURCE_HASHES.json').read_text())
    for key in SOURCE_KEYS:
        record = binding[key]
        directory = source_root / key
        for name, identity in record['files'].items():
            data = (directory / name).read_bytes()
            require(len(data) == identity['bytes'] and hashlib.sha256(data).hexdigest() == identity['sha256'], f'source identity mismatch {key}/{name}')
        native = json.loads((directory / 'IDENTITY.json').read_text())
        require(native['drive_id'] == record['drive_id'], f'Drive identity {key}')
        require(native['coverage']['sha256'] == record['files']['source.docx']['sha256'], f'export identity {key}')
        require(native['reading_sha256'] == record['files']['reading.txt']['sha256'], f'reading identity {key}')
        records.append({'key': key, 'drive_id': record['drive_id'], 'native_export_sha256': record['files']['source.docx']['sha256'], 'derived_reading_sha256': record['files']['reading.txt']['sha256']})
    return records


def make_result(source_root):
    source_records = verify_sources(source_root)
    model = fixture_nonadjacent()
    analysis = analyze(model)
    models = [model, fixture_disconnected(), fixture_two(), *family_models()]
    rank_checks = sum(verify_rank_identity(m) for m in models)
    selected = len(analysis['pairs'])
    typed = sum(rational(v['level']) > rational(e['level']) for v in model['vertices'] for e in model['edges'])
    adjacent_selected = sum(p['adjacent_in_graph'] for p in analysis['pairs'])
    require((selected, typed, adjacent_selected) == (3, 16, 2), 'counterexample count')
    require(analysis['pairs'][-1]['maximum'] == 'b' and analysis['pairs'][-1]['saddle'] == 's4', 'nonadjacent elder pair')
    require(len(analyze(fixture_disconnected())['essential_maxima']) == 2, 'connectedness counterexample')
    require(Q(1, 2) * len(analyze(fixture_two())['pairs']) != 1, 'half-factor counterexample')
    return {'schema': 'tb-multiplicity-candidate-v1',
            'target': 'Q0-P12-TB-MULTIPLICITY-20260920-v1',
            'technical_result': 'CONDITIONAL DETERMINISTIC AND BOREL MEASURE LEMMA',
            'claims': {'binary_merge_unit_multiplicity': True, 'elder_pair_bar_bijection': True,
                       'selected_measure_dominated_by_typed_measure': True,
                       'requires_factor_one_half': False, 'adjacency_only_is_exhaustive': False},
            'counterexample': {'model': model, 'analysis': analysis, 'all_typed_pairs': typed,
                              'selected_pairs': selected, 'adjacent_selected_pairs': adjacent_selected,
                              'nonadjacent_selected_pairs': selected-adjacent_selected,
                              'adjacency_branch_incidence_at_loop': 2, 'adjacency_pair_atoms_at_loop': 1,
                              'persistence_atoms_at_loop': 0},
            'finite_validation': {'models': len(models), 'exact_rank_equalities': rank_checks,
                                  'arithmetic': 'fractions.Fraction; no floats'},
            'sources': source_records,
            'remaining_hypotheses': ['Actual continuum field has the declared binary H0 event reduction.',
                                     'Actual field law admits the declared Borel finite event charts.',
                                     'Generic locus has full probability if the fail-closed process is to equal all field bars.',
                                     'Any claimed density requires a sigma-finite absolutely continuous all-typed intensity.'],
            'not_established': ['Gaussian Morse/Morse-Smale genericity', 'Continuum model realization of the finite counterexample',
                                'Kac-Rice formula or covariance estimates', 'Contact Jacobian or lifetime tail bounds',
                                'Selection tends to one', 'Complete Theorem B', 'Canonical restoration'],
            'original_prize_closed': False, 'canonical_promotion': False,
            'organizational_independence_credit': 0,
            'canonical_theorem_b_status': 'RETRACTED / NOT RESTORED'}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--sources', type=Path, default=ROOT.parent / 'sources')
    parser.add_argument('--candidate', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    try:
        result = make_result(args.sources)
        if args.candidate:
            observed = json.loads(args.candidate.read_text())
            require(canonical(observed) == canonical(result), 'candidate does not exactly match replay')
        if args.output:
            with args.output.open('x') as stream:
                json.dump(result, stream, indent=2, ensure_ascii=False, sort_keys=True)
                stream.write('\n')
        checks = result['finite_validation']
        print(f"PASS tb-multiplicity: {checks['models']} finite models, {checks['exact_rank_equalities']} exact rank identities; conditional continuum interface only")
        return 0
    except (ValueError, OSError, KeyError, TypeError) as exc:
        print(f'FAIL tb-multiplicity: {exc}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
