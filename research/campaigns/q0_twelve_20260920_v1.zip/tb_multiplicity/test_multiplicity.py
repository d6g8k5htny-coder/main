"""Semantic negative controls and subprocess rejection tests; stdlib only."""
import copy
from fractions import Fraction as Q
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

import multiplicity as m


class MultiplicityTests(unittest.TestCase):
    def test_two_birth_bar(self):
        result = m.analyze(m.fixture_two())
        self.assertEqual(result['pairs'], [{'maximum': 'b', 'saddle': 's', 'birth': '2',
                                          'death': '1', 'lifetime': '1', 'adjacent_in_graph': True}])
        self.assertEqual(result['essential_maxima'], ['a'])
        m.verify_rank_identity(m.fixture_two())

    def test_all_legal_interleavings(self):
        models = list(m.family_models())
        self.assertGreater(len(models), 10)
        for model in models:
            m.verify_rank_identity(model)

    def test_nonadjacency_counterexample(self):
        result = m.analyze(m.fixture_nonadjacent())
        self.assertEqual([(p['maximum'], p['saddle']) for p in result['pairs']], [('d', 's6'), ('c', 's5'), ('b', 's4')])
        self.assertFalse(result['pairs'][-1]['adjacent_in_graph'])
        self.assertEqual(result['loop_edges'], ['s3loop'])
        m.verify_rank_identity(m.fixture_nonadjacent())

    def test_older_dies_is_rejected_by_rank_oracle(self):
        model = m.fixture_two()
        bad = m.analyze(model)
        bad['death_steps'] = {'a': 3}
        with self.assertRaisesRegex(ValueError, 'barcode rank mismatch'):
            m.verify_rank_identity(model, bad)

    def test_omitted_nonadjacent_death_rejected(self):
        model = m.fixture_nonadjacent()
        bad = m.analyze(model)
        del bad['death_steps']['b']
        with self.assertRaisesRegex(ValueError, 'barcode rank mismatch'):
            m.verify_rank_identity(model, bad)

    def test_spurious_loop_death_rejected(self):
        model = m.fixture_nonadjacent()
        bad = m.analyze(model)
        bad['death_steps']['a'] = 8
        with self.assertRaisesRegex(ValueError, 'barcode rank mismatch'):
            m.verify_rank_identity(model, bad)

    def test_spurious_essential_death_rejected(self):
        model = m.fixture_disconnected()
        bad = m.analyze(model)
        bad['death_steps']['a'] = 2
        with self.assertRaisesRegex(ValueError, 'barcode rank mismatch'):
            m.verify_rank_identity(model, bad)

    def test_connectedness_needed(self):
        result = m.analyze(m.fixture_disconnected())
        self.assertEqual(result['essential_maxima'], ['a', 'b'])
        self.assertEqual(result['pairs'], [])

    def test_half_factor_fails_exact_count(self):
        self.assertNotEqual(Q(1, 2) * len(m.analyze(m.fixture_two())['pairs']), Q(1))

    def test_ties_rejected(self):
        model = m.fixture_two()
        model['vertices'][1]['level'] = '3'
        with self.assertRaisesRegex(ValueError, 'distinct event levels'):
            m.analyze(model)

    def test_triple_merge_rejected(self):
        model = m.fixture_two()
        model['edges'][0]['ends'].append('a')
        with self.assertRaisesRegex(ValueError, 'binary edge endpoints'):
            m.analyze(model)

    def test_premature_attachment_rejected(self):
        model = m.fixture_two()
        model['edges'][0]['level'] = '5/2'
        with self.assertRaisesRegex(ValueError, 'edge before endpoint birth'):
            m.analyze(model)

    def test_levels_reject_floats_and_bools(self):
        for value in (3.0, True, 3):
            model = m.fixture_two()
            model['vertices'][0]['level'] = value
            with self.assertRaisesRegex(ValueError, 'exact rational strings'):
                m.analyze(model)

    def test_duplicate_labels_rejected(self):
        model = m.fixture_two()
        model['edges'][0]['id'] = 'a'
        with self.assertRaisesRegex(ValueError, 'unique nonempty event IDs'):
            m.analyze(model)

    def test_loop_has_two_incidences_one_pair_zero_deaths(self):
        model = m.fixture_nonadjacent()
        loop = model['edges'][-1]
        self.assertEqual(len(loop['ends']), 2)
        self.assertEqual(len(set(loop['ends'])), 1)
        self.assertFalse(any(p['saddle'] == loop['id'] for p in m.analyze(model)['pairs']))

    def test_cutoff_partition_includes_boundary(self):
        distances, cutoff = [Q(1, 2), Q(1), Q(3, 2)], Q(1)
        correct = sum(d < cutoff for d in distances) + sum(d >= cutoff for d in distances)
        wrong = sum(d < cutoff for d in distances) + sum(d > cutoff for d in distances)
        self.assertEqual(correct, len(distances))
        self.assertNotEqual(wrong, len(distances))

    def test_lifetime_pushforward_retains_multiplicity(self):
        model = {'vertices': [{'id': 'a', 'level': '9'}, {'id': 'b', 'level': '7'}, {'id': 'c', 'level': '6'}],
                 'edges': [{'id': 's', 'level': '3', 'ends': ['a', 'b']}, {'id': 't', 'level': '2', 'ends': ['a', 'c']}]}
        lifetimes = [p['lifetime'] for p in m.analyze(model)['pairs']]
        self.assertEqual(lifetimes, ['4', '4'])
        self.assertNotEqual(len(lifetimes), len(set(lifetimes)))
        m.verify_rank_identity(model)

    def test_rank_oracle_fraction_exact(self):
        self.assertEqual(m.matrix_rank([[Q(1, 3), Q(2, 3)], [Q(1), Q(2)]], 2), 1)


class CLINegativeControls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.original = json.loads((m.ROOT / 'result.json').read_text())

    def run_cli(self, *args):
        mode = ['-O'] if sys.flags.optimize else []
        return subprocess.run([sys.executable, '-B', *mode, str(m.ROOT / 'multiplicity.py'), *map(str, args)],
                              capture_output=True, text=True, timeout=120)

    def mutation(self, change):
        value = copy.deepcopy(self.original)
        change(value)
        with tempfile.TemporaryDirectory(prefix='negative-', dir=m.ROOT) as folder:
            file = Path(folder) / 'mutated.json'
            file.write_text(json.dumps(value))
            run = self.run_cli('--candidate', file)
            self.assertNotEqual(run.returncode, 0, run.stdout)
            self.assertIn('candidate does not exactly match replay', run.stderr)

    def test_positive_cli(self):
        result = self.run_cli('--candidate', m.ROOT / 'result.json')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('PASS tb-multiplicity', result.stdout)

    def test_half_factor_mutation(self):
        self.mutation(lambda r: r['claims'].__setitem__('requires_factor_one_half', True))

    def test_adjacency_completeness_mutation(self):
        self.mutation(lambda r: r['claims'].__setitem__('adjacency_only_is_exhaustive', True))

    def test_essential_inclusion_mutation(self):
        self.mutation(lambda r: r['counterexample']['analysis']['pairs'].append({'maximum': 'a', 'saddle': 's3loop'}))

    def test_drop_nonadjacent_pair_mutation(self):
        self.mutation(lambda r: r['counterexample']['analysis']['pairs'].pop())

    def test_source_identity_mutation(self):
        self.mutation(lambda r: r['sources'][0].__setitem__('native_export_sha256', '0' * 64))

    def test_unsupported_promotion_mutation(self):
        self.mutation(lambda r: r.__setitem__('canonical_promotion', True))

    def test_independence_mutation(self):
        self.mutation(lambda r: r.__setitem__('organizational_independence_credit', 1))

    def test_bool_int_alias_mutation(self):
        self.mutation(lambda r: r.__setitem__('canonical_promotion', 0))

    def test_actual_source_corruption_cli(self):
        with tempfile.TemporaryDirectory(prefix='source-negative-', dir=m.ROOT) as folder:
            root = Path(folder)
            for key in m.SOURCE_KEYS:
                shutil.copytree(m.ROOT.parent / 'sources' / key, root / key)
            file = root / 'LS-DER-037' / 'reading.txt'
            file.write_bytes(file.read_bytes() + b'\nmutation\n')
            run = self.run_cli('--sources', root, '--candidate', m.ROOT / 'result.json')
            self.assertNotEqual(run.returncode, 0)
            self.assertIn('source identity mismatch', run.stderr)

    def test_output_overwrite_rejected(self):
        with tempfile.TemporaryDirectory(prefix='overwrite-', dir=m.ROOT) as folder:
            target = Path(folder) / 'existing.json'
            target.write_text('retained')
            run = self.run_cli('--output', target)
            self.assertNotEqual(run.returncode, 0)
            self.assertEqual(target.read_text(), 'retained')


if __name__ == '__main__':
    unittest.main()
