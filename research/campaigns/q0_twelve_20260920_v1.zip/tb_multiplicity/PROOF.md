# Directed elder selection and finite-bar counting

Author-side candidate, 2026-09-20. Target `Q0-P12-TB-MULTIPLICITY-20260920-v1`.
This proves a deterministic lemma under an explicit H0 event interface and
its measurable-family extension. It changes no canonical status. Theorem B
remains **RETRACTED / NOT RESTORED**. Independence credit is zero.

## 1. Source boundary and the new step

LS-DER-037 §1 explicitly says it does **not** re-prove the externally approved
unit-multiplicity theorem. Its §8 imports that theorem, and LS-DER-039/040
use the resulting selected-pair process. We give a self-contained elementary
proof of the finite event statement, rather than treating the imported
review label as a proof. The sources establish provenance and the intended
interface; their substantive continuum hypotheses are not certified here.

`SOURCE_HASHES.json` binds the three native DOCX export snapshots and their
derived paragraph readings. The latter are **not** the declared frozen body
bytes. The source's embedded BODY_SHA256 is not substituted for a hash of
the downloaded DOCX or the extracted reading. Native revision metadata was
observed after export; the export was not revision-addressed.

## 2. Precise deterministic interface

Let `V_0 -> V_1 -> ... -> V_N` be ordinary H0 over an arbitrary field, with
the parameter advancing as the superlevel threshold decreases. Assume:

1. There are finitely many events with distinct real levels, in strictly
   decreasing order. Initially the superlevel set is empty.
2. At a birth event, one new connected component is created, carrying one
   distinct label M, called a maximum. It has birth level b(M).
3. At an attachment event S, either two **different** existing components
   join, or a single component receives an attachment. In the first case
   the H0 map identifies their two component basis vectors and is the
   identity on the others. In the second case the H0 map is an isomorphism.
   No component disappears by any other mechanism.
4. Other events, if present, induce H0 isomorphisms. They may be omitted
   from the indexed module without affecting the nontrivial events.
5. The final space is connected. For a final space with c components, replace
   the unique essential class below by c essential classes.

For a compact connected surface, the intended application is the ordinary
superlevel H0 module of a Morse function with distinct critical values:
maxima give births and index-one saddles give the binary attachments. That
identification is an explicit **application hypothesis** here, not something
established by the finite program. Neither an almost-sure genericity theorem
for the Gaussian field nor a proof of a measurable Morse atlas is supplied.

Each current component has an elder representative: the maximum in that
component with largest birth level. At a merge retain the elder of the two
representatives and pair the younger representative M with the attachment S.
Write `D(M)=S`. A self-attachment, including a loop event, creates no pair.
Every selected pair has b(M)>d(S), so its lifetime is strictly positive.

## 3. Unit multiplicity theorem and proof

**Theorem.** Under the interface above, the map D is a bijection from
nonessential birth representatives to merging attachment events. Its pairs
are exactly the finite ordinary H0 persistence bars, with birth b(M) and
death d(D(M)). There is one essential representative per final component.
When the final space is connected, that representative is the unique global
maximum. In particular, there are `number of maxima - 1` finite bars.

**Proof of the counting and labels.** Induct over events. A birth adds a new
representative. A merge of different components kills exactly one current
representative and retains exactly one; no killed label can return as a
representative, since components only join. The retained label is the
largest birth in the union, preserving the invariant. A self-attachment
changes neither representatives nor their count. At the end one label
survives per component, and every other label has died exactly once. Each
merge kills one label, so this is a bijection. In the connected case the
survivor is the largest of all birth levels. This proves the claimed
cardinalities and excludes loop events and the essential class.

**Identification with persistence, rather than just a count.** Let `C_i`
denote the set of components after event i. The map H0 at i to H0 at j,
where i<=j, sends each component basis vector to the basis vector of its
unique descendant. Its rank is the number of components at j containing
at least one component present at i.

For each such component at j, its elder label was born no later than i:
it contains some label born by i, and its oldest birth is at least that old.
That elder has not died by j. Conversely, a label born by i and not dead
by j represents exactly one such component. Hence

    rank(V_i -> V_j)
       = # {M : birth_step(M)<=i and death_step(M)>j},

with death_step=N+1 for surviving labels. The right side is exactly the
rank invariant of the direct sum of the proposed interval modules. This
identifies the barcode: for a finite sequence of finite-dimensional vector
spaces the multiplicity of [a,d), for a<d<=N, is recovered from ranks by

    m(a,d) = R(a,d-1)-R(a-1,d-1)-R(a,d)+R(a-1,d).

The surviving multiplicity at birth a is `R(a,N)-R(a-1,N)`.
These formulas follow directly by substituting the indicator
`1{birth<=i, death>j}` into the four terms: it is one precisely for birth a
and death d, and zero otherwise. Equivalently, interval decomposition of
a finite linear persistence module is obtained by Gaussian elimination of
its maps. Here the rank calculation verifies every interval endpoint,
not merely the total number of bars. QED.

The theorem permits several deaths at different events to have equal
lifetimes. The barcode is a **multiset**. Forgetting labels and storing only
a set of lifetime values can erase multiplicity even when each labelled
birth-death pair occurs once.

## 4. Pair measures and direction

Let `T=Max x Sad_1` consist of typed pairs with b(M)>d(S), optionally
restricted by any fixed Borel spatial domain. Let z(M,S) be a measurable
geometric mark retaining the oriented pair, birth and death values. Define

    Xi_all = sum_(M,S in T) delta_z(M,S),
    Xi_sel = sum_(M,S in T) 1{D(M)=S} delta_z(M,S).

Both coordinates have different types. Reversing (M,S) produces a
saddle-maximum pair outside T. Thus each pair in the bijection contributes
once and **there is no factor 1/2**. This conclusion is about the counting
domain, independent of any angular coordinates or symmetry.

Let L(z)=b-d. By §3, without a spatial restriction,

    L_* Xi_sel = sum_(finite ordinary H0 bars beta) delta_length(beta).

With a restriction, this is precisely the submultiset whose unique selected
pair lies in that restriction. Every Borel set B satisfies
`0 <= Xi_sel(B) <= Xi_all(B)`. A second Boolean mark A, e.g. existential
direct adjacency, gives the exact decomposition

    Xi_sel = Xi_(A and sel) + Xi_(not A and sel).

This never licenses dropping the second summand. If two branch incidences
share the same maximum and saddle, existential adjacency is one Boolean
pair mark, not a count of two branches. A loop can have that mark but still
has selection mark zero.

For any cutoff r_c, the sets `distance<r_c` and `distance>=r_c` form an
exact disjoint partition of Xi_sel. **No zero-boundary assumption is needed
for this pathwise identity.** It is needed only to change one convention
to `distance<=r_c` without assigning the equality set to the other side.
This distinction isolates a needless hypothesis from the counting step in
LS-DER-040 §2; it does not assess that source's analytic density argument.

## 5. A sufficient measurable-family interface

Let F be a standard Borel parameter space and G a Borel good locus. Suppose
G has a countable Borel cover with finite labelled event data on each chart:

- the number of birth and attachment labels is fixed on a chart;
- event levels and point locations are Borel functions;
- event types and the component attachment/endpoint data are Borel maps
  into their finite discrete sets;
- the strict-level and binary-event hypotheses in §2 hold;
- these local data describe the same labelled geometric filtration on
  overlaps, up to a relabelling preserving points, levels and incidence.

Ordering the finitely many distinct event levels uses finitely many Borel
comparisons. At every finite algorithm step the component partition and
elder label are maps into finite discrete sets, obtained by Borel case
distinctions. Induction therefore proves that `1{D(M)=S}` is Borel on each
chart. Form the disjoint Borel partition `B_n=U_n \ union_(k<n) U_k` and use
the data of U_n on B_n. Invariance under relabelling makes the output
geometric measure independent of the chosen chart. This proves global
measurability; **local constancy is not needed** under this interface.

Let E be a standard Borel geometric mark space. For every Borel B in E,
the evaluation Xi(B) is a finite sum of Borel indicators on each B_n, hence
Borel globally. This is exactly a measurable finite point-measure-valued
map for the evaluation sigma algebra. The zero measure outside G is a
Borel extension. On a locally compact second-countable mark space this
also gives the usual Borel structure associated with vague point measures.
No unproved local compactness of an abstract mark space is required for
the evaluation formulation.

For the near polar mark, explicitly assume continuous distance and a Borel
short-logarithm/angle chart on `0<distance<rho<inj(X)`. On this domain
`kappa=6(b-d)/r^3` is Borel. The half-open argument is only required to be
Borel. The distance zero set, cut locus and chart complement must be
assigned a separate Cartesian mark or excluded from the near process;
excluding them from the near process does not prove their absence from a
complete process.

If adjacency is used, it is an **additional** Borel mark. Sufficient
dynamical inputs are Borel branch representatives, a jointly Borel flow
with continuous time paths, and Borel maximum positions. For either branch
z and maximum M, convergence is the Borel event

    intersection_(k>=1) union_(N>=1) intersection_(q rational, q>=N)
      { dist(Phi(f,q,z(f)),M(f)) < 1/k }.

Convergence implies this formula. In the reverse direction continuity
extends the rational inequalities to non-strict inequalities at real times;
choosing a larger k then gives convergence. Taking the union of the two
branch events is invariant under swapping representatives' orientation.
Independence from the particular point on a branch additionally requires
that two such points differ by finite flow time, as assumed in the source.
None of these dynamical inputs is required for the elder-only count.

## 6. First moments and the exact limitation of density statements

For any probability law on F the expectations of the point measures are
measures (possibly infinite). Nonnegative summation gives

    E[L_*Xi_sel] = L_*E[Xi_sel],
    E[Xi_sel] <= E[Xi_all],
    E[Xi_sel] = E[Xi_(A and sel)] + E[Xi_(not A and sel)].

If the all-typed first moment mu_all is sigma-finite, the dominated selected
measure has a Radon–Nikodym derivative p in [0,1], mu_all-a.e. If additionally
mu_all has density J with respect to a specified reference measure, then
the selected density is `K=Jp` a.e. This conclusion uses the **same typed
counting measure**. It does not identify p with conditioning the original
field probability on null pins; the applicable conditional object is the
all-typed Campbell/Palm law. A Kac–Rice identification of that law is outside
this lemma. Neither pointwise values at all parameters nor a limit p->1
follow from domination.

To identify this fail-closed process with the complete Gaussian-field bar
process, one must still establish probability one of G, or bound all omitted
bars. Borel extension alone does not establish that fact. No finite test can
prove any of these continuum or probabilistic hypotheses.

## 7. Concrete counterexamples to weakened conventions

The executable examples are exact finite graph H0 filtrations satisfying
the corresponding stated finite hypotheses; no realization by the specific
Gaussian field, or by a Morse–Smale surface, is claimed.

**All typed pairs and adjacency-only selection.** Births a,b,c,d have levels
10,9,8,7. Add edges c--d at 6, b--c at 5, a--d at 4, and a self-loop a--a at
3. Elder pairs are `(d,s6),(c,s5),(b,s4)` with lifetimes 1,3,5. There are
16 positive-gap typed maximum–edge pairs but only three finite bars. The
last selected pair (b,s4) is not a graph-endpoint adjacency: the incident
endpoint d lies in the component represented by b. Filtering selected pairs
by endpoint adjacency loses that bar. This is a counterexample to a general
event-interface assertion that an adjacency restriction is exhaustive,
not a proof of nonadjacency probability for the actual field.

**Loop and branch incidence.** The loop a--a at 3 has two incident half-edges,
one existential adjacent maximum–edge pair, and zero H0 deaths. Counting
incidences as pair atoms doubles that adjacency atom; treating every saddle
as a death creates a spurious bar.

**Incorrect elder rule.** Births a at 3, b at 2, edge a--b at 1 have a single
finite bar [2,1]. Killing a instead leaves a purported essential birth at 2.
The rank from the state containing only a to the final state is one, while
the mutated bars predict zero. Thus cardinality alone cannot check elder
selection; the rank oracle detects this mutation.

**Half-factor.** The same two-vertex example has exactly one finite bar;
multiplying its one typed selected pair by 1/2 gives mass 1/2.

**Connectedness, ties and higher mergers.** Two vertices and no edge have
two essential classes, so the single-essential conclusion needs connectedness.
Equal birth values do not select a unique elder label unless a tie-breaking
rule is added (even when the unlabeled intervals happen to coincide).
One event joining three components drops H0 rank by two and cannot satisfy
one death per saddle. The checker rejects ties and nonbinary attachments.

**Cutoff equality.** A selected pair at exactly distance r_c belongs to the
far set under `< / >=`. Under `< / >` it is lost. This is why the exact
partition is stated before any zero-boundary argument.

## 8. Replay and scope

`multiplicity.py` implements the elder algorithm and separately checks each
finite barcode against exact rational matrix ranks
`rank[B_j,E_i]-rank(B_j)`, where B_j is the graph boundary matrix and E_i
contains the earlier vertex basis vectors. The rank oracle does not use
union-find or elder labels. It covers loop cycles, disconnected final states,
and every legal event interleaving of the fixed three-vertex path, as well
as every edge order of a triangle. These are finite validation, not a proof
by sampling of the abstract theorem.

`test_multiplicity.py` supplies semantic and CLI negative controls, including
an altered elder choice, omitted nonadjacent bar, spurious loop death,
spurious essential death, half weight, unsupported success claims, JSON
boolean/integer confusion, corrupted source bytes, ties and a triple merge.
All checks use explicit exceptions, so optimized Python cannot remove them.
`RUN.json` supplies portable argv; result comparison is typed canonical JSON.

Not established: full-probability genericity, the actual continuum event
interface or Borel atlas, the Kac–Rice/contact law, its Jacobian, covariance
or tail bounds, selection convergence, numerical coefficients, Theorem B
restoration, or any original prize problem. No gate changes or independence
credit follow from this candidate or its tests.
