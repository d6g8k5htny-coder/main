"""Exact semantic falsification and actual CLI mutation controls. No authority moves."""
from fractions import Fraction as F
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import pytest
import lpw_amplitude as a

@pytest.fixture(scope='module')
def report():
    return a.compute()

def cli(args, optimized=False, script=None):
    return subprocess.run([sys.executable,'-B']+(['-O'] if optimized else [])+
                          [str(script or (a.HERE/'lpw_amplitude.py'))]+list(map(str,args)),
                          capture_output=True,text=True,timeout=30,
                          env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})

def save(path,obj):
    path.write_text(json.dumps(obj,sort_keys=True)+'\n')
    return path

def test_positive_exact_ceilings(report):
    assert report['strict_rational_ceilings']['E_C4']=='536.605087'
    assert F(report['unconditional_field_bounds']['sharpened_E_C4_upper'])<F('536.605087')
    assert F(report['unconditional_field_bounds']['C3_fourth_upper_budget_improvement_lower'])>341
    assert F(report['unconditional_field_bounds']['C4_upper_budget_improvement_lower'])>6

def test_rayleigh_fourth_and_old_amplitude_identity():
    # Independent within-pair standard normals: E X4 = E Y4 = 3; E X2Y2 = 1.
    assert 3+2*1+3==8
    # Absolute normal moments: E|X|^3 E|Y| = 4/pi, twice with coefficient 4.
    p=a.pi(a.PREC)
    correct=12+32/p
    defective=12+16/p
    assert (correct-defective).lo>0
    # Correlated X=Y breaks Rayleigh: E (X2+Y2)^2=4*3=12.
    assert 4*3>8

def test_phase_rotation_bound_and_understated_amplitude():
    # cos=3/5, sin=4/5, (X,Y)=(3,4): the rho bound is attained.
    value=F(3)*F(3,5)+F(4)*F(4,5)
    assert value==5 and value*value==3*3+4*4
    assert value*value>F(3*3+4*4,2)  # rho/sqrt(2) is false.

def test_full_lattice_gaussian_covariance_not_half_mass():
    # Two independent opposite modes p_+=p_-=1/2 have Var=1 at zero.
    full=F(1,2)+F(1,2)
    assert full==1 and F(1,2)<full
    # Reusing the same xi at opposite modes gives Var=2, not 1.
    assert 4*F(1,2)==2

def test_max_norm_weight_covers_all_multiindices():
    for x,y in [(F(0),F(0)),(F(1,5),F(1,3)),(F(4),F(1,2)),(F(2),F(3))]:
        for p in (3,4):
            bound=max(F(1),abs(x),abs(y))**p
            assert all(abs(x)**i*abs(y)**j<=bound for i in range(p+1) for j in range(p+1-i))
    assert F(1)>F(0)**4  # dropping the 1 loses the zero mode / alpha=0.

def test_shell_factorization_by_direct_rational_square():
    # Positive arbitrary even weights; no Gaussian approximation is used.
    w={0:F(1),1:F(2,3),2:F(1,5),3:F(1,17)}
    for s in (1,2,3):
        direct=sum((w[abs(i)]*w[abs(j)] for i in range(-s,s+1) for j in range(-s,s+1)
                    if max(abs(i),abs(j))==s),F(0))
        qprev=1+2*sum((w[j] for j in range(1,s)),F(0))
        factored=4*w[s]*(qprev+w[s])
        assert direct==factored
        assert direct>2*w[s]*(qprev+w[s]) # missing two sides invalid.

def test_finite_lattice_multiplicity(report):
    assert report['lattice']['finite_lattice_points']==141**2

def test_tail_omission_is_mathematically_false():
    # At a shorter admissible cutoff, the first omitted shell overwhelms
    # interval rounding. A tail-free finite sum cannot bound the full sum.
    small=a.lattice(12)
    h,a0=a.interval(small['h']),a.interval(small['a'])
    p=4
    finite=a.interval(small['sums']['max_coordinate_4']['finite_numerator'])
    nextfinite=a.finite_max_shells(h,a0,13,p)
    assert nextfinite.lo>finite.hi
    zfinite,zfull,zrecord=a.normalization(h,a0,12)
    assert zfull.lo>zfinite.hi # full normalization is strictly larger.

def test_shell_tail_understatement_has_actual_shell_counterexample():
    h=a.rr(a.pi(a.PREC)/12); aa=a.rr(h*h/2); first=71
    previous=a.isum([a.I(1)]+[2*a.exp(-aa*F(s*s,2),a.PREC) for s in range(1,first)])
    w=a.exp(-aa*F(first*first,2),a.PREC)
    actualshell=4*w*(previous+w)*(h*first)**4
    tail,_=a.shell_tail(h,aa,4,first,'max_coordinate')
    assert actualshell.lo>tail.hi/100

def test_tail_ratio_decreasing_and_positive(report):
    for kind in ('source','max_coordinate'):
        for p in (3,4):
            h=a.interval(report['lattice']['h']); aa=a.interval(report['lattice']['a'])
            _,r71=a.shell_tail(h,aa,p,71,kind)
            _,r72=a.shell_tail(h,aa,p,72,kind)
            assert a.interval(r72['ratio']).hi<a.interval(r71['ratio']).lo<1
            assert F(r71['unnormalized_tail_upper'])>0

def test_source_finite_sum_matches_source_scale(report):
    s=report['lattice']['sums']
    for key,lo,hi in [('source_3','554.3913562640253','554.3913562640255'),
                      ('source_4','2041.8327331515470','2041.8327331515472')]:
        enclosure=a.interval(s[key]['full_sum'])
        assert F(lo)<enclosure.lo<=enclosure.hi<F(hi)

@pytest.mark.parametrize('optimized',[False,True])
def test_positive_cli_replays_exact(report,tmp_path,optimized):
    certificate=save(tmp_path/'candidate.json',report)
    output=tmp_path/'out.json'
    run=cli(['--verify',certificate,'--output',output],optimized)
    assert run.returncode==0,run.stderr
    assert a.canonical(a.strict_json(output))==a.canonical(report)

@pytest.mark.parametrize('optimized',[False,True])
@pytest.mark.parametrize('flag,value',[('--max-t3','155'),('--max-t4','428')])
def test_understated_claim_rejected_through_cli(optimized,flag,value):
    run=cli([flag,value],optimized)
    assert run.returncode!=0 and 'ceiling fails' in run.stderr

@pytest.mark.parametrize('mutation',['tail','normalizer','rayleigh','full_lattice','promotion','bool_credit'])
def test_mutated_certificate_rejected(report,tmp_path,mutation):
    bad=copy.deepcopy(report)
    if mutation=='tail':bad['lattice']['sums']['max_coordinate_4']['tail']['unnormalized_tail_upper']='0'
    elif mutation=='normalizer':bad['lattice']['normalizer_full']={'lo':'1','hi':'1'}
    elif mutation=='rayleigh':bad['amplitude_moments']['rayleigh_fourth_exact']='4'
    elif mutation=='full_lattice':bad['field_law']['full_lattice']=False
    elif mutation=='promotion':bad['scientific_promotion']=True
    elif mutation=='bool_credit':bad['organizational_independence_credit']=False
    run=cli(['--verify',save(tmp_path/'bad.json',bad)])
    assert run.returncode!=0 and 'typed reconstruction' in run.stderr

@pytest.mark.parametrize('optimized',[False,True])
def test_actual_shell_implementation_mutation_rejected(report,tmp_path,optimized):
    source=(a.HERE/'lpw_amplitude.py').read_text()
    old='shell = rr(4*w*(previous+w))'
    assert source.count(old)==1
    altered=tmp_path/'lpw_amplitude.py'
    altered.write_text(source.replace(old,'shell = rr(2*w*(previous+w))'))
    (tmp_path/'DEPENDENCIES.json').write_bytes((a.HERE/'DEPENDENCIES.json').read_bytes())
    run=cli(['--verify',save(tmp_path/'good.json',report)],optimized,altered)
    assert run.returncode!=0 and 'typed reconstruction' in run.stderr

@pytest.mark.parametrize('payload',['{"x":0,"x":1}','{"x":1.0}','{"x":NaN}'])
def test_json_parser_rejects_ambiguous_or_inexact(payload,tmp_path):
    path=tmp_path/'bad.json';path.write_text(payload)
    with pytest.raises(ValueError):a.strict_json(path)

def test_changed_source_rejected(tmp_path):
    fake=tmp_path/'fake'
    for relative,_,_,_ in a.SOURCES:
        path=fake/a.PREFIX/relative;path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes((a.REPO/a.PREFIX/relative).read_bytes())
    path=fake/a.PREFIX/a.SOURCES[0][0]
    path.write_bytes(path.read_bytes()+b'\nMUTATED')
    with pytest.raises(ValueError,match='source identity mismatch'):a.input_identities(fake)

def test_wrong_tail_start_precondition():
    h=a.pi(a.PREC)/12; aa=h*h/2
    with pytest.raises(ValueError,match='transition'):a.shell_tail(h,aa,4,1,'max_coordinate')
    with pytest.raises(ValueError,match='ratio'):a.shell_tail(h,aa,4,5,'max_coordinate')
