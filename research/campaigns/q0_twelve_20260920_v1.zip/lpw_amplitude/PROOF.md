# LPW full-lattice amplitude and max-norm ingredient — candidate v1

The source's full two-dimensional sums are reproduced, and the max-convention
field norm admits a substantially smaller Fourier majorant. Exact interval
replay proves

- `S3 < 554.391357`, `S4 < 2041.832734` for the source weights `(1+|k|)^p`;
- `T3 < 155.915377`, `T4 < 428.148915` for the sharper weights
  `max(1,|k1|,|k2|)^p`;
- `E ||f||_{C3}^4 < 4727655047` and `E ||f||_{C4} < 536.605087`.

Every decimal in these inequalities denotes an exact rational. The full
rational enclosures are in `result.json`. The last two upper budgets improve
on the source's loose Rayleigh budgets by factors greater than 341 and 6,
respectively. This compares proven upper budgets, not the unknown actual
moments. The argument includes all lattice modes and is spatially uniform.

**Status: PROVED_CANDIDATE at this analytic ingredient scope.** The written
infinite-dimensional argument below is ordinary mathematics, not a formal
proof-assistant result. The finite checker verifies interval sums and source
custody; finite tests do not themselves prove the analytic lemma. The work
is source-exposed, author-side, with zero organizational independence credit.
It does not reclassify any claim. In particular it proves no conditional
regression norm, density, endpoint eigenfloor, LPW headline coefficient,
q0 upper theorem, all-radius theorem, or original prize claim. None of the
2D lower, 2D upper and 3D lifetime tracks is composed here.

## 1. Exact field law and amplitude moments

Let `h=pi/12`, `a=h^2/2`, `Z1=sum_{n in Z} exp(-a n^2)`. For
`k=h(n,m)`, write `p_k=exp(-a(n^2+m^2))/Z1^2`. Take independent standard
normal pairs `(xi_k,eta_k)` at every full-lattice mode and set

`f(z) = sum_k sqrt(p_k) [xi_k cos(k.z) + eta_k sin(k.z)]`.

For finite partial sums the covariance is
`sum_k p_k [cos(k.z)cos(k.w)+sin(k.z)sin(k.w)]`, hence
`sum_k p_k cos(k.(z-w))`. The limit is Gaussian with this covariance: `sum_k p_k=1` gives L2
convergence at each point. The weighted summability established
below gives a common continuous C4 version. This is exactly the normalized
SIDE24 spectral law used by the R05 source. Opposite modes are represented
by distinct independent pairs. Their redundancy is allowed and neither
removes half the mass nor requires an extra square-root-two factor.

Let `rho_k=sqrt(xi_k^2+eta_k^2)`. Differentiating a trigonometric mode merely
rotates its phase, up to the coordinate multiplier. Cauchy–Schwarz gives

`sup_z |D^alpha [xi cos(k.z)+eta sin(k.z)]| <= |k1|^alpha1 |k2|^alpha2 rho`.

Here the components inside each pair must be independent standard normals
for the following moments. Polar coordinates in their density show that
rho has density `r exp(-r^2/2)` on `r>=0`. Therefore

`E rho = integral_0^infty r^2 exp(-r^2/2) dr = sqrt(pi/2)`.

Integration by parts reduces that integral to the half-Gaussian integral;
the boundary terms vanish. Alternatively, for the fourth moment one can
stay entirely algebraic:

`E rho^4 = E xi^4 + 2 E xi^2 eta^2 + E eta^4 = 3+2+3 = 8`.

Independence between *different* amplitudes is not used in the norm bounds
below. It is used in the displayed independent Fourier representation of
the field covariance. For example, setting `xi=eta` within a pair gives
fourth moment 12, and reusing the same pair for opposite modes doubles
the covariance in a one-frequency example; these are invalid shortcuts.

The old absolute-sum amplitude has a different fourth moment:
`E(|xi|+|eta|)^4=12+32/pi`. Thus `12+16/pi` is not that moment.
The repaired source instead correctly uses it as a loose upper bound for
`E rho^4=8`; similarly `2sqrt(2/pi)>sqrt(pi/2)`, since `pi<4`.
The checker certifies both strict comparisons. This candidate uses the
actual Rayleigh moments, not the larger inherited budgets.

## 2. Sharper max-convention C^p norm bound

Define `||f||_{Cp}=max_{|alpha|<=p} sup_z |D^alpha f(z)|`, and put
`b_p(k)=max(1,|k1|,|k2|)^p` for `p=3,4`. For `M=max(1,|k1|,|k2|)` and
`alpha1+alpha2<=p`,

`|k1|^alpha1 |k2|^alpha2 <= M^(alpha1+alpha2) <= M^p`.

Consequently

`||f||_{Cp} <= A_p := sum_k sqrt(p_k) b_p(k) rho_k`.

The constant 1 is essential: it covers the zero derivative and the zero
mode. This is specifically a **max** norm. A definition summing derivative
suprema would need a different coefficient and cannot reuse this bound
without conversion. The source explicitly declares the max convention.

Define `T_p=sum_k sqrt(p_k)b_p(k)`. The finite sums plus entire shell tails
below prove `T4<infinity` and `T3<infinity`. Tonelli gives
`E A4 = sqrt(pi/2) T4 < infinity`, so `A4<infinity` almost surely. On that
probability-one event all derivative series of orders zero through four
converge absolutely and uniformly on the torus. The usual uniform derivative
convergence theorem identifies them as derivatives of the limiting C4
field. This proves that the random norm inequality applies to that common
version everywhere, not merely at finitely many spatial points.

For a finite collection of modes, Minkowski's L4 triangle inequality gives
`(E A3^4)^(1/4) <= 8^(1/4) sum sqrt(p_k)b3(k)`. Monotone convergence of
the nonnegative partial sums then proves

`E ||f||C3^4 <= 8 T3^4`, and `E ||f||C4 <= sqrt(pi/2) T4`.

These arguments do not condition on any pin or jet value. A later
conditional regression calculation may substitute these ingredients only
with its own uniform covariance and regression hypotheses verified.

## 3. Full normalization and finite two-dimensional sums

The square-root spectral denominator is `Z1`, because the two-dimensional
normalization is `Z1^2`. It is not `sqrt(Z1)` or `Z1^2`. Write
`w_s=exp(-a s^2/2)` and `Q_s=1+2 sum_{j=1}^s w_j`. For the full shell
`max(|n|,|m|)=s>=1`,

`sum_shell exp(-a(n^2+m^2)/2) = Q_s^2-Q_(s-1)^2`
`=4 w_s (Q_(s-1)+w_s)`.

On that shell `b_p=max(1,h s)^p`. The sharper finite numerator is therefore

`1 + sum_{s=1}^70 4 w_s (Q_(s-1)+w_s) max(1,h s)^p`.

The zero mode is counted once. This positive formula avoids subtracting
nearby squared sums and computes the complete `141 x 141` square. A separate
source replay groups quadrant pairs by interchange symmetry, multiplies
by their full-lattice multiplicity, and sums
`exp(-a(n^2+m^2)/2)(1+h sqrt(n^2+m^2))^p`. Its count is checked to be 19881.
No planar Gaussian integral is substituted for the torus sum.

For normalization, the omitted one-dimensional terms from `j=71` onward
have consecutive ratio `exp(-a(2j+1))`, strictly decreasing in j. Thus

`0 < 2 exp(-a*71^2) <= Z1-Ztr`
`<= 2 exp(-a*71^2)/(1-exp(-a*143))`.

The lower endpoint for the full denominator includes the positive first
omitted pair; its upper endpoint includes the entire geometric bound.
Interval rounding may make the tiny added lower contribution invisible at
N=70, but the formula remains correct and the N=12 control verifies the
strict omitted contribution visibly. For a positive finite numerator F
and omitted numerator upper bound U, the full sum is enclosed by
`[F.lo/Z1.hi, (F+U).hi/Z1.lo]` with directed arithmetic. Reversing these
denominator choices is invalid.

## 4. Entire shell tails

A shell at radius s has `8s` points, squared Euclidean radius at least
`s^2`, and Euclidean frequency norm at most `h sqrt(2)s`. At `s>=71`,
`h s>1`. Hence valid unnormalized shell majorants are

- sharper max-coordinate: `B_p(s)=8s exp(-a s^2/2)(h s)^p`;
- source: `D_p(s)=8s exp(-a s^2/2)(1+h sqrt(2)s)^p`.

Their consecutive ratios are respectively

`exp(-a(2s+1)/2) ((s+1)/s)^(p+1)`

and

`exp(-a(2s+1)/2) ((s+1)/s)`
`* [(1+h sqrt(2)(s+1))/(1+h sqrt(2)s)]^p`.

Every factor is positive and decreasing for `s>=1`; for the last factor,
its inner quotient is `1+c/(1+cs)` with `c=h sqrt(2)>0`. Interval evaluation
proves the ratio at 71 is less than one. Thus every omitted shell is covered
by the geometric series `B_p(71)/(1-ratio71)` or its source analogue.
Dividing by the lower endpoint for the full `Z1` preserves an upper bound.
This proves the infinite sum, not just a large finite truncation. The
checker does not claim that a sampled ratio test alone proves monotonicity;
the preceding factorwise argument supplies that proof.

At the working cutoff, the normalized sharper tail upper budgets are below
`1.288e-32` for p=3 and `2.397e-31` for p=4. These are descriptive upward
budgets verified by exact rational endpoints; the JSON is authoritative for
all replayed values.

## 5. Source custody, execution, and falsification

Source bytes are checked before and after every complete replay and never
executed. Each path is beneath
`drive/mirrors/02_RESEARCH_CARRY_FORWARD_CANON/LPW — RAW ARCHIVE INTAKE R05/`.

| File | Drive ID | SHA-256 |
|---|---|---|
| `03_RAYLEIGH_REPAIR_AND_INTERVAL_CERTIFICATE.md` | `1ngaO6hzeIXdCYWMwKl8JYPPZTeryGFTx` | `840c75a7825c67b8d99a536394beb18976475fe9bd0e474ed5f80c375004ec81` |
| `checks/interval_repair.py` | `1cdE15_2dd0VLHJnDGcFQ5RDQJhTkXfr-` | `b37150f0eb79ff5d11b9e8b60f80afd94c677f8150aa701573ce24b337f24069` |
| `raw_reports/lpw_constant.py` | `1fRWIm7IsufB2xkrCxaExFp2TFdcd4oaG` | `e258322cfbb71dbb8665c2d0c0517399dca5ca5913e9ddf70eb7247ba74d3035` |

The parent verified R17 claim `b6eda859-17ee-401f-931f-9ae174c62aa0`, target
`Q0-P12-LPW-AMPLITUDE-20260920-v1`, Work Events row 74. This worker performs
no remote writes or repository writes. The three interval implementation
files are byte-pinned in `DEPENDENCIES.json`, with unchanged before/after
identities in each result. All acceptance decisions use explicit exceptions,
so Python optimization does not disable them.

`RUN.json` contains exact replay and test argument arrays. Locally:

```sh
python3.11 -B lpw_amplitude.py --verify result.json --output fresh-result.json
python3.11 -B -m pytest -q -p no:cacheprovider --basetemp ./fresh-test-temp test_lpw_amplitude.py
```

Use `--repo /absolute/path/to/research-main` to choose the single source and
implementation root; dependency hashes must still match. The supplied
certificate must equal a fresh typed reconstruction, not merely pass a
handful of self-reported inequalities. Duplicate keys, floating JSON numeric
literals, and Boolean-for-zero substitutions are rejected. Meaningful
negative controls include old amplitude-moment and dependence mistakes,
phase-amplitude understatement, missed shell sides, zero-mode omission,
actual omitted positive lattice shells, a hundred-fold tail understatement,
understated T3/T4 ceilings via CLI, actual shell-formula mutation, changed
source bytes, and tampered certificate status/normalization/tail fields.
Normal and optimized Python both replay the same rational result.
