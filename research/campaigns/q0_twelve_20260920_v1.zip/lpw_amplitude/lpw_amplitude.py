#!/usr/bin/env python3
"""Exact full-lattice Rayleigh amplitude and max C^p majorants.

No conditional regression, q0 theorem, claim promotion or independence credit.
Frozen source is hash-checked and read, never executed. Standard library only.
"""
from __future__ import annotations
import argparse
from fractions import Fraction as F
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import sys

DEFAULT_REPO = Path('/Users/dylanroy/Documents/Codex/research-main')
_BOOT = argparse.ArgumentParser(add_help=False)
_BOOT.add_argument('--repo', type=Path, default=DEFAULT_REPO)
REPO = _BOOT.parse_known_args()[0].repo.resolve()
sys.path.insert(0, str(REPO))
from research.interval import Interval as I, exp, pi, sqrt

HERE = Path(__file__).resolve().parent
PREFIX = 'drive/mirrors/02_RESEARCH_CARRY_FORWARD_CANON/LPW — RAW ARCHIVE INTAKE R05/'
SOURCES = (
 ('03_RAYLEIGH_REPAIR_AND_INTERVAL_CERTIFICATE.md', '1ngaO6hzeIXdCYWMwKl8JYPPZTeryGFTx', 9628, '840c75a7825c67b8d99a536394beb18976475fe9bd0e474ed5f80c375004ec81'),
 ('checks/interval_repair.py', '1cdE15_2dd0VLHJnDGcFQ5RDQJhTkXfr-', 6843, 'b37150f0eb79ff5d11b9e8b60f80afd94c677f8150aa701573ce24b337f24069'),
 ('raw_reports/lpw_constant.py', '1fRWIm7IsufB2xkrCxaExFp2TFdcd4oaG', 25380, 'e258322cfbb71dbb8665c2d0c0517399dca5ca5913e9ddf70eb7247ba74d3035'),
)
PREC, BITS, N = 24, 160, 70

def require(ok, message):
    if not ok:
        raise ValueError(message)

def rr(x):
    return x.round_out(BITS)

def cap(x):
    return {'lo': str(x.lo), 'hi': str(x.hi)}

def isum(xs):
    out = I(0)
    for x in xs:
        out = rr(out + x)
    return out

def identity(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def canonical(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=False)

def strict_json(path):
    def pairs(items):
        out = {}
        for k, v in items:
            require(k not in out, 'duplicate JSON key: ' + k)
            out[k] = v
        return out
    def forbidden(value):
        raise ValueError('noninteger JSON number forbidden: ' + value)
    return json.loads(Path(path).read_text(), object_pairs_hook=pairs,
                      parse_float=forbidden, parse_constant=forbidden)

def input_identities(repo=REPO):
    records = {}
    for path, did, size, digest in SOURCES:
        current = identity(repo / PREFIX / path)
        require(current == {'bytes': size, 'sha256': digest}, 'source identity mismatch: ' + path)
        records[PREFIX+path] = {**current, 'drive_id': did}
    dependencies = strict_json(HERE / 'DEPENDENCIES.json')
    for path, expected in dependencies.items():
        current = identity(repo / path)
        require(canonical(current) == canonical(expected), 'dependency identity mismatch: ' + path)
        records[path] = current
    return records

def normalization(h, a, n):
    weights = [rr(exp(-a*j*j, PREC)) for j in range(n+1)]
    ztr = rr(1 + 2*isum(weights[1:]))
    first = n+1
    ratio = rr(exp(-a*(2*first+1), PREC))
    require(ratio.hi < 1, 'normalizer tail ratio')
    positive_first = rr(2*exp(-a*first*first, PREC))
    tail = rr(positive_first/(1-ratio))
    zall = I((ztr+positive_first).lo, (ztr+tail).hi)
    return ztr, zall, {'first': first, 'positive_first': cap(positive_first),
                      'ratio': cap(ratio), 'tail_upper': str(tail.hi)}

def shell_tail(h, a, power, first, kind):
    require(type(first) is int and first > 0, 'positive integer tail start required')
    require(type(power) is int and power in (3,4), 'power must be 3 or 4')
    decay_ratio = exp(-a*F(2*first+1,2), PREC)
    if kind == 'source':
        c = rr(h*sqrt(I(2),PREC))
        factor = rr(1+c*first)
        ratio = rr(I(F(first+1,first))*decay_ratio*((1+c*(first+1))/(1+c*first))**power)
    elif kind == 'max_coordinate':
        require((h*first).lo >= 1, 'tail past max-profile transition required')
        factor = rr(h*first)
        ratio = rr(I(F(first+1,first))**(power+1)*decay_ratio)
    else:
        raise ValueError('unknown majorant kind')
    require(0 < ratio.lo <= ratio.hi < 1, 'shell ratio not in (0,1)')
    initial = rr(8*first*exp(-a*F(first*first,2),PREC)*factor**power)
    bound = rr(initial/(1-ratio))
    return bound, {'first':first, 'ratio':cap(ratio), 'first_shell_majorant':cap(initial),
                   'unnormalized_tail_upper':str(bound.hi)}

def max_profile(h, shell, power):
    t = h*shell
    return rr(I(max(F(1),t.lo),max(F(1),t.hi))**power)

def finite_max_shells(h, a, n, power):
    # Q_s^2-Q_(s-1)^2 = 4 w_s (Q_(s-1)+w_s), with w_s=e^(-a s^2/2).
    previous = I(1)
    total = I(1)
    for s in range(1,n+1):
        w = rr(exp(-a*F(s*s,2),PREC))
        shell = rr(4*w*(previous+w))
        total = rr(total+shell*max_profile(h,s,power))
        previous = rr(previous+2*w)
    return total

@lru_cache(maxsize=4)
def lattice(n=N):
    require(type(n) is int and 12 <= n <= N, 'truncation must be in 12..70')
    h = rr(pi(PREC)/12)
    a = rr(h*h/2)
    ztr,zall,zrecord = normalization(h,a,n)
    half = [rr(exp(-a*F(j*j,2),PREC)) for j in range(n+1)]
    source = {3:I(0),4:I(0)}
    radius = {}
    # Symmetry groups count the full square, including the zero mode.
    grouped_points = 0
    for i in range(n+1):
        for j in range(i+1):
            mult = (1 if i==0 else 2)*(1 if j==0 else 2)*(1 if i==j else 2)
            grouped_points += mult
            sq = i*i+j*j
            if sq not in radius:
                radius[sq] = rr(sqrt(I(sq),PREC))
            base = rr(1+h*radius[sq])
            weight = rr(mult*half[i]*half[j])
            for p in (3,4):
                source[p] = rr(source[p]+weight*base**p)
    require(grouped_points == (2*n+1)**2, 'full square multiplicity failure')
    records = {}
    for p in (3,4):
        for kind, finite in (('source',source[p]),('max_coordinate',finite_max_shells(h,a,n,p))):
            tail,tr = shell_tail(h,a,p,n+1,kind)
            # Full normalizer LOWER is conservative for upper; full upper for lower.
            bound = rr(I((finite/zall).lo, ((finite+tail)/I(zall.lo)).hi))
            records[f'{kind}_{p}'] = {'finite_numerator':cap(finite),'full_sum':cap(bound),
                                      'tail':tr,'normalized_tail_upper':str((tail/I(zall.lo)).hi)}
    return {'N':n,'finite_lattice_points':grouped_points,'h':cap(h),'a':cap(a),
            'normalizer_finite':cap(ztr),'normalizer_full':cap(zall),
            'normalizer_tail':zrecord,'sums':records}

def interval(data):
    return I(data['lo'],data['hi'])

def compute(repo=REPO):
    before = input_identities(repo)
    data = lattice()
    pival = pi(PREC)
    mean = rr(sqrt(pival/2,PREC))
    oldmean = rr(2*sqrt(2/pival,PREC))
    oldfourth = rr(12+16/pival)
    absolute_sum_fourth = rr(12+32/pival)
    require(oldfourth.lo > 8, 'Rayleigh fourth-moment budget invalid')
    require(oldmean.lo > mean.hi, 'Rayleigh mean budget invalid')
    sums = {k:interval(v['full_sum']) for k,v in data['sums'].items()}
    source3 = rr(oldfourth*sums['source_3']**4)
    source4 = rr(oldmean*sums['source_4'])
    sharp3 = rr(8*sums['max_coordinate_3']**4)
    sharp4 = rr(mean*sums['max_coordinate_4'])
    require(sharp3.hi < source3.lo and sharp4.hi < source4.lo, 'improvement not separated')
    ceilings = {'S3':'554.391357', 'S4':'2041.832734', 'T3':'155.915377',
                'T4':'428.148915', 'E_C3_fourth':'4727655047', 'E_C4':'536.605087'}
    for label, bound in (('S3',sums['source_3']), ('S4',sums['source_4']),
                         ('T3',sums['max_coordinate_3']), ('T4',sums['max_coordinate_4']),
                         ('E_C3_fourth',sharp3), ('E_C4',sharp4)):
        require(bound.hi < F(ceilings[label]), 'exact rational ceiling fails: '+label)
    require((source3/sharp3).lo > 341 and (source4/sharp4).lo > 6,
            'upper-budget improvement floors fail')
    require(canonical(before)==canonical(input_identities(repo)), 'inputs changed during replay')
    return {
      'schema':'lpw-amplitude-maxnorm-v1', 'status':'PROVED_CANDIDATE',
      'target':'Q0-P12-LPW-AMPLITUDE-20260920-v1',
      'claim_reference':'b6eda859-17ee-401f-931f-9ae174c62aa0',
      'source_identities':before,'input_hashes_unchanged':True,
      'arithmetic':{'precision_hint':PREC,'outward_significant_bits':BITS},
      'field_law':{'dimension':2,'period':24,'spectral_frequency':'(pi/12)*Z^2',
                   'spectral_mass':'exp(-|k|^2/2)/Z1^2','full_lattice':True,
                   'gaussian_pair_independent_within_each_mode':True,
                   'independent_mode_pairs_for_field_law':True,
                   'amplitude_bound_requires_inter_mode_independence':False},
      'norm':'max_{|alpha|<=p} sup_z |D^alpha f(z)|',
      'amplitude_moments':{'rayleigh_mean':cap(mean),'rayleigh_fourth_exact':'8',
         'old_loose_mean_budget':cap(oldmean),'old_loose_fourth_budget':cap(oldfourth),
         'old_absolute_sum_fourth_actual':cap(absolute_sum_fourth)},
      'lattice':data,
      'strict_rational_ceilings':ceilings,
      'unconditional_field_bounds':{
         'source_E_C3_to_fourth_upper':str(source3.hi),
         'source_E_C4_upper':str(source4.hi),
         'sharpened_E_C3_to_fourth_upper':str(sharp3.hi),
         'sharpened_E_C4_upper':str(sharp4.hi),
         'C3_fourth_upper_budget_improvement_lower':str((source3/sharp3).lo),
         'C4_upper_budget_improvement_lower':str((source4/sharp4).lo)},
      'analytic_status':'Written full-lattice Gaussian law, Rayleigh moment, a.s. C4 convergence and Minkowski proof in PROOF.md; finite replay checks sums, not those analytic proofs.',
      'scientific_promotion':False,'original_prize_closed':False,'organizational_independence_credit':0,
      'limitations':['No conditional field norm or covariance regression is composed here.',
        'No density, endpoint eigenfloor, LPW headline coefficient, q0 upper theorem or all-r closure.',
        'Source-exposed author work; no external or blind review and no formal proof assistant.']}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=REPO)
    p.add_argument('--output',type=Path)
    p.add_argument('--verify',type=Path)
    p.add_argument('--max-t3',default=None)
    p.add_argument('--max-t4',default=None)
    args=p.parse_args()
    try:
        require(args.repo.resolve()==REPO, 'source and imported implementation roots differ')
        result=compute(args.repo)
        for power,claim in ((3,args.max_t3),(4,args.max_t4)):
            if claim is not None:
                require(interval(result['lattice']['sums'][f'max_coordinate_{power}']['full_sum']).hi<=F(claim),
                        f'T{power} ceiling fails')
        if args.verify:
            require(canonical(strict_json(args.verify))==canonical(result),'certificate differs from exact typed reconstruction')
        if args.output:
            require(not args.output.resolve().is_relative_to(REPO),'output inside read-only repository')
            args.output.parent.mkdir(parents=True,exist_ok=True)
            args.output.write_text(json.dumps(result,indent=2,sort_keys=True,ensure_ascii=False)+'\n')
        print('PASS: full-lattice Rayleigh C3/C4 max-norm candidate; no scientific promotion')
    except (ValueError,OSError,ZeroDivisionError) as exc:
        print('FAIL: '+str(exc),file=sys.stderr)
        return 1
    return 0
if __name__=='__main__':
    raise SystemExit(main())
