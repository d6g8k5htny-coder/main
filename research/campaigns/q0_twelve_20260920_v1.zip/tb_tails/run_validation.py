"""Capture bounded author-side validation; never promotes a scientific status."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    out = args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=False)
    results=[]
    for name, argv in (
        ('normal', [sys.executable,'-B',str(HERE/'tail_bounds.py'),
                    '--verify',str(HERE/'result.json'),'--output',str(out/'normal.json')]),
        ('optimized', [sys.executable,'-B','-O',str(HERE/'tail_bounds.py'),
                       '--verify',str(HERE/'result.json'),'--output',str(out/'optimized.json')]),
        ('tests-normal', [sys.executable,'-B','-m','unittest','-v','test_tail_bounds']),
        ('tests-optimized', [sys.executable,'-B','-O','-m','unittest','-v','test_tail_bounds']),
    ):
        p=subprocess.run(argv,cwd=HERE,capture_output=True,text=True,timeout=60,
                         env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
        (out/(name+'.stdout')).write_text(p.stdout)
        (out/(name+'.stderr')).write_text(p.stderr)
        results.append({'name':name,'argv':argv,'cwd':str(HERE),'exit_code':p.returncode,
                        'stdout':name+'.stdout','stderr':name+'.stderr'})
    same=(out/'normal.json').read_bytes()==(out/'optimized.json').read_bytes()
    success=all(r['exit_code']==0 for r in results) and same
    receipt={'schema':'tb-tail-author-validation-v1','success':success,
             'normal_optimized_byte_identical':same,'tests_per_mode':25,
             'commands':results,'python':sys.version,
             'scientific_status_changed':False,'organizational_independence_credit':0,
             'not_established':'Actual field Gaussian interface and selection are imported.'}
    (out/'RUN.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
    print('PASS: 25 tests per mode; normal/-O byte identity' if success else 'FAIL')
    return 0 if success else 1


if __name__=='__main__':
    raise SystemExit(main())
