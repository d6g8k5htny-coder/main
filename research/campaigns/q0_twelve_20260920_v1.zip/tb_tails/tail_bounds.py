"""Conditional Theorem-B tail lemma; no model certification or status promotion.

Only exact rationals and repository-certified interval transcendental functions.
See PROOF.md for the continuum arguments; finite checks alone are not the proof.
"""
from __future__ import annotations

import argparse
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
DEFAULT_REPO = Path('/Users/dylanroy/Documents/Codex/research-main')


def require(ok, message):
    if not ok:
        raise ValueError(message)


def no_duplicates(pairs):
    answer = {}
    for key, value in pairs:
        require(key not in answer, f'duplicate key: {key}')
        answer[key] = value
    return answer


def read_json(path):
    return json.loads(Path(path).read_text(), object_pairs_hook=no_duplicates,
                      parse_constant=lambda s: (_ for _ in ()).throw(ValueError(s)))


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def identity(path):
    raw = Path(path).read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def verify_bindings(repo, sources):
    deps = read_json(HERE / 'DEPENDENCIES.json')
    for name, expected in deps['files'].items():
        require(identity(repo / name) == expected, f'dependency drift: {name}')
    bindings = read_json(HERE / 'SOURCE_BINDINGS.json')
    for record in bindings['sources']:
        for name, expected in record['files'].items():
            require(identity(sources / record['artifact'] / name) == expected,
                    f'source drift: {record["artifact"]}/{name}')
    return deps, bindings


def interval_api(repo):
    sys.path.insert(0, str(repo))
    from research.interval import Interval, exp, pi, sqrt
    for name in ('research.interval', 'research.interval.core',
                 'research.interval.transcendental'):
        require(Path(sys.modules[name].__file__).resolve().is_relative_to(repo.resolve()),
                f'wrong dependency imported: {name}')
    return Interval, exp, pi, sqrt


def quadratic_floor(A):
    require(A >= 0, 'A must be nonnegative')
    return 1 / (F(37) + 36 * A * A)


def floor_certificate(A, proposed):
    """Uniform PSD certificate for M(a)-proposed I, all |a|<=A."""
    return (A >= 0 and 0 < proposed < 1
            and F(1, 36) - proposed * (F(37, 36) + A*A)
            + proposed*proposed >= 0)


def gaussian_interface(r0, lam, upper, cross, trace):
    require(r0 > 0 and 0 < lam <= upper and cross >= 0 and trace >= 0,
            'invalid Gaussian-interface constants')
    A = r0**3 / 12
    M = cross / lam * max(F(1), A + F(1, 6))
    h = max(F(1, 2), r0)
    # E||m+Z||^4 <= (M^4+3 T M^2+3 T^2)(1+s^4).
    determinant_polynomial = h*h / 4 * (M**4 + 3*trace*M*M + 3*trace*trace)
    return {'A': A, 'quadratic_floor': quadratic_floor(A), 'mean_slope': M,
            'determinant_polynomial': determinant_polynomial,
            'density_exponent': quadratic_floor(A) / (2 * upper)}


def tails(C, c, t, B, R, api, prec=90):
    """Upper bounds on the complement of [-B,B] x [t^3,R]."""
    require(C > 0 and c > 0 and 0 < t <= 1 and B >= 1 and R >= 1,
            'requires C,c>0, 0<t<=1 and B,R>=1')
    I, exp, pi, sqrt = api
    B0 = sqrt(pi(prec) / c, prec)
    B4 = B0 * F(3, 4) / (c*c)
    ec = exp(I.exact(-c), prec)
    K0 = 3 + ec / (2*c)
    K4 = F(3, 13) + ec * (1/(2*c) + 1/(c*c) + 1/(c**3))
    small = C * (3*t*(B0 + 8*B4) + F(24, 13)*B0*t**13)
    eR = exp(I.exact(-c*R*R), prec)
    T0 = eR / (2*c)
    T4 = eR * (R**4/(2*c) + R*R/(c*c) + 1/(c**3))
    large_kappa = C * ((B0+8*B4)*T0 + 8*B0*T4)
    eB = exp(I.exact(-c*B*B), prec)
    U0 = eB/(c*B)
    U4 = eB*(B**3/c + 3*B/(2*c*c) + F(3, 4)/(c**3*B))
    large_birth = C*((U0+8*U4)*K0 + 8*U0*K4)
    total = small + large_kappa + large_birth
    return {'small_kappa': small, 'large_kappa': large_kappa,
            'large_birth': large_birth, 'total_outside_rectangle': total,
            'angle_integrated_outside_rectangle': 2*pi(prec)*total,
            'whole_mass_upper': C*((B0+8*B4)*K0+8*B0*K4)}


def enclosure(value):
    value = value.round_out(256)
    return {'lo': str(value.lo), 'hi': str(value.hi)}


def compute(repo, sources):
    deps, bindings = verify_bindings(repo, sources)
    api = interval_api(repo)
    I, exp, pi, sqrt = api
    interface = gaussian_interface(F(1, 20), F(1), F(1), F(1), F(6))
    require(floor_certificate(interface['A'], interface['quadratic_floor']),
            'quadratic floor certificate failed')
    C_actual = I.exact(interface['determinant_polynomial']) / (6*(2*pi(90))**3)
    require(C_actual.hi < 1 and interface['density_exponent'] >= F(1, 75),
            'demo simplification failed')
    cases = []
    for name, c, t, B, R, threshold in (
        ('unit_envelope', F(1), F(1, 10**9), F(8), F(8), F(1, 10**6)),
        ('hypothetical_uniform_gaussian_interface', F(1, 75), F(1, 10**24),
         F(120), F(120), F(1, 10**15)),
    ):
        values = tails(F(1), c, t, B, R, api)
        require(values['angle_integrated_outside_rectangle'].hi < threshold,
                f'tail threshold failed: {name}')
        cases.append({'name': name, 'C': '1', 'c': str(c), 't': str(t),
                      'delta': str(t**3), 'B': str(B), 'R': str(R),
                      'angle_error_threshold': str(threshold),
                      'bounds': {k: enclosure(v) for k, v in values.items()}})
    verify_bindings(repo, sources)
    return {'schema': 'tb-integrated-tails-v1',
            'status': 'CONDITIONAL_ANALYTIC_LEMMA_WITH_CERTIFIED_DEMONSTRATIONS',
            'source_scope': 'LS-DER-039 equations 4,7,17-19 and compact exhaustion',
            'model_constants_certified': False,
            'actual_selection_verified': False,
            'all_angles_model_verified': False,
            'theorem_b_restored': False, 'scientific_status_changed': False,
            'original_prize_closed': False, 'organizational_independence_credit': 0,
            'quadratic_floor_formula': '1/(37+36*A^2)',
            'demo_interface': {k: str(v) for k,v in interface.items()},
            'demo_density_majorant_constant': enclosure(C_actual),
            'demonstrations': cases, 'sources': bindings, 'dependencies': deps,
            'not_established': ['numeric constants for the actual SIDE24 field',
                'actual elder-rule selection or all-angle contact convergence',
                'coarea, pair multiplicity, far complement or total lifetime theorem',
                'canonical promotion or independent organizational review']}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path, default=DEFAULT_REPO)
    parser.add_argument('--sources', type=Path, default=HERE.parent/'sources')
    parser.add_argument('--verify', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result = compute(args.repo.resolve(), args.sources.resolve())
    if args.verify:
        require(canonical(read_json(args.verify)) == canonical(result),
                'stored result differs from exact replay')
    if args.output:
        require(not args.output.resolve().is_relative_to(args.repo.resolve()),
                'repository is read-only for this task')
        args.output.write_text(json.dumps(result, indent=2, sort_keys=True)+'\n')
    print('PASS: conditional TB tail lemma; 2 integrated demonstrations; no status change')


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, KeyError, TypeError) as error:
        print(f'FAIL: {error}', file=sys.stderr)
        sys.exit(1)
