# Quantitative full-mark tail lemma for the Theorem B near component

**Author-produced conditional analytic lemma; no scientific status changes.**
This closes a specific analytic calculation, not Theorem B, Q0, actual
persistence selection, or any registered obligation. Organizational
independence credit is zero. No axis-only H3 floor is used.

The sources are LS-DER-039 §§2,5–6, LS-DER-032 §§4–6, and LS-DER-021
§§1,3–6; LS-DER-040 is downstream context. `SOURCE_BINDINGS.json` pins the
four native DOCX exports and their derived reading texts. These export hashes
are **not** the frozen-body hashes printed inside the source documents; no
frozen-body identity is asserted. The exports were observed by revision
metadata, not requested by revision ID. No excluded payload was consumed.

## 1. Explicit hypotheses and what remains imported

Let Y be the centered six-dimensional corrected pin vector, and V the six
corrected endpoint variables ordered as
`(A_M,A_S,B_M,B_S,C_M,C_S)`. The following are model interfaces, required
uniformly for **all** θ∈S¹ and 0<r≤r₀, independent of b∈R and κ>0:

1. The exact target is y=(b−aκ,−κ/6,0,0,0,0), a=r³/12.
2. λI≤Σ_Y≤ΛI with 0<λ≤Λ; `||Cov(V,Y)||op≤B_c` and
   `tr Cov(V)≤T`, with B_c,T finite and nonnegative.
3. The centered joint law is Gaussian. On the pin affine subspace,
   `det H_j=r(A_j C_j−r B_j²)`. The all-typed intensity obeys
   J_r=(1/6)p_Y(y)E[W_r/r² | Y=y], where the type indicators are at most one.
4. Selected intensity K_r is measurable and 0≤K_r≤J_r. To identify the
   limiting coefficient additionally import K_r→J₀ locally uniformly on
   S¹×R×(0,∞); tail domination alone does not supply this selection limit.

The source LS-DER-032 presents qualitative all-angle covariance continuity,
eigenvalue bounds, and regression as a same-family companion. This delivery
does not independently establish those facts for the actual field, or assign
them numerical constants. It proves their **global-in-target consequence**:
the covariance blocks do not depend on (b,κ), so compact parameter control of
the blocks is enough for a global polynomial bound on their conditional mean.
It does not extend a bound known only at one angle to all angles. LS-DER-021
provides the pin/intensity algebra; its exact Jacobian, multiplicity and
Kac–Rice hypotheses are imported, not rederived. The compact selected-contact
limit in LS-DER-039 depends on its other selection sources (not audited here),
including LS-DER-036-v1.1 and LS-DER-038. Compact positive mass is likewise an
additional input if strict positivity of the coefficient is desired.

## 2. Uniform quadratic lower constant

Put A=r₀³/12 and q₀=1/(37+36A²). The matrix of
Q_a(b,κ)=(b−aκ)²+κ²/36 is

```
M_a = [[1, -a], [-a, a²+1/36]],
det M_a=1/36,  tr M_a=37/36+a².
```

Thus λ_min(M_a)≥det(M_a)/tr(M_a)≥q₀ for |a|≤A. Equivalently,
1−q₀>0 and
`det(M_a−q₀ I)=1/36−q₀(37/36+a²)+q₀²≥q₀²>0`.
This proves Q_a≥q₀(b²+κ²) on the entire domain, not a sampled grid.
Consequently

```
p_Y(y) ≤ (2π)^(-3) λ^(-3) exp[-c(b²+κ²)],
c = q₀/(2Λ).
```

The pin covariance ceiling supplies the exponent, while its floor supplies
the density prefactor. Interchanging them is not valid.

## 3. Explicit Gaussian determinant polynomial

Let s=|b|+κ. Since `||y||≤|b|+(A+1/6)κ`, regression gives
`||m||≤M s`, where M=(B_c/λ)max(1,A+1/6). The residual covariance Γ is
positive semidefinite and Γ≤Cov(V), hence tr Γ≤T. For a Gaussian V=m+Z,
Wick's formula gives exactly

```
E||V||⁴ = ||m||⁴ + 2||m||² tr Γ + 4mᵀΓm
           + (tr Γ)² + 2tr(Γ²)
        ≤ M⁴s⁴ + 6TM²s² + 3T²
        ≤ (M⁴+3TM²+3T²)(1+s⁴).
```

The last step uses 2s²≤1+s⁴. This argument permits singular residual
covariance and needs no residual eigenvalue floor.

Set h=max(1/2,r₀). For each endpoint,
`|A_j C_j−r B_j²|≤h(A_j²+B_j²+C_j²)`. Multiplying and using uv≤(u+v)²/4
gives `W_r/r²≤(h²/4)||V||⁴`. Therefore

```
J_r, K_r ≤ C [1+(|b|+κ)⁴] exp[-c(b²+κ²)],
C = [h²/(24(2π)³ λ³)] [M⁴+3TM²+3T²].
```

The type and selection indicators can only decrease this bound. This is
ordinary Gaussian moment analysis, not a proof that selection tends to one.

## 4. Three integrated truncation errors

Everything in this section holds for **any** given C,c>0. Define

```
D(b,κ)=C κ^(-2/3)[1+(|b|+κ)⁴] exp[-c(b²+κ²)].
B₀=√(π/c),   B₄=3B₀/(4c²),
K₀=3+e^(-c)/(2c),
K₄=3/13+e^(-c)[1/(2c)+1/c²+1/c³].
```

These are finite explicit bounds because `(x+y)⁴≤8(x⁴+y⁴)` for x,y≥0,
`∫_R b^j e^(-cb²)db=B_j` for j=0,4, and

```
∫₀∞ κ^(-2/3)e^(-cκ²)dκ ≤ K₀,
∫₀∞ κ^(10/3)e^(-cκ²)dκ ≤ K₄.
```

For the latter bounds, split at κ=1. On (0,1), drop the exponential and
integrate exactly. On [1,∞), κ^(-2/3)≤κ and κ^(10/3)≤κ⁵. Integration by
parts gives

```
∫_R∞ κ e^(-cκ²)dκ = e^(-cR²)/(2c),
∫_R∞ κ⁵e^(-cκ²)dκ
 = e^(-cR²)[R⁴/(2c)+R²/c²+1/c³].
```

In particular the whole b,κ integral of D is bounded by
`C[(B₀+8B₄)K₀+8B₀K₄]`.

For δ=t³ with 0<t≤1, the small-gap region obeys

```
∫_R∫₀δ D ≤ E_small
 = C[3t(B₀+8B₄)+(24/13)B₀ t¹³].
```

This follows from κ=u³ (κ^(-2/3)dκ=3du), or directly from the power
integrals. The singularity at zero is integrated, not evaluated at a point.

For R≥1, put

```
T₀=e^(-cR²)/(2c),
T₄=e^(-cR²)[R⁴/(2c)+R²/c²+1/c³].
E_largeκ=C[(B₀+8B₄)T₀+8B₀T₄].
```

Then the integral of D over b∈R and κ∈[R,∞) is at most E_largeκ.

For a birth cutoff H≥1, the two-sided Gaussian bounds are

```
U₀=e^(-cH²)/(cH),
U₄=e^(-cH²)[H³/c+3H/(2c²)+3/(4c³H)],
E_birth=C[(U₀+8U₄)K₀+8U₀K₄].
```

Indeed, `∫_H∞e^(-cb²)db≤e^(-cH²)/(2cH)` follows by replacing 1 by b/H.
Twice the fourth-moment integration-by-parts recurrence is
`e^(-cH²)[H³/c+3H/(2c²)]+[3/(2c²)]∫_H∞e^(-cb²)db`.
Inserting the previous inequality yields U₄. Hence
`∫_{|b|>H}∫₀∞D≤E_birth`.

By a union bound the integral outside `[-H,H]×[δ,R]` is at most
E=E_small+E_largeκ+E_birth. Overlaps are harmless overcounting. Each term
tends to zero under δ↓0, R↑∞, H↑∞, with explicit rates. Integration over
the full angle contributes **2πE**, with no extra pair factor.

## 5. Quantitative compact exhaustion in the selected limit

Define F_ell(θ,b,κ)=1{r_ell(κ)≤r_c}K_{r_ell(κ)}(θ,b,κ), where
r_ell=(6ell/κ)^(1/3) and r_c≤r₀. Define F_ell=0 outside the cutoff without
evaluating K there. The majorant proves κ^(-2/3)F_ell≤D. If the imported
pointwise selected limit is valid, its limit also satisfies κ^(-2/3)J₀≤D.
On a fixed compact rectangle take ε_ell to bound `|F_ell−J₀|` uniformly
over all angles. Then

```
|∫_{S¹×R×(0,∞)} κ^(-2/3)(F_ell−J₀)|
 ≤ 12π H (R^(1/3)−δ^(1/3)) ε_ell + 4π E.
```

For ell≤δ r_c³/6 the cutoff is one throughout the rectangle. Local uniform
selected convergence then gives ε_ell→0, since
`sup_{κ≥δ} r_ell(κ)≤(6ell/δ)^(1/3)→0`. Alternatively, pointwise convergence
plus the established integrable D is enough by dominated convergence. No
single cubic selection constant uniform over all marks is required. The
lifetime prefactor `6^(2/3)/3` from the separate coarea calculation multiplies
this estimate if that interface is accepted. This delivery does not certify
it, the selected law, the far component, or the complete lifetime coefficient.

## 6. Reproducible conditional demonstrations

`tail_bounds.py` uses exact Fraction arithmetic and the repository interval
package. `result.json` includes outward rational enclosures of **integrated
error upper-bound expressions**, not estimates of the integrals themselves.

* For the supplied envelope C=c=1, δ=10^-27 and H=R=8, the full-angle
  exterior error is certified below 10^-6.
* A **hypothetical interface**, not a SIDE24 certificate, sets
  r₀=1/20, λ=Λ=B_c=1 and T=6. Then A=1/96000,
  q₀=256000000/9472000001, M=1, the determinant polynomial constant is
  127/16, C=127/(768π³)<1, and c=128000000/9472000001>1/75.
  With the conservative envelope C=1,c=1/75, δ=10^-72 and H=R=120, the
  full-angle exterior error is certified below 10^-15.

These constants demonstrate an executable route from supplied model bounds
to tail thresholds; **neither set is claimed for the actual field**.

Replay (Python 3.11, `-B`; substitute portable roots if copied):

```
python -B tail_bounds.py --repo /path/to/research-main --sources ../sources --verify result.json
python -B -m unittest -v test_tail_bounds
python -B -O -m unittest -v test_tail_bounds
```

Negative controls include exact counterexamples to overstated quadratic and
quartic constants, a missing Gaussian fourth-moment term, a missing two-sided
birth factor, the singular integral's missing factor three, corrupted Gaussian
tail recurrences, and CLI mutations of the result, source, status and scope.
Optimized Python retains all checker guards. `RUN.json` records completed
commands; `MANIFEST.json` hashes the immutable delivered files.
