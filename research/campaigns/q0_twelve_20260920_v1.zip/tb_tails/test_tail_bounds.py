"""Analytic witnesses and fail-closed CLI negative controls, including -O."""
from fractions import Fraction as F
import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import tail_bounds as tb


class TailTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.api = tb.interval_api(tb.DEFAULT_REPO)
        cls.good = tb.read_json(tb.HERE / 'result.json')

    def test_floor_uniform_psd_certificate(self):
        for A in (F(0), F(1, 96000), F(1), F(100)):
            self.assertTrue(tb.floor_certificate(A, tb.quadratic_floor(A)))

    def test_doubled_floor_has_exact_counterexample(self):
        A = F(1, 96000)
        bad = 2*tb.quadratic_floor(A)
        # b=A, kappa=1 makes the square term vanish.
        self.assertLess(F(1, 36), bad*(1+A*A))
        self.assertFalse(tb.floor_certificate(A, bad))

    def test_missing_shear_control_fails_for_large_A(self):
        A = F(10)
        self.assertLess(F(1, 36), F(1, 37)*(1+A*A))
        self.assertFalse(tb.floor_certificate(A, F(1, 37)))

    def test_quartic_separation_eight_is_sharp(self):
        b = k = F(1)
        self.assertEqual((b+k)**4, 8*(b**4+k**4))
        self.assertGreater((b+k)**4, 4*(b**4+k**4))

    def test_gaussian_fourth_moment_coefficient_required(self):
        # Z~N(0,1) embedded in R^6: trace Gamma=1, E||Z||^4=3.
        actual = F(3)
        self.assertEqual(actual, 3*F(1)**2)
        self.assertGreater(actual, F(1)**2)

    def test_determinant_factor_is_sharp(self):
        # A_M=A_S=C_M=C_S=1, B_M=B_S=0, r<=1/2.
        self.assertEqual(F(1), F(1, 16)*F(4)**2)
        self.assertGreater(F(1), F(1, 32)*F(4)**2)

    def test_small_kappa_factor_three_required(self):
        I, exp, _, _ = self.api
        t = F(1, 10)
        true_integral_lower = 3*t*exp(I.exact(-t**6), 60).lo
        self.assertGreater(true_integral_lower, t)

    def test_kappa_fifth_moment_exact_antiderivative(self):
        # P' - 2cRP = -R^5, coefficientwise, for all R and c>0.
        for c in (F(1), F(1, 75), F(13, 7)):
            p = {4:1/(2*c), 2:1/(c*c), 0:1/(c**3)}
            def residual(poly):
                ans = {5:F(1)}
                for n,v in poly.items():
                    if n: ans[n-1] = ans.get(n-1,F(0))+n*v
                    ans[n+1] = ans.get(n+1,F(0))-2*c*v
                return {n:v for n,v in ans.items() if v}
            self.assertEqual(residual(p), {})
            wrong = dict(p); wrong[0] = F(0)
            self.assertNotEqual(residual(wrong), {})

    def test_birth_fourth_moment_recurrence(self):
        for c in (F(1), F(1, 75), F(13, 7)):
            # d[e^-cB² A(B)+q I0(B)]/dB = -2B^4 e^-cB².
            q = F(3, 2)/(c*c)
            p = {3:1/c, 1:F(3,2)/(c*c)}
            residual = {4:F(2), 0:-q}
            for n,v in p.items():
                residual[n-1] = residual.get(n-1,F(0))+n*v
                residual[n+1] = residual.get(n+1,F(0))-2*c*v
            self.assertTrue(all(v == 0 for v in residual.values()))
            self.assertNotEqual(-q/2+p[1], 0)

    def test_missing_two_sided_factor_fails_actual_birth_tail(self):
        from research.interval import erfc
        I, exp, pi, sqrt = self.api
        actual = sqrt(pi(75),75)*erfc(I.exact(1),75)
        wrong = exp(I.exact(-1),75)/2
        self.assertGreater(actual.lo, wrong.hi)

    def test_invalid_domains_rejected(self):
        for args in ((F(0),F(1),F(1),F(1),F(1)),
                     (F(1),F(-1),F(1),F(1),F(1)),
                     (F(1),F(1),F(0),F(1),F(1)),
                     (F(1),F(1),F(2),F(1),F(1)),
                     (F(1),F(1),F(1),F(1,2),F(1))):
            with self.assertRaises(ValueError): tb.tails(*args, self.api)

    def test_stated_numeric_demonstrations(self):
        for case in self.good['demonstrations']:
            self.assertLess(F(case['bounds']['angle_integrated_outside_rectangle']['hi']),
                            F(case['angle_error_threshold']))

    def test_duplicate_json_rejected(self):
        with tempfile.TemporaryDirectory(dir=tb.HERE) as d:
            p = Path(d)/'duplicate.json'; p.write_text('{"a":1,"a":1}')
            with self.assertRaises(ValueError): tb.read_json(p)

    def cli(self, document, optimized):
        with tempfile.TemporaryDirectory(dir=tb.HERE) as d:
            p=Path(d)/'certificate.json'; p.write_text(json.dumps(document))
            command=[sys.executable,'-B']+(['-O'] if optimized else [])
            command += [str(tb.HERE/'tail_bounds.py'),'--verify',str(p)]
            return subprocess.run(command,capture_output=True,text=True,timeout=30)

    def test_cli_exact_replay_normal(self):
        self.assertEqual(self.cli(self.good,False).returncode,0)

    def test_cli_exact_replay_optimized(self):
        self.assertEqual(self.cli(self.good,True).returncode,0)

    def mutate(self, kind):
        result=copy.deepcopy(self.good)
        if kind == 'error':
            result['demonstrations'][0]['bounds']['small_kappa']['hi']='0'
        elif kind == 'promotion': result['theorem_b_restored']=True
        elif kind == 'bool_alias': result['organizational_independence_credit']=False
        elif kind == 'source': result['sources']['sources'][0]['drive_id']='WRONG'
        elif kind == 'interface': result['all_angles_model_verified']=True
        return result

    def test_cli_rejects_error_normal(self):
        self.assertNotEqual(self.cli(self.mutate('error'),False).returncode,0)

    def test_cli_rejects_error_optimized(self):
        self.assertNotEqual(self.cli(self.mutate('error'),True).returncode,0)

    def test_cli_rejects_promotion_normal(self):
        self.assertNotEqual(self.cli(self.mutate('promotion'),False).returncode,0)

    def test_cli_rejects_promotion_optimized(self):
        self.assertNotEqual(self.cli(self.mutate('promotion'),True).returncode,0)

    def test_cli_rejects_bool_alias_normal(self):
        self.assertNotEqual(self.cli(self.mutate('bool_alias'),False).returncode,0)

    def test_cli_rejects_bool_alias_optimized(self):
        self.assertNotEqual(self.cli(self.mutate('bool_alias'),True).returncode,0)

    def test_cli_rejects_source_normal(self):
        self.assertNotEqual(self.cli(self.mutate('source'),False).returncode,0)

    def test_cli_rejects_source_optimized(self):
        self.assertNotEqual(self.cli(self.mutate('source'),True).returncode,0)

    def test_cli_rejects_interface_normal(self):
        self.assertNotEqual(self.cli(self.mutate('interface'),False).returncode,0)

    def test_cli_rejects_interface_optimized(self):
        self.assertNotEqual(self.cli(self.mutate('interface'),True).returncode,0)


if __name__ == '__main__':
    unittest.main(verbosity=2)
