# Exact count, eta and exit-budget lemmas

Author-side mathematical candidate, 2026-09-20. This is an abstract interface
repair and a collection of counterexamples, not a successor to K3-THM-001.
No q0 theorem, source obligation, gate, Boolean or canonical status is changed.
All calculations in the companion checker use integers and exact fractions.
Same-provider technical work earns zero organizational independence credit.

## 1. Source scope and target events

The exact active-package raw snapshots consumed here are:

* GP-LB-STAT-004, Drive `1lfH7g57LcshqpLfNbrx-H7gbJckpzPqr`, 13,399 bytes,
  SHA-256 `26a9c7ef46b546acfdb0fda11f6ee8dd1e655752202d0add39e0011adf936a4c`.
  Its sections 3, 4, 7 and 10 leave exact-law factorial moments, eta, exit and
  uniform weighted losses open. Its controlling lower-campaign disposition
  remains OPEN and the K3 assembly remains REFUTED AS WRITTEN.
* W10_REPORT, Drive `1Ls7kwptRf7XGjmy2y4fZV3lbCtznzsK7`, 32,989 bytes,
  SHA-256 `67c7fe63e168060b9db1f2279de5d88e7f804508a0e4e98a90afbec468ee21d1`.
  Sections 1 and 2 route the event and count interfaces. Its inherited claims
  that particular moments and law transfers are certified are not accepted
  here: the later GP adjudication controls those claims.
* W7 scope addendum, Drive `1K9gkJ1To1v5IHklcSL4q7WJxGekgDdMC`, 2,906 bytes,
  SHA-256 `659e0bf9bc0ae29c84261e40a5ad1bfb6364ac98749c64ee35b496c360eb9f9f`.
  It supplies context for the distinction between an exponential exit rate
  and a sufficient loss budget; no discharge label is inherited.

Each snapshot was obtained by `read_source_v2.py`, which first checks both
inventory and coverage contexts for RESEARCH_SOURCE_CHECK_STATUS and rejects
legacy, quarantine and vault paths before reading payload bytes. Raw payloads,
derived reading copies and identity records are included. No frozen source
program was executed. Repository documents and the OQ-016-U1 register were
read to determine status, not as a source of new proof.

For the mathematical statements below, fix a probability law P_r. In the
intended field application it must be the exact typed six-pin pair-Palm law,
including its determinant weight and normalizer. Let E_pair be the event
`D(M)=S` of elder-rule death-partner pairing, and F=E_pair^c. Identifying this
law or event with a source bearing the symbol q is a separate hypothesis.
An adjacency-conditioned event is not identified by sharing the same pins.

Let N be a finite nonnegative integer-valued count, with E N^2 finite, of
qualifying witnesses, and assume the actual event inclusion

    {N >= 1} subset F.                                           (1)

No dynamical inclusion for the Gaussian field is proved here. Without (1),
even a Bernoulli(r^3) count can coexist with F empty and gives no lower bound
on P_r(F). The abstract lemmas hold under any probability law satisfying the
stated hypotheses; this does not prove those hypotheses for q0.

## 2. Bonferroni and a stronger integer-count replacement

For an integer n>=0 and integer k>=1, put

    L_k(n) = n(2k+1-n)/(k(k+1)).

For n=0 both L_k(n) and 1_{n>0} vanish. For n>=1,

    1 - L_k(n) = (n-k)(n-k-1)/(k(k+1)) >= 0,                    (2)

because two consecutive integers have nonnegative product. Thus, writing
mu=E N and s=E[N(N-1)],

    P(F) >= P(N>0) >= (2k mu-s)/(k(k+1)).                       (3)

At k=1 this is the usual Bonferroni inequality mu-s/2. The factorial moment
s counts ordered distinct witnesses: the unordered-pair sum is s/2. Omitting
this convention silently changes the debit. The condition E N^2<infinity
ensures every expectation in (3) is defined; no subtraction of infinities is
used. If N_qual<=N_raw pointwise, then
N_qual(N_qual-1)<=N_raw(N_raw-1), so a proved raw factorial-moment upper bound
under the same law can be substituted for s.

Let m>0 be a lower bound for mu and S>=0 an upper bound for s. Every right
side in (3) is increasing in mu and decreasing in s. Therefore define

    B_k(m,S)=(2k m-S)/(k(k+1)),
    k_* = floor(S/m)+1,
    B_*(m,S)=B_{k_*}(m,S)>0.                                   (4)

The difference B_{k+1}-B_k is
`2(S-k m)/(k(k+1)(k+2))`. It is nonnegative up to k<=S/m and nonpositive
afterwards, proving that k_* is a maximizer over all positive integers.
There can be two adjacent maximizing values when S/m is an integer.
Writing R=S/m in [k_*-1,k_*), exact subtraction gives

    B_*/m - 1/(1+R)
      = (k_*-R)(R-k_*+1)/(k_*(k_*+1)*(1+R)) >= 0.              (5)

Hence B_* is at least the Cauchy--Schwarz count bound m^2/(m+S). This is a
strict improvement for noninteger R. That latter bound also follows directly
from `mu=E[N 1_{N>0}] <= sqrt(E[N^2] P(N>0))`; the rational function
mu^2/(mu+s) is increasing in mu>=0 and decreasing in s>=0.

This count bound is sharp for specified exact moments when the following
probabilities are feasible:

    P(N=k)   = (k mu-s)/k,
    P(N=k+1) = (s-(k-1)mu)/(k+1),
    P(N=0)   = 1-B_k(mu,s).                                    (6)

For k=floor(s/mu)+1 the first two probabilities are nonnegative. When
B_k<=1, they sum to B_k and have moments exactly mu,s. In the r^3 regime,
fixed scaled coefficients ensure this feasibility for all sufficiently
small r. Equation (2), rather than finite enumeration, proves (3) for every
finite nonnegative integer count.

## 3. Rate consequences: preserving a coefficient versus proving positivity

All limits below are through a full continuum 0<r<=r0, not a finite rung
list. Suppose uniformly at the consumed scope

    liminf mu_r/r^3 >= c>0,
    limsup s_r/r^3 <= d<infinity.                              (7)

For each fixed k, (3) and the elementary liminf/limsup inequalities give

    liminf P_r(F)/r^3 >= (2k c-d)/(k(k+1)).

Taking k=floor(d/c)+1 proves the strictly positive coefficient B_*(c,d).
In particular, second factorial moment **O(r^3)** is sufficient for a
positive cubic lower rate once (1) and the positive first moment hold.
The stronger **o(r^3)** hypothesis gives d=0 and preserves the entire c
coefficient. This is an abstract alternative proof route, not a claim that
the actual q0 factorial moment is O(r^3), and not a restored K3 assembly.

The distinction is real. Put N=4 with probability r^3/4, otherwise zero.
Then mu=r^3, s=3r^3, P(N>0)=r^3/4. Standard Bonferroni gives the negative
number -r^3/2, while k=3 or 4 in (3) gives the exact positive r^3/4. The full
coefficient 1 cannot be retained. On the other hand, without any factorial
control there is no positive coefficient: at r=1/n let N=n with probability
r^4 and otherwise zero. Then mu=r^3 but P(N>0)/r^3=r tends to zero.
This sequence already disproves any asserted full-continuum positive bound.

For a sharp small pair correction, set P(N=2)=r^6,
P(N=1)=r^3-2r^6 and P(N=0)=1-r^3+r^6, for r^3<=1/2. Then
mu=r^3, s=2r^6 and P(N>0)=r^3-r^6, exactly the Bonferroni expression.

## 4. Exact weighted law, disintegration and losses

Let Q be the six-pin Gaussian conditional law and W>=0 its typed determinant
weight with 0<Z=E_Q W<infinity. Then, by definition,

    P_r(B)=E_Q[W 1_B]/Z,
    E_{P_r} N=E_Q[W N]/Z,
    E_{P_r}[N(N-1)]=E_Q[W N(N-1)]/Z.                           (8)

Every numerator and denominator in (8) is part of the same law. An ordinary
Gaussian or fixed nine-pin loss is not interchangeable with a marked
third-point Palm loss. To see this exactly, let Q(B)=epsilon in (0,1),
W=1/epsilon on B and W=1/(1-epsilon) on B^c. Then Z=2 and
P_r(B)=1/2, however small epsilon is. An ordinary factorial moment likewise
does not transfer: take N=2 on B with Q(B)=r^6, N=0 otherwise, and
W=r^-6 1_B. Then E_Q[N(N-1)]=2r^6, but the weighted factorial moment is 2.

A sufficient transfer bound, when actually proved, is dP/dQ<=C, which gives
P(B)<=C Q(B). More generally Holder gives
P(B)<=||dP/dQ||_p Q(B)^(1-1/p) for p>1. Small Q(B) alone never supplies the
missing uniform weighted norm. No such RN bound for the field is proved here.

Assume an exact marked Campbell disintegration is available:

    mu_r = integral a_r(y) nu_r(dy),
    Lambda_r = nu_r(arch),    a_r(y) >= a0 - sum_j ell_{j,r}(y). (9)

Here nu_r is the nonnegative candidate intensity under P_r, and a_r is the
qualifying-event probability under its exact marked conditional law. Equation
(9) must be established for the actual mark, including its height integration,
weights and typing. In particular this candidate does not validate W10's
displayed replacement by a single clipped-height conditional expectation.
All functions in (9) must be measurable, 0<=a_r<=1, and the losses nonnegative.

When Lambda_r>0, integration yields the exact useful statement

    mu_r >= Lambda_r * max(0, a0-L_r),
    L_r = sum_j integral ell_{j,r}(y) nu_r(dy)/Lambda_r.         (10)

Thus a **weighted integrated** loss budget suffices; sup_y loss bounds are a
stronger sufficient way to prove it. There is no need to demand uniform
vanishing when the exact integral can be controlled directly. However merely
pointwise vanishing is insufficient if the intensity measure also varies:
on y in (0,1), let nu_r have density r^-1 1_{(0,r)} and
ell_r=1_{(0,r)}. Then ell_r(y)->0 for each fixed y>0, but the normalized
integrated loss equals 1 for every r.

One sufficient dominated alternative is: nu_r/Lambda_r has densities h_r
with respect to one fixed measure, 0<=h_r<=g for one integrable g;
0<=ell_{j,r}<=1; a fixed finite number of channels; and ell_{j,r}->0 almost
everywhere. The product ell_{j,r} h_r is dominated by g and tends to zero,
so dominated convergence gives L_r->0. If the number of channels grows,
individual small probabilities do not suffice: m disjoint events each of
probability 1/m have union probability 1.

## 5. Exit loss and an explicit algebraic budget

Suppose Lambda_r>=lambda r^3 with lambda>0 and L_r<=L<a0 in (10). Then
mu_r>=c r^3, c=lambda(a0-L)>0. Combined with s_r<=d r^3, equations (3)--(4)
give P_r(F)>=B_*(c,d)r^3. If d=0 asymptotically this preserves c.
No exponential exit rate is required by this algebra: exit is one of the
probability losses in L_r. A vanishing exit loss preserves the original
a0 coefficient (when all other losses vanish); a nonzero limiting exit loss
e<a0 can still leave a positive coefficient a0-e; e=a0 can exhaust it.
Measured zero exits on finitely many trials or radii prove none of these
uniform bounds.

Example with exact input budgets, purely illustrative and not claimed for
the field: lambda=2, a0=3/4, losses 1/8 and 1/16 give c=9/8. If d=3,
k=3 yields B_*=5/16, whereas standard Bonferroni gives -3/8. If a separately
necessary event-transfer debit is at most (1/10)r^3, the final coefficient is
5/16-1/10=17/80. The executable certificate recomputes these numbers.

## 6. Eta applies to an event transfer, not to every lower bound

Assume additionally that A is a measurable adjacency event. Define

    a=P_r(A), p=P_r(E_pair), eta=P_r(E_pair and A^c).

When a>0 set q_adj=P_r(E_pair | A); when a=0 the product a q_adj is defined
as P_r(E_pair and A)=0 without defining the conditional probability. Then

    p=a q_adj+eta,       0<=eta<=1-a,
    1-p=(1-a q_adj)-eta
       =P_r(A and E_pair^c)+P_r(A^c and E_pair^c).             (11)

Consequently:

* A direct inclusion (1) pays no eta debit: its target already is E_pair^c.
* A lower bound for the proxy 1-a q_adj must subtract eta. If its coefficient
  is c and limsup eta/r^3<=e, the transferred lower coefficient is at least
  c-e. Eta=o(r^3) preserves c; eta=o(1) is insufficient at the r^3 scale.
* A lower bound for the true adjacent-failure **mass**
  a(1-q_adj)=P_r(A and E_pair^c) needs no eta debit because it is a subset of
  E_pair^c. A conditional probability 1-q_adj alone must still be multiplied
  by the actual adjacency mass a.

Sharp counterexamples distinguish these routes. Let pairing hold surely
and let P(A^c)=r^3. Then eta=r^3=o(1), the proxy failure is r^3, and the true
failure is zero. Alternatively, let P(A)=r^3, let conditional failure on A
be r^3, and let every point in A^c pair. Then 1-q_adj=r^3 but the true
failure is r^6. All four joint atom masses are nonnegative; the checker
verifies (11) exactly for these examples and all denominator-8 four-cell
laws. No measurability or event identification for the Gaussian adjacency
mark is inferred by this finite-law calculation.

## 7. What remains

This proves the abstract inequalities, their optimal integer quadratic
minorant, law-transfer obstruction, rate distinctions and exact event
identities. For a q0 application the actual inclusion, positive exact-law
intensity, all consumed weighted loss bounds, factorial moment bound,
measurability and full-continuum control remain separate obligations. The
same-provider checker/tests and proof review provide no independent-review
credit, no status move and no solved prize problem.
