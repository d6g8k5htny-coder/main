# Bonferroni, eta and exit-budget candidate

The useful increment is an exact integer-count bound. For a qualifying count
N with `{N>=1}` contained in the actual failure event, `E N >= c r^3` and
`E[N(N-1)] <= d r^3`, let `k=floor(d/c)+1`. Then

    P(failure) >= (2kc-d)/(k(k+1)) * r^3 > 0.

This can remain positive when the ordinary Bonferroni expression is negative.
Thus an exact-law pair moment O(r^3) can suffice for positivity; o(r^3)
preserves the full first-moment coefficient. These actual-field moment bounds
remain to be proved.

PROOF.md also proves the precise eta transfer identity, shows when no eta
debit is needed, and replaces excessive per-location uniformity demands by
an exact intensity-weighted integrated loss budget where that can be proved.
It explains the remaining event-inclusion and weighted-law hypotheses.

The executable certificate includes sharp count distributions and exact
counterexamples to first-moment-only, ordinary-to-weighted-law, pointwise
loss, unweighted adjacency, eta=o(1), and missing event-inclusion arguments.
It does not restore K3-THM-001 or change any research status.

Run with Python 3.11:

    python -B bonferroni_eta.py --certificate result.json --output /absolute/new/report.json
    python -B test_bonferroni_eta.py
    python -O -B test_bonferroni_eta.py

The output path must not already exist. Normal and optimized reports were
byte-identical; 28 tests passed in each mode. RUN.json retains exact commands
and log paths. DEPENDENCIES.json separates context reads from runtime
dependencies. MANIFEST.json pins every delivered payload. No repository or
remote content was modified by this project.
