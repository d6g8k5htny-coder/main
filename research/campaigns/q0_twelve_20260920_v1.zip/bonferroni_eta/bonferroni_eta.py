#!/usr/bin/env python3
"""Exact count and event-transfer certificates; no q0 theorem promotion."""
from __future__ import annotations
import argparse
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
SOURCE_IDENTITIES = {
    "GP-LB-STAT-004": (13399, "26a9c7ef46b546acfdb0fda11f6ee8dd1e655752202d0add39e0011adf936a4c"),
    "W10": (32989, "67c7fe63e168060b9db1f2279de5d88e7f804508a0e4e98a90afbec468ee21d1"),
    "W7-SCOPE": (2906, "659e0bf9bc0ae29c84261e40a5ad1bfb6364ac98749c64ee35b496c360eb9f9f"),
}
SOURCE_IDS = {
    "GP-LB-STAT-004": "1lfH7g57LcshqpLfNbrx-H7gbJckpzPqr",
    "W10": "1Ls7kwptRf7XGjmy2y4fZV3lbCtznzsK7",
    "W7-SCOPE": "1K9gkJ1To1v5IHklcSL4q7WJxGekgDdMC",
}

def require(condition, message):
    if not condition:
        raise ValueError(message)

def rational(x):
    require(type(x) in (int, str, F), "only exact rational input is accepted")
    return F(x)

def minorant(n, k):
    require(type(n) is int and n >= 0, "count must be a nonnegative integer")
    require(type(k) is int and k >= 1, "k must be a positive integer")
    return F(n * (2*k + 1 - n), k * (k+1))

def minorant_gap(n, k):
    lhs = F(int(n > 0)) - minorant(n, k)
    rhs = F(0) if n == 0 else F((n-k)*(n-k-1), k*(k+1))
    require(lhs == rhs and rhs >= 0, "integer minorant identity failed")
    return lhs

def moments(distribution):
    require(isinstance(distribution, dict) and distribution, "empty distribution")
    for n, p in distribution.items():
        require(type(n) is int and n >= 0, "count must be a nonnegative integer")
        require(rational(p) >= 0, "negative mass")
    require(sum(map(rational, distribution.values()), F(0)) == 1, "mass is not one")
    mu = sum((F(n)*rational(p) for n,p in distribution.items()), F(0))
    second = sum((F(n*(n-1))*rational(p) for n,p in distribution.items()), F(0))
    union = sum((rational(p) for n,p in distribution.items() if n > 0), F(0))
    return mu, second, union

def optimized_bound(mu_lower, factorial_upper):
    m, s = rational(mu_lower), rational(factorial_upper)
    require(m >= 0 and s >= 0, "moment bounds must be nonnegative")
    if not m:
        return {"k": 1, "bound": F(0), "cauchy_bound": F(0)}
    # The difference B(k+1)-B(k) has the sign of s-k*m.
    k = s // m + 1
    bound = (2*k*m-s)/(k*(k+1))
    require(bound > 0, "positive first moment must give positive count bound")
    return {"k": k, "bound": bound, "cauchy_bound": m*m/(m+s)}

def weighted_probability(probabilities, weights, event):
    require(len(probabilities) == len(weights) == len(event) and len(event) > 0, "atom shape mismatch")
    ps, ws = [rational(x) for x in probabilities], [rational(x) for x in weights]
    require(all(p >= 0 for p in ps) and sum(ps,F(0)) == 1, "invalid base law")
    require(all(w >= 0 for w in ws), "invalid nonnegative Palm weight")
    require(all(type(e) is bool for e in event), "event must be boolean")
    z = sum((p*w for p,w in zip(ps,ws)), F(0))
    require(z > 0, "zero Palm normalizer")
    return sum((p*w for p,w,e in zip(ps,ws,event) if e),F(0))/z

def event_identity(atoms):
    # Four joint masses: (adjacent, paired), (adjacent, not paired),
    # (not adjacent, paired), (not adjacent, not paired).
    require(len(atoms) == 4, "joint law requires four cells")
    ap, af, np, nf = map(rational, atoms)
    require(min(ap,af,np,nf) >= 0 and ap+af+np+nf == 1, "invalid joint law")
    a, p, eta = ap+af, ap+np, np
    require(1-p == (1-ap)-eta == af+nf, "eta identity failed")
    require(0 <= eta <= 1-a and af <= 1-p, "event subset inequality failed")
    return {"adjacency_mass":a,"pair_probability":p,"eta":eta,"proxy_failure":1-ap,
            "actual_failure":1-p,"adjacent_failure_mass":af,
            "conditional_adjacent_failure":af/a if a else None}

def exact_budget(lambda_lower, terminal_floor, losses, pair_coefficient, eta_coefficient=0):
    lam, a, pair, eta = map(rational,(lambda_lower,terminal_floor,pair_coefficient,eta_coefficient))
    ls = [rational(x) for x in losses]
    require(lam > 0 and 0 <= a <= 1, "invalid first-moment or reliability input")
    require(all(0 <= x <= 1 for x in ls), "loss is not a probability upper bound")
    require(pair >= 0 and eta >= 0, "negative debit")
    reliability = max(F(0), a-sum(ls,F(0)))
    first = lam*reliability
    opt = optimized_bound(first,pair)
    return {"reliability_lower":reliability,"qualified_first_coefficient":first,
            "bonferroni_coefficient":max(F(0),first-pair/2-eta),
            "integer_coefficient":max(F(0),opt["bound"]-eta),
            "cauchy_coefficient":max(F(0),opt["cauchy_bound"]-eta),"k":opt["k"]}

def check_sources(source_root):
    result = {}
    for key, (size, digest) in SOURCE_IDENTITIES.items():
        root = source_root/key
        identity = json.loads((root/"IDENTITY.json").read_text())
        require(identity["drive_id"] == identity["inventory"]["id"] == identity["coverage"]["id"] == SOURCE_IDS[key], "source Drive identity mismatch")
        require(identity["coverage"]["sha256"] == digest and identity["coverage"]["bytes"] == size, "source coverage identity mismatch")
        require(identity["inventory"]["context"] == "RESEARCH_SOURCE_CHECK_STATUS", "source inventory context is not active research")
        require(identity["coverage"]["context"] == "RESEARCH_SOURCE_CHECK_STATUS", "source coverage context is not active research")
        path = identity["inventory"]["path"]
        require(path.startswith("01_ACTIVE_RESEARCH_PACKAGES/") and not any(t in path.lower() for t in ("quarantine","legacy","99_do_not_open")), "prohibited source path")
        raw = (root/"source.raw").read_bytes()
        require(len(raw) == size and hashlib.sha256(raw).hexdigest() == digest, "source identity mismatch: "+key)
        reading = (root/"reading.txt").read_bytes()
        require(hashlib.sha256(reading).hexdigest() == identity["reading_sha256"], "reading copy drift")
        require(reading.decode() == raw.decode("utf-8-sig"), "reading copy is not raw source decoding")
        result[key] = {"drive_id":identity["drive_id"],"bytes":size,"sha256":digest,
                       "role":"status and interface routing only; no source premise inherited as proved"}
    return result

def serial(value):
    if isinstance(value,F): return str(value)
    if isinstance(value,dict): return {str(k):serial(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)): return [serial(x) for x in value]
    return value

def build_report(source_root):
    sources = check_sources(source_root)
    # Exhaustively verify a sizeable exact collection; the all-n proof is in PROOF.md.
    identities = sum(minorant_gap(n,k) >= 0 for n in range(65) for k in range(1,33))
    moment_cases = 0
    for a in range(9):
        for b in range(9-a):
            for c in range(9-a-b):
                d = 8-a-b-c
                mu,s,p = moments({0:F(a,8),1:F(b,8),2:F(c,8),5:F(d,8)})
                o = optimized_bound(mu,s)
                require(p >= o["bound"] >= o["cauchy_bound"], "exact distribution bound failed")
                require(all(o["bound"] >= (2*k*mu-s)/(k*(k+1)) for k in range(1,40)), "integer optimization failed")
                moment_cases += 1
    r = F(1,10)
    spike = weighted_probability([r**3,1-r**3],[1/r**3,1/(1-r**3)],[True,False])
    require(spike == F(1,2), "weighted small-event counterexample failed")
    one_two = moments({0:1-r**3+r**6,1:r**3-2*r**6,2:r**6})
    burst_four = moments({0:1-r**3/4,4:r**3/4})
    require(one_two[2] == one_two[0]-one_two[1]/2, "Bonferroni sharpness failed")
    require(burst_four[2] == optimized_bound(*burst_four[:2])["bound"], "integer sharpness failed")
    weighted_factorial = 2*weighted_probability([r**6,1-r**6],[r**-6,0],[True,False])
    require(weighted_factorial == 2, "weighted factorial counterexample failed")
    proxy = event_identity([1-r**3,0,r**3,0])
    adjacent = event_identity([r**3*(1-r**3),r**6,1-r**3,0])
    no_pair_control = []
    for n in (2,4,8,16,32,64,128):
        rr=F(1,n)
        mu,s,p=moments({0:1-rr**4,n:rr**4})
        require(mu==rr**3 and p/rr**3==rr, "first-moment-only counterexample failed")
        no_pair_control.append({"r":rr,"mean_over_r3":mu/rr**3,"union_over_r3":p/rr**3,"factorial_over_r3":s/rr**3})
    witnesses = {
        "bonferroni_sharp_at_counts_0_1_2":{"r":r,"mean":one_two[0],"factorial":one_two[1],"union":one_two[2]},
        "pair_O_r3_preserves_positivity_not_full_coefficient":{"r":r,"count":4,"mean":burst_four[0],"factorial":burst_four[1],"union":burst_four[2],"bonferroni":burst_four[0]-burst_four[1]/2,"optimized":optimized_bound(*burst_four[:2])},
        "first_moment_alone_insufficient":no_pair_control,
        "unweighted_small_event_can_have_Palm_probability_half":{"ordinary_probability":r**3,"weighted_probability":spike},
        "ordinary_pair_O_r6_does_not_transfer":{"r":r,"ordinary_factorial":2*r**6,"weighted_factorial":weighted_factorial},
        "eta_proxy_false_positive":proxy,
        "conditional_adjacency_without_mass":adjacent,
        "pointwise_arch_loss_insufficient":{"r":r,"arch_interval":[0,r],"intensity_density":1/r,"loss_on_arch":1,"normalized_integral_loss":1,"pointwise_limit_on_open_unit_interval":0},
        "many_marginal_losses_insufficient":{"number_of_disjoint_events":1000,"each_probability":"1/1000","union_probability":1},
        "exit_need_not_be_exponential":{"lambda_coefficient":1,"terminal_floor":"1/2","constant_exit_loss":"1/4","surviving_coefficient":"1/4"},
        "exit_may_exhaust_floor":{"lambda_coefficient":1,"terminal_floor":"1/2","constant_exit_loss":"1/2","surviving_coefficient":0},
        "event_inclusion_is_essential":{"r":r,"qualified_count_is_Bernoulli":r**3,"target_failure_probability":0},
    }
    conditional_budgets = {
        "finite_pair_budget":{"inputs":{"lambda_lower":2,"terminal_floor":"3/4","losses":["1/8","1/16"],"pair_coefficient":3},"result":exact_budget(2,"3/4",["1/8","1/16"],3)},
        "eta_debit":{"inputs":{"lambda_lower":2,"terminal_floor":"3/4","losses":["1/8","1/16"],"pair_coefficient":3,"eta_coefficient":"1/10"},"result":exact_budget(2,"3/4",["1/8","1/16"],3,"1/10")},
    }
    return serial({"schema":"bonferroni-eta-exact-lemma-candidate-v1","status":"CONDITIONAL_INTERFACE_LEMMAS_AND_COUNTEREXAMPLES; NOT_A_Q0_ASSEMBLY",
        "certifying_arithmetic":"integer and Fraction only","sources":sources,
        "all_integer_minorant":"1_{n>0} >= n(2k+1-n)/(k(k+1)), n in N_0, k in N_{>=1}",
        "optimized_bound":"k=floor(s/m)+1; P(N>0)>=(2*k*m-s)/(k*(k+1))>=m^2/(m+s)",
        "finite_checks":{"integer_identities":identities,"exact_distributions":moment_cases},
        "witnesses":witnesses,"conditional_budget_examples":conditional_budgets,
        "remaining_obligations":["Exact target event E_pair and qualifying-event inclusion for the field.","Exact typed pair-Palm law and marked Campbell disintegration; no height-clipped density substitution.","Positive arch intensity and consumed-scope reliability loss budget, direct or via a proved weighted law transfer.","Exact-law second factorial moment O(r^3) for positive-rate route, or o(r^3) to preserve the full first-moment coefficient.","If using adjacency-product proxy, eta budget at r^3 scale; direct failure inclusion has no eta debit.","Measurability, integrability, continuum radius scope and any required all-arch control.","Independent review and owner adjudication; no source status changed."],
        "original_prize_closed":False,"canonical_status_change":False,"organizational_independence_credit":0})

def report_bytes(report):
    return (json.dumps(report,indent=2,sort_keys=True,ensure_ascii=False)+"\n").encode()

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sources",type=Path,default=HERE/"sources")
    parser.add_argument("--certificate",type=Path)
    parser.add_argument("--output",type=Path)
    args=parser.parse_args()
    try:
        payload=report_bytes(build_report(args.sources))
        if args.certificate:
            require(args.certificate.read_bytes()==payload,"certificate differs from exact recomputation")
        if args.output:
            with args.output.open("xb") as f: f.write(payload)
    except (ValueError,KeyError,TypeError,OSError) as exc:
        print("FAIL: "+str(exc),file=sys.stderr)
        return 1
    print("PASS: exact Bonferroni, integer moment, eta and weighted-loss interface candidate")
    return 0

if __name__=="__main__":
    raise SystemExit(main())
