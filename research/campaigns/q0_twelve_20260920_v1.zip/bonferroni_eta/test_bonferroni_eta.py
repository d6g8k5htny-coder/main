#!/usr/bin/env python3
from fractions import Fraction as F
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

import bonferroni_eta as b

HERE=Path(__file__).resolve().parent

class ExactMath(unittest.TestCase):
    def test_integer_minorant_identity(self):
        for n in range(101):
            for k in range(1,41):
                self.assertGreaterEqual(b.minorant_gap(n,k),0)

    def test_optimal_k(self):
        for m in (F(1,100),F(1,7),F(1),F(17,3)):
            for s in (F(0),m/3,m,2*m,13*m/2,100*m):
                opt=b.optimized_bound(m,s)
                self.assertTrue(all(opt['bound'] >= (2*k*m-s)/(k*(k+1)) for k in range(1,150)))
                self.assertGreaterEqual(opt['bound'],opt['cauchy_bound'])

    def test_sharp_two_point_support(self):
        for k in range(1,21):
            m=F(1,100)
            s=(k-F(1,3))*m
            x=(k*m-s)/k
            y=(s-(k-1)*m)/(k+1)
            mu,ss,p=b.moments({0:1-x-y,k:x,k+1:y})
            self.assertEqual((mu,ss),(m,s))
            self.assertEqual(p,b.optimized_bound(m,s)['bound'])

    def test_usual_bonferroni_can_be_negative(self):
        m,s,p=b.moments({0:F(999,1000),4:F(1,1000)})
        self.assertLess(m-s/2,0)
        self.assertEqual(b.optimized_bound(m,s)['bound'],p)

    def test_half_ordered_pair_debit_is_necessary(self):
        m,s,p=b.moments({0:F(7,8),2:F(1,8)})
        self.assertEqual(m-s/2,p)
        self.assertGreater(m-s/4,p)

    def test_first_moment_only_counterexample(self):
        for n in (2,4,16,64,256):
            r=F(1,n)
            m,s,p=b.moments({0:1-r**4,n:r**4})
            self.assertEqual(m,r**3)
            self.assertEqual(p/r**3,r)
            self.assertEqual(s/r**3,n-1)

    def test_weighted_factorial_does_not_follow_ordinary(self):
        r=F(1,10)
        _,ordinary,_=b.moments({0:1-r**6,2:r**6})
        weighted_event=b.weighted_probability([r**6,1-r**6],[r**-6,0],[True,False])
        self.assertEqual(ordinary,2*r**6)
        self.assertEqual(2*weighted_event,2)

    def test_weighted_small_probability_counterexample(self):
        for e in (F(1,2),F(1,100),F(1,1000000)):
            self.assertEqual(b.weighted_probability([e,1-e],[1/e,1/(1-e)],[True,False]),F(1,2))

    def test_all_denominator_eight_joint_laws(self):
        for a in range(9):
            for c in range(9-a):
                for d in range(9-a-c):
                    row=b.event_identity([F(a,8),F(c,8),F(d,8),F(8-a-c-d,8)])
                    self.assertEqual(row['actual_failure'],row['proxy_failure']-row['eta'])
                    self.assertLessEqual(row['adjacent_failure_mass'],row['actual_failure'])

    def test_eta_o_one_not_o_r3(self):
        for n in (2,10,100):
            r=F(1,n)
            row=b.event_identity([1-r**3,0,r**3,0])
            self.assertEqual(row['proxy_failure'],r**3)
            self.assertEqual(row['actual_failure'],0)

    def test_adjacency_conditional_needs_mass(self):
        r=F(1,10)
        row=b.event_identity([r**3*(1-r**3),r**6,1-r**3,0])
        self.assertEqual(row['conditional_adjacent_failure'],r**3)
        self.assertEqual(row['actual_failure'],r**6)

    def test_exact_budget(self):
        row=b.exact_budget(2,'3/4',['1/8','1/16'],3,'1/10')
        self.assertEqual(row['qualified_first_coefficient'],F(9,8))
        self.assertEqual(row['integer_coefficient'],F(17,80))
        self.assertEqual(row['bonferroni_coefficient'],0)

    def test_exit_exhausts_floor(self):
        row=b.exact_budget(1,'1/2',['1/2'],0)
        self.assertEqual(row['integer_coefficient'],0)
        self.assertEqual(b.exact_budget(1,'1/2',['1/4'],0)['integer_coefficient'],F(1,4))

    def test_noninteger_count_rejected(self):
        with self.assertRaises(ValueError): b.minorant(F(3,2),1)
        with self.assertRaises(ValueError): b.moments({F(3,2):1})
        self.assertGreater(F(3,2)*(3-F(3,2))/2,1)

    def test_negative_and_boolean_counts_rejected(self):
        with self.assertRaises(ValueError): b.moments({-1:1})
        with self.assertRaises(ValueError): b.minorant(True,1)
        with self.assertRaises(ValueError): b.minorant(1,0)

    def test_nonprobabilities_rejected(self):
        with self.assertRaises(ValueError): b.moments({0:F(1,2)})
        with self.assertRaises(ValueError): b.moments({0:2,1:-1})
        with self.assertRaises(ValueError): b.event_identity([1,0,1,-1])

    def test_nonexact_or_negative_bound_rejected(self):
        with self.assertRaises(ValueError): b.optimized_bound(0.1,0)
        with self.assertRaises(ValueError): b.optimized_bound(1,-1)
        with self.assertRaises(ValueError): b.exact_budget(1,1,[2],0)

    def test_invalid_palm_weight_rejected(self):
        with self.assertRaises(ValueError): b.weighted_probability([1],[0],[True])
        with self.assertRaises(ValueError): b.weighted_probability([1],[-1],[True])

class ActualCLI(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.expected=b.report_bytes(b.build_report(HERE/'sources'))

    def cli(self,*args,script=None):
        cmd=[sys.executable]
        if sys.flags.optimize: cmd.append('-O')
        cmd+=['-B',str(script or HERE/'bonferroni_eta.py'),*map(str,args)]
        return subprocess.run(cmd,capture_output=True,timeout=30)

    def test_good_report_exact(self):
        with tempfile.TemporaryDirectory() as tmp:
            cert=Path(tmp)/'cert.json'; cert.write_bytes(self.expected)
            out=Path(tmp)/'out.json'
            p=self.cli('--certificate',cert,'--output',out)
            self.assertEqual(p.returncode,0,p.stderr)
            self.assertEqual(out.read_bytes(),self.expected)

    def test_preexisting_output_preserved(self):
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp)/'out.json';out.write_bytes(b'preserve')
            p=self.cli('--output',out)
            self.assertNotEqual(p.returncode,0)
            self.assertEqual(out.read_bytes(),b'preserve')

    def test_bad_numeric_certificate_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            obj=json.loads(self.expected)
            obj['conditional_budget_examples']['eta_debit']['result']['integer_coefficient']='1'
            cert=Path(tmp)/'bad.json';cert.write_bytes(b.report_bytes(obj))
            p=self.cli('--certificate',cert)
            self.assertNotEqual(p.returncode,0)
            self.assertIn(b'certificate differs',p.stderr)

    def test_unearned_status_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            obj=json.loads(self.expected);obj['canonical_status_change']=True
            cert=Path(tmp)/'bad.json';cert.write_bytes(b.report_bytes(obj))
            self.assertNotEqual(self.cli('--certificate',cert).returncode,0)

    def test_source_byte_mutation_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            src=Path(tmp)/'sources';shutil.copytree(HERE/'sources',src)
            p=src/'W10'/'source.raw';p.write_bytes(p.read_bytes()+b'corrupt')
            run=self.cli('--sources',src)
            self.assertNotEqual(run.returncode,0)
            self.assertIn(b'source identity mismatch',run.stderr)

    def test_quarantined_context_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            src=Path(tmp)/'sources';shutil.copytree(HERE/'sources',src)
            p=src/'W10'/'IDENTITY.json';obj=json.loads(p.read_text())
            obj['coverage']['context']='QUARANTINE_OR_HISTORY'
            p.write_text(json.dumps(obj))
            run=self.cli('--sources',src)
            self.assertNotEqual(run.returncode,0)
            self.assertIn(b'coverage context',run.stderr)

    def test_excluded_path_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            src=Path(tmp)/'sources';shutil.copytree(HERE/'sources',src)
            p=src/'W10'/'IDENTITY.json';obj=json.loads(p.read_text())
            obj['inventory']['path']='01_ACTIVE_RESEARCH_PACKAGES/99_DO_NOT_OPEN/W10'
            p.write_text(json.dumps(obj))
            run=self.cli('--sources',src)
            self.assertNotEqual(run.returncode,0)
            self.assertIn(b'prohibited source path',run.stderr)

    def test_wrong_source_id_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            src=Path(tmp)/'sources';shutil.copytree(HERE/'sources',src)
            p=src/'W10'/'IDENTITY.json';obj=json.loads(p.read_text())
            obj['drive_id']='different-file'
            p.write_text(json.dumps(obj))
            run=self.cli('--sources',src)
            self.assertNotEqual(run.returncode,0)
            self.assertIn(b'Drive identity mismatch',run.stderr)

    def test_wrong_minorant_implementation_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            script=Path(tmp)/'bad.py'
            text=(HERE/'bonferroni_eta.py').read_text()
            changed=text.replace('n * (2*k + 1 - n)','n * (2*k + 2 - n)')
            self.assertNotEqual(changed,text);script.write_text(changed)
            run=self.cli('--sources',HERE/'sources',script=script)
            self.assertNotEqual(run.returncode,0)
            self.assertIn(b'minorant identity failed',run.stderr)

    def test_wrong_optimizer_implementation_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            script=Path(tmp)/'bad.py'
            text=(HERE/'bonferroni_eta.py').read_text()
            changed=text.replace('k = s // m + 1','k = 1')
            self.assertNotEqual(changed,text);script.write_text(changed)
            run=self.cli('--sources',HERE/'sources',script=script)
            self.assertNotEqual(run.returncode,0)

if __name__=='__main__': unittest.main(verbosity=2)
