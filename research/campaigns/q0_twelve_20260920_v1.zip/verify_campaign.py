#!/usr/bin/env python3
"""Replay twelve explicitly reviewed project commands and retain every result.

This records execution, source identity, and unresolved obligations. It never
closes a mathematical gate or treats consensus as proof.
"""
from concurrent.futures import ThreadPoolExecutor, as_completed
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent

def require(condition, message):
    if not condition:
        raise ValueError(message)

def identity(path):
    raw = path.read_bytes()
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--jobs', type=int, choices=(1,2,3), default=3)
    args = parser.parse_args()
    require(sys.version_info >= (3,11), 'Python 3.11 or later required')
    require(args.output_dir.is_absolute(), 'absolute output directory required')
    output = args.output_dir.resolve()
    require(not output.is_relative_to(HERE), 'output must be outside immutable bundle')
    plan_path = HERE/'verification_plan.json'
    plan = json.loads(plan_path.read_text())
    repo = Path(plan['repository']).resolve()
    require(not output.is_relative_to(repo), 'output must be outside repository')
    require(plan['schema'] == 'q0-twelve-project-verification-plan-v1', 'unknown plan')
    projects = plan['projects']
    require(len(projects) == 12 and len({x['key'] for x in projects}) == 12, 'twelve distinct projects required')
    before = {}
    for name, expected in plan['files'].items():
        file = (HERE/name).resolve()
        require(file.is_relative_to(HERE), 'bundle path escapes root')
        before[name] = identity(file)
        require(before[name] == expected, 'candidate bytes changed: '+name)
    dependency_before = {}
    for name, expected in plan['repository_dependencies'].items():
        file = (repo/name).resolve()
        require(file.is_relative_to(repo), 'repository path escapes root')
        dependency_before[name] = identity(file)
        require(dependency_before[name] == expected, 'repository dependency changed: '+name)
    output.mkdir(parents=True,exist_ok=False)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')

    def run(project):
        key = project['key']
        require(key.isidentifier(), 'invalid project key')
        out = output/key
        out.mkdir()
        argv = [sys.executable,'-B'] + [s.replace('{bundle}',str(HERE)).replace('{output}',str(out)).replace('{repo}',str(repo)) for s in project['argv']]
        started = time.monotonic()
        try:
            proc = subprocess.run(argv,cwd=HERE/project['working_directory'],env=env,capture_output=True,text=True,timeout=project['timeout_seconds'],check=False)
            code, stdout, stderr, timed_out = proc.returncode, proc.stdout, proc.stderr, False
        except subprocess.TimeoutExpired as exc:
            code, stdout, stderr, timed_out = None, exc.stdout or '', exc.stderr or '', True
            if isinstance(stdout,bytes): stdout = stdout.decode('utf-8',errors='replace')
            if isinstance(stderr,bytes): stderr = stderr.decode('utf-8',errors='replace')
        (out/'stdout.txt').write_text(stdout)
        (out/'stderr.txt').write_text(stderr)
        passed = code == 0 and project['success_text'] in stdout+stderr
        report_identity = None
        if project.get('expected_report'):
            file = out/project['result_file']
            report_identity = identity(file) if file.is_file() else None
            passed = passed and report_identity == before[project['expected_report']]
        return {'key':key,'argv':argv,'returncode':code,'timed_out':timed_out,
                'elapsed_seconds':round(time.monotonic()-started,3),'passed':passed,
                'fresh_report':report_identity,'technical_scope':project['technical_scope'],
                'remaining_obligations':project['remaining_obligations'],
                'scientific_status_changed':False,'organizational_independence_credit':0}

    results = []
    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        futures = [pool.submit(run,p) for p in projects]
        for future in as_completed(futures):
            result = future.result()
            results.append(result)
            print(result['key']+': '+('PASS' if result['passed'] else 'FAIL'),flush=True)
    after = {name:identity(HERE/name) for name in before}
    dependency_after = {name:identity(repo/name) for name in dependency_before}
    stable = before == after and dependency_before == dependency_after
    payload = {'schema':'q0-twelve-project-verification-receipt-v1','plan':identity(plan_path),
               'files':before,'repository_dependencies':dependency_before,'inputs_unchanged':stable,
               'results':sorted(results,key=lambda r:r['key']),'passed':stable and all(r['passed'] for r in results),
               'scientific_status_changed':False,'organizational_independence_credit':0,'original_prize_closed':False}
    raw = json.dumps(payload,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
    receipt = {'payload':payload,'payload_sha256':hashlib.sha256(raw).hexdigest()}
    (output/'verification_receipt.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n')
    return 0 if payload['passed'] else 1

if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print('FAIL: '+str(exc),file=sys.stderr)
        raise SystemExit(1)
