#!/usr/bin/env python3
"""Two source-defined gradient differences; author proof, no scientific promotion.
All claimed arithmetic is exact Fraction and repository-certified intervals.
No frozen source is executed. Fixed-r source is extended to variable r here.
"""
from __future__ import annotations
import argparse
import ast
from fractions import Fraction as F
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
REPO=Path('/Users/dylanroy/Documents/Codex/research-main')
# The explicit CLI root is resolved before importing the permitted interval code.
if '--repo' in sys.argv:
    REPO=Path(sys.argv[sys.argv.index('--repo')+1]).resolve()
sys.path.insert(0,str(REPO))
from research.interval import Interval as I, exp
from research.rn.side24 import image_tail, kernel_derivative

SOURCE_SHA={
 'sources/pin_transform.py.txt':'c6988ac7fcfa32dcc03c1374e13fb4c26af1c12c25cb824a315e6dce8991fd41',
 'sources/rn_field.py.txt':'d9167ae821684f716fdbae11cd39eb13818422f50b6566f677d62c292e4a93c8',
 'sources/H5_PROMOTE.md':'7258c84a7720704e577f341252aa809888735d9f8ace1674429e004da6c6172a',
 'sources/CHART_SIDE_JETMOD_PLAN.md':'0ccadff30e36e920494f5d7a1552dfb41173dffad7054f21878569a5bbb24822',
 'sources/H5_ANALYTIC_ADVANCE.md':'3c95c4b59e58d2ccfbf3cff8afcde81639b2866ebbac3738968f8a42d161de88',
}


def require(ok,message):
    if not ok: raise ValueError(message)


def rational(x):
    if type(x) not in (int,F): raise TypeError('exact int/Fraction required, not bool or float')
    x=F(x)
    require(max(abs(x.numerator).bit_length(),x.denominator.bit_length())<=4096,'oversized rational')
    return x


def band(a,b):
    a,b=rational(a),rational(b)
    require(0<=a<=b<=F(1,20),'radius band must be within [0,1/20]')
    return a,b


def iv(x): return {'lo':str(x.lo),'hi':str(x.hi)}


def decimal(x,places=15):
    scale=10**places
    low=x.lo.numerator*scale//x.lo.denominator
    high=-((-x.hi.numerator*scale)//x.hi.denominator)
    def fmt(v):
        sign='-' if v<0 else '';v=abs(v)
        return sign+str(v//scale)+'.'+str(v%scale).zfill(places)
    return [fmt(low),fmt(high)]


def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()


def strict_pairs(pairs):
    d={}
    for k,v in pairs:
        require(k not in d,'duplicate JSON key: '+k);d[k]=v
    return d


def reject_number(x):raise ValueError('noninteger JSON number refused: '+x)


def load(path):
    data=Path(path).read_bytes();require(len(data)<=5000000,'JSON input exceeds size limit')
    return json.loads(data,object_pairs_hook=strict_pairs,parse_float=reject_number,parse_constant=reject_number)


def source_binding():
    for p,digest in SOURCE_SHA.items():
        require(hashlib.sha256((HERE/p).read_bytes()).hexdigest()==digest,'source identity mismatch: '+p)
    for x in load(HERE/'DEPENDENCIES.json')['files']:
        data=(REPO/x['path']).read_bytes()
        require(len(data)==x['bytes'] and hashlib.sha256(data).hexdigest()==x['sha256'],'dependency identity mismatch: '+x['path'])
    syntax=ast.parse((HERE/'sources/pin_transform.py.txt').read_text())
    fn=next(n for n in syntax.body if isinstance(n,ast.FunctionDef) and n.name=='matrix_B')
    returned=next(n for n in fn.body if isinstance(n,ast.Return))
    rows=returned.value.args[0].elts
    for i,expected in [(3,'[0, -1/r, 0, 0, 1/r, 0]'),(4,'[0, 0, -1/r, 0, 0, 1/r]')]:
        require(ast.dump(rows[i])==ast.dump(ast.parse(expected,mode='eval').body),'normalized gradient coordinate changed')
    assignments={n.targets[0].id:n.value for n in ast.parse((HERE/'sources/rn_field.py.txt').read_text()).body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name)}
    require(ast.literal_eval(assignments['JETS'])==[(0,0),(1,0),(0,1)],'RN5 derivative order changed')
    expected=ast.parse('[(p,a) for p in (-R/2,R/2) for a in JETS] + [(p,a) for p in (-R/2,R/2) for a in HJETS]',mode='eval').body
    require(ast.dump(assignments['RAW'])==ast.dump(expected),'RN5 pin order changed')
    # Scope check is deliberately distinct from the mathematical checks.
    require('still-unenumerated full 24-jet set' in (HERE/'sources/H5_ANALYTIC_ADVANCE.md').read_text(),'source gap statement missing')
    return dict(SOURCE_SHA)


def central_g(r,terms=96):
    """(1-exp(-r²/2))/r², with exact continuous value 1/2 at zero."""
    r=rational(r);band(0,r)
    require(type(terms) is int and 2<=terms<=512,'invalid series terms')
    x=r*r/2;term=F(1,2);total=F(0)
    for n in range(terms):
        total+=term;term*=-x/F(n+2)
    return I(min(total,total+term),max(total,total+term))


def central_h(r,terms=96):
    """[phi''(r)-phi''(0)]/r² = central_g(r)+exp(-r²/2)."""
    r=rational(r);band(0,r)
    # Same exact alternating remainder for exp, avoiding a weaker precision floor.
    x=r*r/2;term=F(1);total=F(0)
    for n in range(terms):
        total+=term;term*=-x/F(n+1)
    return central_g(r,terms)+I(min(total,total+term),max(total,total+term))


@lru_cache(maxsize=1)
def normalizer():
    finite=I.exact(1)+2*exp(I.exact(-288),610)
    omitted=I((2*exp(I.exact(-1152),400)).lo,image_tail(0,F(0),prec=400))
    require(omitted.lo>0,'normalizer omitted tail is not positive')
    return finite+omitted,finite,omitted


def image_even_derivative(order,b):
    """H^(order)(s), H=sum_{j!=0}phi(s+24j), uniformly |s|<=b.
    Orders2,4 are positive because |s+24j|>=23.95 and He2,He4>0 there.
    """
    b=rational(b);band(0,b)
    require(type(order) is int and order in (2,4),'image order must be 2 or 4')
    s=I(0,b);first=I.exact(0)
    for j in (-1,1):
        x=s+24*j;x2=x*x
        p=x2-1 if order==2 else x2*x2-6*x2+3
        require(p.lo>0,'image Hermite positivity failed')
        first+=p*exp(-x2/2,220)
    tail=image_tail(order,b,prec=220)
    require(tail>0,'omitted image derivative tail missing')
    return first+I(0,tail),tail


@lru_cache(maxsize=1)
def gradient_variance():
    """v=-k''(0)=(1-H''(0))/Z, with all images."""
    h2,t=image_even_derivative(2,F(0));z,_,_=normalizer()
    result=(I.exact(1)-h2)/z
    require(result.lo>0,'gradient variance not positive')
    return result


def enclose(a=F(0),b=F(1,20),mutation=None):
    """Full continuum enclosure of Cov(V3,V4), with r=0 as L2 extension.
    mutation is for negative-control tests only and NEVER used in candidate.
    """
    a,b=band(a,b)
    require(mutation in (None,'omit_image4','flip_image4','lose_covariance_sign','wrong_scale','drop_factor2'),'unknown test mutation')
    z,_,_=normalizer()
    h2,t2=image_even_derivative(2,b);h4,t4=image_even_derivative(4,b)
    g=I(central_g(b).lo,central_g(a).hi)
    h=I(central_h(b).lo,central_h(a).hi)
    e2=h2/2;e4=h4/2
    long_numerator=h+e4
    if mutation=='omit_image4':long_numerator=h
    if mutation=='flip_image4':long_numerator=h-e4
    factor=1 if mutation=='drop_factor2' else 2
    longitudinal=factor*long_numerator/z
    transverse=2*gradient_variance()*(g-e2)/z
    if mutation=='lose_covariance_sign': longitudinal=-longitudinal
    if mutation=='wrong_scale':
        # Invalid variance with an extra r² factor (valid only in point controls).
        longitudinal=longitudinal*I(a*a,b*b)
    result={'V3_variance':longitudinal.round_out(2048),'V4_variance':transverse.round_out(2048),'cross_covariance':I.exact(0)}
    terms={'central_g':g,'central_h':h,'image2_integral':e2,'image4_integral':e4,'image2_tail':t2,'image4_tail':t4,'normalizer':z,'gradient_variance':gradient_variance()}
    return result,terms


def direct_point(r):
    """Supplementary point control from normalized covariance derivatives."""
    r=rational(r);band(0,r)
    k20=kernel_derivative(2,F(0),prec=400,bits=1024)
    if r==0:return {'V3_variance':kernel_derivative(4,F(0),prec=400,bits=1024),'V4_variance':k20*k20,'cross_covariance':I.exact(0)}
    return {'V3_variance':2*(kernel_derivative(2,r,prec=400,bits=1024)-k20)/(r*r),'V4_variance':-2*k20*(1-kernel_derivative(0,r,prec=400,bits=1024))/(r*r),'cross_covariance':I.exact(0)}


def build_report():
    sources=source_binding();result,terms=enclose()
    require(result['V3_variance'].lo>F(299687,100000),'longitudinal lower target failed')
    require(result['V3_variance'].hi<F(3000000000000001,10**15),'longitudinal upper target failed')
    require(result['V4_variance'].lo>F(999375,10**6),'transverse lower target failed')
    require(result['V4_variance'].hi<F(1000000000000001,10**15),'transverse upper target failed')
    _,finite,omitted=normalizer()
    return {'schema_version':1,'target':'Q0-P12-JET-DEFINITION-20260920-v1','claim_id':'d82842d4-3422-4dee-aceb-47b8989f6a63','technical_state':'AUTHOR_PROOF_WITH_EXACT_INTERVAL_REPLAY','coordinates':{'V3':'(fx(S)-fx(M))/r','V4':'(fy(S)-fy(M))/r','M':['-r/2','0'],'S':['r/2','0'],'variance_normalization_power':2,'source':'matrix_B rows3,4 (zero-based); not an identification with the missing full 24-jet map'},'radius_domain':{'lo':'0','hi':'1/20','zero_role':'continuous Gaussian L2 extension (fxx(0),fxy(0)); quotient defined only for positive r'},'covariance':{k:iv(v) for k,v in result.items()},'outward_decimal':{k:decimal(v) for k,v in result.items()},'decomposition':{k:iv(v) if isinstance(v,I) else str(v) for k,v in terms.items()},'normalizer_finite':iv(finite),'normalizer_omitted':iv(omitted),'uniform_eigenvalue_lower':'1599/1600','inverse_operator_norm_upper':'1600/1599','source_sha256':sources,'arithmetic':'exact Fraction and certified interval exp, no floating-point exploration','source_definition_status':'two canonical corrected-pin coordinates recovered; full H5 24-entry map still insufficient data','scientific_promotions':0,'independence_credit':0,'obligation_closed':False,'original_prize_closed':False,'does_not_establish':['Membership in or recovery of the full H5 24-jet (J,p_J) interface','Conditional covariance, positive inverse of full G12, or cover map F','Claimed-modulus acceptance, H5 restoration, RN spatial cover, or q0 theorem closure','Independent acceptance or public publication']}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,default=REPO);p.add_argument('--output',type=Path);p.add_argument('--verify',type=Path);p.add_argument('--self-test',action='store_true');args=p.parse_args()
    require(args.repo.resolve()==REPO,'repo resolution inconsistency')
    report=build_report()
    if args.verify:require(canonical(load(args.verify))==canonical(report),'stored result differs from exact replay')
    if args.self_test:
        import unittest
        import test_checker
        suite=unittest.defaultTestLoader.loadTestsFromModule(test_checker)
        require(unittest.TextTestRunner(verbosity=1).run(suite).wasSuccessful(),'negative controls failed')
    if args.output:
        with args.output.open('x') as f:json.dump(report,f,indent=2,ensure_ascii=False);f.write('\n')
    print('PASS: two source-defined gradient differences on [0,1/20]; lambda_min > 0.999375; 0 promotions; full 24-jet map missing')

if __name__=='__main__':
    try:main()
    except (OSError,ValueError,TypeError,ArithmeticError) as error:
        print('FAIL: '+str(error),file=sys.stderr);raise SystemExit(1)
