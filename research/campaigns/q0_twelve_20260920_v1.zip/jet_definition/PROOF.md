# Two normalized gradient differences on the full small-radius interval

Author reconstruction, 2026-09-20. Target `Q0-P12-JET-DEFINITION-20260920-v1`;
R17 claim `d82842d4-3422-4dee-aceb-47b8989f6a63`. Independent review pending;
organizational independence credit zero. No scientific status changes.

For the normalized SIDE24 Gaussian field, write

\[
 M_r=(-r/2,0),\quad S_r=(r/2,0),\quad
 V_3(r)=\frac{f_x(S_r)-f_x(M_r)}r,\quad
 V_4(r)=\frac{f_y(S_r)-f_y(M_r)}r.
\]

These are exactly rows 3 and 4 (zero based) of `matrix_B` in the source
`pin_transform.py`, not a newly invented pair of H5 interface entries.
For every `0 < r <= 1/20`, their **unconditional** covariance is diagonal,
and the following outward rational decimal bounds hold:

| Entry | Lower bound | Upper bound |
|---|---:|---:|
| Var(V3) | 2.996876822184468 | 3.000000000000001 |
| Var(V4) | 0.999375260335306 | 1.000000000000000 |
| Cov(V3,V4) | 0 | 0 |

Consequently this two-coordinate covariance has
`lambda_min > 1599/1600 = 0.999375` and inverse operator norm
`< 1600/1599`. The bounds also hold at `r=0` for the continuous Gaussian L2
extension `(f_xx(0),f_xy(0))`. The quotients themselves are defined only for
positive r. This does not assert any inverse bound for the full pin Gram
matrix or a covariance conditioned on pins.

## Exact source identity and bounded search

The source covariance law is RN5's normalized periodized Gaussian,
`closure_round2/rn_field.py`, 16,701 bytes, SHA
`d9167ae821684f716fdbae11cd39eb13818422f50b6566f677d62c292e4a93c8`.
Its carrier is Drive `1g5UP_KYlvPmx7LFwjGk6qK5QZLnL1hLj`, archive SHA
`28c1c385406452a706f11aea1646a87585b002841005d57febdf32222c368c6e`.
The source implementation fixes `r=1/20`; extension across the interval is
a new author derivation in this note, not inherited certification.

The two coordinates and their powers are bound to
`K3_SIDE24_LB/UPPER2D/H2_foundations/pin_transform.py`, 17,623 bytes, SHA
`c6988ac7fcfa32dcc03c1374e13fb4c26af1c12c25cb824a315e6dce8991fd41`,
from Drive archive `1vSI-evINWskhXVyiZ0slt-rLT74sPpXH`, 30,148,285 bytes,
SHA `a2136bc033f349382f9896896347da7a6dabde3334103276ad04db9205aa2b5b`.
The checker hashes these source bytes and compares the exact AST of the two
matrix rows. No source code is imported or executed.

Exclusion metadata was inspected before archive extraction. Neither source
member is excluded. No excluded H5 certificate body, legacy source or vault
body was opened. The H5 plan is used only to identify the required interface,
not to inherit numerical certification from its historical claims.

The bounded keyword search used `24-jet`, `p_J`, `jetmod`, `G12` against the
eligible stored text/metadata index; exact search results are retained.
The nonexcluded `CHART_SIDE_JETMOD_PLAN.md`, Drive
`1SKlIuKXqWRT_mXWj7P1DHK3OrJHj-QBC`, SHA
`0ccadff30e36e920494f5d7a1552dfb41173dffad7054f21878569a5bbb24822`,
restates the requirement but does not enumerate its 24 entries.
`MATH-20260917-b9c2_H5_ANALYTIC_ADVANCE.md`, Drive
`1Mo7EUbXvrMpmzjvtNDz1W6TBM-4zg2-u`, SHA
`3c95c4b59e58d2ccfbf3cff8afcde81639b2866ebbac3738968f8a42d161de88`,
explicitly distinguishes six demonstration stencils from the still
unenumerated full interface. It already discusses the longitudinal stencil;
this work makes no novelty claim and does not use its numerical certificate.
A bounded unsuccessful search does not prove the definitions do not exist.

Missing exact inputs remain:

1. A source-bound 24-entry `(J,p_J)` list with each offset/derivative/sign.
2. Its authoritative whole-band partition and per-entry modulus criterion.
3. Its conditioned G12 transformation, inverse/Schur bounds and map F to
   the chart cover integrand.

The result therefore certifies two canonical corrected-pin coordinates and
makes **no claim to have certified two of the unidentified 24 H5 entries**.

## Covariance identity, all signs and powers

Let `phi(u)=exp(-u²/2)`,

\[
 S(s)=\sum_{j\in\mathbb Z}\phi(s+24j),\quad Z=S(0),\quad k(s)=S(s)/Z.
\]

The two-axis kernel is exactly `K(x,y)=k(x)k(y)`: absolute convergence factors
the full sum and its full normalizer. In particular `k(0)=1` and `k'(0)=0`
exactly. Derivatives in the second covariance argument introduce the factor
`(-1)^|beta|`. Thus `Cov(f_x(p),f_x(q))=-k''(p_x-q_x)` on y=0, while
`Cov(f_y(p),f_y(q))=-k(p_x-q_x) k''(0)` there. Expanding the variance of each
difference yields

\[
 L(r):=\operatorname{Var}V_3(r)=2\frac{k''(r)-k''(0)}{r^2},\quad
 T(r):=\operatorname{Var}V_4(r)=2v\frac{1-k(r)}{r^2},\quad v=-k''(0).
\]

Every `Cov(f_x(p),f_y(q))` contains `k'(0)`, so the cross entry is exactly zero.
The division by `r²` comes from the two source factors `1/r`. Replacing it by
`r⁰`, dropping the factor two or losing the second-argument sign gives a
different covariance and is rejected by a separate direct-kernel control.

The fundamental theorem of calculus gives
`V3(r)=integral[-1/2,1/2] f_xx(rt,0) dt`, and similarly for `V4` and `f_xy`.
All kernel derivatives are continuous by uniformly summable Gaussian
majorants. The integrals consequently converge in Gaussian L2 to the named
second derivatives as r decreases to zero. Equivalently the covariance
formulas have the continuous endpoints `L(0)=k''''(0)` and `T(0)=v²`.

## Cancellation-free central terms

Put `H(s)=S(s)-phi(s)`. Define

\[
 g(r)=\frac{1-e^{-r^2/2}}{r^2}
      =\frac12\int_0^1 e^{-tr^2/2}\,dt,\quad
 h(r)=\frac{\phi''(r)-\phi''(0)}{r^2}=g(r)+e^{-r^2/2}.
\]

Both are positive and decreasing for positive r. Their continuous values at
zero are `1/2` and `3/2`. The exact alternating series

\[
 g(r)=\tfrac12\sum_{n\ge0}\frac{(-x)^n}{(n+1)!},\quad
 e^{-x}=\sum_{n\ge0}\frac{(-x)^n}{n!},\qquad x=r^2/2\le1/800
\]

have decreasing terms tending to zero. Consecutive partial sums enclose the
value. The implementation uses 96 terms plus the next signed term, in exact
Fraction arithmetic. There is no subtraction of near-unit intervals and no
negative power of r is evaluated at zero. On any `[a,b]` in `[0,1/20]`,
`g(r)` lies between the computed lower at b and upper at a; likewise h.

## Uniform second- and fourth-derivative image corrections

For each nonzero image and `|s|<=1/20`, `|s+24j|>=23.95`. Therefore

\[
 \phi''(u)=(u^2-1)\phi(u)>0,\qquad
 \phi''''(u)=(u^4-6u^2+3)\phi(u)>0.
\]

Uniform derivative convergence allows termwise differentiation, and H is even.
Taylor's integral identity applied to H and H'' gives, for positive r,

\[
 E_2(r):=\int_0^1(1-t)H''(tr)\,dt
         =\frac{H(r)-H(0)}{r^2},\quad
 E_4(r):=\int_0^1(1-t)H''''(tr)\,dt
         =\frac{H''(r)-H''(0)}{r^2}.
\]

Both corrections are positive. The resulting stable formulas are

\[
 L(r)=\frac{2(h(r)+E_4(r))}{Z},\quad
 T(r)=\frac{2v(g(r)-E_2(r))}{Z},\quad
 v=\frac{1-H''(0)}{Z}.
\]

The signs differ: the curvature correction is subtracted from g, but the
fourth-derivative correction is added to h. Dropping/flipping E4 produces a
disjoint interval from the independent direct covariance at `r=1/20`.

The first two noncentral images j=±1 are interval-evaluated over the whole
box `s in [0,b]`. No grid inference is used. All remaining images use
`research.rn.side24.image_tail(n,b)` with n=2 or4. Explicitly, if
`C_n` is the sum of absolute coefficients of the probabilists' Hermite
polynomial He_n (`C2=2`, `C4=10`), then

\[
 t_n=C_n(48+b)^n e^{-(48-b)^2/2},\quad
 q_n=\left(\frac{72+b}{48+b}\right)^n
 e^{-((72-b)^2-(48-b)^2)/2},\quad
 T_n=2t_n/(1-q_n).
\]

For `|u|>=1`, `|He_n(u)|<=C_n |u|^n`. Polynomial and Gaussian consecutive
ratios both decrease with the image index, so the ratio at j=2 bounds every
subsequent ratio. The implementation checks `q_n<1` and uses the geometric
series for every omitted image. Since the actual even derivatives are
positive here, the complete image enclosure is first-pair + `[0,T_n]`.
Integration multiplies this enclosure by exactly `integral(1-t)=1/2`.
This proves bounds for every r in the full continuum.

## Complete normalizer

The denominator is enclosed as
`Z = 1 + 2exp(-288) + sum_{|j|>=2}exp(-(24j)²/2)`.
Its omitted part has positive lower bound `2exp(-1152)` and the complete
geometric upper `image_tail(0,0)`. The finite part is computed with 610-digit
interval precision so the omitted-pair witness is resolvable; correctness
comes from rational containment, not precision alone. The exact control
proves `Z_finite.lo + omitted.lo > Z_finite.hi`. Dropping this tail demonstrably
fails containment. The y-axis normalizer was cancelled only against the
identical complete y-axis sum; no y-tail was silently discarded.

Final `round_out(2048)` only enlarges the endpoint intervals. The displayed
decimals are rounded outward to 15 places using integer arithmetic.
The matrix is diagonal; positivity and comparison of its two diagonal lower
bounds prove the stated eigenvalue and inverse-norm inequalities.

## Replay and meaningful failure controls

`RUN.json` gives exact Python3.11 commands. `checker.py --verify result.json`
recomputes the complete report, hashes source and repository imports and
compares canonical JSON bytes. Bool/int aliases, noninteger numbers,
duplicate keys and inward-mutated bounds cannot pass this comparison.
The output option creates a new file exclusively.

Sixteen tests run in normal and optimized Python. They cover direct-kernel
checks at eight points including the continuous endpoint; monotonic endpoint
ordering; narrower subband bounds; alternating-series containment of a
separately composed exponential; parity; source hashes and exact AST rows;
wrong covariance sign/r-power/factor2; omitted/flipped E4; missing normalizer
tail; and hundredfold weakening of second/fourth image tails against an
actual omitted pair. Seven mutated stored reports are rejected by the actual
CLI in both modes. Point checks are supplementary; the monotonicity and
image integral argument establishes the continuum result.

This does not establish the full H5 interface, conditioned G12, chart cover,
all-small-r q0 theorem, excluded-certificate restoration or scientific
promotion. It is not an independent-provider review, a formal proof-assistant
proof, or a claim of novelty. Original prize problems closed: false.
