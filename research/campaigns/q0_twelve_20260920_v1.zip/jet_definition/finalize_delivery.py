#!/usr/bin/env python3
"""Replays and freezes this author-side delivery. No scientific promotion."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

HERE=Path(__file__).resolve().parent
REPO=Path('/Users/dylanroy/Documents/Codex/research-main')
PYTHON=Path('/Users/dylanroy/Documents/Codex/2026-09-19/connect-research-repository/work/venv/bin/python')

def identity(p):
    data=p.read_bytes();return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}


def main():
    commands={
      'normal':[str(PYTHON),'-B','checker.py','--repo',str(REPO),'--verify','result.json'],
      'optimized':[str(PYTHON),'-B','-O','checker.py','--repo',str(REPO),'--verify','result.json'],
      'tests_normal':[str(PYTHON),'-B','-m','unittest','-v','test_checker'],
      'tests_optimized':[str(PYTHON),'-B','-O','-m','unittest','-v','test_checker'],
    }
    inputs=['checker.py','test_checker.py','result.json','PROOF.md','DEPENDENCIES.json']
    before={name:identity(HERE/name) for name in inputs}
    deps=json.loads((HERE/'DEPENDENCIES.json').read_text())['files']
    deps_before={x['path']:identity(REPO/x['path']) for x in deps}
    runs=[]
    for name,argv in commands.items():
        r=subprocess.run(argv,cwd=HERE,capture_output=True,text=True,timeout=60)
        (HERE/(name+'.stdout.txt')).write_text(r.stdout)
        (HERE/(name+'.stderr.txt')).write_text(r.stderr)
        ok=r.returncode==0 and ('PASS:' in r.stdout if name in ('normal','optimized') else 'Ran 16 tests' in r.stderr and '\nOK\n' in r.stderr)
        runs.append({'name':name,'argv':argv,'returncode':r.returncode,'passed':ok,'stdout':identity(HERE/(name+'.stdout.txt')),'stderr':identity(HERE/(name+'.stderr.txt'))})
        print(name,'PASS' if ok else 'FAIL')
    after={name:identity(HERE/name) for name in inputs}
    deps_after={x['path']:identity(REPO/x['path']) for x in deps}
    passed=all(x['passed'] for x in runs) and before==after and deps_before==deps_after
    receipt={'schema_version':1,'passed':passed,'runs':runs,'inputs_stable':before==after,'dependencies_stable':deps_before==deps_after,'input_identities':before,'dependency_identities':deps_before,'tests_per_mode':16,'actual_cli_mutants_per_mode':7,'scientific_promotions':0,'independence_credit':0,'obligation_closed':False}
    (HERE/'verification_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    run={'schema_version':1,'cwd':str(HERE),'repository':str(REPO),'python':str(PYTHON),'argv':commands['normal'],'optimized_argv':commands['optimized'],'test_commands':[commands['tests_normal'],commands['tests_optimized']],'success_criterion':'Every command exits 0; checker prints PASS; each test mode reports Ran 16 tests and OK; exact report and source/dependency hashes unchanged. Full H5 interface remains insufficient data.','scope':'Two unconditional corrected gradient coordinates on [0,1/20] including continuous endpoint; not full 24-jet, q0 or RN closure.'}
    (HERE/'RUN.json').write_text(json.dumps(run,indent=2)+'\n')
    files={str(p.relative_to(HERE)):identity(p) for p in sorted(HERE.rglob('*')) if p.is_file() and p.name!='MANIFEST.json' and '__pycache__' not in p.parts}
    manifest={'schema_version':1,'target':'Q0-P12-JET-DEFINITION-20260920-v1','files':files,'file_count':len(files),'verification_passed':passed,'scientific_promotions':0,'independence_credit':0,'original_prize_closed':False,'obligation_closed':False}
    (HERE/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print('MANIFEST',identity(HERE/'MANIFEST.json'))
    if not passed:raise SystemExit(1)

if __name__=='__main__':main()
