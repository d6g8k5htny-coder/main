"""Meaningful exact controls; no status promotions or independence credit."""
from fractions import Fraction as F
from pathlib import Path
import copy
import json
import subprocess
import sys
import tempfile
import unittest
import checker as c


def overlaps(x,y):return max(x.lo,y.lo)<=min(x.hi,y.hi)


class GradientDifferenceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.report=c.build_report()
        cls.enclosure,_=c.enclose()

    def test_exact_source_coordinate_binding(self):
        self.assertEqual(len(c.source_binding()),5)

    def test_source_hash_mutation_rejected(self):
        key='sources/pin_transform.py.txt';old=c.SOURCE_SHA[key]
        try:
            c.SOURCE_SHA[key]='0'*64
            with self.assertRaisesRegex(ValueError,'source identity'):c.source_binding()
        finally:c.SOURCE_SHA[key]=old

    def test_positive_whole_domain_bounds(self):
        self.assertGreater(self.enclosure['V3_variance'].lo,F(299687,100000))
        self.assertLess(self.enclosure['V3_variance'].hi,F(3000000000000001,10**15))
        self.assertGreater(self.enclosure['V4_variance'].lo,F(999375,10**6))
        self.assertLess(self.enclosure['V4_variance'].hi,F(1000000000000001,10**15))

    def test_continuous_endpoint(self):
        result,_=c.enclose(F(0),F(0));direct=c.direct_point(F(0))
        for key in result:self.assertTrue(overlaps(result[key],direct[key]))
        self.assertGreater(result['V3_variance'].lo,F(2999999,1000000))
        self.assertGreater(result['V4_variance'].lo,F(999999,1000000))

    def test_supplementary_direct_points(self):
        # This is a separate covariance-shaped check, not the continuum proof.
        for r in [F(0),F(1,10**8),F(1,10000),F(1,1000),F(1,80),F(1,40),F(7071,200000),F(1,20)]:
            direct=c.direct_point(r)
            for key in direct:self.assertTrue(overlaps(self.enclosure[key],direct[key]),(r,key))

    def test_central_functions_against_exp(self):
        for r in [F(1,100),F(1,40),F(1,20)]:
            e=c.exp(c.I.exact(-r*r/2),400)
            g=(1-e)/(r*r);h=g+e
            for outer,inner in [(c.central_g(r,32),g),(c.central_h(r,32),h)]:
                self.assertLessEqual(outer.lo,inner.lo);self.assertGreaterEqual(outer.hi,inner.hi)

    def test_monotone_central_endpoint_order(self):
        for f in [c.central_g,c.central_h]:
            self.assertGreater(f(F(1,100)).lo,f(F(1,20)).hi)
            self.assertGreater(f(F(0)).lo,f(F(1,100)).hi)

    def test_subband_strict_tightening(self):
        small,_=c.enclose(F(1,40),F(1,20))
        for key in ['V3_variance','V4_variance']:
            self.assertLess(small[key].width(),self.enclosure[key].width())
            self.assertGreaterEqual(small[key].lo,self.enclosure[key].lo)
            self.assertLessEqual(small[key].hi,self.enclosure[key].hi)

    def test_image4_omission_and_sign_rejected_by_direct_law(self):
        r=F(1,20);true=c.direct_point(r)['V3_variance']
        for mutation in ['omit_image4','flip_image4']:
            invalid,_=c.enclose(r,r,mutation)
            self.assertFalse(overlaps(true,invalid['V3_variance']),mutation)

    def test_factor_scale_and_covariance_sign_rejected(self):
        r=F(1,20);true=c.direct_point(r)['V3_variance']
        for mutation in ['drop_factor2','wrong_scale','lose_covariance_sign']:
            invalid,_=c.enclose(r,r,mutation)
            self.assertFalse(overlaps(true,invalid['V3_variance']),mutation)

    def test_positive_denominator_tail_is_not_droppable(self):
        z,finite,omitted=c.normalizer()
        self.assertGreater(omitted.lo,0)
        self.assertGreater(finite.lo+omitted.lo,finite.hi)
        self.assertGreater(z.lo,finite.hi)

    def test_weakened_image_tail_misses_actual_first_omitted_pair(self):
        for order in (2,4):
            x=c.I.exact(48);x2=x*x
            p=x2-1 if order==2 else x2*x2-6*x2+3
            actual_pair=2*p*c.exp(-x2/2,400)
            tail=c.image_tail(order,F(0),prec=400)
            self.assertGreater(actual_pair.lo,tail/100)

    def test_cross_covariance_is_exact_zero_by_y_oddness(self):
        # Every covariance fx(p),fy(q) on y=0 has a k'(0) factor, exactly zero.
        self.assertEqual(c.kernel_derivative(1,F(0)).lo,0)
        self.assertEqual(c.kernel_derivative(1,F(0)).hi,0)
        self.assertEqual(c.iv(self.enclosure['cross_covariance']),{'lo':'0','hi':'0'})
        for displacement in (-F(1,20),F(0),F(1,20)):
            pair=-c.kernel_derivative(1,displacement)*c.kernel_derivative(1,F(0))
            self.assertEqual(pair.lo,0);self.assertEqual(pair.hi,0)

    def test_unsafe_inputs_rejected(self):
        for pair in [(True,F(1,20)),(0.0,F(1,20)),(-1,F(1,20)),(F(1,10),F(1,20)),(0,F(1,10))]:
            with self.assertRaises((TypeError,ValueError)):c.enclose(*pair)
        for terms in [True,1,513]:
            with self.assertRaises(ValueError):c.central_g(F(0),terms)
        with self.assertRaises(ValueError):c.enclose(mutation='unknown')

    def test_scope_does_not_close_missing_interface(self):
        self.assertIs(self.report['obligation_closed'],False)
        self.assertIs(self.report['original_prize_closed'],False)
        self.assertEqual(self.report['independence_credit'],0)
        self.assertIn('full H5 24-entry map still insufficient data',self.report['source_definition_status'])

    def test_cli_stored_report_mutations_normal_and_optimized(self):
        # Actual CLI replay, not a helper that accidentally rechecks the good global.
        with tempfile.TemporaryDirectory(dir=c.HERE) as tmp:
            tmp=Path(tmp)
            cases={'good':self.report}
            for label,path,value in [
                ('inward_upper',('covariance','V3_variance','hi'),'2'),
                ('missing_tail',('decomposition','image4_tail'),'0'),
                ('false_zero_alias',('scientific_promotions',),False),
                ('source_id',('source_sha256','sources/pin_transform.py.txt'),'0'*64),
                ('promotion',('obligation_closed',),True)]:
                obj=copy.deepcopy(self.report);part=obj
                for key in path[:-1]:part=part[key]
                part[path[-1]]=value;cases[label]=obj
            paths={}
            for label,obj in cases.items():
                paths[label]=tmp/(label+'.json');paths[label].write_text(json.dumps(obj))
            paths['duplicate_key']=tmp/'duplicate.json';paths['duplicate_key'].write_text('{"a":1,"a":1}')
            paths['float_number']=tmp/'float.json';paths['float_number'].write_text('{"a":0.0}')
            for optimized in (False,True):
                for label,path in paths.items():
                    argv=[sys.executable,'-B']+(['-O'] if optimized else [])+[str(c.HERE/'checker.py'),'--repo',str(c.REPO),'--verify',str(path)]
                    result=subprocess.run(argv,capture_output=True,text=True,timeout=30)
                    self.assertEqual(result.returncode==0,label=='good',(optimized,label,result.stdout,result.stderr))
                    self.assertIn('PASS:' if label=='good' else 'FAIL:',result.stdout+result.stderr)


if __name__=='__main__':unittest.main(verbosity=2)
