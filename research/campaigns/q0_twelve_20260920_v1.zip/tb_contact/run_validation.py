#!/usr/bin/env python3
"""Record bounded normal/-O replay and hostile tests without repository writes."""
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent

def identity(path):
    data=path.read_bytes()
    return {'bytes':len(data),'sha256':sha256(data).hexdigest()}


def main():
    destination=ROOT/(sys.argv[1] if len(sys.argv)>1 else 'validation_v1')
    if destination.parent.resolve()!=ROOT or destination.exists():
        raise SystemExit('FAIL: validation directory must be new and immediately below this project')
    destination.mkdir()
    inputs={str(p.relative_to(ROOT)):identity(p) for p in sorted(ROOT.rglob('*'))
            if p.is_file() and destination not in p.parents}
    environment={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}
    entries=[]
    for name,flags in (('normal',[]),('optimized',['-O'])):
        commands=[(name,[sys.executable,'-B']+flags+[str(ROOT/'contact_check.py'),
                    '--certificate',str(ROOT/'result.json'),'--output',str(destination/(name+'.json'))]),
                  ('tests_'+name,[sys.executable,'-B']+flags+[str(ROOT/'test_contact.py')])]
        for label,argv in commands:
            start=datetime.now(timezone.utc).isoformat()
            run=subprocess.run(argv,cwd=ROOT,env=environment,text=True,capture_output=True,timeout=60)
            stdout=destination/(label+'.stdout.txt')
            stderr=destination/(label+'.stderr.txt')
            stdout.write_text(run.stdout)
            stderr.write_text(run.stderr)
            passed=(run.returncode==0 and
                    (('Ran 35 tests' in run.stderr and run.stderr.rstrip().endswith('OK'))
                     if label.startswith('tests_') else (run.stdout.startswith('PASS:') and not run.stderr)))
            entries.append({'name':label,'argv':argv,'cwd':str(ROOT),'started_utc':start,
                            'returncode':run.returncode,'passed':passed,
                            'stdout':identity(stdout),'stderr':identity(stderr)})
    same_inputs=all(identity(ROOT/rel)==expected for rel,expected in inputs.items())
    same_reports=all((destination/(name+'.json')).read_bytes()==(ROOT/'result.json').read_bytes()
                     for name in ('normal','optimized'))
    passed=all(entry['passed'] for entry in entries) and same_inputs and same_reports
    receipt={'schema':'tb-contact-validation-v1','passed':passed,'entries':entries,
             'input_identities':inputs,'inputs_unchanged':same_inputs,'normal_optimized_reports_equal_candidate_bytes':same_reports,
             'checks_per_suite':35,'calculation_mutation_kinds':12,'report_mutation_kinds':4,
             'source_tampering_kinds':1,'negative_controls_run_in_both_modes':True,
             'scientific_status_changed':False,'organizational_independence_credit':0,
             'original_prize_closed':False}
    (destination/'verification_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(('PASS' if passed else 'FAIL')+': normal/-O exact replay and 35 tests in each mode; reports byte-identical; input hashes stable')
    return 0 if passed else 1

if __name__=='__main__':
    raise SystemExit(main())
