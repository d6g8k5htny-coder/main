"""Hostile CLI tests: altered live calculations, reports, and actual source bytes."""
from pathlib import Path
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parent
CHECKER=ROOT/'contact_check.py'
CERTIFICATE=ROOT/'result.json'
# The test list is independent of the checker's enumeration; accidental removal
# of a production control cannot silently remove its test here.
MUTATIONS=(
    'pin-entry-sign','pin-density-direction','height-jacobian',
    'hessian-scaling','fold-cubic','lifetime-half','lifetime-wrong-power',
    'omit-cutoff','unordered-half','duplicate-area','unweighted-selection',
    'omit-nonadjacent-selected',
)


class ContactChecks(unittest.TestCase):
    def command(self,mode,args):
        command=[sys.executable,'-B']+(['-O'] if mode else [])+[str(CHECKER)]+list(args)
        result=subprocess.run(command,cwd=ROOT,text=True,capture_output=True,timeout=30,
                              env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
        return result

    def expect_reject(self,mode,args):
        run=self.command(mode,args)
        self.assertEqual(run.returncode,1,run.stdout+run.stderr)
        self.assertIn('FAIL:',run.stderr)
        self.assertNotIn('PASS:',run.stdout)

    def test_normal_and_optimized_reports_identical(self):
        with tempfile.TemporaryDirectory(prefix='test-',dir=ROOT) as td:
            reports=[]
            for mode in (False,True):
                output=Path(td)/('optimized.json' if mode else 'normal.json')
                run=self.command(mode,['--certificate',str(CERTIFICATE),'--output',str(output)])
                self.assertEqual(run.returncode,0,run.stdout+run.stderr)
                self.assertIn('PASS:',run.stdout)
                self.assertEqual(run.stderr,'')
                reports.append(output.read_bytes())
            self.assertEqual(reports[0],reports[1])
            self.assertEqual(reports[0],CERTIFICATE.read_bytes())


def make_mutation(mode,mutation):
    def test(self):
        self.expect_reject(mode,['--mutation',mutation])
    return test


def make_report_tamper(mode,kind):
    def test(self):
        report=json.loads(CERTIFICATE.read_text())
        if kind=='bool-versus-zero':
            report['scientific_status_changed']=0
        elif kind=='contact-coefficient':
            report['algebra']['contact_density']='J = (1/12) p_Y z'
        elif kind=='cutoff':
            report['algebra']['cutoff']='no cutoff'
        elif kind=='integral':
            report['weak_identity_exact_tests'][7]['pushforward_integral']='0'
        with tempfile.TemporaryDirectory(prefix='test-',dir=ROOT) as td:
            bad=Path(td)/'bad-report.json'
            bad.write_text(json.dumps(report))
            self.expect_reject(mode,['--certificate',str(bad)])
    return test


def make_source_tamper(mode):
    def test(self):
        with tempfile.TemporaryDirectory(prefix='test-',dir=ROOT) as td:
            sources=Path(td)/'sources'
            shutil.copytree(ROOT/'sources',sources)
            path=sources/'LS-DER-021'/'reading.txt'
            text=path.read_text()
            self.assertIn('det T_r=-r^-5',text)
            path.write_text(text.replace('det T_r=-r^-5','det T_r=-r^+5'))
            self.expect_reject(mode,['--sources',str(sources)])
    return test


for mode in (False,True):
    suffix='optimized' if mode else 'normal'
    for mutation in MUTATIONS:
        setattr(ContactChecks,'test_'+suffix+'_'+mutation.replace('-','_'),make_mutation(mode,mutation))
    for kind in ('bool-versus-zero','contact-coefficient','cutoff','integral'):
        setattr(ContactChecks,'test_'+suffix+'_report_'+kind.replace('-','_'),make_report_tamper(mode,kind))
    setattr(ContactChecks,'test_'+suffix+'_source_bytes',make_source_tamper(mode))

if __name__=='__main__':
    unittest.main(verbosity=2)
