#!/usr/bin/env python3
"""Exact algebra/integral replay of a conditional contact pushforward lemma.

Author-side finite checks support PROOF.md; they are not a formal proof of
Kac--Rice applicability, a contact limit, selection asymptotics, or Theorem B.
No floating-point path, third-party imports, network, or repository mutation.
"""
from __future__ import annotations

import argparse
from fractions import Fraction as F
from hashlib import sha256
from itertools import permutations
import json
from pathlib import Path
import sys
import zipfile
import xml.etree.ElementTree as ET

NAMES = ('r','c','s','b','k','am','bm','cm','as','bs','cs','u','v','q','ell','root6')
DIM = len(NAMES)
ZERO_EXP = (F(0),) * DIM


class Failure(Exception):
    pass


def require(condition, message):
    # Explicit, optimization-safe: no mathematical check uses assert.
    if not condition:
        raise Failure(message)


class Poly:
    """Exact sparse Laurent/generalized polynomial; root6 is positive cube root 6.

    Exponents of root6 are integral, reduced using root6**3 = 6. All other
    variables with fractional powers are positive in their stated domains.
    """
    def __init__(self, terms=None):
        self.terms = {}
        for exps, coeff in (terms or {}).items():
            coeff = F(coeff)
            exps = list(map(F, exps))
            root = exps[-1]
            require(root.denominator == 1, 'nonintegral root6 power')
            quot, rem = divmod(root.numerator, 3)
            exps[-1] = F(rem)
            coeff *= F(6) ** quot
            key = tuple(exps)
            self.terms[key] = self.terms.get(key, F(0)) + coeff
        self.terms = {e:c for e,c in self.terms.items() if c}

    @staticmethod
    def const(value):
        return Poly({ZERO_EXP:F(value)})

    @staticmethod
    def var(name):
        exps = list(ZERO_EXP)
        exps[NAMES.index(name)] = F(1)
        return Poly({tuple(exps):F(1)})

    @staticmethod
    def lift(value):
        return value if isinstance(value, Poly) else Poly.const(value)

    def __add__(self, other):
        terms = self.terms.copy()
        for exps, coeff in Poly.lift(other).terms.items():
            terms[exps] = terms.get(exps, F(0)) + coeff
        return Poly(terms)
    __radd__ = __add__

    def __neg__(self):
        return Poly({e:-c for e,c in self.terms.items()})

    def __sub__(self, other):
        return self + -Poly.lift(other)

    def __rsub__(self, other):
        return Poly.lift(other) + -self

    def __mul__(self, other):
        terms = {}
        for e,c in self.terms.items():
            for f,d in Poly.lift(other).terms.items():
                key = tuple(x+y for x,y in zip(e,f))
                terms[key] = terms.get(key,F(0)) + c*d
        return Poly(terms)
    __rmul__ = __mul__

    def __pow__(self, power):
        power = F(power)
        if power < 0 or power.denominator != 1:
            require(len(self.terms) == 1, 'only monomials admit inverse/fractional powers')
            (exps, coeff), = self.terms.items()
            require(power.denominator == 1 or coeff == 1, 'fractional coefficient unsupported')
            return Poly({tuple(e*power for e in exps):coeff**power.numerator if power.denominator==1 else 1})
        result = Poly.const(1)
        base = self
        n = power.numerator
        while n:
            if n % 2:
                result = result*base
            base = base*base
            n //= 2
        return result

    def __truediv__(self, other):
        return self * Poly.lift(other)**-1

    def __eq__(self, other):
        return self.terms == Poly.lift(other).terms

    def derivative(self, name):
        index = NAMES.index(name)
        require(name != 'root6','root6 is an algebraic constant')
        terms = {}
        for exps, coeff in self.terms.items():
            if exps[index]:
                new = list(exps)
                new[index] -= 1
                terms[tuple(new)] = coeff*exps[index]
        return Poly(terms)

    def substitute(self, name, value):
        index = NAMES.index(name)
        value = Poly.lift(value)
        total = Poly.const(0)
        for exps, coeff in self.terms.items():
            rest = list(exps)
            rest[index] = 0
            total += Poly({tuple(rest):coeff}) * value**exps[index]
        return total


def determinant(matrix):
    n = len(matrix)
    total = Poly.const(0)
    for perm in permutations(range(n)):
        sign = -1 if sum(perm[i]>perm[j] for i in range(n) for j in range(i+1,n))%2 else 1
        term = Poly.const(sign)
        for i in range(n):
            term *= matrix[i][perm[i]]
            if not term.terms:
                break
        total += term
    return total


def multiply(a,b):
    return [[sum((a[i][k]*b[k][j] for k in range(len(b))),Poly.const(0))
             for j in range(len(b[0]))] for i in range(len(a))]


def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False)


def file_identity(path):
    data=path.read_bytes()
    return {'bytes':len(data),'sha256':sha256(data).hexdigest()}


def verify_sources(directory):
    binding_path=Path(__file__).with_name('SOURCE_BINDING.json')
    binding=json.loads(binding_path.read_text())
    records=[]
    require(len(binding['sources'])==4,'source count')
    for source in binding['sources']:
        location=directory/source['key']
        for part, expected in source['files'].items():
            require(file_identity(location/part)==expected,'source identity mismatch: '+source['key']+'/'+part)
        identity=json.loads((location/'IDENTITY.json').read_text())
        require(identity['drive_id']==source['drive_id'],'Drive identity mismatch')
        require(identity['coverage']['sha256']==source['files']['source.docx']['sha256'],'export hash inconsistent')
        require(identity['reading_sha256']==source['files']['reading.txt']['sha256'],'reading hash inconsistent')
        namespace='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
        with zipfile.ZipFile(location/'source.docx') as archive:
            document=ET.fromstring(archive.read('word/document.xml'))
        paragraphs=[]
        for paragraph in document.iter(namespace+'p'):
            parts=[]
            for node in paragraph.iter():
                if node.tag==namespace+'t':
                    parts.append(node.text or '')
                elif node.tag==namespace+'tab':
                    parts.append('\t')
                elif node.tag in (namespace+'br',namespace+'cr'):
                    parts.append('\n')
            paragraphs.append(''.join(parts))
        extracted=('\n'.join(paragraphs)+'\n').encode('utf-8')
        require(extracted==(location/'reading.txt').read_bytes(),'DOCX reading extraction mismatch')
        records.append({'key':source['key'],'drive_id':source['drive_id'],
                        'derived_reading_reproduced_from_export':True,
                        'export':source['files']['source.docx'],'derived_reading':source['files']['reading.txt']})
    return records


def cube_root_integer(value):
    require(value >= 0,'cube root domain')
    lo,hi=0,max(1,value)
    while lo<hi:
        mid=(lo+hi)//2
        if mid**3<value:
            lo=mid+1
        else:
            hi=mid
    require(lo**3==value,'not a perfect cube')
    return lo


def rational_power(value,power):
    value,power=F(value),F(power)
    if power.denominator==1:
        return value**power.numerator
    require(power.denominator==3,'unsupported exact exponent')
    root=F(cube_root_integer(value.numerator),cube_root_integer(value.denominator))
    return root**power.numerator


def integral_power(power,lo,hi):
    power=F(power)
    require(power>-1 or lo>0,'nonintegrable at zero')
    require(power!=-1,'logarithmic primitive outside test class')
    return (rational_power(hi,power+1)-rational_power(lo,power+1))/(power+1)


MUTATIONS=(
    'pin-entry-sign','pin-density-direction','height-jacobian',
    'hessian-scaling','fold-cubic','lifetime-half','lifetime-wrong-power',
    'omit-cutoff','unordered-half','duplicate-area','unweighted-selection',
    'omit-nonadjacent-selected',
)


def derive(mutation=None):
    v={name:Poly.var(name) for name in NAMES}
    r,c,s,b,k=(v[n] for n in ('r','c','s','b','k'))
    half=F(1,2)
    # Coordinate order: (x1,x2,r,theta) -> (M1,M2,S1,S2).
    space=[[1,0,-c/2,r*s/2],[0,1,-s/2,-r*c/2],
           [1,0,c/2,-r*s/2],[0,1,s/2,r*c/2]]
    require(determinant(space)==r*(c*c+s*s),'endpoint spatial Jacobian')
    # The trigonometric identity c²+s²=1 supplies the positive r Jacobian.
    joint=[row+[0,0] for row in space]+[[0,0,0,0,1,0],[0,0,-k*r*r/2,0,1,-r**3/6]]
    require(determinant(joint)==-r**4*(c*c+s*s)/6,'full endpoint and mark Jacobian')
    # Columns fM,fS,ftM,fsM,ftS,fsS; rows V+,Vcorr-,Gt+,Gt-,Gs+,Gs-.
    T=[[half,half,0,0,0,0],[-r**-3,r**-3,-r**-2/2,0,-r**-2/2,0],
       [0,0,half,0,half,0],[0,0,-r**-1,0,r**-1,0],
       [0,0,0,half,0,half],[0,0,0,-r**-1,0,r**-1]]
    if mutation=='pin-entry-sign':
        T[1][1]=-r**-3
    require(determinant(T)==-r**-5,'corrected six-pin determinant')
    inverse=[[1,-r**3/2,-r/2,0,0,0],[1,r**3/2,r/2,0,0,0],
             [0,0,1,-r/2,0,0],[0,0,0,0,1,-r/2],
             [0,0,1,r/2,0,0],[0,0,0,0,1,r/2]]
    identity=[[Poly.const(int(i==j)) for j in range(6)] for i in range(6)]
    require(multiply(T,inverse)==identity and multiply(inverse,T)==identity,'six-pin inverse round trip')
    raw=[[b],[b-k*r**3/6],[0],[0],[0],[0]]
    target=[[b-k*r**3/12],[-k/6],[Poly.const(0)],[Poly.const(0)],[Poly.const(0)],[Poly.const(0)]]
    require(multiply(T,raw)==target,'transformed exact pin target')
    density_factor=r**(5 if mutation=='pin-density-direction' else -5)
    mark_factor=r**3/(3 if mutation=='height-jacobian' else 6)
    am,bm,cm,aa,bs,cs=(v[n] for n in ('am','bm','cm','as','bs','cs'))
    detm=determinant([[r*am,r*bm],[r*bm,cm]])
    dets=determinant([[r*aa,r*bs],[r*bs,cs]])
    delta_m,delta_s=am*cm-r*bm**2,aa*cs-r*bs**2
    require(detm==r*delta_m and dets==r*delta_s,'individual Hessian determinant')
    weight_factor=r**(1 if mutation=='hessian-scaling' else 2)
    require(detm*dets==weight_factor*delta_m*delta_s,'Hessian product scale')
    require(mark_factor*density_factor*weight_factor==F(1,6),'r^3 r^-5 r^2 density cancellation')
    # Exact cubic model in the declared oriented pair frame.
    u,w,q=(v[n] for n in ('u','v','q'))
    model=b-k*r**3/12+k*u**3/(6 if mutation=='fold-cubic' else 3)-k*r*r*u/4+q*w*w/2
    ft,fs=model.derivative('u'),model.derivative('v')
    for point,height,curvature in ((-r/2,b,-k*r),(r/2,b-k*r**3/6,k*r)):
        at=lambda expr:expr.substitute('u',point).substitute('v',0)
        require(at(model)==height,'cubic fold endpoint height')
        require(at(ft)==0 and at(fs)==0,'cubic fold critical pins')
        require(at(ft.derivative('u'))==curvature,'cubic fold Hessian orientation')
        require(at(fs.derivative('v'))==q,'cubic fold transverse curvature')
    require(ft.derivative('u').derivative('u')==2*k,'fold third derivative 2 kappa')
    # Positive root6 and positive kappa,ell; no approximate cube roots.
    ell,root6=v['ell'],v['root6']
    rstar=root6*ell**F(1,3)*k**F(-1,3)
    require(k*rstar**3/6==ell,'inverse lifetime map')
    jac=root6**2/3*k**F(-2,3)*ell**F(-1,3)
    if mutation=='lifetime-half':
        jac=jac/2
    if mutation=='lifetime-wrong-power':
        jac=root6**2/3*k**F(-2,3)*ell**F(-2,3)
    require(rstar*rstar.derivative('ell')==jac,'lifetime pushforward r dr coefficient')
    require(jac*(k*rstar**2/2)==rstar,'forward/inverse lifetime derivative chain')
    # A nontrivial truncated weak identity with K=1, k in (6,48), 0<r<1/2,
    # one-unit birth interval, and one-radian oriented angular arc.
    moments=[]
    for n in range(13):
        raw_moment=((F(48)**(n+1)-F(6)**(n+1))/F(n+1)
                    *F(1,2)**(3*n+2)/(F(6)**n*(3*n+2)))
        # Independently reduced piecewise density: 6 ell^-1/3 below 1/8;
        # 12 ell^-1/3 - 12 from 1/8 to 1; zero elsewhere.
        if mutation=='omit-cutoff':
            pushed=6*integral_power(F(n)-F(1,3),0,1)
        else:
            pushed=(6*integral_power(F(n)-F(1,3),0,F(1,8))
                    +12*integral_power(F(n)-F(1,3),F(1,8),1)
                    -12*integral_power(n,F(1,8),1))
        if mutation=='unordered-half':
            pushed/=2
        require(raw_moment==pushed,'weak pushforward moment/cutoff/order n='+str(n))
        moments.append({'test':'ell^'+str(n),'endpoint_integral':str(raw_moment),'pushforward_integral':str(pushed)})
    specific=F(21,4)
    total=specific*(576**2 if mutation=='duplicate-area' else 576)
    require(total==F(3024),'ordinary area must occur exactly once')
    # Same raw conditional law, four equally likely states. W weights 1,3,2,6.
    weights=list(map(F,(1,3,2,6)))
    totalw=sum(weights)
    adjacent={0,1}
    selected={1,3}
    p=sum(weights[i] for i in selected)/totalw
    if mutation=='unweighted-selection':
        p=F(len(selected),len(weights))
    a=sum(weights[i] for i in adjacent)/totalw
    qadj=sum(weights[i] for i in adjacent & selected)/sum(weights[i] for i in adjacent)
    eta=sum(weights[i] for i in selected-adjacent)/totalw
    if mutation=='omit-nonadjacent-selected':
        eta=F(0)
    expected_selected_weight=sum(weights[i] for i in selected)/len(weights)
    require(F(totalw,len(weights))*p==expected_selected_weight,'selection must use weighted typed Palm probability')
    require(p==a*qadj+eta,'adjacency decomposition requires the nonadjacent selected mass')
    return {
        'schema':'tb-contact-exact-chain-v1',
        'claim':'Conditional weak pushforward and normalization lemma for the all-typed ordered contact measure',
        'algebra':{
            'spatial_jacobian':'r (cos(theta)^2 + sin(theta)^2) = r',
            'joint_signed_jacobian':'-r^4/6',
            'six_pin_signed_determinant':'-r^-5',
            'density_direction':'p_X = r^-5 p_Y',
            'pin_target':['b-kappa*r^3/12','-kappa/6','0','0','0','0'],
            'hessian_product':'det(H_M) det(H_S) = r^2 Delta_M Delta_S',
            'contact_density':'J = (1/6) p_Y z',
            'selected_density':'K = (1/6) p_Y E_Q[(W/r^2) 1_E] = J p_weighted',
            'lifetime_inverse':'r_ell(kappa) = (6*ell/kappa)^(1/3)',
            'lifetime_jacobian':'r dr = (6^(2/3)/3) kappa^(-2/3) ell^(-1/3) d ell',
            'cutoff':'0 < ell < kappa*r_c^3/6; equivalently kappa > 6*ell/r_c^3',
            'total_area_factor':'576',
        },
        'cubic_fold':{'potential':'b-kappa*r^3/12 + kappa*u^3/3 - kappa*r^2*u/4 + q*v^2/2',
                      'hypotheses':'r>0, kappa>0, q<0',
                      'maximum':'(-r/2,0)','saddle':'(r/2,0)',
                      'third_derivative':'2*kappa','normalized_weight':'kappa^2*q^2',
                      'scope':'deterministic local model; no random-field contact-limit claim'},
        'weak_identity_exact_tests':moments,
        'finite_counterexamples':{
            'correct_specific_mass':'21/4','unordered_half_mass':'21/8',
            'omitted_cutoff_mass':'9','correct_total_mass':'3024',
            'duplicate_area_mass':str(F(3024)*576),
            'angular_half_circle_example':'support theta in (pi,pi+1): full-S1 mass 21/4; half-circle (0,pi) mass 0',
            'weighted_selection':{'weights':['1','3','2','6'],'raw_probabilities':['1/4']*4,
                                  'adjacent_indices':[0,1],'selected_indices':[1,3],
                                  'p_weighted':str(p),'p_raw':'1/2','a':str(a),'q_adj':str(qadj),'eta':str(eta),
                                  'E_W':str(F(totalw,4)),'E_W_indicator_E':str(expected_selected_weight),
                                  'wrong_E_W_times_p_raw':'3/2'},
        },
        'required_hypotheses':[
            'All-typed ordered two-point Kac-Rice density exists at distinct endpoint positions and heights.',
            'Exact six-pin density exists with invertible T_r for r>0; required conditional weights are measurable and E_Q[W] is finite where the pin density is positive.',
            'Selection is a measurable event under the identical determinant-weighted typed Palm law.',
            '0<r_c<12 and kappa>0; source measure is absolutely continuous with respect to dx r dr dtheta db dkappa.',
            'Test function is nonnegative Borel, or absolutely integrable for the source/pushforward measure.',
            'Stationarity is required only to replace the spatial integral by 576 times a specific density.',
        ],
        'boundaries':'No atoms at r=0, kappa=0, or ell=0 are introduced. Strict/weak r_c cutoffs agree as measures; density equality is a.e.',
        'not_established':[
            'Applicability of Kac-Rice to the source field or existence of a version with every needed regularity property.',
            'Uniform nondegeneracy, endpoint moment control, a contact limit, or a positive coefficient.',
            'Persistence multiplicity, elder-rule measurability, selection convergence, tails, or the far contribution.',
            'Theorem B restoration, q0 completion, canonical promotion, external independent review, or any original prize problem.',
        ],
        'organizational_independence_credit':0,
        'scientific_status_changed':False,
        'original_prize_closed':False,
        'arithmetic':'Exact Fraction symbolic identities and exact rational integrals; no floating-point computations.',
        'replay_scope':'Finite algebra and integral checks support the written measure-theoretic proof; not a proof-assistant formalization.',
    }


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sources',type=Path,default=Path(__file__).with_name('sources'))
    parser.add_argument('--certificate',type=Path)
    parser.add_argument('--output',type=Path)
    parser.add_argument('--mutation',choices=MUTATIONS)
    args=parser.parse_args(argv)
    try:
        require(sys.version_info >= (3,11),'Python 3.11 or later required')
        sources=verify_sources(args.sources)
        report=derive(args.mutation)
        report['source_identities']=sources
        if args.certificate:
            stored=json.loads(args.certificate.read_text())
            require(canonical(stored)==canonical(report),'candidate report differs from fresh exact replay')
        if args.output:
            with args.output.open('x',encoding='utf-8') as handle:
                handle.write(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
        print('PASS: exact contact chain, cubic fold, 13 weak integral identities, weighted-selection identity; no scientific promotion')
        return 0
    except (Failure,OSError,ValueError,KeyError,TypeError,zipfile.BadZipFile,ET.ParseError) as exc:
        print('FAIL: '+str(exc),file=sys.stderr)
        return 1


if __name__=='__main__':
    raise SystemExit(main())
