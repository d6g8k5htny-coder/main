# Exact contact-to-lifetime pushforward at fixed positive separation

**Author-side conditional lemma and reproducible algebra; no scientific status change.**
Target `Q0-P12-TB-CONTACT-20260920-v1`, claim
`3457ae5b-a4b1-4eec-9a2c-926060e2e192`. Organizational independence credit is
zero. This is a normalization and measure-transport result. It does not restore
Theorem B, establish a contact limit, prove persistence multiplicity, or close q0.

## Source and identity boundary

The definitions come from the permitted active-package snapshots:

- [LS-DER-021](https://docs.google.com/document/d/16dSMQF3nbRcx93feO8vJzdnT8wDQvO-p6zViPtyUazw/edit),
  §§1, 3, 5, 6: ordered endpoint convention, corrected six pins, normalized
  determinant weight, and selection decomposition.
- [LS-DER-032](https://docs.google.com/document/d/1AUEXzPfbZsdtArlkHNhIUK4hbHqg8ATbb5M99Ex57HU/edit),
  controlling-object and external-gap paragraphs: the covariance and moment
  interfaces are separate analytic work. Their conclusions are **not imported**
  as proved hypotheses here.
- [LS-DER-039](https://docs.google.com/document/d/14_m8kQQKOcJ22Cu_L-LQdRM9Lzp9D1o9SR3lke2bpXM/edit),
  §§1 and 6: contact measure relative to `r dr dθ db dκ` and lifetime map.
- [LS-DER-040](https://docs.google.com/document/d/1UnPp4EiC8Jg5-P1hmxwz99YSt121GG6rECFW8fudKHk/edit),
  §§1–2: ordinary torus area, specific versus total intensity, near cutoff.

`SOURCE_BINDING.json` binds each copied DOCX export and the separately derived
reading, including its Drive ID. Replay also reproduces each reading from the
DOCX paragraph XML. These are exact **export** identities; a
revision was observed after export, but the export was not requested by revision
ID. A DOCX digest or derived-reading digest is not asserted to equal a native
frozen-body digest printed inside the document. No historical code, excluded
certificate, legacy body, or vault body is executed or used as evidence.

## 1. Exact hypotheses and object

Let the domain be the ordinary flat torus `T = R²/(24 Z²)`, with Lebesgue area
`A=576`. Fix `0<r_c<12`. An ordered pair has a maximum at `M` and an index-one
saddle at `S`; its orientation is from maximum to saddle. Suppose the all-typed
ordered two-point count has the following Kac–Rice first-moment representation
at distinct positions and endpoint heights `b,d`:

```
p_X(M,S;b,d,0,0,0,0) E_Q[W] dM dS db dd,
W = |det H_M det H_S| 1{H_M negative definite} 1{det H_S<0}.
```

Here the raw coordinate order is `(f_M,f_S,f_tM,f_sM,f_tS,f_sS)`;
`Q` is the conditional field law at these six pins. The density and the needed
conditional expectations must exist, be measurable, and satisfy this first-moment
identity. Assume `E_Q[W]` is finite a.e. where the pin density is positive, so the
weighted probability below is defined whenever its normalizer is positive. We
do not prove these analytic and disintegration hypotheses for the research field.
Any selection event `E` is assumed measurable under the same conditional law.
The purely measure-theoretic pushforward in §5 also allows extended nonnegative
integrals.

The frame is `t=(cos θ,sin θ)`, `s=(-sin θ,cos θ)`. Both endpoint gradient
rotations have determinant one and both Hessian rotations preserve determinants
and signatures. Their dependence on position causes no additional density
factor: in joint position/jet coordinates the Jacobian is block triangular.

For clarity, write `K_r` for the selected contact density, and `J_r` for the
all-typed contact density, relative to `dx r dr dθ db dκ`. This density may depend
on `x` before stationarity is imposed. They are densities of a declared point
process, not an assertion that its atoms are persistence bars. That identification
and its multiplicity belong to a separate argument.

## 2. Endpoint coordinates and ordered angular measure

For a pair with torus distance below `r_c`, let `u` be its unique shortest
Euclidean displacement from `M` to `S`, and set

```
x = M + u/2 modulo 24 Z²,   r=|u|,   t=u/r,
M=x-r t/2,                 S=x+r t/2.
```

Uniqueness follows because two vectors of length below 12 cannot differ by a
nonzero vector of `24 Z²`: their difference has length below 24, whereas every
nonzero lattice vector has length at least 24. For `r>0` the direction is unique
as an element of the full circle `S¹`. Thus the midpoint chart has degree one.
Torus coordinate seams can be handled by charts; they do not create multiplicity.

The map `(x,u) -> (M,S)` has determinant one. In the input order
`(x1,x2,r,θ)` and output order `(M1,M2,S1,S2)` its derivative is

```
[1 0 -c/2   r s/2]
[0 1 -s/2  -r c/2]
[1 0  c/2  -r s/2]
[0 1  s/2   r c/2],       c=cos θ, s=sin θ.
```

Its determinant is `r(c²+s²)=r`. Consequently
`dM dS = dx r dr dθ`. Integration uses ordinary angular length over the full
`S¹`, not normalized angular probability. No `1/2` occurs: each maximum–saddle
pair already has distinguished endpoint types, and reversal is not another
pair in this same typed process. Restricting to a half circle would lose pairs.

Put `d=b-κr³/6`, with `κ>0`. For fixed `r`, the signed height Jacobian from
`(b,κ)` to `(b,d)` is `-r³/6`. The combined six-dimensional transformation has
signed determinant `-r⁴/6`. In particular the mixed derivative
`∂d/∂r=-κr²/2` is present, but it lies in an off-diagonal block and changes no
factor. We obtain

```
J_r = (r³/6) p_X E_Q[W].                                      (1)
```

## 3. Corrected six-pin law and Hessian power count

With the raw order fixed above, define `Y=T_r X` in the order
`(V+,Vcorr-,Gt+,Gt-,Gs+,Gs-)`:

```
T_r =
[ 1/2      1/2       0          0        0          0      ]
[-r^-3     r^-3     -1/(2r²)    0       -1/(2r²)    0      ]
[ 0        0        1/2         0        1/2        0      ]
[ 0        0       -r^-1        0        r^-1       0      ]
[ 0        0        0           1/2      0          1/2    ]
[ 0        0        0          -r^-1     0          r^-1   ].
```

The determinant is **`-r^-5`**. The sign is tied to these row and column orders;
densities use its absolute value. An explicit inverse is

```
f_M = V+ - r³ Vcorr-/2 - r Gt+/2,
f_S = V+ + r³ Vcorr-/2 + r Gt+/2,
f_tM = Gt+ - r Gt-/2,     f_tS = Gt+ + r Gt-/2,
f_sM = Gs+ - r Gs-/2,     f_sS = Gs+ + r Gs-/2.
```

The exact target transforms to
`y=(b-κr³/12,-κ/6,0,0,0,0)`. The change-of-density rule is

```
p_Y(T_r x) = p_X(x)/|det T_r|,
p_X(x) = r^-5 p_Y(T_r x).                                    (2)
```

Both inverse identities, the determinant and target are checked as Laurent
polynomial identities, not at finitely many choices of `r`.

On the gradient pins define, at each endpoint,
`A=f_tt/r`, `B=f_ts/r`, `C=f_ss`. The Hessian is

```
H = [r A   r B]
    [r B    C ],       Delta = A C - r B²,       det H=r Delta.
```

For `r>0`, the maximum condition is equivalently `A_M<0, Delta_M>0`, and the
saddle condition is `Delta_S<0`. Thus, exactly,

```
w := W/r²
   = |Delta_M Delta_S|
     1{A_M<0, Delta_M>0} 1{Delta_S<0},
z := E_Q[w],
J_r = (1/6) p_Y z.                                           (3)
```

The cancellation is `r³ · r^-5 · r² = 1`. It is valid for every positive radius
in the chart under the stated Kac–Rice hypotheses. It does not itself establish
that `z` or `p_Y` has a limit, is uniformly bounded, or is bounded away from zero.

## 4. Selection must use the weighted law

Where `z>0`, define the typed Palm probability by

```
P^W(E) = E_Q[w 1_E]/z.
```

Then `p_r=P^W(E)` and

```
K_r = (1/6) p_Y E_Q[w 1_E] = J_r p_r.                         (4)
```

When `z=0`, nonnegativity forces `E_Q[w 1_E]=0`; set `p_r=0` there. This gives a
consistent density without division by a possibly zero normalizer. A raw
Gaussian conditional probability `Q(E)` is generally not a valid substitute.
For a measurable adjacency event `A`, total probability under **this same law**
gives `p_r=a_r q_r^adj + eta_r`, with `eta_r=P^W(E ∩ A^c)`.
When `P^W(A)=0`, define `q_r^adj=0`; the identity remains valid.

An exact counterexample uses four equally likely raw states with weights
`(1,3,2,6)`, adjacency indices `{0,1}`, and selected indices `{1,3}`. Then

```
E_Q[w]=3,        E_Q[w 1_E]=9/4,
p_r=3/4,        Q(E)=1/2,
a_r=1/3,        q_r^adj=3/4,        eta_r=1/2.
```

Correct multiplication gives `3·(3/4)=9/4`. Using raw selection gives `3/2`;
dropping the nonadjacent-selected mass gives `p_r=1/4` instead of `3/4`.
This is a counterexample to an incorrect measure identity, not a claim that
these four states occur in the source Gaussian field.

## 5. Weak lifetime pushforward, with the cutoff retained

Let `K_r(x,θ,b,κ)` be any nonnegative measurable contact density on
`T × (0,r_c) × S¹ × B × K`, where `B⊂R` and `K⊂(0,∞)` are measurable. Let `μ`
have density `K_r dx r dr dθ db dκ`. Define `ℓ=κr³/6` and retain the other
marks. For fixed `κ>0` this is a strictly increasing C¹ diffeomorphism from
`(0,r_c)` to `(0,κr_c³/6)`. Its inverse and Jacobian are

```
r_ℓ(κ) = (6ℓ/κ)^(1/3),
dℓ/dr = κr²/2,
r dr = [2/(κ r_ℓ)] dℓ
     = (6^(2/3)/3) κ^(-2/3) ℓ^(-1/3) dℓ.                    (5)
```

Therefore, for **every nonnegative Borel test function** `φ(x,θ,b,κ,ℓ)`,

```
∫ φ(x,θ,b,κ,κr³/6) K_r dx r dr dθ db dκ
 = (6^(2/3)/3)
   ∫ φ(x,θ,b,κ,ℓ) 1{0<ℓ<κr_c³/6}
     K_{r_ℓ(κ)} κ^(-2/3) ℓ^(-1/3) dx dℓ dθ db dκ.           (6)
```

Proof: apply the one-dimensional substitution (5) to each fixed
`(x,θ,b,κ)` slice, then use Tonelli. One can first do this for bounded Borel
functions on compact subintervals and pass monotonically to the open domain;
there is no assumption of integrability near zero hidden in the proof. The
identity for signed test functions follows whenever their absolute value is
integrable. Both sides may equal infinity in the nonnegative case.

Thus the `ℓ` marginal has density, a.e.,

```
ν_near^tot(ℓ) = (6^(2/3)/3) ℓ^(-1/3)
  ∫_T ∫_S¹ ∫_B ∫_K
     1{κ>6ℓ/r_c³} K_{r_ℓ(κ)}(x,θ,b,κ) κ^(-2/3)
     dκ db dθ dx.                                             (7)
```

The cutoff is part of the exact formula. It may not be deleted because `ℓ` is
small without a separate limiting argument and an integrable dominating
function. No such limit or domination is asserted here. In particular (7)
is not itself an asymptotic law.

Under stationarity `K_r` is independent of `x`, and integration over ordinary
torus area multiplies the specific density by **576 exactly once**. If `dx`
is instead normalized Haar probability, it computes a specific density; that
convention must be identified before interpreting a total count.

### Boundary treatment

The radius zero and `κ=0` are excluded from the coordinate domain; the lifetime
map sends every admitted point to `ℓ>0`. Hence its pushforward has no atom at
`ℓ=0`. This does not permit adding an unspecified atomic contact measure at
`r=0` or `κ=0`. Absolute continuity of the declared source measure makes the
surface `r=r_c` null, so strict or weak cutoff choices give the same measure.
At a fixed positive lifetime its corresponding `κ` boundary is a singleton;
changing its indicator does not change the `dκ` integral. Density statements
remain a.e. statements about measurable versions. Angular seams and torus
coordinate seams are likewise null; they are not extra multiplicity factors.

## 6. Exact local fold model and continuum integral controls

A deterministic potential in the pair frame is

```
F(u,v) = b-κr³/12 + κu³/3 - κr²u/4 + qv²/2,
r>0, κ>0, q<0.
```

Its points `(-r/2,0)` and `(r/2,0)` have zero gradient, heights `b` and
`b-κr³/6`, and Hessians `diag(-κr,q)` and `diag(κr,q)`. The first is a maximum
and the second a saddle. Also `F_uuu=2κ` and `W/r²=κ²q²`. This exact family
checks the cubic sign, endpoint order and all powers without taking a random
field limit. It is a local model, not a periodic realization or a proof that a
source Palm family converges to it.

For a nontrivial continuum integration check, choose `K_r=1`, `0<r<1/2`,
`6<κ<48`, a unit-length birth interval and a one-radian directed angular arc.
Per unit area the total source mass is `42∫_0^(1/2) r dr=21/4`. The exact
lifetime density is

```
6 ℓ^(-1/3),                    0<ℓ<1/8,
12 ℓ^(-1/3)-12,                1/8<ℓ<1,
0,                            otherwise.
```

Integrating this density gives `21/4`. The checker independently compares both
sides for each of the 13 test functions `ℓ^n`, `n=0,…,12`, using exact rational
primitives at perfect-cube endpoints. These finite checks supplement, rather
than replace, the proof for arbitrary Borel tests in (6).

Meaningful failures are concrete:

- Adding an unordered `1/2` gives mass `21/8`.
- Omitting the moving `κ` cutoff, while retaining `0<ℓ<1`, gives mass `9`.
- A support arc `(π,π+1)` has mass `21/4` over `S¹` and mass zero over `(0,π)`.
- The correct full-torus mass is `3024`; two area factors give `1,741,824`.
- The weighted-selection counterexample changes `9/4` to `3/2`.

## Replay and limits

Run `python3.11 -B contact_check.py --certificate result.json` and
`python3.11 -B test_contact.py` from this directory. The verifier uses exact
`Fraction` arithmetic, sparse Laurent identities, and the positive algebraic
constant `root6³=6`. It imports no repository mathematics and executes no source
artifact. `RUN.json` gives executable paths and success criteria.

The 35-test suite includes positive normal/optimized replay, 12 live-calculation
mutations in both modes, four report mutations in both modes (including
Boolean-versus-integer confusion), and actual source-byte tampering in both
modes. Explicit checks survive `python -O`.

This work establishes the stated conditional measure-transport lemma and its
normalization chain. It does not establish Kac–Rice applicability, a uniform
six-pin eigenfloor, a contact limit, persistence measurability or multiplicity,
selection convergence, global mark tails, the far contribution, a lifetime
coefficient, Theorem B restoration, any q0 closure, or an original prize result.
No canonical status is changed and no organizational independence is claimed.
