# Private integration handoff: twelve mathematical candidates

All twelve candidates recomputed successfully. Every fresh report is byte-equal
to its saved candidate; 305 bundle inputs and 24 repository dependencies stayed
unchanged. The original project tests passed 320 cases per Python mode. Six
runner rejection controls and two live prohibited-source rejections also passed.
The source reader's positive permitted-source replay matched the original bytes.
These are execution facts, not proof-assistant or independent-review claims.

Integrate only the explicit MANIFEST.json allowlist or the verified aggregate
ZIP. **Do not copy the entire scratch directory**: exploratory results, old
helpers, standalone intermediate ZIPs and the excluded recovered-history script
are intentionally outside the delivery. SOURCE_BOUNDARY.md records the intake
incident; the corrected reader is read_source_v2.py.

Repository validation HEAD: 07a0a4803f998aff4265abd42dfeaea5252bd3bb.
Requested branch: chatgpt/drive-github-hardening-20260919.
Existing private draft PR: https://github.com/d6g8k5htny-coder/main/pull/3.
The repository task remains the sole repository writer and owns RN N6 spatial
transport. No parent repository edits occurred in this campaign.

1. Preserve all source/body/export distinctions, exact conditional scope and
   counterexamples. Add a dependency-aware execution route using the provided
   replay plan/checkers and retain failures. Source code carriers remain inert.
2. Port only after checking coordinate/law/normalization compatibility. The H3
   fixed-axis and LPW coordinate systems differ. The two-jet result does not
   define or certify the missing full 24-jet interface.
3. The improved LPW constant belongs to the original typed elder-pairing
   interpretation. Shared six pins and determinant weighting alone do not
   identify it with selected-branch adjacency. See LPW_INTERFACE_AUDIT.md.
4. Counterexamples invalidate stated inference rules, not the actual Gaussian
   field or all historical final bounds. Synthetic numerical illustrations in
   WP, Lambda and tube/tail projects are not actual-field certificates.
5. Keep the manuscript-level missing hypotheses and source canonical statuses
   unchanged. Do not create a K3 lower assembly successor or restore Theorem B
   from this delivery. Nonauthor same-provider review and organizational
   independence are separate; the latter is zero here.
6. Publish any successor receipt to owner-only My Drive with permission readback
   and the private GitHub branch. The earlier DG-EXEC destination inherited
   anyone-with-link access and must not receive this private delivery.

Twelve separate project agents were used in waves of three. An additional LPW
reviewer hit the account usage limit before issuing a verdict; its source
snapshots and the parent's completed written audit are included, with no claimed
review pass. The tube agent hit the same limit after saving its full tested
manifest; the parent verified and replayed those complete artifacts.

Parent authoring claims are disposed in the native R17 Work Events register at
handoff. This package is not a duplicate governance or claim register. The next
integration task must use its own exact-target writer claim as needed.
