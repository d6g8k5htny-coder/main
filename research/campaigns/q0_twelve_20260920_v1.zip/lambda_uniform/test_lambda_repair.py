#!/usr/bin/env python3
"""Nontrivial exact examples and live fail-closed CLI controls, normal and -O."""
from fractions import Fraction as F
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('repair', HERE/'lambda_repair.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
API=r.load_interval(r.REPO)

class Algebra(unittest.TestCase):
    def test_all_five_sample_jets_unchanged(self):
        w=r.perturbation_witness()
        self.assertEqual(w['fine_Q'],'1');self.assertEqual(w['coarse_Q'],'1')
        self.assertEqual(w['off_grid_Dxxx'],'9');self.assertEqual(w['rung_ratio'],'1')
    def test_counterexample_nonnegative(self):
        w=r.perturbation_witness()
        self.assertGreater(F(w['amplitude']),0)
        self.assertTrue(w['nonnegative_on_domain'])
    def test_general_polynomial_product_differentiation(self):
        p=r.pmul([1,2,3],[4,5])
        self.assertEqual(p,[4,13,22,15])
        self.assertEqual(r.peval(r.pdiff(p,3),F(19,7)),90)
    def test_linear_exponential_chain(self):
        v=r.exp_profile(0,[1,0,0],API)
        self.assertEqual(v,(1,F(1,2),F(1,4),F(1,8)))
    def test_inverse_square_root_chain(self):
        v=r.invsqrt_profile(1,[1,0,0],API)
        self.assertEqual(v,(1,F(1,2),F(3,4),F(15,8)))
    def test_quadratic_variance_chain(self):
        v=r.invsqrt_profile(1,[0,2,0],API)
        self.assertEqual(v,(1,0,1,0))
    def test_third_chain_mixed_term(self):
        v=r.exp_profile(0,[2,4,6],API)
        self.assertEqual(v[3],10)
    def test_full_leibniz_cross_terms(self):
        # (1+x)^6 at zero has third derivative 6*5*4.
        p=r.product_profile(*([[1,1,0,0]]*6))
        self.assertEqual(p,(1,6,30,120))
    def test_square_factor_third_derivative(self):
        # (1+x+x^2)^2 has third derivative 12 at zero.
        self.assertEqual(r.product_profile([1,1,2,0],[1,1,2,0])[3],12)
    def test_analytic_synthetic_bound(self):
        p=r.analytic_b3(0,[F(3,2),2,0],1,[0,0,0],[F(1,2),0,0,0],[[1,0,0,0]]*3,1,API)
        self.assertLess(p[3],F(57,256));self.assertGreater(p[3],F(1,5))
    def test_positive_synthetic_floor(self):
        p=r.positive_floor(F(1,2),1,1,F(1,2),[1,1,1],-1,1,API)
        self.assertGreater(p,F(1,20));self.assertLess(p,F(1,16))
    def test_zero_typed_margin_rejected(self):
        with self.assertRaises(ValueError):r.positive_floor(0,1,1,1,[1,0,1],-1,1,API)
    def test_nonnegative_trace_rejected(self):
        with self.assertRaises(ValueError):r.positive_floor(0,1,1,1,[1,1,1],0,1,API)
    def test_zero_window_rejected(self):
        with self.assertRaises(ValueError):r.positive_floor(0,1,1,0,[1,1,1],-1,1,API)
    def test_nonpositive_density_variance_floor_rejected(self):
        with self.assertRaises(ValueError):r.positive_floor(0,0,1,1,[1,1,1],-1,1,API)
    def test_zero_variance_rejected(self):
        with self.assertRaises(ValueError):r.invsqrt_profile(0,[1,1,1],API)
    def test_bad_normalizer_rejected(self):
        with self.assertRaises(ValueError):r.analytic_b3(0,[1,1,1],1,[1,1,1],[1]*4,[[1]*4]*3,0,API)
    def test_negative_derivative_rejected(self):
        with self.assertRaises(ValueError):r.exp_profile(0,[-1,1,1],API)
    def test_float_bound_rejected(self):
        with self.assertRaises(ValueError):r.grid_b3_upper(1.0,1,1)
    def test_C4_grid_budget(self):
        self.assertEqual(r.grid_b3_upper(1,4,1),F(15,2))
        self.assertLessEqual(r.grid_b3_upper(1,F(13,3),1),8)
    def test_invalid_grid_spacing_rejected(self):
        with self.assertRaises(ValueError):r.grid_b3_upper(1,1,0)
    def test_negative_grid_fourth_bound_rejected(self):
        with self.assertRaises(ValueError):r.grid_b3_upper(1,-1,1)
    def test_fourth_derivative_not_optional(self):
        self.assertGreater(r.grid_b3_upper(1,10,1),8)
    def test_fallback_quartic_integral(self):
        # Integral of x^4 over square is 2 * [x^5/5]_-1^1 = 4/5.
        integral=2*(F(1,5)-F(-1,5))
        self.assertEqual(integral,F(4,5))
        self.assertGreater(integral,0)
        self.assertGreaterEqual(r.smooth_fallback(0,0,24,F(3,2),2),integral)
    def test_fallback_remainder_is_essential(self):
        self.assertEqual(r.smooth_fallback(0,0,0,F(3,2),2),0)
        self.assertGreater(r.smooth_fallback(0,0,24,F(3,2),2),0)

class CLIGuards(unittest.TestCase):
    def call(self,script,args):
        return subprocess.run([sys.executable,'-B']+(['-O'] if sys.flags.optimize else [])+[str(script)]+args,
                              capture_output=True,text=True,cwd=HERE)
    def test_fresh_report_equals_frozen_report(self):
        with tempfile.TemporaryDirectory(dir=HERE) as d:
            out=Path(d)/'report.json'
            p=self.call(HERE/'lambda_repair.py',['--verify',str(HERE/'result.json'),'--output',str(out)])
            self.assertEqual(p.returncode,0,p.stderr)
            self.assertEqual(out.read_bytes(),(HERE/'result.json').read_bytes())
    def mutate_report(self,key,value):
        with tempfile.TemporaryDirectory(dir=HERE) as d:
            pth=Path(d)/'bad.json';data=json.loads((HERE/'result.json').read_text());data[key]=value
            pth.write_text(r.dump(data))
            p=self.call(HERE/'lambda_repair.py',['--verify',str(pth)])
            self.assertNotEqual(p.returncode,0);self.assertIn('certificate mismatch',p.stderr)
    def test_tampered_claim_rejected(self):self.mutate_report('canonical_status_changed',True)
    def test_tampered_obstruction_rejected(self):self.mutate_report('finite_jet_obstruction',{})
    def test_tampered_floor_rejected(self):self.mutate_report('synthetic_example',{'pointwise_lower_headline':'1'})
    def test_tampered_remainder_rejected(self):self.mutate_report('replacement_theorems',{})
    def test_existing_output_preserved(self):
        with tempfile.TemporaryDirectory(dir=HERE) as d:
            out=Path(d)/'existing';out.write_text('preserve')
            p=self.call(HERE/'lambda_repair.py',['--output',str(out)])
            self.assertNotEqual(p.returncode,0);self.assertEqual(out.read_text(),'preserve')
    def test_changed_source_rejected(self):
        with tempfile.TemporaryDirectory(dir=HERE) as d:
            d=Path(d);shutil.copy(HERE/'lambda_repair.py',d);shutil.copy(HERE/'DEPENDENCIES.json',d)
            shutil.copytree(HERE/'sources',d/'sources')
            with (d/'sources/KIMI-DER-027b/source.raw').open('ab') as f:f.write(b'changed')
            p=self.call(d/'lambda_repair.py',[])
            self.assertNotEqual(p.returncode,0);self.assertIn('source dependency mismatch',p.stderr)
    def test_actual_factor_eight_mutation_fails(self):
        with tempfile.TemporaryDirectory(dir=HERE) as d:
            d=Path(d);src=(HERE/'lambda_repair.py').read_text()
            src=src.replace('amplitude = F(8)/derivative','amplitude = F(7)/derivative')
            (d/'lambda_repair.py').write_text(src);shutil.copy(HERE/'DEPENDENCIES.json',d)
            shutil.copytree(HERE/'sources',d/'sources')
            p=self.call(d/'lambda_repair.py',[])
            self.assertNotEqual(p.returncode,0);self.assertIn('counterexample arithmetic failed',p.stderr)

if __name__=='__main__':unittest.main()
