# Lambda: exact obstruction and analytic replacement candidates

This document proves two defects in a proposed inference and supplies three valid replacement lemmas. It **does not compute an actual Lambda lower constant**, discharge H-B3, repair the lower theorem assembly, or change a canonical status. The synthetic example in the checker is explicitly a different function. All organizational independence credit is zero.

## 1. Source and scope

The active definition source is KIMI-DER-027b, Drive `1LnBIGjoX01WHuPv3_OtuXHfhnU1s1e8p`, 6,905 bytes, SHA-256 `8089e581787ab6f978f883923ad43e1dcbbda83d68f6fe55e18b0f8969102f86`. Its unfinished sections and nonclosure are retained. GP-LB-STAT-004A, Drive `1cdSyfIoV8WiHug7aJDv4Ng7Vq2GnRP_j`, 2,114 bytes, SHA-256 `c6845e83b441cb1ef25ef57df54f0cf0d0ef9b03e2a963c57c6fc30fa70fc658`, states that recovered source does not establish an analytic H-B3 bound or an unconditional Lambda constant. `docs/OPEN_PROBLEMS.md` OQ-016-U2 supplies the current task scope; OQ-016-U1 prohibits an assembly successor.

On its typed support the definition is

`lambda = exp(-q/2) P cM (-cS) (-cY) / (2 pi sqrt(v) DEN)`,

where `v=c6v>0`, `cM>0`, `cS<0`, `cY<0`, and `trc<0`. It is zero outside the support. The source proposes H-B3 as a third-derivative supremum bounded by eight times finite central differences of sampled Hessians, accompanied by a two-grid stability check. Its section 3 also prints the fallback `(G + sigma rho) rho h^2` from a center gradient and Hessian. Those two mathematical proposals are examined below. No source high-precision numerical value is inherited as a certified enclosure.

A short inert excerpt of a separately prepared `lambda-grid-v2` reading copy was exposed before its identity metadata was inspected. Its metadata identifies `QUARANTINE_OR_HISTORY` and a quarantine path. Reading then stopped. No code was executed; none of its bytes, formulas, or implementation behavior is used as proof evidence or included in this delivery. The findings here concern the independently verified active DER-027b prose, and make no verdict about a recovered successor implementation.

## 2. Finite sampled jets cannot certify H-B3

For any finite set S of x-coordinates, put `P(x)=product_{s in S}(x-s)^4`. At every sample x=s, P and its first three derivatives vanish. In particular adding A P to any smooth function changes none of its sampled values, gradients, or Hessians. Every finite-difference statistic computed from those same Hessians is unchanged. Unless P is constant its third derivative is a nonzero polynomial somewhere off the sample set; scaling A makes that third derivative arbitrarily large. Adding a positive multiple preserves nonnegativity when the initial function is nonnegative, since P>=0.

This applies to any finite union of coarse, fine, and auxiliary stations, including a fixed multigrid test. It does not assert that the actual Lambda is an arbitrary smooth function, or that its actual H-B3 inequality is false. It proves that these finite jets and stability observations alone cannot imply that inequality. Extra analytic information about the specified function is indispensable.

The exact executable witness uses S={0,1,2,3,4},

`f(x,y)=10+x^3/6+A product_{k=0}^4(x-k)^4` on `[0,4]x[0,1]`.

At the fine stations, central Hessian differences with h=1 have norm exactly 1. The coarse central difference at x=2 with h=2 also has norm 1. Their stability ratio is exactly 1. Select x*=1/2 or 7/2 so that P'''(x*)>0, and set A=8/P'''(x*)>0. Then f'''(x*)=9>8. In two variables the only nonzero third tensor component is xxx, so the full trilinear operator norm is its absolute value. The function is nonnegative, all sampled jets up through order two are untouched, and the factor-eight inference fails. The report contains exact rational A and x*; no numerical probe establishes the inequality.

## 3. The old fallback requires a missing remainder hypothesis

On the square [-1,1]^2 take f(x,y)=x^4. Its gradient and Hessian vanish at the center. Thus the section-3 expression `(G+sigma rho) rho h^2` is zero. Nevertheless

`integral f - h^2 f(0) = 2 integral_{-1}^1 x^4 dx = 4/5`.

Here f is globally smooth and the third derivative has supremum 24 on the square. Smoothness and knowledge of a B3 bound therefore do not make the printed expression valid if its B3 remainder is omitted. This is an error in that standalone proposed bound, not a numerical refutation of an actual Lambda integral.

For a convex cell C of side h with center c and radius rho=h/sqrt(2), assume f is C3 and `||D3 f||op<=B3` throughout C. Taylor's integral formula gives

`||grad f(x)|| <= G + sigma rho + B3 rho^2/2`,

where G=||grad f(c)|| and sigma=||D2f(c)||op. Consequently the valid Lipschitz fallback is

`|integral_C f - h^2 f(c)| <= (G+sigma rho+B3 rho^2/2) rho h^2`.

A sharper symmetric midpoint bound is

`|integral_C f - h^2 f(c)| <= (sigma+B3 rho) h^4/12`.

Indeed `||D2 f||<=sigma+B3 rho`; the linear term integrates to zero, and `integral_C ||x-c||^2 = h^4/6`. This proof applies to a smooth cell. Across clipping or typing interfaces, a center jet alone is insufficient: one must establish global Lipschitz continuity or a valid branchwise Hessian/interface argument. This delivery does not certify those hypotheses for Lambda.

## 4. A constructive analytic C3 replacement

All norms below are Euclidean multilinear operator norms. On one convex, pure-typed smooth box suppose each ingredient is C3, `q>=q_-`, `v>=v_->0`, and `DEN>=d_->0` is a constant. Let Qj bound ||Dj q|| and Vj bound ||Dj v|| for j=1,2,3, and let the four entries of each remaining profile bound the absolute value and the first three derivative norms.

For E=exp(-q_-/2), the profile of exp(-q/2) is bounded by

- E;
- E Q1/2;
- E (Q2/2+Q1^2/4);
- E (Q3/2+3 Q1 Q2/4+Q1^3/8).

Writing a=v_-^(-1/2), the profile of v^(-1/2) is bounded by

- a;
- a V1/(2v_-);
- a (V2/(2v_-)+3V1^2/(4v_-^2));
- a (V3/(2v_-)+9V1 V2/(4v_-^2)+15V1^3/(8v_-^3)).

These are ordinary chain rules with absolute-value triangle inequalities; the mixed third-derivative term occurs three times. For two profiles A,B the product profile is

`C_n = sum_{k=0}^n binom(n,k) A_k B_(n-k)`, n=0,1,2,3.

The multilinear Leibniz rule proves this bound by summing over subsets of the n arguments. Iterating over `exp(-q/2), v^(-1/2), P, cM, -cS, -cY`, then dividing by `2 pi d_-`, gives a valid analytic B3. It requires no finite-difference safety factor. The checker computes this rule using exact Fraction coefficients and certified repository exp, sqrt and pi endpoints.

This is a replacement **method and theorem**, not a certified range enclosure of the actual Laurent-series ingredients. Its important missing inputs are the actual uniform C3 profiles, the variance floor, normalizer lower bound, and a proof that the box stays in one smooth typed branch. A clipping window must be handled separately on any interface.

## 5. A fourth-derivative-assisted grid theorem

There is also a valid grid route when a genuine analytic fourth-derivative bound is available. Let f be C4 on a convex region containing all relevant points, their connecting segments, and the full central-difference stencils. Assume `||D4f||op<=B4` there. Let stations form a Euclidean h/sqrt(2)-net of the target square-grid region. For every selected station p, require both p±h e_k (k=1,2) to lie in the C4 domain. Let Q bound the **matrix operator norm**, or more conservatively the Frobenius norm, of each matrix central quotient

`[H(p+h e_k)-H(p-h e_k)]/(2h)`.

This includes every selected station and coordinate direction; missing edge stencils are not filled with zero.

The central quotient is the average of partial_k H along the segment. D4 control gives

`||partial_k H(p)-central_quotient||op <= B4/(2h) integral_-h^h |t|dt = B4 h/2`.

For a unit vector w, `partial_w H = w1 partial_1 H + w2 partial_2 H`, so

`||D3f(p)||op <= sqrt(2)(Q+B4 h/2)`.

Moving from p to an arbitrary target x costs at most `B4||x-p||<=B4 h/sqrt(2)`. Thus

`sup ||D3f||op <= sqrt(2)(Q+B4 h)`.

The usual h/sqrt(2) covering radius, **not h/2**, is used here. Since sqrt(2)<3/2, a convenient rational certificate is `B3=(3/2)(Q+B4 h)`. A sufficient exact condition for this to be no larger than 8Q is `B4 h <= (13/3)Q`. This condition exposes precisely the missing independent derivative information; when Q=0 it requires B4=0. The result does not infer B4 from samples.

## 6. Local positivity without global H-B3

Let B be a positive-area box. Suppose throughout B

`q<=Q, 0<v_-<=v<=V, P>=P_*>0, cM>=mM>0, cS<=-mS<0, cY<=-mY<0, trc<=-tau<0`,

and `0<DEN<=D`. Then the source formula directly gives

`lambda >= exp(-Q/2) P_* mM mS mY / (2 pi sqrt(V) D) > 0`.

Multiplication by area(B) gives an explicit positive integral lower bound. This avoids global H-B3 altogether for the limited purpose of proving positivity. It still needs actual interval ingredient and typing certificates on B and does not establish a large target floor or finite-r convergence. The code explicitly requires the variance interval, all three signed margins interpreted as above, and a negative trace upper bound. It cannot infer that supplied bounds describe the source function.

For an independent exact exercise of sections 4 and 6, take the **synthetic** function `f=exp(-(x^2+y^2)/2)/(4pi)` on [-1/2,1/2]^2. Set v=1, P=1/2, the three positive factors to 1 and DEN=1. Then q in [0,1/2], ||Dq||<=sqrt(2)<3/2, ||D2q||=2, D3q=0. Section 4 gives B3<=171/(256pi)<57/256, and section 6 gives f>=exp(-1/4)/(4pi)>1/20, hence the same integral bound on this unit-area box. The certified interval checker verifies both strict rational headlines. This exercise is deliberately not an actual Lambda evaluation.

## 7. Verification and remaining work

The checker derives the exact polynomial witness, strict inequality, replacement coefficients and synthetic interval exercise. Unit tests use independent analytic examples of chain/product rules and live CLI mutations, including changes to an active source, a weakened counterexample amplitude, the report's positivity headline, derivative formulas, and forbidden status promotion. Normal and optimized Python must both pass and produce byte-identical report bytes. The source bodies are hash bound but never executed.

The actual Lambda uniform ingredient profiles and typed box, interface regularity, finite-r limit transfer, tail estimates, weighted-Palm losses, and all other lower-campaign premises remain separate obligations. These artifacts give a replayable route and rigorous obstructions; they do not label H-B3 or the lower theorem closed. An operator must separately adjudicate any future canonical disposition.
