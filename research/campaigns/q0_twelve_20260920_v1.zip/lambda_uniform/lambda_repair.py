#!/usr/bin/env python3
"""Exact analytic repair candidates; no actual Lambda constant or status promotion."""
from __future__ import annotations
import argparse
from fractions import Fraction as F
import hashlib
import json
from math import comb, factorial
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
REPO = Path('/Users/dylanroy/Documents/Codex/research-main')


def require(ok, text):
    if not ok:
        raise ValueError(text)


def identity(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def exact(x):
    require(isinstance(x, (int, str, F)) and not isinstance(x, bool), 'exact rational required')
    return F(x)


def profile(values):
    require(len(values) == 4, 'four derivative bounds required')
    out = tuple(exact(x) for x in values)
    require(all(x >= 0 for x in out), 'negative derivative bound')
    return out


def product_profile(*factors):
    """Tensor-operator derivative bounds from the full Leibniz rule."""
    out = (F(1), F(0), F(0), F(0))
    for factor in factors:
        b = profile(factor)
        out = tuple(sum(F(comb(n, k)) * out[k] * b[n-k] for k in range(n+1))
                    for n in range(4))
    return out


def exp_profile(q_lower, q_derivatives, interval_api):
    """For exp(-q/2): actual lower q and operator norms of D^k q."""
    I, exp, sqrt, pi = interval_api
    q1, q2, q3 = map(exact, q_derivatives)
    require(min(q1, q2, q3) >= 0, 'negative q derivative bound')
    e = exp(I.exact(-exact(q_lower)/2), 35).hi
    return (e, e*q1/2, e*(q2/2+q1*q1/4),
            e*(q3/2+3*q1*q2/4+q1**3/8))


def invsqrt_profile(v_lower, v_derivatives, interval_api):
    I, exp, sqrt, pi = interval_api
    v = exact(v_lower)
    require(v > 0, 'variance floor must be positive')
    v1, v2, v3 = map(exact, v_derivatives)
    require(min(v1, v2, v3) >= 0, 'negative variance derivative bound')
    a = (I.exact(1)/sqrt(I.exact(v), 35)).hi
    return (a, a*v1/(2*v), a*(v2/(2*v)+3*v1*v1/(4*v*v)),
            a*(v3/(2*v)+9*v1*v2/(4*v*v)+15*v1**3/(8*v**3)))


def analytic_b3(q_lower, q_derivatives, v_lower, v_derivatives,
                p_profile, typed_profiles, den_lower, interval_api):
    """All input bounds must hold over one pure-typed smooth box."""
    I, exp, sqrt, pi = interval_api
    require(len(typed_profiles) == 3, 'three typed determinant factors required')
    d = exact(den_lower)
    require(d > 0, 'normalizer lower bound must be positive')
    factors = [exp_profile(q_lower, q_derivatives, interval_api),
               invsqrt_profile(v_lower, v_derivatives, interval_api),
               profile(p_profile)] + [profile(z) for z in typed_profiles]
    constant = (I.exact(1)/(2*pi(35)*d)).hi
    return tuple(constant*x for x in product_profile(*factors))


def positive_floor(q_upper, v_lower, v_upper, p_lower, margins, trace_upper, den_upper, interval_api):
    I, exp, sqrt, pi = interval_api
    q, v, p, d = map(exact, (q_upper, v_upper, p_lower, den_upper))
    require(0 < exact(v_lower) <= v, 'positive variance interval required')
    ms = [exact(z) for z in margins]
    require(len(ms) == 3 and min(ms) > 0, 'strict typed margins required')
    require(exact(trace_upper) < 0, 'negative trace margin required')
    require(v > 0 and d > 0 and 0 < p <= 1, 'positive variance/normalizer/window bounds required')
    value = exp(I.exact(-q/2), 35)*p
    for x in ms:
        value = value*x
    return (value/(2*pi(35)*sqrt(I.exact(v), 35)*d)).lo


def grid_b3_upper(q, b4, h):
    """Rational relaxation of sqrt(2)*(Q+B4*h), under PROOF.md's halo/net hypotheses."""
    q, b4, h = map(exact, (q, b4, h))
    require(q >= 0 and b4 >= 0 and h > 0, 'invalid grid bound inputs')
    return F(3,2)*(q+b4*h)


def smooth_fallback(g, sigma, b3, rho, side):
    g, sigma, b3, rho, side = map(exact, (g, sigma, b3, rho, side))
    require(min(g,sigma,b3,rho) >= 0 and side > 0, 'invalid fallback bounds')
    return (g+sigma*rho+b3*rho*rho/2)*rho*side*side


def pmul(a, b):
    c = [F(0)]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):
            c[i+j] += x*y
    return c


def pdiff(p, n=1):
    for _ in range(n):
        p = [F(i)*p[i] for i in range(1,len(p))]
    return p or [F(0)]


def peval(p, x):
    out = F(0)
    for a in reversed(p):
        out = out*x+a
    return out


def perturbation_witness():
    roots = [F(i) for i in range(5)]
    p = [F(1)]
    for r in roots:
        for _ in range(4):
            p = pmul(p, [-r,F(1)])
    p3 = pdiff(p,3)
    x = F(1,2)
    if peval(p3,x) < 0:
        x = 4-x
    derivative = peval(p3,x)
    require(derivative > 0, 'nonzero positive off-grid third derivative missing')
    amplitude = F(8)/derivative
    f = [amplitude*a for a in p]
    f[0] += 10
    f[3] += F(1,6)
    for r in roots:
        for n in range(3):
            require(peval(pdiff(p,n),r) == 0, 'perturbation visible to sample jet')
    f2 = pdiff(f,2)
    quotients = []
    for h, centers in [(F(1),[F(1),F(2),F(3)]),(F(2),[F(2)])]:
        quotients.append(max(abs(peval(f2,c+h)-peval(f2,c-h))/(2*h) for c in centers))
    third = peval(pdiff(f,3),x)
    require(quotients == [F(1),F(1)] and third == 9, 'grid counterexample arithmetic failed')
    require(third > 8*max(quotients), 'factor-eight obstruction absent')
    return {'sample_x':[str(x) for x in roots], 'polynomial':'10 + x^3/6 + A*product_{k=0}^4(x-k)^4',
            'amplitude':str(amplitude), 'off_grid_x':str(x),
            'off_grid_Dxxx':str(third), 'fine_Q':str(quotients[0]),
            'coarse_Q':str(quotients[1]), 'rung_ratio':'1', 'claimed_SF_Q':'8',
            'strict_violation':True, 'nonnegative_on_domain':True,
            'domain':'[0,4] x [0,1]', 'is_actual_lambda':False}


def load_interval(repo):
    sys.path.insert(0, str(repo))
    from research.interval import Interval, exp, sqrt, pi
    return Interval, exp, sqrt, pi


def validate_inputs(repo):
    deps = json.loads((HERE/'DEPENDENCIES.json').read_text())
    for rel, expected in deps['repository'].items():
        require(identity(repo/rel) == expected, 'repository dependency mismatch: '+rel)
    for rel, expected in deps['sources'].items():
        require(identity(HERE/rel) == expected, 'source dependency mismatch: '+rel)
    for folder in ['KIMI-DER-027b', 'GP-LB-STAT-004A']:
        record = json.loads((HERE/'sources'/folder/'IDENTITY.json').read_text())
        require(record['inventory']['context'] == 'RESEARCH_SOURCE_CHECK_STATUS', 'ineligible source context')
        require(record['coverage']['context'] == 'RESEARCH_SOURCE_CHECK_STATUS', 'ineligible coverage context')
        path = record['inventory']['path'].lower()
        require(not any(s in path for s in ['quarantine','legacy','99_do_not_open']), 'ineligible source path')
    return deps


def build(repo):
    deps = validate_inputs(repo)
    api = load_interval(repo)
    witness = perturbation_witness()
    I, exp, sqrt, pi = api
    synthetic = analytic_b3(0, [F(3,2),2,0], 1, [0,0,0],
                           [F(1,2),0,0,0], [[1,0,0,0]]*3,1,api)
    synthetic_lower = positive_floor(F(1,2),1,1,F(1,2),[1,1,1],-1,1,api)
    require(synthetic[3] < F(57,256), 'synthetic derivative headline fails')
    require(synthetic_lower > F(1,20), 'synthetic positive floor headline fails')
    require(F(4,5) > 0, 'fallback counterexample failed')
    repaired = smooth_fallback(0,0,24,F(3,2),2)
    require(repaired >= F(4,5), 'repaired fallback misses polynomial integral')
    return {'schema':'q0-lambda-analytic-repair-candidate-v1',
            'project':'lambda_uniform', 'arithmetic':'exact Fraction + repository certified intervals',
            'source_sha256':{p:v['sha256'] for p,v in deps['sources'].items() if p.endswith('source.raw')},
            'finite_jet_obstruction':witness,
            'smooth_fallback_counterexample':{
                'function':'f(x,y)=x^4', 'cell':'[-1,1]^2',
                'center_gradient_norm':'0', 'center_Hessian_norm':'0',
                'true_D3_sup':'24', 'source_formula_error_bound':'0',
                'exact_midpoint_integral_error':'4/5',
                'repaired_bound_using_rational_rho_3_over_2':str(repaired),
                'scope':'DER-027b prose formula; no verdict on recovered successor code'},
            'replacement_theorems':{
                'smooth_gradient_bound':'G + sigma*rho + B3*rho^2/2',
                'smooth_midpoint_error':'(sigma+B3*rho)*h^4/12',
                'C4_assisted_grid_bound':'sqrt(2)*(Q+B4*h)',
                'rational_relaxation':'3/2*(Q+B4*h)',
                'factor_eight_sufficient_condition':'B4*h <= 13*Q/3',
                'grid_condition_example':{'Q':'1','B4':'4','h':'1','certified_B3_upper':str(grid_b3_upper(1,4,1))},
                'analytic_composition':'Full third-order product/chain bound in PROOF.md; no sample inference',
                'positive_box_integral':'area(box)*exp(-Q/2)*P*mM*mS*mY/(2*pi*sqrt(V)*D)'},
            'synthetic_example':{
                'is_actual_lambda':False,'domain':'[-1/2,1/2]^2',
                'function':'exp(-(x^2+y^2)/2)/(4*pi)',
                'third_derivative_upper_headline':'57/256',
                'pointwise_lower_headline':'1/20',
                'integral_lower_headline':'1/20',
                'certified_D3_upper':str(synthetic[3]),
                'certified_pointwise_lower':str(synthetic_lower)},
            'remaining_obligations':[
                'Certify actual normalized periodized Lambda ingredient ranges and C3 operator derivative bounds on a typed box.',
                'Prove actual typed margins including trc<0 and window probability lower bound.',
                'Handle all typing and clipping interfaces by valid branchwise regularity or Lipschitz certificates.',
                'For grid replacement, certify a C4 bound on the complete stencil halo and a true station-net cover.',
                'Establish finite-r uniformity and all other lower-campaign premises separately.',
                'No actual Lambda lower constant, H-B3 discharge, q0 closure, or K3 assembly successor is delivered.'],
            'canonical_status_changed':False,'original_prize_closed':False,
            'organizational_independence_credit':0}


def dump(report):
    return json.dumps(report,indent=2,sort_keys=True)+'\n'


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo',type=Path,default=REPO)
    ap.add_argument('--verify',type=Path)
    ap.add_argument('--output',type=Path)
    args = ap.parse_args(argv)
    try:
        report = build(args.repo)
        text = dump(report)
        if args.verify:
            require(args.verify.read_text() == text, 'certificate mismatch')
        if args.output:
            with args.output.open('x') as f:
                f.write(text)
        print('PASS: exact Lambda obstruction and conditional analytic replacement')
        return 0
    except (ValueError, OSError, KeyError, TypeError, ZeroDivisionError) as e:
        print('FAIL: '+str(e),file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
