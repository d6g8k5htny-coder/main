"""Meaningful failures for the H3 whole-interval conditioning candidate."""
from fractions import Fraction as F
from pathlib import Path
import copy
import json
import os
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
import check_h3_uniform as h

HERE=Path(__file__).resolve().parent

class H3UniformTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.report=json.loads((HERE/'result.json').read_text())
        cls.m,_=h.moments()

    def cli(self,args, *, optimized=None):
        if optimized is None:
            optimized=bool(sys.flags.optimize)
        return subprocess.run([sys.executable,'-B',*(['-O'] if optimized else []),
            str(HERE/'check_h3_uniform.py'),*map(str,args)],
            text=True,capture_output=True,timeout=30,
            env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})

    def must_fail(self,args,text):
        result=self.cli(args)
        self.assertEqual(result.returncode,1,result.stdout+result.stderr)
        self.assertIn(text,result.stderr)
        self.assertNotIn('PASS:',result.stdout)

    def test_cubic_peano_identity_has_negative_half(self):
        self.assertEqual(h.peano_monomial(3),(F(-1,2),F(-1,2)))

    def test_peano_sign_mutation_rejected(self):
        self.must_fail(['--peano-sign','1'],'Peano identity monomial 3')

    def test_understated_transport_rejected(self):
        self.must_fail(['--transport','3/2'],'transport coefficient majorizes')

    def test_oversized_floor_rejected(self):
        self.must_fail(['--floor','1/50'],'requested covariance floor')

    def test_radius_outside_proved_interval_rejected(self):
        self.must_fail(['--radius','1/10'],'radius in exact approved interval')

    def test_radius_zero_rejected_by_requested_band_contract(self):
        self.must_fail(['--radius','0'],'radius in exact approved interval')

    def test_wrong_limit_scale_removes_positive_definiteness(self):
        gram=h.limiting_gram(self.m,last_scale=F(0))
        shifted=tuple(tuple(x-(h.LIMIT_FLOOR if i==j else 0)
                            for j,x in enumerate(row)) for i,row in enumerate(gram))
        with self.assertRaises(ValueError):
            h.interval_ldlt(shifted,round_bits=h.BITS)

    def test_image_tail_covers_actual_omitted_pair(self):
        actual_pair=2*h.exp(h.I.exact(-1152),h.PREC)
        bound=h.tail(0)
        self.assertGreaterEqual(bound,actual_pair.hi)
        self.assertLess(bound/2,actual_pair.lo)

    def test_normalizer_retains_noncentral_mass(self):
        _,z=h.moments()
        # The tiny torus correction may be below a dyadic output ulp. Its
        # positive lower witness must still lie below the certified upper.
        witness=1+2*h.exp(h.I.exact(-288),h.PREC).lo
        self.assertGreater(witness,1)
        self.assertGreaterEqual(z.hi,witness)
        self.assertLess(F(1),witness)  # Dropping every image is refuted.

    def test_derivative_sign_is_load_bearing(self):
        variance=h.covariance((1,0),(1,0),self.m)
        self.assertGreater(variance.lo,0)
        self.assertLess((-variance).hi,0)

    def test_source_archive_drift_rejected(self):
        with tempfile.TemporaryDirectory(dir=HERE) as temp:
            root=Path(temp)
            (root/'quarantine').mkdir()
            (root/'quarantine/EXCLUSIONS.json').write_text('{"exclusions":[]}')
            archive=root/h.ARCHIVE
            archive.parent.mkdir(parents=True)
            archive.write_bytes(b'wrong source')
            with patch.object(h,'REPO',root), self.assertRaisesRegex(ValueError,'archive SHA'):
                h.custody()

    def test_hash_exclusion_rejected_before_archive_read(self):
        with tempfile.TemporaryDirectory(dir=HERE) as temp:
            root=Path(temp)
            (root/'quarantine').mkdir()
            (root/'quarantine/EXCLUSIONS.json').write_text(json.dumps({'exclusions':[
                {'payload_sha256':h.MEMBER_SHA}]}))
            with patch.object(h,'REPO',root), self.assertRaisesRegex(ValueError,'logically excluded'):
                h.custody()

    def test_wrong_candidate_floor_rejected(self):
        with tempfile.TemporaryDirectory(dir=HERE) as temp:
            data=copy.deepcopy(self.report)
            data['payload']['uniform_pin_covariance_floor']='1/10'
            data['payload_sha256']=h.digest(h.canonical(data['payload']).encode())
            path=Path(temp)/'candidate.json'; path.write_text(json.dumps(data))
            self.must_fail(['--verify',path],'newly computed typed JSON')

    def test_boolean_zero_type_alias_rejected(self):
        with tempfile.TemporaryDirectory(dir=HERE) as temp:
            data=copy.deepcopy(self.report)
            data['payload']['organizational_independence_credit']=False
            data['payload_sha256']=h.digest(h.canonical(data['payload']).encode())
            path=Path(temp)/'candidate.json'; path.write_text(json.dumps(data))
            self.must_fail(['--verify',path],'newly computed typed JSON')

    def test_claimed_raw_constant_floor_rejected(self):
        with tempfile.TemporaryDirectory(dir=HERE) as temp:
            data=copy.deepcopy(self.report)
            data['payload']['h3_raw_limit']='1/1000'
            data['payload_sha256']=h.digest(h.canonical(data['payload']).encode())
            path=Path(temp)/'candidate.json'; path.write_text(json.dumps(data))
            self.must_fail(['--verify',path],'newly computed typed JSON')

    def test_omitted_remaining_hypotheses_rejected(self):
        with tempfile.TemporaryDirectory(dir=HERE) as temp:
            data=copy.deepcopy(self.report)
            data['payload']['remaining']=[]
            data['payload_sha256']=h.digest(h.canonical(data['payload']).encode())
            path=Path(temp)/'candidate.json'; path.write_text(json.dumps(data))
            self.must_fail(['--verify',path],'newly computed typed JSON')

    def test_normal_and_optimized_replays_identical(self):
        with tempfile.TemporaryDirectory(dir=HERE) as temp:
            paths=[Path(temp)/'normal.json',Path(temp)/'optimized.json']
            for optimized,path in zip((False,True),paths):
                result=self.cli(['--verify',HERE/'result.json','--output',path],optimized=optimized)
                self.assertEqual(result.returncode,0,result.stderr)
                self.assertIn('PASS:',result.stdout)
            self.assertEqual(paths[0].read_bytes(),paths[1].read_bytes())
            self.assertEqual(paths[0].read_bytes(),(HERE/'result.json').read_bytes())

    def test_output_overwrite_rejected_and_bytes_retained(self):
        with tempfile.TemporaryDirectory(dir=HERE) as temp:
            path=Path(temp)/'existing.json'; path.write_bytes(b'keep exactly')
            self.must_fail(['--output',path],'File exists')
            self.assertEqual(path.read_bytes(),b'keep exactly')

    def test_output_inside_repository_rejected(self):
        self.must_fail(['--output',h.REPO/'must-not-exist-h3-test.json'],'read-only repository')

    def test_float_and_bool_radii_rejected_in_process(self):
        for radius in (.05,True):
            with self.subTest(radius=radius),self.assertRaisesRegex(ValueError,'radius in exact'):
                h.prove(radius=radius)


if __name__=='__main__':
    unittest.main(verbosity=2)
