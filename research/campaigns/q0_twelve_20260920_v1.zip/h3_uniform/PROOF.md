# H3 conditioning through r=0 and the correctly rescaled limit

Author-side proved candidate. Exact target `Q0-P12-H3-UNIFORM-20260920-v1`;
R17 claim `279870b8-89e6-406d-a150-f655dc2c1ff6` is managed by the parent.
Source-exposed OpenAI work; organizational independence credit **zero**.
This document and its replay change no canonical status. They establish no
finite-r numerical H3 floor, full RN or q0 closure, prize result or 3D composition.

## Conclusions

For the **normalized two-dimensional side-24 periodized Gaussian field**, with
M=(-r/2,0), S=(r/2,0), use the source's six pins

    (f(M), fx(M), fy(M), f(S), fx(S), fy(S)) = (6/5,0,0,6/5-r³/6,0,0).

The cancellation-free six-vector V defined below extends to r=0 in Gaussian
L². Its covariance G(r) satisfies the uniform, original-coordinate inequality

    G(r) >= (81/6400) I₆,                       0 <= r <= 1/20.

This supplies a quantitatively invertible conditioning law on an entire
continuum. It is neither a sampled-station assertion nor a floor on the
conditional soft Hessian covariance, which degenerates as r tends to zero.

Let Z(r) be the original source quantity

    E[ |det H_M det H_S| 1{M maximum, S saddle} | six pins ].

Writing m₂=-k''(0), m₄=k⁽⁴⁾(0) for the normalized one-axis kernel,

    lim(r→0+) Z(r)/r² = E[ Q² 1{Q<0} ],
    Q ~ N( -(6/5)m₂, m₄-m₂² ).

The limit is certified in the outward exact decimal interval

    [3.23097853528700494809, 3.23097853528700494810],

and in particular exceeds 3. Thus Z(r) tends to zero: **no constant c>0
can satisfy Z(r)>=c for every 0<r<=1/20 in these original Hessian units**.
A constant lower bound on Z(r)/r² is the appropriate small-r target.
The existing fixed-r 0.0077592917375327855 floor at r=1/20 is unaffected.

By the proved limit there exists δ>0 with Z(r)>=3r² for every 0<r<δ.
This is an existential consequence, **not an explicit radius certificate**.
The present whole-band quantitative result concerns the pin covariance only.

## 1. Law, source and regularity

The field covariance is K(x,y)=k(x)k(y), where

    k(s) = Σ(j∈Z) exp(-(s+24j)²/2) / Σ(j∈Z) exp(-(24j)²/2).

The Gaussian Fourier coefficients are strictly positive and decay faster than
any power, so this is a positive-definite stationary smooth Gaussian law.
Its derivative fields exist to every order in L² and have smooth versions.
All integral identities below may either be read pathwise on a smooth version
or as Bochner integrals in Gaussian L². Stationarity gives

    ||∂x^a ∂y^b f||₂² = m_(2a) m_(2b).

The definition and raw six-pin values are bound to the exact nonexcluded RN5
`closure_round2/rn_field.py` member and the H3 proof member. Their hashes,
archive identity and repository numerical dependency identities are in the
report and `SOURCES.json`. No frozen code is executed. The source fixes r=1/20;
allowing variable r and proving the statements here are new work, not a claim
that the historical source already supplies this extension.

## 2. Cancellation-free six pins

For r>0 define

    V0=f(M), V1=fx(M), V2=fy(M),
    V3=(fx(S)-fx(M))/r,
    V4=(fy(S)-fy(M))/r,
    V5=(f(S)-f(M))/r³ - (fx(S)+fx(M))/(2r²).

This invertible transform takes the stipulated values to
v=(6/5,0,0,0,0,-1/6). The inverse is

    fx(S)=r V3+V1,   fy(S)=r V4+V2,
    f(S)=r³ V5+V0+r(r V3+2 V1)/2.

The fundamental theorem of calculus and two integrations by parts yield

    V3 = ∫[-1/2,1/2] fxx(rt,0) dt,
    V4 = ∫[-1/2,1/2] fxy(rt,0) dt,
    V5 = -(1/2) ∫[-1/2,1/2] (1/4-t²) fxxx(rt,0) dt.          (1)

For the last identity, if g(t)=f(rt,0), integration by parts gives

    ∫ (1/4-t²) g'''(t) dt = g'(1/2)+g'(-1/2)-2(g(1/2)-g(-1/2)).

Division by -2r³ is exactly the displayed V5. The positive kernel in (1)
has mass 1/12 and absolute first moment 1/64. Hence

    V(0)=(f, fx, fy, fxx, fxy, -fxxx/12) at (0,0).           (2)

The monomial checks through degree 12 are falsification controls on formula
(1), not a substitute for the integration-by-parts proof for all smooth f.

## 3. Explicit L² remainder and uniform positive covariance

For any derivative field U, Minkowski and stationarity imply

    ||U(s,0)-U(0,0)||₂ <= |s| ||∂x U||₂.

Apply this to V0–V2 at -r/2 and to the integral formulas for V3–V5. Their
squared error bounds, after division by r², are respectively

    m₂/4, m₄/4, m₂²/4, m₆/16, m₄m₂/16, m₈/4096.

The certified sum C lies in

    [2.40063476562499999999, 2.40063476562500000001]

and is less than (31/20)². Thus, for every a∈R⁶,

    ||a·(V(r)-V(0))||₂ <= (31/20) r ||a||₂.                 (3)

The limiting covariance G(0) is assembled from (2) with exact derivative
signs. The only nontrivial coupled blocks are the (f,fxx) and (fx,-fxxx/12)
blocks:

    [[1,-m₂],[-m₂,m₄]],   [[m₂,m₄/12],[m₄/12,m₆/144]],

and fy, fxy have variances m₂ and m₂². The interval LDL replay of
G(0)-(3/80)I has all six pivots strictly positive. This implies the stated
lower bound for the actual covariance, not only for a midpoint matrix.
Since (19/100)² < 3/80, reverse triangle inequality and (3) give

    ||a·V(r)||₂ >= [19/100-(31/20)r] ||a||₂
                >= (9/80) ||a||₂,              0<=r<=1/20.

Squaring proves G(r)>=(81/6400)I throughout the continuum. Consequently
||G(r)^(-1)||op <= 6400/81 there. The raw six-pin covariance need not have
this uniform bound: the r-dependent transform is essential.

## 4. Full image sums, tails and moments

The checker evaluates k⁽ⁿ⁾(0) through n=8, using exact Hermite coefficients
and the repository's certified exponential intervals. For n≥0 and u≥1,

    |He_n(u)| <= C_n uⁿ,   C_n=Σ|coefficient of He_n|.

The pair of images at ±24j is bounded by
2 C_n (24j)ⁿ exp(-(24j)²/2). For j>=2 the successive ratio decreases and
is at most (3/2)ⁿ exp(-1440)<1. The omitted full tail is therefore at most

    2 C_n 48ⁿ exp(-1152) / [1-(3/2)ⁿ exp(-1440)].

The j=0 and ±1 contributions are retained explicitly. The normalization
uses 1+2exp(-288) plus an interval containing the entire positive tail.
Numerator signed tails and denominator tails are both retained. The moment
identity is m_(2a)=(-1)^a k⁽²ᵃ⁾(0), not an unsigned odd-frequency shortcut.
Exact Fractions and outward rounding are used throughout. The quoted decimal
brackets are themselves exact rationals checked against the full endpoints.

## 5. Pin-subtracted Hessians have a finite conditional limit

Directly dividing fxx(M) or fxy(M) by r is numerically ill-conditioned. Under
V3=V4=0 those random variables equal the following bounded integral forms:

    A_M = [fxx(M)-V3]/r = -∫(1/2-t) fxxx(rt,0) dt,
    A_S = [fxx(S)-V3]/r =  ∫(1/2+t) fxxx(rt,0) dt,
    B_M = [fxy(M)-V4]/r = -∫(1/2-t) fxxy(rt,0) dt,
    B_S = [fxy(S)-V4]/r =  ∫(1/2+t) fxxy(rt,0) dt.

Each integral is over [-1/2,1/2]. These equalities are linear random-variable
identities before conditioning after subtraction, and identify the same
Gaussian conditional law at the specified values by invertibility of G(r).
Let W(r)=(fyy(M),fyy(S),A_M,A_S,B_M,B_S). Then

    W(0)=(q,q,-fxxx/2,fxxx/2,-fxxy/2,fxxy/2), q=fyy(0).

The squared L² errors of W_i(r)-W_i(0), divided by r², are bounded by

    (m₂m₄/4, m₂m₄/4, m₈/64, m₈/64, m₆m₂/64, m₆m₂/64).

For the last four, ∫|t|(1/2±t)dt=1/8. Thus the joint covariance of
(V(r),W(r)) converges to its value at zero. The positive uniform pin floor
makes Gaussian regression continuous: the conditional means
Cov(W,V)G⁻¹v and conditional covariances Cov(W)-Cov(W,V)G⁻¹Cov(V,W)
converge. All conditional means and covariances remain bounded on [0,1/20].
This proves convergence in law of the conditional W(r), including when the
limiting conditional covariance is singular.

At r=0, the pins fix fxxx=2, so A_M=-1 and A_S=1 almost surely. The random
variable q+m₂f is uncorrelated with all six coordinates of V(0): by parity
all except f,fxx vanish, and those two covariances cancel exactly as
-m₂+m₂=0 and m₂²-m₂²=0. Joint Gaussianity makes it independent of V(0).
Therefore the conditional q is exactly Q with mean and variance stated above.
The certificate establishes the variance is strictly positive, so P(Q=0)=0.

## 6. Limit of the typed H3 expectation

In the conditional law, H at each pin is

    [[r A, r B], [r B, q]],   det H = r D,   D=Aq-rB².

The pair (D_M,D_S) converges in law to (-Q,Q). Away from Q=0, the indicator
of M negative definite and S a saddle tends to 1{Q<0}. The continuous
mapping argument therefore applies almost surely under a convergent Gaussian
coupling, or equivalently by the weak convergence theorem for functions
whose discontinuities have limiting probability zero.

The rescaled integrand is |D_M D_S| times that indicator. It is bounded by
a polynomial of degree four in W(r), with coefficients uniformly bounded
for 0<=r<=1/20. The uniformly bounded conditional means and covariances
imply uniform bounds for its square via Gaussian eighth moments. The family
is uniformly integrable. Convergence of expectations consequently gives

    Z(r)/r² -> E[Q² 1{Q<0}].

For μ=-(6/5)m₂, σ²=m₄-m₂² and a=-μ/σ,

    E[Q² 1{Q<0}] = (σ²+μ²) Φ(a) - μσ φ(a).

This identity follows from ∫[-∞,a] zφ(z)dz=-φ(a) and
∫[-∞,a] z²φ(z)dz=Φ(a)-aφ(a). The replay evaluates this expression through
certified sqrt, Φ and normal density. The positive finite limit proves both
the existential rescaled lower floor and the impossibility of an unscaled
constant lower floor down to zero. No historical uniform-band claim is being
reclassified; this conclusion refers exactly to the Z defined in this note.

## Remaining work and reproduction

An explicit H3/r² floor needs quantitative conditional-law transport and
control of the typed-event boundary, followed by a finite-r integration
argument. Those obligations are absent from this delivery; the positive
pin covariance alone does not discharge them. External independent review
also remains open. No scientific status is promoted.

`RUN.json` gives the replay and meaningful negative-control commands. They
require Python 3.11, this directory, and the source/dependency-bound repository.
The checker refuses floating-point input, excluded source members, source
hash drift, invalid positivity margins, wrong Peano signs, missing/altered
candidate content, report overwrite, or report output inside the repository.
Normal and optimized execution must yield identical result bytes.

## Source comparison: LS-DER-032

After this derivation, the parent supplied the native-export reading of
LS-DER-032-v1.0, Drive `1AUEXzPfbZsdtArlkHNhIUK4hbHqg8ATbb5M99Ex57HU`.
It is a same-provider candidate companion, with external review pending and
no canonical impact. Its six variables are symmetric about the midpoint.
In its displayed order their exact relationship to our V is

    U1=V0+(r/2)V1+(r²/4)V3+(r³/2)V5,
    U2=V5,
    U3=V1+(r/2)V3,
    U4=V3,
    U5=V2+(r/2)V4,
    U6=V4.

They share the limiting jets up to permutation, but their finite-r covariance
matrices differ. **The numerical eigenfloor in this note applies to V, not U.**
The source's compactness argument addresses every angle θ; this delivery
addresses only the fixed x axis and the normalized separable side-24 law.
It provides explicit full-band constants for that narrower conditioning
problem and the H3 rescaled limit. No all-angle theorem or source status is
inherited. The DOCX export hash and separately derived reading hash are
recorded in `SOURCES.json`; neither is asserted to be the source's marked
frozen-body hash.
