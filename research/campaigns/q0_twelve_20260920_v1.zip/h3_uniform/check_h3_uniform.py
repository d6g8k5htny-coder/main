#!/usr/bin/env python3
"""Cancellation-free H3 pin law and rescaled small-r limit; no status changes.

Author-side exact interval candidate. Source-exposed, zero independence credit.
Not a finite-r H3 lower bound, RN closure, or 3D composition.
"""
from fractions import Fraction as F
from pathlib import Path
from zipfile import ZipFile
import argparse
import hashlib
import json
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
DEFAULT_REPO = Path('/Users/dylanroy/Documents/Codex/research-main')
early = argparse.ArgumentParser(add_help=False)
early.add_argument('--repo', type=Path, default=DEFAULT_REPO)
REPO = early.parse_known_args()[0].repo.resolve()
sys.path.insert(0, str(REPO))
from research.interval import Interval as I, exp, sqrt, Phi, normal_pdf
from research.bands.hermite_gaussian import hermite_coefficients
from research.rn.conditioning import interval_ldlt

PREC, BITS = 100, 256
ARCHIVE = 'drive/mirrors/2026-09-17_RN5_MOMENT_REPAIR_AND_REVIEW_ERRATUM/RN5_REPAIR_AND_ERRATUM_BUNDLE.zip'
ARCHIVE_SHA = '28c1c385406452a706f11aea1646a87585b002841005d57febdf32222c368c6e'
MEMBER = 'closure_round2/rn_field.py'
MEMBER_SHA = 'd9167ae821684f716fdbae11cd39eb13818422f50b6566f677d62c292e4a93c8'
H3_MEMBER = 'intake/rn_source/K3_SIDE24_LB/UPPER2D/H3_closure/H3_RUNG_FLOOR.md'
H3_SHA = '6347275d86c56842b719b36180e535bc1793d6995ddb68464db2960820440dfa'
RMAX, LIMIT_FLOOR, TRANSPORT, UNIFORM_FLOOR = F(1,20), F(3,80), F(31,20), F(81,6400)
PIN_JETS = ((0,0),(1,0),(0,1),(2,0),(1,1),(3,0))
SCALES = (F(1),)*5+(F(-1,12),)


def need(ok, message):
    if not ok:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    data = path.read_bytes()
    return {'bytes':len(data), 'sha256':digest(data)}


def encode(value):
    if isinstance(value, I):
        return {'lo':str(value.lo), 'hi':str(value.hi)}
    if isinstance(value, F):
        return str(value)
    if isinstance(value, dict):
        return {str(k):encode(v) for k,v in value.items()}
    if isinstance(value, (tuple,list)):
        return [encode(v) for v in value]
    return value


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',',':'), ensure_ascii=False)


def custody():
    exclusions=json.loads((REPO/'quarantine/EXCLUSIONS.json').read_text())['exclusions']
    for member, sha in ((MEMBER,MEMBER_SHA),(H3_MEMBER,H3_SHA)):
        need(not any(e.get('payload_sha256')==sha or e.get('member_path') in
                     (member,member.removeprefix('intake/rn_source/')) for e in exclusions),
             'target source must not be logically excluded')
    data=(REPO/ARCHIVE).read_bytes()
    need(digest(data)==ARCHIVE_SHA, 'RN5 archive SHA mismatch')
    import io
    member_identities={}
    with ZipFile(io.BytesIO(data)) as z:
        for name,sha in ((MEMBER,MEMBER_SHA),(H3_MEMBER,H3_SHA)):
            need(z.namelist().count(name)==1,'source member must be unique')
            body=z.read(name)
            need(digest(body)==sha, 'source member SHA mismatch')
            member_identities[name]={'bytes':len(body),'sha256':sha,'executed':False}
    return {'archive':{'drive_id':'1g5UP_KYlvPmx7LFwjGk6qK5QZLnL1hLj',
                       'relative_path':ARCHIVE,'bytes':len(data),'sha256':ARCHIVE_SHA},
            'members':member_identities,
            'prior_fixed_r_work':'parallel-math-20260920/h3_floor: source exposed',
            'variable_r_extension':'new author-side derivation; source fixed r=1/20'}


def tail(order):
    """Full pair tail |j|>=2 at zero, all terms retained as signed radius."""
    need(type(order) is int and 0<=order<=8, 'tail order 0..8 required')
    c=sum(abs(x) for x in hermite_coefficients(order))
    first=c*48**order*exp(I.exact(-1152),PREC)
    ratio=F(3,2)**order*exp(I.exact(-1440),PREC)
    need(ratio.hi<1,'image tail ratio below one')
    return (2*first/(1-ratio)).hi


def polynomial(coefficients,x):
    result=F(0)
    for c in reversed(coefficients):
        result=result*x+c
    return result


def moments():
    e=exp(I.exact(-288),PREC)
    z=(1+2*e+I(0,tail(0))).round_out(BITS)
    need(z.lo>0,'full normalizer positive')
    result={0:I.exact(1)}
    for n in (2,4,6,8):
        c=hermite_coefficients(n)
        numerator=I.exact(c[0])+2*polynomial(c,F(24))*e+I(-tail(n),tail(n))
        result[n]=(((-1)**(n//2))*numerator/z).round_out(BITS)
        need(result[n].lo>0,'positive derivative variance')
    return result,z


def covariance(alpha,beta,m):
    out=I.exact((-1)**sum(beta))
    for a,b in zip(alpha,beta):
        order=a+b
        if order%2:
            return I.exact(0)
        out*=(-1)**(order//2)*m[order]
    return out.round_out(BITS)


def limiting_gram(m, last_scale=SCALES[-1]):
    scales=(*SCALES[:5],last_scale)
    return tuple(tuple((scales[i]*scales[j]*covariance(a,b,m)).round_out(BITS)
                       for j,b in enumerate(PIN_JETS)) for i,a in enumerate(PIN_JETS))


def peano_monomial(degree, last_sign=-1):
    """Exact cubic-subtraction identity at r=1 on monomials x^degree."""
    h=F(1,2)
    direct=h**degree-(-h)**degree
    if degree:
        direct-=F(degree,2)*(h**(degree-1)+(-h)**(degree-1))
    if degree<3:
        integral=F(0)
    else:
        n=degree-3
        power=lambda k: F(0) if k%2 else 2*h**(k+1)/F(k+1)
        integral=F(last_sign,2)*degree*(degree-1)*(degree-2)*(power(n)/4-power(n+2))
    return direct,integral


def verify_identities(last_sign=-1):
    for n in range(13):
        direct,integral=peano_monomial(n,last_sign)
        need(direct==integral,'Peano identity monomial '+str(n))
    # These polynomial tests catch mistakes; integration by parts in PROOF.md
    # establishes the identity for every smooth field, not only polynomials.
    mass=F(1,2)*(F(1,4)-F(1,12))
    first_abs=F(1,4)*F(1,8)-F(1,64)
    need(mass==F(1,12),'Peano kernel mass 1/12')
    need(first_abs==F(1,64),'Peano absolute first moment 1/64')


def prove(*, radius=RMAX, floor=UNIFORM_FLOOR, transport=TRANSPORT, peano_sign=-1):
    need(type(radius) is F and 0<radius<=RMAX,'radius in exact approved interval (0,1/20]')
    need(type(floor) is F and floor>0,'positive exact requested floor')
    need(type(transport) is F and transport>0,'positive exact transport bound')
    binding=custody()
    verify_identities(peano_sign)
    m,z=moments()
    gram=limiting_gram(m)
    shifted=tuple(tuple(v-(LIMIT_FLOOR if i==j else 0) for j,v in enumerate(row))
                  for i,row in enumerate(gram))
    ldlt=interval_ldlt(shifted,round_bits=BITS)
    need(all(d.lo>0 for d in ldlt.pivots),'limiting pin covariance exceeds 3/80 I')
    # Sum_i ||V_i(r)-V_i(0)||_2^2 <= c r² by exact Peano weights.
    c=(m[2]/4+m[4]/4+m[2]**2/4+m[6]/16+m[4]*m[2]/16+m[8]/4096).round_out(BITS)
    need(c.hi<=transport**2,'transport coefficient majorizes entire L2 remainder')
    need(c.lo>=F('2.40063476562499999999') and c.hi<=F('2.40063476562500000001'),
         'published exact decimal transport bracket contains the entire interval')
    sqrt_lower=F(19,100)
    need(sqrt_lower**2<=LIMIT_FLOOR,'rational square-root floor valid')
    gap=sqrt_lower-transport*radius
    need(gap>0,'uniform singular-value gap is positive')
    need(floor<=gap**2,'requested covariance floor follows from transport')
    mu=(-F(6,5)*m[2]).round_out(BITS)
    variance=(m[4]-m[2]**2).round_out(BITS)
    need(mu.hi<0 and variance.lo>0,'limiting transverse Gaussian is nondegenerate, negative mean')
    sigma=sqrt(variance,PREC).round_out(BITS)
    a=(-mu/sigma).round_out(BITS)
    coefficient=((variance+mu**2)*Phi(a,PREC)-mu*sigma*normal_pdf(a,PREC)).round_out(BITS)
    need(coefficient.lo>F(3),'rescaled H3 limiting coefficient exceeds 3')
    need(coefficient.hi<F(4),'rescaled H3 limiting coefficient below 4')
    need(coefficient.lo>=F('3.23097853528700494809') and coefficient.hi<=F('3.23097853528700494810'),
         'published exact decimal H3 limit bracket contains the entire interval')
    # Bounds on pin-subtracted targets W(r)-W(0), squared / r².
    soft_error_squared=(m[2]*m[4]/4,m[2]*m[4]/4,m[8]/64,m[8]/64,
                        m[6]*m[2]/64,m[6]*m[2]/64)
    return encode({'schema':'h3-uniform-pin-and-rescaled-limit-v1',
        'status':'PROVED_CANDIDATE','source_binding':binding,
        'domain':{'r':f'[0,{radius}]','height':'6/5','dimension':2,'side':24},
        'moments':m,'full_normalizer':z,'limiting_pin_covariance':gram,
        'shifted_ldlt_pivots':ldlt.pivots,'limiting_pin_covariance_floor':LIMIT_FLOOR,
        'peano_first_abs_moment':'1/64','peano_mass':'1/12',
        'pin_l2_remainder_squared_coefficient':c,'pin_l2_remainder_coefficient':transport,
        'uniform_pin_covariance_floor':floor,'singular_value_gap':gap,
        'pin_subtracted_soft_l2_remainder_squared_coefficients':soft_error_squared,
        'limiting_transverse_mean':mu,'limiting_transverse_variance':variance,
        'h3_rescaled_limit':coefficient,'h3_rescaled_limit_proved_lower':'3',
        'qualitative_h3_floor':{'coefficient':'3','claim':'exists delta>0: Z(r)>=3*r² for every 0<r<delta',
                                'numerical_delta_certified':False,'orientation':'fixed x axis'},
        'h3_raw_limit':'0','all_r_raw_constant_positive_floor_impossible':True,
        'finite_r_rescaled_h3_floor_established':False,
        'finite_r_h3_radius_for_half_limit_established':False,
        'original_prize_closed':False,'scientific_status_changed':False,
        'organizational_independence_credit':0,'external_review':'OPEN',
        'remaining':['Quantitative conditional-law remainder and typed-event control for an explicit finite-r H3/r² floor.',
                     'Full q0/RN spatial and all-small-r obligations remain open; this is a pin-law and asymptotic lemma only.']})


def dependencies():
    result={}
    for module in list(sys.modules.values()):
        filename=getattr(module,'__file__',None)
        if not filename:
            continue
        path=Path(filename).resolve()
        if path.suffix=='.py' and path.is_relative_to(REPO):
            result[str(path.relative_to(REPO))]=identity(path)
    return dict(sorted(result.items()))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=DEFAULT_REPO)
    p.add_argument('--output',type=Path)
    p.add_argument('--verify',type=Path)
    p.add_argument('--radius',type=F,default=RMAX)
    p.add_argument('--floor',type=F,default=UNIFORM_FLOOR)
    p.add_argument('--transport',type=F,default=TRANSPORT)
    p.add_argument('--peano-sign',type=int,default=-1)
    a=p.parse_args()
    before=dependencies()
    result=prove(radius=a.radius,floor=a.floor,transport=a.transport,peano_sign=a.peano_sign)
    need(dependencies()==before,'repository computational dependencies stable during replay')
    result['dependencies']=before
    payload=canonical(result)
    envelope={'payload':result,'payload_sha256':digest(payload.encode())}
    if a.verify:
        candidate=json.loads(a.verify.read_text())
        need(canonical(candidate)==canonical(envelope),'candidate report must equal the newly computed typed JSON')
    if a.output:
        target=a.output.resolve()
        need(not target.is_relative_to(REPO),'output must be outside read-only repository')
        with target.open('x') as f:
            f.write(json.dumps(envelope,sort_keys=True,indent=2)+'\n')
    print(f'PASS: uniform six-pin covariance >= {a.floor} on [0,{a.radius}]; H3/r² limit > 3; no status promotion')


if __name__=='__main__':
    try:
        main()
    except (ValueError,OSError,KeyError,TypeError) as error:
        print('FAIL: '+str(error),file=sys.stderr)
        sys.exit(1)
