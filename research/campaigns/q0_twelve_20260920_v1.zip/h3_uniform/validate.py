#!/usr/bin/env python3
"""Run the completed candidate and real failure tests in normal and -O modes."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

HERE=Path(__file__).resolve().parent
if sys.version_info<(3,11):
    raise SystemExit('Python 3.11 required')

def identity(path):
    b=path.read_bytes()
    return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}

def need(condition,message):
    if not condition:
        raise ValueError(message)

records=[]
inputs={name:identity(HERE/name) for name in ('check_h3_uniform.py','test_h3_uniform.py','result.json','PROOF.md')}
for optimized,mode in ((False,'normal'),(True,'optimized')):
    prefix=[sys.executable,'-B',*(['-O'] if optimized else [])]
    for label,command in (
        ('replay',prefix+[str(HERE/'check_h3_uniform.py'),'--verify',str(HERE/'result.json'),
                          '--output',str(HERE/f'validated-{mode}.json')]),
        ('tests',prefix+[str(HERE/'test_h3_uniform.py')])):
        result=subprocess.run(command,cwd=HERE,text=True,capture_output=True,timeout=90,
                              env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
        logs={}
        for channel in ('stdout','stderr'):
            path=HERE/f'{label}-{mode}.{channel}.txt'
            with path.open('x') as f:
                f.write(getattr(result,channel))
            logs[channel]=identity(path)
        need(result.returncode==0,f'{label} {mode} failed: {result.stderr}')
        if label=='replay':
            need(result.stdout.startswith('PASS:'),'missing replay PASS')
        else:
            need('Ran 20 tests' in result.stderr and result.stderr.rstrip().endswith('OK'),
                 'twenty substantive tests did not all pass')
        records.append({'label':label,'mode':mode,'argv':command,'exit_code':result.returncode,'logs':logs})
need(all((HERE/f'validated-{mode}.json').read_bytes()==(HERE/'result.json').read_bytes()
         for mode in ('normal','optimized')),'replay reports differ')
need({name:identity(HERE/name) for name in inputs}==inputs,'inputs changed during validation')
receipt={'schema':'h3-uniform-validation-v1','status':'PASS','records':records,
         'test_cases_each_mode':20,'normal_optimized_report_bytes_identical':True,
         'inputs_unchanged':True,'inputs':inputs,'scientific_status_changed':False,
         'organizational_independence_credit':0,'original_prize_closed':False}
with (HERE/'verification_receipt.json').open('x') as f:
    f.write(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print('PASS: both replays byte-identical; 20 tests per normal/-O mode; unchanged inputs')
