"""Mathematical adversaries and actual fail-closed CLI mutations, including -O."""
from fractions import Fraction as F
from functools import lru_cache
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

import wp_event as w

HERE = Path(__file__).resolve().parent
REPO = w.DEFAULT_REPO
w.load_interval(REPO)


def wick_moment(indices, mean, sigma):
    @lru_cache(None)
    def rec(ids):
        if not ids:
            return F(1)
        i, rest = ids[0], ids[1:]
        answer = mean[i]*rec(rest)
        for j, index in enumerate(rest):
            answer += sigma[i][index]*rec(rest[:j]+rest[j+1:])
        return answer
    return rec(tuple(indices))


class MathematicalControls(unittest.TestCase):
    def test_centered_independent_gaussians(self):
        mean, second = w.gaussian_determinant_moments([0]*3, [0]*3, [[1,0,0],[0,1,0],[0,0,1]])
        self.assertEqual(mean[0], -1)
        self.assertEqual(second[0], 4)

    def test_noncentral_formula_against_distinct_wick_recursion(self):
        factors = [[[1,0,0],[0,1,0],[0,0,1]], [[2,0,0],[1,1,0],[-1,2,1]], [[1,0,0],[2,0,0],[3,0,0]]]
        for L in factors:
            sigma = [[sum(F(L[i][k]*L[j][k]) for k in range(3)) for j in range(3)] for i in range(3)]
            mu, beta = list(map(F,[2,-1,3])), [F(1,3),F(-2,5),F(3,7)]
            p, q = w.gaussian_determinant_moments(mu,beta,sigma)
            for t in [F(-2),F(0),F(1,5),F(7,3)]:
                shifted = [mu[i]+beta[i]*t for i in range(3)]
                actual_mean = wick_moment([0,2],shifted,sigma)-wick_moment([1,1],shifted,sigma)
                actual_second = wick_moment([0,2,0,2],shifted,sigma)-2*wick_moment([0,2,1,1],shifted,sigma)+wick_moment([1,1,1,1],shifted,sigma)
                self.assertEqual(w.evaluate(p,t),actual_mean)
                self.assertEqual(w.evaluate(q,t),actual_second)

    def test_degenerate_residual_covariance_valid(self):
        p,q=w.gaussian_determinant_moments([1,0,-1],[0]*3,[[0]*3 for _ in range(3)])
        self.assertEqual(p[0],-1)
        self.assertEqual(q[0],1)

    def test_exact_tower_identity_for_second_moment(self):
        mu=[F(2),F(0),F(1)];beta=[F(1),F(1,2),F(-1,3)]
        S=[[F(int(i==j)) for j in range(3)] for i in range(3)]
        _,poly=w.gaussian_determinant_moments(mu,beta,S)
        total=[[S[i][j]+beta[i]*beta[j] for j in range(3)] for i in range(3)]
        _,unconditional=w.gaussian_determinant_moments(mu,[0]*3,total)
        self.assertEqual(poly[0]+poly[2]+3*poly[4],unconditional[0])

    def test_indefinite_covariance_refused(self):
        with self.assertRaisesRegex(ValueError,'positive semidefinite'):
            w.covariance([[1,2,0],[2,1,0],[0,0,1]])

    def test_asymmetric_covariance_refused(self):
        with self.assertRaisesRegex(ValueError,'asymmetric'):
            w.covariance([[1,0,0],[1,1,0],[0,0,1]])

    def test_float_input_refused(self):
        with self.assertRaisesRegex(ValueError,'inexact'):
            w.gaussian_window(0,0.1,0,1)

    def test_bernstein_catches_interior_maximum(self):
        lo,hi,_=w.bernstein_range([1,0,-1],-1,1)
        self.assertGreaterEqual(hi,1)
        self.assertEqual(w.evaluate([1,0,-1],-1),0)
        self.assertEqual(w.evaluate([1,0,-1],1),0)

    def test_bernstein_constant_and_single_point(self):
        self.assertEqual(w.bernstein_range([3],-2,2)[:2],(3,3))
        self.assertEqual(w.bernstein_range([1,2,3],F(1,2),F(1,2))[:2],(F(11,4),F(11,4)))

    def test_reversed_bernstein_refused(self):
        with self.assertRaisesRegex(ValueError,'reversed'):
            w.bernstein_range([1,2],1,-1)

    def test_cantelli_positive_mean(self):
        self.assertEqual(w.cantelli_negative(2,3),F(3,7))

    def test_cantelli_nonpositive_mean_cannot_use_positive_formula(self):
        self.assertEqual(w.cantelli_negative(-2,3),1)
        self.assertEqual(w.cantelli_negative(0,3),1)

    def test_cantelli_deterministic_sign(self):
        self.assertEqual([w.cantelli_negative(x,0) for x in [-1,0,1]],[1,0,0])

    def test_negative_variance_refused(self):
        with self.assertRaisesRegex(ValueError,'negative'):
            w.cantelli_negative(1,-1)

    def test_actual_missing_square_root_counterexample(self):
        valid=w.generic_cs_upper(F(1,16),F(1,16))
        self.assertLessEqual(valid.lo,F(1,16))
        self.assertGreaterEqual(valid.hi,F(1,16))
        self.assertLess(F(1,4)*F(1,16),F(1,16))

    def test_conditioning_first_restores_linear_probability(self):
        cap=w.conditional_window_upper(1,F(1,100))
        self.assertLessEqual(cap.lo,F(1,100))
        self.assertGreaterEqual(cap.hi,F(1,100))
        self.assertLess(cap.hi,F(1,10))

    def test_probability_over_one_refused(self):
        with self.assertRaisesRegex(ValueError,'probability'):
            w.generic_cs_upper(1,F(11,10))

    def test_zero_normalizer_refused(self):
        with self.assertRaisesRegex(ValueError,'normalizer'):
            w.conditional_window_upper(1,F(1,2),normalizer=0)

    def test_gaussian_cdf_symmetric_window(self):
        p=w.gaussian_window(0,1,-1,1)
        self.assertGreater(p['probability_lower'],F(68,100))
        self.assertLess(p['probability_upper'],F(69,100))

    def test_gaussian_window_far_mean_uses_distance_to_interval(self):
        p=w.gaussian_window(2,1,-1,1)
        self.assertEqual(p['distance_to_window'],1)
        self.assertGreater(p['probability_lower'],F(15,100))
        self.assertLess(p['probability_upper'],F(16,100))

    def test_gaussian_zero_width(self):
        p=w.gaussian_window(0,1,0,0)
        self.assertEqual(p['probability_upper'],0)

    def test_mean_inside_window_has_no_exponential_distance_kill(self):
        p=w.gaussian_window(F(1,2),1,0,1)
        self.assertEqual(p['distance_to_window'],0)

    def test_gaussian_zero_variance_refused(self):
        with self.assertRaisesRegex(ValueError,'positive'):
            w.gaussian_window(0,0,-1,1)

    def test_gaussian_reversed_window_refused(self):
        with self.assertRaisesRegex(ValueError,'reversed'):
            w.gaussian_window(0,1,1,-1)

    def test_shrinking_variance_prevents_cubic_probability(self):
        for r in [F(1,10),F(1,100),F(1,1000)]:
            ell=r**3/6
            p=w.gaussian_window(0,ell,0,ell)
            self.assertGreater(p['probability_lower'],F(1,3))

    def test_marginal_product_false_without_conditional_law(self):
        p=F(1,16)
        pa=w.atom_mass([p,1-p],[True,False])
        good=w.atom_mass([p,1-p],[False,False])
        self.assertLess(good,pa*(1-pa))

    def test_weighted_Palm_mismatch(self):
        p=w.atom_mass([F(1,100),F(99,100)],[True,False],[100,1])
        self.assertEqual(p,F(100,199))
        self.assertGreater(p,F(1,2))

    def test_atom_probability_sum_refused(self):
        with self.assertRaisesRegex(ValueError,'probabilities'):
            w.atom_mass([F(1,4),F(1,4)],[True,False])


class ActualCLIControls(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='tests-',dir=HERE)
        self.path=Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def run_cli(self,*args,script=None):
        command=[sys.executable,'-B']
        if sys.flags.optimize:
            command.append('-O')
        command.extend([str(script or HERE/'wp_event.py'),'--repo',str(REPO),*map(str,args)])
        return subprocess.run(command,capture_output=True,text=True,timeout=60)

    def test_actual_cli_replay(self):
        out=self.path/'result.json'
        r=self.run_cli('--verify',HERE/'result.json','--output',out)
        self.assertEqual(r.returncode,0,r.stderr)
        self.assertEqual(out.read_bytes(),(HERE/'result.json').read_bytes())

    def test_actual_tampered_probability_report(self):
        report=json.loads((HERE/'result.json').read_text())
        report['exact_counterexamples']['missing_sqrt']['valid_bound']='1/64'
        path=self.path/'bad.json';path.write_text(json.dumps(report))
        r=self.run_cli('--verify',path)
        self.assertNotEqual(r.returncode,0)
        self.assertIn('differs',r.stderr)

    def test_actual_scope_promotion_report(self):
        report=json.loads((HERE/'result.json').read_text())
        report['q0_closed']=True
        path=self.path/'bad.json';path.write_text(json.dumps(report))
        self.assertNotEqual(self.run_cli('--verify',path).returncode,0)

    def test_actual_bad_quartic_report(self):
        report=json.loads((HERE/'result.json').read_text())
        report['exact_gaussian_test_law_NOT_SIDE24']['determinant_second_moment_polynomial'][0]='0'
        path=self.path/'bad.json';path.write_text(json.dumps(report))
        self.assertNotEqual(self.run_cli('--verify',path).returncode,0)

    def test_actual_existing_output_preserved(self):
        out=self.path/'output.json';out.write_bytes(b'KEEP')
        r=self.run_cli('--output',out)
        self.assertNotEqual(r.returncode,0)
        self.assertEqual(out.read_bytes(),b'KEEP')

    def copy_checker(self):
        shutil.copytree(HERE/'sources',self.path/'sources')
        shutil.copyfile(HERE/'DEPENDENCIES.json',self.path/'DEPENDENCIES.json')
        script=self.path/'wp_event.py'
        shutil.copyfile(HERE/'wp_event.py',script)
        return script

    def test_actual_source_mutation_refused(self):
        script=self.copy_checker()
        with (self.path/'sources/GP-LB-STAT-003.md').open('ab') as f:
            f.write(b'changed')
        r=self.run_cli('--verify',HERE/'result.json',script=script)
        self.assertNotEqual(r.returncode,0)
        self.assertIn('source dependency mismatch',r.stderr)

    def test_actual_missing_sqrt_implementation_mutation_refused(self):
        script=self.copy_checker()
        source=script.read_text()
        before='return INTERVAL.sqrt(INTERVAL.Interval.exact(second*probability), 45) * density / normalizer'
        after='return INTERVAL.sqrt(INTERVAL.Interval.exact(second), 45) * probability * density / normalizer'
        self.assertEqual(source.count(before),1)
        script.write_text(source.replace(before,after))
        r=self.run_cli('--verify',HERE/'result.json',script=script)
        self.assertNotEqual(r.returncode,0)

    def test_actual_wrong_conditioning_moment_mutation_refused(self):
        script=self.copy_checker()
        source=script.read_text()
        before='second = add(mul(det_mean, det_mean), [2*trace_square])'
        after='second = add(mul(det_mean, det_mean), [0*trace_square])'
        self.assertEqual(source.count(before),1)
        script.write_text(source.replace(before,after))
        r=self.run_cli('--verify',HERE/'result.json',script=script)
        self.assertNotEqual(r.returncode,0)


if __name__=='__main__':
    unittest.main(verbosity=2)
