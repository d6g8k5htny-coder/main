"""Exact WP inequality repair candidate; no q0 or status closure.

The interval backend is the repository's certified Fraction implementation.
The Gaussian example is an exact test law, NOT a reconstructed SIDE24 law.
"""
from __future__ import annotations

import argparse
from fractions import Fraction as F
import hashlib
from itertools import combinations, permutations
import json
from math import comb
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
DEFAULT_REPO = Path('/Users/dylanroy/Documents/Codex/research-main')
INTERVAL = None


def require(condition, message):
    if not condition:
        raise ValueError(message)


def fraction(value):
    require(not isinstance(value, (float, bool)), 'inexact or Boolean endpoint')
    return F(value)


def add(a, b):
    out = [F(0)] * max(len(a), len(b))
    for i, x in enumerate(a):
        out[i] += x
    for i, x in enumerate(b):
        out[i] += x
    return out


def scale(a, c):
    return [x*c for x in a]


def mul(a, b):
    out = [F(0)] * (len(a)+len(b)-1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            out[i+j] += x*y
    return out


def evaluate(poly, t):
    result = F(0)
    for coefficient in reversed(poly):
        result = result*t + coefficient
    return result


def determinant(matrix):
    n = len(matrix)
    result = F(0)
    for order in permutations(range(n)):
        inversions = sum(order[i] > order[j] for i in range(n) for j in range(i+1, n))
        term = F((-1)**inversions)
        for i, j in enumerate(order):
            term *= matrix[i][j]
        result += term
    return result


def covariance(matrix):
    require(len(matrix) == 3 and all(len(row) == 3 for row in matrix), '3x3 covariance required')
    result = [[fraction(x) for x in row] for row in matrix]
    require(all(result[i][j] == result[j][i] for i in range(3) for j in range(3)), 'covariance asymmetric')
    for n in range(1, 4):
        for indices in combinations(range(3), n):
            minor = [[result[i][j] for j in indices] for i in indices]
            require(determinant(minor) >= 0, 'covariance not positive semidefinite')
    return result


def gaussian_determinant_moments(mean, beta, sigma):
    """Polynomials E[D|T=t], E[D²|T=t] for H=mean+beta*T+N(0,sigma).

    Coordinates are (Hxx,Hxy,Hyy), D=Hxx*Hyy-Hxy².
    T is standard normal independent of the residual; sigma may be singular.
    """
    require(len(mean) == len(beta) == 3, 'three Hessian means/slopes required')
    means = [[fraction(a), fraction(b)] for a, b in zip(mean, beta)]
    sigma = covariance(sigma)
    B = [[F(0), F(0), F(1, 2)], [F(0), F(-1), F(0)], [F(1, 2), F(0), F(0)]]
    BS = [[sum(B[i][k]*sigma[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
    BSB = [[sum(BS[i][k]*B[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
    trace = sum(BS[i][i] for i in range(3))
    trace_square = sum(BS[i][j]*BS[j][i] for i in range(3) for j in range(3))
    det_mean = add(add(mul(means[0], means[2]), scale(mul(means[1], means[1]), -1)), [trace])
    second = add(mul(det_mean, det_mean), [2*trace_square])
    for i in range(3):
        for j in range(3):
            second = add(second, scale(mul(means[i], means[j]), 4*BSB[i][j]))
    return det_mean, second


def bernstein_range(poly, a, b):
    a, b = fraction(a), fraction(b)
    require(a <= b, 'reversed polynomial interval')
    poly = [fraction(x) for x in poly]
    require(poly, 'empty polynomial')
    n = len(poly)-1
    power = [sum(poly[k]*comb(k, j)*a**(k-j)*(b-a)**j for k in range(j, n+1)) for j in range(n+1)]
    coefficients = [sum(power[j]*F(comb(i, j), comb(n, j)) for j in range(i+1)) for i in range(n+1)]
    return min(coefficients), max(coefficients), coefficients


def cantelli_negative(mean, variance):
    mean, variance = fraction(mean), fraction(variance)
    require(variance >= 0, 'negative determinant variance')
    if variance == 0:
        return F(int(mean < 0))
    if mean <= 0:
        return F(1)
    return variance/(variance+mean*mean)


def load_interval(repo):
    global INTERVAL
    sys.path.insert(0, str(repo))
    import research.interval as backend
    require(Path(backend.__file__).resolve() == (repo/'research/interval/__init__.py').resolve(), 'wrong interval backend')
    INTERVAL = backend


def gaussian_window(mean, sd, lower, upper):
    """Certified upper on Gaussian window mass; sd must be strictly positive.

    Degenerate field-value variances require a separate atom calculation;
    pretending the density formula applies at sd=0 is rejected.
    """
    mean, sd, lower, upper = map(fraction, (mean, sd, lower, upper))
    require(sd > 0, 'strictly positive field-value sd required')
    require(lower <= upper, 'reversed Gaussian window')
    I = INTERVAL.Interval
    distance = max(lower-mean, mean-upper, F(0))
    peak = INTERVAL.exp(I.exact(-distance*distance/(2*sd*sd)), 45) / (I.exact(sd)*INTERVAL.sqrt(2*INTERVAL.pi(45), 45))
    width_density = peak*(upper-lower)
    cdf = INTERVAL.Phi(I.exact((upper-mean)/sd), 45) - INTERVAL.Phi(I.exact((lower-mean)/sd), 45)
    return {
        'distance_to_window': distance,
        'width_density_upper': min(F(1), width_density.hi),
        'cdf_upper': min(F(1), max(F(0), cdf.hi)),
        'probability_upper': min(F(1), width_density.hi, max(F(0), cdf.hi)),
        'probability_lower': max(F(0), cdf.lo),
    }


def generic_cs_upper(second, probability, density=1, normalizer=1):
    second, probability, density, normalizer = map(fraction, (second, probability, density, normalizer))
    require(second >= 0 and density >= 0, 'negative moment or density')
    require(0 <= probability <= 1, 'probability outside [0,1]')
    require(normalizer > 0, 'nonpositive Palm normalizer')
    return INTERVAL.sqrt(INTERVAL.Interval.exact(second*probability), 45) * density / normalizer


def conditional_window_upper(second_sup, probability, density=1, normalizer=1):
    second_sup, probability, density, normalizer = map(fraction, (second_sup, probability, density, normalizer))
    require(second_sup >= 0 and density >= 0, 'negative conditional moment or density')
    require(0 <= probability <= 1, 'probability outside [0,1]')
    require(normalizer > 0, 'nonpositive Palm normalizer')
    return INTERVAL.sqrt(INTERVAL.Interval.exact(second_sup), 45)*probability*density/normalizer


def atom_mass(probabilities, event, weights=None):
    p = [fraction(x) for x in probabilities]
    require(all(x >= 0 for x in p) and sum(p) == 1, 'invalid atom probabilities')
    require(len(event) == len(p), 'event length mismatch')
    w = [F(1)]*len(p) if weights is None else [fraction(x) for x in weights]
    require(len(w) == len(p) and all(x >= 0 for x in w), 'invalid weights')
    normalizer = sum(x*y for x, y in zip(p, w))
    require(normalizer > 0, 'zero atom weight')
    return sum(x*y for x, y, inside in zip(p, w, event) if inside)/normalizer


def outward(value, places=24):
    if hasattr(value, 'lo'):
        lo, hi = value.lo, value.hi
    else:
        lo = hi = fraction(value)
    unit = 10**places
    floor = (lo*unit).numerator // (lo*unit).denominator
    ceil = -((-hi*unit).numerator // (-hi*unit).denominator)
    return {'lo': str(F(floor, unit)), 'hi': str(F(ceil, unit))}


def digest(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def verify_bindings(repo):
    bindings = json.loads((HERE/'DEPENDENCIES.json').read_text())
    for path, identity in bindings['repository_files'].items():
        require(digest(repo/path) == identity, 'repository dependency mismatch: '+path)
    for path, identity in bindings['local_files'].items():
        require(digest(HERE/path) == identity, 'source dependency mismatch: '+path)
    return bindings


def build_report(repo):
    bindings = verify_bindings(repo)
    load_interval(repo)
    mean, beta = [F(2), F(0), F(1)], [F(1), F(1, 2), F(-1, 3)]
    residual = [[F(int(i == j)) for j in range(3)] for i in range(3)]
    mean_poly, second_poly = gaussian_determinant_moments(mean, beta, residual)
    a, b = F(-1, 100), F(1, 100)
    poly_lo, poly_hi, bernstein = bernstein_range(second_poly, a, b)
    unconditional_cov = [[residual[i][j]+beta[i]*beta[j] for j in range(3)] for i in range(3)]
    unmean, unsecond = gaussian_determinant_moments(mean, [0, 0, 0], unconditional_cov)
    det_variance = unsecond[0]-unmean[0]*unmean[0]
    type_cap = cantelli_negative(unmean[0], det_variance)
    window = gaussian_window(0, 1, a, b)
    generic = generic_cs_upper(unsecond[0], min(type_cap, window['probability_upper']))
    linear = conditional_window_upper(poly_hi, window['probability_upper'])
    require(generic.lo > 10*linear.hi, 'Gaussian example expected strict improvement lost')
    require(poly_lo > 0, 'conditional moment lower unexpectedly nonpositive')
    p, root_p = F(1, 16), F(1, 4)
    actual, invalid, repaired = p, root_p*p, root_p*root_p
    require(actual > invalid and repaired == actual, 'missing-square-root counterexample failed')
    same_events = [True, False]
    pa = atom_mass([p, 1-p], same_events)
    good = atom_mass([p, 1-p], [False, False])
    false_product = pa*(1-pa)
    require(good < false_product, 'marginal-product counterexample failed')
    tilted = atom_mass([F(1, 100), F(99, 100)], same_events, [100, 1])
    require(tilted == F(100, 199) and tilted > F(1, 2), 'Palm law mismatch example failed')
    # A shrinking Gaussian variance defeats an ell-only rate claim.
    ell = F(1, 6*100**3)
    shrinking_variance = gaussian_window(0, ell, 0, ell)
    require(shrinking_variance['probability_lower'] > F(1, 3), 'shrinking-variance counterexample failed')
    return {
        'schema': 'Q0_WP_EVENT_REPAIR_V1',
        'project': 'wp_event',
        'target': 'Q0-P12-WP-EVENT-20260920-v1',
        'status': 'PROVED_CONDITIONAL_LEMMAS_AND_EXACT_COUNTEREXAMPLES',
        'generic_inequality': 'p_G/Z * sqrt(E[W^2 D^2|G]) * sqrt(min(P(D<0|G),P(X in I|G)))',
        'conditional_window_inequality': 'p_G/Z * sup_{x in I} sqrt(E[W^2 D^2|G,X=x]) * P(X in I|G)',
        'gaussian_window_density_bound': 'min(1, |I|/(sigma*sqrt(2*pi))*exp(-dist(mu,I)^2/(2*sigma^2)))',
        'cantelli': 'Var(D)/(Var(D)+E(D)^2) when E(D)>0; 1 otherwise (deterministic sign handled exactly)',
        'exact_counterexamples': {
            'missing_sqrt': {'p': str(p), 'E_D_squared': str(p), 'actual': str(actual), 'invalid_bound': str(invalid), 'valid_bound': str(repaired)},
            'marginal_product': {'P_A': str(pa), 'P_B': str(pa), 'P_A_and_not_B': str(good), 'invalid_lower': str(false_product)},
            'wrong_Palm_law': {'ordinary_P_bad': '1/100', 'weight_on_bad': '100', 'weight_elsewhere': '1', 'weighted_P_bad': str(tilted)},
            'shrinking_Gaussian_variance': {'sigma': 'ell=r^3/6', 'window': '[0,ell]', 'probability': 'Phi(1)-1/2 > 1/3 for every r>0', 'reason': 'window width alone supplies no cubic probability bound'},
        },
        'exact_gaussian_test_law_NOT_SIDE24': {
            'X': 'standard normal', 'H_mean': list(map(str, mean)), 'H_slope_in_X': list(map(str, beta)),
            'residual_covariance': [[str(x) for x in row] for row in residual],
            'window': [str(a), str(b)],
            'determinant_mean_polynomial': list(map(str, mean_poly)),
            'determinant_second_moment_polynomial': list(map(str, second_poly)),
            'second_moment_Bernstein_coefficients': list(map(str, bernstein)),
            'conditional_second_moment_range': [str(poly_lo), str(poly_hi)],
            'unconditional_D_mean': str(unmean[0]), 'unconditional_D_second_moment': str(unsecond[0]),
            'unconditional_D_variance': str(det_variance), 'Cantelli_upper': str(type_cap),
            'window_probability': {'lo': outward(window['probability_lower'])['lo'], 'hi': outward(window['probability_upper'])['hi']},
            'generic_CS_upper_expression_enclosure': outward(generic),
            'conditional_window_upper_expression_enclosure': outward(linear),
            'certified_improvement_factor_strictly_greater_than': '10',
        },
        'uniform_rate_lemma': {
            'assumptions': 'weighted Kac-Rice; X variance positive a.e.; integrable conditional moment envelope B; sup_r integral(p_G*B/(Z*sigma*sqrt(2*pi))) <= C',
            'conclusion': 'E_Palm[N_window_saddles] <= C*ell = (C/6)*r^3',
            'absolute_loss': 'F contains A\\B and B contained in {N>=1}; P_Palm(A)>=a*r^3 implies P_Palm(F)>=(a-C/6)*r^3, useful only when a>C/6',
            'conditional_loss': 'if P_Palm(B|A)<=beta<1 under the same law, P_Palm(F)>=P_Palm(A)*(1-beta)',
            'minimal_rate_is_context_dependent': True,
        },
        'remaining_obligations': [
            'Actual q0 event inclusion F_r containing A_r minus the WP obstruction, including topology and eta_r transfer.',
            'Actual SIDE24 six-pin typed pair-Palm normalizer, joint conditional Gaussian law and weights.',
            'Uniform spatial integrability of p_G B/(Z sigma), including singular pin charts and all omitted regions.',
            'Lambda mass and coefficient margin in the matching Palm law; no lower assembly successor is supplied.',
            'External mathematical review and organizational independence.',
        ],
        'source_bindings': bindings['local_files'],
        'backend_bindings': bindings['repository_files'],
        'scientific_status_changed': False,
        'q0_closed': False,
        'original_prize_closed': False,
        'external_independence_credit': 0,
    }


def encoded(report):
    return (json.dumps(report, indent=2, sort_keys=True)+'\n').encode()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=DEFAULT_REPO)
    parser.add_argument('--verify', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    try:
        repo = args.repo.resolve()
        output = args.output.resolve() if args.output else None
        if output:
            require(not output.exists(), 'output exists; refusing overwrite')
            require(not output.is_relative_to(repo), 'refusing repository write')
            require(output.parent.is_dir(), 'output parent missing')
        report = encoded(build_report(repo))
        if args.verify:
            require(args.verify.read_bytes() == report, 'certificate differs from exact recomputation')
        if output:
            with output.open('xb') as handle:
                handle.write(report)
        print('WP event repair PASS: exact square-root and conditioning-first lemmas; q0 remains open')
    except (ValueError, OSError, KeyError, ZeroDivisionError) as error:
        print('WP event repair FAIL: '+str(error), file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
