# WP square-root repair and a conditional linear-window replacement

Target `Q0-P12-WP-EVENT-20260920-v1`; author-side mathematical candidate.
The results below are conditional lemmas and exact counterexamples. They do
not establish a SIDE24 numerical WP bound, a q0 lower assembly, or a change
of any scientific status. Organizational independence credit is zero.

## 1. Source boundary and the event identity that must be supplied

The exact active-source bytes are identified in `SOURCES.json` and
`DEPENDENCIES.json`. GP-LB-STAT-003, Drive
`11-H0mx2obq_wN7YYH0tL0BABlS-Nxm6y`, was read before the conflicting
KIMI-DER-025 numerical claims. The former explicitly identifies the missing
square root and says that the corpus has not yet supplied the event-level
formula deciding the WP target rate. KIMI-DER-025, Drive
`1QqLjDhYopotMbDTQ52f3SJgAWHgCvGNa`, supplies the historical window-saddle
definition; none of its numerical values, quadrature claims or certifications
is used here. The source code in that report was not executed.

Here is the exact probability identity, with its hypotheses exposed. Under
one probability law P, let F be the desired failure event, A a proposed
Lambda witness event, and B its WP obstruction. If

    A \ B is a subset of F,                                      (E)

then, without independence,

    P(F) >= P(A \ B) = P(A) - P(A intersect B).

If N is a nonnegative integer-valued WP count and
`A intersect B subset {N>=1}`, then

    P(F) >= P(A) - E[N].                                        (1)

The stronger assumption `B subset {N>=1}` also suffices. If P(A)>0 and
`A intersect B subset A intersect {N>=1}`, conditioning gives

    P(F) >= P(A) [1 - P(B|A)] >= P(A) [1 - E[N|A]].             (2)

Equations (1) and (2) are consequences of (E), not a proof of (E) for q0.
The actual topology, witness multiplicity, matching Palm law and eta_r
transfer still have to establish that inclusion and identify this N.

For P(A)>=a r^3, an absolute bound E[N]<=c r^3 yields
`P(F)>=(a-c)r^3`, useful when `c<a`. An `o(r^3)` absolute loss preserves
the leading lower coefficient. A conditional bound `P(B|A)<=beta<1`
instead gives the positive coefficient `a(1-beta)`; a conditional `o(1)`
loss preserves a. These statements do not require either structure to be
the correct SIDE24 structure. They show exactly why the minimal requested
rate depends on the unproved event identification.

**Counterexample to a marginal product:** let A=B have probability 1/16.
Then P(A\B)=0, while P(A)(1-P(B))=15/256. The example works with
P(A)=P(B)=r^3 for every 0<r<1: a vanishing marginal obstruction does not
imply a small conditional obstruction.

## 2. Weighted Kac-Rice and the correct Cauchy-Schwarz inequality

Fix a base conditional Gaussian law Q (for example, the unweighted six-pin
law at a positive radius where it is defined). Let W>=0 be an integrable
weight with Z=E_Q W>0, and set `dP = W dQ/Z`. In the application W may
include the two marked Hessian determinants and their typing indicators.
This tilt is part of the definition of the pair-Palm law; it is not an
independence assumption. It does not leave the field Gaussian.

For a spatial point y write G_y=`grad f(y)=0`, X=f(y), D=det H_y, and
I=(b-ell,b). Assume the weighted Kac-Rice identity is valid on a measurable
region Omega, with the required nondegeneracy and integrability:

    E_P N = (1/Z) integral_Omega p_grad,y(0)
              E_Q[W |D| 1_{D<0} 1_{X in I} | G_y] dy.          (KR)

This is an explicit hypothesis, not a claim that singular pin charts or
the full SIDE24 region have been covered. All expectations and probabilities
on the right remain under the *base* conditional law Q. Write A_y for
`{D<0, X in I}`, and M2=E_Q[W^2 D^2|G_y]. Conditional Cauchy-Schwarz gives

    E_Q[W |D| 1_A_y | G_y] <= sqrt(M2) sqrt(Q(A_y|G_y))
       <= sqrt(M2) sqrt(min(Q(D<0|G_y), Q(X in I|G_y))).         (3)

There is no independence step. The gradient density and the same Z from
(KR) must multiply/divide this expression. Setting W=1 yields precisely
the corrected ordinary intensity inequality in GP-LB-STAT-003. If one
instead chooses to apply Cauchy-Schwarz under P, then both its second moment
and event probability must be under P; the Gaussian window formula cannot
silently be used for a non-Gaussian weighted marginal.

**Sharp square-root counterexample:** take D=-1 on an event of probability
1/16 and D=0 elsewhere, and let that event be A_y. Then M2=1/16 and the
left side is 1/16. The correct right side is 1/16. Omitting the outer
probability square root produces 1/64, which is false as an upper bound.
This elementary probability-law counterexample refutes the alleged generic
inequality; it is not claimed to be a SIDE24 field counterexample.

**Palm-law counterexample:** let Q(B)=1/100, W=100 on B and W=1 elsewhere.
Then Z=199/100 and P(B)=100/199>1/2. The ordinary probability 1/100 cannot
be used as the weighted probability. The exact values are replayed.

For the type probability under Q, let m=E_Q[D|G_y] and v=Var_Q(D|G_y).
When m>0, Cantelli gives `Q(D<0|G_y)<=v/(v+m^2)`. Indeed for t>=0,
the event D-m<=-m implies `(D-m-t)^2 >= (m+t)^2`, so its probability is
at most `(v+t^2)/(m+t)^2`; t=v/m yields the claim. When m<=0, use 1
unless v=0, in which case D=m almost surely and the strict sign is known.
Using v/(v+m^2) for a negative m is unsupported and is refused by the
implementation's branch test.

## 3. Conditioning first restores a linear window factor

Assume X|G_y is Gaussian with mean mu and strictly positive standard
deviation sigma, and that regular conditional second moments exist.
Choose a measurable envelope

    B_y >= ess sup_{x in I} sqrt(E_Q[W^2 D^2 | G_y,X=x]).

Disintegrate in X *before* applying Cauchy-Schwarz. For almost every x,

    E_Q[W |D| 1_{D<0} | G_y,X=x]
       <= sqrt(E_Q[W^2 D^2 | G_y,X=x]) <= B_y.

Multiplying by the Gaussian conditional density and integrating yields

    E_Q[W |D| 1_{D<0} 1_{X in I} | G_y]
       <= B_y Q(X in I|G_y).                                  (4)

Thus (4) legitimately has the *linear* window probability that was missing
from the old argument. Its moment is a uniform moment conditional on X
inside the window, not the old unconditional moment M2. Substituting M2
for B_y^2 without a proof would repeat a different invalid step.

For `d=dist(mu,[b-ell,b])`, Gaussian density monotonicity gives

    Q(X in I|G_y) <= min(1, ell/(sigma sqrt(2 pi))
                                  exp(-d^2/(2 sigma^2))).      (5)

The nearest point in the entire window determines d. If mu is inside the
window, d=0; a distance from mu to only its upper endpoint is not valid.
The checker also computes the exact-endpoint interval CDF difference and
uses the smaller certified upper bound. If sigma=0, this density argument
is inapplicable; the implementation refuses it. One would need a separate
atomic conditional-law argument.

**Uniform integration lemma.** Assume (KR), (4) and sigma>0 for almost
every y, and suppose the exact radius-uniform integrability condition

    sup_{0<r<=r0} integral_Omega_r
          p_grad,y(0) B_{r,y}/(Z_r sigma_{r,y} sqrt(2 pi)) dy
       <= C < infinity.                                      (U)

Then `E_P N <= C ell = (C/6)r^3` when ell=r^3/6. This is immediate from
(KR), (4), (5), Tonelli and (U). The exponential in (5) can improve the
integral; (U) deliberately uses the weaker factor 1. On a regular cell of
area at most V with p_grad<=g0, B<=B0, Z>=z0>0 and sigma>=s0>0, that
cell contributes at most `V g0 B0/(z0 s0 sqrt(2 pi))` to C.

These are sufficient criteria, not certificates that SIDE24 satisfies them.
In particular a normalizer shrinking like r^2 may require matching decay
of the weighted moment; singular pin neighborhoods need their own chart.
The generic inequality (3) alone with bounded M2 and window mass O(ell)
only supplies O(sqrt(ell))=O(r^(3/2)), which is too weak for an absolute
loss from an r^3 mass.

**Counterexample to width-only uniformity:** take X_r=ell Z0 for standard
normal Z0 and I_r=[0,ell], ell=r^3/6. Then
`P(X_r in I_r)=Phi(1)-1/2>1/3` for every r>0. The checker certifies the
last rational inequality. Shrinking window width alone proves no cubic
rate when conditional variance shrinks at the same scale.

## 4. Exact Gaussian Hessian second-moment envelope

The following specialization computes B when W=1, and provides a reusable
building block for actual law-specific input. It is not a weighted
SIDE24 moment certificate. A nontrivial W needs the corresponding higher
conditional Gaussian polynomial moment or another justified envelope.

Write h=(Hxx,Hxy,Hyy) and

    J = [[0,0,1/2], [0,-1,0], [1/2,0,0]],   D=h^T J h.

If h|T=t is Gaussian with affine mean m(t)=a+beta t and constant positive
semidefinite covariance S, then

    d(t)=E[D|T=t] = m(t)^T J m(t) + tr(J S),

    Q(t)=E[D^2|T=t]
        = d(t)^2 + 2 tr(J S J S) + 4 m(t)^T J S J m(t).       (6)

To prove (6), expand h=m+z. The centered linear and centered quadratic
terms have zero covariance by odd Gaussian moments. The linear variance
is `4 m^T J S J m`. Isserlis' three pairings of four centered factors
give variance `2 tr(J S J S)` for the quadratic term. The mean supplies
the d(t)^2 term. This argument allows singular S by a linear image of
independent normals or by continuity. Q has degree at most four.

For an exact polynomial Q on [a,b], set t=a+(b-a)u. If its power
coefficients in u are c_j and degree n, its Bernstein coefficients are

    beta_i = sum_{j<=i} c_j * binom(i,j)/binom(n,j).

The identity between the two bases follows by the binomial theorem.
Bernstein basis functions are nonnegative and sum to one on [0,1].
Consequently `min_i beta_i <= Q(t) <= max_i beta_i` over the *whole*
interval, including an interior maximum. The checker uses these exact
Fraction coefficients, not a grid. It verifies S is symmetric positive
semidefinite by all principal minors, which characterizes that property
for a real symmetric matrix.

The exact test law is T=X~N(0,1), residual S=I3 independent of T,
`a=(2,0,1)`, `beta=(1,1/2,-1/3)`, and I=[-1/100,1/100]. Formula (6) gives

    d(t) = 1+t/3-7t^2/12,
    Q(t) = 9+4t+19t^2/18-7t^3/18+49t^4/144.

The Bernstein upper is exactly `130177514449/14400000000`.
The unconditional determinant second moment is 1595/144, its mean 5/12,
its variance 785/72, and the Cantelli cap is 314/319. The generic
Cauchy-Schwarz upper is enclosed near 0.29727987472 and the conditioning-
first upper near 0.02398940988. Exact rational interval endpoints in
`result.json` prove a factor strictly greater than 10 between these upper
expressions. This compares bounds on this *test law*, not an actual WP
intensity, and is not a numerical SIDE24 improvement claim.

## 5. Replay, adversaries and remaining work

`wp_event.py` verifies source and interval-backend hashes, recomputes all
certificate fields using exact Fraction arithmetic and the repository
interval functions, and rejects byte-different certificates. It refuses
overwriting an output and any output inside the repository. `RUN.json`
contains replay commands. Tests verify (6) against a separate noncentral
Wick recursion, the exact Gaussian tower identity, covariance and
degeneracy guards, Cantelli sign, interior polynomial maxima, the four
counterexamples and genuine mutated CLI executions. The same tests run
under normal Python and `-O`; no production guard relies on `assert`.

What remains is the actual q0 event inclusion and eta_r identification,
the matching typed pair-Palm law and normalizer, actual uniform conditional
weighted moments and spatial enclosures including pin singularities,
Lambda coefficient margin, and independent mathematical review. This is
an inequality-repair module, not a replacement lower assembly. The three-
dimensional lifetime track is not used and no prize problem is implicated.
