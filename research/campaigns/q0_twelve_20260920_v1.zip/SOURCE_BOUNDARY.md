# Source eligibility correction

During this campaign the original local snapshot helper materialized Drive
object `1hnd7jbFwcCQIuOcbrzilMQoymsOzFQZb`, titled `verify_lambda_grid_v2.py`,
SHA256 `579ef6cd88d543ec14db45558e5e7c1899078095e0df295c7d46fd1810273831`.
It sits beneath the active-package tree but its nested folder is
`RECOVERED_OUTSIDE_K3_QUARANTINE` and both inventory and coverage metadata label
it `QUARANTINE_OR_HISTORY`. The original helper checked specific forbidden
folders and individual exclusion entries, but missed that context. The artifact
was exposed before this was caught, including a short inert excerpt read by
project 10. No source code was executed.

This recovered script is excluded from the mathematical evidence, candidate
bundle, replay plan and repository dependency set. Its local scratch snapshot
is retained only as incident history, not silently recategorized or deleted.
Project 10 derives its results from the permitted DER-027b definition and active
adjudication; its proof does not certify or refute the recovered implementation.

`read_source_v2.py` requires `RESEARCH_SOURCE_CHECK_STATUS` in both inventory and
coverage metadata and rejects any legacy, quarantine or vault path before body
access. Payload exclusions are now also checked before the read. The old helper
is not used for subsequent reads and is not delivered as an approved reader.
`SOURCE_GUARDS.json` records live rejection of the problematic object in normal
and optimized Python, without creating an output directory, plus a successful
byte-identical permitted-source replay.

All other initially prepared shared-source identities were individually reviewed
at metadata level and have the permitted research context. Source status still
requires reading the corresponding adjudication; an eligible file is not an
endorsed theorem. Native DOCX exports and derived readings are identified
separately, never equated to a printed frozen-body hash.
