"""Independent exact moment identities and adversarial CLI certificate checks."""
from fractions import Fraction as F
import copy
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('candidate',HERE/'check_ceiling.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
I=c.I

class MomentTests(unittest.TestCase):
    def test_standard_gaussian_even_moments(self):
        for n,expected in [(0,1),(2,1),(4,3),(6,15),(8,105)]:
            self.assertIn(F(expected),c.gaussian_moment((I.exact(0),),((I.exact(1),),),(0,)*n))
    def test_noncentral_gaussian_fourth(self):
        self.assertIn(F(475),c.gaussian_moment((I.exact(2),),((I.exact(9),),),(0,)*4))
    def test_correlated_pair_fourth(self):
        cov=((I.exact(2),I.exact(-1)),(I.exact(-1),I.exact(3)))
        self.assertIn(F(8),c.gaussian_moment((I.exact(0),)*2,cov,(0,0,1,1)))
    def test_mixed_noncentral_wick_against_formula(self):
        mu=tuple(map(I.exact,(2,-3,1)))
        cov=tuple(tuple(map(I.exact,row)) for row in ((5,-1,2),(-1,3,1),(2,1,4)))
        expected=c.fourth_formula(mu,cov,0,1,2)
        got=c.rnd(c.gaussian_moment(mu,cov,(0,0,1,1))-2*c.R*c.gaussian_moment(mu,cov,(0,1,2,2))+c.R**2*c.gaussian_moment(mu,cov,(2,2,2,2)))
        self.assertEqual(expected,got)
        wrong=c.rnd(c.gaussian_moment(mu,cov,(0,0,1,1))+2*c.R*c.gaussian_moment(mu,cov,(0,1,2,2))+c.R**2*c.gaussian_moment(mu,cov,(2,2,2,2)))
        self.assertIsNone(wrong.intersect(expected))
    def test_half_gaussian_zero_threshold(self):
        h=c.half_moments(I.exact(0));phi=c.normal_pdf(I.exact(0),c.PREC)
        for n,expected in [(0,F(1,2)),(2,F(1,2)),(4,F(3,2))]:self.assertIn(expected,h[n])
        self.assertIsNotNone(h[1].intersect(-phi));self.assertIsNotNone(h[3].intersect(-2*phi))
        self.assertLess(h[1].hi,0);self.assertLess(h[3].hi,0)
        self.assertIsNone((-h[1]).intersect(-phi))
    def test_half_gaussian_nonzero_threshold(self):
        h=c.half_moments(I.exact(1));phi=c.normal_pdf(I.exact(1),c.PREC)
        self.assertIsNotNone(h[2].intersect(h[0]-phi))
        self.assertIsNotNone(h[4].intersect(3*h[0]-4*phi))
    def test_independent_regression_half_moments(self):
        mu=(I.exact(0),)*6;cov=tuple(tuple(I.exact(int(i==j)) for j in range(6)) for i in range(6))
        f,_=c.restricted_moment_factory(mu,cov)
        for indices,expected in [((),F(1,2)),((0,0),F(1,2)),((1,1),F(1,2)),((0,0,1,1),F(1,2)),((1,1,1,1),F(3,2))]:self.assertIn(expected,f(indices))
        self.assertIn(F(0),f((1,)))
    def test_cs_exact_case(self):
        self.assertIn(F(6),c.ceiling_from_moments(I.exact(4),I.exact(9)))
        with self.assertRaises(ValueError):c.ceiling_from_moments(I(-1,1),I.exact(9))
    def test_historical_mills_float_underflow_counterexample(self):
        proof=c.historical_tail_counterexample()
        self.assertGreater(proof['positive_cdf_lower'],0)
        self.assertLess(proof['cdf_upper'],proof['half_smallest_binary64_subnormal'])
        self.assertFalse(proof['historical_source_executed'])
    def test_raw_determinant_scale(self):
        c.scale_identity(c.R**2)
        with self.assertRaises(ValueError):c.scale_identity(F(1))

class CLITests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory(prefix='tests-',dir=HERE);cls.folder=Path(cls.temp.name)
        cls.checker=HERE/'check_ceiling.py';cls.serial=0
        cls.baseline=cls.folder/'baseline.json'
        result=subprocess.run([sys.executable,'-B',str(cls.checker),'--output',str(cls.baseline)],capture_output=True,text=True)
        if result.returncode!=0:raise RuntimeError(result.stderr)
        cls.original=json.loads(cls.baseline.read_text())
    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()
    def run_cli(self,*args,opt=False):
        type(self).serial+=1
        out=self.folder/('out-'+str(self.serial)+'.json')
        argv=[sys.executable,'-B']+(['-O'] if opt else [])+[str(self.checker),'--output',str(out),*args]
        return subprocess.run(argv,capture_output=True,text=True),out
    def test_normal_and_optimized_exact_replay(self):
        for opt in (False,True):
            r,out=self.run_cli('--certificate',str(self.baseline),opt=opt)
            self.assertEqual(r.returncode,0,r.stderr);self.assertEqual(out.read_bytes(),self.baseline.read_bytes())
    def test_real_mathematical_mutations_rejected_both_modes(self):
        for mutation in ('too_small_cap','wrong_cross','wrong_scale'):
            for opt in (False,True):
                r,out=self.run_cli('--mutation',mutation,opt=opt)
                self.assertNotEqual(r.returncode,0,mutation);self.assertFalse(out.exists());self.assertIn('FAIL',r.stderr)
    def test_stored_certificate_mutations_fail_closed(self):
        changes=[('all_small_r_certified',True),('external_independence_credit',False),('scientific_status_changed',0),('safe_decimal_typed_ceiling','3'),('historical_uniform_ceiling_replayed',True)]
        for key,value in changes:
            item=copy.deepcopy(self.original);item['payload'][key]=value
            item['payload_sha256']=c.sha(c.canonical(item['payload']))
            path=self.folder/(key+'.json');path.write_text(json.dumps(item))
            for opt in (False,True):
                r,out=self.run_cli('--certificate',str(path),opt=opt)
                self.assertNotEqual(r.returncode,0,key);self.assertFalse(out.exists())
    def test_requested_too_small_cap_fails(self):
        r,out=self.run_cli('--cap','3');self.assertNotEqual(r.returncode,0);self.assertFalse(out.exists())
    def test_reused_output_refused(self):
        r=subprocess.run([sys.executable,'-B',str(self.checker),'--output',str(self.baseline)],capture_output=True,text=True)
        self.assertNotEqual(r.returncode,0);self.assertEqual(json.loads(self.baseline.read_text()),self.original)

if __name__=='__main__':unittest.main()
