# H3 fixed-radius ceiling and historical tail-conversion counterexample

Author-side mathematical candidate, 2026-09-20. R17 target
`Q0-P12-H3-CEILING-20260920-v1`, claim
`b66c025c-7ed6-4f08-90a5-6755bbe1b433`. No scientific status changes,
no external independence credit, no original prize closure.

## Result

For the normalized two-dimensional SIDE24 Gaussian field, at exactly
`r = 1/20` and `b = 6/5`, with the six pins below, the typed normalizer satisfies

\[
0\le Z_{1/20}/(1/20)^2\le 3.230674239349,
\qquad Z_{1/20}\le 0.0080766855983725.
\]

These decimals are exact rationals rounded **up** from certified rational
interval upper endpoints. This is a new fixed-radius proof. It improves on the
historical uniform ceiling `3.74767948915996` at this one radius. It neither
proves nor disproves that constant uniformly for `0 < r <= 1/20`.

The proof also gives a reusable analytic upper-bound formula for any radius at
which the same Gaussian law is established. A uniform enclosure of that law is
still needed to obtain a uniform numerical bound.

## Law and determinant scaling

Write `M=(-r/2,0)`, `S=(r/2,0)`. The actual observations are

\[
(f_M,f_{x,M},f_{y,M},f_S,f_{x,S},f_{y,S})
 =(b,0,0,b-r^3/6,0,0).
\]

The invertible conditioning transform used by the checker is

\[
V=(f_M,f_{x,M},f_{y,M},(f_{x,S}-f_{x,M})/r,
(f_{y,S}-f_{y,M})/r,
(f_S-f_M)/r^3-(f_{x,S}+f_{x,M})/(2r^2)),
\]

with exact value `(b,0,0,0,0,-1/6)`. The checker tests the inverse transform
against the original observations, and reconstructs all covariance entries
from derivatives of the full normalized periodized kernel

\[
K(x)=k(x_1)k(x_2),\qquad
k(s)=\frac{\sum_{j\in\mathbb Z}e^{-(s+24j)^2/2}}
{\sum_{j\in\mathbb Z}e^{-(24j)^2/2}}.
\]

The repository kernel includes explicit omitted-image tails and normalization;
its `source_binding()` verifies the exact RN5 carrier and member identities.
No frozen code is executed. The kernel is the covariance of the Gaussian
field; its positive Fourier weights give the positive semidefinite joint law.
Positive interval LDL pivots are checked for the six conditioning variables
and six conditional soft variables.

Use the soft order `(q_M,q_S,alpha_M,alpha_S,beta_M,beta_S)`, where
`q=f_yy`, `alpha=f_xx/r`, `beta=f_xy/r`. Then

\[
D_i=\alpha_i q_i-r\beta_i^2,\qquad
\det H_i=rD_i.
\]

Thus the source normalizer is

\[
Z_r=r^2\mathbb E[|D_MD_S|\,1_T],
\quad T=\{q_M<0,D_M>0,D_S<0\}.
\]

`T` is precisely maximum typing at M and saddle typing at S: for a real
symmetric 2-by-2 Hessian, `q_M<0` and positive determinant imply negative
definiteness. The determinant scale is checked coefficient by coefficient;
the factor `r^2` cannot be dropped.

## Upper bound without rare-event corrections

Let `A={q_M<0}`. Since `T` is a subset of `A`, nonnegativity and
Cauchy–Schwarz give

\[
\frac{Z_r}{r^2}
\le \mathbb E[|D_MD_S|1_A]
\le \sqrt{\mathbb E[D_M^2 1_A]\;\mathbb E[D_S^2 1_A]}.
\]

No independence is assumed between the determinants. Omitting `1_A` gives a
second, weaker bound used as a consistency comparison. Both square moments
are quartic polynomials in the six jointly Gaussian coordinates. In
particular,

\[
\mathbb E[D_i^2 1_A]=
\mathbb E[\alpha_i^2 q_i^2 1_A]
-2r\mathbb E[\alpha_i q_i\beta_i^2 1_A]
+r^2\mathbb E[\beta_i^4 1_A].
\]

The minus sign and coefficient two matter. A mutation reversing that sign is
rejected against a separately expanded noncentral fourth-moment formula.

## Exact halfspace moments

Let `X` denote the six-dimensional conditional Gaussian vector, with mean
`mu` and covariance `Sigma`. Put `sigma=sqrt(Sigma_00)>0` and write

\[
X_i=\mu_i+\frac{\Sigma_{i0}}{\sigma}U+\xi_i,
\quad U\sim N(0,1),\quad
\operatorname{Cov}(\xi_i,\xi_j)=
\Sigma_{ij}-\frac{\Sigma_{i0}\Sigma_{0j}}{\Sigma_{00}}.
\]

The residual vector is independent of `U`; the identity follows from Gaussian
regression, including the degenerate zero residual of coordinate zero. The
condition `q_M<0` becomes `U<h=-mu_0/sigma`.

For a Gaussian with affine means `m_i(u)=mu_i+(Sigma_i0/sigma)u`, conditional
moments obey the exact noncentral Wick recurrence

\[
W(i,j_1,\ldots,j_n;u)=m_i(u)W(j_1,\ldots,j_n;u)
+\sum_{k=1}^n C_{i j_k}W(j_1,\ldots,\widehat j_k,\ldots,j_n;u).
\]

This produces polynomials of degree at most four in `u`. Integrate each
coefficient using

\[
M_0(h)=\Phi(h),\quad M_1(h)=-\phi(h),\quad
M_n(h)=-h^{n-1}\phi(h)+(n-1)M_{n-2}(h).
\]

These are the exact integrals from negative infinity to `h`; no finite cutoff
or discarded tail is present. Repository certified `Phi`, `normal_pdf`, and
`sqrt` return rational enclosures. Every other operation is exact rational
interval arithmetic with outward binary rounding to 256 bits. Interval
correlation loss can enlarge a result but cannot invalidate containment.

At the fixed radius, upward rounded displays of the square moments are

| Moment | Certified upper display |
|---|---:|
| `E[D_M^2 1_A]` | 3.259953470949136 |
| `E[D_S^2 1_A]` | 3.201657978803568 |
| `E[D_M^2]` | 3.483478471770983 |
| `E[D_S^2]` | 3.397102687896412 |

The full Gaussian Cauchy–Schwarz ceiling is `3.440019488271`; the halfspace
ceiling is `3.230674239349`. The checker proves that the latter interval lies
strictly below the former. All exact enclosures appear in `result.json`.

## Why the historical uniform ceiling is not accepted by this replay

The historical proof describes a Laurent-series/Neumann pipeline covering
seven radius cells. This candidate does not execute or reconstruct that
pipeline, so it does not license its all-radius claim. In addition, the
historical tail-conversion step has a concrete enclosure defect.

In the exact source `h3_band_ceil.py`, `iv_Phi` lines 448–455 converts the
Gordon–Mills lower and upper tail endpoints to ordinary binary64 `float`
before constructing an interval. At `x=-40`, the exact Mills inequalities are

\[
0<\phi(40)(1/40-1/40^3)<\Phi(-40)<\phi(40)/40<2^{-1075}.
\]

The final inequality is verified using the repository's rational interval
normal density; its witness is retained in the report. Both positive
endpoints round to binary64 zero, whose interval `[0,0]` excludes the strictly
positive probability. The accompanying direct float-conversion demonstration
is labeled NON-CERTIFYING; exact rational inequalities supply the witness.
This is a counterexample to the endpoint-conversion step's enclosure
contract. Historical source text is inspected and hashed, never executed.

Consequently, a corrected band replay must preserve positive tails using
outward interval endpoints. This finding does **not** show that the final
historical ceiling is false: other slack might absorb the lost terms. Neither
source grade nor register status is changed here.

## Validation and delivery

`check_ceiling.py` reconstructs the law, square moments, tail counterexample,
and exact coefficient; `--certificate result.json` requires identical typed
canonical JSON and rehashes all loaded repository Python dependencies before
and after computation. Optimized and normal interpreter reports agree byte
for byte. `test_ceiling.py` exercises exact Gaussian moments, correlated and
noncentral moments, halfspace recurrences, regression, the tail-conversion
counterexample, determinant scaling, and meaningful CLI mutations. A false
uniform claim, altered ceiling, forged independence value, or bool/integer
status alias is rejected even when the attacker recomputes the payload hash.

The scope remains fixed `r=1/20`, the stated six pins, two dimensions, and the
stated source law. No all-small-r theorem, RN uniform lemma, H5 obligation,
external independent review, source-status promotion, or original prize claim
is closed. Normalizer lower bounds are a separate project.
