#!/usr/bin/env python3
"""Certified fixed-r H3 upper candidate. No uniform-r or scientific promotion."""
from __future__ import annotations
import argparse
from functools import lru_cache
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
import sys

HERE=Path(__file__).resolve().parent
DEFAULT_REPO=Path('/Users/dylanroy/Documents/Codex/research-main')
early=argparse.ArgumentParser(add_help=False)
early.add_argument('--repo',type=Path,default=DEFAULT_REPO)
REPO=early.parse_known_args()[0].repo.resolve()
sys.dont_write_bytecode=True
sys.path.insert(0,str(REPO))
from research.interval import Interval as I, sqrt, Phi, normal_pdf
from research.rn import side24
from research.rn.conditioning import condition_gaussian, interval_ldlt
BITS,PREC=256,104
R,HEIGHT=F(1,20),F(6,5)
SOURCE_HASHES={'H3_BAND_CEIL.md':'18e109bc2e7a186c307f689f940ad476d69fc543e828081e0e706de2c578800d','h3_band_ceil.py':'b97c5428a20e5dd33f3e53653d20447f1e27515dcc7dc7a7c2004ebe30029452'}


def need(x,message):
    if not x: raise ValueError(message)

def sha(b):return hashlib.sha256(b).hexdigest()
def rnd(x):return x.round_out(BITS)
def enc(x):
    if isinstance(x,I):return {'lo':str(x.lo),'hi':str(x.hi)}
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {str(k):enc(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [enc(v) for v in x]
    return x

def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()

def source_binding():
    exclusions=json.loads((REPO/'quarantine/EXCLUSIONS.json').read_text())['exclusions']
    for name,digest in SOURCE_HASHES.items():
        need(not any(e.get('payload_sha256')==digest or e.get('member_path')=='K3_SIDE24_LB/UPPER2D/H3_closure/'+name for e in exclusions),'eligible source required')
        need(sha((HERE/'sources'/name).read_bytes())==digest,'source hash mismatch '+name)
    rn5=side24.source_binding()
    return {'ceiling_sources':SOURCE_HASHES,'historical_code_executed':False,'rn5':rn5}


def historical_tail_counterexample():
    # Analyze frozen source text, never execute it. For x=-40 the Mills
    # endpoints both lie below half the smallest positive binary64 number.
    source=(HERE/'sources/h3_band_ceil.py').read_text()
    fragment='return iv.mpf((float(lo.a), float(hi.b)))'
    need(fragment in source,'historical tail conversion evidence missing')
    x=F(40);phi=rnd(normal_pdf(I.exact(x),PREC))
    lower=rnd(phi*(1/x-1/x**3));upper=rnd(phi/x)
    half_min_subnormal=F(1,2**1075)
    need(lower.lo>0,'strict positive Mills lower witness')
    need(upper.hi<half_min_subnormal,'both Mills endpoints strictly below binary64 rounding threshold')
    # Float observations are NON-CERTIFYING diagnostics; exact comparisons
    # immediately above prove the underflow and strict-positive true tail.
    observed=(float(lower.lo),float(upper.hi))
    need(observed==(0.0,0.0),'binary64 demonstration differs on this runtime')
    return {'status':'COUNTEREXAMPLE','argument':'Phi(-40)>lower>0, but source converts both Mills endpoints to zero.',
        'x':-x,'positive_cdf_lower':lower.lo,'cdf_upper':upper.hi,
        'half_smallest_binary64_subnormal':half_min_subnormal,
        'source_fragment':fragment,'diagnostic_float_conversions':['0.0','0.0'],
        'float_demonstration_role':'NON-CERTIFYING; proof uses exact rational inequalities',
        'historical_source_executed':False,
        'scope':'Historical iv_Phi unconditional enclosure guarantee fails; numerical uniform ceiling not disproved.'}


def build_law():
    m,s=((-R/2,F(0)),(R/2,F(0)))
    raw=tuple((p,jet) for p in (m,s) for jet in ((0,0),(1,0),(0,1)))
    transform=((1,0,0,0,0,0),(0,1,0,0,0,0),(0,0,1,0,0,0),
        (0,-1/R,0,0,1/R,0),(0,0,-1/R,0,0,1/R),
        (-1/R**3,-1/(2*R**2),0,1/R**3,-1/(2*R**2),0))
    values=(HEIGHT,F(0),F(0),HEIGHT-R**3/6,F(0),F(0))
    pinvalues=tuple(sum(F(c)*v for c,v in zip(row,values)) for row in transform)
    need(pinvalues==(HEIGHT,0,0,0,0,F(-1,6)),'pin window mismatch')
    recovered=(pinvalues[0],pinvalues[1],pinvalues[2],R**3*pinvalues[5]+pinvalues[0]+R*(R*pinvalues[3]+2*pinvalues[1])/2,R*pinvalues[3]+pinvalues[1],R*pinvalues[4]+pinvalues[2])
    need(recovered==values,'pin transform inverse mismatch')
    pins=[[(raw[j][0],raw[j][1],F(c)) for j,c in enumerate(row) if c] for row in transform]
    soft=[[(p,jet,scale)] for jet,scale in (((0,2),F(1)),((2,0),1/R),((1,1),1/R)) for p in (m,s)]
    @lru_cache(maxsize=256)
    def cov(p,a,q,b):return side24.covariance(p,a,q,b,prec=PREC,bits=BITS)
    def lc(a,b):
        result=I.exact(0)
        for p,alpha,c in a:
            for q,beta,d in b:result=rnd(result+rnd(c*d*cov(p,alpha,q,beta)))
        return result
    coords=pins+soft
    matrix=[[None]*12 for _ in range(12)]
    for i in range(12):
        for j in range(i+1):matrix[i][j]=matrix[j][i]=lc(coords[i],coords[j])
    name='SIDE24:normalized:r=1/20:b=6/5:six-pins'
    law=condition_gaussian([row[:6] for row in matrix[:6]],[row[:6] for row in matrix[6:]],[row[6:] for row in matrix[6:]],pinvalues,(0,)*6,
        conditioning_order=tuple('V'+str(i) for i in range(6)),target_order=('qM','qS','aM','aS','bM','bS'),
        covariance_law=name,mean_law=name,conditioning_law=name,mark_domain=(0,0),round_bits=BITS)
    softfactor=interval_ldlt(law.covariance,round_bits=BITS)
    need(all(p.lo>0 for p in (*law.pivots,*softfactor.pivots)),'pin/soft positive pivots not established')
    return law.intercept,law.covariance,{'pin_values':pinvalues,'raw_values':values,'transform':transform,'pin_pivots':law.pivots,'soft_pivots':softfactor.pivots}


def gaussian_moment(mu,cov,indices):
    """Noncentral Wick via E[X_i P]=mu_i E[P]+sum_j cov_ij E[d_j P]."""
    @lru_cache(maxsize=None)
    def rec(state):
        if not state:return I.exact(1)
        i,*rest=state;out=rnd(mu[i]*rec(tuple(rest)))
        for k,j in enumerate(rest):out=rnd(out+rnd(cov[i][j]*rec(tuple(rest[:k]+rest[k+1:]))))
        return out
    return rec(tuple(sorted(indices)))


def padd(a,b):
    out=[I.exact(0)]*max(len(a),len(b))
    for i,c in enumerate(a):out[i]=rnd(out[i]+c)
    for i,c in enumerate(b):out[i]=rnd(out[i]+c)
    return tuple(out)

def pscale(a,c):return tuple(rnd(v*c) for v in a)
def pmul(a,b):
    out=[I.exact(0)]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):out[i+j]=rnd(out[i+j]+rnd(x*y))
    return tuple(out)


def half_moments(h):
    """Integrals of u^n phi(u), -infinity<u<h, n=0..4."""
    phi=rnd(normal_pdf(h,PREC));cdf=rnd(Phi(h,PREC))
    out=[cdf,-phi]
    for n in range(2,5):out.append(rnd(-h**(n-1)*phi+(n-1)*out[n-2]))
    return tuple(out)


def restricted_moment_factory(mu,cov):
    """E[monomial(X) 1_{qM<0}], with exact Gaussian regression on qM."""
    need(cov[0][0].lo>0,'qM variance positive')
    sigma=rnd(sqrt(cov[0][0],PREC))
    beta=[rnd(cov[i][0]/sigma) for i in range(6)]
    residual=[[rnd(cov[i][j]-cov[i][0]*cov[0][j]/cov[0][0]) for j in range(6)] for i in range(6)]
    h=rnd(-mu[0]/sigma);moments=half_moments(h)
    @lru_cache(maxsize=None)
    def rec(state):
        if not state:return (I.exact(1),)
        i,*rest=state;out=pmul((mu[i],beta[i]),rec(tuple(rest)))
        for k,j in enumerate(rest):out=padd(out,pscale(rec(tuple(rest[:k]+rest[k+1:])),residual[i][j]))
        return out
    def integrate(indices):
        p=rec(tuple(sorted(indices)));out=I.exact(0)
        for c,v in zip(p,moments):out=rnd(out+rnd(c*v))
        return out
    return integrate,{'standardized_threshold':h,'truncated_standard_moments':moments,'regression_coefficients':beta,'residual_covariance':residual}


def determinant_square(moment,site,r=R,cross=F(-2)):
    q,a,b=(site,site+2,site+4)
    return rnd(moment((a,a,q,q))+cross*r*moment((a,q,b,b))+r*r*moment((b,b,b,b)))


def ceiling_from_moments(a,b):
    need(a.lo>=0 and b.lo>=0,'nonnegative square-moment enclosures required')
    return rnd(sqrt(rnd(a*b),PREC))


def fourth_formula(mu,cov,a,q,b,r=R):
    ma,mq,mb=mu[a],mu[q],mu[b]
    va,vq,vb=cov[a][a],cov[q][q],cov[b][b]
    aq,ab,qb=cov[a][q],cov[a][b],cov[q][b]
    ea2q2=ma**2*mq**2+ma**2*vq+mq**2*va+4*ma*mq*aq+va*vq+2*aq**2
    eaqb2=(ma*mq+aq)*(mb**2+vb)+2*mb*(ma*qb+mq*ab)+2*ab*qb
    eb4=mb**4+6*mb**2*vb+3*vb**2
    return rnd(ea2q2-2*r*eaqb2+r**2*eb4)


def scale_identity(claimed):
    # Symbolic coefficients in ordered monomials aqAQ, aqB^2, b^2AQ, b^2B^2.
    # Raw determinants are (r aq-r^2 b^2)(r AQ-r^2 B^2).
    raw=(R**2,-R**3,-R**3,R**4)
    scaled=tuple(claimed*c for c in (F(1),-R,-R,R**2))
    need(raw==scaled,'raw determinant product must include exact r^2 factor')
    return {'raw_product_coefficients':raw,'r_squared_times_scaled_coefficients':scaled}


def evaluate(cap=F('3.74767948915996'),mutation=None):
    need(type(cap) is F and cap>0,'positive exact cap required')
    binding=source_binding()
    dependencies={str(Path(m.__file__).resolve().relative_to(REPO)):sha(Path(m.__file__).read_bytes()) for m in tuple(sys.modules.values()) if getattr(m,'__file__',None) and REPO in Path(m.__file__).resolve().parents and Path(m.__file__).suffix=='.py'}
    mu,cov,metadata=build_law()
    full=lambda indices:gaussian_moment(mu,cov,indices)
    restricted,regression=restricted_moment_factory(mu,cov)
    cross=F(2) if mutation=='wrong_cross' else F(-2)
    full_squares=[determinant_square(full,j,cross=cross) for j in (0,1)]
    half_squares=[determinant_square(restricted,j) for j in (0,1)]
    for j in (0,1):need(full_squares[j].intersect(fourth_formula(mu,cov,j+2,j,j+4)) is not None,'independent fourth-moment formula disagreement')
    all_upper=ceiling_from_moments(*full_squares)
    type_upper=ceiling_from_moments(*half_squares)
    need(type_upper.hi<all_upper.lo,'typed halfspace strictly improves full Gaussian CS ceiling')
    if mutation=='too_small_cap':cap=F(3)
    need(type_upper.hi<=cap,'requested ceiling too small for computed proof')
    scale_identity(F(1) if mutation=='wrong_scale' else R**2)
    need(all(sha((REPO/p).read_bytes())==digest for p,digest in dependencies.items()),'loaded repository sources changed during run')
    # Safe decimal reporting uses integer ceil, not float formatting.
    scale=10**12
    typed_decimal=F(-(-type_upper.hi.numerator*scale//type_upper.hi.denominator),scale)
    full_decimal=F(-(-all_upper.hi.numerator*scale//all_upper.hi.denominator),scale)
    return enc({'schema':'H3_FIXED_R_CEILING_V1','status':'PROVED_CANDIDATE','domain':{'r':R,'height':HEIGHT,'dimensions':2,'normalized_side':24,'uniform_r':False},
        'source_binding':binding,'historical_tail_counterexample':historical_tail_counterexample(),'repository_dependencies':dependencies,'checker_sha256':sha(Path(__file__).read_bytes()),
        'determinant_scaling':scale_identity(R**2),'gaussian_law':{'mean':mu,'covariance':cov,**metadata},'regression':regression,
        'full_determinant_second_moments':full_squares,'qM_negative_determinant_second_moments':half_squares,
        'full_cs_coefficient_enclosure':all_upper,'typed_cs_coefficient_enclosure':type_upper,
        'safe_decimal_full_ceiling':full_decimal,'safe_decimal_typed_ceiling':typed_decimal,'Z_upper':R**2*typed_decimal,
        'historical_uniform_ceiling':F('3.74767948915996'),'historical_uniform_ceiling_replayed':False,
        'fixed_r_comparison_to_historical_cap':True,'requested_cap':cap,'certified_arithmetic':'Fractions plus repository interval','precision_bits':BITS,
        'scientific_status_changed':False,'original_prize_closed':False,'external_independence_credit':0,'all_small_r_certified':False,
        'remaining_hypotheses':['Fixed-r domain only; uniform-r Laurent/Neumann law pipeline not replayed.','Ordinary mathematical review of source-law applicability and interval library remains required.'],
        'does_not_establish':['No uniform-r ceiling, H5 ZBAND closure, RN uniform lemma, canonical promotion or organizational independence.']})


def main():
    p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,default=REPO);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--certificate',type=Path);p.add_argument('--cap',default='3.74767948915996');p.add_argument('--mutation',choices=['too_small_cap','wrong_cross','wrong_scale'])
    args=p.parse_args();out=args.output.resolve()
    need(REPO!=out and REPO not in out.parents,'read-only repository output refused')
    need(not out.exists() and out.parent.is_dir(),'fresh output path required')
    result=evaluate(F(args.cap),args.mutation)
    envelope={'payload':result,'payload_sha256':sha(canonical(result))}
    if args.certificate:
        expected=json.loads(args.certificate.read_text())
        need(canonical(expected)==canonical(envelope),'candidate exact typed JSON mismatch')
    out.write_text(json.dumps(envelope,sort_keys=True,indent=2)+'\n')
    print('H3 fixed-r ceiling PASS; domain r=1/20; typed coefficient <= '+result['safe_decimal_typed_ceiling']+'; uniform_r=False')
if __name__=='__main__':
    try:main()
    except (ValueError,TypeError,ZeroDivisionError) as e:
        print('H3 fixed-r ceiling FAIL: '+str(e),file=sys.stderr);sys.exit(1)
