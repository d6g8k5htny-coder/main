# H3 ceiling candidate

New fixed-r result: `Z_(1/20)/(1/20)^2 <= 3.230674239349`, proved from the exact
six-pin normalized SIDE24 law by halfspace Gaussian quartic moments and
Cauchy–Schwarz. The historical all-radius ceiling is not replayed; an exact
counterexample is supplied for its Mills-tail binary64 conversion step.

Read `PROOF.md`; use `RUN.json` for portable orchestration with an explicit
repository path and fresh output location. `MANIFEST.json` identifies only the
frozen final delivery files. `result-draft.json` is an excluded exploration
artifact and must not be consumed.

This is an author-side candidate with zero external independence credit and
no canonical status change.
