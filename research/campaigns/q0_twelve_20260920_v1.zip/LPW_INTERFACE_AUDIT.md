# Additional parent audit of the LPW deterministic interface

The extra review worker stopped at the account usage limit. Its partial findings
are not a completed review verdict. The parent subsequently read the exact
original candidate, the author clarification and GP-DER-118 §0 and performed
the audit below. This is same-provider author-side work, not organizationally
independent acceptance. Project 5's frozen artifacts remain unchanged.

## Exact sources

- Original candidate, Drive `1p4CsAYJZt30ptsgzANnUSaA-4gU3UcNN`, 22,614 bytes,
  SHA256 `cf58f72eb0399c626160c143b50f674ff3bd5c449225211edd6fd378a374e1a5`.
- Clarification A1/A2, Drive `1dSzIiXY4wEU7BX4gj9qmLyCdpSG3laKE`, 3,313 bytes,
  SHA256 `8e932a486a5e84809284fae9520ce0cec88f28fedea43a9385e856209fd50f09`.
- GP-DER-118-v1.10, Drive `1qc6ep2S4PIoPMEWDsdDQI1dr0LOwJiK9`, 30,933 bytes,
  whole-file SHA256 `c1d6e559274d7e87a3fa92f44cb2534a5e277a3b5941fd40db380599ddba0564`.
  Only the stated law/event definitions are used, not its status declarations
  as proof of another result. Whole-file and frozen-body identities differ.

All three are eligible active-package source snapshots. Exact raw bytes and
metadata are included. Original source code is not executed.

## Six-pin coordinate identification

With raw order (fM,fxM,fyM,fS,fxS,fyS), the candidate's displayed Hermite matrix
acts on exp(i k·z), theta=kx*r/2, as the R05 ten-profile convention requires:

- U0: cos(theta)+(theta/2)sin(theta).
- U1: i*kx*[3sin(theta)/(2theta)-cos(theta)/2].
- U2: i*ky*cos(theta).
- U3: -kx²*sin(theta)/(2theta).
- U4: -kx*ky*sin(theta)/theta.
- U5: i*kx³*[cos(theta)/(2theta²)-sin(theta)/(2theta³)].

The last profile tends to -1/6, and i*(-1/6) agrees with i³/6, so its endpoint
is fxxx/6, not its negative. These expressions follow directly by substituting
exp(±i theta) and the derivative multipliers into each displayed matrix row.
The four remaining J coordinates are the fixed midpoint derivatives
(fyy,fxxy/2,fxyy/2,fyyy/6). Thus the Fourier-profile identification used in
project 5 agrees with this original candidate, at every positive radius.
The observed vector is exactly (b-r³/12,-r²/4,0,0,0,1/3).

## Deterministic Taylor lift and weight

Write K for the global maximum of the fourth derivatives, h=r/2. The endpoint
gradient expansions have remainders bounded by K*h³/6. Their difference gives
|fxx(0)| and |fxy(0)| <=K*r²/24. Their average gives
|fx(0)+r²*fxxx(0)/8|<=K*r³/48, and the corresponding fy formula.

The endpoint value difference has remainder <=K*r⁴/192. Substitution of the
averaged gradient equation gives |fxxx(0)-2|<=5K*r/16. The averaged values
and the fxx bound give |(f(0)-b)/r³+1/12|<=K*r/128. Therefore the rescaled
x-linear coefficient differs from -1/4 by at most 23K*r/384. The y-linear
coefficient differs from -A/4 by at most K*r/48.

For the monomials (1,x,y,x²,xy,x³), the C2 norms on [-2,1/2]×[-1,1]
are bounded by (1,2,1,4,2,12). The six coefficient errors contribute

  (1/128 + 2*23/384 + 1/48 + 4/48 + 2/24 + 12*5/96)K*r
  = (361/384)K*r.

The Taylor remainder after any derivative through order two is bounded by
K*r*3^(4-|alpha|)/(4-|alpha|)!, hence by (9/2)K*r. The total is
(2089/384)K*r<8K*r. The four free-jet basis functions have C2 bounds
(4,4,2,6), giving 16*delta. Thus delta=1/1024 and r<=1/(256K) imply
C2 error<=3/64<1/16, uniformly over the whole rectangle.

The explicit path y=(x²-1/4)/5, -2<=x<=-1/2, has height minimum
-99/1280 and endpoint height9/16 under the cubic witness. The identity

 R(x)+99/1280=(4x+5)²(48x²-40x+1)/3840

proves the minimum throughout the interval, since the second factor is
positive there. Under C2 error1/16 the path remains strictly above -1/6
with clearance103/3840, and ends at height at least1/2 above the pinned
maximum. Entrywise Hessian bounds give determinants at least81/16 at the
maximum and at most -1673/128 at the saddle. Their product magnitude is
larger than65. Physical Hessians equal r times the scaled Hessians, so the
pair weight is at least65*r⁴.

For the normalizer, the pinned gradient differences imply the average of
fxx and fxy over the pin interval is zero. Their Lipschitz constants are at
most M3. Thus their endpoint magnitudes are at most r*M3. The remaining
Hessian entry is at most M3. Each determinant is bounded by2*r*M3² for
r<=1, giving Z<=4*r²*E_Q M3⁴. The constructed positive event also makes Z>0.
These arguments do not need a third-saddle count or a trajectory tube.

## What the topological conclusion means

For an elder-rule interpretation of superlevel H0, a path from M to a point
above its birth height b, staying above the proposed saddle level, implies
that M has joined an older component before that saddle level. It therefore
cannot have that saddle as its death partner. This is the exact event in the
original LPW candidate and the intended scope of project 5's coefficient.
Application to a random field still needs the asserted measurable, well-defined
persistence interpretation (or one can retain only the path-defined event).

GP-DER-118 §0 verifies the same six pins, Hessian weight and typed Palm law.
Its event, however, is convergence of a selected gradient branch to M.
**Equality of laws does not identify that adjacency event with elder pairing.**
This audit does not transfer the LPW bound to an adjacency-conditioned q or to
a differently defined canonical q0. Any such transfer requires its own exact
event identity and, where applicable, an eta budget.

The direct source audit supports the deterministic and coordinate interfaces
of the LPW candidate. It does not change its canonical status, supply external
acceptance, prove every Gaussian persistence genericity premise, or close q0.
The twelve-project replay validates the numerical project 5 result at its
explicitly frozen conditional scope.
