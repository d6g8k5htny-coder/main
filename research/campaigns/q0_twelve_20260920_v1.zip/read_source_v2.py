#!/usr/bin/env python3
"""Materialize one eligible, digest-pinned local Drive snapshot outside the repo.

Native DOCX text is a derived reading copy, not an asserted source-body digest.
This helper does not execute sources or extract arbitrary ZIP members.
"""
import argparse
import hashlib
from io import BytesIO
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
from zipfile import ZipFile

sys.dont_write_bytecode = True
REPO = Path('/Users/dylanroy/Documents/Codex/research-main')
sys.path.insert(0, str(REPO))
from tools.drive_coverage import Store, DEFAULT

def require(condition, message):
    if not condition:
        raise ValueError(message)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--id', required=True)
    parser.add_argument('--output-dir', required=True, type=Path)
    args = parser.parse_args()
    output = args.output_dir.resolve()
    require(not output.is_relative_to(REPO), 'output must be outside repository')
    inventory = [json.loads(x) for x in (REPO/'drive/inventory.jsonl').read_text().splitlines()]
    item = next(x for x in inventory if x['id'] == args.id)
    path = item.get('path', '')
    require(path.startswith('01_ACTIVE_RESEARCH_PACKAGES/'), 'source is outside active packages')
    require(not any(t in path.lower() for t in ['99_do_not_open', 'legacy', 'quarantine']), 'prohibited source path')
    require(item.get('context') == 'RESEARCH_SOURCE_CHECK_STATUS', 'nonresearch or quarantined inventory context')
    exclusions = json.loads((REPO/'quarantine/EXCLUSIONS.json').read_text())['exclusions']
    require(not any(x.get('kind') == 'drive_object' and x.get('carrier_id') == args.id for x in exclusions), 'excluded Drive object')
    rows = [json.loads(x) for x in (REPO/DEFAULT/'coverage.jsonl').read_text().splitlines()]
    row = next(x for x in rows if x['id'] == args.id)
    require(row['status'] in {'EXACT_SOURCE_BYTES', 'EXISTING_EXACT_BYTES', 'NATIVE_EXPORT', 'RAW_SOURCE_SNAPSHOT'}, 'source is not stored/eligible')
    require(row.get('context') == 'RESEARCH_SOURCE_CHECK_STATUS', 'nonresearch or quarantined coverage context')
    require(not any(x.get('payload_sha256') == row['sha256'] for x in exclusions), 'excluded source payload')
    storage = row['storage']
    if 'file' in storage:
        file = (REPO/storage['file']).resolve()
        require(file.is_relative_to(REPO), 'stored path escapes repository')
        require(not any(t in str(file.relative_to(REPO)).lower().split('/') for t in ['legacy', 'quarantine']), 'excluded file location')
        raw = file.read_bytes()
    else:
        raw = b''.join(Store(REPO, DEFAULT).object_chunks(storage['object']))
    require(len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256'], 'source identity mismatch')
    require(not any(x.get('payload_sha256') == row['sha256'] for x in exclusions), 'excluded source payload')
    is_docx = row.get('export_mime_type') == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    if is_docx:
        with ZipFile(BytesIO(raw)) as archive:
            require(archive.namelist().count('word/document.xml') == 1, 'missing/duplicate document body')
            root = ET.fromstring(archive.read('word/document.xml'))
        ns = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
        paragraphs = []
        for p in root.iter(ns+'p'):
            paragraphs.append(''.join(n.text or '' if n.tag == ns+'t' else '\t' if n.tag == ns+'tab' else '\n' if n.tag in (ns+'br', ns+'cr') else '' for n in p.iter()))
        text = '\n'.join(paragraphs)+'\n'
        rule = 'Derived DOCX paragraph text in document order; w:t preserved, tab/br/cr converted; no native body identity asserted.'
    else:
        require(not raw.startswith(b'PK'), 'archive source requires separately excluded-member-aware reader')
        text = raw.decode('utf-8-sig')
        rule = 'UTF-8 decoding with optional BOM removed for reading only; exact raw bytes retained.'
    output.mkdir(parents=True, exist_ok=False)
    (output/('source.docx' if is_docx else 'source.raw')).write_bytes(raw)
    (output/'reading.txt').write_text(text)
    metadata = {'drive_id':args.id, 'inventory':item, 'coverage':row, 'extraction_rule':rule,
                'reading_sha256':hashlib.sha256(text.encode()).hexdigest(), 'authority':'SOURCE SNAPSHOT; CHECK CURRENT STATUS',
                'native_export_caveat':'Export revision observed, not revision-addressed export.' if is_docx else None}
    (output/'IDENTITY.json').write_text(json.dumps(metadata,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({'id':args.id,'output':str(output),'bytes':len(raw),'sha256':row['sha256']}))

if __name__ == '__main__':
    main()
