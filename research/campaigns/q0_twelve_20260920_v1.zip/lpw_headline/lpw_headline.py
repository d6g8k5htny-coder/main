#!/usr/bin/env python3
"""Exact LPW density, conditional norms and headline successor candidate.

The source LPW topology/weight theorem and six-pin identification are explicit
imported hypotheses. No scientific status, external review or prize is closed.
"""
from __future__ import annotations
import argparse
from fractions import Fraction as F
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
DEFAULT_REPO = Path('/Users/dylanroy/Documents/Codex/research-main')
BOOT = argparse.ArgumentParser(add_help=False)
BOOT.add_argument('--repo', type=Path, default=DEFAULT_REPO)
BOOT.add_argument('--amplitude-dir', type=Path, default=HERE.parent/'lpw_amplitude')
CONFIG = BOOT.parse_known_args()[0]
REPO = CONFIG.repo.resolve()
AMPLITUDE = CONFIG.amplitude_dir.resolve()
sys.path.insert(0, str(REPO))
from research.interval import Interval as I, sqrt, exp, pi

R, DELTA, PREC, BITS = F(1,100000), F(1,1024), 24, 160
PREFIX = 'drive/mirrors/02_RESEARCH_CARRY_FORWARD_CANON/LPW — RAW ARCHIVE INTAKE R05/'
SCALES = tuple(map(F, ('1','1','1','1/2','1','1/6','1','1/2','1/2','1/6')))
POWERS = ((0,0),(1,0),(0,1),(2,0),(1,1),(3,0),(0,2),(2,1),(1,2),(0,3))

def require(ok, message):
    if not ok:
        raise ValueError(message)

def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',',':'))

def strict_json(path):
    def pairs(items):
        out = {}
        for k,v in items:
            require(k not in out, 'duplicate JSON key: '+k)
            out[k] = v
        return out
    def bad(value):
        raise ValueError('noninteger JSON literal: '+value)
    return json.loads(Path(path).read_text(), object_pairs_hook=pairs,
                      parse_float=bad, parse_constant=bad)

def identity(path):
    data = path.read_bytes()
    return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

def inputs(repo=REPO, amplitude=AMPLITUDE):
    manifest = strict_json(HERE/'DEPENDENCIES.json')
    actual = {}
    for scope, root in (('repository',repo),('amplitude',amplitude)):
        actual[scope] = {}
        for name, expected in manifest[scope].items():
            current = identity(root/name)
            require(canonical(current)==canonical(expected), 'input identity mismatch: '+scope+'/'+name)
            actual[scope][name] = current
    return actual

def rr(x):
    return x.round_out(BITS)

def total(xs):
    result = I(0)
    for x in xs:
        result = rr(result+x)
    return result

def cap(x):
    return {'lo':str(x.lo),'hi':str(x.hi)}

def matrix_cap(a):
    return [[cap(x) for x in row] for row in a]

def ceiling(x):
    return -(-x.numerator//x.denominator)

def fourth_root(x):
    return rr(sqrt(sqrt(x,PREC),PREC))

def ldl(a):
    n = len(a)
    require(all(len(row)==n for row in a), 'matrix must be square')
    require(all(a[i][j]==a[j][i] for i in range(n) for j in range(n)), 'matrix must be symmetric')
    l = [[I(int(i==j)) for j in range(n)] for i in range(n)]
    d = []
    for j in range(n):
        pivot = rr(a[j][j]-total(l[j][k]**2*d[k] for k in range(j)))
        require(pivot.lo>0, 'nonpositive LDL pivot at '+str(j))
        d.append(pivot)
        for i in range(j+1,n):
            l[i][j] = rr((a[i][j]-total(l[i][k]*l[j][k]*d[k] for k in range(j)))/pivot)
    return l,d

def solve_ldl(l,d,b):
    n = len(d)
    y = []
    for i in range(n):
        y.append(rr(b[i]-total(l[i][j]*y[j] for j in range(i))))
    z = [rr(y[i]/d[i]) for i in range(n)]
    out = [I(0) for _ in range(n)]
    for i in reversed(range(n)):
        out[i] = rr(z[i]-total(l[j][i]*out[j] for j in range(i+1,n)))
    return out

def covariance_endpoint(moments):
    result = [[I(0) for _ in range(10)] for _ in range(10)]
    for i,(xi,yi) in enumerate(POWERS):
        for j,(xj,yj) in enumerate(POWERS):
            xx,yy=xi+xj,yi+yj
            if xx%2 or yy%2:
                continue
            sign=(-1)**(xj+yj+xx//2+yy//2)
            result[i][j]=rr(sign*SCALES[i]*SCALES[j]*moments[xx//2]*moments[yy//2])
    return result

def family(endpoint, entry_bounds, radius=R):
    return [[rr(endpoint[i][j]+I(-entry_bounds[i][j]*radius**2,
                                 entry_bounds[i][j]*radius**2))
             for j in range(10)] for i in range(10)]

def shifted(a, floor):
    return [[rr(v-I(floor if i==j else 0)) for j,v in enumerate(row)] for i,row in enumerate(a)]

def conditional(a, u):
    """Six-pin conditioning; symmetric upper triangle reused for sound LDL."""
    pin=[row[:6] for row in a[:6]]
    l,d=ldl(pin)
    solved=[solve_ldl(l,d,[a[i][j] for i in range(6)]) for j in range(6,10)]
    sol_u=solve_ldl(l,d,u)
    mean=[total(a[i][k]*sol_u[k] for k in range(6)) for i in range(6,10)]
    schur=[[I(0) for _ in range(4)] for _ in range(4)]
    for i in range(4):
        for j in range(i,4):
            value=rr(a[6+i][6+j]-total(a[6+i][k]*solved[j][k] for k in range(6)))
            schur[i][j]=value
            schur[j][i]=value
    return mean,schur,d

def gaussian_density(mean,cov,box):
    l,d=ldl(cov)
    residual=[rr(j-mu) for j,mu in zip(box,mean)]
    # Whiten by L, then q=sum y_i^2/d_i. This avoids signed interval cross terms.
    y=[]
    for i in range(len(d)):
        y.append(rr(residual[i]-total(l[i][j]*y[j] for j in range(i))))
    quadratic=total(y[i]**2/d[i] for i in range(len(d)))
    determinant=I(1)
    for pivot in d:
        determinant=rr(determinant*pivot)
    density=rr(exp(-quadratic/2,PREC)/(4*pi(PREC)**2*sqrt(determinant,PREC)))
    return density, {'mean':list(map(cap,mean)), 'schur_covariance':matrix_cap(cov),
       'schur_ldl_pivots':list(map(cap,d)), 'whitened_box':list(map(cap,y)),
       'mahalanobis_squared':cap(quadratic),'determinant':cap(determinant),
       'density':cap(density)}

def regression_operator(max_variance, eigenfloor):
    require(max_variance>0 and eigenfloor>0, 'invalid regression hypotheses')
    return rr(sqrt(I(max_variance/eigenfloor),PREC))

def assemble(b3, k, density_floor, claim, survival=F(1,2), volume_factor=32,
             determinant_power=4, radius=None):
    require(type(b3) is int and b3>0 and type(k) is int and k>=1, 'invalid budgets')
    require(density_floor>0, 'nonpositive density floor')
    require(survival==F(1,2), 'Markov survival must retain one half')
    require(volume_factor==32, 'thin-box Jacobian/volume mismatch')
    require(determinant_power==4, 'Hessian product power must be four')
    radius=F(1,256*k) if radius is None else radius
    require(0<radius<=min(R,F(1),F(1,256*k)), 'radius exceeds norm or covariance range')
    require(16*DELTA+8*k*radius<=F(3,64)<F(1,16), 'geometry fails')
    weight_base=F(81,16)*F(1673,128)
    require(weight_base>=65, 'determinant lower weight fails')
    require(F(1,6)-F(99,1280)-F(1,16)==F(103,3840)>0, 'path clearance fails')
    require(1+determinant_power-2==3, 'cubic exponent fails')
    coefficient=65*survival*volume_factor*DELTA**4*density_floor/(4*b3)
    require(0<claim<=coefficient, 'claimed headline exceeds exact justified coefficient')
    return {'B3_ceiling':b3, 'K_ceiling':k,'density_floor':str(density_floor),
      'normalizer_r2_upper':str(4*b3), 'Markov_survival':str(survival),
      'thin_box_volume_coefficient':str(volume_factor*DELTA**4),
      'determinant_r4_lower':'65','exact_coefficient':str(coefficient),
      'claimed_downward_floor':str(claim), 'radius':str(radius),
      'hard_geometry':str(16*DELTA+8*k*radius), 'power_ledger':[1,4,-2,3]}

def load_amplitude():
    spec=importlib.util.spec_from_file_location('headline_amplitude_dependency',AMPLITUDE/'lpw_amplitude.py')
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    fresh=module.compute(REPO)
    require(canonical(fresh)==canonical(strict_json(AMPLITUDE/'result.json')), 'amplitude replay mismatch')
    return fresh

def compute(claim=F('2.77e-23'), old_claim=F('6.238e-44'), density_claim=F(1,1000), endpoint_floor=F(253,2000)):
    before=inputs()
    from research.parallel.lpw import lpw_modulus as mod
    mod.source_identity(REPO)
    _,_,moments,lattice=mod.lattice()
    majorants,modulus=mod.modulus(moments,'quadratic')
    require(modulus.hi<F('1.804'),'quadratic modulus ceiling')
    endpoint=covariance_endpoint(moments)
    _,endpoint_pivots=ldl(shifted(endpoint,endpoint_floor))
    gamma=family(endpoint,majorants)
    eigenfloor=endpoint_floor-modulus.hi*R**2
    require(eigenfloor>0,'uniform covariance floor')
    b=F(6,5)
    u=[I(b-R**3/12,b), I(-R**2/4,0), I(0), I(0), I(0), I(F(1,3))]
    box=[I(-(10+2*DELTA)*R,0),I(2-DELTA,2+DELTA),I(-DELTA,DELTA),I(-DELTA,DELTA)]
    mean,schur,pin_pivots=conditional(gamma,u)
    density,density_report=gaussian_density(mean,schur,box)
    require(density.lo>=density_claim,'claimed density floor exceeds computed lower endpoint')
    amplitude=load_amplitude()
    field=amplitude['unconditional_field_bounds']
    field3=F(field['sharpened_E_C3_to_fourth_upper'])
    field4=F(field['sharpened_E_C4_upper'])
    maxvar=lambda order:max((moments[i]*moments[j]).hi for i in range(order+1) for j in range(order+1-i))
    A3=regression_operator(maxvar(3),eigenfloor)
    A4=regression_operator(maxvar(4),eigenfloor)
    tr6=total(gamma[i][i] for i in range(6)).hi
    tr10=total(gamma[i][i] for i in range(10)).hi
    fro6=total(gamma[i][j]**2 for i in range(6) for j in range(6)).hi
    eu4=tr6**2+2*fro6
    usq=total(x**2 for x in u).hi
    jsq=total(x**2 for x in box).hi
    ub=rr(sqrt(I(usq),PREC))
    vb=rr(sqrt(I(usq+jsq),PREC))
    B3=rr((1+fourth_root(I(field3))+A3*(fourth_root(I(eu4))+ub))**4)
    B4=rr(I(field4)+A4*(sqrt(I(tr10),PREC)+vb))
    b3=ceiling(B3.hi)
    k=max(1,ceiling(2*B4.hi))
    old=assemble(3790446482793,9432,F(1,10**21),old_claim)
    successor=assemble(b3,k,density_claim,claim)
    require(F(successor['exact_coefficient'])>F(old['exact_coefficient']), 'successor must improve old budget')
    require(canonical(before)==canonical(inputs()), 'input identities changed during replay')
    return {'schema':'lpw-headline-successor-v1','status':'CONDITIONAL_PROVED_CANDIDATE',
      'target':'Q0-P12-LPW-HEADLINE-20260920-v1',
      'claim_reference':'60663b69-45c3-431d-b27c-33c13695d2d7',
      'inputs':before,'inputs_unchanged':True,
      'parameters':{'R':str(R),'delta':str(DELTA),'b':str(b),'endpoint_floor':str(endpoint_floor),
                    'norm':'max_{|alpha|<=k} sup |D^alpha f|'},
      'lattice':lattice,'quadratic_entry_majorants':[[str(x) for x in row] for row in majorants],
      'quadratic_modulus':cap(modulus), 'endpoint_covariance':matrix_cap(endpoint),
      'endpoint_shifted_ldl_pivots':list(map(cap,endpoint_pivots)),
      'uniform_eigenfloor':str(eigenfloor),'pin_values':list(map(cap,u)),
      'jet_box':list(map(cap,box)), 'pin_ldl_pivots':list(map(cap,pin_pivots)),
      'conditional_density':density_report,
      'conditional_norms':{'unconditional_C3_fourth':str(field3),'unconditional_C4_mean':str(field4),
        'max_derivative_variance3':str(maxvar(3)), 'max_derivative_variance4':str(maxvar(4)),
        'operator_A3':cap(A3),'operator_A4':cap(A4),'trace6_upper':str(tr6),
        'trace10_upper':str(tr10),'frobenius6_squared_upper':str(fro6),
        'pin_fourth_moment_upper':str(eu4),'pin_euclidean_norm':cap(ub),
        'ten_coordinate_norm':cap(vb),'B3':cap(B3),'B4':cap(B4)},
      'old_repaired_arithmetic':old,'successor':successor,
      'coefficient_budget_improvement_ratio':str(F(successor['exact_coefficient'])/F(old['exact_coefficient'])),
      'imported_hypotheses':[
        'The source ten Hermite profiles exactly represent its normalized SIDE24 six-pin and J coordinates; the coordinate transform is not rederived here.',
        'The source deterministic LPW topology/Taylor theorem: the stated thin-box/norm event forces failure, has determinant weight at least 65*r^4, and pair-Palm normalizer at most 4*B3*r^2.',
        'The continuous Gaussian regression/Palm version and q notation agree with LPW-CAND-20260912 (source-declared SHA cf58f72eb0399c626160c143b50f674ff3bd5c449225211edd6fd378a374e1a5; original theorem body not consumed here).'],
      'analytic_proof':'PROOF.md proves regression operator, conditional norm, Schur density and integrated conditional Markov chain. Exact code verifies arithmetic, not a proof assistant.',
      'scientific_promotion':False,'organizational_independence_credit':0,'original_prize_closed':False,
      'limitations':['Source-exposed same-provider author candidate; external review remains required.',
        'No q0 upper bound, RN annulus closure, limiting coefficient, two-sided law, 3D composition or original prize claim.',
        'Old B3/K/density values are imported only in the separately labelled historical arithmetic replay; all successor analytic budgets are recomputed.']}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=REPO)
    p.add_argument('--amplitude-dir',type=Path,default=AMPLITUDE)
    p.add_argument('--verify',type=Path)
    p.add_argument('--output',type=Path)
    p.add_argument('--claim',default='2.77e-23')
    p.add_argument('--old-claim',default='6.238e-44')
    p.add_argument('--density-claim',default='1/1000')
    p.add_argument('--endpoint-floor',default='253/2000')
    args=p.parse_args()
    try:
        report=compute(F(args.claim),F(args.old_claim),F(args.density_claim),F(args.endpoint_floor))
        if args.verify:
            require(canonical(strict_json(args.verify))==canonical(report),'stored candidate reconstruction mismatch')
        if args.output:
            with args.output.open('x') as f:
                f.write(json.dumps(report,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
        print('PASS: conditional LPW density/norm/headline successor; no scientific promotion')
    except (ValueError,ZeroDivisionError,OSError) as error:
        print('FAIL: '+str(error),file=sys.stderr)
        return 1
    return 0

if __name__=='__main__':
    raise SystemExit(main())
