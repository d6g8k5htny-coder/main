"""Finite replay and meaningful failures; these do not prove topology imports."""
import copy
from fractions import Fraction as F
import json
from pathlib import Path
import subprocess
import sys

import pytest
import lpw_headline as h

@pytest.fixture(scope='session')
def report():
    return h.compute()

def cli(*args):
    return subprocess.run([sys.executable,'-B',str(h.HERE/'lpw_headline.py'),*map(str,args)],
                          text=True,capture_output=True,timeout=120)

def test_replay(report):
    assert h.canonical(report)==h.canonical(h.strict_json(h.HERE/'result.json'))

def test_successor_scope_and_exact_number(report):
    s=report['successor']
    assert s['B3_ceiling']==8523327240 and s['K_ceiling']==1392
    assert F(s['exact_coefficient'])==F(13,468574870385996070912000)
    assert F(s['claimed_downward_floor'])==F('2.77e-23')
    assert F(s['radius'])==F(1,356352)
    assert len(report['imported_hypotheses'])==3
    assert report['scientific_promotion'] is False
    assert report['original_prize_closed'] is False

def test_old_decimal_repair(report):
    c=F(report['old_repaired_arithmetic']['exact_coefficient'])
    assert F('6.238e-44')<c<F('6.239e-44')

@pytest.mark.parametrize('flag,value,reason',[
 ('--claim','3e-23','claimed headline'),
 ('--old-claim','6.239e-44','claimed headline'),
 ('--density-claim','1/500','claimed density'),
 ('--endpoint-floor','13/100','nonpositive LDL')])
def test_bad_actual_cli_claims(flag,value,reason):
    p=cli(flag,value)
    assert p.returncode!=0 and reason in p.stderr

@pytest.mark.parametrize('change,reason',[
 ({'survival':F(1)},'Markov survival'),
 ({'volume_factor':64},'thin-box'),
 ({'determinant_power':3},'Hessian'),
 ({'radius':F(1,100000)},'radius exceeds')])
def test_exact_assembly_mutations(change,reason):
    with pytest.raises(ValueError,match=reason):
        h.assemble(8523327240,1392,F(1,1000),F('2.77e-23'),**change)

def test_uniform_density_is_pointwise_box_bound(report):
    d=report['conditional_density']
    assert F(d['density']['lo'])>F('0.001116')>F(1,1000)
    assert F(d['density']['hi'])<F('0.001126')
    assert len(d['schur_ldl_pivots'])==4
    assert all(F(p['lo'])>0 for p in d['schur_ldl_pivots'])

def test_covariance_floor_reproved(report):
    assert all(F(p['lo'])>0 for p in report['endpoint_shifted_ldl_pivots'])
    assert F(report['parameters']['endpoint_floor'])==F(253,2000)>F(31,250)

def test_ldl_known_matrix_and_solve():
    a=[[h.I(4),h.I(2)],[h.I(2),h.I(3)]]
    l,d=h.ldl(a)
    x=h.solve_ldl(l,d,[h.I(6),h.I(5)])
    assert d==[h.I(4),h.I(2)] and all(F(1) in v for v in x)

def test_ldl_catches_negative_direction():
    with pytest.raises(ValueError,match='nonpositive LDL'):
        h.ldl([[h.I(1),h.I(2)],[h.I(2),h.I(1)]])

def test_sharp_regression_bound_has_scalar_equality_witness():
    # Var X=9, V=X/6, Gamma=1/4, Cov(X,V)=3/2.
    # The deterministic regression operator is C/Gamma=6 exactly.
    actual=F(3,2)/F(1,4)
    correct=h.regression_operator(F(9),F(1,4))
    incorrect=h.sqrt(h.I(9),h.PREC)
    assert actual in correct and actual>incorrect.hi

def test_conditioning_cannot_use_unconditional_norm_directly():
    # f=Z in a scalar model. E|Z|^4=3, but conditioned on Z=2 it is 16.
    assert F(2)**4>3
    # With Gamma=1 and M=1, the regression term restores a valid triangle bound.
    assert (h.fourth_root(h.I(3))+2).lo**4>16

def test_global_markov_subtraction_does_not_preserve_rare_box():
    # P(E)=1/100, X=100 on E and 0 elsewhere: EX=1 but X>2 on all of E.
    probability=F(1,100)
    budget=F(1)
    assert probability*100==budget
    assert 100>2*budget
    assert probability-F(1,2)<0
    # Conditional EX|E=100 violates the hypothesized conditional budget 1.
    assert 100>budget

def test_density_normalization_uses_sqrt_determinant():
    cov=[[h.I(F(1,4) if i==j else 0) for j in range(4)] for i in range(4)]
    density,_=h.gaussian_density([h.I(0)]*4,cov,[h.I(0)]*4)
    exact_enclosure=4/h.pi(h.PREC)**2
    wrong=64/h.pi(h.PREC)**2
    assert density.lo<=exact_enclosure.hi and exact_enclosure.lo<=density.hi
    assert wrong.lo>density.hi

def test_density_mean_omission_is_an_overestimate():
    cov=[[h.I(int(i==j)) for j in range(4)] for i in range(4)]
    point=[h.I(0)]*4
    good,_=h.gaussian_density([h.I(2),h.I(0),h.I(0),h.I(0)],cov,point)
    wrong,_=h.gaussian_density(point,cov,point)
    assert wrong.lo>good.hi

@pytest.mark.parametrize('path,value',[
 (('successor','exact_coefficient'),'1/1000'),
 (('successor','Markov_survival'),'1'),
 (('conditional_density','density','lo'),'1/100'),
 (('scientific_promotion',),True),
 (('organizational_independence_credit',),False),
 (('imported_hypotheses',),[])])
def test_actual_certificate_mutations_rejected(tmp_path,report,path,value):
    mutated=copy.deepcopy(report)
    target=mutated
    for key in path[:-1]:
        target=target[key]
    target[path[-1]]=value
    candidate=tmp_path/'tampered.json'
    candidate.write_text(json.dumps(mutated))
    p=cli('--verify',candidate)
    assert p.returncode!=0 and 'reconstruction mismatch' in p.stderr

@pytest.mark.parametrize('text',['{"x":0,"x":1}','{"x":0.0}','{"x":NaN}'])
def test_untrusted_json_rejected(tmp_path,text):
    p=tmp_path/'bad.json'
    p.write_text(text)
    with pytest.raises(ValueError):
        h.strict_json(p)

def test_actual_regression_implementation_mutation(tmp_path,report):
    source=(h.HERE/'lpw_headline.py').read_text()
    source=source.replace('max_variance/eigenfloor','max_variance')
    # Keep only the source/dependency file beside the mutated executable.
    p=tmp_path/'lpw_headline.py'
    p.write_text(source)
    (tmp_path/'DEPENDENCIES.json').write_bytes((h.HERE/'DEPENDENCIES.json').read_bytes())
    run=subprocess.run([sys.executable,'-B',str(p),'--amplitude-dir',str(h.AMPLITUDE),
                        '--verify',str(h.HERE/'result.json')],text=True,capture_output=True,timeout=120)
    assert run.returncode!=0 and 'reconstruction mismatch' in run.stderr

def test_changed_dependency_rejected(tmp_path):
    data=h.strict_json(h.HERE/'DEPENDENCIES.json')
    repo=tmp_path/'repo'
    for name in data['repository']:
        p=repo/name
        p.parent.mkdir(parents=True,exist_ok=True)
        p.write_bytes((h.REPO/name).read_bytes())
    changed=repo/h.PREFIX/'raw_reports/LPW_CONSTANT_REPORT.md'
    changed.write_bytes(changed.read_bytes()+b'\n# changed\n')
    p=cli('--repo',repo)
    assert p.returncode!=0 and 'input identity mismatch' in p.stderr
