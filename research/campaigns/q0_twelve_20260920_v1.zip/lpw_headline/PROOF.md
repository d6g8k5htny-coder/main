# LPW exact headline chain and density/regression successor — candidate v1

For the source-defined normalized two-dimensional SIDE24 six-pin law, this
candidate establishes the numerical and analytic conditional-regression chain

`1 - q(r,6/5) >= [13 / 468574870385996070912000] r^3 > 2.77e-23 r^3`

for `0 < r <= 1/356352`, **conditional on the explicitly inherited LPW
coordinate identification and deterministic topology/weight theorem below**.
Every decimal used in an inequality denotes an exact rational. The old
historical arithmetic is separately reproduced and its unsafe `6.239e-44`
headline is rejected; `6.238e-44` is downward-safe for that old fraction.

The new lower-coefficient budget is more than `4.44e20` times the old budget.
This compares proved sufficient constants, not actual failure probabilities
or a limiting coefficient. Most of the gain comes from bounding the actual
four-dimensional Gaussian density, preserving its conditional covariance and
mean, instead of replacing its quadratic form by a loose global spectral
bound. The new density proof uses the entire original compact box and radius
range. It is not a sample, fit, or changed event.

**Status: CONDITIONAL_PROVED_CANDIDATE, source-exposed author work.** No source
status changes, external review, independent lineage, q0 upper theorem, RN
annulus, two-sided law, 3D composition, or original prize result follows.
Organizational independence credit is zero. This is an ordinary written
mathematical proof with exact interval arithmetic, not a proof assistant.

## 1. Exact object and inherited interfaces

The field has full-lattice spectral frequencies `k=(pi/12)(n,m)`, masses
`p_k=exp(-|k|^2/2)/Z1^2`, and covariance `sum p_k cos(k.(x-y))`, where
`Z1=sum_n exp(-(pi/12)^2*n^2/2)`. All moments in this computation include the
entire infinite lattice. No planar values such as 1, 3 or 15 are substituted.

The source gives a ten-coordinate centered Gaussian vector `V_r=(U_r,J)`.
Its Hermite six-pin vector limits to
`U_0=(f,fx,fy,fxx/2,fxy,fxxx/6)`, and
`J=(fyy,fxxy/2,fxyy/2,fyyy/6)`. Observed values are

`u_r=(b-r^3/12, -r^2/4, 0, 0, 0, 1/3)`, `b=6/5`.

The exact ten Fourier profiles and their derivative powers are those in the
pinned `research/parallel/lpw/ARGUMENT.md`. Their identification with the
original six-pin transformation is inherited, not independently rederived
here. This is the LPW law, not the different fixed-radius H3 calculation.

The remaining deterministic input is the source LPW topology/Taylor/weight
theorem, referenced by R05 and its constant report. Its original candidate
body has source-declared SHA-256
`cf58f72eb0399c626160c143b50f674ff3bd5c449225211edd6fd378a374e1a5`;
that body is **not consumed or hash-verified in this work**. The statements
imported through the hash-verified R05 exposition are precisely:

1. On the thin jet box described below, with `M4<=K` and
   `16 delta + 8 K r <= 3/64 < 1/16`, the prescribed local path event forces
   failure of the typed q event, and its Hessian pair weight is at least
   `65 r^4`.
2. For the same six-pin law, `Z_r <= 4 B3 r^2` if
   `E[M3^4 | U_r=u_r] <= B3`.
3. The weighted conditional expectation divided by this normalizer is the
   intended pair-Palm probability defining `1-q`.

Here `||f||Ck=max_{|alpha|<=k} sup |D^alpha f|`,
`M3=max(1,||f||C3)`, and `M4=max_{|alpha|=4} sup |D^alpha f|`.
These imported interfaces are not proved by checking their rational constants.
The code retains them as hypotheses in every result. No unconditional closure
is claimed by composing them.

## 2. Complete moments, quadratic covariance family and endpoint floor

The reused, hash-pinned covariance checker recomputes full spectral moments
through order 12 with finite cutoff 70 plus the entire geometric tails.
For the first omitted integer 71 and power p, the ratio
`exp(-a(2n+1)) (1+1/n)^p`, `a=(pi/12)^2/2`, decreases with n and is below
one half. Positive finite and omitted numerator bounds are divided by the
appropriate full-normalizer endpoints. The implementation uses exact rational
interval arithmetic from `research/interval`; precision is a tightness hint.

For source profiles `g_i(theta)` with `theta=k1*r/2`, the proved inequalities
`|g_i'| <= d_i |theta|` have
`d=(1,1,1,1/6,1/3,1/30,0,0,0,0)`. The nonconstant magnitude bound for g0 is
`1+k1^2*R^2/8`, with `R=1/100000`; all other bounds are the source profile
constants. Differentiation and integration give

`|Gamma_ij(r)-Gamma_ij(0)| <= C_ij r^2`,
`C_ij=(1/8) E[|k1|^(x_i+x_j+2) |k2|^(y_i+y_j) (d_i P_j+P_i d_j)]`.

Parity-annulled entries are zero. Full Gaussian tails justify dominated
summation and differentiation uniformly in r. Every `C_ij` is recomputed;
`sqrt(sum C_ij^2) < 1.804`. The whole closed interval `[0,R]` is therefore
contained in the entrywise interval matrix
`G_ij = Gamma_ij(0) + [-C_ij R^2, C_ij R^2]`.

The endpoint covariance is independently assembled from the full even
moments. For derivative powers `(x_i,y_i)`, scale factors
`(1,1,1,1/2,1,1/6,1,1/2,1/2,1/6)`, and even summed orders `(x,y)`, its entry
is `(-1)^(x_j+y_j+x/2+y/2) scale_i scale_j m_x m_y`; an odd sum gives zero.

Unlike the prior modulus result, this work does not import the endpoint
`31/250` lower bound. Interval LDL decomposition of
`Gamma_0-(253/2000)I` gives ten strictly positive pivot intervals. Interval
arithmetic encloses the deterministic LDL recursion for the actual matrix;
positive pivots prove positive definiteness by congruence. Thus

`lambda_min(Gamma_0) > 253/2000`,
`lambda_min(Gamma_r) >= lambda := 253/2000 - C_F R^2 > 0`,

where `C_F` is the computed Frobenius upper endpoint. All pivot endpoints
and the exact lambda are in `result.json`. The smallest endpoint pivot is
greater than `0.0000755`; this is an exact checked rational inequality.
Principal six-pin blocks inherit lambda by restricting quadratic forms.

## 3. A uniform direct Gaussian density bound

Put `delta=1/1024`. The thin event box has

`|q/(2r)+5|<=delta`, `|A-2|<=delta`, `|B|<=delta`, `|D3|<=delta`.

Its first coordinate has width `4 delta r`, so its volume is exactly
`32 delta^4 r`. For `0<r<=R` every such box lies inside

`JBOX=[-(10+2delta)R,0] x [2-delta,2+delta] x [-delta,delta]^2`.

The first-coordinate upper endpoint of each thin box is
`(-10+2delta)r<0`; its lower endpoint is no smaller than the displayed
lower endpoint. The other intervals agree exactly. Thus there is no loss
of the rare-event width under a rescaling.

Partition the covariance as `Gamma_r=[[A_r,B_r^T],[B_r,D]]`. Gaussian
conditioning gives `mu_r=B_r A_r^-1 u_r` and
`S_r=D-B_r A_r^-1 B_r^T`. We evaluate these formulas on the entire interval
matrix G and the entire interval vector of possible u values. A six-by-six
interval LDL factorization and triangular solves provide their enclosures.
Each off-diagonal Schur entry is computed once and used symmetrically;
this is valid because the actual Schur matrix is symmetric. Four positive
Schur LDL pivot intervals certify every actual conditional covariance.

If `S=L diag(d_i) L^T`, set `y=L^-1(j-mu)`. Then

`(j-mu)^T S^-1 (j-mu)=sum y_i^2/d_i`, `det S=product d_i`.

Interval triangular recursion and interval squares bound these expressions
for every `j in JBOX` and every `r in [0,R]`, with no mesh. The density is

`phi_r(j)=exp[-(sum y_i^2/d_i)/2] / ((2pi)^2 sqrt(product d_i))`.

The entire-family interval lies strictly inside the rational bounds

`0.001116 < phi_r(j) < 0.001126`.

In particular the chosen floor is **m=1/1000**. The finer exact endpoint
values are authoritative in `result.json` (descriptive decimals begin
0.001116884878722 and 0.001125716562598). This large gain over the historical
1e-21 sufficient floor does not change the box, field, pins, topology event,
or deterministic weight. It avoids replacing the actual quadratic form
by `(||j||+||mu||)^2/lambda`.

## 4. Sharper regression operator and valid conditional norm budgets

For any derivative `X=D^alpha f(x)` and Gaussian conditioning vector V with
covariance Gamma, let `c=Cov(X,V)`. Positivity of the joint covariance, or
nonnegativity of the residual variance, gives

`c Gamma^-1 c^T <= Var X <= M`.

If `Gamma>=lambda I`, spectral calculus gives
`Gamma^-2 <= lambda^-1 Gamma^-1`. Hence

`||c Gamma^-1||_2^2 <= M/lambda`.

The deterministic regression field `L v=Cov(f,V) Gamma^-1 v` therefore
satisfies `||L||_(Euclidean -> Ck) <= sqrt(M_2k/lambda)`. This is uniform in
x, all derivatives through order k and r, since all their variances are
bounded by the maximum of the recomputed product moments. The max norm
allows the supremum of these scalar bounds without a derivative-count factor.
This sharp inequality replaces the looser Cauchy–Schwarz bound involving
`trace(Gamma)/lambda^2`. The scalar model `Var X=9`, `V=X/6` has
`Gamma=1/4` and operator norm 6, attaining the new formula; it refutes
omitting the inverse-eigenvalue factor.

Set `g=f-LV`. For a continuous C4 Gaussian version, all finite collections
of g evaluations and derivatives have zero covariance with V. Gaussian
independence, followed by a countable dense-set/continuity argument, makes
the whole residual field independent of V. Thus the chosen continuous
regression version at every v is `g+Lv`. The residual need not be stationary.
Minkowski and the deterministic operator bound give

`(E[M3^4 | U=u])^(1/4)`
`<= 1 + (E||f||C3^4)^(1/4)`
`   + A3 ((E||U||_2^4)^(1/4) + ||u||_2)`.

For a centered Gaussian vector with covariance A, Isserlis gives
`E||U||_2^4=(tr A)^2+2||A||_F^2`. Both terms are bounded from the full
interval matrix. For conditioning on all ten coordinates,

`E[M4 | V=v] <= E||f||C4 + A4 (sqrt(tr Gamma)+||v||_2)`.

The sibling amplitude computation is byte-pinned, re-executed and compared
field-for-field with its saved result on every replay. Its written Rayleigh
majorant proof establishes
`E||f||C3^4<4727655047` and `E||f||C4<536.605087` for the same max norm and
full-lattice field. The present formulas explain why those unconditional
ingredients can be used here; they are never substituted directly for
conditional moments.

Exact interval substitution yields

`A3 < 10.89`, `A4 < 28.811`,
`B3 < 8523327240`, `B4 < 696`, `K=max(1,2 B4) <= 1392`.

B4 is uniform for both the pins and **every j in JBOX**. B3 is uniform for
six-pin conditioning alone. No unconditional tail loss is subtracted from
a rare conditional box probability.

## 5. Conditional Markov, exact coefficient and radius

Take `K=1392` and `r0=1/(256 K)=1/356352<R`. Uniform conditional Markov gives

`P(M4<=K | U=u_r, J=j) >= 1-B4/K >= 1/2`

for every j in JBOX under the explicit regression version. Integrating over
the thin box first, using its density floor and then the deterministic
weight lower bound, gives numerator at least

`65 r^4 * (1/2) * m * (32 delta^4 r) = 1040 m delta^4 r^5`.

The imported normalizer inequality gives denominator at most `4 B3 r^2`.
Their quotient is therefore at least

`(260 m delta^4 / B3) r^3`.

With the upward integer B3 and the downward rational m this is exactly

`c_exact=260/(1000 * 8523327240 * 2^40)`
`       =13/468574870385996070912000 > 2.77e-23`.

The scale checks are exact:
`16 delta+8 K r0=3/64<1/16`,
`1/6-99/1280-1/16=103/3840>0`,
`(81/16)(1673/128)>=65`, and exponent `1+4-2=3`.
These arithmetic checks do not independently prove the imported topology.

For the historical budgets only, the separately labelled replay uses
`B3=3790446482793`, `K=9432`, `m=10^-21`, giving
`c_old=260/(3790446482793 * 2^40 * 10^21)`.
Exact integer comparison gives
`6.238e-44 < c_old < 6.239e-44`. Hence the latter printed decimal cannot be
admitted as a lower bound from that old fraction. No frozen source is edited.
The new candidate is a distinct successor; it does not retroactively repair
an invalid displayed equality by silently replacing its inputs.

## 6. Custody, execution and retained failure cases

The parent verified R17 claim `60663b69-45c3-431d-b27c-33c13695d2d7`, target
`Q0-P12-LPW-HEADLINE-20260920-v1`, Work Events row 76. This worker writes only
its scratch directory. All original source bytes are read, never executed.
No vault, legacy or excluded quarantine body is consumed. `DEPENDENCIES.json`
pins every reused module, written argument, amplitude result and R05 source;
`MANIFEST.json` records all deliverables and exact Drive identities.

`RUN.json` contains explicit normal, optimized and test argument arrays.
The checker recomputes the lattice, matrix family, density, field amplitude,
conditional norms and headline. Data-only candidate JSON must match the entire
fresh typed reconstruction. Duplicate keys, floating JSON literals and
Boolean-as-zero status mutations are rejected. Source/dependency identities
are checked both before and after the run.

Negative controls exercise the actual CLI with an oversized old or new
headline, excessive density floor and false endpoint eigenfloor. Other
controls retain the lost one-half Markov factor, correct thin-box width,
Hessian exponent, radius, density mean, square-root determinant, conditional
versus unconditional norm distinction and sharp regression scalar witness.
An actual operator-implementation mutation and tampered candidate artifacts
are rejected by replay. Tests are finite diagnostics supporting this ordinary
analytic proof; they do not discharge inherited topology or review gates.
