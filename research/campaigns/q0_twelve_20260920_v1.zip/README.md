# Twelve distinct mathematical projects for q0

Twelve separate project agents, with three workers active at a time under the
available concurrency limit, plus an additional LPW source-review agent. The
extra reviewer hit the account usage limit partway through; its partial findings
are not a completed verdict. The parent completed the written interface audit. This campaign supplies proved lemmas, explicit
conditional results and counterexamples. It does not declare q0, Theorem B, or
any original prize problem solved. All agents belong to the same provider;
organizational independence credit is zero.

| Project | Result or current work | Application still needed |
|---|---|---|
| 1. H3 uniform | Fixed-axis covariance floor 81/6400 through r=1/20; Z(r)/r² tends to a value above 3.23097 | Numeric radius for Z(r)>=3r²; all-angle extension |
| 2. H3 ceiling | At r=1/20, Z/r² <=3.230674239349; historical float-tail enclosure defect | Uniform-radius upper bound |
| 3. LPW amplitude | Full-lattice Rayleigh bounds: E||f||C3^4<4727655047 and E||f||C4<536.605087 | Conditional regression when used under pins |
| 4. Two-jet band | Exact gradient-increment covariance enclosures on [0,1/20] | Full 24-jet definitions and conditioning |
| 5. LPW constant | Conditional coefficient >2.77e-23 for r<=1/356352; improved whole-box density and regression | Original deterministic topology/weight and q/Palm interface |
| 6. Persistence count | Elder-selected directed pairs biject with finite H0 bars under binary event interface | Actual continuum reduction, Borel atlas and genericity |
| 7. Contact transport | Exact six-pin determinant, lifetime Jacobian, moving cutoff and weighted-selection identity | Kac–Rice applicability and actual contact/selection limits |
| 8. Full-mark tails | Explicit small-kappa, large-kappa and birth-height integrated errors | Actual all-angle Gaussian constants and selection convergence |
| 9. Weighted event | Correct square-root bound; conditioning-first linear window bound with exact Gaussian quartic envelope | Event geometry and actual coefficient/rate inputs |
| 10. Lambda | Exact finite-jet and midpoint counterexamples; valid C3 and C4-assisted replacements | Actual model derivative bounds and positive margins |
| 11. Gaussian tube | Three-component C1 chaining; dimensional scaling; reversed probability implication corrected | Actual nominal path geometry and uniform input bounds |
| 12. Pair loss | Optimized integer-count bound, weighted loss budget and exact eta distinction | Actual weighted event counts and losses |

Each project folder contains a written proof, deterministic result, source
identities, adversarial tests and replay instructions. `PARENT_REVIEW.md` records
mathematical review; finite tests supplement the proofs. The combined replay plan
binds all twelve frozen candidates and the exact repository dependencies,
recomputes their reports, compares output bytes and retains every exit status.
Author tests pass in both normal and optimized Python: 320 tests per mode.
The fresh combined outcome is recorded in verification/verification_receipt.json.

Replay locally with Python 3.11 or later:

```sh
python3.11 -B verify_campaign.py --output-dir /absolute/new/replay-directory --jobs 3
```

The output directory must be new and outside both this bundle and the repository.
The plan pins the local repository dependencies; a changed input fails closed.

`LPW_INTERFACE_AUDIT.md` checks the original deterministic source and explains
why the improved elder-pairing coefficient does not automatically apply to a
gradient-adjacency event.

`SOURCE_BOUNDARY.md` records a provenance error caught during intake and its
correction. A recovered quarantine/history script is excluded from evidence and
delivery. `read_source_v2.py` is the corrected permitted-source reader.

The separate repository task owns integration, the RN near-annulus calculation,
and private Drive/GitHub publication. This directory is an author-side candidate
bundle, not a second governance or claim register. Canonical statuses remain
unchanged.
