# Parent mathematical review — twelve-project candidate campaign

This is an author-side integration review, not independent organizational review,
formal proof-assistant validation, or canonical promotion. Each project retains
its stated hypotheses. Fresh execution is recorded separately from this review.

1. **H3 uniform:** Read the integral pin identities, the L2 covariance transport,
   endpoint LDL certificate, Gaussian conditional convergence and uniform
   integrability argument. The result is fixed-axis: an explicit covariance floor
   and a positive normalized normalizer limit. The radius in Z(r)>=3r² is
   existential, not a certified numeric band. An unscaled positive floor cannot
   persist to r=0.
2. **H3 ceiling:** Read the half-space Gaussian regression/Wick calculation and
   truncated normal recurrence. The two factors in Cauchy–Schwarz use the same
   necessary half-space, without an independence assumption. This is r=1/20
   only. The positive-tail-to-binary-float underflow witness is a defect in a
   historical enclosure routine, not a disproof of its final printed ceiling.
3. **LPW amplitude:** Checked the independent full-Z² cosine/sine representation,
   Rayleigh fourth moment 8, Tonelli/Minkowski passage, max-over-multiindices
   majorant, exact square-shell aggregation and full normalizer/tails. The
   improved numbers are unconditional sufficient norm budgets. They are not
   actual field moments or conditional bounds by themselves.
4. **Two-jet band:** Read the exact H2 gradient-increment definitions and the
   image/tail estimates on the whole radius interval, including r=0 by continuous
   extension. The two-coordinate unconditioned block is proved; the complete
   historical 24-jet interface is still insufficiently defined. No excluded H5
   certificate was consumed and no full 24-jet conclusion is inferred.
5. **LPW headline:** Read the whole-box Schur LDL Gaussian density enclosure,
   ten positive endpoint LDL pivots, conditional regression argument and exact
   Markov/volume/weight quotient. Checked Fourier-profile signs against the
   permitted R05 raw report: its g5=-1/6 multiplies i*k1³, hence agrees with
   fxxx/6 at the endpoint. The projection inequality
   ||Cov(X,V)Gamma^-1||² <= Var(X)/lambda follows from residual nonnegative
   variance and spectral calculus. Conditional field norms follow by the
   independent Gaussian residual field and triangle inequality; the
   unconditional amplitude budget is not substituted directly. The exact
   coefficient and radius are conditional on the explicitly listed LPW
   six-pin identification, deterministic topology/weight theorem and q/Palm
   version. Those inputs are not proved by this candidate.
6. **Persistence multiplicity:** Read the finite event induction and full rank
   invariant argument, the separate boundary-matrix rank oracle, Borel chart
   construction and first-moment domination. Essential classes and loops are
   excluded correctly; selected pairs need not be endpoint-adjacent in the
   stated graph interface. The counterexample is not a realization theorem
   for the actual Gaussian surface. Actual continuum reduction and genericity
   remain hypotheses.
7. **Contact transport:** Read the full midpoint/polar and height Jacobians,
   corrected six-pin inverse, density transform, Hessian power cancellation,
   weighted-Palm counterexample and Tonelli proof for Borel test functions.
   Directed types require no half factor. The cutoff kappa>6ell/r_c³ remains
   in the exact formula. The fold polynomial and 21/4 integral witness check
   the signs and normalizations; neither establishes a random contact limit.
8. **Full-mark tails:** Read the determinant/trace quadratic floor, Gaussian
   quartic majorant and all three integrated tail bounds. Checked the two-sided
   fourth-moment recurrence, small-kappa factor 3 and compact-error volume
   12*pi*H*(R^(1/3)-delta^(1/3)). The numeric demonstrations have hypothetical
   envelope/model constants and are not actual all-angle SIDE24 certificates.
   Actual all-angle covariance bounds and selected-contact convergence remain
   explicit application hypotheses.

9. **Weighted event repair:** Read the event inclusion and both absolute and
   conditional loss inequalities, weighted Kac–Rice disintegration, Cantelli sign
   cases and conditioning-first linear window bound. The Gaussian second moment
   polynomial and Bernstein envelope apply to the stated W=1 test law; actual
   nontrivial Palm weights require their own higher-moment envelope. Uniform
   spatial integrability includes the shrinking normalizer and conditional
   variance, so the displayed cubic rate is conditional on a real additional
   hypothesis, not inferred from window width alone.
10. **Lambda replacement:** Read the exact finite-jet obstruction and x^4
    midpoint counterexample, third-order product/chain profiles, positive typed
    box lemma and C4-assisted grid theorem. Verified the Euclidean square-net
    radius h/sqrt(2), the central-stencil B4*h/2 error, operator tensor
    reconstruction and their combined sqrt(2)*(Q+B4*h) constant. Actual
    ingredient bounds, negative trace and variance/typing margins remain
    inputs; the Gaussian synthetic example is not the source Lambda.

11. **Gaussian tube:** Read the full infinite dyadic chaining argument, including
    the base-grid count, all signed component increments, summable probability
    allocation, continuity passage and mean mismatch. Checked the weighted
    derivative units and the strict success-ball contract, as well as the
    all-small-r hypothetical family. The reversed implication in source D2 is
    confirmed from the original permitted body. The agent hit a usage limit
    after saving a manifest and both-mode passing receipts; parent verification
    establishes the artifact state, not a missing final message.
12. **Count and eta:** Read the all-integer quadratic minorant and optimized
    moment bound, its exact moment-matching extremal law, continuum liminf
    argument and marked-loss integration. Checked that O(r³) factorial moments
    can retain a positive cubic coefficient but o(r³) is needed by this bound
    to retain the full first-moment coefficient. Direct elder-failure inclusion
    requires no eta debit; the adjacency-product proxy does. Shared pins or
    unweighted small probabilities do not identify these events or laws.

Mathematical scope is not enlarged by running twelve agents, passing tests, or
agreeing on a result. Each writer belongs to the same provider.

After project 5 froze, the parent recovered the original LPW candidate by its
exact body SHA using eligible active-package metadata. It is now preserved in
sources/LPW-CAND-20260912. An additional reviewer began auditing the deterministic
interface and hit the account usage limit before issuing a verdict. The parent
completed a written source audit in LPW_INTERFACE_AUDIT.md. This later read does not alter project 5's frozen custody
statement or retrospectively remove its explicit hypotheses. A separate review
records any further conclusion.

Source-intake exposure and correction are recorded in SOURCE_BOUNDARY.md. The
recovered quarantine/history script is excluded from all mathematical evidence
and delivery. This review does not erase that incident.
