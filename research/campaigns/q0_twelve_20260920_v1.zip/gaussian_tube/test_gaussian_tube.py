"""Meaningful deterministic and CLI negative controls; standard-library only."""
from fractions import Fraction as F
import copy
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
import gaussian_tube as g

HERE=Path(__file__).resolve().parent

class TubeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.backend=g.load_backend(g.DEFAULT_REPO)
        cls.report=g.run()
        cls.temp_root=HERE/'.test-work'
        cls.temp_root.mkdir(exist_ok=True)

    @classmethod
    def tearDownClass(cls):
        cls.temp_root.rmdir()

    def temp(self):
        return tempfile.TemporaryDirectory(dir=self.temp_root)

    def cli(self,*args,optimized=False,script=None):
        cmd=[sys.executable,'-B']+(['-O'] if optimized else [])+[str(script or HERE/'gaussian_tube.py'),*map(str,args)]
        return subprocess.run(cmd,text=True,capture_output=True,timeout=30)

    def test_baseline_report_exact(self):
        self.assertEqual(g.encode(self.report),(HERE/'result.json').read_bytes())

    def test_full_component_counts(self):
        c=g.cover_certificate()
        self.assertEqual(c['prefactor'],24)
        self.assertEqual(c['levels'][0]['signed_tests'],54)
        self.assertEqual(c['levels'][-1]['n'],16)

    def test_missing_component_rejected(self):
        for bad in (1,2,4):
            with self.subTest(bad=bad),self.assertRaises(ValueError):g.cover_certificate(components=bad)

    def test_unsummable_entropy_rate_rejected(self):
        with self.assertRaisesRegex(ValueError,'entropy'):g.cover_certificate(rate=2)

    def test_domain_dimension_rejected(self):
        with self.assertRaises(ValueError):g.cover_certificate(dimension=3)

    def test_weighted_derivative_units(self):
        v,l=g.component_envelope((1,F(1,10),F(1,10)),(1,2,3),((2,3),(5,7),(7,11)))
        self.assertEqual((v,l),(F(1),F(5)))
        v2,l2=g.component_envelope((1,1,1),(1,2,3),((2,3),(5,7),(7,11)))
        self.assertEqual((v2,l2),(F(3),F(18)))

    def test_derivative_component_not_silently_dropped(self):
        with self.assertRaises(ValueError):g.component_envelope((1,1),(1,1),((1,1),(1,1)))
        with self.assertRaises(ValueError):g.component_envelope((1,1,1),(1,1,1),((1,),(1,1),(1,1)))

    def test_incorrect_gradient_units_rejected(self):
        with self.assertRaises(ValueError):g.component_envelope((1,1,2),(1,1,1),((1,1),)*3)
        with self.assertRaises(ValueError):g.component_envelope((1,0,0),(1,1,1),((1,1),)*3)

    def test_negative_inputs_rejected(self):
        for args in ((-1,1,1,1),(1,-1,1,1),(1,1,-1,1),(1,1,1,-1)):
            with self.subTest(args=args),self.assertRaises(ValueError):g.chaining_bound(*args,self.backend)

    def test_inexact_inputs_rejected(self):
        for bad in (0.1,True):
            with self.subTest(bad=bad),self.assertRaises(ValueError):g.chaining_bound(bad,1,1,1,self.backend)

    def test_zero_random_scale_explicitly_separate(self):
        with self.assertRaises(ValueError):g.chaining_bound(0,0,1,1,self.backend)

    def test_insufficient_clearance_rejected(self):
        with self.assertRaisesRegex(ValueError,'clearance'):g.clearance_certificate(1,1,0,1,1,self.backend)

    def test_mean_error_can_destroy_clearance(self):
        g.clearance_certificate(F(1,100),F(1,100),0,1,1,self.backend)
        with self.assertRaisesRegex(ValueError,'clearance'):
            g.clearance_certificate(F(1,100),F(1,100),1,1,1,self.backend)

    def test_barrier_inequality_counterexample(self):
        c=g.barrier_counterexample()
        self.assertTrue(c['claimed_lower_bound_is_false'])
        self.assertEqual(c['actual_capture_on_arrival'],'0')
        self.assertEqual(c['correct_upper_bound'],'9/20')
        with self.assertRaisesRegex(ValueError,'premise'):g.barrier_counterexample(1,1,F(1,10))

    def test_entropy_counterexample_certified(self):
        c=self.report['entropy_counterexample']
        self.assertGreater(F(c['maximum_failure_lower']),F(4,5))
        self.assertLess(F(c['variance_only_2exp_minus_t2_over2']['hi']),F(1,40))

    def test_units_match_exact_window_scaling(self):
        for c in self.report['units']:
            r=F(c['r'])
            self.assertEqual(F(c['height_scale_kappa_r3']),r**3)
            self.assertEqual(F(c['physical_gradient_scale_kappa_r2']),r**2)
            self.assertEqual(F(c['weighted_gradient_scale_r_times_kappa_r2']),r**3)

    def test_cli_replays_identically_in_both_modes(self):
        with self.temp() as d:
            outputs=[]
            for optimized in (False,True):
                out=Path(d)/('optimized.json' if optimized else 'normal.json')
                result=self.cli('--verify',HERE/'result.json','--output',out,optimized=optimized)
                self.assertEqual(result.returncode,0,result.stderr)
                self.assertIn('PASS:',result.stdout)
                outputs.append(out.read_bytes())
            self.assertEqual(outputs[0],outputs[1])

    def test_cli_changed_source_rejected_in_both_modes(self):
        with self.temp() as d:
            source=Path(d)/'source'
            shutil.copytree(HERE/'source',source)
            with (source/'source.raw').open('ab') as f:f.write(b'\nchanged')
            for optimized in (False,True):
                result=self.cli('--source-dir',source,optimized=optimized)
                self.assertNotEqual(result.returncode,0)
                self.assertIn('source payload mismatch',result.stderr)
                self.assertNotIn('PASS:',result.stdout)

    def test_cli_wrong_source_context_rejected_in_both_modes(self):
        with self.temp() as d:
            source=Path(d)/'source'
            shutil.copytree(HERE/'source',source)
            meta=json.loads((source/'IDENTITY.json').read_text())
            meta['inventory']['context']='QUARANTINED'
            (source/'IDENTITY.json').write_text(json.dumps(meta))
            for optimized in (False,True):
                result=self.cli('--source-dir',source,optimized=optimized)
                self.assertNotEqual(result.returncode,0)
                self.assertIn('nonresearch source context',result.stderr)

    def test_cli_report_tampering_rejected_in_both_modes(self):
        with self.temp() as d:
            for target in ('theorem','hypothetical_uniform_family','barrier_direction_counterexample'):
                bad=copy.deepcopy(self.report)
                bad[target]='MUTATED'
                file=Path(d)/(target+'.json')
                file.write_bytes(g.encode(bad))
                for optimized in (False,True):
                    result=self.cli('--verify',file,optimized=optimized)
                    self.assertNotEqual(result.returncode,0)
                    self.assertIn('report differs',result.stderr)

    def test_cli_existing_output_preserved(self):
        with self.temp() as d:
            target=Path(d)/'exists.json'
            target.write_bytes(b'preserve')
            result=self.cli('--output',target)
            self.assertNotEqual(result.returncode,0)
            self.assertEqual(target.read_bytes(),b'preserve')

    def test_actual_implementation_mutations_rejected_both_modes(self):
        text=(HERE/'gaussian_tube.py').read_text()
        mutations=(
            ('entropy','def cover_certificate(components=3, dimension=2, rate=3):','def cover_certificate(components=3, dimension=2, rate=2):'),
            ('clearance','require(mu > bound.hi,','require(mu < bound.hi,'),
            ('missing_component','def cover_certificate(components=3, dimension=2, rate=3):','def cover_certificate(components=2, dimension=2, rate=3):'),
            ('tail_budget','tail=2*exp(I.exact(-exact(u)),40)','tail=exp(I.exact(-exact(u)),40)'),
        )
        with self.temp() as d:
            for name,old,new in mutations:
                self.assertEqual(text.count(old),1)
                script=Path(d)/(name+'.py')
                script.write_text(text.replace(old,new))
                for optimized in (False,True):
                    result=self.cli('--source-dir',HERE/'source','--verify',HERE/'result.json',optimized=optimized,script=script)
                    self.assertNotEqual(result.returncode,0,(name,result.stdout,result.stderr))
                    self.assertNotIn('PASS:',result.stdout)

if __name__=='__main__':
    unittest.main(verbosity=2)
