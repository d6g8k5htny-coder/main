#!/usr/bin/env python3
"""Conditional Gaussian C1 tube bounds, exact arithmetic; no scientific promotion.

The continuum theorem is proved in PROOF.md. This executable replays its finite
constants, source custody, counterexamples and a hypothetical uniform family.
It does not supply the SIDE24 third-saddle tube or its variance/clearance data.
"""
from __future__ import annotations
import argparse
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
DEFAULT_REPO = Path('/Users/dylanroy/Documents/Codex/research-main')
SOURCE_ID = '1ff-sfJKUg8kO4G5JcBGMn0jyErKAp1lz'
SOURCE_SHA = 'd6bde0636b400d995f889e55446892631f3c2d462e060b34c27532fbd4a05bfd'
DEPENDENCIES = {
    'research/interval/__init__.py': (2371, 'a6a185d24615288dde72ff00e66e2927787279d42d518b6d81ce9edd5a6bdb8e'),
    'research/interval/core.py': (21974, '3f9e699cdb215957c38f9a7837de1e7e56b175a5d0d0a5cda111700576d3dffa'),
    'research/interval/transcendental.py': (51153, '7db4b5a6d868a731413e9f1a7f39bdf9d4b7209edce29142265cd0ed612cc8b6'),
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def identity(path):
    raw = Path(path).read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def load_backend(repo):
    repo = Path(repo).resolve()
    for name, (size, sha) in DEPENDENCIES.items():
        require(identity(repo/name) == {'bytes':size, 'sha256':sha}, 'repository dependency mismatch: '+name)
    sys.path.insert(0, str(repo))
    from research.interval import Interval, exp, log, normal_sf, sqrt
    return Interval, exp, log, normal_sf, sqrt


def verify_source(source_dir=HERE/'source', repo=DEFAULT_REPO):
    source_dir, repo = Path(source_dir), Path(repo)
    raw = identity(source_dir/'source.raw')
    require(raw == {'bytes':22934, 'sha256':SOURCE_SHA}, 'source payload mismatch')
    meta = json.loads((source_dir/'IDENTITY.json').read_text())
    require(meta['drive_id'] == SOURCE_ID, 'source ID mismatch')
    for row in (meta['inventory'], meta['coverage']):
        require(row['context'] == 'RESEARCH_SOURCE_CHECK_STATUS', 'nonresearch source context')
        require(row['sha256'] == SOURCE_SHA and row['bytes'] == 22934, 'source metadata identity mismatch')
    path = meta['inventory']['path']
    require(path.startswith('01_ACTIVE_RESEARCH_PACKAGES/'), 'not an active source')
    require(not any(x in path.lower() for x in ('legacy','quarantine','99_do_not_open')), 'prohibited source path')
    exclusions = json.loads((repo/'quarantine/EXCLUSIONS.json').read_text())['exclusions']
    require(not any(x.get('carrier_id') == SOURCE_ID and x.get('kind') == 'drive_object' or x.get('payload_sha256') == SOURCE_SHA for x in exclusions), 'source is excluded')
    return {'drive_id':SOURCE_ID, **raw, 'scope':'corrected source definition and D2 counterexample; no inherited theorem grade'}


def exact(value):
    require(not isinstance(value, (float,bool)), 'inexact or Boolean input')
    return F(value)


def interval_json(value):
    value = value.round_out(100)
    return {'lo':str(value.lo), 'hi':str(value.hi)}


def cover_certificate(components=3, dimension=2, rate=3):
    """A dyadic increment union budget uses rate >= dimension+1."""
    require(type(components) is int and components == 3, 'all three C1 components required')
    require(type(dimension) is int and dimension == 2, 'two spatial dimensions required')
    require(type(rate) is int and rate >= dimension+1, 'entropy budget cannot be summed with the declared 2^-n allocation')
    prefactor = 2*components*2**dimension
    levels = []
    for n in range(1,17):
        count = (2**n+1)**dimension
        signed_tests = 2*components*count
        envelope = prefactor*2**(dimension*n)
        ratio = F(signed_tests, prefactor*2**(rate*n))
        require(signed_tests <= envelope, 'dyadic count bound failed')
        require(ratio <= F(1,2**n), 'increment tail allocation failed')
        levels.append({'n':n, 'points_per_component':count, 'signed_tests':signed_tests, 'tail_factor':str(ratio)})
    # Exact infinite-series identities, proved by their geometric generating function.
    require(F(1,2)/(1-F(1,2)) == 1, 'sum 2^-n')
    require(F(1,2)/(1-F(1,2))**2 == 2, 'sum n*2^-n')
    return {'components':components, 'dimension':dimension, 'prefactor':prefactor,
            'increment_entropy_rate':rate, 'sum_2_to_minus_n':'1',
            'sum_n_2_to_minus_n':'2', 'levels':levels}


def component_envelope(weights, point_stds, gradient_stds):
    """C1 physical units: weights=(1,h,h); increments use derivative L2 sums."""
    require(len(weights)==len(point_stds)==len(gradient_stds)==3, 'three components are mandatory')
    w, v = tuple(map(exact, weights)), tuple(map(exact, point_stds))
    require(w[0] == 1 and w[1] == w[2] and w[1] > 0, 'weights must be (1,h,h), h>0')
    require(all(x >= 0 for x in v), 'negative standard deviation')
    rows=[]
    for j, row in enumerate(gradient_stds):
        require(len(row)==2, 'both spatial derivatives required')
        row=tuple(map(exact,row))
        require(all(x>=0 for x in row), 'negative derivative standard deviation')
        rows.append(w[j]*sum(row))
    return max(w[j]*v[j] for j in range(3)), max(rows)


def chaining_bound(v, ld, a, u, backend):
    """P(norm_h(m-m_nom+E)>B) <= 2 exp(-u), provided the stated interface."""
    I, exp, log, sf, sqrt=backend
    v,ld,a,u=map(exact,(v,ld,a,u))
    require(v>=0 and ld>=0 and a>=0 and u>=0, 'negative tube parameter')
    require(v+ld>0, 'use deterministic handling when the stochastic scale is zero')
    return I.exact(a)+(v+ld)*sqrt(I.exact(2*(u+4)),40)+5*ld


def clearance_certificate(v, ld, a, u, mu, backend):
    mu=exact(mu)
    bound=chaining_bound(v,ld,a,u,backend)
    require(mu > bound.hi, 'clearance does not strictly exceed the certified tube threshold')
    I,exp,log,sf,sqrt=backend
    tail=2*exp(I.exact(-exact(u)),40)
    return {'threshold':interval_json(bound), 'clearance':str(mu),
            'strict_gap_lower':str(mu-bound.hi), 'failure_upper':str(min(F(1),tail.hi))}


def barrier_counterexample(arrival=F(1,2), conditional_capture=F(0), c=F(1,10)):
    arrival,conditional_capture,c=map(exact,(arrival,conditional_capture,c))
    require(0<=arrival<=1 and 0<=conditional_capture<=1 and 0<c<=1, 'invalid probabilities')
    require(conditional_capture<=1-c, 'premise is false')
    actual=arrival*conditional_capture
    upper=(1-c)*arrival
    return {'arrival':str(arrival),'conditional_capture':str(conditional_capture),
            'barrier_success_floor':str(c),'actual_capture_on_arrival':str(actual),
            'correct_upper_bound':str(upper),'claimed_lower_bound_is_false':actual<upper}


def run(repo=DEFAULT_REPO, source_dir=HERE/'source'):
    backend=load_backend(repo)
    I,exp,log,sf,sqrt=backend
    source=verify_source(source_dir,repo)
    cover=cover_certificate()
    # The rounded elementary constants cover every u>=0, not only a grid.
    ln24=log(I.exact(24),40)
    ln2=log(I.exact(2),40)
    require(ln24.hi<4, 'log(24)<4 failed')
    require(6*ln2.hi<F(25,4), 'sqrt(6 log2)<5/2 failed')
    # All-continuum hypothetical family proof, r<=1/100.
    require(F(52,25)<F(9,4), 'sqrt factor enclosure failed')
    uniform_factor=F(1,10)+3*F(1,10)+5*F(1,100)
    require(uniform_factor == F(9,20) and uniform_factor<F(1,2), 'uniform tube margin failed')
    examples=[]
    for r in (F(1,100),F(1,200),F(1,500)):
        cert=clearance_certificate(r**4,r**4,r**3/10,1/r,r**3/2,backend)
        examples.append({'r':str(r),'u':str(1/r),**cert})
    # Rate scale and entropy counterexamples use exact interval Gaussian tails.
    scalar_tail=2*sf(I.exact(3),40)
    require(scalar_tail.lo>F(1,500), 'normal tail lower bound failed')
    independent_failure=1-(1-F(1,500))**1000
    require(independent_failure>F(4,5), 'independent Gaussian maximum lower bound failed')
    false_tail=2*exp(I.exact(F(-9,2)),40)
    require(false_tail.hi<F(1,40), 'false variance-only upper threshold failed')
    entropy={'independent_coordinates':1000,'point_variance':'1','threshold':'3',
             'one_coordinate_abs_tail':interval_json(scalar_tail),
             'maximum_failure_lower':str(independent_failure),
             'variance_only_2exp_minus_t2_over2':interval_json(false_tail)}
    mean_example={'centered_residual':'identically zero','nominal_mean_error':'1',
                  'clearance':'1/2','failure_probability':'1',
                  'conclusion':'A centered-residual bound without deterministic mean mismatch does not control nominal tube escape.'}
    derivative_example={'field':'E(x,y)=Z*x on [-1,1]^2','weight_h':'1',
                        'field_value_at_origin':'0','derivative_x':'Z','point_variance_at_origin':'0',
                        'conclusion':'A value-only bound at the pin omits the derivative component.'}
    rates=[]
    for p in range(1,9):
        m=p+1
        # e^x >= x^m/m! gives 2 exp(-1/r)/r^p <= 2 m! r.
        factorial=1
        for j in range(1,m+1): factorial*=j
        rates.append({'p':p,'m':m,'coefficient_of_r_after_dividing_by_r_to_p':str(2*factorial)})
    units=[]
    for r in (F(1,20),F(1,40)):
        units.append({'r':str(r),'height_scale_kappa_r3':str(r**3),
                      'physical_gradient_scale_kappa_r2':str(r**2),
                      'weighted_gradient_scale_r_times_kappa_r2':str(r**3),
                      'source_endpoint_height_margin':str(F(65,256)*r**3)})
    v,l=component_envelope((1,F(1,10),F(1,10)),(1,2,3),((2,3),(5,7),(7,11)))
    require(v==1 and l==5, 'derivative units envelope failed')
    return {
        'schema':'gaussian-c1-tube-candidate-v1','project':'gaussian_tube',
        'technical_status':'CONDITIONAL_THEOREM_AND_SOURCE_LOGIC_COUNTEREXAMPLE',
        'canonical_status_changed':False,'organizational_independence_credit':0,'original_prize_closed':False,
        'source':source,'dependencies':{k:{'bytes':n,'sha256':s} for k,(n,s) in DEPENDENCIES.items()},
        'norm':'max(sup|E|, h sup|partial_x E|, h sup|partial_y E|), h>0',
        'theorem':{'interface':'Centered jointly Gaussian continuous component fields on a square of side D; variance <=v^2 and canonical metric <=L times l_infinity distance for all three scaled components; deterministic nominal/conditional-mean mismatch <=a.',
                   'ld':'L*D','threshold':'a+(v+L*D)*sqrt(2*(u+4))+5*L*D',
                   'tail_upper':'2*exp(-u), u>=0','clearance_condition':'mu strictly greater than the threshold',
                   'rate_sufficient':'((mu-a-5LD)/(v+LD))^2/2 - p*log(1/r) tends to +infinity, with mu>a+5LD',
                   'all_power_sufficient':'(mu-a-5LD)/((v+LD)*sqrt(2 log(1/r))) tends to +infinity'},
        'cover':cover,'elementary_constant_enclosures':{'log24':interval_json(ln24),'log2':interval_json(ln2)},
        'hypothetical_uniform_family':{'r_domain':'0<r<=1/100','v':'r^4','LD':'r^4','a':'r^3/10','mu':'r^3/2',
            'u':'1/r','threshold_upper':'9*r^3/20','failure_upper':'2*exp(-1/r)',
            'actual_SIDE24_input_verification':False,'finite_examples':examples,'polynomial_tail_certificates':rates},
        'barrier_direction_counterexample':barrier_counterexample(),
        'entropy_counterexample':entropy,'mean_mismatch_counterexample':mean_example,
        'derivative_omission_counterexample':derivative_example,
        'growing_ratio_counterexample':{'r_n':'exp(-n^2)','clearance_over_sigma':'sqrt(n)',
             'tail_lower_for_n_ge_1':'(2/sqrt(2*pi))*exp(-3/2)*exp(-n/2)/sqrt(n)',
             'failure_divided_by_r':'tends to +infinity despite clearance/sigma tending to +infinity'},
        'units':units,'component_example':{'v':'1','L':'5'},
        'remaining_obligations':[
            'Construct the actual third-saddle nominal ascent tube and prove that its perturbation ball lies wholly in the event of reaching height above b.',
            'Certify the conditional mean mismatch, all scaled derivative variance and canonical-metric bounds, uniformly over r and the claimed mark/tube family.',
            'Show the required clearance growth relative to variance and entropy; fixed far-end slack and r-free residual scale do not demonstrate it.',
            'Supply the separately controlled exceptional geometric event and any determinant-weighted Palm transfer for the actual q0 law.',
            'This is not a new K3 assembly, a SIDE24 gamma premise discharge, a restored Theorem B, or a scientific status change.'
        ]
    }


def encode(result):
    return (json.dumps(result,indent=2,sort_keys=True,ensure_ascii=False)+'\n').encode()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=DEFAULT_REPO)
    parser.add_argument('--source-dir',type=Path,default=HERE/'source')
    parser.add_argument('--verify',type=Path)
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    try:
        payload=encode(run(args.repo,args.source_dir))
        if args.verify:
            require(args.verify.read_bytes()==payload,'report differs from exact reconstruction')
        if args.output:
            require(not args.output.exists(),'output already exists')
            args.output.parent.mkdir(parents=True,exist_ok=True)
            with args.output.open('xb') as handle: handle.write(payload)
    except (ValueError,KeyError,OSError,ArithmeticError) as exc:
        print('FAIL: '+str(exc),file=sys.stderr)
        return 1
    print('PASS: Gaussian C1 tube conditional theorem and counterexamples')
    return 0


if __name__=='__main__':
    sys.exit(main())
