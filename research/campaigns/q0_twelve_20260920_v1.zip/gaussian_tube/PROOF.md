# Gaussian C1 tube clearance: an explicit conditional bound

This is a new author-side conditional lemma and a source-logic correction. It
changes no research status. The actual SIDE24 third-saddle tube, its clearance
and its uniform conditional covariance bounds have not been established here.
Organizational independence credit is zero; no original prize problem is closed.

## 1. Source, law and units

The consumed source is the corrected active `KIMI-DER-026.md`, Drive ID
`1ff-sfJKUg8kO4G5JcBGMn0jyErKAp1lz`, 22,934 bytes, SHA-256
`d6bde0636b400d995f889e55446892631f3c2d462e060b34c27532fbd4a05bfd`.
The source's own verdict is conditional on P-NMZ-gamma. Its statements about
other carriers, station computations, dynamic genericity and existing grades
are not independently verified or imported as proved premises here. The
corrected primary bytes were materialized only after active-path, context,
coverage and exclusion checks. No frozen source code was executed.

Fix the conditioning pins and any other deterministic parameters. All
probabilities in Sections 2–5 refer to the resulting **Gaussian conditional
law**. Determinant-weighted typed pair-Palm probabilities require a separate
transfer; they are not Gaussian merely because the underlying field is.

On a deterministic square Q=[0,D]^2, D>0, use

    ||g||_(1,h) = max(sup_Q |g|, h sup_Q |partial_x g|,
                      h sup_Q |partial_y g|), h>0.

All three components have the units of field height. A tube contained in Q
inherits this upper bound. A torus chart or several chart pieces must first
be covered by such squares; for K squares a union bound multiplies the
probability by K, or one can replace u with u+log K in each bound. A random
field-dependent tube cannot silently be treated as deterministic. A uniformly
controlled deterministic cover suffices, even when the realized tube varies.

Write the field as `m+E`, with E centered Gaussian and m its conditional mean.
Let m_nom be a proposed deterministic nominal field and assume
`||m-m_nom||_(1,h) <= a`. This mean mismatch is a separate input, not part of
a centered tail estimate.

For the fold rescaling x=rX, y=rY and f=b+kappa*r^3 P, the residual's height
scale is kappa*r^3 and its physical gradient scale is kappa*r^2. Consequently

    ||E||_(1,r; physical domain) = kappa*r^3 ||E_scaled||_(C1; scaled domain).

Using an unweighted physical derivative as though it had height units misses
one factor of r. The source's 65/256 is a scaled height margin above b; its
physical height margin is `(65/256)*kappa*r^3`, not 65/256 and not a number to
compare directly with b=6/5. The exact table in result.json checks both rungs;
it does not transfer the endpoint branch's geometry to the third saddle.

## 2. A three-component Gaussian chaining lemma

Let `(Y_0,Y_1,Y_2)=(E,h partial_x E,h partial_y E)`. Assume these are jointly
centered Gaussian fields with continuous sample paths on Q, and uniformly
for each component j and all x,y in Q,

    Var(Y_j(x)) <= v^2,
    (E|Y_j(x)-Y_j(y)|^2)^(1/2) <= L ||x-y||_infinity.

Here v,L are nonnegative and `v+LD>0`. These are entire-domain conditions,
not station-net observations. Joint independence is unnecessary.

**Lemma.** For every u>=0,

    P( ||m-m_nom+E||_(1,h) >
       a+(v+LD)*sqrt(2*(u+4))+5*LD ) <= 2 exp(-u).       (1)

The continuum proof is elementary and does not assume a concentration theorem
for a seminorm without first accounting for its spatial complexity.

**Proof.** For a centered scalar Gaussian Z of variance at most s^2, completing
the square in its density gives E exp(tZ)<=exp(t^2*s^2/2). Markov's inequality,
minimized at t=z/s^2, gives `P(|Z|>z)<=2exp(-z^2/(2s^2))` for z>=0 and s>0.
If s=0 then Z=0 a.s.; all strict positive-deviation events are empty.

Let G_n be the square dyadic grid with `(2^n+1)^2` points. At n=0 there are
four corners, hence 24 signed component tests. With probability at least
`1-exp(-u)`, every base value is bounded by

    v sqrt(2*(u+log 24)).

For n>=1 give a grid point indexed (i,j) the parent
`(floor(i/2),floor(j/2))` at level n-1. Their physical distance in max norm
is at most D*2^-n. There are no more than

    6 (2^n+1)^2 <= 24 * 4^n

signed component increments. Therefore the probability that any increment
at level n exceeds

    LD * 2^-n * sqrt(2*(u+log 24+3n log 2))

is at most `exp(-u)*2^-n`. Summing all levels together with the base event
bounds the exceptional probability by `2exp(-u)`. Countable union bounds
apply without independence and to the full infinite family.

Every point is a limit of nested dyadic floor approximations. On the common
good event, continuity and telescoping yield the bound

    sup_j sup_Q |Y_j| <= v sqrt(2*(u+log 24))
      + LD sum_(n>=1) 2^-n sqrt(2*(u+log 24+3n log 2)).

Use sqrt(A+B)<=sqrt A+sqrt B, `sum 2^-n=1`, and
`sum sqrt(n)*2^-n <= sum n*2^-n=2`. This is at most

    (v+LD)*sqrt(2*(u+log 24)) + 2LD*sqrt(6 log 2).

The exact interval backend verifies `log 24<4` and `6log 2<25/4`, so this is
at most the stochastic part of (1). Adding the deterministic mismatch a by
the norm triangle inequality proves (1). The checker verifies grid counts
through level 16 as regression examples; the displayed inequality proves
**every** level, and the geometric generating function proves the infinite
series identities. Finite testing is not being substituted for this proof. ∎

A useful way to supply L from a twice differentiable Gaussian field is as
follows. For each component alpha in {(0,0),(1,0),(0,1)}, suppose its two
spatial derivatives have uniform L2 bounds B_(alpha,x), B_(alpha,y).
Integration along the segment from x to y and Minkowski's integral inequality
give

    L_alpha <= w_alpha*(B_(alpha,x)+B_(alpha,y)),
    v_alpha <= w_alpha*sup_x sqrt(Var(D^alpha E(x))),
    w_(0,0)=1, w_(1,0)=w_(0,1)=h.

Take maxima over the three components. This requires the segment to stay in
the square and the differentiability/integrability needed for the integral
identity. A bound for E alone omits the two first derivatives. A derivative
standard deviation has units of field/length, whereas L has the same units
and LD again has units of field. `component_envelope` checks this algebraic
interface, not the actual SIDE24 covariance estimates.

## 3. From a tube bound to an escape bound

The necessary deterministic dynamic input is explicit:

> Outside an exceptional event G_bad, every field g with
> `||g-m_nom||_(1,h;Q) < mu` has the designated third-saddle branch well
> defined, retained in the designated tube until its escape section, and
> reaching some field value strictly greater than b.

This is a **ball contained in the success event**. A positive distance from a
boundary alone does not identify which side contains the nominal field, nor
does it prove continuation of the branch. The contract includes those facts.
When mu strictly exceeds the threshold in (1), this contract and gradient
ascent monotonicity imply

    P(terminal value <= b) <= P(G_bad) + 2 exp(-u),      (2)

provided the terminal exists and ascent terminates as asserted by the
application. Monotonicity gives nondecreasing field value along a gradient
trajectory and a strict earlier crossing of b persists at the terminal.
No assertion about the actual third-saddle contract is made here.

Set S=v+LD and H=mu-a-5LD. For sufficiently small r suppose H>0 and define
`u=H^2/(2S^2)-5`. Once u>=0 the threshold is strictly below mu, since its
square-root part is `sqrt(H^2-2S^2)<H`. Thus the tube term is at most

    2 exp(5) exp(-H^2/(2S^2)).                         (3)

For a desired exponent p>0, the sufficient asymptotic condition is

    H^2/(2S^2) - p log(1/r) -> +infinity.              (4)

In particular `H/(S sqrt(2log(1/r))) -> infinity` gives a tube term o(r^p)
for every fixed p. The mean error a and spatial increment/entropy cost LD
are load-bearing in this condition. For K(r) charts, subtract also log K(r)
in (4), or use the preceding adjusted u allocation. Fixed far-end positive
slack and an r-free residual scale do not demonstrate (4). They may still
be useful to another argument; they do not establish this growing-clearance
criterion by themselves.

To obtain an o(r^p) conclusion from (2), `P(G_bad)=o(r^p)` must separately
hold in the same law and uniformly over the stated parameters. To move to
another measure, such as the determinant-weighted typed pair-Palm law,
a separately verified transfer is also needed. Neither operation is hidden
inside a Gaussian tube tail.

## 4. An explicit all-small-r conditional example

This is a sufficient **hypothetical input family**, not measured or certified
SIDE24 data. If for every `0<r<=1/100` the above interface and dynamic ball
contract hold with

    v=r^4, LD=r^4, a=r^3/10, mu=r^3/2,

then set u=1/r. Since

    2/r+8 <= (52/25)/r < (9/4)/r,

(1)'s threshold divided by r^3 is at most

    1/10 + 3 sqrt(r) + 5r <= 1/10+3/10+1/20 = 9/20 < 1/2.

The tube failure is therefore at most `2exp(-1/r)` on the **whole** radius
interval. For each fixed p>0 select an integer m>p. The elementary exponential
series gives `exp(1/r)>=(1/r)^m/m!`, hence

    2exp(-1/r)/r^p <= 2m! r^(m-p) -> 0.

The checker validates this exact budget, three finite interval instances,
and representative integer p=1,...,8. The written argument covers every p.
Again, the actual tube and these covariance/clearance scalings remain inputs.

## 5. Counterexamples and one precise source correction

**A growing ratio alone is insufficient.** Let E be the constant scalar
field Z~N(0,1), and put r_n=exp(-n^2), clearance=sqrt(n). The clearance/standard
deviation ratio tends to infinity. For any t>=1, direct integration over
[t,t+1/t] gives

    P(|Z|>t) >= (2/sqrt(2pi))*exp(-3/2)*exp(-t^2/2)/t.

For t=sqrt(n), divide by r_n. The lower bound tends to infinity, since its
exponent is n^2-n/2 and the remaining factor is 1/sqrt(n). Thus even o(r)
fails. This is a counterexample to mere ratio divergence, not to the source's
stronger superlogarithmic premise.

**Entropy cannot be discarded.** For 1,000 independent N(0,1) coordinates,
the interval backend proves `P(|Z|>3)>1/500`. Hence

    P(max_j |Z_j|>3) > 1-(499/500)^1000 > 4/5.

But a putative variance-only unshifted bound with s=1 gives
`2exp(-9/2)<1/40`. They contradict one another. This finite Gaussian process
already disproves a general supremum claim based only on pointwise variance;
it can be included as values of a continuous Gaussian interpolation. It is
not asserted to be the SIDE24 conditional field or to meet a small-L input.
The mismatch is exactly the spatial complexity which the increment constant
and grid summation account for in (1).

**Mean mismatch and derivatives matter.** An identically zero centered residual
with a nominal/true-mean discrepancy 1 violates a nominal clearance 1/2 with
probability one. Centered residual variance alone misses it. Likewise
`E(x,y)=Z*x` has E(0,0)=0 but partial_x E(0,0)=Z. A field-value estimate at a
pin does not control its C1 norm. These are generic interface counterexamples,
not fields claimed to satisfy the program's six pins.

**Fixed clearance cannot force a vanishing Gaussian tail.** At any included
point where the centered residual standard deviation is at least sigma_0>0,
a threshold bounded above by M has

    P(||E||_(1,h)>threshold) >= 2 barPhi(M/sigma_0)>0.

This is a conditional obstruction if that upper threshold bound holds. The
source's fixed far-end gate is not a proved upper bound on the true maximal
clearance, so this argument does not refute P-NMZ-gamma. It explains why a
fixed certified slack alone supplies no shrinking failure rate.

**KIMI-DER-026, D2 has a reversed probability implication.** Its premise
`P(capture<=b | arrival) <= 1-c` entails

    P(capture<=b AND arrival) <= (1-c)P(arrival).

It does not entail the displayed lower bound in D2. The exact counterexample
has `P(arrival)=1/2`, `P(capture<=b | arrival)=0`, and c=1/10. The premise is
satisfied, the intersection probability is zero, and the asserted lower
bound is 9/20. The source's stronger conclusion that a small-arrival rate is
necessary does not follow from that inequality. The useful corrected
statement is: *this particular fixed-constant upper estimate does not by
itself certify a small failure rate when its right side stays of order one*.
It does not make a much smaller actual failure rate impossible.

## 6. Scope and replay

`gaussian_tube.py` uses the repository's exact-rational interval implementation
for log, square root, exp and Gaussian tails. Source and backend identities
are checked before replay. The result is deterministic; normal and `-O`
replays must reconstruct exactly the same bytes. There are no runtime Python
assertions in the checker. Tests exercise changed source bytes, wrong context,
missing derivative components, inadequate entropy budget, negative/inexact
parameters, inadequate clearance, report tampering, and actual CLI failures
in both modes. The finite computations validate constants and counterexamples;
the continuum and asymptotic arguments are the ordinary proof above.

Remaining work is the actual deterministic third-saddle dynamic contract,
uniform conditional mean/covariance data on its whole tube, the required
clearance scaling, exceptional-event estimates, and applicable Palm transfer.
This candidate is not a K3 assembly successor and closes none of those items.
