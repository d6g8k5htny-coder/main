#!/bin/bash
# ISOLATE: list Orca's live-region decisions with times (read-only grep of orca-debug.txt).
F=$1/orca-debug.txt
grep -a -n -E "WEB: Ignoring because|WEB: Event is believed|PRESENT LIVE REGION MESSAGE|LIVE REGIONS: messages in queue|LIVE REGION MANAGER: (Queu|Present|Interrupt|Flush)|Flushing|PROCESS OBJECT EVENT (object:text-changed:insert|object:children-changed:add|object:text-changed:delete|object:children-changed:remove)" "$F" | cut -c1-230
