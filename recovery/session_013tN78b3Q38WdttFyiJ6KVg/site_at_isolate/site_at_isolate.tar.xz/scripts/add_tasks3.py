#!/usr/bin/python3 -I
# ISOLATE: add STATUS4 (status3.html: lone wrapping role=status, then empty status filled by a button).
import json, sys
p = sys.argv[1]
T = json.load(open(p))
caret_in = lambda sel: f"(() => {{ const s = getSelection(); const n = s && s.anchorNode; const e = n && (n.nodeType === 1 ? n : n.parentElement); return !!e && !!e.closest('{sel}'); }})()"
steps = [{"nav": "http://127.0.0.1:8770/status3.html", "atspi_early": True, "min": 5000, "cap": 90000, "idle": 3000, "label": "load"},
         {"probe": "(() => { const r = document.createRange(); r.selectNodeContents(document.getElementById('vh2')); const rs = [...r.getClientRects()]; return { chars: document.getElementById('vh2').textContent.length, rects: rs.length, tops: [...new Set(rs.map(x => Math.round(x.top)))], width: document.getElementById('vh2').getBoundingClientRect().width }; })()", "label": "vh2 line count"},
         {"key": "ctrl+Home", "label": "browse mode: top of document", "min": 900, "cap": 12000, "idle": 1100},
         {"walk": "Down", "n": 6, "wai": caret_in('#vh2'), "waiKey": "KP_Enter", "stop": caret_in('#label-k2'), "label": "browse Down (vh2 lines)", "min": 900, "cap": 15000, "idle": 1100},
         {"key": "Tab", "label": "Tab to btn-k2", "max": 6, "min": 900, "cap": 8000, "idle": 1100,
          "until": "(() => { const a = document.activeElement; return !!a && a.id === 'btn-k2'; })()"},
         {"key": "Return", "label": "Return on btn-k2 (live update)", "min": 2500, "cap": 12000, "idle": 1500,
          "check": "(window.__isolog || []).filter(e => e.ev === 'vk2-s-set-button').map(e => e.iso)"},
         {"key": "ctrl+Home", "label": "top again", "min": 900, "cap": 12000, "idle": 1100},
         {"walk": "Down", "n": 10, "wai": caret_in('#vk2,#vk2-s'), "waiKey": "KP_Enter", "stop": caret_in('#label-end'), "label": "browse Down after K2 update", "min": 900, "cap": 15000, "idle": 1100},
         {"key": "ctrl+Home", "label": "top again before Say All", "min": 900, "cap": 12000, "idle": 1100},
         {"key": "KP_Add", "label": "Say All (KP_Add, desktop layout)", "min": 3000, "cap": 90000, "idle": 3000},
         {"atspi_only": True, "label": "final AT-SPI snapshot"}]
T['STATUS4'] = {"title": "Status variants three", "atspiEach": True, "steps": steps}
json.dump(T, open(p, 'w'), indent=1)
print(list(T))
