#!/bin/bash
# ISOLATE: run the listed runs sequentially, one stack at a time.
R=/tmp/claude-0/-home-user-main/d5c985ca-97e5-58d8-a9d4-1e0a19065a22/scratchpad/isolate
for T in "$@"; do
  echo "$(date -u +%FT%TZ) start $T" >> $R/evidence/run_all.log
  bash $R/scripts/stack.sh $T >> $R/evidence/run_all.log 2>&1
  python3 -I $R/scripts/extract.py $R/evidence/$T >> $R/evidence/run_all.log 2>&1
  echo "$(date -u +%FT%TZ) done $T" >> $R/evidence/run_all.log
done
