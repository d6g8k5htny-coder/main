#!/usr/bin/python3 -I
# ISOLATE: add SELECT2 (replicate of SELECT1), SELECT3 (select2.html d-g) and STATUS3 (status2.html g-k) to tasks.json.
import json, copy, sys
p = sys.argv[1]
T = json.load(open(p))
T['SELECT2'] = copy.deepcopy(T['SELECT1'])
def sel_block(i):
    chk = f"[document.getElementById('sel-{i}').value, document.getElementById('sel-{i}').disabled, document.getElementById('sel-{i}').hasAttribute('disabled'), [...document.getElementById('sel-{i}').options].map(o => [o.text, o.disabled, o.selected])]"
    b = lambda k, lab, mn=900: {"key": k, "label": f"sel-{i} {lab}", "min": mn, "cap": 8000, "idle": 1100, "check": chk}
    return [
        {"key": "Tab", "label": f"Tab to sel-{i}", "max": 6, "min": 900, "cap": 8000, "idle": 1100,
         "until": f"(() => {{ const a = document.activeElement; return !!a && a.id === 'sel-{i}'; }})()"},
        {"probe": chk, "label": f"sel-{i} DOM state after focus"},
        b("alt+Down", "alt+Down (open popup)", 1500), b("Up", "popup Up"), b("Down", "popup Down"),
        b("Escape", "Escape (close popup)", 1200),
        {"key": "KP_Enter", "label": f"sel-{i} EXTRA Where Am I after Escape", "min": 900, "cap": 10000, "idle": 1100}]
steps = [{"nav": "http://127.0.0.1:8770/select2.html", "atspi_early": True, "min": 7000, "cap": 60000, "idle": 2500,
          "label": "load (wait > 4 s so sel-d is re-enabled and e/f/g enabled before any key)"},
         {"probe": "window.__isolog", "label": "page event log"},
         {"atspi_only": True, "label": "settled AT-SPI snapshot before any key"}]
for i in 'defg': steps += sel_block(i)
steps += [{"probe": "window.__isolog", "label": "page event log end"}, {"atspi_only": True, "label": "final AT-SPI snapshot"}]
T['SELECT3'] = {"title": "Select variants two", "atspiEach": True, "steps": steps}
caret_in = lambda sel: f"(() => {{ const s = getSelection(); const n = s && s.anchorNode; const e = n && (n.nodeType === 1 ? n : n.parentElement); return !!e && !!e.closest('{sel}'); }})()"
def press(btn, ev):
    return [{"key": "Tab", "label": f"Tab to {btn}", "max": 8, "min": 900, "cap": 8000, "idle": 1100,
             "until": f"(() => {{ const a = document.activeElement; return !!a && a.id === '{btn}'; }})()"},
            {"key": "Return", "label": f"Return on {btn} (live update)", "min": 1500, "cap": 12000, "idle": 1500,
             "check": f"(window.__isolog || []).filter(e => e.ev === '{ev}').map(e => e.iso)"}]
steps = [{"nav": "http://127.0.0.1:8770/status2.html", "atspi_early": True, "min": 7000, "cap": 120000, "idle": 3000,
          "label": "load (timers: vi at 2 s, vj-p at 3.5 s; Orca load behaviour, no keys)"},
         {"probe": "window.__isolog", "label": "page event log after load"},
         {"probe": "(() => { const r = document.createRange(); r.selectNodeContents(document.getElementById('vh')); const rs = [...r.getClientRects()]; return { chars: document.getElementById('vh').textContent.length, rects: rs.length, tops: [...new Set(rs.map(x => Math.round(x.top)))], width: document.getElementById('vh').getBoundingClientRect().width, innerWidth }; })()", "label": "vh line count"}]
steps += press('btn-i', 'vi-set-button') + press('btn-j', 'vj-set-button') + press('btn-k', 'vk-s-set-button')
steps += [{"probe": "window.__isolog", "label": "page event log after buttons"},
          {"key": "ctrl+Home", "label": "browse mode: top of document", "min": 900, "cap": 12000, "idle": 1100},
          {"walk": "Down", "n": 30, "wai": caret_in('#vg,#vh,#vi,#vj,#vk,#vk-s'), "waiKey": "KP_Enter",
           "stop": caret_in('#label-end'), "label": "browse Down", "min": 900, "cap": 15000, "idle": 1100},
          {"key": "ctrl+Home", "label": "top again before Say All", "min": 900, "cap": 12000, "idle": 1100},
          {"key": "KP_Add", "label": "Say All (KP_Add, desktop layout)", "min": 3000, "cap": 150000, "idle": 3000},
          {"atspi_only": True, "label": "final AT-SPI snapshot"}]
T['STATUS3'] = {"title": "Status variants two", "atspiEach": True, "steps": steps}
json.dump(T, open(p, 'w'), indent=1)
print(list(T))
