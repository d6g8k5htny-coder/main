#!/usr/bin/python3 -I
# ISOLATE: add SELECT4 (select3.html timing bisection: enable at 0, 250, 1000, 2000 ms after load).
import json, sys
p = sys.argv[1]
T = json.load(open(p))
def blk(i):
    chk = f"[document.getElementById('sel-{i}').value, document.getElementById('sel-{i}').disabled]"
    return [{"key": "Tab", "label": f"Tab to sel-{i}", "max": 6, "min": 900, "cap": 8000, "idle": 1100,
             "until": f"(() => {{ const a = document.activeElement; return !!a && a.id === 'sel-{i}'; }})()"},
            {"key": "alt+Down", "label": f"sel-{i} alt+Down (open popup)", "min": 1500, "cap": 8000, "idle": 1100, "check": chk},
            {"key": "Down", "label": f"sel-{i} popup Down", "min": 900, "cap": 8000, "idle": 1100, "check": chk},
            {"key": "Escape", "label": f"sel-{i} Escape (close popup)", "min": 1200, "cap": 8000, "idle": 1100, "check": chk}]
steps = [{"nav": "http://127.0.0.1:8770/select3.html", "atspi_early": True, "min": 6000, "cap": 60000, "idle": 2500, "label": "load"},
         {"probe": "window.__isolog", "label": "page event log"}]
for i in ['t0', 't250', 't1000', 't2000']: steps += blk(i)
steps += [{"atspi_only": True, "label": "final AT-SPI snapshot"}]
T['SELECT4'] = {"title": "Select timing three", "atspiEach": True, "steps": steps}
json.dump(T, open(p, 'w'), indent=1)
print(list(T))
