# SITE-AT-ISOLATE: Orca 46.1 source notes (static read)

Lane: SITE-AT-ISOLATE-CLAUDE54-20261025, step 3 (Orca's source). No stack, no browser, nothing posted.
Source: `/usr/lib/python3/dist-packages/orca`, package `orca 46.1-1ubuntu1` (`orca_platform.py` version "46.1").
`dpkg --verify orca` reports only missing doc and man files. No Python file differs from the package.
All `file:line` references below are relative to that directory.

Cross-checks: I read the retained Orca debug logs of this lane's own SITE runs, read-only, under
`scratchpad/siteat/{exec,rep}/evidence/*/orca-debug.txt`. They come from the same author and lane, so they are not an independent check.
Labels used below:
- **SOURCE**: the code path is fixed by the Python source.
- **LOG**: the SITE logs show that this path ran.
- **SUGGESTS**: an inference that needs the minimal-page test, or C code (libatspi, Chromium) that I did not read.

## 1. role=status, which Orca sees as STATUS_BAR

LOG: Chromium 141 exposes `<p id="atlas-status" role="status">` as `role='status bar'` with `xml-roles:status`.
The text is in the status bar's own Text interface, for example `AXText: [status bar] reports 168 characters`.
Each text run is a `[static]` child with no tag.

### 1a. The speech format for STATUS_BAR has no text slot (SOURCE)
- `formatting.py:479-482` sets `Atspi.Role.STATUS_BAR` to:
  - `'focused': 'labelAndName + roleName'`
  - `'unfocused': 'labelAndName + roleName + pause + statusBar'`
- The format has no `currentLineText`, `displayedText`, `expandedEOCs` or `substring`. Compare:
  - PARAGRAPH, `formatting.py:399-404`: `... + currentLineText + allTextSelection`
  - SECTION, `formatting.py:453-456`: `(labelOrName or (currentLineText + allTextSelection))`
  - LANDMARK, `formatting.py:307-310`: `(substring and currentLineText)`
- Braille is the same: `formatting.py:825-828` uses `labelOrName + roleName` plus `statusBar`.
- `generator.generate` picks the format string by role and formatType (`generator.py:227-233`, via `formatting.getFormat`, `formatting.py:1074-1114`).
  - STATUS_BAR has no `basicWhereAmI` key, so basic Where Am I falls through to `'unfocused'` at `formatting.py:1101-1102`.
  - Detailed Where Am I: the web generator overrides the role to `'default'` (`scripts/web/speech_generator.py:736-737`), giving `'pageSummary'` (`formatting.py:138`), not the text.
- The web script does not override the role to something with text. Its `_getAlternativeRole` (`generator.py:1301-1360`) has no status case.
  - `treatAsDiv` only applies to LIST/PANEL (`scripts/web/script_utilities.py:128`, `2112-2152`).
  - STATUS_BAR is not in `_textBlockElementRoles` (`scripts/web/script_utilities.py:1983-2020`).

### 1b. What `statusBar` speaks: only child objects, never the bar's own text (SOURCE)
- `speech_generator.py:2283-2304` (`_generateStatusBar`) speaks `generate(child)` for each item of `utilities.statusBarItems(obj)`.
- `script_utilities.py:1642-1660` (`statusBarItems`) is `getOnScreenObjects(obj)` with every STATUS_BAR filtered out (`include`, lines 1650-1652).
- `script_utilities.py:1498-1560` (`getOnScreenObjects`):
  - It adds the root itself when `hasPresentableText(root)` (lines 1536-1537). The filter above then removes the root, because the root is the status bar.
  - It skips children that are static text leaves (pred at lines 1539-1543).
  - Chromium's leaf test, `scripts/toolkits/Chromium/script_utilities.py:58-77`, is: role STATIC or TEXT, no children, and tag None, "" or "br".
- **Net effect:** text that sits directly in the role=status element is never spoken by any generator in this format. Only element children with their own tag are spoken (for example `<time>` or `<code>`), and they are spoken without the surrounding text.
- The items are cached in `script.pointOfReference['statusBarItems']`, not keyed by object (lines 1647-1654), and are cleared only by Where Am I's status-bar command (`where_am_i_presenter.py:378-380`). An empty list is never cached.
  - SUGGESTS: one status bar's non-empty items could be reused for another. This was not seen in these runs.
- LOG, `exec/T1` 17:54:10.665: `CHROMIUM: [static: 'Source snapshot … No scientific status inferred.'] believed to be static text leaf`, then `statusBar=[]`.
- LOG, `exec/T5S` 18:35:33 and `exec/T6S` 18:37:09: Where Am I gave `statusBar=[2026-10-24T00:43:16Z PAUSE]`, and the spoken output was only `'2026-10-24T00:43:16Z.'`. A child element was spoken while the sentence around it was dropped, which is exactly the behaviour 1b describes.

### 1c. "statusbar." versus "blank" versus silence (SOURCE)
- **Role word.** `roleName` is `generator.getLocalizedRoleName`. For STATUS_BAR it maps to ATK `"statusbar"` (`generator.py:1498-1503`, special case at lines 1500-1501).
- **When the role word is dropped.** The web `_generateRoleName` returns `[]` when `obj == args['priorObj']` (`scripts/web/speech_generator.py:530-531`). The general branch also requires `priorObj != obj` (line 629).
- **Pause-only results.** When everything else is empty, the result holds only pauses, and `speech_generator.py:118-125` turns that into `[]`.
- **Line navigation.**
  - Path: `sayLine` (`scripts/web/script.py:903-925`) → `speakContents` (840-844) → web `generateContents` (`scripts/web/speech_generator.py:764-797`) → `generateSpeech(obj, startOffset, endOffset, string)` per item.
  - On the first line of the status, priorObj is the previous object, so the output is "statusbar".
  - On the next line inside the same status, the previous caret context (`getPriorContext`, `scripts/web/script_utilities.py:4699-4708`, set by `setCaretContext` at lines 4719-4727) is the same status bar. The result is pause-only, so `generateContents` emits `messages.BLANK` (`scripts/web/speech_generator.py:788-795`).
  - LOG, `exec/T1` 17:54:10.673 `SPEECH OUTPUT: 'statusbar.'` (offsets 0-89), then 17:54:12.516 `'blank'` (offsets 89-168, `roleName=[]`).
- **Say All.**
  - Path: web `textLines` (`scripts/web/script.py:533-648`).
  - It logs `WEB SAY ALL CONTENT: … '<full text>'` (lines 579-581) **before** generation.
  - It then calls `speechGenerator.generateContents([content], …)` (lines 595-596), which takes the same STATUS_BAR format, so only "statusbar" is yielded.
  - This is why the Say All log holds the full text while speech says "statusbar".
  - LOG, `rep/T1` 19:24:00.820, `WEB SAY ALL CONTENT: 1. [status bar] ' Source snapshot … '` → `roleName=[statusbar]`, `statusBar=[]` → `WEB SAY ALL: … 'statusbar'`.
- **Where Am I.**
  - Path: `where_am_i_presenter.py:463-492` (`_do_where_am_i`, presentObject at 483-490) → `script.presentObject(realActiveAncestor(locusOfFocus), formatType='basicWhereAmI')`.
  - Browse-mode caret moves set the locus of focus to the caret object (`scripts/web/script_utilities.py:335`).
  - The web `presentObject` sends status bars to `default.presentObject` (`scripts/web/script.py:931-933`, `scripts/default.py:2317-2325`).
  - Web `generateSpeech` fills `priorObj` from `getPriorContext` (`scripts/web/speech_generator.py:747-749`). After a caret move within the status bar, priorObj equals obj, so the output is pause-only and `speech.speak([])` is silent.
  - LOG, `exec/T1S` 18:26:30.856 and 18:27:13.151: `Results for [status bar] are pauses only`, then `SPEECH: Speak []`.
  - **Correction to the delivery:** Where Am I on these status lines was **silent**, not "statusbar." or "blank".
- The web `_generateAncestors` returns early for status bars (`scripts/web/speech_generator.py:81-86`), so no ancestor context is added either.

### 1d. Why the role name replaces the text
- **Proven:** the cause is the STATUS_BAR format itself.
  - The format assumes a desktop status bar: a container presented through its child widgets.
  - Combined with the Chromium static-text-leaf exclusion, no generator in it reads the element's own text.
  - It is not "name instead of text", because `labelAndName=[]` for an unnamed status.
  - It is not a landmark treatment; `isLandmark` is not involved.
- **SUGGESTS** (to be confirmed by the minimal pages):
  - The same text as a plain `<p>`, or as `aria-live=polite` without the role, uses the PARAGRAPH format with `currentLineText`, so it should be spoken.
  - A heading or other element child inside role=status is spoken through `statusBar` items, but its sibling text is not.
  - An `aria-label` on the status would be spoken via `labelAndName`. The web `_generateName` returns the name for non-text-block roles (`scripts/web/speech_generator.py:372-414`). That is a workaround inferred from source and has not been tested.
  - The cause is in Orca's handling of the role, not in the SITE markup's validity.

## 2. Live-region flushing and deduplication while typing

### 2a. Every key press flushes queued live messages and stops speech (SOURCE)
- `input_event.py:932`: `KeyboardEvent._process` calls `self._present()` for every non-duplicate event.
- `input_event.py:855-857`: on a pressed key, it calls `self._script.presentationInterrupt()`.
- `scripts/default.py:2674-2683` runs `speech.stop()`, which also cuts a live message already being spoken.
- `scripts/web/script.py:526-530` then logs `WEB: Flushing live region messages` and calls `liveRegionManager.flushMessages()`.
- `liveregions.py:565-566` (`flushMessages`) runs `msg_queue.clear()`.
- Messages are spoken only by `pumpMessages`, which is scheduled with `GLib.timeout_add(100, …)` when the queue was empty (`liveregions.py:306-309`, pump at 311-350).
  - A message is lost if the next key press is processed before the pump runs.
  - That window is 100 ms, or longer while the main loop is busy with events.
- Other rules:
  - Assertive purges queued polite messages (`liveregions.py:300-303`).
  - Queued messages expire after 45 s (`liveregions.py:29`, `purgeByKeepAlive`).
  - Deletions in live regions are ignored (`scripts/web/script.py:2301-2304`).

### 2b. Drop rules before the queue (SOURCE)
- `scripts/web/script_utilities.py:4987-5028` (`handleAsLiveRegion`):
  - **Duplicate** (5007-5012): text-changed:insert with the same type and `any_data` as the last queued live event is dropped. Its memory, `_lastQueuedLiveRegionEvent`, is reset in `clearCachedObjects` (line 222), not by `flushMessages`.
  - **`WEB: Event is believed to be redundant live region notification`** (5021-5025): `any_data` equals the last queued live object but the event type differs.
- `scripts/toolkits/Chromium/script_utilities.py:257-275` (Chromium override): every live-region `children-changed:add` is dropped unless the child is a table, with the message `CHROMIUM: Event is believed to be redundant live region notification`. The comment there assumes a text-changed:insert accompanies it.
- `scripts/toolkits/Chromium/script.py:159-165` (`onChildrenAdded`): `children-changed:add` whose child is a static text leaf is dropped before any live-region handling (`CHROMIUM: Ignoring because child is static text leaf`).

### 2c. What the SITE logs show (LOG)
- **`#equation-count`** (role=status, `container-atomic:true`). The flush race happened as described in 2a.
  - `exec/T4`: "32 matching excerpts…" was queued at 18:04:52.6616. Key 'i' at 52.8011 flushed it. The pump at 52.8058 reported `messages in queue: 0`.
  - `rep/T4`: queued at 19:31:31.8174. Key 'd' at 31.9045 flushed it. The pump at 31.9309 reported `0`.
  - Later updates arrived only as `children-changed:add` of static leaves and were dropped (2b).
- **`#atlas-count`** (`<p aria-live=polite>`, not role=status, `container-atomic:false`). In **both** T2 runs, Chromium sent the count text **only** as `children-changed:add` of a new `[static]` child. There was no text-changed:insert for any count string.
  - The first one (17:58:32.287) was dropped as `CHROMIUM: … redundant live region notification`; its child was already defunct.
  - The rest, including the settled "2 displayed · 2 matching…" at 17:58:33.58, were dropped as static text leaves.
  - **None was ever queued.** All five `Event to be handled as live region` lines in each T2 log come from page load.
  - **Correction to delivery finding 3:** for `#atlas-count` the flush is not the operative cause. Orca's Chromium children-changed filters are. The flush-on-key explanation holds for `#equation-count`.
- SUGGESTS: why Chromium sends text-changed:insert for `#equation-count` but only children-changed for `#atlas-count`. Atomic versus non-atomic, or the DOM update path, are possible reasons. This cannot be decided from Orca's source.

## 3. "grayed" on the View select's options

### 3a. Where "grayed" comes from (SOURCE)
- The string is `object_properties.py:560`, `STATE_INSENSITIVE_SPEECH = _("grayed")`, mapped as `'insensitive'` at `formatting.py:64`.
- `generator.py:555-567` (`_generateAvailability`) appends it when `not AXUtilities.is_sensitive(obj)`. The speech wrapper is `speech_generator.py:490-497`.
- `ax_utilities_state.py:298-301`: `is_sensitive` is `has_state(SENSITIVE)`. ENABLED (`ax_utilities_state.py:142-145`) is **not** consulted.
- The option format is MENU_ITEM `'unfocused'`, which includes `availability` (`formatting.py:376-380`). The web `_generateRoleName` does not speak MENU_ITEM (`scripts/web/speech_generator.py:552-560`), hence "List grayed.".

### 3b. Does Orca cache the states? No (SOURCE)
- `ax_object.py:943-957` (`get_state_set`) calls `Atspi.Accessible.get_state_set(obj)` on every call, and `has_state` (960-966) uses it.
- Orca's own stored data (`ax_object.py:58-93`: known-dead flags, mutter frames, object attributes) does not include states.
- On every locus-of-focus change, Orca clears the AT-SPI client cache of the new focus. This happens in `focus_manager.py:169-173` → `AXObject.clear_cache` → `Atspi.Accessible.clear_cache_single` (`ax_object.py:1210-1227`).
- Not verified here: libatspi 2.52's `clear_cache_single` is C (the symbol is present in `libatspi.so.0`). That it forces the states to be fetched again over D-Bus is my understanding of at-spi2-core, not something I read in source.

### 3c. LOG comparison (rep/T2 and rep/T4)
- **View options.** The options of `#atlas-view` (path …,2,3,1,10,0,{0,1}) reported states without `enabled`, `sensitive` or `selectable`:
  - 'focusable, focused'
  - 'focusable, visible'
  - 'focusable, showing, visible'
  - 'focusable, focused, visible'
- **After the cache clear.** Orca cleared the cache at 19:26:09.704. `availability=[grayed]` was computed after that, at 19:26:09.715, and 'List grayed.' was sent at .736.
- **The combo box itself.** It was 'enabled, … sensitive …' at the same moment.
- **Comparison selects.** The HTML ships all three selects with `disabled` (`siteat/bundle/site/dependencies.html`; read only, not served or edited).
  - `#atlas-view`: static `<option>`s from the HTML, enabled at `atlas.mjs:30`.
  - `#equation-select`: empty in the HTML, with options created by script. It is enabled in the same statement at `atlas.mjs:30`. Its popup option 'periodized_gaussian_h0/PROOF.md · lines 27–28' was 'enabled, focusable, focused, selectable, selected, sensitive, showing, visible' (rep/T4) and was **not** grayed.
  - `#classification-filter`: options rebuilt by `replaceChildren` (`dependencies.mjs:303`) before it is enabled (`dependencies.mjs:312`). Its option reported 'enabled … sensitive'.

### 3d. Verdict for H2
- **Proven:** "grayed" means that the option's AT-SPI state set lacks SENSITIVE. Orca keeps no Python-side state cache that could keep an option insensitive, and it refreshes the AT-SPI cache on focus.
- **SUGGESTS:** the insensitive state comes from Chromium.
  - The evidence refines H2. It is not "a select shipped disabled", because `#equation-select` was also shipped disabled and was not grayed.
  - The likely cause is option nodes that existed (parsed) while the select was disabled and were never recreated after it was enabled. Their stale state also lacks `selectable` and `selected`.
- **Needed from the minimal page:**
  - a never-disabled select;
  - a disabled-then-enabled select with static options;
  - a disabled-then-enabled select whose options are created or replaced after it is enabled.

## Limits
- This is a static read of Orca's Python only. libatspi (C) and Chromium (C++) were not read, so every Chromium-side cause above is an inference.
- The log cross-checks use this lane's own SITE logs, which are not independent. Times are Orca log times.
- I assumed default settings for `onlySpeakDisplayedText`, `inferLiveRegions` and `speakBlankLines`. The settings files were only hashed in the evidence and not read here.
- No live test was run in this step. The minimal-page runs are separate steps of this lane.
- I did not analyse why the View select gave no value name on focus, on Down, or in Where Am I.
