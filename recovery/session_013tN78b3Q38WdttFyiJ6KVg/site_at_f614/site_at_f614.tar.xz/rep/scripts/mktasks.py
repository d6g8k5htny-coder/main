#!/usr/bin/python3 -I
# REP: writes tasks.json (task step lists for drive.mjs). Predicates are page JS expressions (observation only).
import json, sys
U = 'http://127.0.0.1:8770/site/'
NODE = 'math.d1-component.congruence-erratum'
ATL = U + 'dependencies.html#current-atlas'
ATLN = U + 'dependencies.html?atlas-node=' + NODE + '#current-atlas'
def act(js): return "(() => { const a = document.activeElement; return !!a && (" + js + "); })()"
def caret_heading(rx):
    return ("(() => { const s = getSelection(); const n = s && s.anchorNode; const e = n && (n.nodeType === 1 ? n : n.parentElement);"
            " const h = e && e.closest('h1,h2,h3,h4,h5,h6'); return !!h && /" + rx + "/.test(h.textContent); })()")
READ = dict(min=900, cap=16000, idle=1100)
NAVK = dict(min=700, cap=3000, idle=900)
LOAD = dict(min=3000, cap=45000, idle=2500)
inspector = [
    dict(key='Tab', until=act("a.id === 'atlas-focus'"), max=18, label='Tab to Return to focus', **NAVK),
    dict(key='Return', label='Return to focus (inspector)', check=act("a.id === 'atlas-inspector'"), **READ),
]
T = {}
T['SMOKE'] = dict(steps=[dict(nav=ATL, canary=True, min=4000, cap=20000), dict(key='Tab', n=2, **NAVK)])
T['T1'] = dict(steps=[
    dict(nav=U + 'index.html#main-content', canary=True, min=8000, cap=40000, idle=3000),
    dict(key='shift+Tab', until=act("a.matches('nav[aria-label=Primary] a[href=\"dependencies.html#current-atlas\"]')"), max=6, label='to Primary Mathematics', min=900, cap=5000),
    dict(key='Return', label='open atlas', check="[location.href, document.title, document.getElementById('atlas-status')?.textContent.trim(), document.querySelector('.current-state')?.textContent.trim()]", **LOAD),
    dict(key='Down', n=19, label='read atlas start', min=900, cap=12000, idle=1100),
    dict(key='shift+h', until=caret_heading('Current research sources'), max=4, label='to Current research sources', **READ),
    dict(key='Down', n=10, label='read observation and pins', min=900, cap=16000, idle=1100),
    dict(key='h', until=caret_heading('Equations and dependency|Mathematics'), max=4, label='back toward atlas heading', **READ),
    dict(key='KP_Add', label='Orca Say All from here (refute probe)', min=3000, cap=70000, idle=3000),
    dict(key='Escape', label='stop', **NAVK),
])
T['T2'] = dict(steps=[
    dict(nav=ATL, canary=True, min=4000, cap=20000),
    dict(key='Tab', until=act("a.id === 'atlas-search'"), max=8, label='to search', **NAVK),
    dict(key='Tab', label='to View select', check=act("a.id === 'atlas-view'"), min=900, cap=8000),
    dict(key='Down', label='View Down', check="document.getElementById('atlas-view').value", min=900, cap=8000),
    dict(key='KP_Enter', label='Where Am I on View', min=900, cap=8000),
    dict(key='Up', label='View Up', check="document.getElementById('atlas-view').value", min=900, cap=8000),
    dict(key='Down', label='View Down again', check="document.getElementById('atlas-view').value", min=900, cap=8000),
    dict(key='alt+Down', label='open View popup (refute probe)', min=1200, cap=8000),
    dict(key='Up', label='popup Up', check="document.getElementById('atlas-view').value", min=900, cap=8000),
    dict(key='Down', label='popup Down', check="document.getElementById('atlas-view').value", min=900, cap=8000),
    dict(key='Return', label='popup choose', check="document.getElementById('atlas-view').value", min=900, cap=8000),
    dict(key='Tab', until=act("a.id === 'atlas-toggle-view'"), max=14, label='to toggle', **NAVK),
    dict(key='Return', label='toggle 1', check="document.getElementById('atlas-toggle-view').textContent.trim()", min=900, cap=8000),
    dict(key='Return', label='toggle 2', check="document.getElementById('atlas-toggle-view').textContent.trim()", min=900, cap=8000),
    dict(key='shift+Tab', until=act("a.id === 'atlas-search'"), max=16, label='back to search', **NAVK),
    dict(key='type:congruence', label='type congruence', check="document.getElementById('atlas-count').textContent.trim()", min=4000, cap=12000),
    dict(key='Tab', until=act("a.tagName === 'BUTTON' && a.textContent.includes('" + NODE + "')"), max=16, label='to node button', min=900, cap=5000),
    dict(key='Return', label='select node', check=act("a.id === 'atlas-inspector'") , **READ),
    dict(key='Down', n=5, label='read inspector', **READ),
    dict(key='shift+Tab', until=act("a.getAttribute('aria-pressed') !== null"), max=8, label='back to node button', min=900, cap=12000),
])
T['T3'] = dict(steps=[dict(nav=ATLN, canary=True, min=4000, cap=20000)] + inspector + [
    dict(key='Down', n=5, label='counts', **READ),
    dict(key='h', until=caret_heading('Continuation'), max=7, label='to Continuation', **READ),
    dict(key='Down', n=22, label='five axes', **READ),
    dict(key='h', until=caret_heading('^\\s*Consumes'), max=3, label='Consumes', **READ),
    dict(key='Down', n=2, label='read Consumes', **READ),
    dict(key='h', until=caret_heading('Consumed by'), max=3, label='Consumed by', **READ),
    dict(key='Down', n=6, label='read Consumed by', **READ),
])
def record(linktext, static):
    s = [dict(nav=ATLN, canary=True, min=4000, cap=20000)] + inspector + [
        dict(key='Tab', until=act("a.textContent.trim() === '" + linktext + "'"), max=5, label='to ' + linktext, min=900, cap=6000),
        dict(key='Return', label='open record', check="[location.href, document.title]", **LOAD),
        dict(key='ctrl+Home', label='top', **READ),
        dict(key='h', label='first heading', **READ),
        dict(key='Down', n=4, label='observation and pins', **READ)]
    if static:
        s += [dict(key='h', until=caret_heading('Resume this node'), max=4, label='to Resume', **READ),
              dict(key='Down', n=8, label='read Resume', **READ)]
    else:
        s += [dict(key='h', label='h1', **READ)]
    s += [dict(key='h', until=caret_heading('Incoming required'), max=14, label='to Incoming required', **READ),
          dict(key='Down', n=3, label='read typed row', **READ),
          dict(key='shift+h', label='back to heading', **NAVK),
          dict(key='k', label='next link (neighbor)', check=act("a.href.includes('math.uniform-matrix-cap-lifetime')"), **READ),
          dict(key='Return', label='open neighbor', check="[location.href, document.title]", **LOAD),
          dict(key='ctrl+Home', label='top', **READ),
          dict(key='h', label='first heading', **READ),
          dict(key='Down', n=2, label='observation', **READ),
          dict(key='h', label='h1', **READ)]
    return dict(steps=s)
T['T3B'] = dict(steps=[dict(nav=ATLN, canary=True, min=4000, cap=20000)] + inspector + [
    dict(key='h', until=caret_heading('^\\s*Consumes'), max=12, label='to Consumes', **READ),
    dict(key='Down', n=9, label='read Consumes and Consumed by', **READ),
])
T['T5'] = record('Read the preserved mathematical record', False)
T['T6'] = record('Read the static node record', True)
T['T7'] = dict(steps=[dict(nav=ATLN, canary=True, min=4000, cap=20000)] + inspector + [
    dict(key='shift+Tab', until=act("a.getAttribute('role') === 'tab'"), max=4, label='to tab list', min=900, cap=6000),
    dict(key='Right', until=act("a.id === 'atlas-tab-diagnostics'"), max=4, label='to Diagnostics tab', min=900, cap=6000),
    dict(key='Return', label='activate Diagnostics', check="[document.getElementById('atlas-tab-diagnostics')?.getAttribute('aria-selected'), location.href]", min=900, cap=6000),
    dict(key='Tab', until=act("a.tagName === 'SUMMARY' && a.textContent.includes('Snapshot diagnostics')"), max=6, label='to summary', min=900, cap=6000),
    dict(key='Return', label='expand', check="document.querySelector('#atlas-diagnostics')?.closest('details')?.open ?? [...document.querySelectorAll('details')].filter(d=>d.querySelector('summary').textContent.includes('Snapshot diagnostics')).map(d=>d.open)", min=900, cap=6000),
    dict(key='Tab', label='first gap button', min=900, cap=8000),
    dict(key='Up', n=6, label='read up', **READ),
    dict(key='Down', n=14, label='read down', **READ),
])
T['T8'] = dict(steps=[dict(nav=ATL, canary=True, min=4000, cap=20000),
    dict(key='Up', n=3, label='read up (capacity)', **READ),
    dict(key='Down', n=2, label='read down', **READ),
    dict(key='Tab', until=act("a.tagName === 'SUMMARY' && a.textContent.includes('History and activity')"), max=55, label='to History summary', min=600, cap=2500, idle=800),
    dict(key='Return', label='expand', check="[...document.querySelectorAll('details')].filter(d=>d.querySelector('summary').textContent.includes('History and activity')).map(d=>d.open)", min=900, cap=6000),
    dict(key='Tab', label='to manifest link', check=act("a.href"), min=900, cap=8000),
    dict(key='Up', n=4, label='read up', **READ),
    dict(key='Down', n=7, label='read down', **READ),
])
T['T4'] = dict(steps=[dict(nav=ATL, canary=True, min=4000, cap=20000),
    dict(key='Tab', until=act("a.id === 'equation-search'"), max=45, label='to equation search', min=600, cap=2500, idle=800),
    dict(key='type:periodized', label='type periodized', check="document.getElementById('equation-count').textContent.trim()", min=4000, cap=12000),
    dict(key='Tab', label='to excerpt select', check=act("a.id === 'equation-select'"), min=900, cap=10000),
    dict(key='Down', label='select Down', check="document.getElementById('equation-select').value", min=900, cap=10000),
    dict(key='KP_Enter', label='Where Am I on select', min=900, cap=12000),
    dict(key='alt+Down', label='open excerpt popup (refute probe)', min=1200, cap=10000),
    dict(key='Return', label='popup choose current', check="document.getElementById('equation-select').value", min=900, cap=10000),
    dict(key='Tab', until=act("a.textContent.includes('Read exact source lines')"), max=4, label='to source link', min=900, cap=8000),
    dict(key='KP_Enter', label='Where Am I on link', min=900, cap=12000),
    dict(key='Down', n=3, label='read identity and warning', min=900, cap=20000, idle=1100),
    dict(key='Up', n=6, label='read up', **READ),
])
json.dump(T, open(sys.argv[1], 'w'), indent=1)
print({k: len(v['steps']) for k, v in T.items()})
