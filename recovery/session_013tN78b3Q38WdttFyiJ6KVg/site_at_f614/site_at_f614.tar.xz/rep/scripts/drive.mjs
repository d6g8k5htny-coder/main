// REP lane CDP driver (written from scratch for the replication).
// usage: node drive.mjs TASKS_JSON TASK_ID OUT_DIR CDP_PORT
// - Connects to Chromium at browser level, auto-attaches (flatten) to every target, and on each target
//   enables Fetch for all requests: only http://127.0.0.1:8770/ is continued; everything else is
//   Fetch.failRequest(BlockedByClient) and appended to OUT_DIR/refusals.jsonl.
// - Harness navigation (Page.navigate) only for a task's start URL. Every user key is sent as a real
//   X event by xkey.py (AT-SPI -> XTest). CDP is used only to observe the DOM (Runtime.evaluate).
// - Step log: OUT_DIR/steps.jsonl (one line per key with send time and DOM probe after).
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const [tasksPath, taskId, outDir, port] = process.argv.slice(2);
const TASKS = JSON.parse(fs.readFileSync(tasksPath, 'utf8'));
const task = TASKS[taskId];
if (!task) { console.error('no task', taskId); process.exit(2); }
const XKEY = path.join(path.dirname(new URL(import.meta.url).pathname), 'xkey.py');
const ORIGIN = 'http://127.0.0.1:8770/';
const stepsLog = fs.openSync(path.join(outDir, 'steps.jsonl'), 'a');
const refLog = fs.openSync(path.join(outDir, 'refusals.jsonl'), 'a');
const netLog = fs.openSync(path.join(outDir, 'cdp-requests.jsonl'), 'a');
const wl = (fd, o) => fs.writeSync(fd, JSON.stringify(o) + '\n');
const sleep = ms => new Promise(r => setTimeout(r, ms));
const iso = () => new Date().toISOString();

const ver = await (await fetch(`http://127.0.0.1:${port}/json/version`)).json();
const ws = new WebSocket(ver.webSocketDebuggerUrl);
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
let nextId = 1; const pending = new Map(); const sessions = new Map();
function send(method, params = {}, sessionId) {
  const id = nextId++;
  const msg = { id, method, params }; if (sessionId) msg.sessionId = sessionId;
  ws.send(JSON.stringify(msg));
  return new Promise((res, rej) => pending.set(id, { res, rej, method }));
}
ws.onmessage = async ev => {
  const m = JSON.parse(ev.data);
  if (m.id && pending.has(m.id)) {
    const p = pending.get(m.id); pending.delete(m.id);
    if (m.error) p.rej(new Error(p.method + ': ' + JSON.stringify(m.error))); else p.res(m.result);
    return;
  }
  const sid = m.sessionId;
  if (m.method === 'Target.attachedToTarget') {
    const s = m.params.sessionId; const ti = m.params.targetInfo;
    sessions.set(s, ti);
    try {
      if (['page', 'iframe', 'worker', 'service_worker', 'shared_worker'].includes(ti.type)) {
        await send('Fetch.enable', { patterns: [{ urlPattern: '*', requestStage: 'Request' }] }, s);
        await send('Target.setAutoAttach', { autoAttach: true, waitForDebuggerOnStart: true, flatten: true }, s).catch(() => {});
        if (ti.type === 'page' || ti.type === 'iframe') await send('Network.enable', {}, s).catch(() => {});
      }
    } catch (e) { wl(netLog, { t: iso(), err: String(e), target: ti.type }); }
    await send('Runtime.runIfWaitingForDebugger', {}, s).catch(() => {});
    wl(netLog, { t: iso(), event: 'attached', type: ti.type, url: ti.url, session: s });
  } else if (m.method === 'Fetch.requestPaused') {
    const { requestId, request, resourceType } = m.params;
    if (request.url.startsWith(ORIGIN)) {
      wl(netLog, { t: iso(), event: 'fetch-continue', url: request.url, target: sessions.get(sid)?.type });
      send('Fetch.continueRequest', { requestId }, sid).catch(() => {});
    } else {
      wl(refLog, { t: iso(), url: request.url, method: request.method, resourceType, action: 'Fetch.failRequest BlockedByClient', target: sessions.get(sid)?.type });
      send('Fetch.failRequest', { requestId, errorReason: 'BlockedByClient' }, sid).catch(() => {});
    }
  } else if (m.method === 'Network.requestWillBeSent') {
    wl(netLog, { t: iso(), event: 'request', url: m.params.request.url, type: m.params.type, initiator: m.params.initiator?.type });
  } else if (m.method === 'Network.responseReceived') {
    wl(netLog, { t: iso(), event: 'response', url: m.params.response.url, status: m.params.response.status });
  } else if (m.method === 'Network.loadingFailed') {
    wl(netLog, { t: iso(), event: 'failed', id: m.params.requestId, error: m.params.errorText, blocked: m.params.blockedReason });
  }
};
await send('Target.setDiscoverTargets', { discover: true });
await send('Target.setAutoAttach', { autoAttach: true, waitForDebuggerOnStart: true, flatten: true });
await sleep(500);
let pageSession = null;
for (const [s, ti] of sessions) if (ti.type === 'page') pageSession = s;
if (!pageSession) {
  const { targetInfos } = await send('Target.getTargets');
  const pg = targetInfos.find(t => t.type === 'page');
  const r = await send('Target.attachToTarget', { targetId: pg.targetId, flatten: true });
  pageSession = r.sessionId; await sleep(300);
}
// Track the current top-level page session (same target across navigations).
const PROBE = `(() => {
  const d = el => { if (!el) return null; let s = el.tagName.toLowerCase(); if (el.id) s += '#' + el.id;
    if (el.className && typeof el.className === 'string') s += '.' + el.className.trim().split(/\\s+/).slice(0,2).join('.');
    const r = el.getAttribute('role'); if (r) s += '[role=' + r + ']';
    const n = (el.getAttribute('aria-label') || el.innerText || el.value || '').trim().replace(/\\s+/g,' ').slice(0, 120);
    const ex = {}; for (const a of ['aria-pressed','aria-selected','aria-expanded','href','value']) { const v = a==='value' ? el.value : el.getAttribute(a); if (v != null && v !== '') ex[a] = String(v).slice(0,200); }
    return { el: s, text: n, ...ex }; };
  const live = [...document.querySelectorAll('[role=status],[aria-live],[role=alert],[role=log]')].map(e => ({ el: d(e).el, live: e.getAttribute('aria-live'), text: (e.textContent||'').trim().replace(/\\s+/g,' ').slice(0, 300) }));
  return { url: location.href, title: document.title, ready: document.readyState, active: d(document.activeElement), live };
})()`;
async function evalPage(expr) {
  try {
    const r = await send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true }, pageSession);
    return r.result?.value ?? (r.exceptionDetails ? { exception: r.exceptionDetails.text } : null);
  } catch (e) { return { error: String(e) }; }
}
const audioLast = () => { try { return parseFloat(fs.readFileSync(path.join(outDir, 'audio_last'), 'utf8')) * 1000; } catch { return 0; } };
async function waitIdle(minMs, capMs, idleMs = 1100) {
  const t0 = Date.now(); await sleep(minMs);
  while (Date.now() - t0 < capMs) {
    if (Date.now() - audioLast() > idleMs) return { waited: Date.now() - t0, capped: false };
    await sleep(150);
  }
  return { waited: Date.now() - t0, capped: true };
}
function xkey(k) {
  const out = execFileSync('/usr/bin/python3.12', ['-I', XKEY, k], { encoding: 'utf8', env: process.env });
  return out.trim().split('\n').map(l => JSON.parse(l));
}
let stepNo = 0;
async function doKey(k, opts = {}) {
  stepNo++;
  const before = opts.noProbeBefore ? null : await evalPage(PROBE);
  const sent = xkey(k);
  const w = await waitIdle(opts.min ?? 900, opts.cap ?? 4000);
  const after = await evalPage(PROBE);
  const extra = opts.check ? await evalPage(opts.check) : undefined;
  const rec = { step: stepNo, kind: 'X-KEY', key: k, label: opts.label, sent_at: new Date(sent[0].t * 1000).toISOString(), sent, wait: w, end_at: iso(), focus_before: before?.active, after, check: extra };
  wl(stepsLog, rec); return rec;
}
wl(stepsLog, { step: 0, kind: 'START', task: taskId, t: iso(), page_session: pageSession });
// Refusal canary on the CSP-free data: start page: proves the Fetch block path before the task (harness, not site).
await send('Page.enable', {}, pageSession).catch(() => {});
{ const c = await evalPage(`fetch('http://refusal-canary.invalid/rep-lane').then(()=>'NOT BLOCKED').catch(e=>'blocked: '+e.message)`);
  wl(stepsLog, { step: 0, kind: 'HARNESS canary fetch (data: start page)', t: iso(), result: c }); }
for (const st of task.steps) {
  if (st.nav) {
    stepNo++;
    const t = iso();
    await send('Page.navigate', { url: st.nav }, pageSession);
    for (let i = 0; i < 60; i++) { await sleep(250); const r = await evalPage('document.readyState'); if (r === 'complete') break; }
    const w = await waitIdle(st.min ?? 6000, st.cap ?? 30000, st.idle ?? 2500);
    const after = await evalPage(PROBE);
    const extra = st.check ? await evalPage(st.check) : undefined;
    wl(stepsLog, { step: stepNo, kind: 'HARNESS Page.navigate', url: st.nav, sent_at: t, wait: w, end_at: iso(), after, check: extra });
    if (st.canary) {
      const c = await evalPage(`fetch('http://refusal-canary.invalid/rep-lane').then(()=>'NOT BLOCKED').catch(e=>'blocked: '+e.message)`);
      wl(stepsLog, { step: stepNo, kind: 'HARNESS canary fetch', t: iso(), result: c });
    }
  } else if (st.until) {
    let ok = false;
    for (let i = 0; i < (st.max ?? 10); i++) {
      const r = await doKey(st.key, { ...st, check: st.until });
      if (r.check === true) { ok = true; break; }
    }
    wl(stepsLog, { step: stepNo, kind: 'PREDICATE', label: st.label, until: st.until, met: ok, t: iso() });
  } else if (st.key) {
    for (let i = 0; i < (st.n ?? 1); i++) await doKey(st.key, st);
  } else if (st.probe) {
    wl(stepsLog, { step: stepNo, kind: 'DOM-PROBE', label: st.label, t: iso(), value: await evalPage(st.probe) });
  } else if (st.sleep) {
    await sleep(st.sleep);
  }
}
wl(stepsLog, { step: stepNo, kind: 'END', t: iso() });
await sleep(1500);
ws.close();
process.exit(0);
