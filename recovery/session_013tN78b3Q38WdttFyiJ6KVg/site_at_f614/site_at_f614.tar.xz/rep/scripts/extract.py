#!/usr/bin/python3 -I
# REP: join Orca-sent speech (orca-debug.txt) to the driver's step boundaries (steps.jsonl).
# usage: extract.py EVIDENCE_DIR   -> writes speech.tsv and steps-speech.txt in EVIDENCE_DIR
# Evidence classes: [SPEECH] = string Orca handed to speech-dispatcher (exact, from Orca's own debug log);
# [AUDIO] = sink activity after send (approximate playback indicator); [DOM] = CDP probe text.
import json, os, re, sys, datetime
d = sys.argv[1]
day = None
steps = [json.loads(l) for l in open(os.path.join(d, 'steps.jsonl'))]
start = [s for s in steps if s['kind'] == 'START'][0]['t']
day = start[:10]
def ts(hms):
    return datetime.datetime.fromisoformat(day + 'T' + hms + '+00:00').timestamp()
sp = []
rx = re.compile(r"^(\d\d:\d\d:\d\d\.\d+) - (SPEECH OUTPUT: '(.*)' \{|SPEECH DISPATCHER: Speaking '(.*)' as (key|char))")
prev_out = None
rx2 = re.compile(r"^(\d\d:\d\d:\d\d\.\d+) - SPEECH DISPATCHER: Speaking '(<speak>.*</speak>)' ")
for line in open(os.path.join(d, 'orca-debug.txt'), errors='replace'):
    m = rx.match(line)
    if not m: continue
    t = ts(m.group(1))
    if m.group(3) is not None:
        sp.append((t, m.group(1), 'sent', m.group(3)))
    else:
        sp.append((t, m.group(1), 'sent-' + m.group(5), m.group(4)))
for line in open(os.path.join(d, 'orca-debug.txt'), errors='replace'):
    m2 = rx2.match(line)
    if not m2: continue
    t = ts(m2.group(1)); txt = re.sub(r'<[^>]+>', '', m2.group(2)).replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>').replace('&apos;', "'").replace('&quot;', '"')
    if any(abs(t - u) < 0.05 and (txt.strip() == v.strip()) for (u, _, k, v) in sp if k == 'sent'): continue
    sp.append((t, m2.group(1), 'sent-ssml(say-all or unlogged)', txt))
sp.sort(key=lambda x: x[0])
# audio bursts
bursts = []
try:
    for l in open(os.path.join(d, 'sink.log')):
        p = l.split()
        if p[1] in ('start', 'end'): bursts.append((float(p[0]), p[1]))
except OSError: pass
def audio_after(t, until):
    # seconds of sink activity between t and until (approx)
    tot = 0.0; cur = None
    for bt, kind in bursts:
        if kind == 'start': cur = bt
        elif cur is not None:
            a, b = max(cur, t), min(bt, until)
            if b > a: tot += b - a
            cur = None
    return tot
keys = [s for s in steps if s['kind'] in ('X-KEY', 'HARNESS Page.navigate')]
bounds = []
for s in keys:
    bounds.append((datetime.datetime.fromisoformat(s['sent_at'].replace('Z', '+00:00')).timestamp(), s))
out = open(os.path.join(d, 'steps-speech.txt'), 'w')
tsv = open(os.path.join(d, 'speech.tsv'), 'w')
for i, (t0, s) in enumerate(bounds):
    t1 = bounds[i + 1][0] if i + 1 < len(bounds) else 1e12
    lab = s.get('key') or s.get('url')
    after = s.get('after') or {}
    act = (after.get('active') or {})
    out.write(f"#{s['step']} [{s['kind']}] {lab} ({s.get('label','')}) sent {s['sent_at']} wait={s.get('wait')}\n")
    out.write(f"   [DOM] url={after.get('url')} active={act.get('el')} '{act.get('text','')[:90]}' {{{', '.join(k+'='+str(v)[:60] for k,v in act.items() if k not in ('el','text'))}}}\n")
    if 'check' in s and s['check'] is not None: out.write(f"   [DOM check] {json.dumps(s['check'], ensure_ascii=False)[:400]}\n")
    for (t, hms, kind, text) in sp:
        if t0 - 0.05 <= t < t1 - 0.05:
            out.write(f"   [SPEECH {kind} {hms}] '{text}'\n")
            tsv.write(f"{s['step']}\t{hms}\t{kind}\t{text}\n")
    out.write(f"   [AUDIO ~{audio_after(t0, min(t1, t0 + 60)):.1f}s sink activity in this step]\n")
for s in steps:
    if s['kind'].startswith(('PREDICATE', 'HARNESS canary', 'END')):
        out.write(json.dumps(s, ensure_ascii=False)[:300] + '\n')
print('steps', len(bounds), 'speech lines', len(sp))
