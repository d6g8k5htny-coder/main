#!/usr/bin/python3 -I
# REP: join custody-server log entries to bundle bytes. usage: join.py EVIDENCE_DIR BUNDLE_ROOT
import json, sys, os, hashlib, collections
d, root = sys.argv[1], sys.argv[2]
st = collections.Counter(); bad = []; rem = set(); n404 = []
for l in open(os.path.join(d, 'server-requests.jsonl')):
    e = json.loads(l); st[e['status']] += 1; rem.add(e['remote'])
    if e['status'] == 200:
        h = hashlib.sha256(open(os.path.join(root, e['file']), 'rb').read()).hexdigest()
        if h != e['sha256']: bad.append(e['url'])
    else: n404.append((e['status'], e['url'], e.get('note')))
ref = [json.loads(l) for l in open(os.path.join(d, 'refusals.jsonl'))]
cdp = [json.loads(l) for l in open(os.path.join(d, 'cdp-requests.jsonl'))]
nonlocal_req = [c['url'] for c in cdp if c.get('event') == 'request' and not c['url'].startswith(('http://127.0.0.1:8770/', 'data:'))]
print(json.dumps({'requests': sum(st.values()), 'status': dict(st), 'remotes': sorted(rem), 'sha_mismatch': bad, 'non200': n404,
                  'refusals': [(r['url'], r['resourceType'], r['action']) for r in ref], 'cdp_nonlocal_requests': nonlocal_req,
                  'fetch_continued': sum(1 for c in cdp if c.get('event') == 'fetch-continue')}))
