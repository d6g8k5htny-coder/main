// SITE generated-bundle replay: DOM-ONLY keyboard dry run of the eight-task plan.
// THIS IS DOM/AX EVIDENCE ONLY. No screen reader, no Orca, no speech. Keys are CDP key events
// (Playwright keyboard), which Orca cannot see; the real run must use X key events via AT-SPI.
//
// usage: NODE_PATH=/opt/node22/lib/node_modules node dryrun.cjs BASE_URL OUT_DIR
//   BASE_URL e.g. http://127.0.0.1:8770/site/   (custody serve.mjs must already be listening)
// Every request is intercepted with CDP Fetch at Request stage. Only BASE origin is continued;
// anything else is failed with Fetch.failRequest(BlockedByClient) and logged as a refusal.
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { chromium } = require('playwright');

const [BASE, OUT] = process.argv.slice(2);
if (!BASE || !OUT) { console.error('usage: node dryrun.cjs BASE_URL OUT_DIR'); process.exit(2); }
const ORIGIN = new URL(BASE).origin;
if (!/^http:\/\/127\.0\.0\.1:\d+$/.test(ORIGIN)) throw new Error('BASE must be http://127.0.0.1:PORT');
fs.mkdirSync(OUT, { recursive: true });
const CHROME = '/opt/pw-browsers/chromium-1194/chrome-linux/chrome';
const VIEWPORT = { width: 1200, height: 760 };
const NODE = 'math.d1-component.congruence-erratum';
const NEIGHBOR = 'math.uniform-matrix-cap-lifetime';
const ARCHIVE = 'eee261a6e4c075dfc5318a6b6daaa9b42e482d8b7f6ad9cc43a9d1e4e9d13fc5';
const U = p => new URL(p, BASE).href;

const events = [];          // network/console/refusal log
const refusals = [];
const iso = () => new Date().toISOString();
const ev = (kind, data) => events.push({ time: iso(), kind, ...data });

// ---------- in-page helpers (serialized into the page) ----------
const PAGE_HELPERS = String.raw`
window.__dr = {
  desc(el) {
    if (!el) return null;
    const t = (el.innerText ?? el.textContent ?? '').replace(/\s+/g, ' ').trim();
    return { tag: el.tagName.toLowerCase(), id: el.id || null, role_attr: el.getAttribute('role'),
      aria_label: el.getAttribute('aria-label'), aria_pressed: el.getAttribute('aria-pressed'),
      aria_selected: el.getAttribute('aria-selected'), aria_expanded: el.getAttribute('aria-expanded'),
      open: el.tagName === 'SUMMARY' ? el.parentElement.open : undefined,
      href: el.getAttribute('href'), abs_href: el.href || null, value: el.value ?? null,
      text: t.slice(0, 400) };
  },
  visible(el) {
    if (!el || !el.getClientRects().length) return false;
    const cs = getComputedStyle(el); if (cs.visibility === 'hidden') return false;
    for (let a = el; a; a = a.parentElement) if (a.getAttribute && a.getAttribute('aria-hidden') === 'true') return false;
    return true;
  },
  // Approximate browse-mode reading order: text grouped by nearest line container, controls as own lines.
  // This is a DOM approximation of what a virtual cursor would traverse, NOT Orca's line segmentation.
  lines(start, { untilText = null, max = 40, inclusive = true } = {}) {
    const root = typeof start === 'string' ? document.querySelector(start) : start;
    if (!root) return { error: 'start not found: ' + start };
    const CONTAINER = 'button,select,input,textarea,summary,p,li,dt,dd,h1,h2,h3,h4,h5,h6,pre,caption,th,td,figcaption,label,a';
    const BLOCKISH = new Set(['block', 'list-item', 'table', 'table-row', 'table-cell', 'flex', 'grid', 'table-caption']);
    const container = node => { let el = node.nodeType === 1 ? node : node.parentElement;
      for (let e = el; e && e !== document.body; e = e.parentElement) {
        if (e.matches('button,select,input,textarea,summary')) return e;
      }
      for (let e = el; e && e !== document.body; e = e.parentElement) {
        if (e.matches('p,li,dt,dd,h1,h2,h3,h4,h5,h6,pre,caption,th,td,figcaption,label') || BLOCKISH.has(getComputedStyle(e).display)) return e;
      }
      return document.body; };
    const out = []; let cur = null, curText = '';
    const vlines = el => { try { const r = document.createRange(); r.selectNodeContents(el); const tops = new Set([...r.getClientRects()].filter(q => q.width > 0 && q.height > 0).map(q => Math.round(q.top))); return tops.size; } catch { return null; } };
    const flush = () => { const t = curText.replace(/\s+/g, ' ').trim(); if (cur && t) out.push({ tag: cur.tagName.toLowerCase(), id: cur.id || null, visual_lines: vlines(cur), text: t.slice(0, 600) }); cur = null; curText = ''; };
    const w = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT);
    w.currentNode = root; let node = inclusive ? root : w.nextNode(); let done = false;
    const seenControls = new Set();
    while (node && !done) {
      if (node.nodeType === 1 && node.matches('select,input,textarea')) {
        if (this.visible(node) && !seenControls.has(node)) { flush(); seenControls.add(node);
          const lbl = node.labels && node.labels[0] ? node.labels[0].innerText.trim() : (node.getAttribute('aria-label') || '');
          out.push({ tag: node.tagName.toLowerCase(), id: node.id || null, text: '[' + node.tagName.toLowerCase() + ' "' + lbl + '" value="' + (node.tagName === 'SELECT' ? (node.selectedOptions[0]?.text ?? '') : node.value) + '"]' }); }
      } else if (node.nodeType === 3 && node.data.trim()) {
        const p = node.parentElement;
        if (p && this.visible(p) && !p.closest('select,script,style,noscript')) {
          const c = container(node); if (c !== cur) { flush(); cur = c; } curText += node.data;
        }
      }
      if (untilText && out.some(l => l.text.includes(untilText))) done = true;
      if (out.length >= max) done = true;
      if (!done) node = w.nextNode();
    }
    if (!done) flush(); else if (out.length < max) flush();
    return { lines: out, reached: untilText ? out.findIndex(l => l.text.includes(untilText)) : null };
  },
  headings() { return [...document.querySelectorAll('h1,h2,h3,h4,h5,h6')].filter(h => this.visible(h)).map(h => ({ level: +h.tagName[1], id: h.id || null, text: h.innerText.replace(/\s+/g, ' ').trim().slice(0, 120) })); },
  text(sel) { const e = document.querySelector(sel); return e ? e.textContent.replace(/\s+/g, ' ').trim() : null; },
};`;

async function main() {
  const browser = await chromium.launch({ executablePath: CHROME, headless: true, args: ['--force-renderer-accessibility'] });
  const versions = { chromium: browser.version(), playwright: require('playwright/package.json').version, node: process.version, viewport: VIEWPORT, executable: CHROME };
  const context = await browser.newContext({ viewport: VIEWPORT, serviceWorkers: 'block', locale: 'en-US', timezoneId: 'UTC' });
  await context.addInitScript(PAGE_HELPERS);
  const page = await context.newPage();
  const cdp = await context.newCDPSession(page);
  await cdp.send('Accessibility.enable');
  await cdp.send('Fetch.enable', { patterns: [{ urlPattern: '*', requestStage: 'Request' }] });
  cdp.on('Fetch.requestPaused', async p => {
    let local = false; try { local = new URL(p.request.url).origin === ORIGIN; } catch {}
    try {
      if (local) await cdp.send('Fetch.continueRequest', { requestId: p.requestId });
      else { const r = { time: iso(), url: p.request.url, method: p.request.method, resourceType: p.resourceType, action: 'Fetch.failRequest BlockedByClient' };
        refusals.push(r); ev('refusal', r); await cdp.send('Fetch.failRequest', { requestId: p.requestId, errorReason: 'BlockedByClient' }); }
    } catch (e) { ev('fetch-error', { url: p.request.url, msg: String(e) }); }
  });
  page.on('request', r => ev('request', { url: r.url(), method: r.method(), type: r.resourceType() }));
  page.on('response', r => ev('response', { url: r.url(), status: r.status() }));
  page.on('requestfailed', r => ev('requestfailed', { url: r.url(), failure: r.failure()?.errorText }));
  page.on('console', m => ev('console', { type: m.type(), text: m.text().slice(0, 500) }));
  page.on('pageerror', e => ev('pageerror', { msg: String(e).slice(0, 500) }));

  async function axFocused() {
    try {
      const { result } = await cdp.send('Runtime.evaluate', { expression: 'document.activeElement' });
      if (!result.objectId) return null;
      const r = await cdp.send('Accessibility.getPartialAXTree', { objectId: result.objectId, fetchRelatives: false });
      const n = r.nodes.find(x => !x.ignored) || r.nodes[0];
      if (!n) return null;
      const props = {}; for (const p of n.properties || []) props[p.name] = p.value?.value;
      return { role: n.role?.value ?? null, name: n.name?.value ?? null, value: n.value?.value ?? null, description: n.description?.value ?? null, props };
    } catch (e) { return { error: String(e) }; }
  }
  const LIVE = ['.current-state', '#atlas-status', '#atlas-count', '#equation-count', '#atlas-diagnostic-selection', '#atlas-error'];
  async function probe(extra) {
    for (let attempt = 0; attempt < 3; attempt++) { try { return await probeOnce(extra); } catch (e) { if (attempt === 2) return { probe_error: String(e).split('\n')[0], url: page.url() }; await sleep(500); } }
  }
  async function probeOnce(extra) {
    const dom = await page.evaluate(([live]) => {
      const d = window.__dr; if (!d) return { url: location.href, title: document.title, note: 'no helpers (non-HTML document?)' };
      const L = {}; for (const s of live) { const e = document.querySelector(s); if (e) L[s] = e.textContent.replace(/\s+/g, ' ').trim().slice(0, 400); }
      return { url: location.href, title: document.title, focus: d.desc(document.activeElement), live: L };
    }, [LIVE]);
    return { ...dom, ax_focus: await axFocused(), ...(extra || {}) };
  }
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  async function atlasReady() {
    await page.waitForFunction(() => { const s = document.getElementById('atlas-search'), st = document.getElementById('atlas-status'), eq = document.getElementById('equation-select');
      return s && !s.disabled && eq && !eq.disabled && st && st.textContent.startsWith('Source snapshot') && document.querySelector('.current-state')?.textContent.startsWith('Verified'); }, null, { timeout: 30000 });
  }
  const focusIs = fn => async () => page.evaluate(fn);
  async function pressUntil(key, pred, max) {
    for (let i = 1; i <= max; i++) { await page.keyboard.press(key); await sleep(30); if (await page.evaluate(pred)) return i; }
    return null;
  }
  const tasks = [];
  let task = null;
  const step = async (s, run) => {
    const t0 = iso(); let result = {}; let ok = true; let err = null;
    try { result = (await run()) || {}; } catch (e) { ok = false; err = String(e && e.stack || e).slice(0, 800); }
    const p = await probe();
    if (result.check !== undefined) ok = ok && !!result.check;
    task.steps.push({ n: task.steps.length + 1, ...s, started: t0, ok, error: err, result, after: p });
    console.log(`${task.id}.${task.steps.length} ${ok ? 'OK ' : 'BAD'} ${s.label} :: focus=${p.focus?.tag}#${p.focus?.id || ''} "${(p.ax_focus?.name || '').slice(0, 70)}"${err ? ' ERR ' + err.split('\n')[0] : ''}`);
  };
  const begin = (id, title, start_url) => { task = { id, title, start_url, steps: [] }; tasks.push(task); };
  const gotoStart = async url => { await page.goto(url, { waitUntil: 'load' }); };
  const lines = (sel, opts) => page.evaluate(([s, o]) => window.__dr.lines(s, o), [sel, opts]);
  const linesFromFocus = opts => page.evaluate(o => window.__dr.lines(document.activeElement, o), opts);
  const enterNav = async (key, urlPart) => { await Promise.all([page.waitForURL(u => u.href.includes(urlPart), { waitUntil: 'load', timeout: 20000 }), page.keyboard.press(key)]); };

  // ---------------- Task 1 ----------------
  begin(1, 'Primary navigation to Mathematics/current atlas and its source context', U('index.html#main-content'));
  await step({ label: 'load home with fragment #main-content (fragment suppresses Orca Say All)', action: 'navigate' }, async () => {
    await gotoStart(task.start_url);
    await page.waitForFunction(() => document.querySelector('.current-state')?.textContent.startsWith('Verified'), null, { timeout: 30000 });
    return { check: true };
  });
  await step({ label: 'shift+Tab until Primary nav link "Mathematics"', action: 'key_repeat', keys: 'shift+Tab' }, async () => {
    const n = await pressUntil('Shift+Tab', () => { const a = document.activeElement; return a?.matches('nav[aria-label=Primary] a[href="dependencies.html#current-atlas"]'); }, 8);
    return { count: n, check: n !== null };
  });
  await step({ label: 'Enter activates Mathematics -> dependencies.html#current-atlas', action: 'key', keys: 'Return' }, async () => {
    await enterNav('Enter', 'dependencies.html#current-atlas'); await atlasReady();
    return { check: page.url() === U('dependencies.html#current-atlas'), headings: (await page.evaluate(() => window.__dr.headings())).slice(0, 6) };
  });
  await step({ label: 'read forward from atlas section until "Source snapshot" status (Orca: Down)', action: 'read' }, async () => {
    const r = await lines('#current-atlas', { untilText: 'Source snapshot', max: 12 });
    return { ...r, check: r.reached !== null && r.reached >= 0 };
  });
  await step({ label: 'read #current-research top context: h2, observation status, pins (Orca: shift+H then Down x2)', action: 'read' }, async () => {
    const r = await lines('#current-research h2', { max: 3 });
    const cap = await page.evaluate(() => window.__dr.text('.current-capacity'));
    return { ...r, capacity: cap, check: r.lines?.[1]?.text.startsWith('Verified source observation: 2026-10-25T14:27:24Z') };
  });

  // ---------------- Task 2 ----------------
  begin(2, 'Graph/List switching, node search and selection with announced selection', U('dependencies.html#current-atlas'));
  await step({ label: 'load atlas (fragment URL)', action: 'navigate' }, async () => { await gotoStart(task.start_url); await atlasReady(); return { check: true, initial_view: await page.evaluate(() => document.getElementById('atlas-view').value) }; });
  await step({ label: 'Tab until "Find in current graph" search entry', action: 'key_repeat', keys: 'Tab' }, async () => {
    const n = await pressUntil('Tab', () => document.activeElement?.id === 'atlas-search', 15); return { count: n, check: n !== null };
  });
  await step({ label: 'Tab to View combobox (Graph)', action: 'key', keys: 'Tab' }, async () => {
    await page.keyboard.press('Tab'); return { check: await page.evaluate(() => document.activeElement?.id === 'atlas-view' && document.activeElement.value === 'graph') };
  });
  await step({ label: 'Down in View combobox -> List', action: 'key', keys: 'Down' }, async () => {
    await page.keyboard.press('ArrowDown'); await sleep(100);
    return await page.evaluate(() => ({ value: document.getElementById('atlas-view').value, list_hidden: document.getElementById('atlas-list').hidden, stage_hidden: document.getElementById('atlas-stage').hidden, toggle: document.getElementById('atlas-toggle-view').textContent,
      list_items: document.querySelectorAll('#atlas-list > li').length, url: location.search,
      check: document.getElementById('atlas-view').value === 'list' && !document.getElementById('atlas-list').hidden }));
  });
  await step({ label: 'Tab until "Switch to graph" button', action: 'key_repeat', keys: 'Tab' }, async () => {
    const n = await pressUntil('Tab', () => document.activeElement?.id === 'atlas-toggle-view', 15); return { count: n, check: n !== null, text: await page.evaluate(() => document.activeElement.textContent) };
  });
  await step({ label: 'Enter on toggle -> Graph view', action: 'key', keys: 'Return' }, async () => {
    await page.keyboard.press('Enter'); await sleep(100);
    return await page.evaluate(() => ({ value: document.getElementById('atlas-view').value, stage_hidden: document.getElementById('atlas-stage').hidden, toggle: document.getElementById('atlas-toggle-view').textContent, focus_kept: document.activeElement?.id,
      check: document.getElementById('atlas-view').value === 'graph' && document.getElementById('atlas-toggle-view').textContent === 'Switch to list' }));
  });
  await step({ label: 'Enter on toggle -> List view again', action: 'key', keys: 'Return' }, async () => {
    await page.keyboard.press('Enter'); await sleep(100);
    return await page.evaluate(() => ({ value: document.getElementById('atlas-view').value, toggle: document.getElementById('atlas-toggle-view').textContent, check: document.getElementById('atlas-view').value === 'list' }));
  });
  await step({ label: 'shift+Tab until search entry', action: 'key_repeat', keys: 'shift+Tab' }, async () => {
    const n = await pressUntil('Shift+Tab', () => document.activeElement?.id === 'atlas-search', 15); return { count: n, check: n !== null };
  });
  await step({ label: 'type "congruence"', action: 'type', text: 'congruence' }, async () => {
    await page.keyboard.type('congruence', { delay: 20 }); await sleep(150);
    return await page.evaluate(() => ({ count_text: document.getElementById('atlas-count').textContent, buttons: [...document.querySelectorAll('#atlas-list button')].map(b => b.firstChild.textContent),
      check: document.getElementById('atlas-count').textContent.startsWith('2 displayed · 2 matching source nodes of 49') }));
  });
  await step({ label: `Tab until list node button ${NODE}`, action: 'key_repeat', keys: 'Tab' }, async () => {
    const n = await pressUntil('Tab', () => { const a = document.activeElement; return a?.closest('#atlas-list') && a.firstChild?.textContent === 'math.d1-component.congruence-erratum'; }, 20);
    return { count: n, check: n !== null, pressed: await page.evaluate(() => document.activeElement.getAttribute('aria-pressed')) };
  });
  await step({ label: 'Enter selects node; focus moves to inspector', action: 'key', keys: 'Return' }, async () => {
    const before = await page.evaluate(() => document.getElementById('atlas-count').textContent);
    await page.keyboard.press('Enter'); await sleep(200);
    return await page.evaluate(([node, before]) => { const ins = document.getElementById('atlas-inspector');
      const btn = [...document.querySelectorAll('#atlas-list button')].find(b => b.firstChild.textContent === node);
      return { focus_is_inspector: document.activeElement === ins, inspector_h3: ins.querySelector('h3')?.textContent, list_button_pressed: btn?.getAttribute('aria-pressed'),
        url_node: new URL(location.href).searchParams.get('atlas-node'), atlas_panel: document.getElementById('current-atlas').getAttribute('data-atlas-panel'),
        count_text_changed: document.getElementById('atlas-count').textContent !== before, breadcrumb: document.getElementById('atlas-breadcrumb').textContent,
        check: document.activeElement === ins && ins.querySelector('h3')?.textContent === node && btn?.getAttribute('aria-pressed') === 'true' }; }, [NODE, before]);
  });
  await step({ label: 'read inspector start (Orca: Down x3): id, kind/classification, counts', action: 'read' }, async () => {
    const r = await linesFromFocus({ max: 4 }); return { ...r, check: r.lines?.[2]?.text === 'Downstream nodes · all edges: 3. Downstream nodes · required edges: 3.' };
  });
  await step({ label: 'shift+Tab back to the selected list button: pressed state', action: 'key_repeat', keys: 'shift+Tab' }, async () => {
    const n = await pressUntil('Shift+Tab', () => { const a = document.activeElement; return a?.closest('#atlas-list') && a.firstChild?.textContent === 'math.d1-component.congruence-erratum'; }, 8);
    return { count: n, pressed: await page.evaluate(() => document.activeElement.getAttribute('aria-pressed')), check: n !== null && (await page.evaluate(() => document.activeElement.getAttribute('aria-pressed'))) === 'true' };
  });

  // ---------------- Task 3 ----------------
  const STATE_URL = U(`dependencies.html?atlas-node=${NODE}#current-atlas`);
  begin(3, 'Five evidence axes, all/required counts and typed neighbors', STATE_URL);
  await step({ label: 'load selected-node state URL', action: 'navigate' }, async () => { await gotoStart(task.start_url); await atlasReady();
    return { check: await page.evaluate(n => document.querySelector('#atlas-inspector h3')?.textContent === n, NODE) }; });
  await step({ label: 'Tab until "Return to focus" button', action: 'key_repeat', keys: 'Tab' }, async () => {
    const n = await pressUntil('Tab', () => document.activeElement?.id === 'atlas-focus', 20); return { count: n, check: n !== null };
  });
  await step({ label: 'Enter -> focus moves to selected-node inspector', action: 'key', keys: 'Return' }, async () => {
    await page.keyboard.press('Enter'); await sleep(150);
    return { check: await page.evaluate(() => document.activeElement?.id === 'atlas-inspector') };
  });
  await step({ label: 'read counts line (Orca: Down x2 from inspector)', action: 'read' }, async () => {
    const r = await linesFromFocus({ max: 3 }); return { ...r, check: r.lines?.[2]?.text.includes('all edges: 3') && r.lines?.[2]?.text.includes('required edges: 3') };
  });
  await step({ label: 'inspector heading map (Orca H targets)', action: 'read' }, async () => {
    const h = await page.evaluate(() => [...document.querySelectorAll('#atlas-inspector h3,#atlas-inspector h4,#atlas-inspector h5')].map(e => e.tagName + ' ' + e.textContent));
    return { inspector_headings: h, check: h.length > 0 };
  });
  await step({ label: 'read five axes after h5 "Continuation" (Orca: H x5, Down until "Alignment")', action: 'read' }, async () => {
    const r = await page.evaluate(() => { const h = [...document.querySelectorAll('#atlas-inspector h5')].find(e => e.textContent === 'Continuation'); return window.__dr.lines(h, { untilText: 'Alignment metadata', max: 20 }); });
    const axes = await page.evaluate(() => [...document.querySelectorAll('#atlas-inspector dl.atlas-axes dt')].map(dt => [dt.textContent, dt.nextElementSibling.textContent]));
    return { ...r, axes, check: axes.length === 5 && axes.map(a => a[0]).join() === 'source,review,kernel,computation,alignment' };
  });
  await step({ label: 'read typed neighbors (Orca: H to "Consumes", Down; H to "Consumed by", Down x2)', action: 'read' }, async () => {
    const r = await page.evaluate(() => { const h = [...document.querySelectorAll('#atlas-inspector h4')].find(e => e.textContent === 'Consumes'); return window.__dr.lines(h, { untilText: 'reads_with_congruence_erratum', max: 12 }); });
    return { ...r, check: r.reached !== null && r.reached >= 0 };
  });

  // ---------------- Task 4 ----------------
  begin(4, 'Equation search/selection, exact source link and hypotheses warning', U('dependencies.html#current-atlas'));
  await step({ label: 'load atlas (fragment URL)', action: 'navigate' }, async () => { await gotoStart(task.start_url); await atlasReady(); return { check: true }; });
  await step({ label: 'Tab until "Find equation text or source" entry', action: 'key_repeat', keys: 'Tab' }, async () => {
    const n = await pressUntil('Tab', () => document.activeElement?.id === 'equation-search', 200); return { count: n, check: n !== null };
  });
  await step({ label: 'type "periodized"', action: 'type', text: 'periodized' }, async () => {
    await page.keyboard.type('periodized', { delay: 20 }); await sleep(150);
    return await page.evaluate(() => ({ equation_count: document.getElementById('equation-count').textContent, options: document.getElementById('equation-select').options.length,
      first_option: document.getElementById('equation-select').options[1]?.text, check: document.getElementById('equation-count').textContent.startsWith('32 matching excerpts of 108') }));
  });
  await step({ label: 'Tab to excerpt combobox', action: 'key', keys: 'Tab' }, async () => { await page.keyboard.press('Tab'); return { check: await page.evaluate(() => document.activeElement?.id === 'equation-select') }; });
  await step({ label: 'Down selects first match', action: 'key', keys: 'Down' }, async () => {
    await page.keyboard.press('ArrowDown'); await sleep(150);
    return await page.evaluate(() => { const s = document.getElementById('equation-select'); const a = document.querySelector('#equation-content a');
      return { value: s.value, label: s.selectedOptions[0]?.text, link_text: a?.textContent, link_href: a?.href, pre: document.querySelector('#equation-content pre')?.textContent,
        warning: document.querySelector('#equation-content p')?.textContent, check: s.value.endsWith('periodized_gaussian_h0/PROOF.md:27-28') }; });
  });
  await step({ label: 'Tab until source link (do NOT activate)', action: 'key_repeat', keys: 'Tab' }, async () => {
    const n = await pressUntil('Tab', () => document.activeElement?.matches('#equation-content a'), 4);
    return { count: n, check: n !== null && (await page.evaluate(() => document.activeElement.href)) === 'https://github.com/d6g8k5htny-coder/main/blob/f61419d8de39b45b20832a760b90fffa82429ab9/experiments/universality/periodized_gaussian_h0/PROOF.md#L27-L28' };
  });
  await step({ label: 'read around link (Orca: Up for excerpt text, Down x2 for identity + hypotheses warning)', action: 'read' }, async () => {
    const r = await lines('#equation-content', { max: 6 }); return { ...r, check: r.lines.some(l => l.text.includes("The surrounding proof's hypotheses and scope govern this equation")) };
  });

  // ---------------- Task 5 ----------------
  begin(5, 'Preserved mathematical record: original date/revisions and a typed neighbor', STATE_URL);
  await step({ label: 'load selected-node state URL; Tab to Return to focus; Enter', action: 'navigate+keys' }, async () => {
    await gotoStart(task.start_url); await atlasReady();
    const n = await pressUntil('Tab', () => document.activeElement?.id === 'atlas-focus', 20); await page.keyboard.press('Enter'); await sleep(150);
    return { tab_count: n, check: await page.evaluate(() => document.activeElement?.id === 'atlas-inspector') };
  });
  await step({ label: 'Tab to "Read the preserved mathematical record"', action: 'key', keys: 'Tab' }, async () => {
    await page.keyboard.press('Tab'); const d = await page.evaluate(() => ({ text: document.activeElement.textContent, href: document.activeElement.href, next: document.activeElement.nextSibling?.textContent }));
    return { ...d, check: d.text === 'Read the preserved mathematical record' };
  });
  await step({ label: 'Enter opens preserved record (bare URL: Orca Say All on load)', action: 'key', keys: 'Return' }, async () => {
    await enterNav('Enter', `snapshots/${ARCHIVE}/nodes/${NODE}.html`);
    return { headings: await page.evaluate(() => window.__dr.headings()), check: (await page.title()).endsWith('Historical mathematical dependency atlas') };
  });
  await step({ label: 'read date/revisions (Orca: ctrl+Home, H, Down x2; then Down to "Immutable historical")', action: 'read' }, async () => {
    const r = await lines('#current-research h2', { untilText: 'Immutable historical mathematical record', max: 10 });
    return { ...r, check: r.lines?.[1]?.text.startsWith('Original source observation: 2026-10-24T00:43:16Z') && r.lines?.[2]?.text.includes('0899cf51675e2e0d053c2d82a7e954f814ca40ee') && r.lines?.[2]?.text.includes('7d815a5dcfb875b551c21804165e6588cc73d3ab') };
  });
  await step({ label: 'heading positions for "Incoming required" (Orca H/3 count)', action: 'read' }, async () => {
    const h = await page.evaluate(() => window.__dr.headings()); const firstLink = await page.evaluate(() => { const hh = [...document.querySelectorAll('h3')].find(e => e.textContent === 'Incoming required'); const all = [...document.querySelectorAll('a[href]')]; const a = all.find(x => hh.compareDocumentPosition(x) & Node.DOCUMENT_POSITION_FOLLOWING); return a ? { text: a.textContent, href: a.href } : null; }); return { headings: h, incoming_required_index_1based: h.findIndex(x => x.text === 'Incoming required') + 1, first_link_after_incoming_required: firstLink, check: firstLink?.text === 'math.uniform-matrix-cap-lifetime' };
  });
  await step({ label: `focus typed neighbor link ${NEIGHBOR} (Orca: K after H to "Incoming required"; DOM: Tab until)`, action: 'key_repeat', keys: 'Tab' }, async () => {
    await page.evaluate(() => { document.activeElement?.blur(); });
    const n = await pressUntil('Tab', () => { const a = document.activeElement; if (!a || a.tagName !== 'A') return false; let h = a.closest('ul')?.previousElementSibling; return a.textContent === 'math.uniform-matrix-cap-lifetime' && h?.textContent === 'Incoming required'; }, 40);
    return { tab_count_from_document_start: n, row: await page.evaluate(() => document.activeElement.closest('li')?.textContent.replace(/\s+/g, ' ').trim()), check: n !== null };
  });
  await step({ label: 'Enter follows preserved typed neighbor', action: 'key', keys: 'Return' }, async () => {
    await enterNav('Enter', `snapshots/${ARCHIVE}/nodes/${NEIGHBOR}.html`);
    const r = await lines('#current-research h2', { max: 2 });
    return { h1: await page.evaluate(() => document.querySelector('h1')?.textContent), ...r, check: (await page.evaluate(() => document.querySelector('h1')?.textContent)) === NEIGHBOR && r.lines?.[1]?.text.includes('2026-10-24T00:43:16Z') };
  });

  // ---------------- Task 6 ----------------
  begin(6, 'Static node record: its own date/revisions and a typed neighbor', STATE_URL);
  await step({ label: 'load selected-node state URL; Tab to Return to focus; Enter', action: 'navigate+keys' }, async () => {
    await gotoStart(task.start_url); await atlasReady();
    const n = await pressUntil('Tab', () => document.activeElement?.id === 'atlas-focus', 20); await page.keyboard.press('Enter'); await sleep(150);
    return { tab_count: n, check: await page.evaluate(() => document.activeElement?.id === 'atlas-inspector') };
  });
  await step({ label: 'Tab x2 to "Read the static node record"', action: 'key_repeat', keys: 'Tab' }, async () => {
    const n = await pressUntil('Tab', () => document.activeElement?.textContent === 'Read the static node record', 4);
    const d = await page.evaluate(() => ({ href: document.activeElement.href, next: document.activeElement.nextSibling?.textContent })); return { count: n, ...d, check: n === 2 };
  });
  await step({ label: 'Enter opens static node record (bare URL: Orca Say All on load)', action: 'key', keys: 'Return' }, async () => {
    await enterNav('Enter', `/site/nodes/${NODE}.html`);
    return { headings: await page.evaluate(() => window.__dr.headings()), check: (await page.title()).endsWith('Current research dependency atlas') };
  });
  await step({ label: 'read own date/revisions (Orca: ctrl+Home, H, Down x2)', action: 'read' }, async () => {
    const r = await lines('#current-research h2', { max: 3 });
    return { ...r, check: r.lines?.[1]?.text.startsWith('Pinned source observation: 2026-10-25T14:27:24Z') && r.lines?.[2]?.text.includes('f61419d8de39b45b20832a760b90fffa82429ab9') && r.lines?.[2]?.text.includes('c4eabc1a917ba2c1b96fe4af425cf2a484877c03') };
  });
  await step({ label: 'read resume block date/identity (Orca: H to "Resume this node", Down x2)', action: 'read' }, async () => {
    const r = await lines('#resume-node-heading', { max: 3 }); return { ...r, check: r.lines?.[1]?.text.startsWith('As of 2026-10-25T14:27:24Z.') };
  });
  await step({ label: 'heading positions for "Incoming required"', action: 'read' }, async () => {
    const h = await page.evaluate(() => window.__dr.headings()); const firstLink = await page.evaluate(() => { const hh = [...document.querySelectorAll('h3')].find(e => e.textContent === 'Incoming required'); const all = [...document.querySelectorAll('a[href]')]; const a = all.find(x => hh.compareDocumentPosition(x) & Node.DOCUMENT_POSITION_FOLLOWING); return a ? { text: a.textContent, href: a.href } : null; }); return { headings: h, incoming_required_index_1based: h.findIndex(x => x.text === 'Incoming required') + 1, first_link_after_incoming_required: firstLink, check: firstLink?.text === 'math.uniform-matrix-cap-lifetime' };
  });
  await step({ label: `focus typed neighbor link ${NEIGHBOR} (Orca: K after "Incoming required"; DOM: Tab until)`, action: 'key_repeat', keys: 'Tab' }, async () => {
    await page.evaluate(() => { document.activeElement?.blur(); });
    const n = await pressUntil('Tab', () => { const a = document.activeElement; if (!a || a.tagName !== 'A') return false; const h = a.closest('ul')?.previousElementSibling; return a.textContent === 'math.uniform-matrix-cap-lifetime' && h?.textContent === 'Incoming required'; }, 60);
    return { tab_count_from_document_start: n, row: await page.evaluate(() => document.activeElement.closest('li')?.textContent.replace(/\s+/g, ' ').trim()), check: n !== null };
  });
  await step({ label: 'Enter follows static typed neighbor', action: 'key', keys: 'Return' }, async () => {
    await enterNav('Enter', `/site/nodes/${NEIGHBOR}.html`);
    return { h1: await page.evaluate(() => document.querySelector('h1')?.textContent), check: (await page.evaluate(() => document.querySelector('h1')?.textContent)) === NEIGHBOR && !page.url().includes('/snapshots/') };
  });

  // ---------------- Task 7 ----------------
  begin(7, 'Diagnostics: selected counts and explicit missing-report/mapping-gap limits', STATE_URL);
  await step({ label: 'load selected-node state URL; Tab to Return to focus; Enter', action: 'navigate+keys' }, async () => {
    await gotoStart(task.start_url); await atlasReady();
    const n = await pressUntil('Tab', () => document.activeElement?.id === 'atlas-focus', 20); await page.keyboard.press('Enter'); await sleep(150);
    return { tab_count: n, check: await page.evaluate(() => document.activeElement?.id === 'atlas-inspector') };
  });
  await step({ label: 'shift+Tab until Evidence tab', action: 'key_repeat', keys: 'shift+Tab' }, async () => {
    const n = await pressUntil('Shift+Tab', () => document.activeElement?.id === 'atlas-tab-evidence', 5); return { count: n, check: n !== null };
  });
  await step({ label: 'Right arrow moves to Diagnostics tab', action: 'key', keys: 'Right' }, async () => {
    await page.keyboard.press('ArrowRight'); return { check: await page.evaluate(() => document.activeElement?.id === 'atlas-tab-diagnostics') };
  });
  await step({ label: 'Enter activates Diagnostics tab', action: 'key', keys: 'Return' }, async () => {
    await page.keyboard.press('Enter'); await sleep(150);
    return await page.evaluate(() => ({ selected: document.getElementById('atlas-tab-diagnostics').getAttribute('aria-selected'), panel_hidden: document.getElementById('atlas-panel-diagnostics').hidden,
      evidence_hidden: document.getElementById('atlas-panel-evidence').hidden, url_panel: new URL(location.href).searchParams.get('atlas-panel'), focus: document.activeElement.id,
      check: document.getElementById('atlas-tab-diagnostics').getAttribute('aria-selected') === 'true' && !document.getElementById('atlas-panel-diagnostics').hidden }));
  });
  await step({ label: 'Tab until summary "Snapshot diagnostics and mapping gaps"', action: 'key_repeat', keys: 'Tab' }, async () => {
    const n = await pressUntil('Tab', () => document.activeElement?.tagName === 'SUMMARY' && document.activeElement.textContent === 'Snapshot diagnostics and mapping gaps', 4); return { count: n, check: n !== null };
  });
  await step({ label: 'Enter expands diagnostics disclosure', action: 'key', keys: 'Return' }, async () => {
    await page.keyboard.press('Enter'); await sleep(100); return { open: await page.evaluate(() => document.activeElement.parentElement.open), check: await page.evaluate(() => document.activeElement.parentElement.open === true) };
  });
  await step({ label: 'Tab to first mapping-gap button', action: 'key', keys: 'Tab' }, async () => {
    await page.keyboard.press('Tab'); return { check: await page.evaluate(() => document.activeElement?.closest('#atlas-diagnostics') !== null) };
  });
  await step({ label: 'read selection counts + missing report + gaps (Orca: Up x2 from first gap button, then Down)', action: 'read' }, async () => {
    const r = await lines('#atlas-diagnostic-selection', { max: 6 });
    const gaps = await page.evaluate(() => [...document.querySelectorAll('#atlas-diagnostics li')].map(li => li.textContent));
    return { ...r, total_items: gaps.length, items_without_source: gaps.filter(t => t.includes('source metadata not recorded')),
      check: r.lines?.[0]?.text === 'Selected math.d1-component.congruence-erratum: Downstream nodes · all edges: 3. Downstream nodes · required edges: 3. No scientific disposition is inferred.' && r.lines?.[1]?.text.startsWith('Diagnostic report unavailable in this source projection.') };
  });
  await step({ label: `Tab until the selected node's own gap row (${NODE})`, action: 'key_repeat', keys: 'Tab' }, async () => {
    const n = await pressUntil('Tab', () => document.activeElement?.textContent.startsWith('math.d1-component.congruence-erratum:'), 60); return { count_from_first_gap_button: n, check: n !== null };
  });

  // ---------------- Task 8 ----------------
  begin(8, 'History: retained snapshots and absence of admitted live activity', U('dependencies.html#current-atlas'));
  await step({ label: 'load atlas (fragment URL)', action: 'navigate' }, async () => { await gotoStart(task.start_url); await atlasReady(); return { check: true }; });
  await step({ label: 'read retained-history capacity line just before the atlas (Orca: Up from atlas start)', action: 'read' }, async () => {
    const cap = await page.evaluate(() => window.__dr.text('.current-capacity'));
    const prev = await page.evaluate(() => window.__dr.lines('.current-capacity', { max: 2 }));
    return { capacity: cap, following: prev, check: cap?.startsWith('History capacity: 11 of 512 mathematical archives') };
  });
  await step({ label: 'Tab until summary "History and activity"', action: 'key_repeat', keys: 'Tab' }, async () => {
    const n = await pressUntil('Tab', () => document.activeElement?.tagName === 'SUMMARY' && document.activeElement.textContent === 'History and activity', 250); return { count: n, check: n !== null };
  });
  await step({ label: 'Enter expands History and activity', action: 'key', keys: 'Return' }, async () => {
    await page.keyboard.press('Enter'); await sleep(100); return { check: await page.evaluate(() => document.activeElement.parentElement.open === true) };
  });
  await step({ label: 'Tab to "published snapshot manifest" link', action: 'key', keys: 'Tab' }, async () => {
    await page.keyboard.press('Tab'); return { href: await page.evaluate(() => document.activeElement.href), check: await page.evaluate(() => document.activeElement.textContent === 'published snapshot manifest') };
  });
  await step({ label: 'read History paragraph (Orca: Up, then Down until "no live presence")', action: 'read' }, async () => {
    const t = await page.evaluate(() => document.activeElement.closest('p').textContent.replace(/\s+/g, ' ').trim());
    return { paragraph: t, check: t.includes('No activity report is admitted in this projection; no live presence, assignment or review activity is inferred.') };
  });
  await step({ label: 'OPTIONAL Enter on manifest link (local JSON) and inspect retained archive population', action: 'key', keys: 'Return' }, async () => {
    await enterNav('Enter', 'snapshots/index.json');
    const body = await page.evaluate(() => document.body.innerText);
    let parsed = null; try { parsed = JSON.parse(body); } catch {}
    return { is_json: !!parsed, archives: parsed?.archives?.length, archive_ids: parsed?.archives?.map(a => a.id.slice(0, 8) + ' ' + a.observed_at), capacity: parsed?.capacity, current: parsed?.current,
      first_chars: body.slice(0, 120), check: parsed?.archives?.length === 11 };
  });
  await step({ label: 'OPTIONAL browser back (alt+Left) returns to atlas', action: 'key', keys: 'alt+Left' }, async () => {
    let keyboardBack = true;
    try { await Promise.all([page.waitForURL(u => u.href.includes('dependencies.html'), { waitUntil: 'load', timeout: 4000 }), page.keyboard.press('Alt+ArrowLeft')]); }
    catch { keyboardBack = false; await page.goBack({ waitUntil: 'load' }); }
    await atlasReady();
    return { cdp_alt_left_navigated: keyboardBack, fallback: keyboardBack ? null : 'page.goBack() (NOT a keyboard step; browser-UI accelerators are not reachable by CDP key events in headless). Real run: alt+Left as an X key event.', check: page.url().includes('dependencies.html') };
  });
  await step({ label: 'SUPPLEMENTARY atlas Back/Forward (navigation history) after selecting a neighbor', action: 'keys' }, async () => {
    await gotoStart(STATE_URL); await atlasReady();
    await pressUntil('Tab', () => document.activeElement?.id === 'atlas-focus', 20); await page.keyboard.press('Enter'); await sleep(100);
    const n = await pressUntil('Tab', () => { const a = document.activeElement; return a?.tagName === 'BUTTON' && a.closest('#atlas-inspector') && a.firstChild?.textContent === 'math.uniform-matrix-cap-lifetime'; }, 60);
    await page.keyboard.press('Enter'); await sleep(150);
    const afterSelect = await page.evaluate(() => document.querySelector('#atlas-inspector h3')?.textContent);
    const m = await pressUntil('Shift+Tab', () => document.activeElement?.id === 'atlas-back', 80);
    // atlas-back is hidden while the reader panel is open? record state
    const backVisible = await page.evaluate(() => { const b = document.getElementById('atlas-back'); return b.getClientRects().length > 0; });
    await page.keyboard.press('Enter'); await sleep(400);
    const afterBack = await page.evaluate(() => ({ h3: document.querySelector('#atlas-inspector h3')?.textContent, node: new URL(location.href).searchParams.get('atlas-node'), focus: document.activeElement?.id || document.activeElement?.tagName }));
    const f = await pressUntil('Tab', () => document.activeElement?.id === 'atlas-forward', 30); const fwdFocus = { tab_count: f, id: await page.evaluate(() => document.activeElement?.id) };
    if (f === null) return { after_back: afterBack, check: false };
    await page.keyboard.press('Enter'); await sleep(400);
    const afterForward = await page.evaluate(() => ({ h3: document.querySelector('#atlas-inspector h3')?.textContent, node: new URL(location.href).searchParams.get('atlas-node') }));
    return { tab_to_neighbor_button: n, selected_after_enter: afterSelect, shift_tab_to_back: m, back_visible: backVisible, after_back: afterBack, tab_to_forward_after_back: fwdFocus, after_forward: afterForward,
      check: afterSelect === 'math.uniform-matrix-cap-lifetime' && afterBack.h3 === 'math.d1-component.congruence-erratum' && afterForward.h3 === 'math.uniform-matrix-cap-lifetime' };
  });

  begin(9, 'HARNESS SELF-TEST (not a contract task): non-local request is blocked and logged', 'http://refusal-canary.invalid/');
  await step({ label: 'navigate to a .invalid canary; Fetch must fail it (BlockedByClient) and log a refusal', action: 'navigate' }, async () => {
    const before = refusals.length; let err = null;
    try { await page.goto(task.start_url, { waitUntil: 'load', timeout: 10000 }); } catch (e) { err = String(e).split('\n')[0]; }
    return { navigation_error: err, new_refusals: refusals.slice(before), check: refusals.length === before + 1 && /BLOCKED_BY_CLIENT/.test(err || '') };
  });

  const result = { evidence_class: 'DOM/AX ONLY (Playwright CDP key events, headless). NOT screen-reader evidence. NOT Orca speech.',
    replay_class: 'GENERATED-BUNDLE REPLAY (custody bundle served from 127.0.0.1), distinct from deployed-origin and git-source testing',
    base: BASE, versions, started: tasks[0]?.steps[0]?.started, finished: iso(), refusals, tasks,
    summary: tasks.map(t => ({ id: t.id, steps: t.steps.length, ok: t.steps.filter(s => s.ok).length, bad: t.steps.filter(s => !s.ok).map(s => s.n) })) };
  fs.writeFileSync(path.join(OUT, 'dryrun-result.json'), JSON.stringify(result, null, 2));
  fs.writeFileSync(path.join(OUT, 'dryrun-events.json'), JSON.stringify(events, null, 1));
  console.log(JSON.stringify(result.summary), 'refusals:', refusals.length);
  await browser.close();
}
main().catch(e => { console.error(e); process.exit(1); });
