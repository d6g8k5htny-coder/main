'use strict';
// DOM-only debug of atlas Back/Forward focus behaviour. Not screen-reader evidence.
const { chromium } = require('playwright');
const [BASE] = process.argv.slice(2); const ORIGIN = new URL(BASE).origin;
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', headless: true });
  const c = await b.newContext({ viewport: { width: 1200, height: 760 } }); const p = await c.newPage(); const cdp = await c.newCDPSession(p);
  await cdp.send('Fetch.enable', { patterns: [{ urlPattern: '*', requestStage: 'Request' }] });
  cdp.on('Fetch.requestPaused', async q => { if (new URL(q.request.url).origin === ORIGIN) await cdp.send('Fetch.continueRequest', { requestId: q.requestId }); else { console.log('REFUSED', q.request.url); await cdp.send('Fetch.failRequest', { requestId: q.requestId, errorReason: 'BlockedByClient' }); } });
  p.on('framenavigated', f => { if (f === p.mainFrame()) console.log('  [framenavigated]', f.url().replace(BASE, '')); });
  const st = async l => console.log(l, JSON.stringify(await p.evaluate(() => ({ url: location.href.split('/site/')[1].slice(0, 80), hl: history.length, focus: (document.activeElement?.id || document.activeElement?.tagName) + ' ' + (document.activeElement?.textContent || '').slice(0, 50), h3: document.querySelector('#atlas-inspector h3')?.textContent }))));
  const until = async (k, f, m) => { for (let i = 1; i <= m; i++) { await p.keyboard.press(k); if (await p.evaluate(f)) return i; } return null; };
  await p.goto(new URL('dependencies.html?atlas-node=math.d1-component.congruence-erratum#current-atlas', BASE).href, { waitUntil: 'load' });
  await p.waitForFunction(() => !document.getElementById('atlas-search').disabled && document.getElementById('atlas-status').textContent.startsWith('Source'));
  await st('loaded');
  console.log('tab->focus', await until('Tab', () => document.activeElement.id === 'atlas-focus', 20)); await p.keyboard.press('Enter'); await p.waitForTimeout(200); await st('after Return to focus');
  console.log('tab->neighbor', await until('Tab', () => { const a = document.activeElement; return a?.tagName === 'BUTTON' && a.closest('#atlas-inspector') && a.firstChild?.textContent === 'math.uniform-matrix-cap-lifetime'; }, 60));
  await p.keyboard.press('Enter'); await p.waitForTimeout(300); await st('after neighbor Enter');
  console.log('shift-tab->back', await until('Shift+Tab', () => document.activeElement.id === 'atlas-back', 80)); await st('on Back');
  await p.keyboard.press('Enter'); await p.waitForTimeout(500); await st('after Back Enter');
  const f = await until('Shift+Tab', () => document.activeElement.id === 'atlas-forward', 80); console.log('shift-tab->forward', f); await st('on Forward?');
  if (f) { await p.keyboard.press('Enter'); await p.waitForTimeout(500); await st('after Forward Enter'); }
  await b.close();
})().catch(e => { console.error('ERR', String(e).split('\n')[0]); process.exit(1); });
