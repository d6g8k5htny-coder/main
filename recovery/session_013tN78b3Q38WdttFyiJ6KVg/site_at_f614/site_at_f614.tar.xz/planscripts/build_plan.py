#!/usr/bin/python3 -I
# Build plan.json + plan.md for the SITE generated-bundle Orca replay from a hand-written step spec
# plus measured values of the DOM-only dry run (run6). Reads only this lane's own dry-run output.
# usage: python3 -I build_plan.py DRYRUN_RESULT_JSON OUT_DIR
import json, sys, os, hashlib, datetime

res_path, out_dir = sys.argv[1], sys.argv[2]
R = json.load(open(res_path))
DR = {f"{t['id']}.{s['n']}": s for t in R['tasks'] for s in t['steps']}
def dr(ref, *keys):
    s = DR[ref]; out = {'ref': f'run6 {ref}', 'ok': s['ok'], 'label': s['label']}
    for k in keys:
        if k in s['result']: out[k] = s['result'][k]
    return out

P = 'http://127.0.0.1:8770/site/'
NODE = 'math.d1-component.congruence-erratum'
NB = 'math.uniform-matrix-cap-lifetime'
ARCH = 'eee261a6e4c075dfc5318a6b6daaa9b42e482d8b7f6ad9cc43a9d1e4e9d13fc5'
STATE = f'{P}dependencies.html?atlas-node={NODE}#current-atlas'
ATLAS = f'{P}dependencies.html#current-atlas'

def S(action, keys=None, *, until=None, max=None, text=None, mode=None, focus=None, speech=None, dom=None, ref=None, refkeys=(), note=None, optional=False):
    st = {'action': action}
    if keys: st['keys'] = keys
    if text: st['text'] = text
    if until or max:
        st['repeat'] = {'until': until, 'max': max}
    if mode: st['orca_mode'] = mode
    if focus: st['expected_focus'] = focus
    if speech: st['expected_text'] = speech
    if dom: st['dom_check'] = dom
    if optional: st['optional'] = True
    if note: st['notes'] = note
    if ref:
        d = dr(ref, *refkeys); st['dry_run'] = d
        for k in ('count', 'tab_count', 'tab_count_from_document_start', 'count_from_first_gap_button'):
            if k in d and 'repeat' in st and action == 'key_repeat': st['repeat']['dry_run_count'] = d[k]
    return st

ENTER_INSPECTOR = [
    S('navigate', text=STATE, mode='browse (fragment URL: Say All on load suppressed)', focus={'dom': 'section#current-atlas', 'ax': 'region "Equations and dependency worktree"'},
      dom='atlas ready: #atlas-search enabled, #atlas-status starts "Source snapshot", .current-state starts "Verified"; #atlas-inspector h3 == ' + NODE, ref='3.1',
      note='Harness navigation (CDP Page.navigate), not a user key. Wait for the DOM readiness probe, then for speech idle.'),
    S('key_repeat', 'Tab', until='DOM focus is button#atlas-focus "Return to focus"', max=16, mode='browse', focus={'ax': 'button "Return to focus"'},
      speech=['Return to focus'], ref='3.2', refkeys=('count',),
      note='Passes 4 links (Why observation..., Static node index..., Preserved 3 October..., Share...), the search entry, the View combo box and 5 toolbar buttons. Entry and combo box put Orca in focus mode automatically; the next Tab leaves it.'),
    S('key', 'Return', mode='browse', focus={'dom': 'article#atlas-inspector', 'ax': 'article "Selected node source and five evidence axes"'},
      speech=['Selected node source and five evidence axes'], dom='document.activeElement is #atlas-inspector; URL gains atlas-panel=evidence', ref='3.3'),
]

TASKS = []
TASKS.append({
 'id': 1, 'title': 'Primary navigation to Mathematics/current atlas and identification of its source context',
 'contract_wording': 'Primary navigation to Mathematics/current atlas and identification of its source context.',
 'start_url': f'{P}index.html#main-content', 'say_all_on_load': 'suppressed (fragment URL #main-content; Chromium focuses main#main-content)',
 'steps': [
  S('navigate', text=f'{P}index.html#main-content', mode='browse', focus={'dom': 'main#main-content', 'ax': 'main'},
    dom='.current-state becomes "Verified source observation: 2026-10-25T14:27:24Z · stale. This observation is more than two hours old; check upstream sources." (role=status, may be announced)', ref='1.1',
    note='Record the page title Orca speaks ("The shape of randomness · Universal Law") and any status announcement.'),
  S('key_repeat', 'shift+Tab', until='DOM focus is nav[aria-label=Primary] a[href="dependencies.html#current-atlas"]', max=6, mode='browse',
    focus={'ax': 'link "Mathematics"'}, speech=['Cite', 'Reproduce', 'Mathematics'], ref='1.2', refkeys=('count',),
    note='Order: Cite (Research tools), Reproduce, Mathematics (Primary navigation).'),
  S('key', 'Return', mode='browse (new page; fragment suppresses Say All)', focus={'dom': 'section#current-atlas', 'ax': 'region "Equations and dependency worktree"'},
    speech=['Equations and dependency worktree'], dom='URL == ' + ATLAS + '; title "Mathematics · Universal Law"; #atlas-status == "Source snapshot 2026-10-25T14:27:24Z · Math c4eabc1a · 49 nodes, 55 edges (42 required). Classifications are the graph\'s recorded values. No scientific status inferred."', ref='1.3',
    note='Live regions (#atlas-status polite, .current-state status) are filled after current.json verifies; capture any announcement they produce.'),
  S('read', 'Down', until='speech contains "Source snapshot 2026-10-25T14:27:24Z"', max=10, mode='browse',
    speech=['Source snapshot 2026-10-25T14:27:24Z', 'Math c4eabc1a', '49 nodes, 55 edges (42 required)'], ref='1.4',
    note='DOM reading order from the section: eyebrow, h1, intro, "Why observation and classification dates differ" link, then #atlas-status (5th block, 2 visual lines).'),
  S('read', 'Down', until='speech contains "0 explicit graph-to-artifact bindings"', max=5, mode='browse',
    speech=['31 source-bearing metadata records; 0 explicit graph-to-artifact bindings', '108 separately acquired equation excerpts'], ref='1.4'),
  S('read', 'shift+h', until='speech contains "Current research sources"', max=3, mode='browse', speech=['Current research sources'], ref='1.5',
    note='Previous heading before the atlas h1 (the two details in between are collapsed).'),
  S('read', 'Down', until='speech contains "Verified source observation: 2026-10-25T14:27:24Z"', max=4, mode='browse',
    speech=['Verified source observation: 2026-10-25T14:27:24Z', 'stale', 'more than two hours old'], ref='1.5',
    note='Clock-age staleness is expected for this dated input; do not regenerate bytes.'),
  S('read', 'Down', until='speech contains "c4eabc1a917ba2c1b96fe4af425cf2a484877c03"', max=6, mode='browse',
    speech=['main f61419d8de39b45b20832a760b90fffa82429ab9', 'Math- c4eabc1a917ba2c1b96fe4af425cf2a484877c03'], ref='1.5',
    note='These two are external github.com links: read only, never activated.'),
 ],
 'pass_criteria': {
  'PASS': 'Orca speech strings show the Primary-navigation "Mathematics" link reached by real keys and announced; after Return the Mathematics atlas (title "Mathematics · Universal Law" / region or heading "Equations and dependency worktree") is announced; and speech then identifies its source context: source snapshot observation 2026-10-25T14:27:24Z, Math c4eabc1a, 49 nodes / 55 edges (42 required), and the pinned identities main f61419d8de39b45b20832a760b90fffa82429ab9 / Math- c4eabc1a917ba2c1b96fe4af425cf2a484877c03 with the observation\'s clock-age disclosure (stale, more than two hours old).',
  'FAIL': 'The keys reach and activate the controls (DOM evidence) but speech omits, garbles or contradicts the link, the atlas identity or the source context, or Return lands somewhere else.',
  'NOT_OBSERVED': 'The stack did not capture speech for the step (Orca/speech-dispatcher failure, log tail lost without a speech-dispatcher recovery), or the keys could not be delivered as X events.'},
 'notes': ['Start URL uses a fragment, so Orca Say All on load is suppressed; record that.',
           'Source context here = the current atlas status line plus the "Current research sources" observation and pins; the "Why these dates differ" disclosure is optional extra context.'],
})

TASKS.append({
 'id': 2, 'title': 'Graph/List switching, node search and selection, including announced selection',
 'contract_wording': 'Graph/List switching, node search and selection, including announced selection.',
 'start_url': ATLAS, 'say_all_on_load': 'suppressed (fragment URL)', 'chain_alternative': 'May continue on the Task 1 end page (same URL); counts below are from a fresh load.',
 'steps': [
  S('navigate', text=ATLAS, mode='browse', focus={'dom': 'section#current-atlas', 'ax': 'region "Equations and dependency worktree"'}, dom='atlas ready; #atlas-view value "graph"', ref='2.1'),
  S('key_repeat', 'Tab', until='DOM focus is input#atlas-search', max=8, mode='focus (auto: entry)', focus={'ax': 'searchbox "Find in current graph"'},
    speech=['Find in current graph'], ref='2.2', refkeys=('count',)),
  S('key', 'Tab', mode='focus (auto: combo box)', focus={'ax': 'combobox "View" value "Graph"'}, speech=['View', 'Graph'], ref='2.3'),
  S('key', 'Down', mode='focus', focus={'ax': 'combobox "View" value "List"'}, speech=['List'],
    dom='#atlas-view.value=="list"; #atlas-list visible, #atlas-stage hidden; #atlas-toggle-view text "Switch to graph"; URL gains atlas-view=list', ref='2.4',
    note='Chromium on Linux changes a closed select on Down and fires change without opening the popup. If DOM value did not change, Orca kept browse mode: press Insert+a, then Down.'),
  S('key_repeat', 'Tab', until='DOM focus is button#atlas-toggle-view', max=12, mode='browse', focus={'ax': 'button "Switch to graph"'},
    speech=['Switch to graph'], ref='2.5', refkeys=('count',),
    note='Passes Expand one frontier, Collapse to focus, Reset view, Back, Forward, Return to focus, Zoom in, Zoom out (Previous/Next nodes are disabled and skipped).'),
  S('key', 'Return', mode='browse', focus={'ax': 'button "Switch to list"'}, speech=['Switch to list'],
    dom='#atlas-view.value=="graph"; #atlas-stage visible; button text "Switch to list"; focus kept on the button', ref='2.6',
    note='If Orca does not present the name change within 2 s, press KP_Enter (Orca Where Am I) once and record what it says.'),
  S('key', 'Return', mode='browse', focus={'ax': 'button "Switch to graph"'}, speech=['Switch to graph'], dom='#atlas-view.value=="list"', ref='2.7',
    note='Same KP_Enter fallback.'),
  S('key_repeat', 'shift+Tab', until='DOM focus is input#atlas-search', max=14, mode='focus (auto: entry)', focus={'ax': 'searchbox "Find in current graph"'},
    speech=['Find in current graph'], ref='2.8', refkeys=('count',)),
  S('type', text='congruence', mode='focus', focus={'ax': 'searchbox "Find in current graph" value "congruence"'},
    speech=['2 displayed · 2 matching source nodes of 49 indexed source nodes'],
    dom='#atlas-count (aria-live=polite) == "2 displayed · 2 matching source nodes of 49 indexed source nodes · 0 outside this page. ..."; list buttons [math.d1-component.congruence-erratum, math.uniform-matrix-cap-lifetime]', ref='2.9',
    note='One X key event per character (keysyms a-z). Wait about 3 s after the last key for the polite announcement. Intermediate counts may be announced as typing proceeds.'),
  S('key_repeat', 'Tab', until=f'DOM focus is the #atlas-list button whose first text is {NODE}', max=14, mode='browse',
    focus={'ax': f'button (toggle, pressed=false) "{NODE} reading_rule_component · PROVED_REVIEWED Downstream nodes · all edges: 3 · required edges: 3"'},
    speech=[NODE, 'not pressed'], ref='2.10', refkeys=('count', 'pressed')),
  S('key', 'Return', mode='browse', focus={'dom': 'article#atlas-inspector', 'ax': 'article "Selected node source and five evidence axes"'},
    speech=['Selected node source and five evidence axes'],
    dom=f'#atlas-inspector h3 == {NODE}; list button aria-pressed="true"; URL atlas-node={NODE}&atlas-panel=evidence (pushState); breadcrumb "Navigation history: {NB} → {NODE}"; #atlas-count text unchanged', ref='2.11',
    note='This is the page\'s selection announcement: focus moves to the selected-node reader.'),
  S('read', 'Down', until='speech contains "required edges: 3"', max=8, mode='browse', speech=[NODE, 'Kind: reading_rule_component · Classification: PROVED_REVIEWED · D1', 'Downstream nodes · all edges: 3. Downstream nodes · required edges: 3.'], ref='2.12'),
  S('key_repeat', 'shift+Tab', until=f'DOM focus is the #atlas-list button {NODE}', max=6, mode='browse (passes the Evidence tab: focus mode, then back)',
    focus={'ax': f'button (toggle, pressed=true) "{NODE} ..."'}, speech=[NODE, 'pressed'], ref='2.13', refkeys=('count', 'pressed'),
    note='Path: Evidence tab panel, Evidence tab, the uniform-matrix-cap-lifetime list button, then the selected button. Confirms the selection is announced as a pressed state.'),
 ],
 'pass_criteria': {
  'PASS': 'Speech shows: the View combo box operated by real keys with the spoken value changing Graph to List; the "Switch to graph/list" button operated with the change perceivable in speech (name change, or Where Am I); typing "congruence" in "Find in current graph" yields a spoken result count (2 displayed · 2 matching source nodes of 49); the node button is reached and spoken with its name and not-pressed state; and on Return the selection is announced (focus to "Selected node source and five evidence axes" with the selected id, and/or pressed state on return to the button).',
  'FAIL': 'Any of these operate in DOM but are not spoken, are spoken wrongly, or the selection produces no announcement at all.',
  'NOT_OBSERVED': 'Speech capture failed for the relevant steps, or keys could not be delivered.'},
 'notes': ['Node choice: math.d1-component.congruence-erratum (the contract example). The search term "congruence" matches 2 nodes in this bundle.'],
})

TASKS.append({
 'id': 3, 'title': 'Reading all five evidence axes, all/required counts, and typed neighbors',
 'contract_wording': 'Reading all five evidence axes, all/required counts, and typed neighbors.',
 'start_url': STATE, 'say_all_on_load': 'suppressed (fragment URL)',
 'chain_alternative': 'Or continue from Task 2 after its Return (focus already on #atlas-inspector) and skip steps 1-3.',
 'steps': ENTER_INSPECTOR + [
  S('read', 'Down', until='speech contains "required edges: 3"', max=8, mode='browse',
    speech=[NODE, 'Kind: reading_rule_component · Classification: PROVED_REVIEWED · D1', 'Downstream nodes · all edges: 3. Downstream nodes · required edges: 3.'], ref='3.4'),
  S('read', 'h', until='speech contains "Continuation"', max=8, mode='browse', speech=['Resume this node', 'Recorded graph state', 'Recorded review record', 'Operational task state', 'Continuation'], ref='3.5',
    note='Inspector headings in order: h3 id, h4 Resume this node, h5 Recorded graph state, h5 Recorded review record, h5 Operational task state, h5 Continuation, h4 Consumes, h4 Consumed by.'),
  S('read', 'Down', until='speech contains "Alignment metadata not recorded"', max=22, mode='browse',
    speech=['source', 'Source metadata recorded · recorded', 'review', 'Review metadata recorded · recorded', 'kernel', 'Kernel metadata not recorded · not_recorded',
            'computation', 'Computation metadata not recorded · not_recorded', 'alignment', 'Alignment metadata not recorded · not_recorded'], ref='3.6', refkeys=('axes',)),
  S('read', 'h', until='speech contains "Consumes"', max=3, mode='browse', speech=['Consumes'], ref='3.7'),
  S('read', 'Down', until='speech contains "No direct relation recorded"', max=3, mode='browse', speech=['No direct relation recorded.'], ref='3.7'),
  S('read', 'h', until='speech contains "Consumed by"', max=3, mode='browse', speech=['Consumed by'], ref='3.7'),
  S('read', 'Down', until='speech contains "reads_with_congruence_erratum"', max=10, mode='browse',
    speech=[NB, 'candidate · PROVED_REVIEWED', 'all edges: 2 · required edges: 2', f'Required · reads_with_congruence_erratum · {NB} → {NODE}'], ref='3.7'),
 ],
 'pass_criteria': {
  'PASS': 'Speech reads all five axes with their states (this bundle: source recorded, review recorded, kernel/computation/alignment not_recorded), both counts (all edges 3, required edges 3), and the typed neighbors with direction and type (Consumes: none recorded; Consumed by: math.uniform-matrix-cap-lifetime, Required, reads_with_congruence_erratum, uniform-matrix-cap-lifetime → congruence-erratum).',
  'FAIL': 'Any axis, count or neighbor type/direction is missing from speech or spoken with a different value than the DOM.',
  'NOT_OBSERVED': 'Speech capture failed, or the inspector could not be reached by keys.'},
 'notes': ['Dated contract example (3/3; source/review recorded; kernel/computation/alignment not_recorded) is matched by this bundle at Math c4eabc1a.'],
})

TASKS.append({
 'id': 4, 'title': 'Equation search/selection and identification of the exact source link and hypotheses warning',
 'contract_wording': 'Equation search/selection and identification of the exact source link and hypotheses warning.',
 'start_url': ATLAS, 'say_all_on_load': 'suppressed (fragment URL)',
 'steps': [
  S('navigate', text=ATLAS, mode='browse', focus={'dom': 'section#current-atlas'}, dom='atlas ready; #equation-select enabled', ref='4.1'),
  S('key_repeat', 'Tab', until='DOM focus is input#equation-search', max=60, mode='focus (auto: entry)', focus={'ax': 'searchbox "Find equation text or source"'},
    speech=['Find equation text or source'], ref='4.2', refkeys=('count',),
    note='Long Tab path through the default graph neighborhood and inspector. Alternative, not DOM-verified: Orca "e" twice (next entry) then Insert+a to enter focus mode.'),
  S('type', text='periodized', mode='focus', focus={'ax': 'searchbox "Find equation text or source" value "periodized"'},
    speech=['32 matching excerpts of 108 acquired excerpts'],
    dom='#equation-count (role=status) == "32 matching excerpts of 108 acquired excerpts. Search covers exact text and public source paths; no equation-to-node logical join is inferred."', ref='4.3', refkeys=('first_option',)),
  S('key', 'Tab', mode='focus (auto: combo box)', focus={'ax': 'combobox "Exact acquired equation excerpt" value "Choose a source equation excerpt"'},
    speech=['Exact acquired equation excerpt'], ref='4.4'),
  S('key', 'Down', mode='focus', focus={'ax': 'combobox "Exact acquired equation excerpt" value "periodized_gaussian_h0/PROOF.md · lines 27–28"'},
    speech=['periodized_gaussian_h0/PROOF.md', 'lines 27–28'],
    dom='select value "d6g8k5htny-coder/main:experiments/universality/periodized_gaussian_h0/PROOF.md:27-28"; #equation-content shows pre, link, identity/warning', ref='4.5', refkeys=('link_href', 'warning')),
  S('key_repeat', 'Tab', until='DOM focus is #equation-content a', max=4, mode='browse', focus={'ax': 'link "Read exact source lines and surrounding hypotheses"'},
    speech=['Next excerpt', 'Read exact source lines and surrounding hypotheses'], ref='4.6', refkeys=('count',),
    note='DO NOT press Return here. The link is external github.com: reading it and activating it are separate observations, and activation is not performed (any accidental activation must be failed by CDP Fetch and logged as a refusal).'),
  S('read', 'Down', until='speech contains "hypotheses and scope govern this equation"', max=6, mode='browse',
    speech=['Acquired excerpt · d6g8k5htny-coder/main f61419d8de39b45b20832a760b90fffa82429ab9', 'lines 27–28', "The surrounding proof's hypotheses and scope govern this equation; excerpt extraction is not theorem acceptance."], ref='4.7'),
  S('read', 'Up', until='speech contains "K_24(z)"', max=6, mode='browse', speech=['K_24(z)=sum_(j in Z^d) exp(-|z+24j|^2/2)'], ref='4.7', optional=True,
    note='Optional: the excerpt text itself (pre).'),
 ],
 'pass_criteria': {
  'PASS': 'Speech shows the equation search operated by typing with the spoken result count (this bundle: 32 matching excerpts of 108 for "periodized"), the excerpt selected by keyboard (periodized_gaussian_h0/PROOF.md · lines 27–28), the link "Read exact source lines and surrounding hypotheses", the identity line naming d6g8k5htny-coder/main f61419d8de39b45b20832a760b90fffa82429ab9 lines 27–28, and the hypotheses warning sentence. The exact link target (https://github.com/d6g8k5htny-coder/main/blob/f61419d8de39b45b20832a760b90fffa82429ab9/experiments/universality/periodized_gaussian_h0/PROOF.md#L27-L28) is DOM evidence, reported separately.',
  'FAIL': 'Count, selected excerpt, link name, identity line or warning is not spoken or is spoken wrongly.',
  'NOT_OBSERVED': 'Speech capture failed. Link activation is NOT_OBSERVED by rule (external; not activated), which is reported separately and does not by itself fail the reading task.'},
 'notes': ['Dated contract example "32 of 108; lines 27–28 link to immutable Main f614" is matched by this bundle (commit f61419d8de39b45b20832a760b90fffa82429ab9).'],
})

def neighbor_steps(page_kind):
    if page_kind == 'preserved':
        title = f'{NODE} · Historical mathematical dependency atlas'; first_h = 'Historical mathematical material'
        date_line = 'Original source observation: 2026-10-24T00:43:16Z'; pins = ['main 0899cf51675e2e0d053c2d82a7e954f814ca40ee', 'Math- 7d815a5dcfb875b551c21804165e6588cc73d3ab']
        nb_url = f'{P}snapshots/{ARCH}/nodes/{NB}.html'; nb_title = f'{NB} · Historical mathematical dependency atlas'; T = '5'
    else:
        title = f'{NODE} · Current research dependency atlas'; first_h = 'Current research sources'
        date_line = 'Pinned source observation: 2026-10-25T14:27:24Z'; pins = ['main f61419d8de39b45b20832a760b90fffa82429ab9', 'Math- c4eabc1a917ba2c1b96fe4af425cf2a484877c03']
        nb_url = f'{P}nodes/{NB}.html'; nb_title = f'{NB} · Current research dependency atlas'; T = '6'
    return title, first_h, date_line, pins, nb_url, nb_title, T

for kind in ('preserved', 'static'):
    title, first_h, date_line, pins, nb_url, nb_title, T = neighbor_steps(kind)
    link_name = 'Read the preserved mathematical record' if kind == 'preserved' else 'Read the static node record'
    href = f'{P}snapshots/{ARCH}/nodes/{NODE}.html' if kind == 'preserved' else f'{P}nodes/{NODE}.html'
    steps = [dict(s, dry_run=dr(f'{T}.1', 'tab_count')) if i == 0 else s for i, s in enumerate(ENTER_INSPECTOR)]
    steps[1] = dict(steps[1], dry_run=dr(f'{T}.1', 'tab_count'))
    steps[2] = dict(steps[2], dry_run=dr(f'{T}.1'))
    steps += [
      S('key_repeat' if kind == 'static' else 'key', 'Tab', until=(f'DOM focus is link "{link_name}"' if kind == 'static' else None), max=(4 if kind == 'static' else None),
        mode='browse', focus={'ax': f'link "{link_name}"'}, speech=[link_name], dom=f'href == {href}', ref=f'{T}.2', refkeys=('count', 'href', 'next')),
      S('key', 'Return', mode='browse (bare URL: Orca Say All on load starts)', focus={'dom': 'body'}, speech=[title],
        dom=f'URL == {href}; title "{title}"; CSP script-src \'none\' (no JS on this page)', ref=f'{T}.3',
        note='Wait for load plus about 3 s and keep whatever Say All speaks (it is speech evidence). Chromium also requests /favicon.ico, which is a local 404 "not in bundle"; preserve it as an absent resource.'),
      S('key', 'ctrl+Home', mode='browse', note='Stops Say All and moves the caret to the top of the document.'),
      S('read', 'h', until=f'speech contains "{first_h}"', max=2, mode='browse', speech=[first_h], ref=f'{T}.4'),
      S('read', 'Down', until=f'speech contains "{date_line.split(": ")[1]}"', max=4, mode='browse', speech=[date_line], ref=f'{T}.4'),
      S('read', 'Down', until=f'speech contains "{pins[1].split(" ")[1]}"', max=6, mode='browse', speech=pins, ref=f'{T}.4',
        note='External github.com links: read only.'),
    ]
    if kind == 'preserved':
        steps += [S('read', 'Down', until='speech contains "Immutable historical mathematical record"', max=30, mode='browse', optional=True,
                    speech=[f'Immutable historical mathematical record · mathematical SHA-256 {ARCH}'], ref='5.4',
                    note='Optional: archive identity line. A 13-line references paragraph comes first.')]
        h_note = 'Headings on this page: Historical mathematical material, h1 id, Independent evidence metadata axes, Source and recorded review references, Original node metadata, Typed neighbors, Outgoing required, Outgoing context, Incoming required (9th), Incoming context. Alternative: "3" (next level-3 heading) three times.'
        h_max = 10
    else:
        steps += [S('read', 'h', until='speech contains "Resume this node"', max=3, mode='browse', speech=['Resume this node'], ref='6.5'),
                  S('read', 'Down', until='speech contains "As of 2026-10-25T14:27:24Z"', max=3, mode='browse', speech=['As of 2026-10-25T14:27:24Z.'], ref='6.5'),
                  S('read', 'Down', until='speech contains "main commit f61419d8de39b45b20832a760b90fffa82429ab9"', max=12, mode='browse',
                    speech=['Snapshot identity: graph d6g8k5htny-coder/Math- commit c4eabc1a917ba2c1b96fe4af425cf2a484877c03', 'main commit f61419d8de39b45b20832a760b90fffa82429ab9'], ref='6.5')]
        h_note = 'Headings: Current research sources, h1 id, Resume this node, Recorded graph state, Recorded review record, Operational task state, Continuation, Independent evidence metadata axes, Source and recorded review references, Original node metadata, Typed neighbors, Outgoing required, Outgoing context, Incoming required (14th), Incoming context. Alternative from "Resume this node": "3" seven times.'
        h_max = 14
    steps += [
      S('read', 'h', until='speech contains "Incoming required"', max=h_max, mode='browse', speech=['Incoming required'], ref=f'{T}.{5 if kind=="preserved" else 6}',
        refkeys=('incoming_required_index_1based', 'first_link_after_incoming_required'), note=h_note),
      S('read', 'Down', until='speech contains "reads_with_congruence_erratum"', max=3, mode='browse',
        speech=[NB, 'reads_with_congruence_erratum', f'{NB} → {NODE}', 'required: true'], ref=f'{T}.{6 if kind=="preserved" else 7}'),
      S('read', 'shift+h', until='speech contains "Incoming required"', max=2, mode='browse', note='Returns the caret to the heading so that "k" lands on the neighbor link.'),
      S('key', 'k', mode='browse', focus={'dom': f'a[href="{NB}.html"]', 'ax': f'link "{NB}"'}, speech=[NB],
        dom='DOM check before Return: document.activeElement must be the neighbor link (Orca grabs focus on links). Dry run verified that the first link after the "Incoming required" heading is that link.',
        ref=f'{T}.{6 if kind=="preserved" else 7}', refkeys=('tab_count_from_document_start', 'row'),
        note='Fallback if DOM focus did not move: Tab until DOM focus is the neighbor link (dry run measured this count from the document start).'),
      S('key', 'Return', mode='browse (bare URL: Say All on load)', focus={'dom': 'body'}, speech=[nb_title],
        dom=f'URL == {nb_url}; h1 == {NB}', ref=f'{T}.{7 if kind=="preserved" else 8}'),
      S('key', 'ctrl+Home', mode='browse'),
      S('read', 'h', until=f'speech contains "{first_h}"', max=2, mode='browse', speech=[first_h]),
      S('read', 'Down', until=f'speech contains "{date_line.split(": ")[1]}"', max=4, mode='browse', speech=[date_line],
        ref=('5.7' if kind == 'preserved' else None), note=('Preserved neighbor keeps the same archived observation.' if kind == 'preserved' else 'Static neighbor keeps the current observation.')),
      S('read', 'h', until=f'speech contains "{NB}"', max=2, mode='browse', speech=[NB]),
    ]
    if kind == 'preserved':
        TASKS.append({'id': 5, 'title': 'Opening the preserved mathematical record, identifying its original date/revisions, and using a typed neighbor',
          'contract_wording': 'Opening the preserved mathematical record, identifying its original date/revisions, and using a typed neighbor.',
          'start_url': STATE, 'say_all_on_load': 'suppressed on the atlas (fragment); ACTIVE on the preserved page and its neighbor (bare URLs reached by link)',
          'chain_alternative': 'Or continue from Task 3 with focus on #atlas-inspector and skip steps 1-3.',
          'steps': steps,
          'pass_criteria': {
            'PASS': 'Speech shows "Read the preserved mathematical record" reached and activated; arrival on the preserved record (title or heading "Historical mathematical material" plus the node id); its original date 2026-10-24T00:43:16Z and original revisions main 0899cf51675e2e0d053c2d82a7e954f814ca40ee / Math- 7d815a5dcfb875b551c21804165e6588cc73d3ab (distinct from the current 2026-10-25T14:27:24Z, f61419d8 and c4eabc1a); the typed neighbor row (Incoming required · reads_with_congruence_erratum · required: true); and arrival on the preserved neighbor page math.uniform-matrix-cap-lifetime (Historical) with the same archived observation.',
            'FAIL': 'The preserved page is reached but its date/revisions or the neighbor are not spoken or are spoken wrongly, or the neighbor link lands on a non-preserved page.',
            'NOT_OBSERVED': 'Speech capture failed or the link could not be activated by keys.'},
          'notes': [f'Preserved mathematical record = snapshots/{ARCH}/nodes/{NODE}.html (immutable archive {ARCH[:8]}, archive_version 2, observed 2026-10-24T00:43:16Z). The atlas derives this link from the single archive link in #current-research.',
                    'Not the "Preserved 3 October dependency snapshot" in the lower half of dependencies.html, which is a different, older viewer (Math 7858329).']})
    else:
        TASKS.append({'id': 6, 'title': 'Opening the static node record, identifying its own date/revisions, and using a typed neighbor',
          'contract_wording': 'Opening the static node record, identifying its own date/revisions, and using a typed neighbor.',
          'start_url': STATE, 'say_all_on_load': 'suppressed on the atlas (fragment); ACTIVE on the static page and its neighbor (bare URLs reached by link)',
          'chain_alternative': 'Or continue from Task 3 with focus on #atlas-inspector and skip steps 1-3.',
          'steps': steps,
          'pass_criteria': {
            'PASS': 'Speech shows "Read the static node record" reached and activated; arrival on the static record (title "… · Current research dependency atlas" or heading "Current research sources" plus the node id); its own date 2026-10-25T14:27:24Z (Pinned source observation and Resume "As of") and revisions main f61419d8de39b45b20832a760b90fffa82429ab9 / Math- c4eabc1a917ba2c1b96fe4af425cf2a484877c03; the typed neighbor row; and arrival on nodes/math.uniform-matrix-cap-lifetime.html (current, not snapshots/).',
            'FAIL': 'Date/revisions or neighbor not spoken or spoken wrongly, or the neighbor lands in the archive.',
            'NOT_OBSERVED': 'Speech capture failed or the link could not be activated by keys.'},
          'notes': [f'Static node record = nodes/{NODE}.html (current observation alias). It has no JavaScript (CSP script-src \'none\'), so it prints "Compare this timestamp with the present time" instead of a computed stale state.']})

TASKS.append({
 'id': 7, 'title': 'Operating Diagnostics and reading selected counts plus explicit missing-report/mapping-gap limits',
 'contract_wording': 'Operating Diagnostics and reading selected counts plus explicit missing-report/mapping-gap limits.',
 'start_url': STATE, 'say_all_on_load': 'suppressed (fragment URL)', 'chain_alternative': 'Or continue from Task 3 with focus on #atlas-inspector and skip steps 1-3.',
 'steps': [dict(ENTER_INSPECTOR[0], dry_run=dr('7.1')), dict(ENTER_INSPECTOR[1], dry_run=dr('7.1', 'tab_count')), dict(ENTER_INSPECTOR[2], dry_run=dr('7.1'))] + [
  S('key_repeat', 'shift+Tab', until='DOM focus is button#atlas-tab-evidence (role tab)', max=4, mode='focus (auto: page tab)', focus={'ax': 'tab "Evidence" selected'},
    speech=['Evidence'], ref='7.2', refkeys=('count',), note='First shift+Tab lands on the Evidence tab panel, the second on the Evidence tab.'),
  S('key', 'Right', mode='focus', focus={'dom': 'button#atlas-tab-diagnostics', 'ax': 'tab "Diagnostics" not selected'}, speech=['Diagnostics'], ref='7.3',
    note='Manual-activation tabs: arrows move focus only. If DOM focus stayed on Evidence, Orca was in browse mode: press Insert+a and repeat Right.'),
  S('key', 'Return', mode='focus', focus={'ax': 'tab "Diagnostics" selected'}, speech=['Diagnostics'],
    dom='aria-selected="true"; #atlas-panel-diagnostics visible; evidence panel hidden; URL atlas-panel=diagnostics', ref='7.4'),
  S('key_repeat', 'Tab', until='DOM focus is summary "Snapshot diagnostics and mapping gaps"', max=4, mode='focus (auto: expandable)',
    focus={'ax': 'DisclosureTriangle "Snapshot diagnostics and mapping gaps" expanded=false'}, speech=['Diagnostics', 'Snapshot diagnostics and mapping gaps', 'collapsed'], ref='7.5', refkeys=('count',)),
  S('key', 'Return', mode='focus', focus={'ax': 'DisclosureTriangle expanded=true'}, speech=['expanded'], ref='7.6'),
  S('key', 'Tab', mode='browse', focus={'ax': 'button "eng.d0-packet-allowlist-fix: no explicit graph-to-artifact binding; roles/custody unknown"'},
    speech=['eng.d0-packet-allowlist-fix: no explicit graph-to-artifact binding; roles/custody unknown'], ref='7.7'),
  S('read', 'Up', until='speech contains "Diagnostic report unavailable in this source projection"', max=5, mode='browse',
    speech=['Diagnostic report unavailable in this source projection. Engineering generation checks are separate from mathematical evidence.'], ref='7.8'),
  S('read', 'Up', until=f'speech contains "Selected {NODE}"', max=5, mode='browse', speech=[f'Selected {NODE}: Downstream nodes · all edges: 3.'], ref='7.8'),
  S('read', 'Down', until='speech contains "No scientific disposition is inferred"', max=4, mode='browse', speech=['Downstream nodes · required edges: 3.', 'No scientific disposition is inferred.'], ref='7.8'),
  S('read', 'Down', until='speech contains "source metadata not recorded"', max=18, mode='browse',
    speech=['eng.hard-gate: no explicit graph-to-artifact binding; roles/custody unknown', 'hist.ALLCELL-FDZ-Q4: no explicit graph-to-artifact binding; roles/custody unknown', 'source metadata not recorded'], ref='7.8',
    refkeys=('total_items',), note='18 of the 49 node rows carry "· source metadata not recorded".'),
  S('read', 'b', until=f'speech contains "{NODE}: no explicit graph-to-artifact binding"', max=20, mode='browse', optional=True,
    speech=[f'{NODE}: no explicit graph-to-artifact binding; roles/custody unknown'], ref='7.9', refkeys=('count_from_first_gap_button',),
    note='Optional: the selected node\'s own mapping-gap row.'),
 ],
 'pass_criteria': {
  'PASS': 'Speech shows the Diagnostics tab reached and activated by keys and the "Snapshot diagnostics and mapping gaps" disclosure expanded, then reads (a) the selected counts "Selected math.d1-component.congruence-erratum: Downstream nodes · all edges: 3. Downstream nodes · required edges: 3. No scientific disposition is inferred.", (b) the explicit missing-report limit "Diagnostic report unavailable in this source projection. Engineering generation checks are separate from mathematical evidence.", and (c) at least one mapping-gap statement ("…: no explicit graph-to-artifact binding; roles/custody unknown") plus one "· source metadata not recorded". Reading the stated missing report satisfies the reading task; no report content is invented.',
  'FAIL': 'The tab or disclosure cannot be operated by keys, or the counts or limits are missing from speech or misreported.',
  'NOT_OBSERVED': 'Speech capture failed.'},
 'notes': ['"Diagnostics" = the role=tab "Diagnostics" in the selected-node reader (atlas-shell.mjs), whose panel holds the "Snapshot diagnostics and mapping gaps" details moved there at runtime.'],
})

TASKS.append({
 'id': 8, 'title': 'Operating History and identifying retained snapshots and the absence of admitted live activity',
 'contract_wording': 'Operating History and identifying retained snapshots and the absence of admitted live activity.',
 'start_url': ATLAS, 'say_all_on_load': 'suppressed (fragment URL)',
 'steps': [
  S('navigate', text=ATLAS, mode='browse', focus={'dom': 'section#current-atlas'}, dom='atlas ready', ref='8.1'),
  S('read', 'Up', until='speech contains "History capacity: 11 of 512 mathematical archives"', max=5, mode='browse',
    speech=['History capacity: 11 of 512 mathematical archives'], ref='8.2', refkeys=('capacity',),
    note='The capacity paragraph is the last block of #current-research, immediately before the atlas section.'),
  S('read', 'Down', until='speech contains "no history is pruned"', max=4, mode='browse', speech=['Publication refuses additional versions at capacity; no history is pruned.'], ref='8.2'),
  S('key_repeat', 'Tab', until='DOM focus is summary "History and activity"', max=60, mode='focus (auto: expandable)',
    focus={'ax': 'DisclosureTriangle "History and activity" expanded=false'}, speech=['History and activity', 'collapsed'], ref='8.3', refkeys=('count',),
    note='Long Tab path (graph neighborhood, inspector, equation controls). The diagnostics summary is in the hidden Diagnostics panel and is skipped.'),
  S('key', 'Return', mode='focus', focus={'ax': 'DisclosureTriangle expanded=true'}, speech=['expanded'], ref='8.4'),
  S('key', 'Tab', mode='browse', focus={'ax': 'link "published snapshot manifest"'}, speech=['published snapshot manifest'], dom=f'href == {P}snapshots/index.json (local)', ref='8.5'),
  S('read', 'Up', until='speech contains "This view selects one current source snapshot"', max=4, mode='browse', speech=['This view selects one current source snapshot.'], ref='8.6'),
  S('read', 'Down', until='speech contains "no live presence, assignment or review activity is inferred"', max=6, mode='browse',
    speech=['the published snapshot manifest identifies the retained population', 'No activity report is admitted in this projection; no live presence, assignment or review activity is inferred.'], ref='8.6'),
  S('key', 'Return', mode='browse (bare URL: Say All on JSON text)', optional=True, focus={'dom': 'body'},
    dom=f'URL == {P}snapshots/index.json; JSON archives[] has 11 ids (7c583e28 … eee261a6), capacity.snapshots 11, current {ARCH[:8]}…', ref='8.7', refkeys=('archives', 'archive_ids', 'capacity'),
    note='Optional, local only. Before pressing Return, re-check DOM focus is still on the manifest link (Up/Down may have moved it); if not, Tab until it. Interrupt Say All with ctrl+Home after about 5 s. The JSON field "origin" names a github.io URL as text only: nothing is fetched.'),
  S('key', 'alt+Left', optional=True, mode='browse', dom='back on dependencies.html', ref='8.8', refkeys=('cdp_alt_left_navigated', 'fallback'),
    note='Browser-UI accelerator. The headless dry run could not deliver it as a CDP key and used page.goBack(); the real run must send it as an X key event.'),
  S('keys', 'SUPPLEMENTARY: from STATE URL: Tab x12, Return; Tab until inspector button math.uniform-matrix-cap-lifetime, Return; shift+Tab until #atlas-back, Return; Tab until #atlas-forward, Return', optional=True,
    mode='browse', dom='After Back: selection math.d1-component.congruence-erratum restored and DOM focus on section#current-atlas. After Forward: selection math.uniform-matrix-cap-lifetime and focus on #atlas-inspector.',
    ref='8.9', refkeys=('tab_to_neighbor_button', 'shift_tab_to_back', 'after_back', 'tab_to_forward_after_back', 'after_forward'),
    note='Navigation-history Back/Forward of the atlas. Supplementary to, not part of, the History disclosure observation.'),
 ],
 'pass_criteria': {
  'PASS': 'Speech shows the "History and activity" disclosure reached and expanded by keys and its text read, including that the published snapshot manifest identifies the retained population and "No activity report is admitted in this projection; no live presence, assignment or review activity is inferred."; and the retained snapshots identified by the spoken "History capacity: 11 of 512 mathematical archives … no history is pruned." (DOM: the manifest lists the same 11 archive ids as custody).',
  'FAIL': 'The disclosure cannot be operated, or the activity-absence statement or the retained-snapshot count is missing from speech or misreported.',
  'NOT_OBSERVED': 'Speech capture failed.'},
 'notes': ['"History" = the "History and activity" details in the atlas. In readable HTML, the retained snapshots are given only as the capacity count plus the link to snapshots/index.json, which is JSON; speech can identify the count, not each id.',
           'The atlas Back/Forward buttons are navigation history (supplementary observation 8.9).'],
})

for t in TASKS:
    for i, s in enumerate(t['steps'], 1): s['n'] = i
    refs = sorted({s['dry_run']['ref'] for s in t['steps'] if 'dry_run' in s})
    oks = [s['dry_run']['ok'] for s in t['steps'] if 'dry_run' in s]
    t['dry_run_summary'] = f"DOM-only dry run (run6): {sum(oks)}/{len(oks)} referenced step checks OK ({', '.join(r.split()[1] for r in refs)})."

plan = {
 'schema': 'site-at-orca-plan/1',
 'generated_at': datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),
 'lane': {'session': 'session_013tN78b3Q38WdttFyiJ6KVg ("Claude 54")', 'pickup': 'https://github.com/d6g8k5htny-coder/main/issues/539#issuecomment-6400510700',
          'contract': 'https://github.com/d6g8k5htny-coder/main/issues/475#issuecomment-6399096111', 'handoff': 'https://github.com/d6g8k5htny-coder/main/issues/539#issuecomment-6399518119',
          'route_proposal': 'https://github.com/d6g8k5htny-coder/main/issues/475#issuecomment-6399102609'},
 'replay_class': 'GENERATED-BUNDLE REPLAY of carrier 665f068607840ba5326e4089b1b62972902310bb (Main f61419d8, Math c4eabc1a, observation 2026-10-25T14:27:24Z). Distinct from deployed-origin testing and from git-source testing.',
 'bundle': {'path': '/tmp/claude-0/-home-user-main/d5c985ca-97e5-58d8-a9d4-1e0a19065a22/scratchpad/siteat/bundle/', 'files': 861, 'bytes': 20900216,
            'fingerprint': 'f192a8f3e87c9c4ce59e6c084d2848a2bc8d35e4859a943d69a5a4baf156cdac'},
 'serve_command': 'cd /tmp/claude-0/-home-user-main/d5c985ca-97e5-58d8-a9d4-1e0a19065a22/scratchpad/siteat/scripts && /opt/node22/bin/node /tmp/claude-0/-home-user-main/d5c985ca-97e5-58d8-a9d4-1e0a19065a22/scratchpad/siteat/scripts/serve.mjs /tmp/claude-0/-home-user-main/d5c985ca-97e5-58d8-a9d4-1e0a19065a22/scratchpad/siteat/bundle <LOG_PATH.jsonl> 8770',
 'serve_note': 'Start it as "(cd …/scripts && exec node serve.mjs …) &" so that $! is the node PID and SIGTERM reaches serve.mjs, which then logs {"event":"stopped"}. A plain "cd … && node … &" leaves node orphaned when the subshell is killed (seen in dry run 1).',
 'url_prefix': P,
 'evidence_classes': {
   'speech': 'Orca speech strings: what Orca handed to speech-dispatcher, timestamped from the Orca debug log (tail recovered from the speech-dispatcher log if lost, with those lines marked). This is the only screen-reader evidence.',
   'dom_ax': 'DOM/accessibility-tree text and focus, from CDP probes (Runtime.evaluate on document.activeElement, Accessibility.getPartialAXTree). This is a separate class, and it is the only class this plan\'s dry run produced.',
   'keyboard': 'Keyboard operation: each real X key event sent through AT-SPI (keysym, ISO time), with DOM focus before and after it.'},
 'environment': {
   'browser': 'Chromium 141.0.7390.37 at /opt/pw-browsers/chromium-1194/chrome-linux/chrome, --force-renderer-accessibility, --window-size=1200,850 (viewport must stay wider than 720 px: below that the atlas switches to its mobile list/reader layout and every Tab count changes)',
   'network_block': 'CDP Fetch.enable {patterns:[{urlPattern:"*", requestStage:"Request"}]} on the page target BEFORE the first navigation; continue only origin http://127.0.0.1:8770; Fetch.failRequest(BlockedByClient) and log every other request as a refusal. No relays (the C220 raw.githubusercontent relay must NOT be reused).',
   'orca': 'Orca 46.1 under /usr/bin/python3.12, default profile. Checked here: nativeNavTriggersFocusMode=True, structNavTriggersFocusMode=False, caretNavTriggersFocusMode=False. PAGE_TAB, COMBO_BOX and ENTRY, plus focusable expandable elements (summary), are focus-mode widgets. Orca+a (Insert+a) toggles browse/focus mode. The modifier is Insert / KP_Insert (desktop layout).',
   'speech': 'speech-dispatcher 0.12 started explicitly with the C220 scratch config and SPEECHD_ADDRESS; espeak-ng 1.51; paced ALSA file sink. One stack at a time.'},
 'key_injection': {
   'method': 'Atspi.generate_keyboard_event(keysym, None, Atspi.KeySynthType.SYM) per key (extend c220/scripts/xtest_key.py). For modifier chords, press the modifier keycode with KeySynthType.PRESS, send the key, then KeySynthType.RELEASE. Keycodes come from "xmodmap -pke" under Xvfb :99; typical evdev values are Shift_L 50, Control_L 37, Alt_L 64, Insert 118, KP_Enter 104; verify them.',
   'keysyms': {'Tab': '0xff09', 'Return': '0xff0d', 'Up': '0xff52', 'Down': '0xff54', 'Left': '0xff51', 'Right': '0xff53', 'Home': '0xff50', 'KP_Enter': '0xff8d', 'Insert': '0xff63',
               'Shift_L': '0xffe1', 'Control_L': '0xffe3', 'Alt_L': '0xffe9', 'a-z': '0x61-0x7a', '3': '0x33'},
   'never': 'CDP Input.dispatchKeyEvent is invisible to Orca (C220-02); use it only for DOM-only dry runs.'},
 'step_protocol': {
   'boundaries': 'For every step log: step id, ISO time the key was sent, keysym(s), DOM focus before/after (CDP probe), URL, live-region texts, and the speech strings until the next key.',
   'waits': 'After a key, wait for speech idle (no new speech-dispatcher message for 1.0 s, max 10 s). After typing, wait about 3 s for polite live regions. After a navigation, wait for the DOM readiness probe and then speech idle.',
   'read_until': 'action "read" means: press the key repeatedly, up to max, until the Orca speech since the step began contains the until-text after whitespace normalisation and ignoring punctuation that Orca may verbalise (· – →). Stop at max and mark the expectation unmet.',
   'key_repeat': 'action "key_repeat" means: press the key until the DOM focus predicate holds (checked by a CDP probe after each key), up to max. dry_run_count is the count measured in the DOM dry run.'},
 'node_choice': {'node': NODE, 'typed_neighbor': NB, 'edge': f'{NB} → {NODE} · reads_with_congruence_erratum · required: true (the only edge touching the node)',
                 'why': 'The contract\'s dated example node. This bundle shows counts 3/3, source/review recorded and kernel/computation/alignment not_recorded, and it has both a preserved and a static record plus a neighbor present in both.'},
 'records': {
   'preserved_mathematical_record': f'{P}snapshots/{ARCH}/nodes/{NODE}.html — title "… · Historical mathematical dependency atlas", "Original source observation: 2026-10-24T00:43:16Z", original pins main 0899cf51675e2e0d053c2d82a7e954f814ca40ee / Math- 7d815a5dcfb875b551c21804165e6588cc73d3ab, "Immutable historical mathematical record · mathematical SHA-256 {ARCH}". Reached from the atlas inspector link "Read the preserved mathematical record".',
   'static_node_record': f'{P}nodes/{NODE}.html — title "… · Current research dependency atlas", "Pinned source observation: 2026-10-25T14:27:24Z", pins main f61419d8de39b45b20832a760b90fffa82429ab9 / Math- c4eabc1a917ba2c1b96fe4af425cf2a484877c03, plus a Resume block "As of 2026-10-25T14:27:24Z". Reached from the inspector link "Read the static node record".',
   'not_to_confuse': 'dependencies.html also contains the "Preserved 3 October dependency snapshot" (Claim dependency viewer, Math 7858329), a different and older viewer. It is not the preserved mathematical record of Task 5.'},
 'contract_hints_vs_bundle': {
   'congruence-erratum counts 3/3': 'matched: "Downstream nodes · all edges: 3. Downstream nodes · required edges: 3."',
   'source/review recorded; kernel/computation/alignment not_recorded': 'matched in the atlas inspector, the static record and the preserved record',
   'periodized equation search 32 of 108': 'matched: "32 matching excerpts of 108 acquired excerpts."',
   'lines 27–28 link to immutable Main f614': 'matched (DOM href): https://github.com/d6g8k5htny-coder/main/blob/f61419d8de39b45b20832a760b90fffa82429ab9/experiments/universality/periodized_gaussian_h0/PROOF.md#L27-L28'},
 'dry_run': {
   'evidence_class': R['evidence_class'], 'replay_class': R['replay_class'], 'versions': R['versions'],
   'result_file': os.path.abspath(res_path), 'summary': R['summary'], 'refusals': R['refusals'],
   'runs': {'run1': 'all 8 tasks OK except the optional alt+Left (a CDP key cannot reach the browser UI); the server PID was the subshell (node orphaned, then stopped by PID)',
            'run2/run3': 'supplementary Back/Forward step wrong in my script: after atlas Back the page moves focus to section#current-atlas, so Tab then hit an inspector link and navigated (debug trace in debug-backforward/)',
            'run4': 'probe crashed on the canary error page (fixed with a retry)', 'run5': 'all OK', 'run6': 'final: all 66 steps OK, plus pressed-state and first-link-after-heading checks'},
   'network': 'run6: 217 server requests, all from 127.0.0.1, 216 x 200 with served sha256 equal to the bundle file bytes, 1 x 404 /favicon.ico ("not in bundle", browser-initiated on the static, preserved and JSON pages). Zero non-local requests from the site. One deliberate harness self-test navigation to http://refusal-canary.invalid/ was failed by Fetch.failRequest(BlockedByClient) and logged.',
   'not_validated': 'Orca browse-mode keys (h, shift+h, k, b, Up/Down line reading, ctrl+Home, Insert+a, KP_Enter), Say All behaviour, live-region speech and X key delivery. Only DOM reading order and DOM targets were checked for those steps.'},
 'tasks': TASKS,
 'problems_and_limits': [
   'DOM dry run only: no Orca, Xvfb, AT-SPI or speech ran. No screen-reader result is implied; SITE spoken AT remains NOT_OBSERVED until the executor run.',
   'Browse-mode line counts depend on Orca line segmentation and the 1200 px layout; the plan therefore uses read-until loops with max bounds rather than fixed Down counts.',
   'Tab counts depend on the default graph neighborhood (math.uniform-matrix-cap-lifetime) and the viewport; re-measure with the DOM focus predicate rather than trusting the counts blindly.',
   'Retained snapshot ids are not listed in readable HTML; speech can confirm the count (11 of 512) and the current archive id on preserved pages, while the id list is DOM/JSON evidence.',
   'Interpretation: "Operating Diagnostics" = the Diagnostics tab plus its disclosure; "Operating History" = the "History and activity" disclosure (atlas Back/Forward is recorded as supplementary).',
   'External anchors (github.com pins, sources, the equation source link) are read, never activated. Activation is NOT_OBSERVED by rule.',
   '/favicon.ico is absent from the bundle (local 404) and must be preserved as absent, not synthesized.'],
}

os.makedirs(out_dir, exist_ok=True)
jp = os.path.join(out_dir, 'plan.json')
with open(jp, 'w') as f: json.dump(plan, f, indent=2, ensure_ascii=False)

# ---------- plan.md ----------
L = []
w = L.append
w('# SITE screen-reader replay: eight-task key plan\n')
w(f"Generated {plan['generated_at']} by Claude 54 (session_013tN78b3Q38WdttFyiJ6KVg) for pickup {plan['lane']['pickup']}.\n")
w(f"**Replay class:** {plan['replay_class']}\n")
w('**Status of this document.** This is a plan plus a DOM-only dry run. No screen reader ran, and nothing here is Orca speech evidence. SITE spoken AT remains NOT_OBSERVED.\n')
w('## Evidence classes (keep them separate)\n')
for k, v in plan['evidence_classes'].items(): w(f'- **{k}**: {v}')
w('\n## Serving and environment\n')
w(f"- Bundle: `{plan['bundle']['path']}` ({plan['bundle']['files']} files, {plan['bundle']['bytes']} B, fingerprint `{plan['bundle']['fingerprint']}`)")
w(f"- Serve: `{plan['serve_command']}`")
w(f"  - {plan['serve_note']}")
w(f"- URL prefix: `{P}`")
for k, v in plan['environment'].items(): w(f'- {k}: {v}')
w(f"- Keys: {plan['key_injection']['method']}")
w('- Keysyms: ' + ', '.join(f'{k} {v}' for k, v in plan['key_injection']['keysyms'].items()))
w(f"- {plan['key_injection']['never']}")
w('\n## Step protocol\n')
for k, v in plan['step_protocol'].items(): w(f'- **{k}**: {v}')
w('\n## Node and records\n')
nc = plan['node_choice']
w(f"- Node: `{nc['node']}`. Typed neighbor: `{nc['typed_neighbor']}` ({nc['edge']}). {nc['why']}")
for k, v in plan['records'].items(): w(f'- **{k}**: {v}')
w('\n## Contract hints compared with this bundle\n')
for k, v in plan['contract_hints_vs_bundle'].items(): w(f'- {k}: {v}')
for t in TASKS:
    w(f"\n## Task {t['id']}: {t['title']}\n")
    w(f"- Start URL: `{t['start_url']}`")
    w(f"- Say All on load: {t['say_all_on_load']}")
    if t.get('chain_alternative'): w(f"- Chaining: {t['chain_alternative']}")
    w(f"- Dry run: {t['dry_run_summary']}\n")
    w('| # | action | keys / text | repeat (max; dry-run count) | Orca mode | expected focus | expected speech / DOM | dry run |')
    w('|---|---|---|---|---|---|---|---|')
    for s in t['steps']:
        rep = s.get('repeat') or {}
        reps = ''
        if rep: reps = f"until {rep.get('until')}; max {rep.get('max')}" + (f"; dry {rep['dry_run_count']}" if 'dry_run_count' in rep else '')
        kt = s.get('keys') or ''
        if s.get('text'): kt = (kt + ' ' if kt else '') + f"`{s['text']}`"
        foc = '; '.join(f'{k}: {v}' for k, v in (s.get('expected_focus') or {}).items())
        exp = ' / '.join(f'"{x}"' for x in (s.get('expected_text') or []))
        if s.get('dom_check'): exp += (' — ' if exp else '') + 'DOM: ' + s['dom_check']
        if s.get('notes'): exp += ' — Note: ' + s['notes']
        d = s.get('dry_run')
        ds = (('OK' if d['ok'] else 'BAD') + ' ' + d['ref'].split()[1]) if d else 'not DOM-checkable'
        opt = ' (optional)' if s.get('optional') else ''
        cell = lambda x: str(x).replace('|', '\\|').replace('\n', ' ')
        w(f"| {s['n']} | {s['action']}{opt} | {cell(kt)} | {cell(reps)} | {cell(s.get('orca_mode',''))} | {cell(foc)} | {cell(exp)} | {ds} |")
    w('\n**Pass criteria**\n')
    for k, v in t['pass_criteria'].items(): w(f'- **{k}**: {v}')
    if t.get('notes'):
        w('\n**Notes**\n')
        for n in t['notes']: w(f'- {n}')
w('\n## Dry run\n')
d = plan['dry_run']
w(f"- Class: {d['evidence_class']}")
w(f"- Versions: Chromium {d['versions']['chromium']}, Playwright {d['versions']['playwright']}, Node {d['versions']['node']}, viewport {d['versions']['viewport']['width']}x{d['versions']['viewport']['height']}")
w(f"- Result file: `{d['result_file']}`")
w('- Per-section summary: ' + '; '.join(f"T{x['id']} {x['ok']}/{x['steps']}" for x in d['summary']) + ' (T9 = harness self-test)')
w(f"- Network: {d['network']}")
w(f"- Not validated: {d['not_validated']}")
w('- Runs: ' + '; '.join(f'{k}: {v}' for k, v in d['runs'].items()))
w('\n## Problems and limits\n')
for p in plan['problems_and_limits']: w(f'- {p}')
mp = os.path.join(out_dir, 'plan.md')
open(mp, 'w').write('\n'.join(L) + '\n')
for p in (jp, mp):
    b = open(p, 'rb').read(); print(p, len(b), hashlib.sha256(b).hexdigest())
