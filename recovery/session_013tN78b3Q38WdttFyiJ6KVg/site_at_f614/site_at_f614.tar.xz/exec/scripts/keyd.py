#!/usr/bin/python3.12 -I
# SITE replay key daemon: real X key events through AT-SPI (registryd -> XTest), so Orca sees them.
# Extended from c220/scripts/xtest_key.py. Runs as a persistent child of driver.mjs.
# stdin: one JSON per line: {"id": n, "mods": ["Shift_L"], "key": "Tab"}  or  {"id": n, "text": "abc"}
# stdout: one JSON per line: {"id", "t0", "t1", "ok", "events": [[kind, value, synth, ok, t], ...]}
# Modifiers are pressed/released by keycode (KeySynthType.PRESS/RELEASE); keys use KeySynthType.SYM (keysym).
import json, os, sys, time
import gi
gi.require_version('Atspi', '2.0')
gi.require_version('Gdk', '3.0')
from gi.repository import Atspi, Gdk

disp = Gdk.Display.open(os.environ['DISPLAY'])
keymap = Gdk.Keymap.get_for_display(disp)

def keycode(name):
    kv = Gdk.keyval_from_name(name)
    ok, keys = keymap.get_entries_for_keyval(kv)
    if not ok or not keys:
        raise ValueError(f'no keycode for {name}')
    return min(k.keycode for k in keys if k.level == 0) if any(k.level == 0 for k in keys) else keys[0].keycode

MODS = {m: keycode(m) for m in ('Shift_L', 'Control_L', 'Alt_L', 'Insert')}
print(json.dumps({'ready': True, 'modifier_keycodes': MODS, 'display': os.environ['DISPLAY'],
                  'atspi_version': Atspi._version if hasattr(Atspi, '_version') else '2.0'}), flush=True)

def sym(name):
    if len(name) == 1:
        return Gdk.unicode_to_keyval(ord(name))
    kv = Gdk.keyval_from_name(name)
    if kv in (0, 0xffffff):
        raise ValueError(f'unknown keysym {name}')
    return kv

for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    cmd = json.loads(line)
    ev = []
    t0 = time.time()
    ok_all = True
    try:
        if 'text' in cmd:
            for ch in cmd['text']:
                k = sym(ch)
                ok = Atspi.generate_keyboard_event(k, None, Atspi.KeySynthType.SYM)
                ev.append(['sym', ch, hex(k), bool(ok), time.time()]); ok_all &= bool(ok)
                time.sleep(cmd.get('char_delay', 0.18))
        else:
            mods = cmd.get('mods', [])
            for m in mods:
                ok = Atspi.generate_keyboard_event(MODS[m], None, Atspi.KeySynthType.PRESS)
                ev.append(['press', m, MODS[m], bool(ok), time.time()]); ok_all &= bool(ok)
                time.sleep(0.03)
            k = sym(cmd['key'])
            ok = Atspi.generate_keyboard_event(k, None, Atspi.KeySynthType.SYM)
            ev.append(['sym', cmd['key'], hex(k), bool(ok), time.time()]); ok_all &= bool(ok)
            for m in reversed(mods):
                time.sleep(0.03)
                ok = Atspi.generate_keyboard_event(MODS[m], None, Atspi.KeySynthType.RELEASE)
                ev.append(['release', m, MODS[m], bool(ok), time.time()]); ok_all &= bool(ok)
    except Exception as e:  # report, keep running
        ok_all = False
        ev.append(['error', repr(e), None, False, time.time()])
    print(json.dumps({'id': cmd.get('id'), 't0': t0, 't1': time.time(), 'ok': ok_all, 'events': ev}), flush=True)
