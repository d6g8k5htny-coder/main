#!/usr/bin/python3 -I
"""SITE replay extractor (adapted from c220/scripts/extract.py).

usage: extract.py EVIDENCE_TASK_DIR BUNDLE_DIR
Writes speech.json, speech.txt, requests.json into EVIDENCE_TASK_DIR. Reads only logs and (as data) bundle files.
Evidence classes:
  SPEECH  = strings Orca handed to speech-dispatcher: orca-debug.txt 'SPEECH DISPATCHER: Speaking '<speak>..'' lines;
            lines lost from Orca's buffered debug tail are recovered from the speech-dispatcher log
            'Queueing message' lines and marked log_source=speechd-only.
  KEYS    = real X key events sent (driver.json keyd records) and the key events Orca itself processed
            ('PROCESS ATSPI_KEY_PRESSED_EVENT' blocks in orca-debug.txt).
  DOM/AX  = driver.json probes (activeElement, AX node, live-region text) -- a separate class.
"""
import calendar, hashlib, html, json, os, re, sys, time

d, bundle = sys.argv[1], sys.argv[2]
run = open(os.path.join(d, 'run.txt')).read()
day = re.search(r'start (\d{4}-\d{2}-\d{2})T', run).group(1)
base = calendar.timegm(time.strptime(day, '%Y-%m-%d'))

def orca_t(hms):
    h, m, s = hms.split(':')
    return round((base + int(h) * 3600 + int(m) * 60 + float(s)) * 1000, 3)

def norm(x):
    return re.sub(r'\s+', ' ', x.replace('\u2026', '...')).strip()

def plain(ssml):
    s = re.sub(r'<mark name="[^"]*"/>', '', ssml)
    s = s.replace('<speak>', '').replace('</speak>', '')
    return html.unescape(s)

def fmt(ms):
    if ms is None:
        return '-'
    return time.strftime('%H:%M:%S', time.gmtime(ms / 1000)) + f".{int(ms % 1000):03d}"

# ---------- Orca debug log ----------
ts_re = re.compile(r'^(\d\d:\d\d:\d\d\.\d+) - (.*)$')
sent, orca_keys, sayall = [], [], []
pending_key = None
with open(os.path.join(d, 'orca-debug.txt'), encoding='utf-8', errors='replace') as f:
    lines = f.read().split('\n')
i = 0
while i < len(lines):
    line = lines[i]
    mk = re.match(r"^vvvvv PROCESS ATSPI_KEY_(PRESSED|RELEASED)_EVENT: '(.*)' \((\d+)\) vvvvv$", line)
    if mk:
        pending_key = {'type': mk.group(1).lower(), 'key': mk.group(2), 'keycode': int(mk.group(3))}
        i += 1; continue
    m = ts_re.match(line)
    if m:
        t, body = orca_t(m.group(1)), m.group(2)
        if pending_key:
            pending_key['t'] = t; orca_keys.append(pending_key); pending_key = None
        if body.startswith("SPEECH DISPATCHER: Speaking '<speak>"):
            ssml = body[len("SPEECH DISPATCHER: Speaking '"):]
            j = i
            while '</speak>' not in ssml and j + 1 < len(lines) and not ts_re.match(lines[j + 1]):
                j += 1; ssml += '\n' + lines[j]
            i = j
            ssml = ssml.rstrip()
            if ssml.endswith("'"):
                ssml = ssml[:-1]
            sent.append({'t': t, 'text': plain(ssml), 'log_source': 'orca-debug'})
        elif re.match(r"SPEECH DISPATCHER: Speaking '.*' as (key|char|character)$", body):
            mm = re.match(r"SPEECH DISPATCHER: Speaking '(.*)' as (key|char|character)$", body)
            sent.append({'t': t, 'text': mm.group(1), 'log_source': 'orca-debug', 'orca_kind': 'as ' + mm.group(2)})
        elif body.startswith('WEB SAY ALL'):
            sayall.append(t)
    i += 1
orca_debug_last_t = max([s['t'] for s in sent] + [k['t'] for k in orca_keys] + [0])

# ---------- speech-dispatcher log ----------
sd_re = re.compile(r'^\[\w{3} (\w{3} +\d+ \d\d:\d\d:\d\d \d{4}) : (\d+)\] speechd: +(.*)$')
sd_events = []
with open(os.path.join(d, 'sdlog', 'speech-dispatcher.log'), encoding='utf-8', errors='replace') as f:
    raw = f.read().split('\n')
merged = []
for line in raw:  # join multi-line 'Queueing message |...| with priority N' records
    if merged and not sd_re.match(line) and 'Queueing message |' in merged[-1] and not re.search(r'\| with priority \d+$', merged[-1]):
        merged[-1] += '\n' + line
    else:
        merged.append(line)
if True:
    for line in merged:
        m = re.match(r'^\[\w{3} (\w{3} +\d+ \d\d:\d\d:\d\d \d{4}) : (\d+)\] speechd: +(.*)$', line, re.S)
        if not m:
            continue
        t = round((calendar.timegm(time.strptime(m.group(1), '%b %d %H:%M:%S %Y')) + int(m.group(2)) / 1e6) * 1000, 3)
        body = m.group(3)
        if body.startswith('Queueing message |'):
            mm = re.match(r'Queueing message \|(.*)\| with priority (\d+)', body, re.S)
            if mm:
                sd_events.append(('queue', t, plain(mm.group(1)), int(mm.group(2))))
        elif body == 'Module speak!':
            sd_events.append(('speak', t, None, None))
        elif body.startswith('speak_queue playback thread reporting end'):
            sd_events.append(('end', t, None, None))
        elif body.endswith('DATA:|CANCEL self') or body.endswith('DATA:|STOP self'):
            sd_events.append(('cancel', t, body.split('|')[-1], None))
# FIFO playback model
queue, playing, queued = [], None, []
for kind, t, text, prio in sd_events:
    if kind == 'queue':
        q = {'t': t, 'text': text, 'priority': prio, 'status': 'queued'}
        queued.append(q); queue.append(q)
    elif kind == 'speak':
        if queue:
            playing = queue.pop(0); playing['play_start'] = t; playing['status'] = 'playing'
    elif kind == 'end':
        if playing:
            playing['play_end'] = t
            if playing['status'] == 'playing':
                playing['status'] = 'played'
            playing = None
    elif kind == 'cancel':
        if playing:
            playing['cancel_t'] = t; playing['status'] = 'cancelled during playback'
        for q in queue:
            q['status'] = 'flushed before playback'; q['cancel_t'] = t
        queue = []

# join Orca-sent with speechd queue; recover lost tail
used = set()
for u in sent:
    for j, q in enumerate(queued):
        if j in used or norm(q['text']) != norm(u['text']) or abs(q['t'] - u['t']) > 3000:
            continue
        used.add(j); u['speechd'] = q; break
for j, q in enumerate(queued):
    if j not in used:
        sent.append({'t': q['t'], 'text': q['text'], 'log_source': 'speechd-only (Orca debug tail lost)'
                     if q['t'] > orca_debug_last_t - 1000 else 'speechd-only', 'speechd': q})
sent.sort(key=lambda u: u['t'])

# ---------- driver steps ----------
drv = json.load(open(os.path.join(d, 'driver.json')))
steps = drv['steps']
wins = []
for k, s in enumerate(steps):
    start = s.get('t_action') or 0
    wins.append([start, None, s])
for k in range(len(wins)):
    wins[k][1] = wins[k + 1][0] if k + 1 < len(wins) else float('inf')
if wins:
    wins[0][0] = 0
def step_of(t):
    for a, b, s in wins:
        if a <= t < b:
            return s['n']
    return None
for u in sent:
    u['step'] = step_of(u['t']); u['iso'] = fmt(u['t'])
for k in orca_keys:
    k['step'] = step_of(k['t']); k['iso'] = fmt(k['t'])

def short(a):
    if not a:
        return 'null'
    r = a['tag'] + ('#' + a['id'] if a.get('id') else '') + (f"[role={a['role']}]" if a.get('role') else '')
    for kk in ('aria-pressed', 'aria-selected', 'aria-expanded', 'details_open', 'value'):
        if kk in a:
            r += f' {kk}={a[kk]!r}'
    return r + f' "{(a.get("text") or a.get("aria-label") or "")[:90]}"'

out_lines = [f"SPEECH EXTRACT for {os.path.basename(d)}  (classes: SENT = Orca->speech-dispatcher string; ORCA-KEY = key event Orca processed; X-KEY = real X event sent; DOM/AX = CDP probe)"]
for a, b, s in wins:
    key = s.get('key')
    out_lines.append('')
    out_lines.append(f"== #{s['n']} [{s['kind']}] {s['label']}  key={json.dumps(key)}  t={s.get('iso_action')}")
    if s.get('keyd'):
        kd = s['keyd']
        out_lines.append(f"   X-KEY ok={kd['ok']} {fmt(kd['t0'])}-{fmt(kd['t1'])} " + ' '.join(f"{e[0]}:{e[1]}" for e in kd['events']))
    for k in orca_keys:
        if k['step'] == s['n'] and k['type'] == 'pressed':
            out_lines.append(f"   ORCA-KEY {k['iso']} pressed '{k['key']}' ({k['keycode']})")
    for u in sent:
        if u['step'] == s['n']:
            q = u.get('speechd') or {}
            pl = q.get('status', 'no speechd match')
            if q.get('play_start'):
                pl += f" {fmt(q.get('play_start'))}-{fmt(q.get('play_end') or q.get('cancel_t'))}"
            src = '' if u['log_source'] == 'orca-debug' else f" [{u['log_source']}]"
            out_lines.append(f"   SENT {u['iso']}{src} {u['text']!r}  -> {pl}")
    if s.get('before'):
        out_lines.append(f"   DOM focus before: {short(s['before'].get('active'))}")
    af = s.get('after') or {}
    out_lines.append(f"   DOM focus after:  {short(af.get('active'))}  url={af.get('url')}")
    if af.get('ax'):
        ax = af['ax']
        out_lines.append(f"   AX after: {ax.get('role')} {ax.get('name')!r} value={ax.get('value')!r} {ax.get('props')}")
    for c in s.get('checks', []):
        out_lines.append(f"   DOM CHECK {c['label']}: {c['ok']}")
    for kk in ('repeat_result', 'read_result', 'manifest_dom', 'canary'):
        if s.get(kk) is not None:
            out_lines.append(f"   {kk}: {json.dumps(s[kk])[:400]}")
open(os.path.join(d, 'speech.txt'), 'w').write('\n'.join(out_lines) + '\n')

# ---------- requests ----------
srv = [json.loads(l) for l in open(os.path.join(d, 'server-requests.jsonl')) if l.strip()]
mism = []
for r in srv:
    if r['status'] == 200 and r.get('file'):
        h = hashlib.sha256(open(os.path.join(bundle, r['file']), 'rb').read()).hexdigest()
        if h != r['sha256']:
            mism.append(r['url'])
statuses = {}
for r in srv:
    statuses[r['status']] = statuses.get(r['status'], 0) + 1
cdp_req = [e for e in drv['cdp_events'] if e['kind'] == 'net.request']
nonlocal_req = [e['url'] for e in cdp_req if not e['url'].startswith('http://127.0.0.1:8770/')]
reqs = {'server_requests': len(srv), 'server_status_counts': statuses, 'server_remotes': sorted({r['remote'] for r in srv}),
        'served_sha256_equal_bundle_file': len(mism) == 0, 'sha_mismatches': mism,
        'non_200': [(r['status'], r['url'], r.get('note')) for r in srv if r['status'] != 200],
        'cdp_requests': len(cdp_req), 'cdp_nonlocal_request_urls': nonlocal_req,
        'refusals': drv['refusals'],
        'cdp_targets': [e for e in drv['cdp_events'] if e['kind'].startswith('target.')]}
json.dump(reqs, open(os.path.join(d, 'requests.json'), 'w'), indent=1)

kd_sent = sum(1 for s in steps if s.get('keyd'))
summary = {'orca_sent_total': len(sent), 'orca_debug_lines': sum(1 for u in sent if u['log_source'] == 'orca-debug'),
           'speechd_only': sum(1 for u in sent if u['log_source'] != 'orca-debug'), 'speechd_queued': len(queued),
           'x_key_commands': kd_sent, 'orca_key_presses_seen': sum(1 for k in orca_keys if k['type'] == 'pressed'),
           'orca_debug_last_t': fmt(orca_debug_last_t), 'say_all_lines': len(sayall)}
json.dump({'summary': summary, 'orca_sent': sent, 'orca_keys': orca_keys, 'speechd_queued': queued}, open(os.path.join(d, 'speech.json'), 'w'), indent=1, default=str)
print(json.dumps(summary)); print(json.dumps({k: reqs[k] for k in ('server_requests', 'server_status_counts', 'server_remotes', 'served_sha256_equal_bundle_file', 'non_200', 'cdp_nonlocal_request_urls')}))
print('refusals', [(r['url'], r['action']) for r in drv['refusals']])
