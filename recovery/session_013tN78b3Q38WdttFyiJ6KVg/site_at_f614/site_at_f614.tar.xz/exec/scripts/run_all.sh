#!/bin/bash
# Runs the SITE tasks one stack at a time (stack.sh tears each stack down before the next starts).
X=/tmp/claude-0/-home-user-main/d5c985ca-97e5-58d8-a9d4-1e0a19065a22/scratchpad/siteat/exec
for id in ${ONLY:-T1 T2 T3 T4 T5 T6 T7 T8}; do
  echo "=== $id $(date -u +%H:%M:%S)"
  timeout 900 $X/scripts/stack.sh "$id"
done
echo "ALL DONE $(date -u +%H:%M:%S)"
