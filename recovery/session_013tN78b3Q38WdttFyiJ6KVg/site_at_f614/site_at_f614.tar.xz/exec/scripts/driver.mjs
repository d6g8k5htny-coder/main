// SITE generated-bundle replay driver (Orca run). Connects to an already running Chromium (stack.sh).
// - CDP is used ONLY to observe (DOM/AX probes, live-region text, network) and to BLOCK+LOG every
//   non-local request (Fetch.failRequest BlockedByClient) on every attached target. Harness navigation
//   (Page.navigate to a task start URL) is labelled as such.
// - Every key a user presses is a real X key event via AT-SPI generate_keyboard_event (keyd.py).
// - Live speech progress is read from the speech-dispatcher log (Queueing message lines) only to pace
//   the run (read-until loops). The evidence extraction (extract.py) uses the original Orca debug log.
// usage: node driver.mjs TASK_ID OUT_DIR CDP_PORT
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import readline from 'node:readline';

const [TASK, OUT, PORTARG] = process.argv.slice(2);
const PORT = Number(PORTARG || 9333);
const ORIGIN = 'http://127.0.0.1:8770';
const BASE = ORIGIN + '/site/';
const SCRIPTS = path.dirname(new URL(import.meta.url).pathname);
const SDLOG = path.join(OUT, 'sdlog', 'speech-dispatcher.log');
const AUDIO = path.join(OUT, 'audio.raw');
const sleep = ms => new Promise(r => setTimeout(r, ms));
const iso = ms => new Date(ms).toISOString();
const events = [];      // cdp events (network, console, targets, load)
const refusals = [];    // blocked non-local requests
const steps = [];       // action/focus boundaries
const liveChanges = []; // DOM live-region text changes (polled)
const ev = (kind, data) => { const t = Date.now(); events.push({ t, iso: iso(t), kind, ...data }); };
const out = (name, obj) => fs.writeFileSync(path.join(OUT, name), JSON.stringify(obj, null, 1));
function dump() {
  out('driver.json', { task: TASK, steps, live_changes: liveChanges, refusals, cdp_events: events, keyd_ready: keydReady });
  fs.writeFileSync(path.join(OUT, 'refusals.jsonl'), refusals.map(r => JSON.stringify(r)).join('\n') + (refusals.length ? '\n' : ''));
}

// ---------------- CDP (browser endpoint, flattened sessions) ----------------
let wsUrl;
for (let i = 0; i < 80 && !wsUrl; i++) {
  try { wsUrl = (await (await fetch(`http://127.0.0.1:${PORT}/json/version`)).json()).webSocketDebuggerUrl; } catch { await sleep(250); }
}
if (!wsUrl) throw new Error('no DevTools endpoint');
const ws = new WebSocket(wsUrl);
let nextId = 0; const pending = new Map();
const sessions = new Map(); // sessionId -> targetInfo
let MAIN = null; let mainTargetId = null;
let loadCount = 0; let navCount = 0;
function send(method, params = {}, sessionId) {
  const id = ++nextId;
  const msg = { id, method, params }; if (sessionId) msg.sessionId = sessionId;
  ws.send(JSON.stringify(msg));
  return new Promise((resolve, reject) => pending.set(id, { resolve, reject, method }));
}
async function onAttached(p) {
  const { sessionId, targetInfo, waitingForDebugger } = p;
  sessions.set(sessionId, targetInfo);
  ev('target.attached', { sessionId, type: targetInfo.type, url: targetInfo.url, targetId: targetInfo.targetId, waitingForDebugger });
  const t = targetInfo.type;
  try {
    if (['page', 'iframe', 'worker', 'service_worker', 'shared_worker'].includes(t)) {
      await send('Fetch.enable', { patterns: [{ urlPattern: '*', requestStage: 'Request' }] }, sessionId);
      await send('Network.enable', {}, sessionId);
    }
    if (['page', 'iframe'].includes(t)) {
      await send('Target.setAutoAttach', { autoAttach: true, waitForDebuggerOnStart: true, flatten: true }, sessionId);
    }
    if (t === 'page' && !MAIN && targetInfo.url.startsWith('data:text/html')) {
      MAIN = sessionId; mainTargetId = targetInfo.targetId;
      await send('Page.enable', {}, sessionId);
      await send('Runtime.enable', {}, sessionId);
      await send('Log.enable', {}, sessionId);
    }
  } catch (e) { ev('error', { where: 'onAttached', msg: String(e) }); }
  if (waitingForDebugger) send('Runtime.runIfWaitingForDebugger', {}, sessionId).catch(() => {});
}
ws.onmessage = m => {
  const d = JSON.parse(m.data);
  if (d.id && pending.has(d.id)) {
    const p = pending.get(d.id); pending.delete(d.id);
    d.error ? p.reject(new Error(`${p.method}: ${d.error.message}`)) : p.resolve(d.result);
    return;
  }
  if (!d.method) return;
  const p = d.params || {}; const sid = d.sessionId || null;
  switch (d.method) {
    case 'Target.attachedToTarget': onAttached(p); break;
    case 'Target.detachedFromTarget': ev('target.detached', { sessionId: p.sessionId }); sessions.delete(p.sessionId); break;
    case 'Target.targetCreated': ev('target.created', { type: p.targetInfo.type, url: p.targetInfo.url, targetId: p.targetInfo.targetId }); break;
    case 'Fetch.requestPaused': {
      const u = p.request.url;
      if (u.startsWith(ORIGIN + '/')) {
        ev('fetch.continue', { url: u, resourceType: p.resourceType, sessionId: sid });
        send('Fetch.continueRequest', { requestId: p.requestId }, sid).catch(e => ev('error', { msg: String(e) }));
      } else {
        const r = { t: Date.now(), iso: iso(Date.now()), url: u, method: p.request.method, resourceType: p.resourceType,
                    target_type: sessions.get(sid)?.type ?? null, action: 'Fetch.failRequest(BlockedByClient)', step: steps.length };
        refusals.push(r); ev('fetch.REFUSED', r);
        send('Fetch.failRequest', { requestId: p.requestId, errorReason: 'BlockedByClient' }, sid).catch(e => ev('error', { msg: String(e) }));
      }
      break;
    }
    case 'Network.requestWillBeSent': if (!/^data:/.test(p.request.url)) ev('net.request', { sessionId: sid, requestId: p.requestId, url: p.request.url, type: p.type }); break;
    case 'Network.responseReceived': if (!/^data:/.test(p.response.url)) ev('net.response', { sessionId: sid, url: p.response.url, status: p.response.status, remote: p.response.remoteIPAddress ?? null }); break;
    case 'Network.loadingFailed': ev('net.failed', { sessionId: sid, requestId: p.requestId, errorText: p.errorText, blockedReason: p.blockedReason }); break;
    case 'Runtime.consoleAPICalled': if (sid === MAIN) ev('console', { type: p.type, args: p.args.map(a => a.value ?? a.description) }); break;
    case 'Runtime.exceptionThrown': if (sid === MAIN) ev('exception', { text: p.exceptionDetails.text, desc: p.exceptionDetails.exception?.description }); break;
    case 'Log.entryAdded': if (sid === MAIN) ev('log', { level: p.entry.level, text: p.entry.text, url: p.entry.url }); break;
    case 'Page.loadEventFired': if (sid === MAIN) { loadCount++; ev('page.load', {}); } break;
    case 'Page.frameNavigated': if (sid === MAIN && !p.frame.parentId) { navCount++; ev('page.frameNavigated', { url: p.frame.url }); } break;
    case 'Page.navigatedWithinDocument': if (sid === MAIN) ev('page.navigatedWithinDocument', { url: p.url }); break;
  }
};
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
await send('Target.setDiscoverTargets', { discover: true });
await send('Target.setAutoAttach', { autoAttach: true, waitForDebuggerOnStart: true, flatten: true });
for (let i = 0; i < 40 && !MAIN; i++) {
  if (i === 10) {
    const { targetInfos } = await send('Target.getTargets');
    for (const ti of targetInfos) if (ti.type === 'page' && ![...sessions.values()].some(s => s.targetId === ti.targetId)) {
      await send('Target.attachToTarget', { targetId: ti.targetId, flatten: true });
    }
  }
  await sleep(100);
}
if (!MAIN) throw new Error('main page session not attached');
ev('cdp.ready', { main: MAIN });

async function evaluate(expr) {
  const r = await send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true }, MAIN);
  if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text);
  return r.result.value;
}

// ---------------- live speech tail (pacing only) ----------------
const queued = []; let lastQueueT = 0; let sdPos = 0; let sdRest = '';
let audioSize = 0; let lastAudioChange = 0;
const unesc = s => s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'")
  .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(+n)).replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16))).replace(/&amp;/g, '&');
const plain = ssml => unesc(ssml.replace(/<mark name="[^"]*"\/>/g, '').replace(/<\/?speak>/g, ''));
function pollSpeech() {
  try {
    const st = fs.statSync(SDLOG);
    if (st.size > sdPos) {
      const fd = fs.openSync(SDLOG, 'r'); const buf = Buffer.alloc(st.size - sdPos);
      fs.readSync(fd, buf, 0, buf.length, sdPos); fs.closeSync(fd); sdPos = st.size;
      const lines = (sdRest + buf.toString('utf8')).split('\n'); sdRest = lines.pop();
      for (const ln of lines) {
        const m = ln.match(/speechd: +Queueing message \|(.*)\| with priority (\d+)/);
        if (m) { const t = Date.now(); queued.push({ t, text: plain(m[1]), priority: +m[2] }); lastQueueT = t; }
      }
    }
  } catch {}
  try { const s = fs.statSync(AUDIO).size; if (s !== audioSize) { audioSize = s; lastAudioChange = Date.now(); } } catch {}
}
setInterval(pollSpeech, 80);
const normT = s => s.toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g, '');
const speechSince = i => queued.slice(i).map(q => q.text);

// settle: wait until Orca stopped queueing and (optionally) playback went idle
async function settle({ minMs = 500, firstMs = 1500, qIdle = 700, aIdle = 600, maxMs = 12000, audio = true, q0 = queued.length } = {}) {
  const start = Date.now();
  for (;;) {
    await sleep(80); pollSpeech();
    const now = Date.now(), el = now - start;
    const got = queued.length > q0 || el >= firstMs;
    const qOk = now - lastQueueT >= qIdle, aOk = now - lastAudioChange >= aIdle;
    if (el >= minMs && got && qOk && (!audio || aOk)) return { waited_ms: el, timeout: false };
    if (el >= maxMs) return { waited_ms: el, timeout: true };
  }
}

// ---------------- keys (real X events via AT-SPI) ----------------
const keyd = spawn('/usr/bin/python3.12', ['-I', path.join(SCRIPTS, 'keyd.py')], { env: process.env, stdio: ['pipe', 'pipe', 'pipe'] });
keyd.stderr.on('data', d => ev('keyd.stderr', { text: String(d) }));
const keyPending = new Map(); let keydReady = null; let keyId = 0;
let keydReadyResolve; const keydReadyP = new Promise(r => { keydReadyResolve = r; });
readline.createInterface({ input: keyd.stdout }).on('line', line => {
  const o = JSON.parse(line);
  if (o.ready) { keydReady = o; keydReadyResolve(); return; }
  const p = keyPending.get(o.id); if (p) { keyPending.delete(o.id); p(o); }
});
await Promise.race([keydReadyP, sleep(15000)]);
if (!keydReady) throw new Error('keyd not ready');
const MODMAP = { shift: 'Shift_L', ctrl: 'Control_L', alt: 'Alt_L', insert: 'Insert' };
function xkey(spec) {
  const id = ++keyId;
  let cmd;
  if (typeof spec === 'object') cmd = { id, text: spec.text };
  else { const parts = spec.split('+'); const key = parts.pop(); cmd = { id, mods: parts.map(m => MODMAP[m.toLowerCase()]), key }; }
  return new Promise(res => { keyPending.set(id, res); keyd.stdin.write(JSON.stringify(cmd) + '\n'); });
}

// ---------------- DOM / AX probe (observation only) ----------------
const PROBE = `(() => {
  const d = el => { if (!el) return null; const o = { tag: el.tagName.toLowerCase() };
    if (el.id) o.id = el.id; if (el.className && typeof el.className === 'string') o.cls = el.className.slice(0, 80);
    for (const a of ['role','aria-label','aria-pressed','aria-selected','aria-expanded','aria-controls','href','type']) { const v = el.getAttribute && el.getAttribute(a); if (v !== null && v !== undefined) o[a] = v; }
    if ('value' in el && (el.tagName === 'INPUT' || el.tagName === 'SELECT')) o.value = el.value;
    if (el.tagName === 'SUMMARY') o.details_open = !!el.parentElement?.open;
    o.text = (el.innerText ?? el.textContent ?? '').replace(/\\s+/g, ' ').trim().slice(0, 200); return o; };
  const live = {};
  for (const el of document.querySelectorAll('[aria-live],[role=status],[role=alert],#atlas-status,#atlas-count,#equation-count')) {
    const k = el.id ? '#' + el.id : (el.className ? '.' + String(el.className).split(' ')[0] : el.tagName.toLowerCase());
    live[k] = (el.textContent || '').replace(/\\s+/g, ' ').trim().slice(0, 400);
  }
  return { url: location.href, title: document.title, readyState: document.readyState, hasFocus: document.hasFocus(), active: d(document.activeElement), live };
})()`;
async function axActive() {
  try {
    const r = await send('Runtime.evaluate', { expression: 'document.activeElement', returnByValue: false }, MAIN);
    if (!r.result.objectId) return null;
    const ax = await send('Accessibility.getPartialAXTree', { objectId: r.result.objectId, fetchRelatives: false }, MAIN);
    send('Runtime.releaseObject', { objectId: r.result.objectId }, MAIN).catch(() => {});
    const n = ax.nodes.find(x => !x.ignored) || ax.nodes[0];
    if (!n) return null;
    return { role: n.role?.value, name: n.name?.value, value: n.value?.value,
             props: (n.properties || []).map(p => [p.name, p.value?.value]).filter(([k]) => ['focused','pressed','selected','expanded','checked','disabled','hasPopup'].includes(k)) };
  } catch (e) { return { error: String(e) }; }
}
async function probe() {
  let p; try { p = await evaluate(PROBE); } catch (e) { p = { error: String(e) }; }
  p.ax = await axActive(); p.t = Date.now(); return p;
}
// background live-region poll (DOM evidence class)
let lastLive = {};
setInterval(async () => {
  if (!MAIN) return;
  try {
    const v = await evaluate(`(() => { const o = {}; for (const el of document.querySelectorAll('[aria-live],[role=status],[role=alert]')) { const k = el.id ? '#' + el.id : (el.className ? '.' + String(el.className).split(' ')[0] : el.tagName.toLowerCase()); o[k] = (el.textContent || '').replace(/\\s+/g, ' ').trim().slice(0, 400); } return { url: location.href, o }; })()`);
    for (const [k, txt] of Object.entries(v.o)) {
      const key = v.url.split('?')[0].split('#')[0] + ' ' + k;
      if (lastLive[key] !== txt) { liveChanges.push({ t: Date.now(), iso: iso(Date.now()), url: v.url, el: k, text: txt, prev: lastLive[key] ?? null, step: steps.length }); lastLive[key] = txt; }
    }
  } catch {}
}, 300);

// ---------------- step primitives ----------------
const descA = a => a ? `${a.tag}${a.id ? '#' + a.id : ''}${a.role ? '[' + a.role + ']' : ''} "${(a.text || a['aria-label'] || '').slice(0, 70)}"` : 'null';
let curTask = TASK;
async function record(kind, label, key, t0, kr, before, w, extra = {}) {
  const after = await probe();
  const q0 = extra.q0;
  const s = { n: steps.length, task: curTask, kind, label, key: key ?? null, t_action: t0, iso_action: iso(t0),
              keyd: kr ? { ok: kr.ok, t0: Math.round(kr.t0 * 1000), t1: Math.round(kr.t1 * 1000), events: kr.events } : null,
              before: before ? { url: before.url, active: before.active, ax: before.ax } : null,
              after: { url: after.url, title: after.title, active: after.active, ax: after.ax, live: after.live, hasFocus: after.hasFocus },
              wait: w, speech_live_pacing: q0 !== undefined ? speechSince(q0) : null, ...extra };
  delete s.q0;
  steps.push(s);
  console.log(`[${s.iso_action}] #${s.n} ${kind} ${label} key=${JSON.stringify(key)} -> ${descA(after.active)} | ${JSON.stringify((s.speech_live_pacing || []).join(' | ')).slice(0, 300)}`);
  dump();
  return s;
}
async function press(key, label, { kind = 'key', settleOpts = {}, extra = {} } = {}) {
  const before = await probe();
  const q0 = queued.length; const t0 = Date.now();
  const kr = await xkey(key);
  const w = await settle({ q0, ...settleOpts });
  return record(kind, label, key, t0, kr, before, w, { q0, ...extra });
}
async function isTrue(expr) { try { return !!(await evaluate(expr)); } catch { return false; } }
async function repeat(key, pred, max, label) {
  const q0r = queued.length; const tStart = Date.now();
  if (await isTrue(pred)) { ev('repeat.already', { label }); }
  for (let i = 1; i <= max; i++) {
    const s = await press(key, `${label} (press ${i})`, { kind: 'key_repeat', settleOpts: { maxMs: 3000, audio: false, qIdle: 500, firstMs: 1200 } });
    if (await isTrue(pred)) {
      const w = await settle({ minMs: 200, firstMs: 0, maxMs: 12000 });
      s.final_wait = w; s.speech_live_pacing_all = speechSince(q0r); s.repeat_result = { met: true, presses: i };
      console.log(`   repeat met after ${i}`); dump(); return { met: true, presses: i };
    }
  }
  ev('repeat.unmet', { label, max }); console.log(`   repeat UNMET ${label}`);
  steps[steps.length - 1].repeat_result = { met: false, presses: max }; dump();
  return { met: false, presses: max };
}
async function read(key, until, max, label) {
  const q0r = queued.length;
  for (let i = 1; i <= max; i++) {
    const s = await press(key, `${label || 'read'} (press ${i}) until "${until}"`, { kind: 'read', settleOpts: { maxMs: 15000 } });
    const acc = normT(speechSince(q0r).join(' '));
    if (acc.includes(normT(until))) { s.read_result = { met: true, presses: i, until }; console.log(`   read met after ${i}`); dump(); return { met: true, presses: i }; }
  }
  steps[steps.length - 1].read_result = { met: false, presses: max, until }; console.log(`   read UNMET "${until}"`); dump();
  return { met: false, presses: max };
}
async function typeText(text, label) {
  const before = await probe(); const q0 = queued.length; const t0 = Date.now();
  const kr = await xkey({ text });
  const w = await settle({ q0, minMs: 3500, qIdle: 1200, maxMs: 15000 });
  return record('type', label || `type "${text}"`, { text }, t0, kr, before, w, { q0 });
}
async function waitFor(expr, maxMs) { const st = Date.now(); while (Date.now() - st < maxMs) { if (await isTrue(expr)) return Date.now() - st; await sleep(150); } return -1; }
async function harnessNav(url, readyExpr) {
  const before = await probe(); const q0 = queued.length; const t0 = Date.now(); const lc = loadCount;
  ev('harness.navigate', { url });
  await send('Page.navigate', { url }, MAIN);
  const st = Date.now(); while (loadCount === lc && Date.now() - st < 30000) await sleep(100);
  const readyMs = await waitFor(readyExpr, 25000);
  const w = await settle({ q0, minMs: 3000, qIdle: 1500, aIdle: 1000, maxMs: 40000 });
  return record('harness_navigate', `HARNESS Page.navigate ${url} (not a user key)`, null, t0, null, before, w, { q0, ready_ms: readyMs, loaded: loadCount > lc });
}
// a user key that loads a new document; Say All may run on bare URLs: record what is spoken for sayAllMs
async function pressNav(key, label, { readyExpr = `document.readyState==='complete'`, sayAllMs = 9000, settleAll = false } = {}) {
  const before = await probe(); const q0 = queued.length; const t0 = Date.now(); const lc = loadCount;
  const kr = await xkey(key);
  const st = Date.now(); while (loadCount === lc && Date.now() - st < 20000) await sleep(100);
  const readyMs = await waitFor(readyExpr, 20000);
  let w;
  if (settleAll) w = await settle({ q0, minMs: 3000, qIdle: 1500, aIdle: 1000, maxMs: 45000 });
  else { await sleep(sayAllMs); w = { waited_ms: Date.now() - t0, sayAllMs }; }
  return record('key_navigate', label, key, t0, kr, before, w, { q0, ready_ms: readyMs, loaded: loadCount > lc });
}
async function check(expr, label) { const v = await isTrue(expr); ev('check', { label, ok: v }); steps[steps.length - 1].checks = [...(steps[steps.length - 1].checks || []), { label, ok: v }]; console.log(`   check ${label}: ${v}`); dump(); return v; }
async function canary() {
  // harness self-test: page-initiated non-local fetch must be failed by Fetch and logged as a refusal
  const r = await evaluate(`fetch('http://refusal-canary.invalid/siteat').then(x => 'UNEXPECTED ' + x.status, e => 'rejected: ' + e)`);
  ev('harness.canary', { result: r });
  return r;
}
const act = sel => `(() => { const a = document.activeElement; return !!a && a.matches(${JSON.stringify(sel)}); })()`;
const actText = (sel, txt) => `(() => { const a = document.activeElement; return !!a && a.matches(${JSON.stringify(sel)}) && (a.textContent||'').replace(/\\s+/g,' ').trim().startsWith(${JSON.stringify(txt)}); })()`;
const ATLAS_READY = `(() => { const s = document.querySelector('#atlas-status'); const q = document.querySelector('#atlas-search'); return !!s && s.textContent.trim().startsWith('Source snapshot') && !!q && !q.disabled; })()`;
const SELECTED_READY = `(${ATLAS_READY}) && (document.querySelector('#atlas-inspector h3')?.textContent.trim() === 'math.d1-component.congruence-erratum')`;
const NODE = 'math.d1-component.congruence-erratum', NB = 'math.uniform-matrix-cap-lifetime';
const ARCH = 'eee261a6e4c075dfc5318a6b6daaa9b42e482d8b7f6ad9cc43a9d1e4e9d13fc5';
const urlHas = s => `location.href.includes(${JSON.stringify(s)}) && document.readyState==='complete'`;
const toInspector = async () => {
  await repeat('Tab', act('button#atlas-focus'), 16, 'Tab to "Return to focus"');
  await press('Return', 'activate "Return to focus"');
  await check(act('#atlas-inspector'), 'focus on #atlas-inspector');
};

// ---------------- tasks ----------------
const TASKS = {
  SMOKE2: async () => {
    await harnessNav(BASE + 'dependencies.html#current-atlas', ATLAS_READY);
    await repeat('Tab', act('input#atlas-search'), 8, 'Tab to search');
    await typeText('cong');
    await press('shift+Tab', 'shift+Tab');
    await read('Down', 'xx-never', 2, 'Down');
  },
  T1: async () => {
    await harnessNav(BASE + 'index.html#main-content', `document.readyState==='complete' && (document.querySelector('.current-state')?.textContent||'').trim().startsWith('Verified')`);
    await repeat('shift+Tab', act('nav[aria-label=Primary] a[href="dependencies.html#current-atlas"]'), 6, 'shift+Tab to Primary "Mathematics"');
    await pressNav('Return', 'activate Primary "Mathematics"', { readyExpr: ATLAS_READY, settleAll: true });
    await check(`location.href === ${JSON.stringify(BASE + 'dependencies.html#current-atlas')}`, 'URL dependencies.html#current-atlas');
    await check(`document.title === 'Mathematics · Universal Law'`, 'title Mathematics · Universal Law');
    await read('Down', 'Source snapshot 2026-10-25T14:27:24Z', 10);
    await read('Down', '42 required', 4);
    await read('Down', '0 explicit graph-to-artifact bindings', 5);
    await read('shift+h', 'Current research sources', 3);
    await read('Down', 'Verified source observation: 2026-10-25T14:27:24Z', 4);
    await read('Down', 'c4eabc1a917ba2c1b96fe4af425cf2a484877c03', 6);
  },
  // SUPPLEMENTARY to T1 (run after T8): try Orca's other reading commands on the role=status lines that
  // browse-mode Down presents only as "statusbar." / "blank": KP_Enter (Where Am I), flat review KP_Up/KP_Page_Up.
  T1S: async () => {
    await harnessNav(BASE + 'index.html#main-content', `document.readyState==='complete' && (document.querySelector('.current-state')?.textContent||'').trim().startsWith('Verified')`);
    await repeat('shift+Tab', act('nav[aria-label=Primary] a[href="dependencies.html#current-atlas"]'), 6, 'shift+Tab to Primary "Mathematics"');
    await pressNav('Return', 'activate Primary "Mathematics"', { readyExpr: ATLAS_READY, settleAll: true });
    await read('Down', 'statusbar', 8, 'Down to the #atlas-status line');
    await press('KP_Enter', 'Where Am I (KP_Enter) on #atlas-status');
    await press('KP_Up', 'flat review: current line (KP_Up)');
    await read('KP_Page_Up', '42 required', 4, 'flat review: next line (KP_Page_Up)');
    await press('KP_Home', 'flat review: previous line (KP_Home)');
    await read('shift+h', 'Current research sources', 3);
    await read('Down', 'statusbar', 3, 'Down to the .current-state line');
    await press('KP_Enter', 'Where Am I (KP_Enter) on .current-state');
    await press('KP_Up', 'flat review: current line (KP_Up)');
    await read('KP_Page_Up', 'more than two hours old', 4, 'flat review: next line (KP_Page_Up)');
  },
  // SUPPLEMENTARY to T2 (run after T8): Where Am I on the View combo box before/after Down, and reading the
  // live count with Orca browse-mode Down after typing (Orca flushes queued live-region messages on each key press).
  T2S: async () => {
    await harnessNav(BASE + 'dependencies.html#current-atlas', ATLAS_READY);
    await repeat('Tab', act('input#atlas-search'), 8, 'Tab to "Find in current graph"');
    await press('Tab', 'Tab to View combo box');
    await press('KP_Enter', 'Where Am I (KP_Enter) on View');
    await press('Down', 'Down on View (Graph -> List)', { settleOpts: { minMs: 1500 } });
    await check(`document.querySelector('#atlas-view').value === 'list'`, 'View value list');
    await press('KP_Enter', 'Where Am I (KP_Enter) on View after Down');
    await repeat('shift+Tab', act('input#atlas-search'), 3, 'shift+Tab back to search');
    await typeText('congruence');
    await check(`(document.querySelector('#atlas-count')?.textContent||'').includes('2 displayed · 2 matching source nodes of 49')`, '#atlas-count 2 of 49');
    await press('insert+a', 'Orca+a (toggle to browse mode)');
    await read('Down', '2 displayed', 14, 'browse-mode Down to the live count');
  },
  // SUPPLEMENTARY to T3 (run after T8): T3's read-until stopped at "Required · reads_with_congruence_erratum · ";
  // read on through the typed edge's direction text.
  T3S: async () => {
    await harnessNav(BASE + `dependencies.html?atlas-node=${NODE}#current-atlas`, SELECTED_READY);
    await toInspector();
    await read('h', 'Consumed by', 9);
    await read('Down', `${NB} → ${NODE}`, 8, 'Down through the Consumed by row');
    await read('Down', 'xx-one-more-line', 1, 'one more line');
  },
  // SUPPLEMENTARY to T4 (run after T8): browse-mode reading of the equation count after typing, and Where Am I on
  // the excerpt combo box after Down (T4's Down changed the value without any Orca speech).
  T4S: async () => {
    await harnessNav(BASE + 'dependencies.html#current-atlas', `(${ATLAS_READY}) && !document.querySelector('#equation-select')?.disabled`);
    await repeat('Tab', act('input#equation-search'), 60, 'Tab to "Find equation text or source"');
    await typeText('periodized');
    await press('insert+a', 'Orca+a (toggle to browse mode)');
    await read('Down', '32 matching excerpts of 108 acquired excerpts', 6, 'browse-mode Down to the equation count');
    await repeat('Tab', act('select#equation-select'), 4, 'Tab to excerpt combo box');
    await press('Down', 'Down on excerpt select', { settleOpts: { minMs: 1500 } });
    await check(`document.querySelector('#equation-select').value.endsWith('periodized_gaussian_h0/PROOF.md:27-28')`, 'excerpt lines 27-28 selected');
    await press('KP_Enter', 'Where Am I (KP_Enter) on excerpt combo box');
  },
  // SUPPLEMENTARY to T5/T6 (run after T1S-T4S): let the load-time speech of the record page play (T5/T6 cut it at
  // 9 s with ctrl+Home), then try Where Am I and flat review on the role=status observation line.
  T5S: async () => {
    await harnessNav(BASE + `snapshots/${ARCH}/nodes/${NODE}.html`, `document.readyState==='complete'`);
    await press('ctrl+Home', 'ctrl+Home');
    await read('h', 'Historical mathematical material', 2);
    await read('Down', 'statusbar', 2, 'Down to the observation status line');
    await press('KP_Enter', 'Where Am I (KP_Enter) on the observation line');
    await press('KP_Up', 'flat review: current line (KP_Up)');
  },
  T6S: async () => {
    await harnessNav(BASE + `nodes/${NODE}.html`, `document.readyState==='complete'`);
    await press('ctrl+Home', 'ctrl+Home');
    await read('h', 'Current research sources', 2);
    await read('Down', 'statusbar', 2, 'Down to the observation status line');
    await press('KP_Enter', 'Where Am I (KP_Enter) on the observation line');
    await press('KP_Up', 'flat review: current line (KP_Up)');
  },
  T2: async () => {
    await harnessNav(BASE + 'dependencies.html#current-atlas', ATLAS_READY);
    await repeat('Tab', act('input#atlas-search'), 8, 'Tab to "Find in current graph"');
    await press('Tab', 'Tab to View combo box');
    await check(act('select#atlas-view'), 'focus on select#atlas-view');
    await press('Down', 'Down on View (Graph -> List)', { settleOpts: { minMs: 1500 } });
    if (!(await check(`document.querySelector('#atlas-view').value === 'list'`, 'View value list'))) {
      if (!(await isTrue(act('select#atlas-view')))) await repeat('shift+Tab', act('select#atlas-view'), 4, 'back to View');
      await press('insert+a', 'FALLBACK Orca+a (toggle focus mode)');
      await press('Down', 'Down on View (retry)', { settleOpts: { minMs: 1500 } });
      await check(`document.querySelector('#atlas-view').value === 'list'`, 'View value list (retry)');
    }
    await repeat('Tab', act('button#atlas-toggle-view'), 12, 'Tab to view toggle button');
    for (const [want, val] of [['Switch to list', 'graph'], ['Switch to graph', 'list']]) {
      const q0 = queued.length;
      await press('Return', `activate toggle (expect "${want}")`, { settleOpts: { minMs: 2000 } });
      await check(`document.querySelector('#atlas-view').value === '${val}' && document.querySelector('#atlas-toggle-view').textContent.trim() === '${want}'`, `view ${val}, button "${want}"`);
      if (!normT(speechSince(q0).join(' ')).includes(normT(want))) await press('KP_Enter', `Where Am I (KP_Enter) after toggle (expect "${want}")`);
    }
    await repeat('shift+Tab', act('input#atlas-search'), 14, 'shift+Tab back to search');
    await typeText('congruence');
    await check(`(document.querySelector('#atlas-count')?.textContent||'').includes('2 displayed · 2 matching source nodes of 49')`, '#atlas-count 2 of 49');
    await repeat('Tab', actText('#atlas-list button', NODE), 14, `Tab to list button ${NODE}`);
    await check(`document.activeElement.getAttribute('aria-pressed') === 'false'`, 'aria-pressed=false before');
    await press('Return', `select ${NODE}`, { settleOpts: { minMs: 1500 } });
    await check(act('#atlas-inspector'), 'focus on #atlas-inspector');
    await check(`document.querySelector('#atlas-inspector h3')?.textContent.trim() === '${NODE}' && location.href.includes('atlas-node=${NODE}')`, 'inspector h3 + URL atlas-node');
    await read('Down', 'required edges: 3', 8);
    await repeat('shift+Tab', actText('#atlas-list button', NODE), 6, `shift+Tab back to list button ${NODE}`);
    await check(`document.activeElement.getAttribute('aria-pressed') === 'true'`, 'aria-pressed=true after');
  },
  T3: async () => {
    await harnessNav(BASE + `dependencies.html?atlas-node=${NODE}#current-atlas`, SELECTED_READY);
    await toInspector();
    await read('Down', 'required edges: 3', 8);
    await read('h', 'Continuation', 8);
    await read('Down', 'Alignment metadata not recorded', 22);
    await read('h', 'Consumes', 3);
    await read('Down', 'No direct relation recorded', 3);
    await read('h', 'Consumed by', 3);
    await read('Down', 'reads_with_congruence_erratum', 10);
  },
  T4: async () => {
    await harnessNav(BASE + 'dependencies.html#current-atlas', `(${ATLAS_READY}) && !document.querySelector('#equation-select')?.disabled`);
    await repeat('Tab', act('input#equation-search'), 60, 'Tab to "Find equation text or source"');
    await typeText('periodized');
    await check(`(document.querySelector('#equation-count')?.textContent||'').startsWith('32 matching excerpts of 108 acquired excerpts')`, '#equation-count 32 of 108');
    await press('Tab', 'Tab to excerpt combo box');
    await check(act('select#equation-select'), 'focus on select#equation-select');
    const selOk = `document.querySelector('#equation-select').value.endsWith('periodized_gaussian_h0/PROOF.md:27-28')`;
    await press('Down', 'Down on excerpt select', { settleOpts: { minMs: 1500 } });
    if (!(await check(selOk, 'excerpt lines 27-28 selected'))) {
      if (!(await isTrue(act('select#equation-select')))) await repeat('shift+Tab', act('select#equation-select'), 4, 'back to excerpt select');
      await press('insert+a', 'FALLBACK Orca+a (toggle focus mode)');
      await press('Down', 'Down on excerpt select (retry)', { settleOpts: { minMs: 1500 } });
      await check(selOk, 'excerpt lines 27-28 selected (retry)');
    }
    await repeat('Tab', act('#equation-content a'), 4, 'Tab to exact source link (NOT activated)');
    await check(`document.activeElement.href === 'https://github.com/d6g8k5htny-coder/main/blob/f61419d8de39b45b20832a760b90fffa82429ab9/experiments/universality/periodized_gaussian_h0/PROOF.md#L27-L28'`, 'DOM href exact immutable f61419d8 lines 27-28');
    await read('Down', 'hypotheses and scope govern this equation', 6);
    await read('Up', 'K_24', 6, 'optional Up');
  },
  T5: async () => {
    await harnessNav(BASE + `dependencies.html?atlas-node=${NODE}#current-atlas`, SELECTED_READY);
    await toInspector();
    await repeat('Tab', actText('a', 'Read the preserved mathematical record'), 3, 'Tab to "Read the preserved mathematical record"');
    await check(`document.activeElement.href === ${JSON.stringify(BASE + `snapshots/${ARCH}/nodes/${NODE}.html`)}`, 'href preserved record');
    await pressNav('Return', 'activate "Read the preserved mathematical record"', { readyExpr: urlHas(`snapshots/${ARCH}/nodes/${NODE}.html`) });
    await press('ctrl+Home', 'ctrl+Home (stop Say All, top)');
    await read('h', 'Historical mathematical material', 2);
    await read('Down', '2026-10-24T00:43:16Z', 4);
    await read('Down', '7d815a5dcfb875b551c21804165e6588cc73d3ab', 6);
    await read('h', 'Incoming required', 10);
    await read('Down', 'required: true', 4);
    await read('shift+h', 'Incoming required', 2);
    await press('k', 'k (next link)');
    if (!(await check(act(`a[href="${NB}.html"]`), 'focus on neighbor link'))) await repeat('Tab', act(`a[href="${NB}.html"]`), 20, 'FALLBACK Tab to neighbor link');
    await pressNav('Return', `activate neighbor ${NB}`, { readyExpr: urlHas(`snapshots/${ARCH}/nodes/${NB}.html`) });
    await press('ctrl+Home', 'ctrl+Home');
    await read('h', 'Historical mathematical material', 2);
    await read('Down', '2026-10-24T00:43:16Z', 4);
    await read('h', NB, 2);
  },
  T6: async () => {
    await harnessNav(BASE + `dependencies.html?atlas-node=${NODE}#current-atlas`, SELECTED_READY);
    await toInspector();
    await repeat('Tab', actText('a', 'Read the static node record'), 4, 'Tab to "Read the static node record"');
    await check(`document.activeElement.href === ${JSON.stringify(BASE + `nodes/${NODE}.html`)}`, 'href static record');
    await pressNav('Return', 'activate "Read the static node record"', { readyExpr: urlHas(`/site/nodes/${NODE}.html`) });
    await press('ctrl+Home', 'ctrl+Home (stop Say All, top)');
    await read('h', 'Current research sources', 2);
    await read('Down', '2026-10-25T14:27:24Z', 4);
    await read('Down', 'c4eabc1a917ba2c1b96fe4af425cf2a484877c03', 6);
    await read('h', 'Resume this node', 3);
    await read('Down', 'As of 2026-10-25T14:27:24Z', 3);
    await read('Down', 'main commit f61419d8de39b45b20832a760b90fffa82429ab9', 12);
    await read('h', 'Incoming required', 14);
    await read('Down', 'required: true', 4);
    await read('shift+h', 'Incoming required', 2);
    await press('k', 'k (next link)');
    if (!(await check(act(`a[href="${NB}.html"]`), 'focus on neighbor link'))) await repeat('Tab', act(`a[href="${NB}.html"]`), 22, 'FALLBACK Tab to neighbor link');
    await pressNav('Return', `activate neighbor ${NB}`, { readyExpr: urlHas(`/site/nodes/${NB}.html`) });
    await check(`!location.href.includes('/snapshots/')`, 'neighbor is current (not snapshots/)');
    await press('ctrl+Home', 'ctrl+Home');
    await read('h', 'Current research sources', 2);
    await read('Down', '2026-10-25T14:27:24Z', 4);
    await read('h', NB, 2);
  },
  T7: async () => {
    await harnessNav(BASE + `dependencies.html?atlas-node=${NODE}#current-atlas`, SELECTED_READY);
    await toInspector();
    await repeat('shift+Tab', act('#atlas-tab-evidence'), 4, 'shift+Tab to Evidence tab');
    await press('Right', 'Right (to Diagnostics tab)');
    if (!(await check(act('#atlas-tab-diagnostics'), 'focus on Diagnostics tab'))) {
      if (!(await isTrue(act('#atlas-tab-evidence')))) await repeat('shift+Tab', act('#atlas-tab-evidence'), 4, 'back to Evidence tab');
      await press('insert+a', 'FALLBACK Orca+a (toggle focus mode)');
      await press('Right', 'Right (retry)');
      await check(act('#atlas-tab-diagnostics'), 'focus on Diagnostics tab (retry)');
    }
    await press('Return', 'activate Diagnostics tab', { settleOpts: { minMs: 1500 } });
    await check(`document.querySelector('#atlas-tab-diagnostics').getAttribute('aria-selected') === 'true' && location.href.includes('atlas-panel=diagnostics')`, 'Diagnostics selected + URL');
    await repeat('Tab', actText('summary', 'Snapshot diagnostics and mapping gaps'), 4, 'Tab to diagnostics disclosure');
    await press('Return', 'expand disclosure', { settleOpts: { minMs: 1500 } });
    await check(`document.activeElement.parentElement.open === true`, 'details open');
    await press('Tab', 'Tab to first gap button');
    await read('Up', 'Diagnostic report unavailable in this source projection', 5);
    await read('Up', `Selected ${NODE}`, 5);
    await read('Down', 'No scientific disposition is inferred', 4);
    await read('Down', 'source metadata not recorded', 18);
  },
  T8: async () => {
    await harnessNav(BASE + 'dependencies.html#current-atlas', ATLAS_READY);
    await read('Up', 'History capacity: 11 of 512 mathematical archives', 5);
    await read('Down', 'no history is pruned', 4);
    await repeat('Tab', actText('summary', 'History and activity'), 60, 'Tab to "History and activity"');
    await press('Return', 'expand History and activity', { settleOpts: { minMs: 1500 } });
    await check(`document.activeElement.parentElement.open === true`, 'details open');
    await press('Tab', 'Tab to "published snapshot manifest" link');
    await check(`document.activeElement.href === ${JSON.stringify(BASE + 'snapshots/index.json')}`, 'manifest href local snapshots/index.json');
    await read('Up', 'This view selects one current source snapshot', 4);
    await read('Down', 'no live presence, assignment or review activity is inferred', 6);
    // optional: open the local manifest, then browser Back by X key alt+Left
    if (!(await isTrue(`document.activeElement.href === ${JSON.stringify(BASE + 'snapshots/index.json')}`))) {
      await repeat('shift+Tab', `document.activeElement.href === ${JSON.stringify(BASE + 'snapshots/index.json')}`, 4, 'back to manifest link');
    }
    await pressNav('Return', 'OPTIONAL activate local "published snapshot manifest"', { readyExpr: urlHas('/site/snapshots/index.json'), sayAllMs: 6000 });
    const ids = await evaluate(`(() => { try { const j = JSON.parse(document.body.innerText); return { ids: j.archives.map(a => a.id), current: j.current, capacity: j.capacity }; } catch (e) { return String(e); } })()`);
    ev('dom.manifest', { ids });
    steps[steps.length - 1].manifest_dom = ids;
    await press('ctrl+Home', 'ctrl+Home');
    await pressNav('alt+Left', 'OPTIONAL alt+Left (browser Back)', { readyExpr: `location.pathname.endsWith('/site/dependencies.html')`, sayAllMs: 4000 });
  },
};

// ---------------- run ----------------
try {
  await settle({ minMs: 2000, firstMs: 2000, qIdle: 1000, maxMs: 15000 });
  const s0 = await probe();
  steps.push({ n: 0, task: TASK, kind: 'start', label: 'neutral start page (data: URL)', t_action: Date.now(), iso_action: iso(Date.now()), after: s0, speech_live_pacing: speechSince(0) });
  const c = await canary();
  steps[0].canary = c; console.log('canary:', c);
  await TASKS[TASK]();
  await settle({ minMs: 1500, maxMs: 15000 });
  steps.push({ n: steps.length, task: TASK, kind: 'end', label: 'final drain', t_action: Date.now(), iso_action: iso(Date.now()), after: await probe() });
} catch (e) {
  console.log('DRIVER ERROR', e.stack || e); ev('driver.error', { msg: String(e.stack || e) });
}
dump();
keyd.stdin.end();
console.log('driver done', TASK, 'steps', steps.length, 'refusals', refusals.length);
ws.close();
process.exit(0);
