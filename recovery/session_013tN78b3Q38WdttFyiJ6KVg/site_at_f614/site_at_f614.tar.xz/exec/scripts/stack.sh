#!/bin/bash
# SITE generated-bundle replay: ONE Xvfb + AT-SPI + speech-dispatcher(espeak-ng, paced sink) + Orca + Chromium
# + custody server stack for one task, then full teardown. Adapted from c220/scripts/run_scenario.sh.
# usage: stack.sh TASK_ID(T1..T8|SMOKE)
set -u
S=/tmp/claude-0/-home-user-main/d5c985ca-97e5-58d8-a9d4-1e0a19065a22/scratchpad/siteat
X=$S/exec
ID="$1"
OUT="$X/evidence/$ID"; SOCK="$S/sd.sock"; PORT=9333
PROFILE="$X/profiles/$ID"
CHROME=/opt/pw-browsers/chromium-1194/chrome-linux/chrome

cleanup() {
  pkill -f "$CHROME" 2>/dev/null; pkill -f /usr/bin/orca 2>/dev/null; pkill -x Xvfb 2>/dev/null
  pkill -x speech-dispatch 2>/dev/null; pkill -x sd_espeak-ng 2>/dev/null; pkill -x sd_openjtalk 2>/dev/null
  pkill -f at-spi-bus-launcher 2>/dev/null; pkill -f at-spi2-registryd 2>/dev/null
  pkill -f "$X/scripts/audio_pacer.py" 2>/dev/null; pkill -f "$X/scripts/keyd.py" 2>/dev/null
  sleep 1
  pkill -9 -f "$CHROME" 2>/dev/null; pkill -9 -f /usr/bin/orca 2>/dev/null; pkill -9 -x Xvfb 2>/dev/null
  pkill -9 -x speech-dispatch 2>/dev/null; pkill -9 -x sd_espeak-ng 2>/dev/null
  rm -f "$SOCK" /tmp/.X99-lock
}
[ -e "$OUT" ] && { echo "refusing: $OUT exists (evidence dirs are new)"; exit 3; }
if pgrep -f /usr/bin/orca >/dev/null || pgrep -x Xvfb >/dev/null || pgrep -x speech-dispatch >/dev/null || pgrep -f "$CHROME" >/dev/null; then
  echo "refusing: another stack is running"; exit 4
fi
mkdir -p "$OUT/sdlog"
CMDS="$OUT/commands.txt"
log() { echo "$(date -u +%Y-%m-%dT%H:%M:%S.%NZ) $*" >> "$CMDS"; }
echo "task=$ID" > "$OUT/run.txt"
date -u +"start %Y-%m-%dT%H:%M:%S.%NZ" >> "$OUT/run.txt"
sha256sum /root/.local/share/orca/user-settings.conf > "$OUT/orca-user-settings.sha256"

# custody server (exact custody serve command; exec so $! is node)
log "(cd $S/scripts && exec /opt/node22/bin/node $S/scripts/serve.mjs $S/bundle $OUT/server-requests.jsonl 8770) &"
(cd $S/scripts && exec /opt/node22/bin/node $S/scripts/serve.mjs $S/bundle "$OUT/server-requests.jsonl" 8770) >"$OUT/server-stdout.jsonl" 2>"$OUT/server-stderr.txt" &
SERVER_PID=$!
sleep 0.5

export DISPLAY=:99
log "Xvfb :99 -screen 0 1280x900x24 -nolisten tcp &"
Xvfb :99 -screen 0 1280x900x24 -nolisten tcp >"$OUT/xvfb.log" 2>&1 &
sleep 1
log 'eval "$(dbus-launch --sh-syntax)"'
eval "$(dbus-launch --sh-syntax)"
echo "dbus=$DBUS_SESSION_BUS_ADDRESS pid=$DBUS_SESSION_BUS_PID" >> "$OUT/run.txt"
export GTK_MODULES=gail:atk-bridge ACCESSIBILITY_ENABLED=1 NO_AT_BRIDGE=0
log "/usr/libexec/at-spi-bus-launcher --launch-immediately &   (GTK_MODULES=$GTK_MODULES ACCESSIBILITY_ENABLED=1)"
/usr/libexec/at-spi-bus-launcher --launch-immediately >"$OUT/atspi.log" 2>&1 &
sleep 1

export SPEECHD_ADDRESS="unix_socket:$SOCK"
log "SITEAT_AUDIO_DIR=$OUT LANG=C.UTF-8 speech-dispatcher -s -t 0 -l 5 -L $OUT/sdlog -C $X/scripts/speechd-conf -S $SOCK -P $OUT/speechd.pid &   (SPEECHD_ADDRESS=$SPEECHD_ADDRESS)"
SITEAT_AUDIO_DIR="$OUT" LANG=C.UTF-8 speech-dispatcher -s -t 0 -l 5 -L "$OUT/sdlog" -C "$X/scripts/speechd-conf" -S "$SOCK" -P "$OUT/speechd.pid" >"$OUT/speechd.out" 2>&1 &
for i in $(seq 1 40); do [ -S "$SOCK" ] && break; sleep 0.25; done
[ -S "$SOCK" ] || echo "PROBLEM: speechd socket missing" >> "$OUT/run.txt"

log "/usr/bin/python3.12 /usr/bin/orca --replace --debug-file=$OUT/orca-debug.txt &"
/usr/bin/python3.12 /usr/bin/orca --replace --debug-file="$OUT/orca-debug.txt" >"$OUT/orca.out" 2>&1 &
sleep 5
grep -q "Speech Dispatcher service failed to connect" "$OUT/orca-debug.txt" && echo "PROBLEM: orca could not connect to speechd" >> "$OUT/run.txt"

CHROME_ARGS=(--no-sandbox --force-renderer-accessibility --no-first-run --no-default-browser-check
  --user-data-dir="$PROFILE" --window-size=1200,850 --window-position=0,0 --remote-debugging-port=$PORT
  --disable-background-networking --disable-component-update --disable-sync --disable-default-apps
  --use-angle=swiftshader --enable-unsafe-swiftshader
  "data:text/html,<title>siteat start</title><p>start</p>")
log "$CHROME ${CHROME_ARGS[*]} &"
"$CHROME" "${CHROME_ARGS[@]}" >"$OUT/chrome.log" 2>&1 &
sleep 3
log "/opt/node22/bin/node $X/scripts/driver.mjs $ID $OUT $PORT"
/opt/node22/bin/node "$X/scripts/driver.mjs" "$ID" "$OUT" $PORT >"$OUT/driver.log" 2>&1
echo "driver_exit=$?" >> "$OUT/run.txt"
sleep 1
date -u +"end %Y-%m-%dT%H:%M:%S.%NZ" >> "$OUT/run.txt"
cleanup
kill -TERM $SERVER_PID 2>/dev/null; sleep 0.5
kill $DBUS_SESSION_BUS_PID 2>/dev/null
rm -rf "$PROFILE"
( cd "$OUT" && sha256sum orca-debug.txt sdlog/speech-dispatcher.log server-requests.jsonl driver.json > hashes.sha256 2>/dev/null; wc -c orca-debug.txt sdlog/speech-dispatcher.log server-requests.jsonl driver.json >> hashes.sha256 2>/dev/null )
cat "$OUT/run.txt"; tail -5 "$OUT/driver.log"
