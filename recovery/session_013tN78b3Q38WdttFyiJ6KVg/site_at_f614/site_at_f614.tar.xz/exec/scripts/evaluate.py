#!/usr/bin/python3 -I
"""Find, per contract item, the ORIGINAL Orca-sent strings (speech.json) that contain it, with step and time.
usage: evaluate.py EVIDENCE_DIR TASK_ID  -> prints findings and writes evaluation.json (search aid only; verdicts are
decided by reading speech.txt)."""
import json, os, re, sys

d, task = sys.argv[1], sys.argv[2]
sp = json.load(open(os.path.join(d, 'speech.json')))
drv = json.load(open(os.path.join(d, 'driver.json')))
steps = {s['n']: s for s in drv['steps']}
n = lambda s: re.sub(r'[^a-z0-9]+', '', s.lower())
ITEMS = {
 'T1': ['Mathematics link', 'Equations and dependency worktree', 'Mathematics · Universal Law',
        'Source snapshot 2026-10-25T14:27:24Z', 'Math c4eabc1a', '49 nodes, 55 edges (42 required)',
        'Verified source observation: 2026-10-25T14:27:24Z', 'stale', 'more than two hours old',
        'f61419d8de39b45b20832a760b90fffa82429ab9', 'c4eabc1a917ba2c1b96fe4af425cf2a484877c03', 'Current research sources'],
 'T2': ['Find in current graph', 'View', 'Graph', 'List', 'Switch to graph', 'Switch to list',
        '2 displayed · 2 matching source nodes of 49', 'math.d1-component.congruence-erratum', 'not pressed', 'pressed',
        'Selected node source and five evidence axes', 'required edges: 3'],
 'T3': ['Selected node source and five evidence axes', 'Downstream nodes · all edges: 3', 'Downstream nodes · required edges: 3',
        'Source metadata recorded', 'Review metadata recorded', 'Kernel metadata not recorded', 'Computation metadata not recorded',
        'Alignment metadata not recorded', 'not_recorded', 'recorded', 'Consumes', 'No direct relation recorded', 'Consumed by',
        'math.uniform-matrix-cap-lifetime', 'reads_with_congruence_erratum',
        'Required · reads_with_congruence_erratum · math.uniform-matrix-cap-lifetime → math.d1-component.congruence-erratum'],
 'T4': ['Find equation text or source', 'periodized', '32 matching excerpts of 108 acquired excerpts', 'Exact acquired equation excerpt',
        'periodized_gaussian_h0/PROOF.md', 'lines 27–28', 'Read exact source lines and surrounding hypotheses',
        'd6g8k5htny-coder/main f61419d8de39b45b20832a760b90fffa82429ab9',
        "The surrounding proof's hypotheses and scope govern this equation; excerpt extraction is not theorem acceptance.", 'K_24'],
 'T5': ['Read the preserved mathematical record', 'Historical mathematical dependency atlas', 'Historical mathematical material',
        'math.d1-component.congruence-erratum', 'Original source observation: 2026-10-24T00:43:16Z',
        '0899cf51675e2e0d053c2d82a7e954f814ca40ee', '7d815a5dcfb875b551c21804165e6588cc73d3ab', 'Incoming required',
        'reads_with_congruence_erratum', 'required: true', 'math.uniform-matrix-cap-lifetime'],
 'T6': ['Read the static node record', 'Current research dependency atlas', 'Current research sources',
        'Pinned source observation: 2026-10-25T14:27:24Z', 'As of 2026-10-25T14:27:24Z',
        'f61419d8de39b45b20832a760b90fffa82429ab9', 'c4eabc1a917ba2c1b96fe4af425cf2a484877c03', 'Incoming required',
        'reads_with_congruence_erratum', 'required: true', 'math.uniform-matrix-cap-lifetime'],
 'T7': ['Evidence', 'Diagnostics', 'Snapshot diagnostics and mapping gaps', 'collapsed', 'expanded',
        'Selected math.d1-component.congruence-erratum: Downstream nodes · all edges: 3.', 'Downstream nodes · required edges: 3.',
        'No scientific disposition is inferred.', 'Diagnostic report unavailable in this source projection.',
        'Engineering generation checks are separate from mathematical evidence.',
        'no explicit graph-to-artifact binding; roles/custody unknown', 'source metadata not recorded'],
 'T8': ['History capacity: 11 of 512 mathematical archives', 'no history is pruned', 'History and activity', 'collapsed', 'expanded',
        'published snapshot manifest', 'This view selects one current source snapshot',
        'the published snapshot manifest identifies the retained population',
        'No activity report is admitted in this projection; no live presence, assignment or review activity is inferred.'],
}
res = []
for item in ITEMS.get(task, []):
    U = sp['orca_sent']; hits = []
    for i in range(len(U)):
        for j in range(i, min(i + 5, len(U))):
            span = U[i:j + 1]
            if n(item) in n(' '.join(u['text'] for u in span)):
                if not any(h['i'] == i or (h['i'] < i <= h['j']) for h in hits):
                    hits.append({'i': i, 'j': j, 'step': span[0]['step'], 'iso': span[0]['iso'],
                                 'text': ' | '.join(u['text'] for u in span),
                                 'src': ','.join(sorted({u['log_source'] for u in span})),
                                 'status': ','.join(str((u.get('speechd') or {}).get('status')) for u in span),
                                 'step_label': steps.get(span[0]['step'], {}).get('label')})
                break
    res.append({'item': item, 'hits': hits})
    print(f"\n## {item!r}: {len(hits)} hit(s)")
    for h in res[-1]['hits'][:4]:
        print(f"   #{h['step']} {h['iso']} [{h['src']}|{h['status']}] {h['text'][:230]!r}   <- {str(h['step_label'])[:70]}")
json.dump(res, open(os.path.join(d, 'evaluation.json'), 'w'), indent=1)
