"""Receiver custody steps 1-3 for carrier 665f0686 (SITE generated-bundle replay).

usage: python3 -I custody.py CARRIER_DIR BUNDLE_DIR OUT_JSON

Reads only data files from CARRIER_DIR; never imports or executes anything from it.
Order: complete-file length/SHA-256/git-blob checks BEFORE any ZIP parsing; then ZIP
structure, single member, inner tar hash; then an own raw-tar walk cross-checked against
the tarfile module; safety checks; manual extraction into a NEW EMPTY BUNDLE_DIR; then
the assembled fingerprint over the in-memory tar members; then publication-metadata and
snapshot joins against the extracted bytes. Exit 0 only if every required check passes.
"""
import hashlib
import io
import json
import os
import re
import stat
import struct
import sys
import tarfile
import zipfile

CARRIER, BUNDLE, OUT = (os.path.abspath(p) for p in sys.argv[1:4])
R = {"schema": "siteat-receiver-custody/1", "carrier_dir": CARRIER, "bundle_dir": BUNDLE,
     "checks": {}, "problems": []}


def check(name, ok, **detail):
    R["checks"][name] = {"ok": bool(ok), **detail}
    if not ok:
        R["problems"].append(name)
    return ok


def fail_out():
    R["passed"] = False
    with open(OUT, "w") as f:
        json.dump(R, f, indent=1, sort_keys=True)
    print(json.dumps(R["problems"]))
    sys.exit(1)


def sha256(b):
    return hashlib.sha256(b).hexdigest()


def gitblob(b):
    return hashlib.sha1(b"blob %d\0" % len(b) + b).hexdigest()


def readall(p):
    with open(p, "rb") as f:
        return f.read()


# ---------------------------------------------------------------- step 1a: complete files
manifest_bytes = readall(os.path.join(CARRIER, "MANIFEST.json"))
R["manifest_file"] = {"bytes": len(manifest_bytes), "sha256": sha256(manifest_bytes),
                      "git_blob": gitblob(manifest_bytes)}
M = json.loads(manifest_bytes)
blobs = {}
for p in M["payloads"]:
    name = os.path.basename(p["path"])
    b = readall(os.path.join(CARRIER, name))
    blobs[name] = b
    got = {"bytes": len(b), "sha256": sha256(b), "git_blob": gitblob(b)}
    want = {"bytes": p["bytes"], "sha256": p["sha256"], "git_blob": p["git_blob"]}
    check("file_" + name, got == want, got=got, manifest=want,
          actions_artifact_id=p.get("actions_artifact_id"))
if R["problems"]:
    fail_out()  # never parse a ZIP whose complete bytes did not verify

# ---------------------------------------------------------------- step 1b: ZIP structure


def zip_layout(b):
    """Own EOCD/central-directory/local-header accounting: no prepended or trailing bytes."""
    eocd = b.rfind(b"PK\x05\x06")
    sig, disk, cddisk, n_disk, n_total, cd_size, cd_off, clen = struct.unpack(
        "<4sHHHHIIH", b[eocd:eocd + 22])
    info = {"eocd_offset": eocd, "entries": n_total, "cd_offset": cd_off, "cd_size": cd_size,
            "comment_len": clen, "eocd_at_end": eocd + 22 + clen == len(b),
            "cd_ends_at_eocd": cd_off + cd_size == eocd, "starts_with_local_header": b[:4] == b"PK\x03\x04"}
    info["multiple_eocd_signatures"] = b.count(b"PK\x05\x06") != 1
    return info


def tiles(b, zf, layout):
    """Local header + data + optional descriptor of every member must tile [0, cd_off) exactly."""
    pos = 0
    for zi in sorted(zf.infolist(), key=lambda z: z.header_offset):
        if zi.header_offset != pos:
            return False, "member %r starts at %d, expected %d" % (zi.filename, zi.header_offset, pos)
        nlen, xlen = struct.unpack("<HH", b[pos + 26:pos + 30])
        pos += 30 + nlen + xlen + zi.compress_size
        if zi.flag_bits & 0x08:
            if b[pos:pos + 4] == b"PK\x07\x08":
                pos += 4
            pos += 12 if not zi.compress_size >= 0xFFFFFFFF else 20
    return pos == layout["cd_offset"], "data ends at %d, central directory at %d" % (pos, layout["cd_offset"])


for name in blobs:
    b = blobs[name]
    zf = zipfile.ZipFile(io.BytesIO(b))
    lay = zip_layout(b)
    ok_tile, why = tiles(b, zf, lay)
    bad_crc = zf.testzip()
    names = [z.filename for z in zf.infolist()]
    check("zip_structure_" + name,
          lay["eocd_at_end"] and lay["cd_ends_at_eocd"] and lay["starts_with_local_header"]
          and lay["comment_len"] == 0 and lay["entries"] == len(names) and ok_tile and bad_crc is None
          and len(set(names)) == len(names),
          eocd_offset=lay["eocd_offset"], cd_offset=lay["cd_offset"], cd_size=lay["cd_size"],
          entries=lay["entries"], comment_len=lay["comment_len"], tiling=why, crc_failure=bad_crc,
          members=[{"name": z.filename, "file_size": z.file_size, "compress_size": z.compress_size,
                    "method": z.compress_type, "flag_bits": z.flag_bits,
                    "unix_mode": oct(z.external_attr >> 16), "date_time": list(z.date_time)}
                   for z in zf.infolist()])

pz = zipfile.ZipFile(io.BytesIO(blobs["PAGES.zip"]))
pnames = [z.filename for z in pz.infolist()]
check("pages_zip_single_member", pnames == ["artifact.tar"] and not pz.infolist()[0].is_dir(),
      members=pnames)
if R["problems"]:
    fail_out()
tar = pz.read("artifact.tar")
want_tar = M["inner_tar"]
check("inner_tar_hash", {"bytes": len(tar), "sha256": sha256(tar)} == want_tar,
      got={"bytes": len(tar), "sha256": sha256(tar)}, manifest=want_tar)
if R["problems"]:
    fail_out()

# ---------------------------------------------------------------- step 1c: own raw tar walk


def octal(field):
    if field[:1] and field[0] & 0x80:  # base-256
        return int.from_bytes(field[1:], "big")
    s = field.split(b"\0", 1)[0].strip()
    return int(s, 8) if s else 0


def raw_walk(t):
    entries, pax, pos, kinds = [], {}, 0, {}
    longname = None
    while True:
        if pos + 512 > len(t):
            return entries, {"error": "truncated header at %d" % pos}, kinds
        h = t[pos:pos + 512]
        if h == b"\0" * 512:
            rest = t[pos:]
            return entries, {"end_marker_offset": pos, "zero_blocks_after_last_member": len(rest) // 512,
                             "trailing_all_zero": rest.count(0) == len(rest),
                             "two_zero_blocks": len(rest) >= 1024 and rest[:1024] == b"\0" * 1024,
                             "length_multiple_of_512": len(t) % 512 == 0,
                             "length_multiple_of_10240": len(t) % 10240 == 0}, kinds
        chk = octal(h[148:156])
        calc = sum(h[:148]) + 8 * 32 + sum(h[156:])
        if chk != calc:
            return entries, {"error": "bad header checksum at %d" % pos}, kinds
        typ = chr(h[156]) if h[156] else "0"
        kinds[typ] = kinds.get(typ, 0) + 1
        size = octal(h[124:136])
        magic = h[257:265]
        name = h[0:100].split(b"\0", 1)[0]
        if magic[:5] == b"ustar" and magic[5:6] == b"\0":
            prefix = h[345:500].split(b"\0", 1)[0]
            if prefix:
                name = prefix + b"/" + name
        data_off = pos + 512
        data = t[data_off:data_off + size]
        pos = data_off + (size + 511) // 512 * 512
        if typ == "x":  # pax extended header for the next member
            pax = {}
            i = 0
            while i < len(data):
                sp = data.index(b" ", i)
                ln = int(data[i:sp])
                k, v = data[sp + 1:i + ln - 1].split(b"=", 1)
                pax[k.decode()] = v
                i += ln
            continue
        if typ == "g":
            kinds["global_pax_keys"] = sorted(k for k in data.decode("utf-8", "replace").split("\n") if k)
            continue
        if typ == "L":
            longname = data.split(b"\0", 1)[0]
            continue
        if longname is not None:
            name, longname = longname, None
        if "path" in pax:
            name = pax["path"]
        if "size" in pax:
            size = int(pax["size"])
        entries.append({"raw_name": name, "type": typ, "size": size, "data_offset": data_off,
                        "mode": octal(h[100:108]), "mtime": octal(h[136:148]),
                        "linkname": h[157:257].split(b"\0", 1)[0], "magic": magic,
                        "devmajor": octal(h[329:337]) if magic[:5] == b"ustar" else 0,
                        "pax_keys": sorted(pax)})
        pax = {}


entries, closure, kinds = raw_walk(tar)
check("tar_closed", "error" not in closure and closure.get("trailing_all_zero") and closure.get("two_zero_blocks")
      and closure.get("length_multiple_of_512"), header_kinds=kinds, **closure)

# second, independent parse with the stdlib module; members must agree exactly
tf = tarfile.open(fileobj=io.BytesIO(tar), mode="r:")
lib = [(m.name, m.type.decode(), m.size) for m in tf.getmembers()]
mine = [(e["raw_name"].decode("utf-8"), e["type"], e["size"]) for e in entries]
# tarfile strips a trailing slash on directory names; normalise both sides for comparison
norm = lambda lst: [(n.rstrip("/") or n, t, s) for n, t, s in lst]
check("tar_two_parsers_agree", norm(lib) == norm(mine), members_raw=len(mine), members_tarfile=len(lib))

# ---------------------------------------------------------------- step 1d: tar safety
unsafe, rel_entries, seen = [], [], set()
for e in entries:
    try:
        n = e["raw_name"].decode("utf-8")
    except UnicodeDecodeError:
        unsafe.append({"name": repr(e["raw_name"]), "why": "non-UTF-8 name"})
        continue
    why = []
    if e["type"] not in ("0", "5"):
        why.append("type %r is not regular file or directory" % e["type"])
    if n.startswith("/"):
        why.append("absolute path")
    if "\0" in n or "\\" in n:
        why.append("NUL or backslash in name")
    rel = n[2:] if n.startswith("./") else ("" if n in (".", "./") else n)
    rel = rel.rstrip("/") if e["type"] == "5" else rel
    parts = rel.split("/") if rel else []
    if any(p in ("..",) for p in parts):
        why.append(".. segment")
    if any(p in ("", ".") for p in parts):
        why.append("empty or . segment")
    if e["linkname"]:
        why.append("linkname set")
    if e["type"] == "0" and e["mode"] & (stat.S_ISUID | stat.S_ISGID | stat.S_ISVTX):
        why.append("setuid/setgid/sticky mode %o" % e["mode"])
    if e["type"] == "5" and e["size"] != 0:
        why.append("directory with nonzero size")
    if rel in seen:
        why.append("duplicate after normalisation")
    seen.add(rel)
    if why:
        unsafe.append({"name": n, "why": why})
    rel_entries.append(dict(e, rel=rel))
# a regular file must never be a parent of another entry
files_set = {e["rel"] for e in rel_entries if e["type"] == "0"}
for e in rel_entries:
    parts = e["rel"].split("/")
    for i in range(1, len(parts)):
        if "/".join(parts[:i]) in files_set:
            unsafe.append({"name": e["rel"], "why": "parent is a regular file"})
check("tar_safe", not unsafe, unsafe=unsafe[:50],
      regular_files=sum(e["type"] == "0" for e in rel_entries),
      directories=sum(e["type"] == "5" for e in rel_entries),
      name_prefix_dot_slash=all(e["raw_name"].startswith(b"./") or e["raw_name"] in (b".", b"./") for e in entries),
      pax_keys_seen=sorted({k for e in entries for k in e["pax_keys"]}),
      modes_seen=sorted({oct(e["mode"]) for e in entries}))
if R["problems"]:
    fail_out()

# ---------------------------------------------------------------- step 1e: extraction
if os.path.lexists(BUNDLE):
    if not (os.path.isdir(BUNDLE) and not os.path.islink(BUNDLE) and not os.listdir(BUNDLE)):
        check("bundle_dir_new_empty", False, why="exists and is not an empty directory")
        fail_out()
    created = False
else:
    os.mkdir(BUNDLE, 0o755)
    created = True
check("bundle_dir_new_empty", True, created_by_script=created)
root_real = os.path.realpath(BUNDLE)
written = 0
for e in rel_entries:
    if not e["rel"]:
        continue
    dest = os.path.join(BUNDLE, *e["rel"].split("/"))
    parent = os.path.realpath(os.path.dirname(dest))
    if not (parent == root_real or parent.startswith(root_real + os.sep)):
        check("extract_contained", False, path=e["rel"])
        fail_out()
    if e["type"] == "5":
        os.makedirs(dest, 0o755, exist_ok=True)
        continue
    os.makedirs(os.path.dirname(dest), 0o755, exist_ok=True)
    fd = os.open(dest, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644)
    with os.fdopen(fd, "wb") as f:
        f.write(tar[e["data_offset"]:e["data_offset"] + e["size"]])
    os.utime(dest, (e["mtime"], e["mtime"]))
    written += 1
check("extract_contained", True, files_written=written)
top = sorted(os.listdir(BUNDLE))
check("artifact_root_has_site", os.path.isdir(os.path.join(BUNDLE, "site")), top_level=top)

# ---------------------------------------------------------------- step 2 (tar side): fingerprint
DOMAIN = b"current-site-generated-browser-input-v1\0"
regs = sorted((e for e in rel_entries if e["type"] == "0"), key=lambda e: e["rel"])
h = hashlib.sha256(DOMAIN)
total = 0
for e in regs:
    nb = e["rel"].encode("utf-8")
    body = tar[e["data_offset"]:e["data_offset"] + e["size"]]
    h.update(struct.pack(">Q", len(nb)) + nb + struct.pack(">Q", len(body)) + body)
    total += len(body)
fp = {"files": len(regs), "bytes": total, "sha256": h.hexdigest()}
check("fingerprint_from_tar_members", fp == M["publication_candidate"]["artifact"], got=fp,
      manifest=M["publication_candidate"]["artifact"])

# ---------------------------------------------------------------- step 3: publication metadata
mz = zipfile.ZipFile(io.BytesIO(blobs["PUBLICATION-METADATA.zip"]))
site = os.path.join(BUNDLE, "site")
meta_rows = []
for zi in mz.infolist():
    mb = mz.read(zi)
    row = {"member": zi.filename, "bytes": len(mb), "sha256": sha256(mb)}
    dest = os.path.join(site, *zi.filename.split("/"))
    if zi.filename == "candidate.json":
        row["compared_to"] = "MANIFEST.json publication_candidate (JSON value; not a site file)"
        row["equal"] = json.loads(mb) == M["publication_candidate"]
        row["site_file_exists"] = os.path.exists(dest)
    else:
        row["compared_to"] = "site/" + zi.filename
        sb = readall(dest) if os.path.isfile(dest) else None
        row["site_bytes"] = None if sb is None else len(sb)
        row["equal"] = sb == mb
    meta_rows.append(row)
by = {r["member"]: r for r in meta_rows}
need = ["current.json", "current-meta.json", "snapshots/index.json"]
check("metadata_equals_site_files", all(by.get(n, {}).get("equal") for n in need),
      members=meta_rows, required=["site/" + n for n in need],
      extra_members=[r["member"] for r in meta_rows if r["member"] not in need])
check("metadata_candidate_equals_manifest", by.get("candidate.json", {}).get("equal") is True)
pc = M["publication_candidate"]
pairs = {"payload": "current.json", "metadata": "current-meta.json", "manifest": "snapshots/index.json"}
check("publication_candidate_hashes_bind_site_files",
      all({"bytes": by[v]["bytes"], "sha256": by[v]["sha256"]} == {"bytes": pc[k]["bytes"], "sha256": pc[k]["sha256"]}
          for k, v in pairs.items()),
      binding={k: "site/" + v for k, v in pairs.items()})

idx = json.loads(readall(os.path.join(site, "snapshots", "index.json")))
cm = json.loads(readall(os.path.join(site, "current-meta.json")))
arch_ids = [a["id"] for a in idx["archives"]]
man_ids = pc["snapshot_ids"]
check("snapshot_ids_equal", sorted(arch_ids) == sorted(man_ids) and len(man_ids) == 11 and len(set(arch_ids)) == 11,
      manifest_count=len(man_ids), index_count=len(arch_ids),
      only_in_manifest=sorted(set(man_ids) - set(arch_ids)), only_in_index=sorted(set(arch_ids) - set(man_ids)))


RELEASE_KEY = re.compile(rb"\?site-release=[0-9a-f]+")


def file_ok(rel_to_site, bytes_, sha, strip_release=False):
    """'ok' exact; 'ok_after_release_strip' when only ?site-release=<hex> keys differ; else missing/mismatch."""
    p = os.path.join(site, *rel_to_site.split("/"))
    if not os.path.isfile(p) or os.path.islink(p):
        return "missing"
    b = readall(p)
    if (len(b), sha256(b)) == (bytes_, sha):
        return "ok"
    if strip_release and p.endswith(".html"):
        s = RELEASE_KEY.sub(b"", b)
        if (len(s), sha256(s)) == (bytes_, sha):
            return "ok_after_release_strip"
    return "mismatch"


def tally(xs):
    return {k: xs.count(k) for k in sorted(set(xs))}


dest_rows, dest_ok, join_ok = [], True, True
for a in idx["archives"]:
    d = os.path.join(site, "snapshots", a["id"])
    served = sorted(os.path.relpath(os.path.join(dp, f), d).replace(os.sep, "/")
                    for dp, _, fs in os.walk(d) for f in fs) if os.path.isdir(d) else []
    row = {"id": a["id"], "observed_at": a.get("observed_at"), "renderer": a.get("renderer"),
           "dir_exists": os.path.isdir(d) and not os.path.islink(d), "served_regular_files": len(served)}
    b = a["bundle"]
    row["archive_zip"] = {"path": "site/" + b["path"], "status": file_ok(b["path"], b["bytes"], b["sha256"])}
    # index files[]/alias_files[] describe archive.zip members (files at <path>, aliases at aliases/<path>)
    zb = readall(os.path.join(site, *b["path"].split("/"))) if row["archive_zip"]["status"] == "ok" else None
    zm = {}
    if zb is not None:
        az = zipfile.ZipFile(io.BytesIO(zb))
        zm = {zi.filename: sha256(az.read(zi)) for zi in az.infolist()}
    row["archive_zip_members"] = len(zm)
    row["index_files_match_zip"] = sum(zm.get(f["path"]) == f["sha256"] for f in a["files"])
    row["index_alias_files_match_zip"] = sum(zm.get("aliases/" + f["path"]) == f["sha256"] for f in a["alias_files"])
    row["index_files_listed"], row["index_alias_files_listed"] = len(a["files"]), len(a["alias_files"])
    # static destinations: every listed path is served under site/snapshots/<id>/
    want_static = {"archive.zip"} | {f["path"] for f in a["files"]}
    row["static_paths_missing"] = sorted(want_static - set(served))
    row["static_paths_unlisted"] = sorted(set(served) - want_static)
    st = [file_ok("snapshots/%s/%s" % (a["id"], f["path"]), f["bytes"], f["sha256"], strip_release=True) for f in a["files"]]
    row["static_vs_index_files"] = tally(st)
    dest_ok &= (row["dir_exists"] and row["archive_zip"]["status"] == "ok" and not row["static_paths_missing"]
                and not row["static_paths_unlisted"] and row["index_files_match_zip"] == len(a["files"])
                and row["index_alias_files_match_zip"] == len(a["alias_files"]))
    join_ok &= "mismatch" not in st and "missing" not in st
    dest_rows.append(row)
check("snapshot_destinations_exist", dest_ok and len(dest_rows) == 11, archives=dest_rows,
      note="archive.zip bytes/sha256 per index; index files[]/alias_files[] equal archive.zip members; "
           "every listed path is present as a static destination and no unlisted file is served there")
check("static_destinations_equal_index_after_release_key_strip", join_ok,
      note="served static HTML differs from the archived bytes only by ?site-release=<hex> URL keys "
           "(own regex, approximating tools/current_site_build.py normalized_archive_bytes/without_release at "
           "f61419d8; no repository code executed); JSON members compared exactly")
check("current_pointer_consistent",
      idx["current"] == cm["archive"] and cm["archive"] in man_ids
      and cm["history_manifest_sha256"] == pc["manifest"]["sha256"] and cm["sha256"] == pc["payload"]["sha256"],
      index_current=idx["current"], current_meta=cm)
co = idx["current_observation"]
co_status = [file_ok(f["path"], f["bytes"], f["sha256"], strip_release=True) for f in co["files"]]
co_status.append(file_ok(co["payload"]["path"], co["payload"]["bytes"], co["payload"]["sha256"]))
check("current_observation_files_served", "mismatch" not in co_status and "missing" not in co_status,
      listed=len(co_status), status=tally(co_status),
      note="site/<path> for the 50 current node pages and current.json; HTML compared after ?site-release key strip")
al_status = [file_ok(f["path"], f["bytes"], f["sha256"], strip_release=True) for f in idx.get("aliases", [])]
check("current_aliases_served", "mismatch" not in al_status and "missing" not in al_status,
      listed=len(al_status), status=tally(al_status),
      bindings=sorted({f.get("binding") for f in idx.get("aliases", [])}),
      snapshots=sorted({f.get("snapshot") for f in idx.get("aliases", [])}))
R["snapshot_index_summary"] = {"origin": idx.get("origin"), "representation": idx.get("representation"),
                               "capacity": idx.get("capacity"), "total_bytes": idx.get("total_bytes"),
                               "aliases": len(idx.get("aliases", []))}
R["passed"] = not R["problems"]
with open(OUT, "w") as f:
    json.dump(R, f, indent=1, sort_keys=True)
print("passed" if R["passed"] else json.dumps(R["problems"]))
sys.exit(0 if R["passed"] else 1)
