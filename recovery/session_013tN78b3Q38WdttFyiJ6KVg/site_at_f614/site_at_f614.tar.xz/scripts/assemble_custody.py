"""Assemble custody/custody.json from the raw check outputs.

usage: python3 -I assemble_custody.py SITEAT_DIR
Reads custody/custody_raw.json, custody/fingerprint_disk.json, custody/serve_test/*, the
carrier files and the scripts; writes custody/custody.json.
"""
import hashlib
import json
import os
import sys

S = os.path.abspath(sys.argv[1])
C = os.path.join(S, "custody")


def rd(p):
    with open(p, "rb") as f:
        return f.read()


def sha(b):
    return hashlib.sha256(b).hexdigest()


raw = json.loads(rd(os.path.join(C, "custody_raw.json")))
disk = json.loads(rd(os.path.join(C, "fingerprint_disk.json")))
reqs = [json.loads(l) for l in rd(os.path.join(C, "serve_test", "requests.jsonl")).splitlines() if l.strip()]
srv = [json.loads(l) for l in rd(os.path.join(C, "serve_test", "server_stdout.jsonl")).splitlines() if l.strip()]
ck = raw["checks"]
scripts = {n: {"bytes": len(rd(os.path.join(S, "scripts", n))), "sha256": sha(rd(os.path.join(S, "scripts", n)))}
           for n in ("custody.py", "fingerprint.py", "serve.mjs", "assemble_custody.py")}
carrier = {}
for n in ("MANIFEST.json", "PAGES.zip", "PUBLICATION-METADATA.zip", "README.md"):
    b = rd(os.path.join(S, "carrier", n))
    carrier[n] = {"bytes": len(b), "sha256": sha(b), "git_blob": hashlib.sha1(b"blob %d\0" % len(b) + b).hexdigest()}
LS_TREE = {"MANIFEST.json": "5d769ad24cd2205ec6d758c39b607768bee05f41",
           "PAGES.zip": "871725e4265dc4751902158f102119fb9d2bcda1",
           "PUBLICATION-METADATA.zip": "59618f00110d4be0ba8bbc62875dcc7702fad07f",
           "README.md": "f6175349c22a4470da1ee8cafc1f3fa945fac1df"}
for n in carrier:
    carrier[n]["ls_tree_blob"] = LS_TREE[n]
    carrier[n]["blob_match"] = carrier[n]["git_blob"] == LS_TREE[n]

test_ok = (len(reqs) == 3 and [r["status"] for r in reqs] == [200, 200, 404]
           and all(r["sha256"] == sha(rd(os.path.join(S, "bundle", *r["file"].split("/")))) for r in reqs if r["status"] == 200))
fp_ok = (disk["files"], disk["bytes"], disk["sha256"]) == (861, 20900216,
                                                            "f192a8f3e87c9c4ce59e6c084d2848a2bc8d35e4859a943d69a5a4baf156cdac")
problems = list(raw["problems"])
if not fp_ok:
    problems.append("fingerprint_from_disk")
if not test_ok:
    problems.append("serve_test")
if not all(v["blob_match"] for v in carrier.values()):
    problems.append("carrier_git_blob")

out = {
    "schema": "siteat-receiver-custody-result/1",
    "evidence_class": "GENERATED-BUNDLE REPLAY input custody: byte-level file checks only. No browser, Orca, "
                      "speech-dispatcher or keyboard input was used; no DOM/AX or speech evidence is produced here.",
    "lane": {"session": "session_013tN78b3Q38WdttFyiJ6KVg", "name": "Claude 54",
             "pickup": "https://github.com/d6g8k5htny-coder/main/issues/539#issuecomment-6400510700"},
    "passed": not problems,
    "problems": problems,
    "identities": {
        "carrier_commit": "665f068607840ba5326e4089b1b62972902310bb",
        "carrier_tree": "221538bd306773362e574b76b3798a6d1055af9f",
        "carrier_subtree": "9e2bea73dacc934557897b8148414806c755a5f0",
        "carrier_commit_parent": "f61419d8de39b45b20832a760b90fffa82429ab9",
        "source_main": "f61419d8de39b45b20832a760b90fffa82429ab9",
        "source_main_tree": "62a6a99b3c9df9b38faa7c17405035e55b67de81",
        "source_math": "c4eabc1a917ba2c1b96fe4af425cf2a484877c03",
        "observation": "2026-10-25T14:27:24Z",
        "publisher_run": "40201937556/attempt1",
        "note": "Carrier commit and source commit are separate identities; the carrier's parent is Main f61419d8 "
                "but its tree holds only carrier/ (4 blobs)."},
    "carrier_files": carrier,
    "carrier_route": "Local git objects in /home/user/main (git cat-file / ls-tree / show of 665f0686); every local "
                     "carrier file's git hash-object equals its ls-tree blob and is cmp-identical to "
                     "`git show 665f0686:carrier/<file>`. No network fetch and no gh api call in this step.",
    "step1_zip": {k: ck[k] for k in ("file_PAGES.zip", "file_PUBLICATION-METADATA.zip", "zip_structure_PAGES.zip",
                                     "zip_structure_PUBLICATION-METADATA.zip", "pages_zip_single_member", "inner_tar_hash")},
    "step1_tar": {k: ck[k] for k in ("tar_closed", "tar_two_parsers_agree", "tar_safe")},
    "step1_extract": {k: ck[k] for k in ("bundle_dir_new_empty", "extract_contained", "artifact_root_has_site")},
    "step1_extract_method": "Manual extraction from the in-memory tar (no tarfile.extract*): directories 0755, files "
                            "O_CREAT|O_EXCL|O_NOFOLLOW 0644, mtimes from tar headers, every parent realpath-contained "
                            "in the bundle directory. Tar modes are not applied.",
    "step1_run_history": "custody.py ran three times; each run created bundle/ from an absent path. Run 1 extracted "
                         "and then crashed in later reporting code (keyword-name bug); run 2 completed with two "
                         "extra-join checks failing because I had misread what the index's per-file hashes cover. "
                         "After each of those runs I deleted the bundle/ that run had created. The final bundle/ "
                         "is from run 3, where all checks pass. No bundle byte was edited.",
    "step2_fingerprint": {
        "definition": "sha256(b'current-site-generated-browser-input-v1\\0' || for each regular file sorted by "
                      "relative POSIX path (Python str order): u64be(len(utf8 name)) || name || u64be(size) || bytes)",
        "from_tar_members": ck["fingerprint_from_tar_members"],
        "from_extracted_disk": {k: disk[k] for k in ("files", "bytes", "sha256", "non_regular_entries", "by_top_level")},
        "expected": {"files": 861, "bytes": 20900216,
                     "sha256": "f192a8f3e87c9c4ce59e6c084d2848a2bc8d35e4859a943d69a5a4baf156cdac"},
        "ok": ck["fingerprint_from_tar_members"]["ok"] and fp_ok},
    "step3_metadata": {k: ck[k] for k in ("metadata_equals_site_files", "metadata_candidate_equals_manifest",
                                          "publication_candidate_hashes_bind_site_files", "current_pointer_consistent")},
    "step3_snapshots": {k: ck[k] for k in ("snapshot_ids_equal", "snapshot_destinations_exist",
                                           "static_destinations_equal_index_after_release_key_strip",
                                           "current_observation_files_served", "current_aliases_served")},
    "snapshot_index_summary": raw["snapshot_index_summary"],
    "step4_server": {
        "script": os.path.join(S, "scripts", "serve.mjs"),
        "command": "cd %s && /opt/node22/bin/node %s %s <LOG_PATH> 8770" % (
            os.path.join(S, "scripts"), os.path.join(S, "scripts", "serve.mjs"), os.path.join(S, "bundle")),
        "bind": "127.0.0.1:8770", "root": os.path.join(S, "bundle"), "url_prefix": "http://127.0.0.1:8770/site/",
        "behaviour": "node: builtins only (http, fs, path, crypto); loopback bind; GET/HEAD only (else 405); "
                     "absolute-form targets 400 (no proxying); '..', NUL or backslash 400; symlinks/non-regular 403; "
                     "missing 404 with a 14-byte text body (the bundle's 404.html is not substituted); '/dir' 301 to "
                     "'/dir/', and '/dir/' serves dir/index.html; Cache-Control no-store; bytes served unmodified; "
                     "one JSON line per request: time, method, url, path, status, bytes, sha256 of the body sent, "
                     "file, content_type, remote, plus location/note when set.",
        "test_log": os.path.join(C, "serve_test", "requests.jsonl"),
        "test_requests": reqs,
        "server_events": srv,
        "test_ok": test_ok,
        "test_note": "Each 200 body was saved by curl (--noproxy 127.0.0.1) and was cmp-identical to the bundle file. "
                     "The 404 was a deliberate missing-path probe. While the server was running, it held one socket "
                     "fd, its listener; addresses were not decoded. It was then stopped with SIGTERM, and a "
                     "follow-up connect to 127.0.0.1:8770 was refused.",
        "external_requests": "none made by the server (it has no client code); browser-side blocking "
                             "(CDP Fetch.failRequest) belongs to the later replay stage, not this step."},
    "scripts": scripts,
    "limits": [
        "Custody only: no accessibility PASS/FAIL is produced; the SITE spoken AT result stays NOT_OBSERVED.",
        "Generated-bundle replay input; not deployed-origin testing and not git-source (docs/site) testing.",
        "The ?site-release=<hex> strip is my own regex, which approximates tools/current_site_build.py "
        "normalized_archive_bytes/without_release at f61419d8. No repository code was executed.",
        "Clock-age/staleness disclosures in the pages are expected for this dated input; nothing was regenerated."],
}
with open(os.path.join(C, "custody.json"), "w") as f:
    json.dump(out, f, indent=1, sort_keys=False)
print(json.dumps({"passed": out["passed"], "problems": problems, "test_ok": test_ok, "fp_ok": fp_ok}))
