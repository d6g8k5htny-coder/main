"""Assembled fingerprint of an extracted artifact root, computed from the files on disk.

usage: python3 -I fingerprint.py ARTIFACT_ROOT [OUT_JSON]

sha256( b"current-site-generated-browser-input-v1\\0"
        || for each regular file, sorted by relative POSIX path (UTF-8):
             u64be(len(name)) || name || u64be(size) || bytes )
Walks with lstat and never follows links; any entry that is neither a regular file nor a
directory is reported and makes the result fail. Also reports per-top-level-directory counts.
"""
import hashlib
import json
import os
import stat
import sys

root = os.path.abspath(sys.argv[1])
files, odd = [], []


def walk(rel):
    full = os.path.join(root, rel) if rel else root
    for name in os.listdir(full):
        r = name if not rel else rel + "/" + name
        st = os.lstat(os.path.join(full, name))
        if stat.S_ISDIR(st.st_mode):
            walk(r)
        elif stat.S_ISREG(st.st_mode):
            files.append(r)
        else:
            odd.append({"path": r, "mode": oct(st.st_mode)})


walk("")
files.sort()
h = hashlib.sha256(b"current-site-generated-browser-input-v1\0")
total, tops = 0, {}
for r in files:
    with open(os.path.join(root, *r.split("/")), "rb") as f:
        body = f.read()
    name = r.encode("utf-8")
    h.update(len(name).to_bytes(8, "big"))
    h.update(name)
    h.update(len(body).to_bytes(8, "big"))
    h.update(body)
    total += len(body)
    t = r.split("/", 1)[0] if "/" in r else "(root files)"
    tops.setdefault(t, [0, 0])
    tops[t][0] += 1
    tops[t][1] += len(body)
out = {"root": root, "files": len(files), "bytes": total, "sha256": h.hexdigest(),
       "non_regular_entries": odd, "by_top_level": {k: {"files": v[0], "bytes": v[1]} for k, v in sorted(tops.items())}}
print(json.dumps({k: out[k] for k in ("files", "bytes", "sha256", "non_regular_entries")}))
if len(sys.argv) > 2:
    with open(sys.argv[2], "w") as f:
        json.dump(out, f, indent=1, sort_keys=True)
sys.exit(0 if not odd else 1)
