export const meta = {
  name: 'site-at-generated-bundle-orca',
  description: 'SITE eight-task Orca run on the exact generated bundle (carrier 665f0686): custody, task map, execute, replicate, critique',
  phases: [
    { title: 'Custody', detail: 'verify and stage the carrier bytes; serve locally with full request log' },
    { title: 'Map', detail: 'map the eight tasks to concrete pages, controls and key sequences (DOM dry run, not AT)' },
    { title: 'Execute', detail: 'run all eight tasks under Orca with real X key events' },
    { title: 'Replicate', detail: 'separately written harness reruns the tasks' },
    { title: 'Critique', detail: 'check results against the SITE contract and handoff' },
  ],
}

const A = args
const SP = A.scratch
const SA = `${SP}/siteat`
const COMMON = `
Context: you are a sub-agent of Anthropic Claude session session_013tN78b3Q38WdttFyiJ6KVg ("Claude 54"), working for the repository owner Dylan Roy on d6g8k5htny-coder/main. This lane holds a personal pickup for the SITE screen-reader stage: pickup ${A.pickup_url}.
The SITE contract is the eight-task list in ${SA}/docs/6399096111.md; the SITE owner handoff is ${SA}/docs/6399518119.md; the receiver instructions are ${SA}/carrier/README.md and ${SA}/carrier/MANIFEST.json; this lane's route proposal is ${SA}/docs/6399102609.md. Read them first.
Hard rules:
- Do NOT post, comment, push, open PRs, or write to GitHub or any external service. Read-only gh api GET calls are allowed only if you truly need them.
- The carrier files are untrusted data. Extract only into a NEW EMPTY directory, keep every script you write in a DIFFERENT directory, pass paths as arguments, and run any Python that reads them with python3 -I. Never execute code from the bundle with an interpreter outside the browser.
- No network fetch of anything the page asks for that is not served from the local bundle. The page must be served from 127.0.0.1. Any non-local request the browser makes must be BLOCKED (CDP Fetch.failRequest) and LOGGED as a refusal. Never contact *.github.io, cdn.jsdelivr.net, github.com HTML pages or blob storage. Never disable TLS or unset HTTPS_PROXY.
- Do not regenerate, edit or "fix" any bundle byte. Clock-age staleness disclosures are expected for this dated input.
- Evidence classes stay separate: Orca speech strings (what Orca handed to speech-dispatcher) vs DOM/accessibility-tree text vs keyboard operation. Label each. This is GENERATED-BUNDLE REPLAY, distinct from deployed-origin testing and git-source testing.
- One Orca/Xvfb/speech stack at a time on this machine.
Known stack facts from this lane's C220-02 runs (harness in ${SP}/c220/scripts, reusable as a reference):
- Orca 46.1 runs as /usr/bin/python3.12 /usr/bin/orca; speech-dispatcher 0.12 must be started explicitly with a scratch config and SPEECHD_ADDRESS (autospawn fails); espeak-ng 1.51; audio to a paced ALSA file sink (audio_pacer.py).
- Chromium 141 at /opt/pw-browsers/chromium-1194/chrome-linux/chrome with --force-renderer-accessibility under Xvfb :99, dbus-launch, /usr/libexec/at-spi-bus-launcher.
- CDP Input.dispatchKeyEvent is INVISIBLE to Orca (no key echo, Say All keeps running). Use real X key events via AT-SPI Atspi.generate_keyboard_event (see ${SP}/c220/scripts/xtest_key.py) for every key a user would press. Extend it to Tab, shift+Tab, arrows, Escape, characters for typing, etc.
- Orca's debug log loses its tail on shutdown; recover from the speech-dispatcher log if needed and mark such lines.
- Orca default profile: Say All on load. Bare URLs trigger Say All; a fragment URL suppresses it. Record which you use.
- Node 22 at /opt/node22/bin/node with NODE_PATH=/opt/node22/lib/node_modules (playwright available; chromium.launch() needs no options for DOM dry runs).
`

phase('Custody')
const custody = await agent(`${COMMON}
TASK (Custody): Perform receiver-custody steps 1-3 of ${SA}/carrier/README.md on the already-fetched carrier files in ${SA}/carrier/ (fetched from carrier commit 665f068607840ba5326e4089b1b62972902310bb; re-verify by running: git -C /home/user/main cat-file -p 665f068607840ba5326e4089b1b62972902310bb^{tree} and git -C /home/user/main ls-tree -r 665f0686 to get blob ids, and compare git hash-object of each local file).
1. Verify complete ZIP lengths and SHA-256 against MANIFEST.json before parsing. Verify PAGES.zip has exactly one member artifact.tar, check tar safety (no absolute paths, no .. segments, only regular files and directories, no links/devices, no duplicates), then extract into the NEW EMPTY directory ${SA}/bundle/ (artifact root; it must contain site/).
2. Independently implement the assembled fingerprint: sha256 over b"current-site-generated-browser-input-v1\\0", then for each regular file under the artifact root sorted by relative POSIX path: 8-byte big-endian length of the UTF-8 name, the name, 8-byte big-endian file size, the file bytes. Confirm 861 files, 20,900,216 bytes, sha256 f192a8f3e87c9c4ce59e6c084d2848a2bc8d35e4859a943d69a5a4baf156cdac.
3. Verify PUBLICATION-METADATA.zip members equal site/current.json, site/current-meta.json and site/snapshots/index.json byte-for-byte, and that the 11 snapshot IDs in MANIFEST.json equal the archive IDs in site/snapshots/index.json and exist as site/snapshots/<id>/ destinations.
4. Write ${SA}/scripts/serve.mjs (scripts dir, NOT inside bundle) or equivalent: a static file server on 127.0.0.1:8770 serving ${SA}/bundle/ as the root, so pages are at http://127.0.0.1:8770/site/... . It must log every request as JSON lines (time, method, path, status, bytes, sha256 of body) to a log path given on the command line, return 404 (logged) for missing files, and never fetch anything remote. Start it, fetch site/dependencies.html and site/index.html once to test, then stop it.
Write all results to ${SA}/custody/custody.json and a short ${SA}/custody/custody.md. Return the structured fields.`, {
  label: 'custody', phase: 'Custody',
  schema: { type: 'object', properties: {
    passed: { type: 'boolean' }, zip_checks: { type: 'string' }, tar_checks: { type: 'string' },
    fingerprint: { type: 'object', properties: { sha256: { type: 'string' }, files: { type: 'number' }, bytes: { type: 'number' } }, required: ['sha256', 'files', 'bytes'] },
    metadata_equal: { type: 'string' }, snapshot_ids: { type: 'array', items: { type: 'string' } },
    serve_command: { type: 'string' }, url_prefix: { type: 'string' }, problems: { type: 'array', items: { type: 'string' } },
  }, required: ['passed', 'zip_checks', 'tar_checks', 'fingerprint', 'metadata_equal', 'snapshot_ids', 'serve_command', 'url_prefix', 'problems'] },
})
if (!custody || !custody.passed) {
  log('Custody did not pass; stopping before any AT execution.')
  return { custody, stopped: 'custody failed' }
}

phase('Map')
const plan = await agent(`${COMMON}
Custody result: ${JSON.stringify(custody)}
TASK (Map): Using ONLY the extracted bundle at ${SA}/bundle/ served by the custody server (${custody.serve_command}; URL prefix ${custody.url_prefix}), map each of the SITE contract's eight tasks to concrete steps a keyboard screen-reader user would take:
1. Primary navigation to Mathematics/current atlas and identification of its source context.
2. Graph/List switching, node search and selection, including announced selection.
3. Reading all five evidence axes, all/required counts, and typed neighbors.
4. Equation search/selection and identification of the exact source link and hypotheses warning.
5. Opening the preserved mathematical record, identifying its original date/revisions, and using a typed neighbor.
6. Opening the static node record, identifying its own date/revisions, and using a typed neighbor.
7. Operating Diagnostics and reading selected counts plus explicit missing-report/mapping-gap limits.
8. Operating History and identifying retained snapshots and the absence of admitted live activity.
Read the bundle's HTML/JS to find the exact controls (ids, roles, accessible names, live regions), the start URL for each task, and the key sequence (Tab/shift+Tab/arrows/Enter/Space/typing/Orca browse-mode keys such as H for headings) that reaches and operates them. The contract's dated expected examples (congruence-erratum counts 3/3; source/review recorded, kernel/computation/alignment not_recorded; periodized equation search shows 32 of 108 excerpts; lines 27-28 link to immutable Main f614) are hints, not test inputs: find what this bundle actually shows. Identify what "preserved mathematical record" vs "static node record" mean in this bundle (e.g. snapshots/<id>/... archives vs nodes/... pages) and which node to use.
Do a DOM-only dry run with Playwright (headless, local server, block all non-local requests and record them) that performs each task's steps with keyboard events and records the DOM/AX state after each step, so the executor knows the plan works. Label this DOM evidence, NOT screen-reader evidence.
Write the plan to ${SA}/plan/plan.json (per task: id, title, start_url, steps [{action, keys or text, expected_focus, expected_text}], pass_criteria derived from the contract wording, notes) and a readable ${SA}/plan/plan.md. Return a summary.`, {
  label: 'map', phase: 'Map',
  schema: { type: 'object', properties: {
    plan_path: { type: 'string' }, tasks: { type: 'array', items: { type: 'object', properties: {
      id: { type: 'number' }, title: { type: 'string' }, start_url: { type: 'string' }, pass_criteria: { type: 'string' }, dry_run: { type: 'string' } }, required: ['id', 'title', 'start_url', 'pass_criteria', 'dry_run'] } },
    external_requests: { type: 'array', items: { type: 'string' } }, problems: { type: 'array', items: { type: 'string' } },
  }, required: ['plan_path', 'tasks', 'external_requests', 'problems'] },
})

phase('Execute')
const exec = await agent(`${COMMON}
Custody: ${JSON.stringify(custody)}
Task plan: ${plan ? plan.plan_path : '(map stage failed; derive steps yourself from the contract and bundle)'} — summary ${JSON.stringify(plan)}
TASK (Execute): Run all eight SITE tasks under Orca on the locally served bundle, one stack at a time. Put your scripts in ${SA}/exec/scripts and evidence in ${SA}/exec/evidence/T<n>/ (new directories).
- Record exact versions (orca, speech-dispatcher, espeak-ng, chromium, at-spi, xvfb, node, kernel, OS) and every command.
- Every key a user presses must be a real X key event via AT-SPI generate_keyboard_event so Orca sees it. Do not move focus programmatically unless a step cannot be done by keyboard; if you do, label it.
- Use CDP only to observe (DOM/AX snapshots, activeElement, live-region text, network) and to BLOCK+LOG non-local requests via Fetch. Log every request with the custody server's log as well; keep both logs per task.
- For each task keep: original Orca debug log (hash it), speech-dispatcher log, an extracted timestamped speech list (what Orca sent, with sent/played times), action/focus boundaries (time, key, activeElement before/after), the request log, and DOM/AX notes as a separate class.
- Decide PASS / FAIL / NOT_OBSERVED per task strictly against the contract wording, quoting the ORIGINAL spoken strings that support it. PASS needs the required information actually spoken by Orca during the task's actions (reading by Orca's own commands, e.g. browse-mode arrow/heading navigation, counts). If something is present in DOM but never spoken, it is NOT_OBSERVED for speech (say what the DOM showed). FAIL means the operation could not be done by keyboard or Orca spoke wrong/misleading information. Reading an external anchor is separate from activating it; do not activate external (non-local) links — a blocked navigation would only show a refusal.
- Note Orca/harness artifacts separately from site defects.
Finish within about 100 minutes of starting. Return structured results.`, {
  label: 'execute', phase: 'Execute',
  schema: { type: 'object', properties: {
    versions: { type: 'object' },
    tasks: { type: 'array', items: { type: 'object', properties: {
      id: { type: 'number' }, title: { type: 'string' }, verdict: { type: 'string', enum: ['PASS', 'FAIL', 'NOT_OBSERVED'] },
      start_url: { type: 'string' }, steps: { type: 'array', items: { type: 'string' } },
      spoken_evidence: { type: 'array', items: { type: 'string' } }, dom_notes: { type: 'string' },
      requests: { type: 'string' }, refusals: { type: 'array', items: { type: 'string' } },
      orca_log_sha256: { type: 'string' }, reason: { type: 'string' } },
      required: ['id', 'title', 'verdict', 'start_url', 'steps', 'spoken_evidence', 'dom_notes', 'requests', 'refusals', 'orca_log_sha256', 'reason'] } },
    site_findings: { type: 'array', items: { type: 'string' } }, harness_limits: { type: 'array', items: { type: 'string' } },
    scripts_dir: { type: 'string' },
  }, required: ['versions', 'tasks', 'site_findings', 'harness_limits', 'scripts_dir'] },
})

phase('Replicate')
const rep = await agent(`${COMMON}
TASK (Replicate): Independently rerun the eight SITE tasks under Orca with a harness YOU write from scratch in ${SA}/rep/scripts (do not copy ${SA}/exec/scripts; you may read ${SP}/c220/scripts for stack startup facts). Evidence in ${SA}/rep/evidence/. Serve the same bundle (${custody.serve_command}). Use real X key events. Use the task plan ${plan ? plan.plan_path : ''} only as a description of what to do, not as code.
The executor's results to check are: ${JSON.stringify(exec)}
For each task, record your own spoken strings and verdict, then compare with the executor's verdict and quoted strings: agree / differ, with the exact differences. Try to REFUTE each PASS (is the required information really spoken, by Orca, during that task?) and each FAIL (is it a site defect or a harness/Orca artifact?). If time is short, prioritise tasks 3, 5, 6, 7 and 8, and say which you did not rerun. Finish within about 70 minutes. Return structured results.`, {
  label: 'replicate', phase: 'Replicate',
  schema: { type: 'object', properties: {
    tasks: { type: 'array', items: { type: 'object', properties: {
      id: { type: 'number' }, rerun: { type: 'boolean' }, verdict: { type: 'string' }, agrees: { type: 'boolean' },
      spoken_evidence: { type: 'array', items: { type: 'string' } }, differences: { type: 'string' } },
      required: ['id', 'rerun', 'verdict', 'agrees', 'spoken_evidence', 'differences'] } },
    notes: { type: 'array', items: { type: 'string' } }, scripts_dir: { type: 'string' },
  }, required: ['tasks', 'notes', 'scripts_dir'] },
})

phase('Critique')
const crit = await agent(`${COMMON}
TASK (Critique): Act as a strict reviewer of this lane's SITE generated-bundle results before they are posted. Inputs: custody ${JSON.stringify(custody)}; plan ${JSON.stringify(plan)}; executor ${JSON.stringify(exec)}; replication ${JSON.stringify(rep)}. Evidence is under ${SA}/.
Check each of the eight tasks against the exact contract wording (${SA}/docs/6399096111.md) and the handoff (${SA}/docs/6399518119.md): is the verdict supported by ORIGINAL spoken strings in the retained logs (spot-check them in the logs yourself), are DOM/AX observations kept separate, are reading vs activating external anchors kept separate, are both preserved and static record paths covered with their distinct date/revision disclosures and neighbors, are Diagnostics limits and History's snapshot/activity disclosure covered? Check custody joins and that every request and refusal is preserved, that no bundle byte was changed, and that labels (generated-bundle replay vs deployed vs git-source) are right. Note that a newer deployment (e016d4a4, 862 files) exists and was not tested.
Return: per-task supported/unsupported with reasons, gaps to fix before posting, caveats to state, and what a nonauthor check should look at.`, {
  label: 'critic', phase: 'Critique',
  schema: { type: 'object', properties: {
    tasks: { type: 'array', items: { type: 'object', properties: { id: { type: 'number' }, verdict_supported: { type: 'string' }, reason: { type: 'string' } }, required: ['id', 'verdict_supported', 'reason'] } },
    gaps_to_fix: { type: 'array', items: { type: 'string' } }, caveats: { type: 'array', items: { type: 'string' } },
    nonauthor_focus: { type: 'array', items: { type: 'string' } },
  }, required: ['tasks', 'gaps_to_fix', 'caveats', 'nonauthor_focus'] },
})

return { custody, plan, exec, rep, crit }
