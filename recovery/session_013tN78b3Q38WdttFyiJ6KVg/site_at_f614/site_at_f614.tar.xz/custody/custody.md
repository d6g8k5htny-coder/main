# SITE receiver custody: carrier 665f0686

**Evidence class:** GENERATED-BUNDLE REPLAY input custody. These are byte-level file checks only. No browser, Orca, speech or keyboard was used. Nothing here is DOM/AX or speech evidence, and the SITE spoken AT result stays NOT_OBSERVED.

**Result: PASS.** All 22 custody checks pass, plus the disk fingerprint and the server test. Problems: none. Full record: `custody.json`.

## Identities (kept separate)
- **Carrier.** Commit `665f068607840ba5326e4089b1b62972902310bb`, tree `221538bd…`, subtree `carrier/` `9e2bea73…` with 4 blobs. Its parent is Main `f61419d8…`.
- **Source.** Main `f61419d8de39b45b20832a760b90fffa82429ab9`, Math `c4eabc1a…`, observation 2026-10-25T14:27:24Z, run 40201937556/1.
- **Route.** Local git objects only. Each carrier file's `git hash-object` equals its `ls-tree` blob, and each file is cmp-identical to `git show 665f0686:carrier/<file>`. No network fetch or gh call was made.

## Step 1: ZIP and tar
- **Complete files, checked before parsing.**
  - PAGES.zip: 4,876,860 B, sha256 `557fd452…`, blob `871725e4…`.
  - PUBLICATION-METADATA.zip: 221,129 B, sha256 `5e4a6ff3…`, blob `59618f00…`.
  - Both equal MANIFEST.json, whose own sha256 is `4c41e229…`.
- **ZIP structure.**
  - Local data tiles exactly up to the central directory.
  - The EOCD is at the end of the file, with no comment.
  - CRCs check out.
  - PAGES.zip has one member, `artifact.tar`: 22,128,640 B, sha256 `6062f676…`, equal to the manifest.
- **Tar parsing.** My own raw-header parser and Python `tarfile` agree on all 908 members: 861 regular files and 47 directories, with 539 GNU `L` long-name headers. There are no pax headers.
- **Tar safety and closure.**
  - All names start with `./`. None is absolute, none has a `..` or empty segment, and there are no duplicates.
  - There are no links, devices or FIFOs.
  - Modes are 0600, 0644 and 0755, with no setuid, setgid or sticky bits.
  - The end marker is at offset 22,119,936, followed by 17 zero blocks. The trailing bytes are all zero.
- **Extraction.**
  - Files were written manually with O_EXCL|O_NOFOLLOW into a new `bundle/` that the script created. All 861 files were written.
  - The artifact root contains `site/`, plus `public-math/`, `retro/` and other top-level directories.
  - The script ran three times, and each run created `bundle/` fresh. Run 1 crashed in reporting code after extracting. Run 2 failed two extra joins because I had misread them. I deleted `bundle/` after each of those two runs. No bundle byte was ever edited.

## Step 2: assembled fingerprint (two independent computations)
- **From the in-memory tar members:** 861 files, 20,900,216 B, `f192a8f3e87c9c4ce59e6c084d2848a2bc8d35e4859a943d69a5a4baf156cdac`.
- **From a walk of the extracted disk tree (`fingerprint.py`, lstat, no links):** the same result. `site/` alone holds 696 files and 15,708,505 B.

## Step 3: metadata and snapshots
- **Site files.** The `current.json` (1,292,316 B), `current-meta.json` (322 B) and `snapshots/index.json` (162,148 B) members are byte-identical to the matching files under `site/`.
- **Extra member.** There is one extra member, `candidate.json` (1,694 B, `2de81876…`). It is not a site file. As a JSON value it equals MANIFEST.json's `publication_candidate`.
- **Bindings.** The publication_candidate's payload, metadata and manifest hashes bind those three site files. `index.current`, `current-meta.archive` and `eee261a6…` are consistent with each other.
- **Snapshot IDs.** The 11 MANIFEST snapshot IDs are exactly the 11 `archives[].id` in `site/snapshots/index.json`. None is missing on either side.
- **Snapshot destinations.** Each `site/snapshots/<id>/` exists and contains:
  - `archive.zip`, matching the index's bytes and sha256;
  - exactly the 52 listed static paths, with no unlisted files.
- **What the listed hashes cover.**
  - The index's `files[]` and `alias_files[]` hashes are hashes of the archive.zip members.
  - The served static HTML differs from those members only by `?site-release=<hex>` URL keys. All of it matches after I strip those keys with my own regex, which approximates `normalized_archive_bytes` in the source. The JSON files match exactly.
  - The current node pages under `site/nodes/` and the 50 current aliases match the same way.
- **Archive dates.** The archives were observed from 2026-10-13T12:34:29Z to 2026-10-24T00:43:16Z. Renderers: research-static-v1 for 2 archives, v2 for 9.

## Step 4: local server
- **Command:** `cd <siteat>/scripts && /opt/node22/bin/node <siteat>/scripts/serve.mjs <siteat>/bundle <LOG> 8770`
- **URL prefix:** `http://127.0.0.1:8770/site/`. The bundle root is served as `/`.
- **Behaviour.**
  - It uses only node builtins, binds loopback only and does no proxying.
  - Every request is logged as one JSON line: time, method, path, status, bytes and sha256 of the body sent.
  - A missing path gets a logged 404. Responses are sent with `Cache-Control: no-store`.
- **Test run (17:07:31Z to 17:07:48Z).**
  - `site/dependencies.html`: 200, 27,803 B, `eb037397…`.
  - `site/index.html`: 200, 18,786 B, `e3648a15…`.
  - Both bodies are cmp-identical to the bundle files.
  - A deliberate missing-path probe returned a logged 404 (14 B).
  - While running, the server held one socket, its listener. It was stopped with SIGTERM, and the port is now closed.
- **Blocking non-local requests.** Blocking them in the browser with CDP Fetch.failRequest belongs to the later replay stage.

## Limits
- This is custody only. It gives no accessibility result.
- This is generated-bundle replay input. It is distinct from deployed-origin testing and from git-source testing.
- Staleness disclosures in the pages are expected for this dated input. Nothing was regenerated.
