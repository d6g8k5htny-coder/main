# SITE screen-reader replay: eight-task key plan

Generated 2026-10-25T17:38:40Z by Claude 54 (session_013tN78b3Q38WdttFyiJ6KVg) for pickup https://github.com/d6g8k5htny-coder/main/issues/539#issuecomment-6400510700.

**Replay class:** GENERATED-BUNDLE REPLAY of carrier 665f068607840ba5326e4089b1b62972902310bb (Main f61419d8, Math c4eabc1a, observation 2026-10-25T14:27:24Z). Distinct from deployed-origin testing and from git-source testing.

**Status of this document.** This is a plan plus a DOM-only dry run. No screen reader ran, and nothing here is Orca speech evidence. SITE spoken AT remains NOT_OBSERVED.

## Evidence classes (keep them separate)

- **speech**: Orca speech strings: what Orca handed to speech-dispatcher, timestamped from the Orca debug log (tail recovered from the speech-dispatcher log if lost, with those lines marked). This is the only screen-reader evidence.
- **dom_ax**: DOM/accessibility-tree text and focus, from CDP probes (Runtime.evaluate on document.activeElement, Accessibility.getPartialAXTree). This is a separate class, and it is the only class this plan's dry run produced.
- **keyboard**: Keyboard operation: each real X key event sent through AT-SPI (keysym, ISO time), with DOM focus before and after it.

## Serving and environment

- Bundle: `/tmp/claude-0/-home-user-main/d5c985ca-97e5-58d8-a9d4-1e0a19065a22/scratchpad/siteat/bundle/` (861 files, 20900216 B, fingerprint `f192a8f3e87c9c4ce59e6c084d2848a2bc8d35e4859a943d69a5a4baf156cdac`)
- Serve: `cd /tmp/claude-0/-home-user-main/d5c985ca-97e5-58d8-a9d4-1e0a19065a22/scratchpad/siteat/scripts && /opt/node22/bin/node /tmp/claude-0/-home-user-main/d5c985ca-97e5-58d8-a9d4-1e0a19065a22/scratchpad/siteat/scripts/serve.mjs /tmp/claude-0/-home-user-main/d5c985ca-97e5-58d8-a9d4-1e0a19065a22/scratchpad/siteat/bundle <LOG_PATH.jsonl> 8770`
  - Start it as "(cd …/scripts && exec node serve.mjs …) &" so that $! is the node PID and SIGTERM reaches serve.mjs, which then logs {"event":"stopped"}. A plain "cd … && node … &" leaves node orphaned when the subshell is killed (seen in dry run 1).
- URL prefix: `http://127.0.0.1:8770/site/`
- browser: Chromium 141.0.7390.37 at /opt/pw-browsers/chromium-1194/chrome-linux/chrome, --force-renderer-accessibility, --window-size=1200,850 (viewport must stay wider than 720 px: below that the atlas switches to its mobile list/reader layout and every Tab count changes)
- network_block: CDP Fetch.enable {patterns:[{urlPattern:"*", requestStage:"Request"}]} on the page target BEFORE the first navigation; continue only origin http://127.0.0.1:8770; Fetch.failRequest(BlockedByClient) and log every other request as a refusal. No relays (the C220 raw.githubusercontent relay must NOT be reused).
- orca: Orca 46.1 under /usr/bin/python3.12, default profile. Checked here: nativeNavTriggersFocusMode=True, structNavTriggersFocusMode=False, caretNavTriggersFocusMode=False. PAGE_TAB, COMBO_BOX and ENTRY, plus focusable expandable elements (summary), are focus-mode widgets. Orca+a (Insert+a) toggles browse/focus mode. The modifier is Insert / KP_Insert (desktop layout).
- speech: speech-dispatcher 0.12 started explicitly with the C220 scratch config and SPEECHD_ADDRESS; espeak-ng 1.51; paced ALSA file sink. One stack at a time.
- Keys: Atspi.generate_keyboard_event(keysym, None, Atspi.KeySynthType.SYM) per key (extend c220/scripts/xtest_key.py). For modifier chords, press the modifier keycode with KeySynthType.PRESS, send the key, then KeySynthType.RELEASE. Keycodes come from "xmodmap -pke" under Xvfb :99; typical evdev values are Shift_L 50, Control_L 37, Alt_L 64, Insert 118, KP_Enter 104; verify them.
- Keysyms: Tab 0xff09, Return 0xff0d, Up 0xff52, Down 0xff54, Left 0xff51, Right 0xff53, Home 0xff50, KP_Enter 0xff8d, Insert 0xff63, Shift_L 0xffe1, Control_L 0xffe3, Alt_L 0xffe9, a-z 0x61-0x7a, 3 0x33
- CDP Input.dispatchKeyEvent is invisible to Orca (C220-02); use it only for DOM-only dry runs.

## Step protocol

- **boundaries**: For every step log: step id, ISO time the key was sent, keysym(s), DOM focus before/after (CDP probe), URL, live-region texts, and the speech strings until the next key.
- **waits**: After a key, wait for speech idle (no new speech-dispatcher message for 1.0 s, max 10 s). After typing, wait about 3 s for polite live regions. After a navigation, wait for the DOM readiness probe and then speech idle.
- **read_until**: action "read" means: press the key repeatedly, up to max, until the Orca speech since the step began contains the until-text after whitespace normalisation and ignoring punctuation that Orca may verbalise (· – →). Stop at max and mark the expectation unmet.
- **key_repeat**: action "key_repeat" means: press the key until the DOM focus predicate holds (checked by a CDP probe after each key), up to max. dry_run_count is the count measured in the DOM dry run.

## Node and records

- Node: `math.d1-component.congruence-erratum`. Typed neighbor: `math.uniform-matrix-cap-lifetime` (math.uniform-matrix-cap-lifetime → math.d1-component.congruence-erratum · reads_with_congruence_erratum · required: true (the only edge touching the node)). The contract's dated example node. This bundle shows counts 3/3, source/review recorded and kernel/computation/alignment not_recorded, and it has both a preserved and a static record plus a neighbor present in both.
- **preserved_mathematical_record**: http://127.0.0.1:8770/site/snapshots/eee261a6e4c075dfc5318a6b6daaa9b42e482d8b7f6ad9cc43a9d1e4e9d13fc5/nodes/math.d1-component.congruence-erratum.html — title "… · Historical mathematical dependency atlas", "Original source observation: 2026-10-24T00:43:16Z", original pins main 0899cf51675e2e0d053c2d82a7e954f814ca40ee / Math- 7d815a5dcfb875b551c21804165e6588cc73d3ab, "Immutable historical mathematical record · mathematical SHA-256 eee261a6e4c075dfc5318a6b6daaa9b42e482d8b7f6ad9cc43a9d1e4e9d13fc5". Reached from the atlas inspector link "Read the preserved mathematical record".
- **static_node_record**: http://127.0.0.1:8770/site/nodes/math.d1-component.congruence-erratum.html — title "… · Current research dependency atlas", "Pinned source observation: 2026-10-25T14:27:24Z", pins main f61419d8de39b45b20832a760b90fffa82429ab9 / Math- c4eabc1a917ba2c1b96fe4af425cf2a484877c03, plus a Resume block "As of 2026-10-25T14:27:24Z". Reached from the inspector link "Read the static node record".
- **not_to_confuse**: dependencies.html also contains the "Preserved 3 October dependency snapshot" (Claim dependency viewer, Math 7858329), a different and older viewer. It is not the preserved mathematical record of Task 5.

## Contract hints compared with this bundle

- congruence-erratum counts 3/3: matched: "Downstream nodes · all edges: 3. Downstream nodes · required edges: 3."
- source/review recorded; kernel/computation/alignment not_recorded: matched in the atlas inspector, the static record and the preserved record
- periodized equation search 32 of 108: matched: "32 matching excerpts of 108 acquired excerpts."
- lines 27–28 link to immutable Main f614: matched (DOM href): https://github.com/d6g8k5htny-coder/main/blob/f61419d8de39b45b20832a760b90fffa82429ab9/experiments/universality/periodized_gaussian_h0/PROOF.md#L27-L28

## Task 1: Primary navigation to Mathematics/current atlas and identification of its source context

- Start URL: `http://127.0.0.1:8770/site/index.html#main-content`
- Say All on load: suppressed (fragment URL #main-content; Chromium focuses main#main-content)
- Dry run: DOM-only dry run (run6): 8/8 referenced step checks OK (1.1, 1.2, 1.3, 1.4, 1.5).

| # | action | keys / text | repeat (max; dry-run count) | Orca mode | expected focus | expected speech / DOM | dry run |
|---|---|---|---|---|---|---|---|
| 1 | navigate | `http://127.0.0.1:8770/site/index.html#main-content` |  | browse | dom: main#main-content; ax: main | DOM: .current-state becomes "Verified source observation: 2026-10-25T14:27:24Z · stale. This observation is more than two hours old; check upstream sources." (role=status, may be announced) — Note: Record the page title Orca speaks ("The shape of randomness · Universal Law") and any status announcement. | OK 1.1 |
| 2 | key_repeat | shift+Tab | until DOM focus is nav[aria-label=Primary] a[href="dependencies.html#current-atlas"]; max 6; dry 3 | browse | ax: link "Mathematics" | "Cite" / "Reproduce" / "Mathematics" — Note: Order: Cite (Research tools), Reproduce, Mathematics (Primary navigation). | OK 1.2 |
| 3 | key | Return |  | browse (new page; fragment suppresses Say All) | dom: section#current-atlas; ax: region "Equations and dependency worktree" | "Equations and dependency worktree" — DOM: URL == http://127.0.0.1:8770/site/dependencies.html#current-atlas; title "Mathematics · Universal Law"; #atlas-status == "Source snapshot 2026-10-25T14:27:24Z · Math c4eabc1a · 49 nodes, 55 edges (42 required). Classifications are the graph's recorded values. No scientific status inferred." — Note: Live regions (#atlas-status polite, .current-state status) are filled after current.json verifies; capture any announcement they produce. | OK 1.3 |
| 4 | read | Down | until speech contains "Source snapshot 2026-10-25T14:27:24Z"; max 10 | browse |  | "Source snapshot 2026-10-25T14:27:24Z" / "Math c4eabc1a" / "49 nodes, 55 edges (42 required)" — Note: DOM reading order from the section: eyebrow, h1, intro, "Why observation and classification dates differ" link, then #atlas-status (5th block, 2 visual lines). | OK 1.4 |
| 5 | read | Down | until speech contains "0 explicit graph-to-artifact bindings"; max 5 | browse |  | "31 source-bearing metadata records; 0 explicit graph-to-artifact bindings" / "108 separately acquired equation excerpts" | OK 1.4 |
| 6 | read | shift+h | until speech contains "Current research sources"; max 3 | browse |  | "Current research sources" — Note: Previous heading before the atlas h1 (the two details in between are collapsed). | OK 1.5 |
| 7 | read | Down | until speech contains "Verified source observation: 2026-10-25T14:27:24Z"; max 4 | browse |  | "Verified source observation: 2026-10-25T14:27:24Z" / "stale" / "more than two hours old" — Note: Clock-age staleness is expected for this dated input; do not regenerate bytes. | OK 1.5 |
| 8 | read | Down | until speech contains "c4eabc1a917ba2c1b96fe4af425cf2a484877c03"; max 6 | browse |  | "main f61419d8de39b45b20832a760b90fffa82429ab9" / "Math- c4eabc1a917ba2c1b96fe4af425cf2a484877c03" — Note: These two are external github.com links: read only, never activated. | OK 1.5 |

**Pass criteria**

- **PASS**: Orca speech strings show the Primary-navigation "Mathematics" link reached by real keys and announced; after Return the Mathematics atlas (title "Mathematics · Universal Law" / region or heading "Equations and dependency worktree") is announced; and speech then identifies its source context: source snapshot observation 2026-10-25T14:27:24Z, Math c4eabc1a, 49 nodes / 55 edges (42 required), and the pinned identities main f61419d8de39b45b20832a760b90fffa82429ab9 / Math- c4eabc1a917ba2c1b96fe4af425cf2a484877c03 with the observation's clock-age disclosure (stale, more than two hours old).
- **FAIL**: The keys reach and activate the controls (DOM evidence) but speech omits, garbles or contradicts the link, the atlas identity or the source context, or Return lands somewhere else.
- **NOT_OBSERVED**: The stack did not capture speech for the step (Orca/speech-dispatcher failure, log tail lost without a speech-dispatcher recovery), or the keys could not be delivered as X events.

**Notes**

- Start URL uses a fragment, so Orca Say All on load is suppressed; record that.
- Source context here = the current atlas status line plus the "Current research sources" observation and pins; the "Why these dates differ" disclosure is optional extra context.

## Task 2: Graph/List switching, node search and selection, including announced selection

- Start URL: `http://127.0.0.1:8770/site/dependencies.html#current-atlas`
- Say All on load: suppressed (fragment URL)
- Chaining: May continue on the Task 1 end page (same URL); counts below are from a fresh load.
- Dry run: DOM-only dry run (run6): 13/13 referenced step checks OK (2.1, 2.10, 2.11, 2.12, 2.13, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9).

| # | action | keys / text | repeat (max; dry-run count) | Orca mode | expected focus | expected speech / DOM | dry run |
|---|---|---|---|---|---|---|---|
| 1 | navigate | `http://127.0.0.1:8770/site/dependencies.html#current-atlas` |  | browse | dom: section#current-atlas; ax: region "Equations and dependency worktree" | DOM: atlas ready; #atlas-view value "graph" | OK 2.1 |
| 2 | key_repeat | Tab | until DOM focus is input#atlas-search; max 8; dry 5 | focus (auto: entry) | ax: searchbox "Find in current graph" | "Find in current graph" | OK 2.2 |
| 3 | key | Tab |  | focus (auto: combo box) | ax: combobox "View" value "Graph" | "View" / "Graph" | OK 2.3 |
| 4 | key | Down |  | focus | ax: combobox "View" value "List" | "List" — DOM: #atlas-view.value=="list"; #atlas-list visible, #atlas-stage hidden; #atlas-toggle-view text "Switch to graph"; URL gains atlas-view=list — Note: Chromium on Linux changes a closed select on Down and fires change without opening the popup. If DOM value did not change, Orca kept browse mode: press Insert+a, then Down. | OK 2.4 |
| 5 | key_repeat | Tab | until DOM focus is button#atlas-toggle-view; max 12; dry 9 | browse | ax: button "Switch to graph" | "Switch to graph" — Note: Passes Expand one frontier, Collapse to focus, Reset view, Back, Forward, Return to focus, Zoom in, Zoom out (Previous/Next nodes are disabled and skipped). | OK 2.5 |
| 6 | key | Return |  | browse | ax: button "Switch to list" | "Switch to list" — DOM: #atlas-view.value=="graph"; #atlas-stage visible; button text "Switch to list"; focus kept on the button — Note: If Orca does not present the name change within 2 s, press KP_Enter (Orca Where Am I) once and record what it says. | OK 2.6 |
| 7 | key | Return |  | browse | ax: button "Switch to graph" | "Switch to graph" — DOM: #atlas-view.value=="list" — Note: Same KP_Enter fallback. | OK 2.7 |
| 8 | key_repeat | shift+Tab | until DOM focus is input#atlas-search; max 14; dry 10 | focus (auto: entry) | ax: searchbox "Find in current graph" | "Find in current graph" | OK 2.8 |
| 9 | type | `congruence` |  | focus | ax: searchbox "Find in current graph" value "congruence" | "2 displayed · 2 matching source nodes of 49 indexed source nodes" — DOM: #atlas-count (aria-live=polite) == "2 displayed · 2 matching source nodes of 49 indexed source nodes · 0 outside this page. ..."; list buttons [math.d1-component.congruence-erratum, math.uniform-matrix-cap-lifetime] — Note: One X key event per character (keysyms a-z). Wait about 3 s after the last key for the polite announcement. Intermediate counts may be announced as typing proceeds. | OK 2.9 |
| 10 | key_repeat | Tab | until DOM focus is the #atlas-list button whose first text is math.d1-component.congruence-erratum; max 14; dry 11 | browse | ax: button (toggle, pressed=false) "math.d1-component.congruence-erratum reading_rule_component · PROVED_REVIEWED Downstream nodes · all edges: 3 · required edges: 3" | "math.d1-component.congruence-erratum" / "not pressed" | OK 2.10 |
| 11 | key | Return |  | browse | dom: article#atlas-inspector; ax: article "Selected node source and five evidence axes" | "Selected node source and five evidence axes" — DOM: #atlas-inspector h3 == math.d1-component.congruence-erratum; list button aria-pressed="true"; URL atlas-node=math.d1-component.congruence-erratum&atlas-panel=evidence (pushState); breadcrumb "Navigation history: math.uniform-matrix-cap-lifetime → math.d1-component.congruence-erratum"; #atlas-count text unchanged — Note: This is the page's selection announcement: focus moves to the selected-node reader. | OK 2.11 |
| 12 | read | Down | until speech contains "required edges: 3"; max 8 | browse |  | "math.d1-component.congruence-erratum" / "Kind: reading_rule_component · Classification: PROVED_REVIEWED · D1" / "Downstream nodes · all edges: 3. Downstream nodes · required edges: 3." | OK 2.12 |
| 13 | key_repeat | shift+Tab | until DOM focus is the #atlas-list button math.d1-component.congruence-erratum; max 6; dry 4 | browse (passes the Evidence tab: focus mode, then back) | ax: button (toggle, pressed=true) "math.d1-component.congruence-erratum ..." | "math.d1-component.congruence-erratum" / "pressed" — Note: Path: Evidence tab panel, Evidence tab, the uniform-matrix-cap-lifetime list button, then the selected button. Confirms the selection is announced as a pressed state. | OK 2.13 |

**Pass criteria**

- **PASS**: Speech shows: the View combo box operated by real keys with the spoken value changing Graph to List; the "Switch to graph/list" button operated with the change perceivable in speech (name change, or Where Am I); typing "congruence" in "Find in current graph" yields a spoken result count (2 displayed · 2 matching source nodes of 49); the node button is reached and spoken with its name and not-pressed state; and on Return the selection is announced (focus to "Selected node source and five evidence axes" with the selected id, and/or pressed state on return to the button).
- **FAIL**: Any of these operate in DOM but are not spoken, are spoken wrongly, or the selection produces no announcement at all.
- **NOT_OBSERVED**: Speech capture failed for the relevant steps, or keys could not be delivered.

**Notes**

- Node choice: math.d1-component.congruence-erratum (the contract example). The search term "congruence" matches 2 nodes in this bundle.

## Task 3: Reading all five evidence axes, all/required counts, and typed neighbors

- Start URL: `http://127.0.0.1:8770/site/dependencies.html?atlas-node=math.d1-component.congruence-erratum#current-atlas`
- Say All on load: suppressed (fragment URL)
- Chaining: Or continue from Task 2 after its Return (focus already on #atlas-inspector) and skip steps 1-3.
- Dry run: DOM-only dry run (run6): 10/10 referenced step checks OK (3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7).

| # | action | keys / text | repeat (max; dry-run count) | Orca mode | expected focus | expected speech / DOM | dry run |
|---|---|---|---|---|---|---|---|
| 1 | navigate | `http://127.0.0.1:8770/site/dependencies.html?atlas-node=math.d1-component.congruence-erratum#current-atlas` |  | browse (fragment URL: Say All on load suppressed) | dom: section#current-atlas; ax: region "Equations and dependency worktree" | DOM: atlas ready: #atlas-search enabled, #atlas-status starts "Source snapshot", .current-state starts "Verified"; #atlas-inspector h3 == math.d1-component.congruence-erratum — Note: Harness navigation (CDP Page.navigate), not a user key. Wait for the DOM readiness probe, then for speech idle. | OK 3.1 |
| 2 | key_repeat | Tab | until DOM focus is button#atlas-focus "Return to focus"; max 16; dry 12 | browse | ax: button "Return to focus" | "Return to focus" — Note: Passes 4 links (Why observation..., Static node index..., Preserved 3 October..., Share...), the search entry, the View combo box and 5 toolbar buttons. Entry and combo box put Orca in focus mode automatically; the next Tab leaves it. | OK 3.2 |
| 3 | key | Return |  | browse | dom: article#atlas-inspector; ax: article "Selected node source and five evidence axes" | "Selected node source and five evidence axes" — DOM: document.activeElement is #atlas-inspector; URL gains atlas-panel=evidence | OK 3.3 |
| 4 | read | Down | until speech contains "required edges: 3"; max 8 | browse |  | "math.d1-component.congruence-erratum" / "Kind: reading_rule_component · Classification: PROVED_REVIEWED · D1" / "Downstream nodes · all edges: 3. Downstream nodes · required edges: 3." | OK 3.4 |
| 5 | read | h | until speech contains "Continuation"; max 8 | browse |  | "Resume this node" / "Recorded graph state" / "Recorded review record" / "Operational task state" / "Continuation" — Note: Inspector headings in order: h3 id, h4 Resume this node, h5 Recorded graph state, h5 Recorded review record, h5 Operational task state, h5 Continuation, h4 Consumes, h4 Consumed by. | OK 3.5 |
| 6 | read | Down | until speech contains "Alignment metadata not recorded"; max 22 | browse |  | "source" / "Source metadata recorded · recorded" / "review" / "Review metadata recorded · recorded" / "kernel" / "Kernel metadata not recorded · not_recorded" / "computation" / "Computation metadata not recorded · not_recorded" / "alignment" / "Alignment metadata not recorded · not_recorded" | OK 3.6 |
| 7 | read | h | until speech contains "Consumes"; max 3 | browse |  | "Consumes" | OK 3.7 |
| 8 | read | Down | until speech contains "No direct relation recorded"; max 3 | browse |  | "No direct relation recorded." | OK 3.7 |
| 9 | read | h | until speech contains "Consumed by"; max 3 | browse |  | "Consumed by" | OK 3.7 |
| 10 | read | Down | until speech contains "reads_with_congruence_erratum"; max 10 | browse |  | "math.uniform-matrix-cap-lifetime" / "candidate · PROVED_REVIEWED" / "all edges: 2 · required edges: 2" / "Required · reads_with_congruence_erratum · math.uniform-matrix-cap-lifetime → math.d1-component.congruence-erratum" | OK 3.7 |

**Pass criteria**

- **PASS**: Speech reads all five axes with their states (this bundle: source recorded, review recorded, kernel/computation/alignment not_recorded), both counts (all edges 3, required edges 3), and the typed neighbors with direction and type (Consumes: none recorded; Consumed by: math.uniform-matrix-cap-lifetime, Required, reads_with_congruence_erratum, uniform-matrix-cap-lifetime → congruence-erratum).
- **FAIL**: Any axis, count or neighbor type/direction is missing from speech or spoken with a different value than the DOM.
- **NOT_OBSERVED**: Speech capture failed, or the inspector could not be reached by keys.

**Notes**

- Dated contract example (3/3; source/review recorded; kernel/computation/alignment not_recorded) is matched by this bundle at Math c4eabc1a.

## Task 4: Equation search/selection and identification of the exact source link and hypotheses warning

- Start URL: `http://127.0.0.1:8770/site/dependencies.html#current-atlas`
- Say All on load: suppressed (fragment URL)
- Dry run: DOM-only dry run (run6): 8/8 referenced step checks OK (4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 4.7).

| # | action | keys / text | repeat (max; dry-run count) | Orca mode | expected focus | expected speech / DOM | dry run |
|---|---|---|---|---|---|---|---|
| 1 | navigate | `http://127.0.0.1:8770/site/dependencies.html#current-atlas` |  | browse | dom: section#current-atlas | DOM: atlas ready; #equation-select enabled | OK 4.1 |
| 2 | key_repeat | Tab | until DOM focus is input#equation-search; max 60; dry 38 | focus (auto: entry) | ax: searchbox "Find equation text or source" | "Find equation text or source" — Note: Long Tab path through the default graph neighborhood and inspector. Alternative, not DOM-verified: Orca "e" twice (next entry) then Insert+a to enter focus mode. | OK 4.2 |
| 3 | type | `periodized` |  | focus | ax: searchbox "Find equation text or source" value "periodized" | "32 matching excerpts of 108 acquired excerpts" — DOM: #equation-count (role=status) == "32 matching excerpts of 108 acquired excerpts. Search covers exact text and public source paths; no equation-to-node logical join is inferred." | OK 4.3 |
| 4 | key | Tab |  | focus (auto: combo box) | ax: combobox "Exact acquired equation excerpt" value "Choose a source equation excerpt" | "Exact acquired equation excerpt" | OK 4.4 |
| 5 | key | Down |  | focus | ax: combobox "Exact acquired equation excerpt" value "periodized_gaussian_h0/PROOF.md · lines 27–28" | "periodized_gaussian_h0/PROOF.md" / "lines 27–28" — DOM: select value "d6g8k5htny-coder/main:experiments/universality/periodized_gaussian_h0/PROOF.md:27-28"; #equation-content shows pre, link, identity/warning | OK 4.5 |
| 6 | key_repeat | Tab | until DOM focus is #equation-content a; max 4; dry 2 | browse | ax: link "Read exact source lines and surrounding hypotheses" | "Next excerpt" / "Read exact source lines and surrounding hypotheses" — Note: DO NOT press Return here. The link is external github.com: reading it and activating it are separate observations, and activation is not performed (any accidental activation must be failed by CDP Fetch and logged as a refusal). | OK 4.6 |
| 7 | read | Down | until speech contains "hypotheses and scope govern this equation"; max 6 | browse |  | "Acquired excerpt · d6g8k5htny-coder/main f61419d8de39b45b20832a760b90fffa82429ab9" / "lines 27–28" / "The surrounding proof's hypotheses and scope govern this equation; excerpt extraction is not theorem acceptance." | OK 4.7 |
| 8 | read (optional) | Up | until speech contains "K_24(z)"; max 6 | browse |  | "K_24(z)=sum_(j in Z^d) exp(-\|z+24j\|^2/2)" — Note: Optional: the excerpt text itself (pre). | OK 4.7 |

**Pass criteria**

- **PASS**: Speech shows the equation search operated by typing with the spoken result count (this bundle: 32 matching excerpts of 108 for "periodized"), the excerpt selected by keyboard (periodized_gaussian_h0/PROOF.md · lines 27–28), the link "Read exact source lines and surrounding hypotheses", the identity line naming d6g8k5htny-coder/main f61419d8de39b45b20832a760b90fffa82429ab9 lines 27–28, and the hypotheses warning sentence. The exact link target (https://github.com/d6g8k5htny-coder/main/blob/f61419d8de39b45b20832a760b90fffa82429ab9/experiments/universality/periodized_gaussian_h0/PROOF.md#L27-L28) is DOM evidence, reported separately.
- **FAIL**: Count, selected excerpt, link name, identity line or warning is not spoken or is spoken wrongly.
- **NOT_OBSERVED**: Speech capture failed. Link activation is NOT_OBSERVED by rule (external; not activated), which is reported separately and does not by itself fail the reading task.

**Notes**

- Dated contract example "32 of 108; lines 27–28 link to immutable Main f614" is matched by this bundle (commit f61419d8de39b45b20832a760b90fffa82429ab9).

## Task 5: Opening the preserved mathematical record, identifying its original date/revisions, and using a typed neighbor

- Start URL: `http://127.0.0.1:8770/site/dependencies.html?atlas-node=math.d1-component.congruence-erratum#current-atlas`
- Say All on load: suppressed on the atlas (fragment); ACTIVE on the preserved page and its neighbor (bare URLs reached by link)
- Chaining: Or continue from Task 3 with focus on #atlas-inspector and skip steps 1-3.
- Dry run: DOM-only dry run (run6): 14/14 referenced step checks OK (5.1, 5.2, 5.3, 5.4, 5.5, 5.6, 5.7).

| # | action | keys / text | repeat (max; dry-run count) | Orca mode | expected focus | expected speech / DOM | dry run |
|---|---|---|---|---|---|---|---|
| 1 | navigate | `http://127.0.0.1:8770/site/dependencies.html?atlas-node=math.d1-component.congruence-erratum#current-atlas` |  | browse (fragment URL: Say All on load suppressed) | dom: section#current-atlas; ax: region "Equations and dependency worktree" | DOM: atlas ready: #atlas-search enabled, #atlas-status starts "Source snapshot", .current-state starts "Verified"; #atlas-inspector h3 == math.d1-component.congruence-erratum — Note: Harness navigation (CDP Page.navigate), not a user key. Wait for the DOM readiness probe, then for speech idle. | OK 5.1 |
| 2 | key_repeat | Tab | until DOM focus is button#atlas-focus "Return to focus"; max 16; dry 12 | browse | ax: button "Return to focus" | "Return to focus" — Note: Passes 4 links (Why observation..., Static node index..., Preserved 3 October..., Share...), the search entry, the View combo box and 5 toolbar buttons. Entry and combo box put Orca in focus mode automatically; the next Tab leaves it. | OK 5.1 |
| 3 | key | Return |  | browse | dom: article#atlas-inspector; ax: article "Selected node source and five evidence axes" | "Selected node source and five evidence axes" — DOM: document.activeElement is #atlas-inspector; URL gains atlas-panel=evidence | OK 5.1 |
| 4 | key | Tab |  | browse | ax: link "Read the preserved mathematical record" | "Read the preserved mathematical record" — DOM: href == http://127.0.0.1:8770/site/snapshots/eee261a6e4c075dfc5318a6b6daaa9b42e482d8b7f6ad9cc43a9d1e4e9d13fc5/nodes/math.d1-component.congruence-erratum.html | OK 5.2 |
| 5 | key | Return |  | browse (bare URL: Orca Say All on load starts) | dom: body | "math.d1-component.congruence-erratum · Historical mathematical dependency atlas" — DOM: URL == http://127.0.0.1:8770/site/snapshots/eee261a6e4c075dfc5318a6b6daaa9b42e482d8b7f6ad9cc43a9d1e4e9d13fc5/nodes/math.d1-component.congruence-erratum.html; title "math.d1-component.congruence-erratum · Historical mathematical dependency atlas"; CSP script-src 'none' (no JS on this page) — Note: Wait for load plus about 3 s and keep whatever Say All speaks (it is speech evidence). Chromium also requests /favicon.ico, which is a local 404 "not in bundle"; preserve it as an absent resource. | OK 5.3 |
| 6 | key | ctrl+Home |  | browse |  |  — Note: Stops Say All and moves the caret to the top of the document. | not DOM-checkable |
| 7 | read | h | until speech contains "Historical mathematical material"; max 2 | browse |  | "Historical mathematical material" | OK 5.4 |
| 8 | read | Down | until speech contains "2026-10-24T00:43:16Z"; max 4 | browse |  | "Original source observation: 2026-10-24T00:43:16Z" | OK 5.4 |
| 9 | read | Down | until speech contains "7d815a5dcfb875b551c21804165e6588cc73d3ab"; max 6 | browse |  | "main 0899cf51675e2e0d053c2d82a7e954f814ca40ee" / "Math- 7d815a5dcfb875b551c21804165e6588cc73d3ab" — Note: External github.com links: read only. | OK 5.4 |
| 10 | read (optional) | Down | until speech contains "Immutable historical mathematical record"; max 30 | browse |  | "Immutable historical mathematical record · mathematical SHA-256 eee261a6e4c075dfc5318a6b6daaa9b42e482d8b7f6ad9cc43a9d1e4e9d13fc5" — Note: Optional: archive identity line. A 13-line references paragraph comes first. | OK 5.4 |
| 11 | read | h | until speech contains "Incoming required"; max 10 | browse |  | "Incoming required" — Note: Headings on this page: Historical mathematical material, h1 id, Independent evidence metadata axes, Source and recorded review references, Original node metadata, Typed neighbors, Outgoing required, Outgoing context, Incoming required (9th), Incoming context. Alternative: "3" (next level-3 heading) three times. | OK 5.5 |
| 12 | read | Down | until speech contains "reads_with_congruence_erratum"; max 3 | browse |  | "math.uniform-matrix-cap-lifetime" / "reads_with_congruence_erratum" / "math.uniform-matrix-cap-lifetime → math.d1-component.congruence-erratum" / "required: true" | OK 5.6 |
| 13 | read | shift+h | until speech contains "Incoming required"; max 2 | browse |  |  — Note: Returns the caret to the heading so that "k" lands on the neighbor link. | not DOM-checkable |
| 14 | key | k |  | browse | dom: a[href="math.uniform-matrix-cap-lifetime.html"]; ax: link "math.uniform-matrix-cap-lifetime" | "math.uniform-matrix-cap-lifetime" — DOM: DOM check before Return: document.activeElement must be the neighbor link (Orca grabs focus on links). Dry run verified that the first link after the "Incoming required" heading is that link. — Note: Fallback if DOM focus did not move: Tab until DOM focus is the neighbor link (dry run measured this count from the document start). | OK 5.6 |
| 15 | key | Return |  | browse (bare URL: Say All on load) | dom: body | "math.uniform-matrix-cap-lifetime · Historical mathematical dependency atlas" — DOM: URL == http://127.0.0.1:8770/site/snapshots/eee261a6e4c075dfc5318a6b6daaa9b42e482d8b7f6ad9cc43a9d1e4e9d13fc5/nodes/math.uniform-matrix-cap-lifetime.html; h1 == math.uniform-matrix-cap-lifetime | OK 5.7 |
| 16 | key | ctrl+Home |  | browse |  |  | not DOM-checkable |
| 17 | read | h | until speech contains "Historical mathematical material"; max 2 | browse |  | "Historical mathematical material" | not DOM-checkable |
| 18 | read | Down | until speech contains "2026-10-24T00:43:16Z"; max 4 | browse |  | "Original source observation: 2026-10-24T00:43:16Z" — Note: Preserved neighbor keeps the same archived observation. | OK 5.7 |
| 19 | read | h | until speech contains "math.uniform-matrix-cap-lifetime"; max 2 | browse |  | "math.uniform-matrix-cap-lifetime" | not DOM-checkable |

**Pass criteria**

- **PASS**: Speech shows "Read the preserved mathematical record" reached and activated; arrival on the preserved record (title or heading "Historical mathematical material" plus the node id); its original date 2026-10-24T00:43:16Z and original revisions main 0899cf51675e2e0d053c2d82a7e954f814ca40ee / Math- 7d815a5dcfb875b551c21804165e6588cc73d3ab (distinct from the current 2026-10-25T14:27:24Z, f61419d8 and c4eabc1a); the typed neighbor row (Incoming required · reads_with_congruence_erratum · required: true); and arrival on the preserved neighbor page math.uniform-matrix-cap-lifetime (Historical) with the same archived observation.
- **FAIL**: The preserved page is reached but its date/revisions or the neighbor are not spoken or are spoken wrongly, or the neighbor link lands on a non-preserved page.
- **NOT_OBSERVED**: Speech capture failed or the link could not be activated by keys.

**Notes**

- Preserved mathematical record = snapshots/eee261a6e4c075dfc5318a6b6daaa9b42e482d8b7f6ad9cc43a9d1e4e9d13fc5/nodes/math.d1-component.congruence-erratum.html (immutable archive eee261a6, archive_version 2, observed 2026-10-24T00:43:16Z). The atlas derives this link from the single archive link in #current-research.
- Not the "Preserved 3 October dependency snapshot" in the lower half of dependencies.html, which is a different, older viewer (Math 7858329).

## Task 6: Opening the static node record, identifying its own date/revisions, and using a typed neighbor

- Start URL: `http://127.0.0.1:8770/site/dependencies.html?atlas-node=math.d1-component.congruence-erratum#current-atlas`
- Say All on load: suppressed on the atlas (fragment); ACTIVE on the static page and its neighbor (bare URLs reached by link)
- Chaining: Or continue from Task 3 with focus on #atlas-inspector and skip steps 1-3.
- Dry run: DOM-only dry run (run6): 15/15 referenced step checks OK (6.1, 6.2, 6.3, 6.4, 6.5, 6.6, 6.7, 6.8).

| # | action | keys / text | repeat (max; dry-run count) | Orca mode | expected focus | expected speech / DOM | dry run |
|---|---|---|---|---|---|---|---|
| 1 | navigate | `http://127.0.0.1:8770/site/dependencies.html?atlas-node=math.d1-component.congruence-erratum#current-atlas` |  | browse (fragment URL: Say All on load suppressed) | dom: section#current-atlas; ax: region "Equations and dependency worktree" | DOM: atlas ready: #atlas-search enabled, #atlas-status starts "Source snapshot", .current-state starts "Verified"; #atlas-inspector h3 == math.d1-component.congruence-erratum — Note: Harness navigation (CDP Page.navigate), not a user key. Wait for the DOM readiness probe, then for speech idle. | OK 6.1 |
| 2 | key_repeat | Tab | until DOM focus is button#atlas-focus "Return to focus"; max 16; dry 12 | browse | ax: button "Return to focus" | "Return to focus" — Note: Passes 4 links (Why observation..., Static node index..., Preserved 3 October..., Share...), the search entry, the View combo box and 5 toolbar buttons. Entry and combo box put Orca in focus mode automatically; the next Tab leaves it. | OK 6.1 |
| 3 | key | Return |  | browse | dom: article#atlas-inspector; ax: article "Selected node source and five evidence axes" | "Selected node source and five evidence axes" — DOM: document.activeElement is #atlas-inspector; URL gains atlas-panel=evidence | OK 6.1 |
| 4 | key_repeat | Tab | until DOM focus is link "Read the static node record"; max 4; dry 2 | browse | ax: link "Read the static node record" | "Read the static node record" — DOM: href == http://127.0.0.1:8770/site/nodes/math.d1-component.congruence-erratum.html | OK 6.2 |
| 5 | key | Return |  | browse (bare URL: Orca Say All on load starts) | dom: body | "math.d1-component.congruence-erratum · Current research dependency atlas" — DOM: URL == http://127.0.0.1:8770/site/nodes/math.d1-component.congruence-erratum.html; title "math.d1-component.congruence-erratum · Current research dependency atlas"; CSP script-src 'none' (no JS on this page) — Note: Wait for load plus about 3 s and keep whatever Say All speaks (it is speech evidence). Chromium also requests /favicon.ico, which is a local 404 "not in bundle"; preserve it as an absent resource. | OK 6.3 |
| 6 | key | ctrl+Home |  | browse |  |  — Note: Stops Say All and moves the caret to the top of the document. | not DOM-checkable |
| 7 | read | h | until speech contains "Current research sources"; max 2 | browse |  | "Current research sources" | OK 6.4 |
| 8 | read | Down | until speech contains "2026-10-25T14:27:24Z"; max 4 | browse |  | "Pinned source observation: 2026-10-25T14:27:24Z" | OK 6.4 |
| 9 | read | Down | until speech contains "c4eabc1a917ba2c1b96fe4af425cf2a484877c03"; max 6 | browse |  | "main f61419d8de39b45b20832a760b90fffa82429ab9" / "Math- c4eabc1a917ba2c1b96fe4af425cf2a484877c03" — Note: External github.com links: read only. | OK 6.4 |
| 10 | read | h | until speech contains "Resume this node"; max 3 | browse |  | "Resume this node" | OK 6.5 |
| 11 | read | Down | until speech contains "As of 2026-10-25T14:27:24Z"; max 3 | browse |  | "As of 2026-10-25T14:27:24Z." | OK 6.5 |
| 12 | read | Down | until speech contains "main commit f61419d8de39b45b20832a760b90fffa82429ab9"; max 12 | browse |  | "Snapshot identity: graph d6g8k5htny-coder/Math- commit c4eabc1a917ba2c1b96fe4af425cf2a484877c03" / "main commit f61419d8de39b45b20832a760b90fffa82429ab9" | OK 6.5 |
| 13 | read | h | until speech contains "Incoming required"; max 14 | browse |  | "Incoming required" — Note: Headings: Current research sources, h1 id, Resume this node, Recorded graph state, Recorded review record, Operational task state, Continuation, Independent evidence metadata axes, Source and recorded review references, Original node metadata, Typed neighbors, Outgoing required, Outgoing context, Incoming required (14th), Incoming context. Alternative from "Resume this node": "3" seven times. | OK 6.6 |
| 14 | read | Down | until speech contains "reads_with_congruence_erratum"; max 3 | browse |  | "math.uniform-matrix-cap-lifetime" / "reads_with_congruence_erratum" / "math.uniform-matrix-cap-lifetime → math.d1-component.congruence-erratum" / "required: true" | OK 6.7 |
| 15 | read | shift+h | until speech contains "Incoming required"; max 2 | browse |  |  — Note: Returns the caret to the heading so that "k" lands on the neighbor link. | not DOM-checkable |
| 16 | key | k |  | browse | dom: a[href="math.uniform-matrix-cap-lifetime.html"]; ax: link "math.uniform-matrix-cap-lifetime" | "math.uniform-matrix-cap-lifetime" — DOM: DOM check before Return: document.activeElement must be the neighbor link (Orca grabs focus on links). Dry run verified that the first link after the "Incoming required" heading is that link. — Note: Fallback if DOM focus did not move: Tab until DOM focus is the neighbor link (dry run measured this count from the document start). | OK 6.7 |
| 17 | key | Return |  | browse (bare URL: Say All on load) | dom: body | "math.uniform-matrix-cap-lifetime · Current research dependency atlas" — DOM: URL == http://127.0.0.1:8770/site/nodes/math.uniform-matrix-cap-lifetime.html; h1 == math.uniform-matrix-cap-lifetime | OK 6.8 |
| 18 | key | ctrl+Home |  | browse |  |  | not DOM-checkable |
| 19 | read | h | until speech contains "Current research sources"; max 2 | browse |  | "Current research sources" | not DOM-checkable |
| 20 | read | Down | until speech contains "2026-10-25T14:27:24Z"; max 4 | browse |  | "Pinned source observation: 2026-10-25T14:27:24Z" — Note: Static neighbor keeps the current observation. | not DOM-checkable |
| 21 | read | h | until speech contains "math.uniform-matrix-cap-lifetime"; max 2 | browse |  | "math.uniform-matrix-cap-lifetime" | not DOM-checkable |

**Pass criteria**

- **PASS**: Speech shows "Read the static node record" reached and activated; arrival on the static record (title "… · Current research dependency atlas" or heading "Current research sources" plus the node id); its own date 2026-10-25T14:27:24Z (Pinned source observation and Resume "As of") and revisions main f61419d8de39b45b20832a760b90fffa82429ab9 / Math- c4eabc1a917ba2c1b96fe4af425cf2a484877c03; the typed neighbor row; and arrival on nodes/math.uniform-matrix-cap-lifetime.html (current, not snapshots/).
- **FAIL**: Date/revisions or neighbor not spoken or spoken wrongly, or the neighbor lands in the archive.
- **NOT_OBSERVED**: Speech capture failed or the link could not be activated by keys.

**Notes**

- Static node record = nodes/math.d1-component.congruence-erratum.html (current observation alias). It has no JavaScript (CSP script-src 'none'), so it prints "Compare this timestamp with the present time" instead of a computed stale state.

## Task 7: Operating Diagnostics and reading selected counts plus explicit missing-report/mapping-gap limits

- Start URL: `http://127.0.0.1:8770/site/dependencies.html?atlas-node=math.d1-component.congruence-erratum#current-atlas`
- Say All on load: suppressed (fragment URL)
- Chaining: Or continue from Task 3 with focus on #atlas-inspector and skip steps 1-3.
- Dry run: DOM-only dry run (run6): 14/14 referenced step checks OK (7.1, 7.2, 7.3, 7.4, 7.5, 7.6, 7.7, 7.8, 7.9).

| # | action | keys / text | repeat (max; dry-run count) | Orca mode | expected focus | expected speech / DOM | dry run |
|---|---|---|---|---|---|---|---|
| 1 | navigate | `http://127.0.0.1:8770/site/dependencies.html?atlas-node=math.d1-component.congruence-erratum#current-atlas` |  | browse (fragment URL: Say All on load suppressed) | dom: section#current-atlas; ax: region "Equations and dependency worktree" | DOM: atlas ready: #atlas-search enabled, #atlas-status starts "Source snapshot", .current-state starts "Verified"; #atlas-inspector h3 == math.d1-component.congruence-erratum — Note: Harness navigation (CDP Page.navigate), not a user key. Wait for the DOM readiness probe, then for speech idle. | OK 7.1 |
| 2 | key_repeat | Tab | until DOM focus is button#atlas-focus "Return to focus"; max 16; dry 12 | browse | ax: button "Return to focus" | "Return to focus" — Note: Passes 4 links (Why observation..., Static node index..., Preserved 3 October..., Share...), the search entry, the View combo box and 5 toolbar buttons. Entry and combo box put Orca in focus mode automatically; the next Tab leaves it. | OK 7.1 |
| 3 | key | Return |  | browse | dom: article#atlas-inspector; ax: article "Selected node source and five evidence axes" | "Selected node source and five evidence axes" — DOM: document.activeElement is #atlas-inspector; URL gains atlas-panel=evidence | OK 7.1 |
| 4 | key_repeat | shift+Tab | until DOM focus is button#atlas-tab-evidence (role tab); max 4; dry 2 | focus (auto: page tab) | ax: tab "Evidence" selected | "Evidence" — Note: First shift+Tab lands on the Evidence tab panel, the second on the Evidence tab. | OK 7.2 |
| 5 | key | Right |  | focus | dom: button#atlas-tab-diagnostics; ax: tab "Diagnostics" not selected | "Diagnostics" — Note: Manual-activation tabs: arrows move focus only. If DOM focus stayed on Evidence, Orca was in browse mode: press Insert+a and repeat Right. | OK 7.3 |
| 6 | key | Return |  | focus | ax: tab "Diagnostics" selected | "Diagnostics" — DOM: aria-selected="true"; #atlas-panel-diagnostics visible; evidence panel hidden; URL atlas-panel=diagnostics | OK 7.4 |
| 7 | key_repeat | Tab | until DOM focus is summary "Snapshot diagnostics and mapping gaps"; max 4; dry 2 | focus (auto: expandable) | ax: DisclosureTriangle "Snapshot diagnostics and mapping gaps" expanded=false | "Diagnostics" / "Snapshot diagnostics and mapping gaps" / "collapsed" | OK 7.5 |
| 8 | key | Return |  | focus | ax: DisclosureTriangle expanded=true | "expanded" | OK 7.6 |
| 9 | key | Tab |  | browse | ax: button "eng.d0-packet-allowlist-fix: no explicit graph-to-artifact binding; roles/custody unknown" | "eng.d0-packet-allowlist-fix: no explicit graph-to-artifact binding; roles/custody unknown" | OK 7.7 |
| 10 | read | Up | until speech contains "Diagnostic report unavailable in this source projection"; max 5 | browse |  | "Diagnostic report unavailable in this source projection. Engineering generation checks are separate from mathematical evidence." | OK 7.8 |
| 11 | read | Up | until speech contains "Selected math.d1-component.congruence-erratum"; max 5 | browse |  | "Selected math.d1-component.congruence-erratum: Downstream nodes · all edges: 3." | OK 7.8 |
| 12 | read | Down | until speech contains "No scientific disposition is inferred"; max 4 | browse |  | "Downstream nodes · required edges: 3." / "No scientific disposition is inferred." | OK 7.8 |
| 13 | read | Down | until speech contains "source metadata not recorded"; max 18 | browse |  | "eng.hard-gate: no explicit graph-to-artifact binding; roles/custody unknown" / "hist.ALLCELL-FDZ-Q4: no explicit graph-to-artifact binding; roles/custody unknown" / "source metadata not recorded" — Note: 18 of the 49 node rows carry "· source metadata not recorded". | OK 7.8 |
| 14 | read (optional) | b | until speech contains "math.d1-component.congruence-erratum: no explicit graph-to-artifact binding"; max 20 | browse |  | "math.d1-component.congruence-erratum: no explicit graph-to-artifact binding; roles/custody unknown" — Note: Optional: the selected node's own mapping-gap row. | OK 7.9 |

**Pass criteria**

- **PASS**: Speech shows the Diagnostics tab reached and activated by keys and the "Snapshot diagnostics and mapping gaps" disclosure expanded, then reads (a) the selected counts "Selected math.d1-component.congruence-erratum: Downstream nodes · all edges: 3. Downstream nodes · required edges: 3. No scientific disposition is inferred.", (b) the explicit missing-report limit "Diagnostic report unavailable in this source projection. Engineering generation checks are separate from mathematical evidence.", and (c) at least one mapping-gap statement ("…: no explicit graph-to-artifact binding; roles/custody unknown") plus one "· source metadata not recorded". Reading the stated missing report satisfies the reading task; no report content is invented.
- **FAIL**: The tab or disclosure cannot be operated by keys, or the counts or limits are missing from speech or misreported.
- **NOT_OBSERVED**: Speech capture failed.

**Notes**

- "Diagnostics" = the role=tab "Diagnostics" in the selected-node reader (atlas-shell.mjs), whose panel holds the "Snapshot diagnostics and mapping gaps" details moved there at runtime.

## Task 8: Operating History and identifying retained snapshots and the absence of admitted live activity

- Start URL: `http://127.0.0.1:8770/site/dependencies.html#current-atlas`
- Say All on load: suppressed (fragment URL)
- Dry run: DOM-only dry run (run6): 11/11 referenced step checks OK (8.1, 8.2, 8.3, 8.4, 8.5, 8.6, 8.7, 8.8, 8.9).

| # | action | keys / text | repeat (max; dry-run count) | Orca mode | expected focus | expected speech / DOM | dry run |
|---|---|---|---|---|---|---|---|
| 1 | navigate | `http://127.0.0.1:8770/site/dependencies.html#current-atlas` |  | browse | dom: section#current-atlas | DOM: atlas ready | OK 8.1 |
| 2 | read | Up | until speech contains "History capacity: 11 of 512 mathematical archives"; max 5 | browse |  | "History capacity: 11 of 512 mathematical archives" — Note: The capacity paragraph is the last block of #current-research, immediately before the atlas section. | OK 8.2 |
| 3 | read | Down | until speech contains "no history is pruned"; max 4 | browse |  | "Publication refuses additional versions at capacity; no history is pruned." | OK 8.2 |
| 4 | key_repeat | Tab | until DOM focus is summary "History and activity"; max 60; dry 41 | focus (auto: expandable) | ax: DisclosureTriangle "History and activity" expanded=false | "History and activity" / "collapsed" — Note: Long Tab path (graph neighborhood, inspector, equation controls). The diagnostics summary is in the hidden Diagnostics panel and is skipped. | OK 8.3 |
| 5 | key | Return |  | focus | ax: DisclosureTriangle expanded=true | "expanded" | OK 8.4 |
| 6 | key | Tab |  | browse | ax: link "published snapshot manifest" | "published snapshot manifest" — DOM: href == http://127.0.0.1:8770/site/snapshots/index.json (local) | OK 8.5 |
| 7 | read | Up | until speech contains "This view selects one current source snapshot"; max 4 | browse |  | "This view selects one current source snapshot." | OK 8.6 |
| 8 | read | Down | until speech contains "no live presence, assignment or review activity is inferred"; max 6 | browse |  | "the published snapshot manifest identifies the retained population" / "No activity report is admitted in this projection; no live presence, assignment or review activity is inferred." | OK 8.6 |
| 9 | key (optional) | Return |  | browse (bare URL: Say All on JSON text) | dom: body | DOM: URL == http://127.0.0.1:8770/site/snapshots/index.json; JSON archives[] has 11 ids (7c583e28 … eee261a6), capacity.snapshots 11, current eee261a6… — Note: Optional, local only. Before pressing Return, re-check DOM focus is still on the manifest link (Up/Down may have moved it); if not, Tab until it. Interrupt Say All with ctrl+Home after about 5 s. The JSON field "origin" names a github.io URL as text only: nothing is fetched. | OK 8.7 |
| 10 | key (optional) | alt+Left |  | browse |  | DOM: back on dependencies.html — Note: Browser-UI accelerator. The headless dry run could not deliver it as a CDP key and used page.goBack(); the real run must send it as an X key event. | OK 8.8 |
| 11 | keys (optional) | SUPPLEMENTARY: from STATE URL: Tab x12, Return; Tab until inspector button math.uniform-matrix-cap-lifetime, Return; shift+Tab until #atlas-back, Return; Tab until #atlas-forward, Return |  | browse |  | DOM: After Back: selection math.d1-component.congruence-erratum restored and DOM focus on section#current-atlas. After Forward: selection math.uniform-matrix-cap-lifetime and focus on #atlas-inspector. — Note: Navigation-history Back/Forward of the atlas. Supplementary to, not part of, the History disclosure observation. | OK 8.9 |

**Pass criteria**

- **PASS**: Speech shows the "History and activity" disclosure reached and expanded by keys and its text read, including that the published snapshot manifest identifies the retained population and "No activity report is admitted in this projection; no live presence, assignment or review activity is inferred."; and the retained snapshots identified by the spoken "History capacity: 11 of 512 mathematical archives … no history is pruned." (DOM: the manifest lists the same 11 archive ids as custody).
- **FAIL**: The disclosure cannot be operated, or the activity-absence statement or the retained-snapshot count is missing from speech or misreported.
- **NOT_OBSERVED**: Speech capture failed.

**Notes**

- "History" = the "History and activity" details in the atlas. In readable HTML, the retained snapshots are given only as the capacity count plus the link to snapshots/index.json, which is JSON; speech can identify the count, not each id.
- The atlas Back/Forward buttons are navigation history (supplementary observation 8.9).

## Dry run

- Class: DOM/AX ONLY (Playwright CDP key events, headless). NOT screen-reader evidence. NOT Orca speech.
- Versions: Chromium 141.0.7390.37, Playwright 1.56.1, Node v22.22.2, viewport 1200x760
- Result file: `/tmp/claude-0/-home-user-main/d5c985ca-97e5-58d8-a9d4-1e0a19065a22/scratchpad/siteat/plan/dryrun/run6/dryrun-result.json`
- Per-section summary: T1 5/5; T2 13/13; T3 7/7; T4 7/7; T5 7/7; T6 8/8; T7 9/9; T8 9/9; T9 1/1 (T9 = harness self-test)
- Network: run6: 217 server requests, all from 127.0.0.1, 216 x 200 with served sha256 equal to the bundle file bytes, 1 x 404 /favicon.ico ("not in bundle", browser-initiated on the static, preserved and JSON pages). Zero non-local requests from the site. One deliberate harness self-test navigation to http://refusal-canary.invalid/ was failed by Fetch.failRequest(BlockedByClient) and logged.
- Not validated: Orca browse-mode keys (h, shift+h, k, b, Up/Down line reading, ctrl+Home, Insert+a, KP_Enter), Say All behaviour, live-region speech and X key delivery. Only DOM reading order and DOM targets were checked for those steps.
- Runs: run1: all 8 tasks OK except the optional alt+Left (a CDP key cannot reach the browser UI); the server PID was the subshell (node orphaned, then stopped by PID); run2/run3: supplementary Back/Forward step wrong in my script: after atlas Back the page moves focus to section#current-atlas, so Tab then hit an inspector link and navigated (debug trace in debug-backforward/); run4: probe crashed on the canary error page (fixed with a retry); run5: all OK; run6: final: all 66 steps OK, plus pressed-state and first-link-after-heading checks

## Problems and limits

- DOM dry run only: no Orca, Xvfb, AT-SPI or speech ran. No screen-reader result is implied; SITE spoken AT remains NOT_OBSERVED until the executor run.
- Browse-mode line counts depend on Orca line segmentation and the 1200 px layout; the plan therefore uses read-until loops with max bounds rather than fixed Down counts.
- Tab counts depend on the default graph neighborhood (math.uniform-matrix-cap-lifetime) and the viewport; re-measure with the DOM focus predicate rather than trusting the counts blindly.
- Retained snapshot ids are not listed in readable HTML; speech can confirm the count (11 of 512) and the current archive id on preserved pages, while the id list is DOM/JSON evidence.
- Interpretation: "Operating Diagnostics" = the Diagnostics tab plus its disclosure; "Operating History" = the "History and activity" disclosure (atlas Back/Forward is recorded as supplementary).
- External anchors (github.com pins, sources, the equation source link) are read, never activated. Activation is NOT_OBSERVED by rule.
- /favicon.ico is absent from the bundle (local 404) and must be preserved as absent, not synthesized.
