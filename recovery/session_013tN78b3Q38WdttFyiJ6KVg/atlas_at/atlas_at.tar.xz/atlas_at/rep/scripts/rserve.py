#!/usr/bin/python3.12
"""Replicator static server (written for ATLAS-AT replication; not derived from the executor's serve.mjs).

usage: python3.12 -I rserve.py SITE_DIR PORT REQUEST_LOG.jsonl
Binds 127.0.0.1 only, serves files under SITE_DIR read-only, logs every request as one JSON line.
"""
import json
import os
import sys
import time
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

SITE, PORT, LOG = os.path.realpath(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
LOGF = open(LOG, "a", buffering=1, encoding="utf-8")

TYPES = {
    ".html": "text/html; charset=utf-8",
    ".mjs": "text/javascript; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".ico": "image/x-icon",
    ".txt": "text/plain; charset=utf-8",
    ".md": "text/plain; charset=utf-8",
    ".woff2": "font/woff2",
}


class Handler(SimpleHTTPRequestHandler):
    extensions_map = {**SimpleHTTPRequestHandler.extensions_map, **TYPES}

    def __init__(self, *a, **kw):
        super().__init__(*a, directory=SITE, **kw)

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def do_POST(self):
        self.send_error(405)

    def log_request(self, code="-", size="-"):
        rec = {
            "t": round(time.time(), 6),
            "client": self.client_address[0],
            "method": self.command,
            "path": self.path,
            "status": int(code) if str(code).isdigit() else str(code),
            "size": size,
            "ua": self.headers.get("User-Agent", "") if self.headers else "",
        }
        LOGF.write(json.dumps(rec) + "\n")

    def log_message(self, fmt, *args):
        sys.stderr.write("%s %s\n" % (time.strftime("%H:%M:%S"), fmt % args))


if __name__ == "__main__":
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    sys.stderr.write(f"rserve: {SITE} on http://127.0.0.1:{PORT}/ log {LOG}\n")
    sys.stderr.flush()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
