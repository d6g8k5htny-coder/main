// Replicator driver for ATLAS-AT (written independently of the executor's drive.mjs).
// usage: node rdrive.mjs RUN OUT CDP_PORT ORIGIN KEYD_PY
// CDP is used ONLY to (a) block every request that is not to ORIGIN (Fetch.failRequest),
// (b) navigate once to ORIGIN/dependencies.html, (c) read DOM state. No CDP input events.
// Every key goes through keyd.py (Atspi.generate_keyboard_event, real X key events).
import { spawn } from 'node:child_process';
import http from 'node:http';
import fs from 'node:fs';
import readline from 'node:readline';

const [RUN, OUT, CDP_PORT, ORIGIN, KEYD] = process.argv.slice(2);
const evFd = fs.openSync(`${OUT}/driver-events.jsonl`, 'a');
const fetchFd = fs.openSync(`${OUT}/cdp-fetch.jsonl`, 'a');
const now = () => Date.now() / 1000;
const rec = (o) => fs.writeSync(evFd, JSON.stringify({ t: now(), run: RUN, ...o }) + '\n');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
setTimeout(() => { rec({ ev: 'watchdog', note: 'driver exceeded 9 min' }); process.exit(3); }, 9 * 60 * 1000).unref();

function getJSON(path) {
  return new Promise((res, rej) => {
    http.get({ host: '127.0.0.1', port: Number(CDP_PORT), path }, (r) => {
      let b = ''; r.on('data', (d) => (b += d)); r.on('end', () => { try { res(JSON.parse(b)); } catch (e) { rej(e); } });
    }).on('error', rej);
  });
}

// ---- minimal CDP client (flattened sessions) ----
let seq = 0; const pending = new Map(); let ws;
function send(method, params = {}, sessionId) {
  const id = ++seq; const m = { id, method, params }; if (sessionId) m.sessionId = sessionId;
  ws.send(JSON.stringify(m));
  return new Promise((res, rej) => {
    const to = setTimeout(() => { pending.delete(id); rej(new Error(`timeout ${method}`)); }, 20000);
    pending.set(id, { res: (v) => { clearTimeout(to); res(v); }, rej: (e) => { clearTimeout(to); rej(e); } });
  });
}
let pageSession = null; let pageResolve; const pageReady = new Promise((r) => (pageResolve = r));
const AUTO = { autoAttach: true, waitForDebuggerOnStart: true, flatten: true };
async function onEvent(msg) {
  if (msg.method === 'Fetch.requestPaused') {
    const { requestId, request, resourceType } = msg.params; const u = request.url; let allow = false;
    try { allow = new URL(u).origin === ORIGIN; } catch { allow = false; }
    fs.writeSync(fetchFd, JSON.stringify({ t: now(), session: msg.sessionId || null, method: request.method, url: u, type: resourceType, decision: allow ? 'continue' : 'failRequest(BlockedByClient)' }) + '\n');
    try {
      if (allow) await send('Fetch.continueRequest', { requestId }, msg.sessionId);
      else await send('Fetch.failRequest', { requestId, errorReason: 'BlockedByClient' }, msg.sessionId);
    } catch (e) { rec({ ev: 'fetch_error', url: u, error: String(e) }); }
  } else if (msg.method === 'Target.attachedToTarget') {
    const { sessionId, targetInfo, waitingForDebugger } = msg.params;
    rec({ ev: 'attached', type: targetInfo.type, url: targetInfo.url, sessionId, waitingForDebugger });
    try { await send('Fetch.enable', { patterns: [{ urlPattern: '*', requestStage: 'Request' }] }, sessionId); rec({ ev: 'fetch_enabled', sessionId, type: targetInfo.type }); }
    catch (e) { rec({ ev: 'fetch_enable_failed', sessionId, type: targetInfo.type, error: String(e) }); }
    try { await send('Target.setAutoAttach', AUTO, sessionId); } catch (e) { rec({ ev: 'autoattach_failed', sessionId, error: String(e) }); }
    if (waitingForDebugger) { try { await send('Runtime.runIfWaitingForDebugger', {}, sessionId); } catch (e) { rec({ ev: 'resume_failed', sessionId, error: String(e) }); } }
    if (targetInfo.type === 'page' && !pageSession) { pageSession = sessionId; pageResolve(sessionId); }
  }
}

// ---- key daemon ----
const kd = spawn('/usr/bin/python3.12', ['-I', KEYD], { stdio: ['pipe', 'pipe', 'pipe'] });
kd.stderr.on('data', (d) => rec({ ev: 'keyd_stderr', text: String(d) }));
const kdLines = readline.createInterface({ input: kd.stdout }); const kdQueue = [];
kdLines.on('line', (l) => { const r = kdQueue.shift(); if (r) { try { r(JSON.parse(l)); } catch (e) { r({ ok: false, error: 'bad json ' + l }); } } });
function keyd(cmd) { return new Promise((res) => { kdQueue.push(res); kd.stdin.write(JSON.stringify(cmd) + '\n'); }); }

// ---- DOM observation ----
async function evalJS(expr) {
  const r = await send('Runtime.evaluate', { expression: expr, returnByValue: true }, pageSession);
  if (r.exceptionDetails) return { error: r.exceptionDetails.text };
  return r.result.value;
}
const WHERE = `(()=>{const s=getSelection();const n=s&&s.anchorNode;const el=n?(n.nodeType===1?n:n.parentElement):null;
const ae=document.activeElement;const idd=(e)=>e?(e.id?('#'+e.id):e.tagName.toLowerCase()):null;
return {sel_el: idd(el), sel_near_id: el&&el.closest('[id]')?('#'+el.closest('[id]').id):null,
 sel_in_status: !!(el&&el.closest('#atlas-status')), sel_text: n?String(n.textContent||'').slice(0,80):null,
 sel_offset: s?s.anchorOffset:null, active: idd(ae), hasFocus: document.hasFocus()};})()`;
const DOMSTATE = `(()=>{const g=(i)=>{const e=document.getElementById(i);return e?e.textContent:null};
const v=document.getElementById('atlas-view');const q=document.getElementById('atlas-search');
const cd=document.getElementById('atlas-count');
return {atlas_status: g('atlas-status'), atlas_count: g('atlas-count'),
 atlas_count_details_open: cd&&cd.closest('details')?cd.closest('details').open:null,
 search_value: q?q.value:null, view_value: v?v.value:null, view_selectedIndex: v?v.selectedIndex:null,
 view_disabled: v?v.disabled:null, view_options: v?[...v.options].map(o=>({text:o.text,value:o.value,disabled:o.disabled,selected:o.selected})):null,
 url: location.href, title: document.title};})()`;
const STRUCT = `(()=>{const a=document.getElementById('atlas-status');return {status_outer: a?a.outerHTML.slice(0,700):null,
 status_parent_outer_head: a?a.parentElement.outerHTML.slice(0,240):null,
 status_role: a?a.getAttribute('role'):null, parent_role: a?a.parentElement.getAttribute('role'):null};})()`;

function sinkSince(t0) {
  try {
    return fs.readFileSync(`${OUT}/sink.jsonl`, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l)).filter((r) => r.t >= t0);
  } catch { return []; }
}

// Orca's debug log is block-buffered but very verbose: when it stops growing, Orca is idle.
const ORCALOG = `${OUT}/orca-debug.txt`;
const logSize = () => { try { return fs.statSync(ORCALOG).size; } catch { return -1; } };
async function waitQuiet(minMs, quietMs, maxMs) {
  const start = Date.now(); let last = logSize(); let lastChange = Date.now();
  for (;;) {
    await sleep(200);
    const sz = logSize(); if (sz !== last) { last = sz; lastChange = Date.now(); }
    const el = Date.now() - start;
    if (el >= minMs && Date.now() - lastChange >= quietMs) return { waited_ms: el, quiet: true };
    if (el >= maxMs) return { waited_ms: el, quiet: false };
  }
}

let kn = 0;
async function key(task, label, key, mods = [], waitMs = 1800, quietMs = 1200) {
  kn += 1; const n = kn;
  const before = await evalJS(WHERE);
  const r = await keyd({ op: 'key', key, mods });
  const w = quietMs > 0 ? await waitQuiet(waitMs, quietMs, Math.max(waitMs, 12000)) : (await sleep(waitMs), { waited_ms: waitMs, quiet: null });
  const after = await evalJS(WHERE);
  const sink = sinkSince(r.t0 || 0).map((x) => x.text);
  const e = { ev: 'key', n, task, label, key, mods, ok: r.ok, t0: r.t0, t1: r.t1, codes: r.codes, error: r.error, wait_ms: waitMs, waited: w, before, after, sink_after: sink };
  rec(e); return e;
}
const onStatus = (e) => !!(e.after && e.after.sel_in_status) || e.sink_after.some((s) => s.includes('Source snapshot'));

async function main() {
  const ver = await getJSON('/json/version'); rec({ ev: 'cdp_version', browser: ver.Browser, protocol: ver['Protocol-Version'] });
  ws = new WebSocket(ver.webSocketDebuggerUrl);
  await new Promise((res, rej) => { ws.onopen = res; ws.onerror = rej; });
  ws.onmessage = (m) => {
    const msg = JSON.parse(typeof m.data === 'string' ? m.data : Buffer.from(m.data).toString());
    if (msg.id !== undefined && pending.has(msg.id)) { const p = pending.get(msg.id); pending.delete(msg.id); if (msg.error) p.rej(new Error(msg.error.message)); else p.res(msg.result); return; }
    onEvent(msg).catch((e) => rec({ ev: 'event_error', error: String(e) }));
  };
  await send('Target.setDiscoverTargets', { discover: true });
  await send('Target.setAutoAttach', AUTO);
  const t = await Promise.race([pageReady, sleep(3000).then(() => null)]);
  if (!t) {
    const { targetInfos } = await send('Target.getTargets');
    const pg = targetInfos.find((x) => x.type === 'page');
    rec({ ev: 'manual_attach', target: pg && pg.url });
    await send('Target.attachToTarget', { targetId: pg.targetId, flatten: true });
    await pageReady;
  }
  await send('Page.enable', {}, pageSession); await send('Runtime.enable', {}, pageSession);
  const startUrl = `${ORIGIN}/dependencies.html`;
  rec({ ev: 'navigate', url: startUrl, pre: await evalJS(WHERE) });
  await send('Page.navigate', { url: startUrl }, pageSession);
  let ready = null;
  for (let i = 0; i < 120; i++) {
    await sleep(500);
    const s = await evalJS(`(()=>{const a=document.getElementById('atlas-status');const v=document.getElementById('atlas-view');return {rs:document.readyState,status:a?a.textContent:null,viewDisabled:v?v.disabled:null}})()`).catch(() => null);
    if (s && s.rs === 'complete' && s.status && s.status.startsWith('Source snapshot') && s.viewDisabled === false) { ready = s; break; }
  }
  rec({ ev: 'page_ready', ok: !!ready, struct: await evalJS(STRUCT), dom: await evalJS(DOMSTATE) });
  rec({ ev: 'settle', ...(await waitQuiet(9000, 4000, 90000)), log_bytes: logSize() }); // let Orca finish its load-time event backlog
  // pointer parked over the empty tab strip: with no window manager X focus follows the pointer, and a select popup must not open under it
  rec({ ev: 'pointer', x: 1000, y: 12, r: await keyd({ op: 'pointer', x: 1000, y: 12 }), where: await evalJS(WHERE) });
  await sleep(800);

  // ---- R1: browse from the top, '1' to the level-1 heading, Down through #atlas-status ----
  rec({ ev: 'task_start', task: 'R1' });
  await key('R1', 'top of document', 'Home', ['Control_L'], 2500);
  await key('R1', 'next level-1 heading', '1', [], 2500);
  let seen = false; let last = null;
  for (let i = 1; i <= 10; i++) {
    last = await key('R1', `Down ${i}`, 'Down', [], 1800);
    const on = onStatus(last); if (on) seen = true;
    if (i >= 6 && seen && !on) break;
  }
  rec({ ev: 'task_end', task: 'R1', status_seen_by_caret_or_sink: seen });

  // ---- R3: basic Where Am I with the browse caret on #atlas-status ----
  rec({ ev: 'task_start', task: 'R3' });
  let on = last && onStatus(last);
  for (let i = 1; !on && i <= 8; i++) { const e = await key('R3', `Up ${i} (back to #atlas-status)`, 'Up', [], 1800); on = onStatus(e); }
  const pos = await evalJS(WHERE);
  rec({ ev: 'r3_position', caret_on_status: !!on, where: pos });
  await key('R3', 'KP_Enter (basic Where Am I)', 'KP_Enter', [], 3500);
  rec({ ev: 'task_end', task: 'R3', caret_on_status_before_kp_enter: !!on });

  // ---- R4: View select ----
  rec({ ev: 'task_start', task: 'R4' });
  let atView = false;
  for (let i = 1; i <= 12 && !atView; i++) { const e = await key('R4', `Tab ${i}`, 'Tab', [], 1600); atView = e.after && e.after.active === '#atlas-view'; }
  rec({ ev: 'r4_focus', at_view: atView, dom: await evalJS(DOMSTATE) });
  rec({ ev: 'probe', task: 'R4', when: 'focused, collapsed', r: await keyd({ op: 'probe', id: 'atlas-view', depth: 3 }) });
  await key('R4', 'KP_Enter (Where Am I on select)', 'KP_Enter', [], 3500);
  await key('R4', 'alt+Down (open popup)', 'Down', ['Alt_L'], 2500);
  rec({ ev: 'probe', task: 'R4', when: 'popup open', r: await keyd({ op: 'probe', id: 'atlas-view', depth: 3 }), dom: await evalJS(DOMSTATE) });
  await key('R4', 'Down (in popup)', 'Down', [], 2000);
  rec({ ev: 'probe', task: 'R4', when: 'after Down in popup', r: await keyd({ op: 'probe', id: 'atlas-view', depth: 3 }), dom: await evalJS(DOMSTATE) });
  await key('R4', 'Up (in popup)', 'Up', [], 2000);
  await key('R4', 'Escape (close popup)', 'Escape', [], 2200);
  rec({ ev: 'task_end', task: 'R4', dom: await evalJS(DOMSTATE) });

  // ---- R5: shift+Tab back to #atlas-search, type OPEN, wait >= 4 s ----
  rec({ ev: 'task_start', task: 'R5' });
  let atSearch = false;
  for (let i = 1; i <= 4 && !atSearch; i++) { const e = await key('R5', `shift+Tab ${i}`, 'Tab', ['Shift_L'], 1800); atSearch = e.after && e.after.active === '#atlas-search'; }
  rec({ ev: 'r5_focus', at_search: atSearch, dom: await evalJS(DOMSTATE) });
  for (const ch of ['o', 'p', 'e', 'n']) await key('R5', `type ${ch.toUpperCase()}`, ch, ['Shift_L'], 600, 0);
  rec({ ev: 'r5_typed', dom: await evalJS(DOMSTATE) });
  await sleep(6500);
  rec({ ev: 'task_end', task: 'R5', quiet_wait_ms: 6500, dom: await evalJS(DOMSTATE), where: await evalJS(WHERE) });

  await keyd({ op: 'quit' });
  rec({ ev: 'done' });
  try { ws.close(); } catch {}
  process.exit(0);
}
main().catch((e) => { rec({ ev: 'fatal', error: String(e && e.stack || e) }); process.exit(2); });
