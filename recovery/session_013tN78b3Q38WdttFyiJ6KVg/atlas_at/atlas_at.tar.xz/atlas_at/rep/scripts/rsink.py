#!/usr/bin/python3.12
"""speech-dispatcher sd_generic file sink: appends one JSON line per synthesis call.
usage (from GenericExecuteSynth): python3.12 -I rsink.py SINK.jsonl 'TEXT' 'VOICE' 'LANG'
The authoritative spoken strings come from Orca's debug log; this file only shows what speech-dispatcher received.
"""
import json
import sys
import time

path = sys.argv[1]
rec = {"t": round(time.time(), 6), "text": sys.argv[2] if len(sys.argv) > 2 else "",
       "voice": sys.argv[3] if len(sys.argv) > 3 else "", "lang": sys.argv[4] if len(sys.argv) > 4 else ""}
with open(path, "a", encoding="utf-8") as f:
    f.write(json.dumps(rec, ensure_ascii=False) + "\n")
