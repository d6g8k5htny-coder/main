#!/usr/bin/python3.12
"""Replicator key daemon. Every user key is a real X key event generated through AT-SPI
(Atspi.generate_keyboard_event -> at-spi2-registryd -> XTest), by hardware keycode, with
modifiers pressed and released as separate key events. Also answers read-only AT-SPI
probes (no keys, no focus changes).

Protocol: one JSON object per line on stdin, one JSON reply per line on stdout.
  {"op":"key","key":"Down","mods":["Alt_L"]}   -> {"ok":true,"t0":..,"t1":..,"codes":{..}}
  {"op":"probe","id":"atlas-view"}              -> states of the element with that DOM id and its descendants
  {"op":"pointer","x":600,"y":450}              -> moves the X pointer (absolute)
  {"op":"quit"}
"""
import json
import os
import sys
import time

import gi

gi.require_version("Atspi", "2.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Atspi, Gdk  # noqa: E402

Atspi.init()

# evdev keycodes of the default Xvfb keymap; used only if Gdk lookup fails
FALLBACK = {"Control_L": 37, "Shift_L": 50, "Alt_L": 64, "Home": 110, "Down": 116, "Up": 111,
            "Escape": 9, "Tab": 23, "KP_Enter": 104, "1": 10, "o": 32, "p": 33, "e": 26, "n": 57}

KM = None
try:
    Gdk.init([])
    disp = Gdk.Display.open(os.environ["DISPLAY"]) or Gdk.Display.get_default()
    KM = Gdk.Keymap.get_for_display(disp)
except Exception as e:  # pragma: no cover
    sys.stderr.write(f"keyd: gdk keymap unavailable: {e}\n")


def keycode(name):
    kv = Gdk.keyval_from_name(name)
    src = "fallback"
    code = FALLBACK.get(name)
    if KM is not None and kv:
        ok, keys = KM.get_entries_for_keyval(kv)
        if ok and keys:
            best = sorted(keys, key=lambda k: (k.group, k.level, k.keycode))[0]
            code, src = best.keycode, f"gdk(level {best.level})"
    if code is None:
        raise ValueError(f"no keycode for {name}")
    return int(code), int(kv), src


def gen(code, kind):
    return Atspi.generate_keyboard_event(code, None, kind)


def do_key(key, mods):
    codes = {}
    for m in mods:
        codes[m] = keycode(m)
    codes[key] = keycode(key)
    t0 = time.time()
    oks = []
    for m in mods:
        oks.append(gen(codes[m][0], Atspi.KeySynthType.PRESS))
        time.sleep(0.04)
    oks.append(gen(codes[key][0], Atspi.KeySynthType.PRESS))
    time.sleep(0.03)
    oks.append(gen(codes[key][0], Atspi.KeySynthType.RELEASE))
    for m in reversed(mods):
        time.sleep(0.04)
        oks.append(gen(codes[m][0], Atspi.KeySynthType.RELEASE))
    t1 = time.time()
    return {"ok": all(bool(x) for x in oks), "t0": t0, "t1": t1,
            "codes": {k: {"keycode": v[0], "keysym": v[1], "src": v[2]} for k, v in codes.items()}}


def states(acc):
    try:
        return sorted(Atspi.StateType(s).value_nick for s in acc.get_state_set().get_states())
    except Exception as e:
        return [f"error:{e}"]


def attrs(acc):
    try:
        return dict(acc.get_attributes() or {})
    except Exception:
        return {}


def describe(acc, depth, maxdepth):
    d = {"role": acc.get_role_name(), "name": acc.get_name(), "states": states(acc)}
    a = attrs(acc)
    for k in ("id", "tag", "display", "class"):
        if k in a:
            d[k] = a[k]
    try:
        r = acc.get_extents(Atspi.CoordType.SCREEN)
        d["extents"] = [r.x, r.y, r.width, r.height]
    except Exception:
        pass
    if depth < maxdepth:
        kids = []
        try:
            n = acc.get_child_count()
        except Exception:
            n = 0
        for i in range(min(n, 20)):
            try:
                c = acc.get_child_at_index(i)
            except Exception:
                c = None
            if c is not None:
                kids.append(describe(c, depth + 1, maxdepth))
        d["children"] = kids
    return d


def find_by_id(dom_id, limit=6000, budget=12.0):
    t_end = time.time() + budget
    desk = Atspi.get_desktop(0)
    apps = []
    for i in range(desk.get_child_count()):
        app = desk.get_child_at_index(i)
        if app is not None:
            apps.append(app)
    seen = 0
    for app in apps:
        nm = (app.get_name() or "").lower()
        if "chrom" not in nm:
            continue
        stack = [app]
        while stack and seen < limit and time.time() < t_end:
            acc = stack.pop()
            seen += 1
            if attrs(acc).get("id") == dom_id:
                return acc, seen
            try:
                n = acc.get_child_count()
            except Exception:
                n = 0
            kids = []
            for i in range(n):
                try:
                    c = acc.get_child_at_index(i)
                except Exception:
                    c = None
                if c is not None:
                    kids.append(c)
            stack.extend(reversed(kids))
    return None, seen


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            cmd = json.loads(line)
            op = cmd.get("op")
            if op == "key":
                rep = do_key(cmd["key"], cmd.get("mods", []))
            elif op == "probe":
                t0 = time.time()
                acc, seen = find_by_id(cmd["id"])
                rep = {"ok": acc is not None, "t0": t0, "visited": seen,
                       "tree": describe(acc, 0, int(cmd.get("depth", 3))) if acc is not None else None,
                       "t1": time.time()}
            elif op == "pointer":
                t0 = time.time()
                ok = Atspi.generate_mouse_event(int(cmd["x"]), int(cmd["y"]), "abs")
                rep = {"ok": bool(ok), "t0": t0, "t1": time.time()}
            elif op == "quit":
                out.write(json.dumps({"ok": True, "bye": True}) + "\n")
                out.flush()
                return
            else:
                rep = {"ok": False, "error": f"unknown op {op}"}
        except Exception as e:
            rep = {"ok": False, "error": repr(e)}
        out.write(json.dumps(rep) + "\n")
        out.flush()


if __name__ == "__main__":
    main()
