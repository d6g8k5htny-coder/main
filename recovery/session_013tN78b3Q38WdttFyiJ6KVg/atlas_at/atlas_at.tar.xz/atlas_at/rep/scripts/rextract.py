#!/usr/bin/python3.12
"""Replicator extractor (independent of the executor's extract.py).
usage: python3.12 -I rextract.py EVIDENCE_RUN_DIR
Reads orca-debug.txt (Orca's own log), driver-events.jsonl (keys with AT-SPI send times, DOM reads),
sink.jsonl, server-requests.jsonl, cdp-fetch.jsonl. Writes extract.json and extract.txt in the run dir.
Spoken text = strings in Orca's 'SPEECH OUTPUT: ...' and 'SPEECH DISPATCHER: Speaking ... as string|char'
lines. Each is attributed to the most recent key whose AT-SPI send time precedes it (time-based), and
cross-checked by log position against Orca's own 'vvvvv PROCESS PRESSED' records.
"""
import datetime as dt
import hashlib
import json
import os
import re
import sys

RUN_DIR = sys.argv[1]
P = lambda f: os.path.join(RUN_DIR, f)  # noqa: E731

TS = re.compile(r"^(\d\d):(\d\d):(\d\d)\.(\d{6}) - ")
PROC = re.compile(r"^vvvvv PROCESS ATSPI_KEY_(PRESSED|RELEASED)_EVENT: '(.*)' \((\d+)\)( DUPLICATE EVENT #\d+)? vvvvv$")
KTIME = re.compile(r"^ {17}time=(\d+\.\d+)$")
EMPTY = re.compile(r"^SPEECH: Speak \[\], acss")
PAUSES = re.compile(r"^SPEECH GENERATOR: Results for (.*) are pauses only")
SO = re.compile(r"^SPEECH OUTPUT: '(.*)' (\{.*\}|None)\s*$", re.S)
SD = re.compile(r"^SPEECH DISPATCHER: Speaking '(.*)' as (string|char)\s*$", re.S)


def fhash(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return os.path.getsize(path), h.hexdigest()


def jl(path):
    out = []
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    out.append(json.loads(line))
    return out


events = jl(P("driver-events.jsonl"))
keys = [e for e in events if e.get("ev") == "key"]
t_first = events[0]["t"] if events else 0.0
day0 = dt.datetime.fromtimestamp(t_first, dt.timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0).timestamp()

# ---- parse Orca debug log into records ----
records = []  # dicts: idx, tod_epoch or None, text, kind
cur = None
ktime = None
with open(P("orca-debug.txt"), encoding="utf-8", errors="replace") as f:
    for raw in f:
        line = raw.rstrip("\n")
        m = TS.match(line)
        if m:
            hh, mm, ss, us = (int(x) for x in m.groups())
            tod = hh * 3600 + mm * 60 + ss + us / 1e6
            ep = day0 + tod
            if ep < t_first - 43200:
                ep += 86400
            cur = {"ts": ep, "text": line[m.end():]}
            records.append(cur)
        elif cur is not None and line.startswith(" " * 18) and not line.startswith("vvvvv"):
            cur["text"] += "\n" + line[18:]
        else:
            cur = None
            km = KTIME.match(line)
            if km:
                ktime = float(km.group(1))
            pm = PROC.match(line)
            if pm:
                records.append({"ts": None, "proc": pm.group(1), "name": pm.group(2), "code": int(pm.group(3)),
                                "dup": bool(pm.group(4)), "text": line, "orca_time": ktime})
                ktime = None

# fill times of PROCESS records with the next timestamped record's time
nxt = None
for r in reversed(records):
    if r["ts"] is not None:
        nxt = r["ts"]
    elif nxt is not None:
        r["ts_next"] = nxt
for i, r in enumerate(records):
    r["i"] = i

speech = []
for r in records:
    if r.get("proc"):
        continue
    m = SO.match(r["text"])
    if m:
        speech.append({"i": r["i"], "ts": r["ts"], "src": "SPEECH OUTPUT", "text": m.group(1)})
        continue
    m = SD.match(r["text"])
    if m:
        speech.append({"i": r["i"], "ts": r["ts"], "src": "SD " + m.group(2), "text": m.group(1)})
        continue
    if EMPTY.match(r["text"]):
        speech.append({"i": r["i"], "ts": r["ts"], "src": "EMPTY", "text": r["text"].split("\n")[0]})
        continue
    m = PAUSES.match(r["text"])
    if m:
        speech.append({"i": r["i"], "ts": r["ts"], "src": "PAUSES-ONLY", "text": r["text"].split("\n")[0]})
presses = [r for r in records if r.get("proc") == "PRESSED"]

# ---- delivery: match each sent key (mods + key) to Orca's PRESSED records in order ----
pi = 0
for k in keys:
    expect = [k["codes"][m]["keycode"] for m in k.get("mods", [])] + [k["codes"][k["key"]]["keycode"]] if k.get("codes") else []
    got = []
    for code in expect:
        j = pi
        while j < len(presses) and presses[j]["code"] != code:
            j += 1
        if j < len(presses) and presses[j].get("ts_next", 0) >= k["t0"] - 0.5:
            got.append(presses[j])
            pi = j + 1
        else:
            got.append(None)
    k["delivered"] = bool(expect) and all(g is not None for g in got)
    k["orca_saw"] = [(g["name"], g["code"]) if g else None for g in got]
    k["orca_key_record_i"] = got[0]["i"] if got and got[0] else None
    k["orca_time"] = got[0].get("orca_time") if got and got[0] else None
    k["orca_lag_s"] = round(k["orca_time"] - k["t0"], 3) if k["orca_time"] else None

# ---- attribution ----
# primary: by log position -- the speech belongs to the last key whose first PRESSED record Orca logged before it.
# cross-check: by time -- the last key whose AT-SPI send time precedes the speech timestamp (pos_ok = both agree).
for s in speech:
    owner = None
    for k in keys:
        if k.get("orca_key_record_i") is not None and k["orca_key_record_i"] < s["i"]:
            owner = k
    towner = None
    for k in keys:
        if k["t0"] <= s["ts"]:
            towner = k
    s["key_n"] = owner["n"] if owner else 0
    s["task"] = owner["task"] if owner else "pre"
    s["label"] = owner["label"] if owner else "page load (before first key)"
    s["pos_ok"] = (towner["n"] if towner else 0) == s["key_n"]

tasks = {}
for k in keys:
    t = tasks.setdefault(k["task"], {"keys": [], "spoken": []})
    t["keys"].append({"n": k["n"], "label": k["label"], "key": k["key"], "mods": k.get("mods", []),
                      "t0_utc": dt.datetime.fromtimestamp(k["t0"], dt.timezone.utc).strftime("%H:%M:%S.%f")[:-3],
                      "atspi_ok": k.get("ok"), "delivered_to_orca": k["delivered"], "orca_saw": k["orca_saw"],
                      "orca_lag_s": k.get("orca_lag_s"), "waited": k.get("waited"),
                      "dom_after": k.get("after"), "sink_after": k.get("sink_after")})
pre = {"keys": [], "spoken": []}
for s in speech:
    tgt = tasks.get(s["task"], pre) if s["task"] != "pre" else pre
    tgt["spoken"].append({"key_n": s["key_n"], "label": s["label"], "src": s["src"],
                          "t_utc": dt.datetime.fromtimestamp(s["ts"], dt.timezone.utc).strftime("%H:%M:%S.%f")[:-3],
                          "text": s["text"], "pos_ok": s["pos_ok"]})

other = {e["ev"]: e for e in events if e.get("ev") not in ("key",)}
dom = {
    "page_ready": other.get("page_ready"),
    "r3_position": other.get("r3_position"),
    "r4_focus": other.get("r4_focus"),
    "r4_end": next((e for e in events if e.get("ev") == "task_end" and e.get("task") == "R4"), None),
    "r5_focus": other.get("r5_focus"),
    "r5_typed": other.get("r5_typed"),
    "r5_end": next((e for e in events if e.get("ev") == "task_end" and e.get("task") == "R5"), None),
    "probes": [e for e in events if e.get("ev") == "probe"],
}

# ---- network evidence ----
reqs = jl(P("server-requests.jsonl"))
fetches = jl(P("cdp-fetch.jsonl"))
blocked = [f for f in fetches if f["decision"] != "continue"]
hashes = {}
for f in ("orca-debug.txt", "sdlog/speech-dispatcher.log", "sink.jsonl", "driver-events.jsonl", "cdp-fetch.jsonl",
          "server-requests.jsonl", "chrome.log", "commands.log"):
    if os.path.exists(P(f)):
        hashes[f] = fhash(P(f))

out = {"run": os.path.basename(RUN_DIR.rstrip("/")), "tree": open(P("tree.txt")).read().split()[0] if os.path.exists(P("tree.txt")) else None,
       "hashes": hashes, "speech_records": len(speech), "orca_pressed_records": len(presses),
       "keys_sent": len(keys), "keys_delivered": sum(1 for k in keys if k["delivered"]),
       "pre": pre, "tasks": tasks, "dom": dom,
       "network": {"server_requests": len(reqs), "server_non_loopback_clients": sorted({r["client"] for r in reqs} - {"127.0.0.1"}),
                   "cdp_paused": len(fetches), "cdp_blocked": [(b["url"], b["decision"]) for b in blocked],
                   "cdp_continued_non_origin": [f["url"] for f in fetches if f["decision"] == "continue" and not f["url"].startswith("http://127.0.0.1:")]}}
with open(P("extract.json"), "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=1)

with open(P("extract.txt"), "w", encoding="utf-8") as f:
    f.write(f"run {out['run']} tree {out['tree']} keys sent {out['keys_sent']} delivered {out['keys_delivered']} speech records {out['speech_records']}\n")
    for name, blk in [("pre", pre)] + sorted(tasks.items()):
        f.write(f"\n== {name}\n")
        for k in blk["keys"]:
            f.write(f"  KEY k{k['n']} {k['t0_utc']} {'+'.join(k['mods'] + [k['key']])} [{k['label']}] delivered={k['delivered_to_orca']} lag={k['orca_lag_s']} sel={k['dom_after'] and k['dom_after'].get('sel_near_id')} active={k['dom_after'] and k['dom_after'].get('active')}\n")
        for s in blk["spoken"]:
            f.write(f"  {s['t_utc']} k{s['key_n']} {s['src']:<14} pos_ok={s['pos_ok']} {s['text']!r}\n")
print(json.dumps({"run": out["run"], "keys": f"{out['keys_delivered']}/{out['keys_sent']}", "speech": out["speech_records"],
                  "net": out["network"]}, ensure_ascii=False))
