#!/bin/bash
# Replicator stack for ONE run (written for the ATLAS-AT replication).
# usage:  flock $A/stack.lock bash rstack.sh RUN_ID TREE      (TREE = base | var)
# Xvfb + dbus-launch + at-spi-bus-launcher + speech-dispatcher (sd_generic file sink) + Orca 46.1
# (default profile, --debug-file) + Chromium 1194 (dead loopback proxy, background networking off,
# Fetch.failRequest for every non-loopback request in the driver). Writes only under $A/rep/.
set -u
A=/tmp/claude-0/-home-user-main/d5c985ca-97e5-58d8-a9d4-1e0a19065a22/scratchpad/atlasat
REP=$A/rep; S=$REP/scripts; RUN="$1"; TREE="$2"
SITE=$A/trees/$TREE/docs/site; OUT=$REP/evidence/$RUN
[ -d "$SITE" ] || { echo "no tree $TREE"; exit 2; }
[ -e "$OUT/RUN_DONE" ] && { echo "run $RUN already recorded; refusing to overwrite"; exit 2; }
DISP=:97; PORT=8781; CDP=9341; ORIGIN=http://127.0.0.1:$PORT
CHROME=/opt/pw-browsers/chromium-1194/chrome-linux/chrome
PROF=$REP/profiles/$RUN; SOCK=$REP/sd.sock   # unix socket paths must stay under 108 bytes
rm -rf "$OUT" "$PROF"; rm -f "$SOCK"; mkdir -p "$OUT/sdlog" "$PROF/xdg-config" "$PROF/xdg-cache"
L=$OUT/commands.log
log() { echo "$(date -u +%Y-%m-%dT%H:%M:%S.%3NZ) $*" >> "$L"; }
log "run $RUN tree $TREE site $SITE; started under flock on $A/stack.lock (shell pid $$)"

stackprocs() { ps -eo pid=,comm=,args= | awk '$2=="Xvfb"||$2=="speech-dispatch"||$2=="orca"||$2=="sd_generic"||$2=="sd_espeak-ng"||$3~/\/usr\/bin\/orca/||$0~/chromium-1194\/chrome-linux\/chrome /{print}'; }
for i in $(seq 1 120); do
  P=$(stackprocs); [ -z "$P" ] && break
  [ $i -eq 1 ] && { log "leftover stack processes after taking the lock; waiting (not killing):"; echo "$P" >> "$L"; }
  sleep 5
done
P=$(stackprocs); if [ -n "$P" ]; then log "ABORT: stack processes still present after 10 min"; echo "$P" >> "$L"; exit 4; fi
log "leftover check: no Xvfb / Orca / speech-dispatcher / chromium-1194 process present"

PIDS=()
teardown() {
  log "teardown start"
  [ -n "${CHPID:-}" ] && kill -TERM "$CHPID" 2>/dev/null; sleep 1.5
  [ -n "${ORPID:-}" ] && kill -TERM "$ORPID" 2>/dev/null; sleep 1.5
  [ -f "$OUT/speechd.pid" ] && kill -TERM "$(cat "$OUT/speechd.pid")" 2>/dev/null
  for p in "${PIDS[@]}"; do kill -TERM "$p" 2>/dev/null; done
  [ -n "${DBUS_SESSION_BUS_PID:-}" ] && kill -TERM "$DBUS_SESSION_BUS_PID" 2>/dev/null
  sleep 1.5
  # anything of the stack still alive at this point is ours (we hold the lock)
  pkill -9 -f "chromium-1194/chrome-linux/chrome" 2>/dev/null; pkill -9 -f "/usr/bin/orca" 2>/dev/null
  pkill -9 -x speech-dispatch 2>/dev/null; pkill -9 -x sd_generic 2>/dev/null
  pkill -9 -f "at-spi-bus-launcher" 2>/dev/null; pkill -9 -f "at-spi2-registryd" 2>/dev/null
  [ -n "${XPID:-}" ] && kill -9 "$XPID" 2>/dev/null
  [ -n "${SRVPID:-}" ] && kill -9 "$SRVPID" 2>/dev/null
  sleep 1
  rm -f /tmp/.X97-lock /tmp/.X11-unix/X97 /root/.cache/at-spi/bus_97 "$SOCK"
  local left; left=$(stackprocs); [ -n "$left" ] && { log "PROBLEM: still running after teardown:"; echo "$left" >> "$L"; }
  log "teardown done"
}
trap 'teardown; exit 130' INT TERM

curl -sS --max-time 10 "$HTTPS_PROXY/__agentproxy/status" > "$OUT/proxy-status-before.json" 2>"$OUT/proxy-status-before.err"
log "proxy status before (read-only GET) saved"
sha256sum /root/.local/share/orca/user-settings.conf > "$OUT/orca-user-settings.sha256"
(cd "$SITE" && sha256sum dependencies.html atlas.mjs atlas-spatial-shell.mjs dependencies.mjs current.json) > "$OUT/served-files.sha256"
echo "$TREE $SITE" > "$OUT/tree.txt"
{ /usr/bin/python3.12 /usr/bin/orca --version; "$CHROME" --version; speech-dispatcher --version | head -1; Xvfb -version 2>&1 | head -2; /opt/node22/bin/node --version; /usr/bin/python3.12 --version; } > "$OUT/versions.txt" 2>&1

# speech-dispatcher config: generic module writing every synthesis request to a JSONL file sink
mkdir -p "$OUT/sdconf/modules"
cat > "$OUT/sdconf/speechd.conf" <<EOF
LogLevel 5
DefaultModule repsink
AddModule "repsink" "sd_generic" "repsink.conf"
DefaultLanguage "en"
DefaultVoiceType "MALE1"
AudioOutputMethod "oss"
AudioOSSDevice "/dev/null"
EOF
cat > "$OUT/sdconf/modules/repsink.conf" <<EOF
Debug 0
GenericExecuteSynth "/usr/bin/python3.12 -I $S/rsink.py $OUT/sink.jsonl \'\$DATA\' \'\$VOICE\' \'\$LANGUAGE\'"
GenericDefaultCharset "utf-8"
GenericLanguage "en" "en" "utf-8"
AddVoice "en" "MALE1" "repsink"
GenericMaxChunkLength 2000
EOF

log "serve: /usr/bin/python3.12 -I $S/rserve.py $SITE $PORT $OUT/server-requests.jsonl"
/usr/bin/python3.12 -I "$S/rserve.py" "$SITE" "$PORT" "$OUT/server-requests.jsonl" > "$OUT/serve.err" 2>&1 & SRVPID=$!

export DISPLAY=$DISP
log "Xvfb $DISP -screen 0 1280x900x24 -nolisten tcp"
Xvfb $DISP -screen 0 1280x900x24 -nolisten tcp > "$OUT/xvfb.log" 2>&1 & XPID=$!
for i in $(seq 1 40); do [ -S /tmp/.X11-unix/X97 ] && break; sleep 0.25; done
eval "$(dbus-launch --sh-syntax)"; log "dbus-launch: $DBUS_SESSION_BUS_ADDRESS pid $DBUS_SESSION_BUS_PID"
export GTK_MODULES=gail:atk-bridge ACCESSIBILITY_ENABLED=1
log "/usr/libexec/at-spi-bus-launcher --launch-immediately"
/usr/libexec/at-spi-bus-launcher --launch-immediately > "$OUT/atspi.log" 2>&1 & PIDS+=($!)
sleep 1.5
export SPEECHD_ADDRESS="unix_socket:$SOCK"
log "speech-dispatcher -s -t 0 -l 5 -L $OUT/sdlog -C $OUT/sdconf -S $SOCK -P $OUT/speechd.pid"
LANG=C.UTF-8 speech-dispatcher -s -t 0 -l 5 -L "$OUT/sdlog" -C "$OUT/sdconf" -S "$SOCK" -P "$OUT/speechd.pid" > "$OUT/speechd.out" 2>&1 & PIDS+=($!)
for i in $(seq 1 40); do [ -S "$SOCK" ] && break; sleep 0.25; done
[ -S "$SOCK" ] && log "speechd socket up" || log "PROBLEM: no speechd socket"
log "/usr/bin/python3.12 /usr/bin/orca --debug-file=$OUT/orca-debug.txt   (SPEECHD_ADDRESS=$SPEECHD_ADDRESS; default profile, no --replace)"
/usr/bin/python3.12 /usr/bin/orca --debug-file="$OUT/orca-debug.txt" > "$OUT/orca.out" 2>&1 & ORPID=$!
sleep 8
CHARGS=(--no-sandbox --force-renderer-accessibility --no-first-run --no-default-browser-check
  --user-data-dir="$PROF/udd" --window-size=1200,850 --window-position=0,0 --lang=en-US
  --remote-debugging-address=127.0.0.1 --remote-debugging-port=$CDP
  --proxy-server=http://127.0.0.1:9 --disable-background-networking --disable-component-update --disable-sync
  --disable-default-apps --disable-features=OptimizationHints,MediaRouter,Translate --disable-gpu
  "data:text/html,<title>rep start</title><p>rep start</p>")
log "XDG_CONFIG_HOME=$PROF/xdg-config XDG_CACHE_HOME=$PROF/xdg-cache $CHROME ${CHARGS[*]}"
XDG_CONFIG_HOME="$PROF/xdg-config" XDG_CACHE_HOME="$PROF/xdg-cache" "$CHROME" "${CHARGS[@]}" > "$OUT/chrome.log" 2>&1 & CHPID=$!
for i in $(seq 1 60); do curl -s --max-time 1 --noproxy '*' "http://127.0.0.1:$CDP/json/version" > /dev/null 2>&1 && break; sleep 0.25; done
sleep 4
log "/opt/node22/bin/node $S/rdrive.mjs $RUN $OUT $CDP $ORIGIN $S/keyd.py"
/opt/node22/bin/node "$S/rdrive.mjs" "$RUN" "$OUT" "$CDP" "$ORIGIN" "$S/keyd.py" > "$OUT/driver.out" 2>&1
DRC=$?; log "driver exit $DRC"
sleep 2
teardown
sha256sum /root/.local/share/orca/user-settings.conf > "$OUT/orca-user-settings.after.sha256"
curl -sS --max-time 10 "$HTTPS_PROXY/__agentproxy/status" > "$OUT/proxy-status-after.json" 2>"$OUT/proxy-status-after.err"
log "proxy status after (read-only GET) saved"
: > "$OUT/LOG_HASHES.tsv"
for f in orca-debug.txt sdlog/speech-dispatcher.log sink.jsonl driver-events.jsonl cdp-fetch.jsonl server-requests.jsonl chrome.log commands.log; do
  [ -f "$OUT/$f" ] && printf '%s\t%s\t%s\n' "$f" "$(stat -c %s "$OUT/$f")" "$(sha256sum "$OUT/$f" | cut -d' ' -f1)" >> "$OUT/LOG_HASHES.tsv"
done
rm -rf "$PROF"
echo "driver_exit=$DRC" > "$OUT/RUN_DONE"
exit $DRC
