# Criteria critic brief: Orca speech on the current Atlas (main#388, ATLAS-AT-ORCA-CURRENT-CLAUDE54-20261025)

Paths: `A=/tmp/claude-0/-home-user-main/d5c985ca-97e5-58d8-a9d4-1e0a19065a22/scratchpad/atlasat`.

You check the executor's and the replicator's results against the raw logs and the pre-registered rule. You do not run
any stack (no Orca, Xvfb or Chromium) and you post nothing anywhere. Read-only, except your report.

Inputs:
- The pickup text: `$A/pickup.md` (scope, tasks 1–7, verdict rule).
- Trees: `$A/trees/base/docs/site` (main 93ad7a46 unmodified), `$A/trees/var/docs/site` (status wrapper variant, `$A/variant.diff`),
  `$A/trees/var2/docs/site` (variant plus fresh View options, `$A/variant2_select.diff`).
- Executor runs: `$A/evidence/BASE1`, `BASE2` (base), `VAR1`, `VAR2` (var), `SEL1` (var2, select task only). Each has
  `orca-debug.txt` (ground truth for spoken strings: `SPEECH OUTPUT:` and `SPEECH DISPATCHER: Speaking` lines), `steps.jsonl`
  (keys, DOM probes), `steps-speech.txt`, `summary.json`/`summary.md` (made by `$A/scripts/summarize.py`), `server-requests.jsonl`,
  `refusals.jsonl`, `chrome-net_error.count`, `proxy-status-before/after.json`, `LOG_HASHES.tsv`.
  BASE1 typed `proof` for T6, which matches all 108 excerpts, so its T6 is not a test; BASE2 and later typed `sigma` (23 of 108).
- Replicator: its report (given to you in the prompt) and its files under `$A/rep/`.

Check, and report each as a short item:
1. For every executor verdict in every `summary.json`, does the raw `orca-debug.txt` support it? Spot-check at least T1, T3, T4,
   T6 in one baseline and one variant run by reading the debug log around the step times in `steps.jsonl`. Flag any verdict the
   summarizer got wrong (it matches case-sensitively on 'Source snapshot 20', 'source observation:', 'displayed', 'matching excerpts',
   'grayed', the view value name).
2. Does the replicator agree with the executor on R1/R3/R4/R5 for base and var? List each disagreement with the evidence.
3. Is the variant faithful to the stated pattern (only the role/wrapper moved; IDs and writers kept; no other change)? Read both diffs.
4. Network hygiene: every server request local; refusals only the harness canary; zero net_error lines; proxy status unchanged.
5. Mechanism claims: (a) Orca 46.1's status-bar speech has no text field (`/usr/lib/python3/dist-packages/orca/formatting.py`
   STATUS_BAR, and `speech_generator.py` `_generateStatusBar`); (b) T6: the executor now attributes the missing `#equation-count`
   announcement to the key-press flush race. The count settles at 23 after `sig`, Orca queues the change as a live region, the next
   key press logs "WEB: Flushing live region messages" (`scripts/web/script.py:526-530`), and no later change occurs. An earlier draft
   blamed `Chromium/script.py` `onChildrenAdded` dropping static-text-leaf children; check which explanation the logs of BASE2, VAR1
   and VAR2 support. Confirm or correct the line numbers.
6. Anything the delivery must not claim (e.g. a site-wide AT PASS, other AT or browsers, the generated deployment, single-run
   limits for SEL1) and any caveat you see.
Return: verdict_problems, replication_disagreements, variant_fidelity, network, mechanism, caveats.
