# Independent replication brief: Orca speech on the current Atlas (main#388, ATLAS-AT-ORCA-CURRENT-CLAUDE54-20261025)

You are replicating a screen-reader measurement with **separately written scripts**. Do not copy or read the executor's driver
(`atlasat/scripts/drive.mjs`), extractor (`atlasat/scripts/extract.py`) or its results (`atlasat/evidence/BASE*`, `VAR*`, `SEL*`) before you finish
your own runs. You may read `atlasat/scripts/stack.sh` only to learn how the stack is brought up (Xvfb, dbus-launch,
at-spi-bus-launcher, speech-dispatcher with the file sink, Orca 46.1 with `--debug-file`, Chromium flags). Write your own
stack script, driver and extractor under `atlasat/rep/scripts/`, and keep your evidence under `atlasat/rep/evidence/<RUN>/`.

Paths (absolute): `A=/tmp/claude-0/-home-user-main/d5c985ca-97e5-58d8-a9d4-1e0a19065a22/scratchpad/atlasat`.

## What to serve
- Baseline: `$A/trees/base/docs/site` (docs/site at main 93ad7a463348743d08a6db2c21b4e4f01b1942d0, unmodified).
- Variant: `$A/trees/var/docs/site`: every direct-text `role="status"` element on dependencies.html (and the JS-created
  `#atlas-space-status`) has its text moved into an inner `<p>` that keeps the ID and writers, with `role="status"` on a wrapping `<div>`.
  The diff is `$A/variant.diff`.
- Serve with a loopback-only static server you write (bind 127.0.0.1, log every request). The page is `/dependencies.html`.

## Hard rules
- Only one stack at a time on this machine. Wrap each whole run (bring-up, keys, teardown) in an exclusive lock on
  `$A/stack.lock`, e.g. `flock $A/stack.lock bash your_run.sh REP_BASE1 base`; the executor's runs take the same lock. After taking the lock,
  also check that no Xvfb, Orca, speech-dispatcher or chromium-1194 process is left over, and tear yours down fully before releasing it.
  Run long commands in the background and wait for them; never chain foreground sleeps.
- Chromium `/opt/pw-browsers/chromium-1194/chrome-linux/chrome` must have NO route to the network proxy: pass
  `--proxy-server=http://127.0.0.1:9 --disable-background-networking --disable-component-update --disable-sync --no-first-run
  --disable-default-apps --disable-features=OptimizationHints,MediaRouter,Translate --force-renderer-accessibility`, and in your CDP
  driver block (Fetch.failRequest) every request that is not to your loopback server. Never unset HTTPS_PROXY or disable TLS anywhere.
- Every user key must be a real X key event sent through AT-SPI (`Atspi.generate_keyboard_event`, python3.12 with gi). CDP
  `Input.dispatchKeyEvent` is invisible to Orca and must not be used. Use CDP only to navigate to the start URL and to observe the DOM.
- Use Orca's default profile (do not edit `/root/.local/share/orca/user-settings.conf`; record its sha256).
- Spoken text = the strings Orca hands to speech-dispatcher, taken from Orca's own debug log (`SPEECH OUTPUT: '...'` lines and
  `SPEECH DISPATCHER: Speaking '...'` lines). Record byte length and sha256 of every log you rely on.
- Do not post anything to GitHub or any external service. Write only under `$A/rep/`.

## Runs and tasks
Run each of these on the baseline (run IDs REP_BASE1) and on the variant (REP_VAR1), one fresh stack per run:
- R1 (browse): from the top of the document, press Orca's `1` (next level-1 heading) to reach "Mathematical atlas", then press
  Down repeatedly (about 6–10 times) through the `#atlas-status` paragraph. Record what Orca says on each press.
- R3 (Where Am I): when the browse caret is on `#atlas-status`, press KP_Enter (basic Where Am I). Record what is said.
- R4 (View select): Tab to `#atlas-view`; press KP_Enter (Where Am I); press alt+Down to open the popup; Down; Up; Escape.
  Record the strings, including whether any option is spoken with "grayed", and the AT-SPI states of the two options if you can.
- R5 (search update): shift+Tab back to `#atlas-search`, type `OPEN` one key at a time, then wait at least 4 s with no keys.
  Record whether any count or status text is spoken after typing, and the DOM text of `#atlas-status` and `#atlas-count`.

## Report (StructuredOutput)
For each run and task: the keys sent with times, the exact spoken strings attributed to that task, the DOM text where relevant, and a
verdict under this pre-registered rule: PASS = the required information was spoken (R1/R3: the graph summary text of `#atlas-status`,
i.e. its "Source snapshot … nodes … edges" content; R4: the selected value name, with no option spoken as grayed while the select is
enabled; R5: an announcement of the updated count or status after typing); FAIL = the task was operated but the information was not
spoken or was spoken wrongly; NOT_OBSERVED = only when capture or key delivery failed. Also list the files you wrote and the
hashes of the logs. Be exact; quote strings as recorded.
