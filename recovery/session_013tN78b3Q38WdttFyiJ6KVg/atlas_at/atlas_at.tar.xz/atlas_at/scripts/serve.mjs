// Static, loopback-only file server for the SITE generated-bundle replay.
// usage: node serve.mjs ARTIFACT_ROOT LOG_PATH [PORT=8770]
//
// - Binds 127.0.0.1 only. Uses only node: builtins; it never opens an outbound connection
//   and never acts as a proxy (absolute-form request targets are refused with 400).
// - ARTIFACT_ROOT is served as "/", so the bundle's site/ is at http://127.0.0.1:PORT/site/...
// - Every request is appended to LOG_PATH as one JSON line:
//   {time, method, url, path, status, bytes, sha256, file, content_type, location?, note?, remote}
//   bytes/sha256 describe the response body actually sent (empty body for HEAD/301/405).
// - Missing files: 404 with a short plain-text body (not the bundle's 404.html), logged.
// - Directories: "/dir" -> 301 to "/dir/"; "/dir/" -> dir/index.html or 404.
// - Bytes are served exactly as stored; nothing is rewritten, generated or cached.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const [rootArg, logArg, portArg] = process.argv.slice(2);
if (!rootArg || !logArg) {
  console.error('usage: node serve.mjs ARTIFACT_ROOT LOG_PATH [PORT=8770]');
  process.exit(2);
}
const ROOT = fs.realpathSync(path.resolve(rootArg));
const PORT = Number(portArg || 8770);
const HOST = '127.0.0.1';
const logFd = fs.openSync(path.resolve(logArg), 'a');

const TYPES = {
  '.html': 'text/html; charset=utf-8', '.htm': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.map': 'application/json',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
  '.gif': 'image/gif', '.webp': 'image/webp', '.ico': 'image/x-icon', '.avif': 'image/avif',
  '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf', '.otf': 'font/otf',
  '.txt': 'text/plain; charset=utf-8', '.md': 'text/markdown; charset=utf-8',
  '.xml': 'application/xml', '.pdf': 'application/pdf', '.zip': 'application/zip',
  '.wasm': 'application/wasm', '.csv': 'text/csv; charset=utf-8', '.ipynb': 'application/json',
  '.webmanifest': 'application/manifest+json', '.tex': 'text/plain; charset=utf-8',
};
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const log = o => fs.writeSync(logFd, JSON.stringify(o) + '\n');

function resolve(reqUrl) {
  // returns {status, file?, location?, note?}
  if (!reqUrl.startsWith('/')) return { status: 400, note: 'non-origin-form request target refused (no proxying)' };
  const q = reqUrl.indexOf('?');
  const rawPath = q < 0 ? reqUrl : reqUrl.slice(0, q);
  const search = q < 0 ? '' : reqUrl.slice(q);
  let p;
  try { p = decodeURIComponent(rawPath.split('#')[0]); } catch { return { status: 400, note: 'bad percent-encoding' }; }
  if (p.includes('\0') || p.includes('\\')) return { status: 400, note: 'NUL or backslash in path' };
  const segs = p.split('/');
  if (segs.includes('..')) return { status: 400, note: '.. segment refused' };
  const fsPath = path.join(ROOT, ...segs.filter(Boolean));
  if (fsPath !== ROOT && !fsPath.startsWith(ROOT + path.sep)) return { status: 400, note: 'outside root' };
  let st;
  try { st = fs.lstatSync(fsPath); } catch { return { status: 404, path: p, note: 'not in bundle' }; }
  if (st.isSymbolicLink()) return { status: 403, path: p, note: 'symlink refused' };
  if (st.isDirectory()) {
    if (!p.endsWith('/')) return { status: 301, path: p, location: rawPath + '/' + search };
    const idx = path.join(fsPath, 'index.html');
    let ist;
    try { ist = fs.lstatSync(idx); } catch { return { status: 404, path: p, note: 'directory without index.html' }; }
    if (!ist.isFile()) return { status: 403, path: p, note: 'index.html is not a regular file' };
    return { status: 200, path: p, file: idx };
  }
  if (!st.isFile()) return { status: 403, path: p, note: 'not a regular file' };
  return { status: 200, path: p, file: fsPath };
}

const server = http.createServer((req, res) => {
  const time = new Date().toISOString();
  const entry = { time, method: req.method, url: req.url, path: null, status: 0, bytes: 0, sha256: sha(Buffer.alloc(0)),
                  file: null, content_type: null, remote: req.socket.remoteAddress };
  let body = Buffer.alloc(0);
  const headers = { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' };
  try {
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      entry.status = 405; entry.note = 'only GET and HEAD'; headers.Allow = 'GET, HEAD';
    } else {
      const r = resolve(req.url);
      entry.status = r.status; entry.path = r.path ?? null;
      if (r.note) entry.note = r.note;
      if (r.status === 200) {
        body = fs.readFileSync(r.file);
        entry.file = path.relative(ROOT, r.file).split(path.sep).join('/');
        headers['Content-Type'] = TYPES[path.extname(r.file).toLowerCase()] || 'application/octet-stream';
      } else if (r.status === 301) {
        headers.Location = r.location; entry.location = r.location;
      } else {
        body = Buffer.from(`${r.status} ${http.STATUS_CODES[r.status]}\n`);
        headers['Content-Type'] = 'text/plain; charset=utf-8';
      }
    }
  } catch (e) {
    entry.status = 500; entry.note = String(e && e.message || e);
    body = Buffer.from('500 Internal Server Error\n'); headers['Content-Type'] = 'text/plain; charset=utf-8';
  }
  entry.content_type = headers['Content-Type'] || null;
  headers['Content-Length'] = body.length;
  const sent = req.method === 'HEAD' ? Buffer.alloc(0) : body;
  entry.bytes = sent.length; entry.sha256 = sha(sent);
  if (req.method === 'HEAD') entry.content_length = body.length;
  log(entry);
  res.writeHead(entry.status, headers);
  res.end(sent);
});

server.listen(PORT, HOST, () => {
  console.log(JSON.stringify({ event: 'listening', time: new Date().toISOString(), host: HOST, port: PORT,
                               root: ROOT, log: path.resolve(logArg), pid: process.pid, node: process.version }));
});
const stop = sig => {
  server.close(() => {
    fs.fsyncSync(logFd); fs.closeSync(logFd);
    console.log(JSON.stringify({ event: 'stopped', signal: sig, time: new Date().toISOString() }));
    process.exit(0);
  });
  server.closeAllConnections?.();
};
process.on('SIGTERM', () => stop('SIGTERM'));
process.on('SIGINT', () => stop('SIGINT'));
