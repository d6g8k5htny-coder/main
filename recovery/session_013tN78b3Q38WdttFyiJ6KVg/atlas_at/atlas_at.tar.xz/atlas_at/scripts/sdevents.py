#!/usr/bin/python3 -I
# REP: speech-dispatcher log -> timeline of SPEAK commands, module BEGIN, END (played to end) and CANCELED.
# usage: sdevents.py EVIDENCE_DIR FROM_HH:MM:SS TO_HH:MM:SS
import re, sys, os
d, a, b = sys.argv[1:4]
rx = re.compile(r'^\[\w+ \w+ +\d+ (\d\d:\d\d:\d\d) \d+ : (\d+)\] speechd: (.*)$')
lines = open(os.path.join(d, 'sdlog', 'speech-dispatcher.log'), errors='replace').read().split('\n')
cur = None
for i, l in enumerate(lines):
    m = rx.match(l)
    if m:
        cur = m.group(1) + '.' + m.group(2).zfill(6); body = m.group(3)
        if 'Command caught: "speak"' in body or 'Command caught: "char"' in body or 'Command caught: "key"' in body or 'Command caught: "cancel"' in body:
            if a <= cur <= b: print(cur, body.strip())
    else:
        s = l.strip()
        if s in ('701 BEGIN', '702 END', '703 CANCELED') and cur and a <= cur <= b:
            print(cur, s)
