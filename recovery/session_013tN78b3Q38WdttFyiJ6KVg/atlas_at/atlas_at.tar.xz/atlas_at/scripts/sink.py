#!/usr/bin/python3 -I
# REP real-time audio sink: reads s16le mono 22050 Hz PCM from speech-dispatcher's ALSA file pipe on stdin
# and consumes it at real-time rate (so cancel/interrupt behave as with a real sound card).
# Writes REP_AUDIO_DIR/sink.log (burst start/end) and REP_AUDIO_DIR/audio_last (epoch of last consumed chunk).
import os, sys, time
d = os.environ.get('REP_AUDIO_DIR', '/nonexistent')
BPS = 44100.0  # bytes per second
log = open(os.path.join(d, 'sink.log'), 'a', buffering=1)
last_path = os.path.join(d, 'audio_last')
log.write('%.6f open pid=%d\n' % (time.time(), os.getpid()))
t_play = 0.0; in_burst = False; prev = 0.0; nbytes = 0
while True:
    chunk = os.read(0, 2048)
    if not chunk:
        break
    now = time.time()
    if not in_burst or (now - prev > 0.3 and now > t_play + 0.3):
        if in_burst:
            log.write('%.6f end bytes=%d\n' % (prev, nbytes))
        log.write('%.6f start\n' % now); in_burst = True; nbytes = 0
    t_play = max(t_play, now) + len(chunk) / BPS
    nbytes += len(chunk)
    wait = t_play - time.time()
    if wait > 0:
        time.sleep(wait)
    prev = time.time()
    if not chunk.strip(b'\x00'):
        continue  # pure digital silence: not speech
    try:
        with open(last_path, 'w') as f:
            f.write('%.6f' % prev)
    except OSError:
        pass
if in_burst:
    log.write('%.6f end bytes=%d\n' % (prev, nbytes))
log.write('%.6f close\n' % time.time())
