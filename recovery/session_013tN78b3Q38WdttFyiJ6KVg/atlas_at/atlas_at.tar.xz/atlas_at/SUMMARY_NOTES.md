# Notes on the generated summary.json / summary.md files (from the criteria critic, applied in the posted text)

- `L_atlas_status_update` and `L_current_state_update` are not valid measurements in the executor runs. Orca's flood pruning
  (`event_manager.py:388-392, 724-749`) dropped the JS-written status events at load-complete in every executor run, and the variant's
  "PASS" came from Orca's automatic Say All on load. The replicator, whose stack was not flooded, heard both texts announced at
  load in base and in variant. The posted result makes no base-versus-variant load claim.
- BASE1 `T6_equation_count` = NOT_OBSERVED means "invalid input, not counted" (`proof` matches all 108 excerpts); keys were delivered.
- SEL1 tasks other than T4 = NOT_OBSERVED mean "not run" (SEL1 runs the View task only).
- SEL1 `T4_view_select` PASS covers only the first option ("Graph"): in executor runs popup Down/Up never moved focus (pointer over popup).
