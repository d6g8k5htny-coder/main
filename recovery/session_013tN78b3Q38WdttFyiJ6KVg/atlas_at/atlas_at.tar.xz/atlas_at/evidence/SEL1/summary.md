# SEL1 (tree var2)

| Task | Verdict | Spoken (Orca to speech-dispatcher) |
|---|---|---|
| L_atlas_status_update | PASS | 'Loading the current pinned graph…' / 'Source snapshot 2026-10-13T14:56:55Z · Math dbe6c0a1 · 49 nodes, 55 edges (42 required). ' |
| L_current_state_update | FAIL | 'Pinned source observation: 2026-10-13T14:56:55Z. Compare this timestamp with the present time; observation is not scien |
| T1_browse | NOT_OBSERVED |  |
| T3_where_am_i | NOT_OBSERVED |  |
| T2a_say_all | NOT_OBSERVED |  |
| T2b_current_state_browse | NOT_OBSERVED |  |
| T2b_current_state_where_am_i | NOT_OBSERVED |  |
| T2b_current_state_say_all | NOT_OBSERVED |  |
| T4_view_select | PASS | 'tab' / 'View combo box.' / 'Graph.' / 'opens menu' / 'Graph.' / '1 of 2.' |
| T5_atlas_search_update | NOT_OBSERVED |  |
| T6_equation_count | NOT_OBSERVED |  |
| T7_3d_status | NOT_OBSERVED |  |
| T7_3d_off | INFO |  |
