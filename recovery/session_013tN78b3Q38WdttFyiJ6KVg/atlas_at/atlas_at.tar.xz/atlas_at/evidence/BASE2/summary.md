# BASE2 (tree base)

| Task | Verdict | Spoken (Orca to speech-dispatcher) |
|---|---|---|
| L_atlas_status_update | FAIL | 'Loading the current pinned graph…' |
| L_current_state_update | FAIL | 'Pinned source observation: 2026-10-13T14:56:55Z. Compare this timestamp with the present time; observation is not scien |
| T1_browse | FAIL | 'statusbar.' / 'blank' |
| T3_where_am_i | FAIL |  |
| T2a_say_all | FAIL | '+' / 'Find a claim. ' / 'Follow its dependencies. ' / 'Read the sources.' / 'statusbar' / 'Expand one frontier of the loaded neighborhood' |
| T2b_current_state_browse | FAIL | 'statusbar.' / 'blank' |
| T2b_current_state_where_am_i | FAIL |  |
| T2b_current_state_say_all | FAIL | '+' / 'Source observation' / 'statusbar' / 'Sources and scope' / 'toggle button' / 'collapsed' |
| T4_view_select | FAIL | 'tab' / 'View combo box.' / 'opens menu' / '1 of 2.' / 'opens menu.' / 'left alt' |
| T5_atlas_search_update | PASS | '49 displayed · 49 matching source nodes of 49 indexed source nodes · 0 outside this page Optional 3D uses this same sou / '30 displayed · 30 matching source nodes of 49 indexed source nodes · 0 outside this page Optional 3D uses this same sou / '21 displayed · 21 matching source nodes of 49 indexed source nodes · 0 outside this page Optional 3D uses this same sou |
| T6_equation_count | FAIL | 'Screen reader off.' |
| T7_3d_status | PASS | 'space' / 'pressed' / '3D · 21 displayed nodes · 7 recorded relationships · Math dbe6c0a1. Same filtered page as Graph and List.' |
| T7_3d_off | INFO | 'space' / 'not pressed' |
