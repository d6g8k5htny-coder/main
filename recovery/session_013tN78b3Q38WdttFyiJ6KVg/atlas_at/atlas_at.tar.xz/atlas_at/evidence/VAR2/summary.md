# VAR2 (tree var)

| Task | Verdict | Spoken (Orca to speech-dispatcher) |
|---|---|---|
| L_atlas_status_update | PASS | 'Loading the current pinned graph…' / 'Source snapshot 2026-10-13T14:56:55Z · Math dbe6c0a1 · 49 nodes, 55 edges (42 required). ' |
| L_current_state_update | FAIL | 'Pinned source observation: 2026-10-13T14:56:55Z. Compare this timestamp with the present time; observation is not scien |
| T1_browse | PASS | "Source snapshot 2026-10-13T14:56:55Z · Math dbe6c0a1 · 49 nodes, 55 edges (42 required). Classifications are the graph' / 'recorded values. No scientific status inferred.' |
| T3_where_am_i | PASS | "Source snapshot 2026-10-13T14:56:55Z · Math dbe6c0a1 · 49 nodes, 55 edges (42 required). Classifications are the graph' / "Source snapshot 2026-10-13T14:56:55Z · Math dbe6c0a1 · 49 nodes, 55 edges (42 required). Classifications are the graph' |
| T2a_say_all | PASS | '+' / 'Find a claim. ' / 'Follow its dependencies. ' / 'Read the sources.' / 'Source snapshot 2026-10-13T14:56:55Z · Math dbe6c0a1 · 49 nodes, 55 edges (42 required). ' / "Classifications are the graph's " |
| T2b_current_state_browse | PASS | 'Verified source observation: 2026-10-13T14:56:55Z · stale. This observation is more than two hours old; check upstream  |
| T2b_current_state_where_am_i | PASS | 'Verified source observation: 2026-10-13T14:56:55Z · stale. This observation is more than two hours old; check upstream  |
| T2b_current_state_say_all | PASS | '+' / 'Source observation' / 'Verified source observation: 2026-10-13T14:56:55Z · stale. ' / 'This observation is more than two hours old; check upstream sources.' / 'Sources and scope' / 'toggle button' |
| T4_view_select | FAIL | 'tab' / 'View combo box.' / 'opens menu' / '1 of 2.' / 'opens menu.' / 'left alt' |
| T5_atlas_search_update | PASS | '49 displayed · 49 matching source nodes of 49 indexed source nodes · 0 outside this page Optional 3D uses this same sou / '21 displayed · 21 matching source nodes of 49 indexed source nodes · 0 outside this page Optional 3D uses this same sou / '21 displayed · 21 matching source nodes of 49 indexed source nodes · 0 outside this page Optional 3D uses this same sou |
| T6_equation_count | FAIL | 'Screen reader off.' |
| T7_3d_status | PASS | 'space' / 'pressed' / '3D · 21 displayed nodes · 7 recorded relationships · Math dbe6c0a1. Same filtered page as Graph and List.' |
| T7_3d_off | INFO | 'space' / 'not pressed' |
