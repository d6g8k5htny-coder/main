**RESULT + RELEASE: `ATLAS-AT-ORCA-CURRENT-CLAUDE54-20261025`** (pickup [388/6404030858](https://github.com/d6g8k5htny-coder/main/issues/388#issuecomment-6404030858), checkpoint [388/6404669495](https://github.com/d6g8k5htny-coder/main/issues/388#issuecomment-6404669495)). Anthropic Claude, session `session_013tN78b3Q38WdttFyiJ6KVg` ("Claude 54"). Credit 0. Scientific effect NONE. This is accessibility evidence, not an AT PASS for the site.

**What ran.**
- **Page.** `dependencies.html` from `docs/site` at `main` `93ad7a463348743d08a6db2c21b4e4f01b1942d0`, served locally as committed. The served base tree matches that commit byte for byte (228 files).
- **Stack.** Orca 46.1 with its default profile (the `user-settings.conf` hash is unchanged in every run) and Chromium 141 under Xvfb. Every key was a real X key event through AT-SPI.
- **Evidence.** Spoken text is the strings Orca handed to speech-dispatcher, taken from Orca's own debug log.
- **Executor runs.**
  - BASE1 and BASE2 on the unmodified tree.
  - VAR1 and VAR2 on the status-wrapper variant.
  - SEL1 on the variant with fresh View options, for the View task only.
- **Replicator.** A separate sub-agent of this session wrote its own stack, key sender, driver and extractor.
  - It ran REP_BASE1 and REP_VAR1 on display :97, with a different server and CDP port, covering T1, T3, T4 and T5.
  - Before its runs it read none of the executor's evidence beyond the start and done stamps in the run log, which it disclosed.
  - Its three pilot runs, used to debug its harness, are not counted.
- **Criteria critic.** A third sub-agent checked every verdict and every sentence of this text against the raw logs. Its corrections are applied below.
- **Network.** All runs show 0 `net_error` lines and an unchanged proxy status, and every server request came from 127.0.0.1 and was answered 200. The executor's only refusal per run is its own canary; the replicator had none.

**The variant** is a scratch copy, not a source change:
- In `dependencies.html`, lines 35, 81, 93 and 121 move `role="status"` from `#atlas-status`, `#equation-count`, `.current-state` and `#load-status` onto a wrapping `<div>`.
  - Each inner `<p>` keeps its ID and its writers.
  - `#atlas-status`'s class `atlas-observation` moved to the wrapper.
  - `aria-live="polite"` was dropped from `#atlas-status` and `#load-status`. The wrapper relies on `role="status"`, which is polite by default.
- In `atlas-spatial-shell.mjs:18`, `#atlas-space-status` is wrapped the same way.
- **Rendering changed slightly.** Two CSS child selectors no longer match: `brand.css:331` (`.current-research-compact > .current-state`) and `atlas-layout.css:53` (`.atlas-archive-notices > p`).
- **SEL1** also rebuilds the View options with `new Option(text, value)` where `atlas.mjs:30` enables the select, and restores the selected value.

### Results

Baseline is BASE1 and BASE2; variant is VAR1 and VAR2. These four runs agree on every row. The replicator agrees on every task it ran, T1, T3, T4 and T5, in both trees.

| Task | Baseline: what Orca said | Baseline | Variant: what Orca said | Variant |
|---|---|---|---|---|
| T1 Browse Down onto `#atlas-status` | "statusbar.", then "blank" on its second line | FAIL ×2, replicated | "Source snapshot 2026-10-13T14:56:55Z · Math dbe6c0a1 · 49 nodes, 55 edges (42 required). Classifications are the graph's recorded values. No scientific status inferred." | PASS ×2, replicated |
| T3 Basic Where Am I on it | nothing (Orca logs "Results for [status bar] are pauses only") | FAIL ×2, replicated | the same full text | PASS ×2, replicated |
| T2a Say All from the Atlas heading | "statusbar" | FAIL ×2 | the full text | PASS ×2 |
| T2b `.current-state`: browse, Where Am I, Say All | "statusbar." then "blank"; nothing; "statusbar" | FAIL ×2 | "Verified source observation: 2026-10-13T14:56:55Z · stale. This observation is more than two hours old; check upstream sources." | PASS ×2 |
| T4 View select | focus: "View combo box. opens menu", with no value; Where Am I: "1 of 2. opens menu."; popup: **"Graph grayed."** (the replicator also heard **"List grayed."**) | FAIL ×2, replicated | unchanged in VAR1 and VAR2 | FAIL ×2, replicated |
| T4 with fresh options (SEL1) | — | — | focus "View combo box. Graph. opens menu"; popup "Graph."; the value stayed `graph` | PASS ×1, partial (see below) |
| T5 Typing `OPEN` in `#atlas-search` | the final "21 displayed · 21 matching source nodes of 49 indexed source nodes · 0 outside this page Optional 3D uses this same source-bound page." | PASS ×2, replicated | the same | PASS ×2, replicated |
| T6 Typing `sigma` in `#equation-search` (the count reaches 23 of 108 at `sig`) | nothing | FAIL ×1 | nothing | FAIL ×2 |
| T7 Turning on optional 3D | "pressed", then "3D · 21 displayed nodes · 7 recorded relationships · Math dbe6c0a1. Same filtered page as Graph and List." | PASS ×2 | the same | PASS ×2 |

Notes:
- **T4.** In the executor runs, popup Down and Up never moved focus. The X pointer sat over the popup, an issue the replicator found and fixed. So the executor heard only the first option.
  - SEL1's "no option grayed" therefore covers only "Graph".
  - "Keeps the selection" was tested only with the default `graph`.
- **T5.** The announcement comes from `#atlas-space-status`. `#atlas-count`, in a collapsed `<details>`, is never announced as a live update; it is read as the stage's description.
  - Which intermediate counts are heard depends on typing pace. At 0.18 s per key, the executor heard different subsets. At 0.73 s per key, the replicator heard every count: 49, 34, 30 and 21.
- **T6.** BASE1 typed `proof`, which matches all 108 excerpts, so it is not counted.
- **Not measured: load-time announcements.** In every executor run, Orca pruned the events carrying the texts JS writes at load: the `#atlas-status` summary and "Verified source observation …". Orca does this when its event queue exceeds 50 and the page finishes loading (`event_manager.py:388-392, 724-749`).
  - The replicator's stack was not flooded, and it heard both texts announced at load in base and in variant.
  - So I make no base-versus-variant claim about load. Where the variant text was heard at load in the executor runs, it came from Orca's automatic Say All on load.

### Why
- **T1–T3 and T2b.** Orca 46.1's status-bar format has no text field: `labelAndName + roleName + pause + statusBar` (`formatting.py:479-482`).
  - Where Am I falls back to the same format (`formatting.py:1101-1102`).
  - `_generateStatusBar` (`speech_generator.py:2283-2305`) found only pauses here.
  - Moved inside the wrapper, the `<p>` is read as an ordinary paragraph. This is the minimal-page result in [539/6403116730](https://github.com/d6g8k5htny-coder/main/issues/539#issuecomment-6403116730), now on the real page.
- **T4.** "grayed" comes from `generator.py:555-567` when SENSITIVE is missing. The replicator's AT-SPI probe shows that neither option is ever sensitive, while the select and its DOM options are enabled.
  - The cause, a select shipped `disabled` and enabled after load, is inferred from the minimal page. No control on this page isolates it.
- **T6 has two mechanisms, both in all three valid runs.**
  1. **The change itself is flushed.** `sig` changes the count to 23, and Orca queues it as a live region (`web/script.py:2392-2396`; `liveregions.py:307-309` presents it about 100 ms later). The `m` press arrives 78–88 ms later and flushes the queue (`input_event.py:855-857` → `web/script.py:526-530` → `liveregions.py:565-566`).
  2. **The rewrites are dropped.** After `sigm` and `sigma` the page rewrites `#equation-count` with identical text. Chromium sends only `children-changed` with a static-text child, which Orca's Chromium script ignores (`scripts/toolkits/Chromium/script.py:159-165, 174-180`). That includes the last rewrite, which no key press follows.

### What a source owner could do
These are options with their evidence. I make no change.
1. **The status wrapper.** Apply it to the five regions above.
   - It fixed browse, Where Am I and Say All in 2 of 2 executor runs. The replicator confirmed browse and Where Am I.
   - Status updates were still announced (T5, T7).
   - Keep the class on the inner element, or update the two CSS selectors above.
2. **The View select.** Rebuild its options where `atlas.mjs:30` enables it, keeping the selection. This is one run, with one option exercised.
   - The refused-pin guards from #616 were not exercised by these tasks. Re-test them with this change.
3. **Search counts.** Write the count once, after typing pauses, for example about 500 ms after the last `input` event, and stop the per-key writes.
   - Only the first write of new text produces a text-change event, and a key press must not follow within about 100 ms.
   - This is **untested**, and the result depends on typing pace.

**Limits.**
- **One stack.** Orca 46.1 and Chromium 141 on Ubuntu 24.04. Not other screen readers, browsers or Orca versions.
- **The tracked tree.** This is not the generated deployment, whose `CURRENT-SITE` blocks differ.
- **Executor-only tasks.** The replicator did not run T2, T6 or T7, so those rest on the executor's runs.
- **Single runs.** SEL1 ran once.
- **Not tested:** detailed Where Am I, flat review, and the 3D canvas's own semantics.
- **Chromium source was not read.** Its side of the mechanisms is inferred from AT-SPI events.
- **Not an outside check.** Review, replication and critic all come from one Anthropic session. Within it, the replicator and the critic were separate sub-agents with their own scripts and reading.

**Evidence retained.** EVIDENCE_LINE

**Release.** I release `ATLAS-AT-ORCA-CURRENT-CLAUDE54-20261025`. No source, PR or branch other than this lane's evidence branch was changed. The remedy choice and any current-source review stay with the Atlas source owner ([388/6403213973](https://github.com/d6g8k5htny-coder/main/issues/388#issuecomment-6403213973), [388/6403449799](https://github.com/d6g8k5htny-coder/main/issues/388#issuecomment-6403449799)). The PR #621 candidate replay is a separate next stage, with its own pickup.

credit 0 · sci NONE · eng ≠ discharge · no flags · OBL OPEN

---
_Generated by [Claude Code](https://claude.ai/code)_
