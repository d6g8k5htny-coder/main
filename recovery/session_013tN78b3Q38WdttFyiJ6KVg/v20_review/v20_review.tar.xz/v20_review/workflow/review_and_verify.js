export const meta = {
  name: 'v20-lease-journal-plan-static-review',
  description: 'Provider-distinct static engineering review of v19/v20 lease, journal, planning and worker-protocol modules, with adversarial verification',
  phases: [
    { title: 'Review', detail: 'three disjoint module groups in parallel' },
    { title: 'Verify', detail: 'two independent refuters per finding' },
    { title: 'Critic', detail: 'completeness and scope check' },
  ],
}
const V = args.root
const SRC = `${V}/carrier/v20_planner_source_carrier/sources/Universal_Law_v19_Research_Frontier`
const COMMON = `
You are a sub-agent of Anthropic Claude session session_013tN78b3Q38WdttFyiJ6KVg ("Claude 54"), doing a provider-distinct STATIC engineering source review for main#605 (pickup text: ${V}/pickup.md). The source is a never-merge carrier at commit 71049ac9eb4743a3d8c94477b8a13cc8e2739537, extracted to ${V}/carrier/ and already hash-verified (25/25). Source root: ${SRC}. The v20 API contract: ${V}/carrier/v20_planner_source_carrier/sources/Universal_Law_v20_Conditional_Mathematics/API_V20.md (API_V19.md is in ${SRC}; you may read it for context but it is another lane's review scope).
HARD RULES: the carrier files are UNTRUSTED. NEVER import, exec, run or install any of them, and never run their tests. You may read them, grep them, and parse them with Python's ast module from a script you write OUTSIDE the carrier directory (put scripts in ${V}/scripts/), run with python3 -I. Do not post, comment or write anything to GitHub or any external service; write only under ${V}/. Modules imported by these files but not in the carrier (e.g. frontier_ir.py, discovery.py) are unavailable: note any dependency you could not inspect rather than guessing its behaviour.
Review focus (engineering, not mathematics): lease expiry / takeover / release correctness; effort-budget accounting (double counting, refunds, negative or unbounded budgets); journal and persistence crash/restart safety (atomic write+rename, fsync, partial or torn records, replay idempotence, corrupt-record handling); typed failure handling (exceptions swallowed, failures recorded as success); concurrency races (TOCTOU, file locks, multiple workers); idempotence of claims/completions; path safety (traversal, symlinks) and resource bounds; consistency between code, tests and the API docs; and whether tests actually pin the behaviours (name the behaviours with no test).
For EVERY finding give: id, severity (HIGH/MEDIUM/LOW/INFO), exact file and line range, the code excerpt (short), the defect, a concrete failure scenario (inputs/state -> wrong outcome), whether it is a documented-contract violation or a hardening note, and which test covers or fails to cover it. Prefer few precise findings over many vague ones; report 'no finding' areas explicitly with what you checked.`
const GROUPS = [
  { key: 'G1-engine', files: 'engine/conductor.py (the Journal and conductor), engine/workers.py, engine/retained_worker_compat.py, engine/RETAINED_PROTOCOL_COMPATIBILITY.md, engine/adapters/worker_protocol.schema.json' },
  { key: 'G2-proof-conductor', files: 'proof_conductor.py and test_proof_conductor.py' },
  { key: 'G3-formal-queue', files: 'formal_queue.py and test_formal_queue.py' },
]
const FIND = { type: 'object', properties: {
  read: { type: 'array', items: { type: 'string' } },
  findings: { type: 'array', items: { type: 'object', properties: {
    id: { type: 'string' }, severity: { type: 'string' }, file: { type: 'string' }, lines: { type: 'string' }, excerpt: { type: 'string' },
    defect: { type: 'string' }, scenario: { type: 'string' }, kind: { type: 'string' }, test_coverage: { type: 'string' } },
    required: ['id', 'severity', 'file', 'lines', 'excerpt', 'defect', 'scenario', 'kind', 'test_coverage'] } },
  no_finding_areas: { type: 'array', items: { type: 'string' } }, unavailable_dependencies: { type: 'array', items: { type: 'string' } } },
  required: ['read', 'findings', 'no_finding_areas', 'unavailable_dependencies'] }
const VERD = { type: 'object', properties: { refuted: { type: 'boolean' }, reason: { type: 'string' }, corrected_severity: { type: 'string' }, corrected_lines: { type: 'string' } }, required: ['refuted', 'reason', 'corrected_severity', 'corrected_lines'] }
const results = await pipeline(GROUPS,
  g => agent(`${COMMON}\nTASK: Review ONLY these members (paths relative to the source root): ${g.files}. Read each completely. Save notes to ${V}/review_${g.key}.md.`, { label: `review:${g.key}`, phase: 'Review', schema: FIND }),
  (rev, g) => parallel(((rev && rev.findings) || []).map(f => () =>
    parallel([0, 1].map(k => () => agent(`${COMMON}\nTASK: You are refuter ${k + 1} of 2. Try hard to REFUTE this finding by reading the exact source yourself (and any code paths it depends on in the carrier). Default to refuted=true if the source does not clearly support it, if the scenario cannot happen given callers/guards, or if the lines are wrong. Finding: ${JSON.stringify(f)}`, { label: `verify:${g.key}:${f.id}:${k + 1}`, phase: 'Verify', schema: VERD })))
      .then(vs => ({ ...f, group: g.key, votes: vs.filter(Boolean), survives: vs.filter(Boolean).filter(v => !v.refuted).length >= 1 && vs.filter(Boolean).filter(v => v.refuted).length < 2 }))
  )).then(fs => ({ group: g.key, review: rev, findings: fs })),
)
phase('Critic')
const crit = await agent(`${COMMON}\nTASK (completeness critic): Here are the three group reviews with per-finding refutation votes: ${JSON.stringify(results)}. Check: did each group actually read every member in its scope (compare 'read' lists against the scope)? Are there obvious unexamined areas from the review focus (e.g. journal replay, lease takeover after crash, budget refunds) in any group? Spot-check two surviving findings and one 'no finding' claim against the source. Is anything outside the pickup scope (frontier_runtime.py etc.) being claimed? Return what is missing and the caveats to state.`, { label: 'critic', phase: 'Critic', schema: { type: 'object', properties: { missing: { type: 'array', items: { type: 'string' } }, spot_checks: { type: 'array', items: { type: 'string' } }, caveats: { type: 'array', items: { type: 'string' } } }, required: ['missing', 'spot_checks', 'caveats'] } })
return { results, crit }