# Merge refutation votes from wf_cee8c9e5-0db (snapshot) and the five verify2 part runs.
import json,sys,glob
S,WF=sys.argv[1],sys.argv[2]
b=json.load(open(S+'/verify2/A_results_snapshot.json'))
votes={k:v for k,v in b.items() if k.startswith('verify:')}
src={k:'wf_cee8c9e5-0db' for k in votes}
for run in sys.argv[3:]:
    label={}
    for l in open(f'{WF}/{run}/journal.jsonl'):
        d=json.loads(l)
        if d['type']=='started': label[d['key']]=d['label']
        elif d['type']=='result' and d['key'] in label and d['result']:
            votes[label[d['key']]]=d['result']; src[label[d['key']]]=run
results=[];missing=[]
for g in ('G1-engine','G2-proof-conductor','G3-formal-queue'):
    rev=b['review:'+g];fs=[]
    for f in rev['findings']:
        vs=[];
        for k in (1,2):
            lab=f"verify:{g}:{f['id']}:{k}"
            if lab in votes: vs.append(dict(votes[lab],refuter=k,run=src[lab]))
            else: missing.append(lab)
        nref=sum(v['refuted'] for v in vs); nkeep=len(vs)-nref
        fs.append(dict(f,group=g,votes=vs,survives=nkeep>=1 and nref<2,
                       status='UNVERIFIED' if len(vs)<2 else ('KEPT 2/2' if nref==0 else ('SPLIT 1/1' if nref==1 else 'REFUTED 2/2'))))
    results.append({'group':g,'review':rev,'findings':fs})
json.dump(results,open(S+'/verify2/merged.json','w'),indent=1,ensure_ascii=True)
print('missing',len(missing),missing)
for r in results:
    for f in r['findings']:
        print(f"{f['id']:7} {f['severity']:6} {f['status']:11} {' '.join(v['corrected_severity'][:12] for v in f['votes'])}")
