# G2: proof_conductor.py and test_proof_conductor.py, static engineering review

This review is for main#605, pickup `V20-LEASE-JOURNAL-PLAN-STATIC-CLAUDE54-20261025`. The source is carrier commit
71049ac9eb4743a3d8c94477b8a13cc8e2739537. Its root is `sources/Universal_Law_v19_Research_Frontier`.
I did not import, execute or test any carrier file. I read both members in full: proof_conductor.py has 818 lines
and test_proof_conductor.py has 656. For context only, I read engine/conductor.py lines 1-60 and 121-230
(Journal, canonical and mathematical_fingerprints), the frontier_runtime.py call sites, API_V19.md and API_V20.md.

I wrote two scripts, both outside the carrier and both run with `python3 -I`:
- scripts/g2_ast.py: an AST listing of the definitions and of the methods each test calls.
- scripts/g2_bytebound.py: an offline model of the byte estimate in `_append` against the bytes Journal writes. It
  reimplements the one-line `canonical`.

API_V20 contains no clause that governs this module. It says only that the v20 CLI does not "replace the
foundation's durable conductor". I compared against API_V19 for context, but API_V19 is another lane's scope.

## Findings, most severe first

### G2-01 MEDIUM: changing one completed artifact makes the whole conductor unreadable for good
Lines 476-478, 657-659, 719-721 and 746-749. Replaying SCALAR_PILOT_COMPLETED recomputes the completion from the
receipt and the project/ tree on disk. Only two current states fall back to history: a 'blocked' backend and a
stale profile. Any other mismatch raises out of `_read`:
- receipt missing or oversized
- profile-key mismatch
- invalid verification
- tree hash differs, which raises 'forged scalar completion'
- more than 32 files

Scenario: a completion is recorded. Then receipt.json is deleted, or one stray file is added under
artifacts/claim-X/project/. The worker can write there, and so can operator cleanup or a partial copy. After that,
ProofConductor(workdir) raises in `__init__` (snapshot -> _read). Every claim, failure, blueprint and snapshot call
fails, for unrelated tasks too. frontier_runtime.py:78 builds the conductor in its own `__init__`, so the runtime
cannot start either.

API_V19:43-46 says a historical pass "cannot mask a current blocked/invalid/stale verdict" and that these axes are
shown separately. Here the "invalid" axis cannot be shown at all: it becomes a global outage. This is a hardening
note, partly in tension with that contract. Test coverage: the relocation test (455-470) copies an intact tree
only. No test deletes, modifies or extends a completed artifact tree.

### G2-02 MEDIUM: the byte guard on append can admit a write that the read guard then rejects forever
Lines 541-546 against 415-417. The append check adds `len(str(payload))`, the Python repr of the payload alone.
Journal.append (engine/conductor.py:188-193) writes the canonical JSON of the whole envelope
(seq/when_utc/type/payload/prev_hash/event_hash) plus a newline.

The model in scripts/g2_bytebound.py measured these undercounts:

| Event | Undercount |
| --- | --- |
| TASK_CLAIMED | 230 bytes |
| FAILURE_REPORTED, no evidence | 206 bytes |
| FAILURE_REPORTED, evidence `{'r':'"'*15000}` (30,008 canonical bytes) | 15,205 bytes |

Scenario: the journal is at 33,538,216 bytes. That failure report passes the guard, and the file becomes
33,569,637 bytes, which is MAX + 15,205. From then on every `_read` raises 'conductor journal byte bound exceeded',
including snapshot and `__init__`. Without quote-heavy evidence, any append within about 200 bytes of the bound
still overshoots.

The bound is reachable: up to 1000 claims, each with up to 32 KiB of evidence, comes to about 32 MiB, before the
IR and blueprint events. I could not check how bounded_json measures size (frontier_ir is unavailable), but the
example above is under 32,768 bytes either way. This is a hardening note. Neither MAX_JOURNAL_BYTES nor MAX_EVENTS
has a test.

### G2-03 MEDIUM, test coverage: the live rejection of a failed native verification is never reached
Lines 695-698, 715-724 and 652-656. The "false receipt" case in the test (626-629) has no project/ tree, so the
tree check at 666-667 rejects it first. The message 'invalid receipt artifact tree' satisfies the regex
'verification|receipt|replay'.

Because of that, no test reaches any of these:
- the live raise at 720-721
- the profile-key check at 696-698
- the backend-changed check at 715-718
- the receipt-changed check at 723-724

The symlink subtest (622-625) points outside the assigned directory. The resolve check at 650 catches it first, so
the walk at 652-656 is not pinned either.

Static mutation reasoning (not executed): deleting 719-721 would journal a completion whose verification has
valid=False. Line 504 would then lock that task out of every future claim, and snapshot would label it
'historical_scalar_pilot_replay_blocked'. No test would fail.

### G2-04 LOW: a lapsed investigation claim lets the fixed native worker run again after a mathematical failure
Lines 364-371 and 381-383. `_technical_retry` treats any expired, unreported latest claim as a technical retry,
whatever its strategy.

Scenario: the native claim is reported as false_lemma. The next claim gets counterexample_audit, and that lease
lapses. A later `claim(strategy='native_scalar_profile')` is then accepted, both live and on replay.

This bypasses the invariant that test 443-453 pins. It also departs from `_decision`, which allows a technical
retry only after checker_failure or timeout. Mathematical authority is not affected: completion still needs a real
native replay. No test covers an intervening lapsed claim.

### G2-05 LOW: leases use the wall clock with no monotonic guard
Lines 578-584, 532, 687, 766 and 512.

Scenario: P's lease expires at 1060. Q takes over at 1070. The clock then steps back to 1040. P's idempotent
re-claim returns P's own claim as active (line 580), and P's failure report is accepted (line 532) while Q still
holds the task. Replay does not check that timestamps are non-decreasing. No test covers this.

### G2-06 LOW: idempotent redelivery has gaps
Lines 610-616 and 684-685:
- The stale check in `submit_failure` runs before its idempotent-return path. A retry after the task goes stale
  therefore raises instead of returning the recorded attempt.
- A duplicate `complete_claim` raises 'no longer pending'. frontier_runtime has its own reconcile path.

Test coverage: test 187-194 covers non-stale redelivery only. The duplicate complete at 591 is stopped by the stale
check, so it does not test this.

### G2-07 LOW: snapshot advertises tasks and strategies that claim() then rejects
Lines 800-802 against 509-510 and 385-386:
- `claimable` ignores an exhausted budget. Test 137-138 relies on this.
- `recommended_strategy` can name a strategy already used by an expired claim. With no decision recorded, it falls
  back to 'dependency_decomposition'. claim(strategy=recommended) then raises 'previously attempted', while
  claim(None) picks 'scope_guidance'.

### G2-08 LOW, test coverage: one subtest is vacuous and one replay check is unpinned
- In test 220-221, the subtest with `lease_seconds=True` passes even without line 568. The task is already leased by
  'worker', so the call raises 'already leased' anyway.
- The artifact_directory check at 494-496 is unpinned. Test 352-365 changes the claim_id too, so line 489 rejects
  the claim first.

### G2-09 LOW: the receipt path checks can be raced, and the tree scan is unbounded
Lines 652-673:
- The symlink walk and size stat are separate from `read_bytes`, which follows links. If the worker swaps the file
  for /dev/zero or a FIFO after the check, the read is unbounded or blocks while all global locks are held.
- `sorted(project.rglob('*'))` lists the whole tree before the 32-file bound.
- A FIFO, socket or device in the tree is skipped silently: it is neither hashed nor rejected.

### G2-10 LOW: every `_read` re-verifies all completions while holding the global locks
Lines 415-481 and 707-714:
- Every call re-hashes up to 64 MiB of artifacts per completion, rescans up to 20,000 backend entries, and runs a
  full native replay when the cache is cold (each new process, and frontier_runtime line 435).
- Timestamps are taken after the locks are acquired, at lines 578, 618 and 763. A lease holder waiting on another
  process's replay can lose its lease.

### G2-11 INFO: gaps in the backend identity behind the positive-verification cache
Lines 82-91, 104-106, 117-125 and 707-713:
- Files are read with lstat only, so a pinned file that is a symlink to a target outside bin/ and lib/ is
  identified by its link text alone.
- A truncated scan of 20,000 entries still produces a signature the cache accepts.
- Environment variables such as search paths are not part of the identity. verify_proof_receipt is unavailable, so
  I could not check whether it isolates them.

The cache lives in memory, per process.

### G2-12 INFO: edges that fail closed but untyped, or leak resources
- If the coordinator and the conductor share a workdir, `__init__` deadlocks on itself. The second open file
  description flocks the same .journal.lock (lines 317-323), and nothing guards against this.
- If `mkdir` succeeds and then the append fails or the process crashes, an orphan artifacts/claim-* directory is
  left behind (593-596).
- These raise untyped errors where callers expect ValueError:
  - OSError from `is_symlink` or `mkdir` outside a try (595, 654)
  - RecursionError from a deeply nested receipt (661)
  - TypeError from forged unhashable IDs on replay (486, 521, 743)

## Areas with no finding, and what I checked
- **Budget accounting.**
  - Every TASK_CLAIMED is charged exactly once, live and on replay (509-510).
  - An idempotent re-claim by the same agent is not charged again (580-584).
  - There is no refund path.
  - The limit is fixed by the first blueprint, and increases are rejected both live (558-559) and on replay
    (456-459).
  - A duplicate blueprint returns the existing one (553-557).
  - The budget is bounded to 1..1000 (174), and remaining is never negative.
  - The attempt cap is 4 (379-380).
- **Cross-process lease exclusion.** `now`, the active set and the lease overlap are all computed under the engine
  mutex plus both flocks, after a fresh journal reload (571-596). Replay re-checks overlap (511-513), and the
  process-contention test pins the single winner.
- **Lease window.** The window is half-open, [claimed_at, expires_at), for failures (532) and completions (687 and
  766).
- **Replay determinism.** For claims and failures, `_strategy` and `_decision` take the recorded timestamps
  (`at=claimed_at`), not the current clock.
- **Typed decisions.** Diagnoses are checked against a whitelist (601 and 528). The decision is recomputed and
  compared on replay (537-539). A failure after a completion, and a completion after a failure, are both rejected.
- **Crash points.** All three recover:
  - mkdir then append: leaves only an orphan directory.
  - IR_REGISTERED then BLUEPRINT_CREATED: replay accepts the IR on its own, and re-registration is skipped.
  - native replay then append: the claim stays pending.
- **Path safety.**
  - The claim_id regex is enforced at 489.
  - The assigned directory is derived from claim_id, not from the stored path (643).
  - The receipt check combines a '..' rejection with lexical and resolved containment (645-651).
- **Lock order.** It is consistent: engine mutex, then engine journal, then the conductor journal.

## Dependencies I could not inspect
These are not in the carrier:
- frontier_ir.py: compile_ir, validate_ir, digest, bounded_json, EFFECTS
- engine/model.py: load, fingerprints
- polynomial_prover.py: profile_contract, verify_proof_receipt, prove_profile
- toolchain_setup.py: default_toolchain
- formal_lane.py: _pins

intelligence.py (MILESTONES) and flow.py are in the carrier but outside this lane's scope, and I did not review
them.

Replay equality depends on verify_proof_receipt returning output that is deterministic and JSON-typed. It also
depends on that output matching the literal at lines 729-731. I could not check either property.

The Journal's own durability belongs to the engine/conductor lane. That covers fsync without a directory fsync, a
torn tail that fails closed with no repair path, and no bound on the initial load.
