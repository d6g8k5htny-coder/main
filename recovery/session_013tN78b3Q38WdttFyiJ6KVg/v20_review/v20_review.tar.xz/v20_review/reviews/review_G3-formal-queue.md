# G3 static engineering review: formal_queue.py and test_formal_queue.py

Lane: V20-LEASE-JOURNAL-PLAN-STATIC-CLAUDE54-20261025 (main#605). Carrier commit 71049ac9eb4743a3d8c94477b8a13cc8e2739537, members hash-verified upstream (25/25).
Source root: `carrier/v20_planner_source_carrier/sources/Universal_Law_v19_Research_Frontier/`.
Method: both files read in full; the API_V20.md contract read in full (it says nothing specific about the formal queue apart from line 76, "the preserved dashboard/queue runs against its own writable runtime copy"); API_V19.md read for context only (its "native jobs ... relative authoritative paths" sentence is about frontier_runtime, not this queue); workspace.py call sites read for context only (formal_queue.py lines 41, 65, 73, 134 and 280-287; owner token gate at 258).
Nothing from the carrier was imported, executed or tested. Scripts are in `scratchpad/v20rev/scripts/`:
- `g3_ast.py`: an AST inventory. Every `_read`, `_append`, `_slot` and `_recover` call sits lexically inside `with self._locked()`, or inside a helper that is called only from locked code.
- `g3_semantics.py`: independent probes of Python and OS behaviour (python 3.11.15). They covered `bytes.splitlines` boundaries against canonical JSON escaping, flock locking per open file description, flock after the lock file is unlinked, head-sequence indexing, lone surrogates, and AttributeError on `.get`.

Dependencies I could not inspect: `formal_lane.py` (`run_profile`, `verify_receipt`, `_digest`, `_profile`, `_sources`, `_pins`, `PROFILE_ID`, `PROFILE_SHA256`, `PINS_SHA256`, `SOURCE_ROOT`) and `toolchain_setup.py` (`default_toolchain`). Three things therefore remain unknown:
- the run timeout and process-group handling, which bound how long a lease is held and whether orphaned Lean children survive;
- how the receipt is built and what `receipt_path` is;
- the reason codes used in the tests (toolchain_missing, toolchain_integrity_mismatch).

## Findings (most severe first)

### G3-F1 MEDIUM: an exception that is not a JournalError kills the background worker thread silently, and the queue stalls for good
- formal_queue.py:305-329 and 397-406 (start() 408-416).
- `claim = self._claim()` (306) sits outside any try block. The fallback `self._complete(...)` (326) runs inside `except Exception`. `_worker` catches only `JournalError` (402-404).
- Trigger: a transient ENOSPC, EIO or EMFILE during `_claim`. The candidates are `attempt_dir.mkdir` (279), `_sync_directory` (280-281), the journal write in `_append` (288 to 167-170), and the head `_atomic` (171).
- Path: the error leaves `_run_one`, then `_worker`, and the thread ends. The default `threading.excepthook` prints to stderr only.
- Why it stays stalled: workspace calls `start()` once (workspace.py:65), and max_workers is 1. `start()` respawns threads only when all of them are dead and someone calls it again.
- What the user sees: enqueue() still returns `queued` and snapshot() shows `queued` indefinitely. Nothing is journaled.
- A second trigger: the fallback `_complete` at 326 raises again. This happens when the first failure recurs, or when the fsync walk at 377-382 meets a file it cannot open.
- A side effect: slot.close() (328) runs outside the journal lock while the job is still `running`. A concurrent `_claim` whose `_recover` saw that slot held can then take the freed slot for another job. Two jobs then show `running` on one slot, and recovery of the first is postponed until the slot frees again.
- Kind: typed-failure and liveness hardening. No documented formal-queue contract covers this.
- Test coverage: none. test_worker_exception_is_durable_failure_and_retry_is_fresh (test 100-112) injects only into run_profile, inside the inner try where the first `_complete` succeeds. It also uses synchronous run_pending rather than `_worker`.

### G3-F2 MEDIUM (test coverage): no individual check in the receipt acceptance gate is pinned
- formal_queue.py:344-370 against test_formal_queue.py:198-210 and 252-272.
- The only test that reaches the gate without Lean submits `{'status':'scoped_kernel_checked','profile_id':'different-profile','full_theorem_certificates':[]}`. That result fails at line 351, and would also fail the statements digest (351), scope and pins (353), verification flags (355), and the missing receipt_path (357, KeyError). The test asserts only `reason_code == 'receipt_rejected'`.
- Consequence: deleting any one of these checks keeps the non-real suite green:
  - input changed before acceptance (346-347);
  - profile, source or alignment fields (348-351);
  - statements digest;
  - scope and checker pins (353);
  - the `valid`, `fresh_replay` and `state` requirement (355-356);
  - the symlink and containment fence (357-359);
  - file equals result (360-361);
  - receipt digest (362-363).
- The unsupported-status branch (368-370) is never reached by any test.
- RealQueueTests (252-272) covers only the accept path and is skipped without the pinned Lean.
- Kind: test-coverage gap on the safety-critical gate. The code itself looks correct for each check as written.

### G3-F3 LOW: a rejected receipt keeps a passing-looking `verification`, and retry and recovery carry stale receipt and verification forward
- formal_queue.py:365-367 and 386-387 (`verification=verification` is stored even after rejection), 256 (retry clears only status, reason_code and reason), 199-201 (recover does not clear them).
- Scenario:
  1. run_profile returns `scoped_kernel_checked`, and verify_receipt returns `{'valid': True, 'fresh_replay': True, 'state': 'scoped_kernel_checked'}`.
  2. The owner edits a pinned Lean source during the run, so 346-347 raises.
  3. The job is now `failed`/`receipt_rejected`, yet `job['verification'].valid` is True and its state is `scoped_kernel_checked`.
  4. After retry(), the job is `queued`, then `running`, and possibly `escalated` after a lease_recovered. It carries that object the whole time.
- workspace.formal_state passes jobs through unchanged (workspace.py:134-140). I could not inspect the UI.
- Kind: hardening, an inconsistency between the status and verification axes. `status` and `full_theorem_certificates` stay correct.
- Test coverage: test 198-210 passes `{'valid': True}` and never asserts `job['verification']`. No test checks what retry clears.

### G3-F4 LOW: truncation detection fails open whenever head.json is absent, or head.sequence is ≤0 or a bool
- formal_queue.py:139-146.
- `if self.head.exists(): ... if sequence > last or (sequence and events[sequence-1]['sha256'] != head['sha256'])`, with `elif state['events']: pass`.
- The code's own comment admits a missing head only for the first append. After that, `_append` always rewrites head atomically, so a missing head with last_sequence > 1 is never legitimate.
- Scenario: delete head.json and drop the trailing complete lines, for example a job's last `attempt_finished` and `retry_requested`.
  - snapshot() accepts the rolled-back state.
  - The next `_append` rewrites head at the rolled-back sequence, which hides the rollback.
  - The attempts list reverts, which defeats MAX_ATTEMPTS.
- Other inputs: `{"sequence":0}` disables the check, and `-1` compares events[-2] (shown by the probe).
- The chain is an unkeyed sha256, so a consistent rewrite is always undetectable. This is defence in depth against accidental or naive loss, not against an adversary.
- Kind: hardening.
- Test coverage: test 212-222 covers truncation only while head.json is present.

### G3-F5 LOW: a crash during the very first journal append loses the configured max_workers permanently
- formal_queue.py:102-106 with 149-160 and 133-134.
- Scenario:
  1. FormalQueue(w, max_workers=4) dies partway through writing event 1, leaving a partial line and no head.
  2. On restart, `_read` moves the tail aside and appends `torn_tail_recovered` as sequence 1.
  3. `state['events']` is no longer empty, so `configured` is never written.
  4. max_workers falls back to the default of 1, and line 133-134 forbids any later `configured` event.
- The journal never gets its configuration record.
- Impact: availability and configuration only, and in the conservative direction. workspace always uses 1.
- Test coverage: none. Test 240-249 writes its tail only after the configured and enqueued events exist.

### G3-F6 LOW: no lease expiry, heartbeat or in-flight cancellation; stop() and the journal lock have no timeout
- formal_queue.py:282-283 (lease records a `pid` that nothing uses), 305-329, 418-423 (`thread.join()` without a timeout), 109-116 (blocking `LOCK_EX`).
- Takeover happens only when the holding file descriptor closes or the process dies. This is by design, and it is safe.
- A hung `run_profile` keeps the slot and leaves the job `running` indefinitely. Its run bound lives in formal_lane, which I could not inspect.
- The `_stop` flag is not consulted during a run. workspace.stop_services() calls formal_queue.stop() first (workspace.py:72-73), so a server shutdown waits for the whole kernel run.
- Any holder of journal.lock that stalls blocks every snapshot() and enqueue(), including HTTP handler threads. A stalled holder means a SIGSTOP'd process, or the fsync walk over the attempt tree under the lock at 377-382.
- Kind: hardening, dependent on formal_lane.
- Test coverage: none. Test 114-132 sets the gate before stop() (130-131).

### G3-F7 LOW: unbounded journal growth, and a full replay on every 0.2 s poll
- formal_queue.py:219-225, 251-258 and 118-125 with 397-406.
- Each new event_id on an active job appends the whole job together with its growing `event_ids`. Total size is about n·B + ~203·n(n+1)/2 bytes, where event_id is at most 200 characters (207): roughly 100 MB at n=1e3 and roughly 10 GB at n=1e4.
- retry() on an `escalated` job is accepted, even though the 252 message says only blocked or failed jobs can be retried. It re-escalates and appends a full job event, including the last receipt (about 22 KB in the retained example), on every call.
- Every operation, including each worker's 0.2 s poll, reads and re-hashes the whole journal under the exclusive lock.
- The routes are gated by the owner token (workspace.py:258). With F1, a stalled worker keeps a job active indefinitely, so the dedup growth does not even need a long Lean run.
- Kind: a resource-bound hardening note.
- Test coverage: none.

### G3-F8 LOW (test coverage): the "global bound" test never exercises the slot bound, and several behaviours are unpinned
- test_formal_queue.py:134-157.
- The only job is `running`. `other.enqueue` deduplicates to that job, and `other.run_pending()` finds no queued job. So `len(count)==1` comes from dedup and status, not from the slot flock. Making `_slot` always succeed would still pass.
- What the test does pin: a live lease is not fenced by another instance's `_recover` (150, 153).
- Two queued jobs are reachable. A blocked job J1, then enqueue() creates J2 with the same input, then retry(J1) (214-225 and 251-256).
- Unpinned behaviours:
  - lease_recovered at MAX_ATTEMPTS becomes escalated (200);
  - retry is rejected for queued, running and scoped_kernel_checked jobs (251-252);
  - an event_id of a terminal job returns that job (215-218);
  - event_id and max_workers validation (87-88, 207-208);
  - the `late_result_rejected` event is recorded (337);
  - head.json missing or corrupt;
  - the content of the torn-tail file.

### G3-F9 INFO: AttributeError is missing from the except tuple of the acceptance gate
- formal_queue.py:353, 355 and 365.
- `result.get('toolchain', {}).get(...)` raises AttributeError when toolchain is None or not a dict. `verification.get` raises it when verification is truthy but not a dict.
- The error escapes `_complete` to `_run_one` at 324. The job is recorded as failed/`worker_exception` rather than `receipt_rejected`, and the verification is dropped. This fails closed, but with the wrong typed reason.
- It can only be reached through formal_lane output.

### G3-F10 INFO: lock and path assumptions
- Unlinking `slot-N.lock` or `journal.lock` while it is held lets a new open lock a fresh inode, so a double lease becomes possible (probe confirmed).
- Where flock is emulated with POSIX locks (NFS, some FUSE and CIFS), locking is per process. An in-process `_recover` could then fence a live worker, and closing its fd would drop that worker's lock.
- The workdir must be a local filesystem with no other writers.
- `artifact_dir` is stored as an absolute path (285) and used authoritatively at 358 and 375. `result_ref` and `receipt_ref` are relative. In a copied runtime (API_V20 line 76) the absolute path is stale. Only display is affected, because a copied `running` job is fenced on open.
- `_atomic` (59-66) does not unlink its temp file when it fails.
- The directory entry of the torn-tail file (151-155) is not fsynced before the truncate (156-159). Only a forensic copy of bytes that were never committed is at risk.

## Areas with no finding (what I checked)
- **Lease takeover and release ordering.** Slot locks are acquired only under the journal lock, in `_recover` and `_claim`. They are released only after the durable terminal event (`_complete`, then `finally: slot.close()`). The non-blocking slot attempt under the journal lock avoids the lock-order deadlock with workers that hold a slot and wait for the journal lock. Recovery happens before claim in the same critical section, so a dead lease is fenced before its slot is reused. On a local filesystem, flock conflicts between two descriptors in the same process (probe).
- **Idempotence of claims and completions.** A claim moves the job to `running` in the same critical section. `_complete` requires `running` and a matching token. A late or stale token appends `late_result_rejected` and returns False. Double terminal events are impossible. These are pinned at test 169, 193 and 272.
- **Effort and attempt accounting.** Every claim adds exactly one attempt, and interrupted attempts count. Nothing is refunded and the count never goes down. retry and recover both use the same `len(attempts) >= MAX_ATTEMPTS` test. `_claim` itself does not re-check the cap, but every path into `queued` does. Only cosmetic issues remain: the "Three attempts" text is hard-coded, and see F7 for escalated retries.
- **Journal append and head.** Each append is one write, then flush and fsync, followed by an atomic head write (temp file, fsync, replace, directory fsync). A partial write raises before in-memory state changes. A durable append whose head update failed is reconciled on the next read, because head may legitimately lag by one. A torn tail is only an incomplete final line. A line that is complete but corrupt fails closed. bytes.splitlines splits only on \n and \r, which canonical JSON always escapes (probe). Lone surrogates fail encoding before any byte is written. Replay is a deterministic last-record-wins over full job snapshots, so it is idempotent. Pinned at test 212-230 and 240-249.
- **Crash windows.** A crash after result.json and before the terminal event is fenced and re-run (pinned at test 173-196). A process death mid-run is pinned at test 159-171.
- **Caller-input path safety.** profile_id must be exactly the registered ID (70-71). event_id is limited to a non-empty string of at most 200 characters. Job ids and tokens are uuid4 hex. The receipt fence checks for a symlink in the final component and resolves the full path for containment.
- **Aliasing.** Every mutation works on a deepcopy, so replayed events are never mutated in place.
