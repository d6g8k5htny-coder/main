# G1 engine: static engineering review notes (main#605, carrier 71049ac9)

Reviewer: Anthropic Claude sub-agent of session_013tN78b3Q38WdttFyiJ6KVg ("Claude 54"). This is a static review only. No carrier file was imported, executed or installed, and no test was run. The only things executed were two standalone stdlib re-implementations and one AST inventory, all kept in `v20rev/scripts/` and run with `python3 -I` (Python 3.11.15).

Source root: `carrier/v20_planner_source_carrier/sources/Universal_Law_v19_Research_Frontier`.

## Members read completely

- `engine/conductor.py` (874 lines)
- `engine/workers.py` (458 lines)
- `engine/retained_worker_compat.py` (113 lines)
- `engine/RETAINED_PROTOCOL_COMPATIBILITY.md` (35 lines)
- `engine/adapters/worker_protocol.schema.json` (144 lines)

Also read for context: v20 `API_V20.md` (the contract) and v19 `API_V19.md` (context only, another lane's scope).

Tests were grepped only to check coverage: `test_flow.py`, `test_proof_conductor.py`, `test_intelligence.py`, `test_frontier_runtime.py` and `test_formal_queue.py`.

## Scripts (outside the carrier)

- `scripts/g1_linesep_repro.py` reproduces F1. It re-implements `canonical()` (conductor.py:24), the line framing of `append` (188-193) and the line parsing of `_load` (159-177).
- `scripts/g1_linesep_fix_check.py` shows two things: a reader that splits on the LF byte accepts the same file, and escaping the separator in place repairs it without breaking the hash chain.
- `scripts/g1_ast_inventory.py` is an AST inventory. Every event type that conductor.py writes is handled by `_replay`. It also lists the try/except spans.

## Contract note (API_V20)

API_V20.md covers `conditioning_lab` and its receipt schema `ul-v20-exact-worker-receipt-1`. On the foundation conductor it says only: "does not ... replace the foundation's durable conductor. The preserved dashboard/queue runs against its own writable runtime copy."

No API_V20 clause binds these five members beyond that preservation, so none of the findings below breaks API_V20. The contract anchors I used are the members' own:

- the Journal docstring, conductor.py:122-126;
- the execute_job docstring, workers.py:239-242;
- RETAINED_PROTOCOL_COMPATIBILITY.md.

A consistency gap if anyone reads API_V20 as covering the engine: API_V20 promises "truncated with observed byte counts" and child CPU/address/file/fd limits for its own lab. The engine worker records only a truncation flag, and its parent sets no rlimits (see F10).

## Test-coverage baseline

The carrier contains no engine-level tests. `file_list.tsv` shows that `engine/tests/` exists in the archive but was not delivered: test_conductor.py, test_adversarial_v17.py, test_workers_v17.py, test_retained_worker_compat.py, test_negative.py, test_http.py, test_engine_integrity_v17.py, test_certificates_v17.py, test_source_custody.py, and tests_v16/test_conductor.py. Engine coverage is therefore UNKNOWN for every finding.

Some carrier tests touch the engine indirectly:

- `test_flow.py`:
  - duplicate delivery and restart, at :108;
  - crash after capture, at :117;
  - failure after research tamper, at :198, with `max_attempts=1`;
  - receipt replay, at :209.
- `test_proof_conductor.py`, at :251 and :352: hash-valid forged journal semantics.
- `test_intelligence.py`, at :92: propose and decide.

No carrier test exercises any of these:

- Journal torn tail, tamper, or separator framing;
- lease expiry or `recover_jobs`;
- the `max_workers` cap;
- the `complete_job` rejection paths (late, expired, stale, invalid receipt);
- retry backoff and escalation;
- `publish_snapshot`;
- the inbox watcher;
- the service lock;
- worker-thread failure;
- CERTIFICATE_EVALUATED;
- execute_job timeout, kill and output truncation;
- any part of `retained_worker_compat`;
- conformance of jobs or receipts to the schema.

## Findings (most severe first)

### F1 HIGH (confirmed by standalone reproduction): Journal reader splits on Unicode line boundaries the writer does not escape, so one valid record makes the journal permanently unloadable

- **Code.** The writer, conductor.py:24, uses `json.dumps(...,ensure_ascii=False,...)`. The reader, conductor.py:163, uses `raw.decode('utf8').splitlines()`.
- **Defect.** `str.splitlines()` also splits on U+0085, U+2028 and U+2029. The JSON encoder with `ensure_ascii=False` writes these characters raw. A record that `append` fsyncs successfully is therefore cut into fragments by the next `_load`. The result is a `JSONDecodeError` (ValueError) on every later operation, because every operation calls `_load`: append, since, `_replay`, and `Coordinator.__init__`.
- **Reachable inputs.** None of these paths checks the character set:
  - the `actor` in propose (424), including from an inbox file (679) and from HTTP (808);
  - `event_id` (180), from HTTP (808, 810);
  - the decide actor (450; `'human x'` passes the `startswith` check);
  - `worker_id` (557);
  - any `reason` or `message` built from `str(err)` (598, 625, 671).
- **Blast radius (static reading of other lanes).** The same Journal class serves `collaboration.py` (annotation text, :98-101), `flow.py` (a source_key built from a watched file's name, :107), `proof_conductor`, `intelligence` and `frontier_runtime`.
- **Scenario.**
  1. An untrusted agent writes `inbox/a.json = {"kind":"statement","target":<id>,"replacement":<valid edit>,"actor":"agent x"}`.
  2. PROPOSAL_CREATED is appended and fsynced.
  3. publish_snapshot then raises. `_watch_once` moves the file to `.rejected` even though the event was committed.
  4. From then on, every snapshot, append and restart fails with ValueError: the "fail closed" path for a corrupted journal.
- **Reproduction.** `g1_linesep_repro.py` shows LOAD FAILS for U+2028, U+2029 and U+0085. The control characters 0x1c and 0x0b load OK because JSON escapes them.
- **Fix.** Split on the LF byte (`raw.split(b'\n')`) before decoding. `formal_queue.py:124` already splits bytes and is not affected. Changing `canonical()` would be the wrong fix: it would change the hashes of existing non-ASCII events.
- **Manual repair.** Replace each raw separator with its `\uXXXX` escape in place. The hash chain stays intact (shown by `g1_linesep_fix_check.py`).
- **Classification.** Contract violation against the module's own docstring (conductor.py:122-126). A well-formed, fsynced journal is classed as malformed.
- **Tests.** None in the carrier; engine/tests are unavailable.

### F2 MEDIUM: worker threads die silently on any exception outside the run_checks try

- **Code.** conductor.py:662-672. In the queue.Empty branch, `self.recover_jobs()` and `self.snapshot()` are not inside any try. The handler's own `self.journal.append('CHECK_RUN',...)` at 671 can also raise.
- **Defect.** An exception escapes the while loop and ends the daemon thread. Nothing journals it, restarts the thread, or clears `started`.
- **Scenario.** A transient OSError hits all `max_workers` threads. Examples: ENOSPC or EMFILE in the `publish_snapshot` inside `recover_jobs`, or a failure to open `.journal.lock`. All threads exit. HTTP keeps serving state, but queued jobs are never claimed, and no event records why.
- **Classification.** Typed-failure handling; hardening.
- **Tests.** None.

### F3 LOW: inbox watcher races, unbounded reads, and thread death

Code: conductor.py:674-686, with `os.replace(f,dest)` at 683 outside the try, and `f.stat().st_size>20000` followed by `f.read_text()` at 677-678.

The watcher has these problems:

- **Thread death.** The file can vanish between `glob` and `os.replace`, for example when another watcher or agent removes it. FileNotFoundError then ends the `_watch` thread and inbox intake stops for the life of the service. There is also a stop/start window: `stop()` does not join `_watch`, and `start()` clears `_stop`.
- **Unbounded reads.** The `st_size` check does not bound reads of special files. A FIFO or a symlink to /dev/zero named `*.json` blocks the watcher or exhausts its memory.
- **Partial-file race.** The watcher has no atomic hand-off convention, so a file still being written is parsed and moved to `.rejected`.
- **Double read.** The file is read twice (678 and 679), so the event_id hash can describe bytes other than the ones parsed.
- **Provenance spoofing (INFO).** The inbox `actor` is taken from the file, so a file can record `human:owner` as the author of the proposal.

Classification: hardening. Tests: none.

### F4 LOW: idle polling turns an unclaimable pending job into a stream of fsynced CHECK_RUN events

- **Code.** conductor.py:665-667 (requeue whenever `pending_job_count`), 629-642, and 660 (`run_checks` always appends CHECK_RUN).
- **Defect.** Suppose a restart happens while leases from the crashed process are still unexpired and fill `max_workers`, with at least one current job still queued. Then:
  1. every idle thread re-enqueues every 0.2 s;
  2. claim_job returns None because of the cap (561);
  3. run_jobs breaks;
  4. a CHECK_RUN CHECK_ERROR event is appended and the snapshot is republished.
- **Scale.** With the defaults (lease 30 s, 2 threads) that is on the order of a hundred or more permanent events, each fsynced. Every later O(N) `_load` gets slower, and the events push real activity out of the `events[-120:]` and `checks[-10:]` views.
- **Classification.** Resource bound; hardening.
- **Tests.** None.

### F5 MEDIUM: leases have no renewal, and expiry is judged after waiting for the lock and running a full replay

- **Code.**
  - conductor.py:236 validates `0<lease_seconds<=3600` independently of the job's `wall_seconds`.
  - conductor.py:569 sets `lease_expires_at = now + lease_seconds`.
  - conductor.py:576-581: complete_job acquires the coordinator mutex and the journal flock, runs a full `_replay()`, and only then tests `lease_expires_at<=time.time()`.
  - workers.py:30 sets the default wall time to 15 s. Before Popen, the worker also does unbounded work: input capture, note and research copies, hashing of `sys.executable`.
- **Scenario A.** `Coordinator(wd, lease_seconds=10)` is accepted. Any job running longer than 10 s goes through this sequence:
  1. recover_jobs in another thread expires it (retry_wait).
  2. A second worker leases it and runs it concurrently.
  3. The first worker's valid result is rejected as "late result".
  4. The cycle repeats until JOB_ESCALATED.

  Every correct diagnostic ends as failed.
- **Scenario B (defaults).** As the journal grows, the claim, execute and complete path (three or more full replays plus up to 15 s in the child) approaches the 30 s lease. A worker that finished on time is then rejected with "worker lease expired before completion" because of lock wait or replay time. Each rejection consumes an attempt; with `max_attempts=1`, as in test_flow, the job escalates at once.
- **Classification.** Hardening; no lease contract is documented for the engine.
- **Tests.** None.

### F6 LOW (plausible; depends on model.fingerprints, which is unavailable): two definitions of "last approved sequence"

- **Code.** `_replay` uses `last_approval = max(changes)` over every PROPOSAL_APPROVED (362), and counts a check as successful only if `last_approved_sequence == last_approval` (370-373). `run_checks` writes `max(job.approval_sequence)` over jobs only (659).
- **Scenario.** The latest approval affects no mathematical fingerprint, for example an edit to an unreferenced import's `scope_description`, if fingerprints() ignores it. That approval creates zero jobs. No CHECK_RUN can then ever match, so `approvals_pending_diagnostics` stays true forever, and every `start()` enqueues a replay (707) and appends another CHECK_RUN.
- **Classification.** Hardening.
- **Tests.** None.

### F7 MEDIUM (plausible; depends on certificates.validate_certificate, which is unavailable): the writer appends events that the replay rejects, which permanently bricks the journal

- **Code.** conductor.py:511-517 appends CERTIFICATE_EVALUATED with whatever verdict `validate_certificate` returns. Only exceptions are mapped to a safe verdict. The replay at 357 raises `unearned mathematical certification` unless `verdict.get('formal_status')=='not_certified'` and `theorem_certificates_awarded==0`; a verdict that is not a dict raises AttributeError.
- **Scenario.** The checker returns a verdict that lacks `formal_status`, or uses another value (for example "certified" from a buggy or malicious checker). The event is committed, and every later `_replay`, and so `snapshot()`, `start()` and `Coordinator()`, raises. The same failure mode as F1 is reached through semantics.
- **Same pattern elsewhere.** `propose` (442) mints `'p-'+uuid4().hex[:12]` (48 bits) without checking it against existing proposals before appending, while the replay raises `duplicate proposal` (272). The probability is negligible (INFO).
- **Fix.** Apply the replay's invariant before appending, and record the result as blocked.
- **Classification.** Hardening. Fail-closed should reject the certificate, not the journal.
- **Tests.** None in the carrier.

### F8 LOW: a failure in a post-commit step is reported as failure of the committed transition

- **Code.**
  - claim_job, 570-572: JOB_LEASED is committed, then `publish_snapshot()` and `snapshot()` run.
  - complete_job, 607-609: JOB_FINISHED is committed, then `publish_snapshot()` runs.
  - decide, 489-493: PROPOSAL_APPROVED is committed, then handle_event and publish_snapshot run. `handle_event` compares the in-memory event with its JSON round-trip at 500.
  - run_one_job, 621-627.
  - publish_snapshot, 418-421: the temp file is not removed on failure.
- **Scenario 1.** ENOSPC while writing `current_state.*.tmp` right after JOB_LEASED. claim_job raises, run_one_job never runs the job, and the lease leaks until expiry. The attempt is consumed and recorded as "worker lease expired after crash/restart"; with `max_attempts=1` the job escalates to failed without ever running.
- **Scenario 2.** The same failure after JOB_FINISHED. run_one_job returns a synthesized `{'result':'failed','retryable':True}` for a job the journal records as diagnostic_completed.
- **Scenario 3.** decide raises to the caller after the approval was committed. recover_outbox repairs this later.
- **Classification.** Typed-failure handling; hardening.
- **Tests.** None.

### F9 LOW (plausible; depends on how worker_process.py writes its output, which is unavailable): execute_job failure classification

- **Code.** workers.py:321-328: on timeout, `retryable=True` and reason "wall-time". The code then continues to 334-338, where `json.loads(diagnostic.json)` runs, and to 350-351, where the except overwrites the receipt with `retryable=isinstance(exc,OSError)`, which is False.
- **Scenario 1.** A child killed by SIGKILL leaves a partial `diagnostic.json`. The timeout is relabelled as a non-retryable JSON error, so complete_job escalates at once (603-605) instead of retrying.
- **Scenario 2.** The except tuple omits TypeError and AttributeError. A `diagnostic.json` that holds a JSON list makes `result.get` at 341 raise AttributeError. That escapes execute_job with no `receipt.json`, which contradicts the docstring at 239-242 ("Failed attempts still retain ... a hashed receipt").
- **Classification.** Contract violation for scenario 2, against the docstring; hardening for scenario 1.
- **Tests.** None in the carrier.

### F10 LOW (dependency unavailable): the parent enforces only wall time

- **Code.** workers.py:308-333. `cpu_seconds` and `memory_bytes` reach the child only through `job.json`. The parent never calls `setrlimit`, so enforcement depends on worker_process.py, which was not delivered.
- **Output bounds.** stdout and stderr go straight to files with no limit while the child runs. Line 331 then reads each whole file into memory before truncating.
- **Process cleanup.** The process group is killed only on timeout (322-323). Grandchildren left after a normal exit survive.
- **Classification.** Hardening, against the docstring at 239 ("actual resource-bounded child checker").
- **Tests.** None.

### F11 LOW: torn appends and first creation of the journal

- **Code.** conductor.py:192-194 and 160-162.
- **Torn appends.** If `f.write` raises partway (ENOSPC), the partial bytes stay in the file. Every later `_load` raises "incomplete journal tail", and freeing disk space does not help. The append could record the file offset and call `ftruncate` back to it on failure.
- **First creation.** There is no directory fsync when `events.jsonl` is first created.
- **Missing file.** A missing `events.jsonl` is silently treated as an empty journal (160), even when the work directory already holds artifacts or `current_state.json`.
- **Classification.** Hardening; the fail-closed behaviour matches the docstring.
- **Tests.** None.

### F12 INFO: claim and completion have no idempotency key

- **Code.** conductor.py:556-573 and 575-588.
- **Defect.** Retrying `complete_job` after a lost response appends JOB_RESULT_REJECTED and raises ValueError for a job that is already completed. Retrying `claim_job` leases a second job, and the first lease leaks until it expires, consuming an attempt.
- **Classification.** Neither method is exposed over HTTP in these members, so this is a hardening note.
- **Tests.** None.

### F13 INFO: a superseded job can be claimed again

- **Code.** conductor.py:326-327 marks a superseded job stale only if it is queued or in retry_wait. A superseded job that is running and later moves to retry_wait is re-leased by claim_job, which checks staleness only by comparing fingerprints (565).
- **Scenario.** The proposal is A→B→A: the record's fingerprint returns to its first value. The non-current job then runs again and consumes worker slots and attempts, and its result is ignored. claim_job also iterates jobs oldest first.
- **Tests.** None.

### F14 INFO: schema identity and the documentation disagree

- worker_protocol.schema.json:3 has `$id` `urn:universal-law:worker:v17.1`, but :19 sets `protocol_version` to the const `research-flow-worker-1`.
- RETAINED_PROTOCOL_COMPATIBILITY.md:4-5 says v17 receipts bind `UL-worker-v17.1`. A schema whose id claims v17.1 therefore rejects every v17.1 receipt.
- The schema does not require `receipt_sha256` and does not describe `research_inputs`.
- JSON Schema treats `1.0` as an integer, while `_limits` rejects it. A minor gap.

### F15 INFO: retained_worker_compat bounds

- retained_worker_compat.py:75-77: the size is checked with stat and the file is then read. The file can grow in between.
- retained_worker_compat.py:98-104: `capture_output=True` buffers the child's output before the bound is checked.
- On timeout, subprocess.run kills only the direct child. A v17 replay grandchild may outlive the 45 s bound.
- Impact is limited because the archive is hash-pinned. The code otherwise matches the MD; see "No finding" below.
- Tests: test_retained_worker_compat.py is unavailable.

### F16 INFO: resource and exposure notes

Code: conductor.py:182, 198, 248-250 and 783-786.

- Every journal operation re-reads and re-hashes the whole journal. The SSE handler does this twice per wake-up per client while holding the journal mutex (784, 786).
- Lease tokens are bearer capabilities for completion. They are published in `current_state.json`, by GET `/api/state` (no token needed, loopback Host only) and in SSE `JOB_LEASED` payloads.
- The hash chain is unkeyed, so "tampered event" (171) detects accidents, not an adversary with write access. test_proof_conductor.py:251 already treats it that way.
- `_load` raises KeyError rather than ValueError when `seq` or `prev_hash` is missing, and accepts `seq: true` as 1.
- Replay of legacy approvals that lack a `jobs` field recomputes job ids from the current checker hashes (308-310). Any change to `workers.py` would orphan their later JOB_* events.

## No finding (what was checked)

- **Journal load.** It checks seq continuity, prev_hash, per-event hash recomputation and duplicate event_ids, and fails closed on a missing final LF. Apart from F1 this is correct.
- **Append idempotence.** `event_id` is checked after a reload under the lock, so there is no cross-process TOCTOU. Content equality is correct for JSON-native payloads.
- **Lock order.** The order is coordinator RLock, then journal RLock, then flock. SSE takes journal RLock then flock, so there is no inversion. Because flock locks per open file description, two Coordinators in one process also exclude each other. `Condition.wait` fully releases the RLock.
- **Lease and job id validation in replay.**
  - The lease token must be 32 hex characters (339).
  - The job id must be `j-` plus 32 hex characters (321).
  - The attempt must equal attempts+1 and be no more than `max_attempts` (338).
  - Outcome events must carry the current lease token (345).
- **Attempt budget.** An attempt is consumed only by JOB_LEASED. Nothing refunds one. The lease-expiry path in complete_job does not double-charge: run_one_job's fallback at 624 re-checks the state and token. Escalation happens at `attempts>=max`.
- **Path safety.**
  - The artifact directory is derived from validated ids, and complete_job compares resolved paths (591-594).
  - `workers._inside` rejects absolute paths, `..`, a symlink as the final component, and any path that resolves outside the root.
  - Artifacts are opened with `xb`, and the attempt directory must be empty.
- **Outbox.** JOB_QUEUED (`queue:<job>`) and CERTIFICATE_EVALUATED (`certificate-evaluation:<pid>`) use deterministic event ids, so recover_outbox is idempotent.
- **Approval checks.** Supersession of queued jobs is applied in replay. Stale proposals and branch hashes are rechecked at approval and at replay.
- **Snapshot writes.** `publish_snapshot` writes a temp file, fsyncs it and calls `os.replace`, which is atomic for readers.
- **verify_receipt.** It checks:
  - the receipt's self-hash, the protocol, the result enum and the limits;
  - for no certification claims;
  - each artifact's size and SHA-256;
  - equality of the recorded and the scheduled job;
  - the input binding, by recapturing it;
  - the requirements for a passing receipt.
- **retained_worker_compat against the MD.**
  - `SEALED_SHA256` matches the `file_list.tsv` sha of `history/sealed/Universal_Law_Mathematical_Conductor_v17.zip` (3,145,944 bytes) and the MD's value.
  - The archive bytes are hashed before use.
  - Extraction rejects members outside the prefix, absolute paths, `..`, backslashes and symlinks.
  - The fixed child runs with `-I -B`, a minimal environment, stdin from /dev/null, and a timeout.
  - Protocols never fall back to each other.
  - The recorded commands are never run.
- **Schema against the code.** The `resource_limits` ranges equal the `_limits` bounds, the `job_id` pattern equals make_job and the replay check, and the `result` enum equals verify_receipt.
- **Event-type coverage (AST).** All 12 event types that conductor.py writes are handled by `_replay`.

## Dependencies I could not inspect

- `engine/model.py`: load, validate, fingerprints, digest, structures, GateError.
- `engine/research_evidence.py`: validate_capture, verify_capture, attach_research, relevant_captures, validate_attachment, SHA.
- `engine/certificates.py`: validate_certificate.
- `engine/source_custody.py`: source_inputs.
- `engine/worker_process.py`: the child, its rlimits and how it writes output.
- `engine/conductor_template.html`.
- `engine/LOCAL_EVIDENCE_NOTES_INDEX.json` and `engine/dataset.json`.
- `engine/verify.py`, `engine/verify_example.py` and `engine/live_integration_test.py`.
- The contents of the sealed v17 archive.
- All of `engine/tests/*` and `engine/tests_v16/*`.
