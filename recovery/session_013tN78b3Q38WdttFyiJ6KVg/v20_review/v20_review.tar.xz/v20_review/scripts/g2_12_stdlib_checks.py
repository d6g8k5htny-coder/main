# Stdlib-only checks; does not import or run any carrier code.
import json, inspect, pathlib, os, tempfile, fcntl, threading, sys
print(sys.version)
try:
    json.loads(b'[' * 100000)
except Exception as e:
    print('json deep nest ->', type(e).__name__, isinstance(e, (OSError, TypeError, json.JSONDecodeError)))
print(inspect.getsource(pathlib.Path.is_symlink))
# flock on two open file descriptions of the same file in one process
d = tempfile.mkdtemp(dir='/tmp/claude-0/-home-user-main/d5c985ca-97e5-58d8-a9d4-1e0a19065a22/scratchpad/v20rev/scripts')
p = os.path.join(d, '.journal.lock')
a = open(p, 'a+b'); fcntl.flock(a.fileno(), fcntl.LOCK_EX)
b = open(p, 'a+b')
try:
    fcntl.flock(b.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    print('second description acquired (no conflict)')
except BlockingIOError:
    print('second open file description blocks on flock in same process')
# unhashable membership
try:
    [1] in {}
except TypeError as e:
    print('unhashable in dict ->', e)
