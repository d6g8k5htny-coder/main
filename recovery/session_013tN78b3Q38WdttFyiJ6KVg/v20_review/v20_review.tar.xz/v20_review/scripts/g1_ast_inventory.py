"""AST-only inventory of engine/conductor.py (file is parsed, never imported/executed)."""
import ast, sys
src = open(sys.argv[1], encoding='utf8').read()
tree = ast.parse(src)
written = {}
for node in ast.walk(tree):
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == 'append':
        f = node.func.value
        if isinstance(f, ast.Attribute) and f.attr == 'journal' and node.args and isinstance(node.args[0], ast.Constant):
            written.setdefault(node.args[0].value, []).append(node.lineno)
handled = set()
for fn in ast.walk(tree):
    if isinstance(fn, ast.FunctionDef) and fn.name == '_replay':
        for c in ast.walk(fn):
            if isinstance(c, ast.Compare) and isinstance(c.left, ast.Name) and c.left.id == 't':
                for comp in c.comparators:
                    for k in ast.walk(comp):
                        if isinstance(k, ast.Constant) and isinstance(k.value, str): handled.add(k.value)
print('written by conductor.py:'); [print(' ', k, v, 'handled' if k in handled else 'NOT HANDLED') for k, v in sorted(written.items())]
print('handled by _replay but not written here:', sorted(handled - set(written)))
# try/except coverage of _worker / _watch_once bodies
for fn in ast.walk(tree):
    if isinstance(fn, ast.FunctionDef) and fn.name in ('_worker', '_watch_once', 'run_one_job', 'claim_job'):
        print(fn.name, 'lines', fn.lineno, fn.end_lineno)
        for c in ast.walk(fn):
            if isinstance(c, ast.Try):
                print('   try lines', c.lineno, '-', c.body[-1].end_lineno, 'handlers', [ast.unparse(h.type) if h.type else 'bare' for h in c.handlers])
