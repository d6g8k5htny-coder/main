"""Standalone check (no carrier import): (a) a byte-level LF splitter accepts the
journal that conductor.py:163's str.splitlines() rejects, with hashes intact;
(b) escaping raw U+2028 in place is a hash-preserving manual repair."""
import hashlib, json, tempfile
from pathlib import Path
ZERO='0'*64
def canonical(v): return json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode('utf8')
def mk(events, payload):
    d={'seq':len(events)+1,'when_utc':'t','type':'PROPOSAL_CREATED','payload':payload,
       'prev_hash':events[-1]['event_hash'] if events else ZERO}
    d['event_hash']=hashlib.sha256(canonical(d)).hexdigest(); events.append(d); return canonical(d)+b'\n'
def verify(lines):
    prev=ZERO; n=0
    for line in lines:
        e=json.loads(line); n+=1
        assert e['seq']==n and e['prev_hash']==prev
        exp=hashlib.sha256(canonical({k:v for k,v in e.items() if k!='event_hash'})).hexdigest()
        assert e['event_hash']==exp, 'hash'
        prev=exp
    return n
ev=[]; raw=mk(ev,{'actor':'a'})+mk(ev,{'actor':'human x'})+mk(ev,{'actor':'b'})
for name, splitter in [('str.splitlines (conductor.py:163)', lambda r: r.decode('utf8').splitlines()),
                       ('bytes split on LF', lambda r: [l.decode('utf8') for l in r.split(b'\n')[:-1]])]:
    try: print(name, '-> OK', verify(splitter(raw)), 'events')
    except Exception as e: print(name, '-> FAIL', type(e).__name__, e)
repaired=raw.replace(' '.encode('utf8'), b'\\u2028')
print('in-place escape repair + str.splitlines ->', verify(repaired.decode('utf8').splitlines()), 'events (hash chain intact)')
