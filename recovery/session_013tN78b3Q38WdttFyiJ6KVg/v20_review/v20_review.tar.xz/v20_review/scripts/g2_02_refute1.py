"""Independent offline model of proof_conductor._append byte guard vs Journal.append bytes.
No carrier import; reimplements canonical() and the envelope from engine/conductor.py:24,188-193."""
import json, hashlib, time
from datetime import datetime, timezone

MAX = 32 * 1024 * 1024

def canonical(v):
    return json.dumps(v, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode('utf8')

def written(etype, payload, seq=9999):
    d = {'seq': seq, 'when_utc': datetime.now(timezone.utc).isoformat(), 'type': etype,
         'payload': payload, 'prev_hash': 'a' * 64}
    d['event_hash'] = hashlib.sha256(canonical(d)).hexdigest()
    return len(canonical(d) + b'\n')

def est(payload):
    return len(str(payload).encode('utf8'))

H = 'b' * 64
cid = 'claim-' + 'c' * 32
now = time.time()
claim = {'claim_id': cid, 'artifact_directory': 'artifacts/' + cid, 'task_id': 'task-' + 'd' * 24,
         'agent_id': 'worker', 'strategy': 'dependency_decomposition', 'claimed_at': now,
         'lease_seconds': 60, 'expires_at': now + 60, 'input_fingerprint': H,
         'question_sha256': H, 'scope_sha256': H}

def failure(evidence):
    attempt = {'attempt_id': 'attempt-' + cid, 'claim_id': cid, 'task_id': claim['task_id'],
               'diagnosis': 'timeout', 'evidence': evidence, 'submitted_at': now + 1,
               'input_fingerprint': H, 'kind': 'agent_failure_report'}
    decision = {'decision_id': 'decision-' + cid, 'claim_id': cid, 'task_id': claim['task_id'],
                'diagnosis': 'timeout', 'action': 'replan', 'previous_strategy': 'dependency_decomposition',
                'strategy': 'bounded_partition', 'disposition': 'investigate_report',
                'question_sha256': H, 'scope_sha256': H, 'input_fingerprint': H,
                'guidance': 'Partition the investigation into bounded subquestions without dropping premises.',
                'preserve_dependencies': [], 'proposed_only': True,
                'mathematical_verdict': 'not_established_by_agent_report',
                'technical_retry_same_fixed_worker': False}
    return {'attempt': attempt, 'decision': decision}

for name, et, p in [('TASK_CLAIMED', 'TASK_CLAIMED', claim),
                    ('FAILURE none', 'FAILURE_REPORTED', failure(None)),
                    ('FAILURE quotes', 'FAILURE_REPORTED', failure({'r': '"' * 15000}))]:
    e, w = est(p), written(et, p)
    print(f'{name:16s} est={e:7d} written={w:7d} undercount={w - e:7d}')

ev = {'r': '"' * 15000}
print('evidence canonical bytes', len(canonical(ev)), 'json.dumps default', len(json.dumps(ev).encode()))
p = failure(ev)
e, w = est(p), written('FAILURE_REPORTED', p)
start = MAX - e  # largest size the guard still admits
print('start', start, 'guard admits', start + e <= MAX, 'final', start + w, 'over MAX by', start + w - MAX)

# simulate many small claims approaching bound: does it land over MAX?
import random
over = 0
trials = 2000
for t in range(trials):
    size = MAX - random.randint(5000, 50000)
    while True:
        e = est(claim); w = written('TASK_CLAIMED', claim)
        if size + e > MAX:
            break
        size += w
    over += size > MAX
print('repeated TASK_CLAIMED: fraction ending over MAX', over / trials)
