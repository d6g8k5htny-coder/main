"""Static AST inventory of formal_queue.py: call sites of lock-sensitive helpers
and whether each is lexically inside `with self._locked()`; except clauses."""
import ast, sys
path = sys.argv[1]
src = open(path, encoding='utf8').read()
tree = ast.parse(src)
SENS = {'_append', '_read', '_slot', '_recover'}

def is_locked_with(node):
    if not isinstance(node, ast.With):
        return False
    for item in node.items:
        c = item.context_expr
        if isinstance(c, ast.Call) and isinstance(c.func, ast.Attribute) and c.func.attr == '_locked':
            return True
    return False

def walk(node, fn, locked, out):
    for child in ast.iter_child_nodes(node):
        lk = locked or is_locked_with(child)
        if isinstance(child, ast.Call) and isinstance(child.func, ast.Attribute) and child.func.attr in SENS:
            out.append((fn, child.func.attr, child.lineno, lk))
        if isinstance(child, ast.ExceptHandler):
            t = ast.unparse(child.type) if child.type else 'BARE'
            out.append((fn, 'except ' + t, child.lineno, lk))
        walk(child, fn, lk, out)

for cls in [n for n in tree.body if isinstance(n, ast.ClassDef)]:
    for fn in [n for n in cls.body if isinstance(n, ast.FunctionDef)]:
        out = []
        walk(fn, fn.name, False, out)
        for row in out:
            print('%-20s %-28s line %-4d locked=%s' % row)
# module-level functions
for fn in [n for n in tree.body if isinstance(n, ast.FunctionDef)]:
    out = []
    walk(fn, fn.name, False, out)
    for row in out:
        print('%-20s %-28s line %-4d locked=%s' % row)
