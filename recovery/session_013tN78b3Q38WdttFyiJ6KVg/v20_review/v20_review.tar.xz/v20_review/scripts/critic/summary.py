import json,sys
d=json.load(open(sys.argv[1]))
for g in d:
    print('='*100); print('GROUP',g['group'])
    r=g['review']
    print('READ:'); [print('  -',x) for x in r['read']]
    print('UNAVAILABLE:'); [print('  -',x) for x in r['unavailable_dependencies']]
    print('NO_FINDING count',len(r['no_finding_areas']))
    print('review.findings ids',[f['id'] for f in r['findings']])
    for f in g['findings']:
        vs=[(v.get('refuter'),v.get('refuted'),v.get('corrected_severity')) for v in f['votes']]
        print(f"{f['id']:8} {f['severity']:6} surv={f['survives']!s:5} {f['status']:14} votes={vs} | {f['file']} {f['lines'][:70]}")
