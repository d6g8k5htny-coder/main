import json
# stdlib-only probe; no carrier code imported
def canonical(v):return json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode('utf8')
for ch in [' ',' ','\x85','\x0b','\x1c','\r']:
    raw=canonical({'actor':'agent'+ch+'x'})+b'\n'
    s=raw.decode('utf8').splitlines(); b=raw.split(b'\n')
    try:
        [json.loads(l) for l in s]; strres='OK'
    except ValueError as e: strres='FAIL(%s)'%type(e).__name__
    print(repr(ch),'str.splitlines parts=',len(s),strres,'| bytes.splitlines parts=',len(raw.splitlines()))
