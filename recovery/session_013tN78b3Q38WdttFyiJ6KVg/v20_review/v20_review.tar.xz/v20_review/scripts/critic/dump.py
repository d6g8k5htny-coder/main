import json,sys,os
d=json.load(open(sys.argv[1])); out=sys.argv[2]
os.makedirs(out,exist_ok=True)
for g in d:
    with open(os.path.join(out,g['group']+'.txt'),'w') as fh:
        r=g['review']
        fh.write('GROUP '+g['group']+'\n\nNO_FINDING_AREAS:\n')
        for x in r['no_finding_areas']: fh.write(' * '+(x if isinstance(x,str) else json.dumps(x))+'\n')
        # check review.findings == findings (minus votes)
        for a,b in zip(r['findings'],g['findings']):
            diff=[k for k in a if a.get(k)!=b.get(k)]
            if diff: fh.write('DIFF review vs merged for %s: %s\n'%(a['id'],diff))
        for f in g['findings']:
            fh.write('\n'+'#'*80+'\n')
            for k in ['id','severity','status','file','lines','excerpt','defect','scenario','kind','test_coverage']:
                fh.write(f'{k}: {f[k]}\n')
            for v in f['votes']:
                fh.write(f"\n--- VOTE refuter {v['refuter']} refuted={v['refuted']} sev={v['corrected_severity']}\n lines: {v['corrected_lines']}\n reason: {v['reason']}\n")
for g in d: print(g['group'], os.path.getsize(os.path.join(out,g['group']+'.txt')))
