# Stdlib-only reproduction of G1-F1. It re-implements, without importing any carrier
# code, the two lines it concerns: engine/conductor.py:24 (canonical, ensure_ascii=False)
# and :163 (raw.decode('utf8').splitlines()). Run: python3 -I repro_g1f1_framing.py
import json
canonical = lambda v: json.dumps(v, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode('utf8')
for ch in ['\u0085', ' ', ' ', '\x0b', '\x1c', '\n']:
    raw = canonical({'payload': {'value': 'a' + ch + 'b'}}) + b'\n'
    parts = raw.decode('utf8').splitlines()
    try:
        [json.loads(p) for p in parts]; outcome = 'loads'
    except ValueError as e:
        outcome = type(e).__name__
    print(repr(ch), 'lines=%d' % len(parts), outcome)
