# Parse (never import) the two members and list defs with line ranges plus,
# for each test, which ProofConductor public methods it calls.
import ast, sys
root = sys.argv[1]
for name in ('proof_conductor.py', 'test_proof_conductor.py'):
    tree = ast.parse(open(root + '/' + name, 'rb').read(), name)
    print('==', name)
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.ClassDef)):
            calls = sorted({n.func.attr for n in ast.walk(node) if isinstance(n, ast.Call)
                            and isinstance(n.func, ast.Attribute)
                            and n.func.attr in {'claim', 'submit_failure', 'complete_claim', 'blueprint', 'snapshot', '_read'}})
            tag = (' calls=' + ','.join(calls)) if name.startswith('test_') and node.name.startswith('test_') else ''
            print(f'{node.lineno:4d}-{node.end_lineno:4d} {node.name}{tag}')
