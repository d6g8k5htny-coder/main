"""Standalone re-implementation (NOT an import) of engine/conductor.py
canonical() [line 24], Journal.append line framing [188-193] and
Journal._load line parsing [161-171], to test whether a JSON-valid payload
string can produce a journal that the loader rejects."""
import hashlib, json, sys, tempfile, os
from pathlib import Path
ZERO = '0' * 64
def canonical(v):  # identical body to conductor.py:24
    return json.dumps(v, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode('utf8')
def append(path, events, etype, payload, event_id=None):  # mirrors 188-194
    d = {'seq': len(events) + 1, 'when_utc': '2026-10-25T00:00:00+00:00', 'type': etype,
         'payload': payload, 'prev_hash': events[-1]['event_hash'] if events else ZERO}
    if event_id: d['event_id'] = event_id
    d['event_hash'] = hashlib.sha256(canonical(d)).hexdigest()
    with path.open('ab') as f:
        f.write(canonical(d) + b'\n'); f.flush(); os.fsync(f.fileno())
    events.append(d)
def load(path):  # mirrors 159-177
    events = []; prev = ZERO
    raw = path.read_bytes()
    if raw and not raw.endswith(b'\n'): raise ValueError('incomplete journal tail')
    for n, line in enumerate(raw.decode('utf8').splitlines(), 1):
        if not line.strip(): raise ValueError('empty journal line ' + str(n))
        event = json.loads(line)
        if event['seq'] != len(events) + 1 or event['prev_hash'] != prev:
            raise ValueError('event sequence/previous hash corrupted at line ' + str(n))
        expected = hashlib.sha256(canonical({k: v for k, v in event.items() if k != 'event_hash'})).hexdigest()
        if event.get('event_hash') != expected: raise ValueError('tampered event at line ' + str(n))
        events.append(event); prev = expected
    return events
print(sys.version)
for ch in [' ', ' ', '\x85', '\x1c', '\x0b', '\n']:
    with tempfile.TemporaryDirectory() as t:
        p = Path(t) / 'events.jsonl'; ev = []
        append(p, ev, 'PROPOSAL_CREATED', {'actor': 'agent:inbox'})
        # e.g. propose(actor=...) only checks isinstance str, 1..120 chars (conductor.py:424)
        append(p, ev, 'PROPOSAL_CREATED', {'actor': 'human' + ch + 'x'})
        raw_has = ch.encode('utf8') in p.read_bytes()
        try:
            out = load(p); res = 'loads OK (%d events)' % len(out)
        except Exception as e:
            res = 'LOAD FAILS: %s: %s' % (type(e).__name__, e)
        print(repr(ch), 'raw-in-file=%s' % raw_has, '->', res)
