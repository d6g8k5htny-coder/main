"""Independent language/OS semantics probes (no carrier code imported)."""
import fcntl, json, os, sys, tempfile, pathlib
print('python', sys.version.split()[0])
# 1. bytes.splitlines boundaries vs canonical JSON escaping
seps = [b'\n', b'\r', b'\x0b', b'\x0c', b'\x1c', b'\x1d', b'\x1e', b'\xc2\x85', ' '.encode(), ' '.encode()]
for s in seps:
    print('splitlines', s, len((b'a' + s + b'b').splitlines()))
for ch in ['\n', '\r', '\x0b', ' ', '\x85']:
    print('dumps', repr(ch), json.dumps(ch, ensure_ascii=False).encode('utf8'))
# 2. flock across two fds in one process (per open-file-description)
d = tempfile.mkdtemp(dir=sys.argv[1])
p = pathlib.Path(d) / 'slot-0.lock'
a = p.open('a+b'); fcntl.flock(a.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
b = p.open('a+b')
try:
    fcntl.flock(b.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB); print('second fd acquired: BAD')
except BlockingIOError:
    print('second fd blocked (per-OFD flock): OK')
b.close(); a.close()
# 3. flock after unlink+recreate (lock file replaced while held)
a = p.open('a+b'); fcntl.flock(a.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
os.unlink(p)
b = p.open('a+b')
try:
    fcntl.flock(b.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB); print('after unlink, new inode acquired while old held: double lease possible')
except BlockingIOError:
    print('after unlink still blocked')
b.close(); a.close()
# 4. head sequence semantics: negative / zero / bool
events = [{'sha256': 'e1'}, {'sha256': 'e2'}, {'sha256': 'e3'}]
for seq in [0, -1, -3, True]:
    try:
        cond = seq > len(events) or (seq and events[seq - 1]['sha256'] != 'X')
        print('head seq', seq, 'mismatch-raised?' , cond, 'index used', seq - 1)
    except Exception as e:
        print('head seq', seq, type(e).__name__)
# 5. surrogate in event_id -> canonical encode
try:
    json.dumps({'e': '\ud800'}, ensure_ascii=False).encode('utf8')
except UnicodeEncodeError as e:
    print('lone surrogate: UnicodeEncodeError before any write; isinstance ValueError =', isinstance(e, ValueError))
# 6. JSON true as sequence
print('True != 0+1 ->', True != 0 + 1)
# 7. AttributeError from .get on non-dict toolchain
r = {'toolchain': None}
try:
    r.get('toolchain', {}).get('pins_sha256')
except AttributeError:
    print('toolchain None -> AttributeError (not in _complete except tuple)')
