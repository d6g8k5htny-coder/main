#!/usr/bin/env python3
"""Verify carrier members against selected_members.tsv and file_list.tsv. usage: python3 -I verify.py CARRIER_DIR"""
import hashlib, sys, os
root = os.path.join(sys.argv[1], 'v20_planner_source_carrier')
sel = [l.rstrip('\n').split('\t') for l in open(os.path.join(root, 'selected_members.tsv')) if l.strip()]
fl = {}
for l in open(os.path.join(root, 'file_list.tsv')):
    p = l.rstrip('\n').split('\t')
    if len(p) >= 4: fl[p[1]] = (p[2], p[3])
ok = 0
for path, size, sha in sel:
    b = open(os.path.join(root, 'sources', path), 'rb').read()
    h = hashlib.sha256(b).hexdigest()
    m = (str(len(b)) == size and h == sha)
    fm = any(k.endswith(path) and v == (size, sha) for k, v in fl.items())
    print('OK ' if m and fm else 'BAD', path, len(b), h[:12], 'file_list:', fm)
    ok += m and fm
print(ok, '/', len(sel))
