import json, hashlib
def canonical(v):return json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode('utf8')
for ch in [' ',' ','\x85','\x1c','\x0b','\x0c','\x1d','\x1e']:
    d={'seq':1,'type':'PROPOSAL_CREATED','payload':{'actor':'agent'+ch+'x'},'prev_hash':'0'*64}
    d['event_hash']=hashlib.sha256(canonical(d)).hexdigest()
    raw=canonical(d)+b'\n'
    try:
        lines=raw.decode('utf8').splitlines()
        for l in lines: json.loads(l)
        r='ok (%d lines)'%len(lines)
    except Exception as e: r='FAIL %s: %s'%(type(e).__name__, e)
    # byte split
    try:
        for l in raw.splitlines(): json.loads(l)
        b='ok'
    except Exception as e: b='FAIL '+type(e).__name__
    print(repr(ch), 'str.splitlines:', r, '| bytes.splitlines:', b, '| JSONDecodeError subclass ValueError:', issubclass(json.JSONDecodeError, ValueError))
