# Standalone model of proof_conductor._append's byte estimate versus the bytes
# engine/conductor.py Journal.append actually writes. Reimplements the canonical
# serializer from its one-line source; imports nothing from the carrier.
import json, hashlib, sys, ast
from datetime import datetime, timezone

def canonical(v):
    return json.dumps(v, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode('utf8')

def written_line(etype, payload, seq=4321, prev='f'*64):
    d = {'seq': seq, 'when_utc': datetime.now(timezone.utc).isoformat(), 'type': etype,
         'payload': payload, 'prev_hash': prev}
    d['event_hash'] = hashlib.sha256(canonical(d)).hexdigest()
    return canonical(d) + b'\n'

now = 1793000000.123456
claim = {'claim_id': 'claim-' + '0'*32, 'artifact_directory': 'artifacts/claim-' + '0'*32,
         'task_id': 'ft-' + 'a'*24, 'agent_id': 'frontier:job-0123456789', 'strategy': 'scope_guidance',
         'claimed_at': now, 'lease_seconds': 60, 'expires_at': now + 60,
         'input_fingerprint': 'b'*64, 'question_sha256': 'c'*64, 'scope_sha256': 'd'*64}
est = len(str(claim).encode('utf8')); real = len(written_line('TASK_CLAIMED', claim))
print('TASK_CLAIMED estimate', est, 'written', real, 'undercount', real - est)

def failure(evidence):
    attempt = {'attempt_id': 'attempt-claim-' + '0'*32, 'claim_id': 'claim-' + '0'*32, 'task_id': 'ft-' + 'a'*24,
               'diagnosis': 'timeout', 'evidence': evidence, 'submitted_at': now + 5,
               'input_fingerprint': 'b'*64, 'kind': 'agent_failure_report'}
    decision = {'decision_id': 'decision-claim-' + '0'*32, 'claim_id': 'claim-' + '0'*32, 'task_id': 'ft-' + 'a'*24,
                'diagnosis': 'timeout', 'action': 'replan', 'previous_strategy': 'scope_guidance',
                'strategy': 'bounded_partition', 'disposition': 'investigate_report',
                'question_sha256': 'c'*64, 'scope_sha256': 'd'*64, 'input_fingerprint': 'b'*64,
                'guidance': 'Partition the investigation into bounded subquestions without dropping premises.',
                'preserve_dependencies': [], 'proposed_only': True,
                'mathematical_verdict': 'not_established_by_agent_report',
                'technical_retry_same_fixed_worker': False}
    return {'attempt': attempt, 'decision': decision}

for label, ev in [('evidence None', None),
                  ('evidence 15000 double quotes', {'r': '"' * 15000}),
                  ('evidence 7000 C0 controls', {'r': '\x01' * 7000})]:
    p = failure(ev)
    est = len(str(p).encode('utf8')); real = len(written_line('FAILURE_REPORTED', p))
    print('FAILURE_REPORTED', label, 'estimate', est, 'written', real, 'undercount', real - est,
          'canonical evidence bytes', len(canonical(ev)))

MAX = 32 * 1024 * 1024
p = failure({'r': '"' * 15000})
est = len(str(p).encode('utf8')); real = len(written_line('FAILURE_REPORTED', p))
size = MAX - est  # largest admitted st_size for this payload
print('admitted at st_size', size, '-> file after append', size + real, '> MAX by', size + real - MAX)
