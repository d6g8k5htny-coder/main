import json, hashlib, uuid, time
from datetime import datetime, timezone
def canonical(v): return json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode('utf8')
def envelope(etype,payload,seq=9999):
    d={'seq':seq,'when_utc':datetime.now(timezone.utc).isoformat(),'type':etype,'payload':payload,'prev_hash':'a'*64}
    d['event_hash']=hashlib.sha256(canonical(d)).hexdigest()
    return len(canonical(d)+b'\n')
cid='claim-'+uuid.uuid4().hex; now=time.time()
claim={'claim_id':cid,'artifact_directory':'artifacts/'+cid,'task_id':'task-'+'b'*32,'agent_id':'agent-1','strategy':'scope_guidance','claimed_at':now,'lease_seconds':60,'expires_at':now+60,'input_fingerprint':'c'*64,'question_sha256':'d'*64,'scope_sha256':'e'*64}
est=len(str(claim).encode('utf8')); act=envelope('TASK_CLAIMED',claim)
print('claim est',est,'actual',act,'undercount',act-est)
ev={'r':'"'*15000}
print('evidence canonical',len(canonical(ev)),'repr',len(str(ev).encode()))
