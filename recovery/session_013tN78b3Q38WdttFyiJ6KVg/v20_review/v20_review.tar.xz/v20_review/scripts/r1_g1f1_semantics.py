import json, hashlib
def canonical(v):return json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode('utf8')
for ch in [' ',' ','\x85','\x1c','\x0b','\x0c','\x1d','\x1e','\r']:
    d={'seq':1,'type':'PROPOSAL_CREATED','payload':{'actor':'agent'+ch+'x'},'prev_hash':'0'*64}
    d['event_hash']=hashlib.sha256(canonical(d)).hexdigest()
    raw=canonical(d)+b'\n'
    try:
        for line in raw.decode('utf8').splitlines():
            json.loads(line)
        r='ok'
    except ValueError as e:r='FAIL %s: %s'%(type(e).__name__,e)
    print(repr(ch), r, 'bytes-splitlines parts:', len(raw.splitlines()))
