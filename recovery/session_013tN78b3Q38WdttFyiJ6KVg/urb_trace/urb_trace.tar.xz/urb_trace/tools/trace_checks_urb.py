"""Trace-side exact checks for Math- unique_replacement_bar_intensity_20261001 (Claude 54).

Not part of the packet; standard library only; does not import check_exact.py. Each check is a
finite rational computation for a ROOTS.md / PROOF.md step that the packet's fixtures take as given
or do not exercise. Fixtures are copied from check_exact.py main() as (k, s, a, beta, q).
"""
from fractions import Fraction as F
import json
import random

FIXTURES = {
    'two_window': ((F(1), F(-21, 10), F(0), F(-3), F(3, 5)), [(F(-5, 8), F(3, 4)), (F(-5, 6), F(-4, 3))]),
    'below_window': ((F(1), F(-39, 16), F(0), F(-3), F(3, 2)), [(F(-5, 8), F(3, 4)), (F(-37, 24), F(-35, 12))]),
    'nonzero_shear': ((F(1), F(-21, 10), F(12), F(9), F(18, 5)), [(F(-11, 8), F(3, 4)), (F(1, 2), F(-4, 3))]),
}
M0, S0 = (F(-1, 2), F(0)), (F(1, 2), F(0))


def P(p, x, z):
    k, s, a, b, q = p
    return 2*k*x**3 - 3*k*x/2 - k/2 + s*z**2/2 + a*(x**2 - F(1, 4))*z/2 + b*x*z**2/2 + q*z**3/6


def grad(p, x, z):
    k, s, a, b, q = p
    return (6*k*x**2 - 3*k/2 + a*x*z + b*z**2/2, s*z + a*(x**2 - F(1, 4))/2 + b*x*z + q*z**2/2)


def hess_det(p, x, z):
    k, s, a, b, q = p
    return (12*k*x + a*z)*(s + b*x + q*z) - (a*x + b*z)**2


def shear(p):
    k, s, a, b, q = p
    B = b - a*a/(12*k)
    D = (q - a*b/(4*k) + a**3/(72*k*k))/2
    return B, D


# polynomials in z: lists of Fraction coefficients, index = power
def padd(A, B):
    n = max(len(A), len(B))
    return [(A[i] if i < len(A) else 0) + (B[i] if i < len(B) else 0) for i in range(n)]


def pmul(A, B):
    out = [F(0)] * (len(A) + len(B) - 1)
    for i, x in enumerate(A):
        for j, y in enumerate(B):
            out[i + j] += x * y
    return out


def pscale(A, c):
    return [c * x for x in A]


def ptrim(A):
    A = list(A)
    while len(A) > 1 and A[-1] == 0:
        A.pop()
    return A


def pdivmod(A, B):
    A, B = ptrim(A), ptrim(B)
    q = [F(0)] * max(1, len(A) - len(B) + 1)
    r = A[:]
    while len(ptrim(r)) >= len(B) and any(r):
        r = ptrim(r)
        c = r[-1] / B[-1]
        d = len(r) - len(B)
        q[d] = c
        r = padd(r, [0] * d + pscale(B, -c))
        r = r[:-1] if len(r) > 1 else r
    return ptrim(q), ptrim(r)


results = {}

# U1. Completeness of the critical-point list. grad P = (g1, g2), each quadratic in x with coefficients in z.
#     Res_x(g1, g2)(z) has degree <= 4; it equals c z^2 (z - z1)(z - z2) with c != 0, where z1, z2 are the
#     fixture extras. So the critical z-values are exactly {0, z1, z2}; z = 0 gives exactly the two pins, and each
#     extra z-value gives exactly one common x, which is the fixture's. Hence the fixture lists ALL critical points.
u1 = {}
for name, (p, extras) in FIXTURES.items():
    k, s, a, b, q = p
    A1, B1, C1 = [6*k], [F(0), a], [-3*k/2, F(0), b/2]                       # g1 = A1 x^2 + B1 x + C1
    A2, B2, C2 = [a/2], [F(0), b], [-a/8, s, q/2]                            # g2 = A2 x^2 + B2 x + C2
    t1 = padd(pmul(A1, C2), pscale(pmul(C1, A2), -1))                        # A1 C2 - C1 A2
    t2 = padd(pmul(A1, B2), pscale(pmul(B1, A2), -1))                        # A1 B2 - B1 A2
    t3 = padd(pmul(B1, C2), pscale(pmul(C1, B2), -1))                        # B1 C2 - C1 B2
    res = ptrim(padd(pmul(t1, t1), pscale(pmul(t2, t3), -1)))
    z1, z2 = extras[0][1], extras[1][1]
    target = pmul(pmul([F(0), F(0), F(1)], [-z1, F(1)]), [-z2, F(1)])
    quo, rem = pdivmod(res, target)
    ok = len(quo) == 1 and quo[0] != 0 and rem == [0] and len(res) == 5 and z1 != z2 and 0 not in (z1, z2)
    # at z = 0 the common roots are exactly x = +-1/2
    ok &= grad(p, F(-1, 2), F(0)) == (0, 0) and grad(p, F(1, 2), F(0)) == (0, 0)
    # at each extra z the common x is unique: eliminate x^2 to get a linear equation, then check the fixture x
    for (x, z) in extras:
        a1, b1, c1 = 6*k, a*z, -3*k/2 + b*z*z/2
        a2, b2, c2 = a/2, b*z, -a/8 + s*z + q*z*z/2
        lin_b, lin_c = a2*b1 - a1*b2, a2*c1 - a1*c2                          # a2*g1 - a1*g2 = lin_b x + lin_c
        ok &= lin_b != 0 and -lin_c/lin_b == x and grad(p, x, z) == (0, 0)
    u1[name] = ok
results['U1_all_critical_points_listed'] = u1

# U2. Hessian determinant formulas: extras det = -3k(B_s + 4 s u), u = X + aZ/(12k) (CUB (C8), ROOTS R1);
#     pins det = 3k(B_s - 2s) at M0 and 3k(B_s + 2s) at S0 (ROOTS R1 L75-76).
u2 = {}
for name, (p, extras) in FIXTURES.items():
    k, s, a, b, q = p
    B, D = shear(p)
    ok = hess_det(p, *M0) == 3*k*(B - 2*s) and hess_det(p, *S0) == 3*k*(B + 2*s)
    for (x, z) in extras:
        u = x + a*z/(12*k)
        ok &= hess_det(p, x, z) == -3*k*(B + 4*s*u)
        # the reduced system (R1.1) holds at the extras
        ok &= 6*k*(u*u - F(1, 4)) + B*z*z/2 == 0 and s + B*u + D*z == 0 and z != 0
    u2[name] = ok
results['U2_determinant_formulas_and_R1_1'] = u2

# U3. H = H_poly / (1728 k^3) with U = 12k beta - a^2, V = 72k^2 q - 18k a beta + a^3 (ROOTS R1 L83-88),
#     and the q^2 coefficient of H_poly is 5184 k^4 (L88-89). Randomized exact identity check at 300 rational
#     points plus the fixtures (a polynomial identity of low degree; evidence, not a symbolic proof).
rng = random.Random(20261026)


def Hval(p):
    k, s, a, b, q = p
    B, D = shear(p)
    return 12*k*D*D + B**3 - 4*B*s*s


def Hpoly(p):
    k, s, a, b, q = p
    U = 12*k*b - a*a
    V = 72*k*k*q - 18*k*a*b + a**3
    return V*V + U**3 - 576*k*k*U*s*s


def rnd():
    return F(rng.randint(-40, 40), rng.randint(1, 12))


pts = [p for p, _ in FIXTURES.values()] + [(F(rng.randint(1, 30), rng.randint(1, 9)), rnd(), rnd(), rnd(), rnd()) for _ in range(300)]
results['U3_H_equals_Hpoly_over_1728k3'] = all(Hval(p) == Hpoly(p) / (1728 * p[0]**3) for p in pts)
results['U3_q2_coefficient_5184k4'] = all(
    (Hpoly((p[0], p[1], p[2], p[3], F(1))) + Hpoly((p[0], p[1], p[2], p[3], F(-1))) - 2*Hpoly((p[0], p[1], p[2], p[3], F(0))))/2
    == 5184 * p[0]**4 for p in pts)

# U4. (R1.3) derivation: after D_s Z = -s - B_s u and B_s Z^2 = -12k(u^2 - 1/4), H Z^2 = 3k(B_s + 4su)^2 reduces to
#     12k(s + B u)^2 - 12k B^2 (u^2 - 1/4) + 48 k s^2 (u^2 - 1/4) = 3k(B + 4 s u)^2, an identity in (k, s, B, u).
def r13(k, s, B, u):
    return 12*k*(s + B*u)**2 - 12*k*B*B*(u*u - F(1, 4)) + 48*k*s*s*(u*u - F(1, 4)) - 3*k*(B + 4*s*u)**2


results['U4_R1_3_substitution_identity'] = all(r13(rnd(), rnd(), rnd(), rnd()) == 0 for _ in range(300))
results['U4_R1_3_at_fixture_extras'] = all(
    Hval(p) * z * z == 3*p[0]*(shear(p)[0] + 4*p[1]*(x + p[2]*z/(12*p[0])))**2
    for p, extras in FIXTURES.values() for (x, z) in extras)

# U5. PROOF (7) is a double-counting identity. Check its bookkeeping on random finite planar configurations:
#     maxima M with heights f(M), an actual partner and a signed mark Phi(M); saddles S with heights. A pair (M, S)
#     is an admissible rejected pair when S is not M's partner, f(S) < f(M), c0 <= t|S - M| <= C0 and the normalized
#     gap (f(M) - f(S))/|S - M|^3 lies in [klo, khi] (squared forms, so everything stays rational). D(M) is counted
#     per maximum; the pair list is enumerated separately, saddle by saddle. The two sides of (7) must agree, maxima
#     with D = 0 must drop out of both, and the unweighted pair sum must differ on some configuration.
def u5_config(seed):
    g = random.Random(seed)
    maxima = [((F(g.randint(-12, 12), 4), F(g.randint(-12, 12), 4)), F(g.randint(1, 40), 8),
               F(g.randint(-20, 20), g.randint(1, 6))) for _ in range(g.randint(3, 7))]
    saddles = [((F(g.randint(-12, 12), 4), F(g.randint(-12, 12), 4)), F(g.randint(-40, 20), 8))
               for _ in range(g.randint(4, 12))]
    partner = [g.randrange(len(saddles)) for _ in maxima]
    return maxima, saddles, partner


def u5_admissible(M, S, is_partner, t=F(1), c0=F(1, 2), C0=F(5, 2), klo=F(1, 50), khi=F(4)):
    (mpos, fm, _), (spos, fs) = M, S
    d2 = (mpos[0] - spos[0])**2 + (mpos[1] - spos[1])**2
    gap = fm - fs
    return (not is_partner and gap > 0 and d2 > 0 and c0*c0 <= t*t*d2 <= C0*C0
            and klo*klo*d2**3 <= gap*gap <= khi*khi*d2**3)


u5_ok, u5_seen_D, u5_unweighted_differs, u5_partner_matters = True, set(), 0, 0
for seed in range(300):
    maxima, saddles, partner = u5_config(seed)
    Dm = [sum(u5_admissible(M, S, j == partner[i]) for j, S in enumerate(saddles)) for i, M in enumerate(maxima)]
    u5_seen_D |= set(Dm)
    pairs = [(i, j) for j, S in enumerate(saddles) for i, M in enumerate(maxima) if u5_admissible(M, S, j == partner[i])]
    lhs = sum(M[2] for i, M in enumerate(maxima) if Dm[i] > 0)
    u5_ok &= all(Dm[i] > 0 for i, j in pairs) and lhs == sum(maxima[i][2] / Dm[i] for i, j in pairs)
    u5_unweighted_differs += sum(maxima[i][2] for i, j in pairs) != lhs
    # control on the check itself: a count that forgets the partner exclusion must break the identity somewhere
    Dbad = [sum(u5_admissible(M, S, False) for S in saddles) for M in maxima]
    u5_partner_matters += lhs != sum(maxima[i][2] / Dbad[i] for i, j in pairs)
u5_ok &= u5_unweighted_differs > 0 and u5_partner_matters > 0
results['U5_once_per_bar_double_counting'] = u5_ok
results['U5_configs_where_unweighted_differs'] = u5_unweighted_differs
results['U5_configs_where_partnerless_count_breaks_it'] = u5_partner_matters
results['U5_D_values_seen'] = sorted(u5_seen_D)

# U6. Radial ledger and coefficient (PROOF L188, L195): substituting r = t h turns int_{c0 h}^{C0 h} r dr * r^3
#     into h^5 int_{c0}^{C0} t^4 dt = h^5 (C0^5 - c0^5)/5. Both integrals are computed by Boole's rule on 4 equal
#     subintervals, which is exact for polynomials of degree <= 5, so each side is an exact rational integral.
def boole(f, lo, hi):
    h = (hi - lo) / 4
    return (hi - lo) / 90 * (7*f(lo) + 32*f(lo + h) + 12*f(lo + 2*h) + 32*f(lo + 3*h) + 7*f(hi))


results['U6_boole_exact_degree_5_not_6'] = (boole(lambda t: t**5, F(1, 3), F(2)) == (F(2)**6 - F(1, 3)**6) / 6
                                            and boole(lambda t: t**6, F(1, 3), F(2)) != (F(2)**7 - F(1, 3)**7) / 7)
results['U6_C_R_radial_factor'] = all(
    boole(lambda t: t**4, F(i, 7), F(i + j, 7)) == (F(i + j, 7)**5 - F(i, 7)**5) / 5
    for i in range(1, 6) for j in range(1, 6))
results['U6_substitution_r_eq_th'] = all(
    boole(lambda r: r * r**3, c0 * h, C0 * h) == h**5 * boole(lambda t: t**4, c0, C0) == h**5 * (C0**5 - c0**5) / 5
    for c0, C0 in [(F(1, 3), F(2)), (F(1, 2), F(7, 4)), (F(2, 9), F(11, 5))]
    for h in [F(1, 5), F(3, 7), F(1, 100)])

# U7. ROOTS R2 scaling: P_(k, k eta) = k P_(1, eta) pointwise; B_s and D_s are homogeneous of degree 1; strict typing
#     s < -|B_s|/2 is preserved; the map (k, eta) -> (k, k eta) on (0, inf) x R^4 has Jacobian k^4.
u7 = True
for _ in range(200):
    k = F(rng.randint(1, 20), rng.randint(1, 7))
    eta = (rnd(), rnd(), rnd(), rnd())
    p1 = (F(1),) + eta
    pk = (k,) + tuple(k * e for e in eta)
    x, z = rnd(), rnd()
    u7 &= P(pk, x, z) == k * P(p1, x, z) and grad(pk, x, z) == tuple(k * g for g in grad(p1, x, z))
    B1, D1 = shear(p1)
    Bk, Dk = shear(pk)
    u7 &= Bk == k * B1 and Dk == k * D1 and ((pk[1] < -abs(Bk)/2) == (p1[1] < -abs(B1)/2))
results['U7_scaling_rays'] = u7
# The map (k, eta) -> (k, k eta) is bilinear, so central differences give its Jacobian exactly. The matrix is
# lower-triangular (first row (1, 0, 0, 0, 0), first column (1, eta)); its determinant is computed, not assumed.
def det(Mx):
    Mx = [row[:] for row in Mx]
    n, out = len(Mx), F(1)
    for c in range(n):
        piv = next((r for r in range(c, n) if Mx[r][c] != 0), None)
        if piv is None:
            return F(0)
        if piv != c:
            Mx[c], Mx[piv] = Mx[piv], Mx[c]
            out = -out
        out *= Mx[c][c]
        for r in range(c + 1, n):
            f = Mx[r][c] / Mx[c][c]
            Mx[r] = [a - f * b for a, b in zip(Mx[r], Mx[c])]
    return out


def ray(v):
    return (v[0],) + tuple(v[0] * e for e in v[1:])


u7j = True
for _ in range(100):
    v = (F(rng.randint(1, 20), rng.randint(1, 7)), rnd(), rnd(), rnd(), rnd())
    eps = F(1, 3)
    J = [[(ray(tuple(v[m] + (eps if m == j else 0) for m in range(5)))[i]
           - ray(tuple(v[m] - (eps if m == j else 0) for m in range(5)))[i]) / (2 * eps) for j in range(5)]
         for i in range(5)]
    u7j &= det(J) == v[0]**4 and all(J[0][j] == (1 if j == 0 else 0) for j in range(5))
results['U7_jacobian_k4'] = u7j

# U8. R3.2 on the fixtures: the rejected count D is in {1, 2}, and both values occur (two_window t=1 gives 2,
#     t=8/5 gives 1; nonzero_shear gives 1), recomputed here from the definitions in (5).
def D_count(p, extras, band, gaps, t):
    roots = [M0, S0] + extras
    window = [y for y in extras if -p[0] < P(p, *y) < 0]
    partner = max(window, key=lambda y: P(p, *y))
    n = 0
    for y in roots:
        if y == partner or hess_det(p, *y) >= 0 or P(p, *y) >= 0:
            continue
        d2 = (y[0] - M0[0])**2 + y[1]**2
        if not (band[0]**2 <= t*t*d2 <= band[1]**2):
            continue
        if gaps[0]**2 * d2**3 <= P(p, *y)**2 <= gaps[1]**2 * d2**3:
            n += 1
    return n


counts = {
    'two_window_t1': D_count(*FIXTURES['two_window'], (F(1, 2), F(2)), (F(1, 10), F(2)), F(1)),
    'two_window_t8_5': D_count(*FIXTURES['two_window'], (F(1, 2), F(2)), (F(1, 10), F(2)), F(8, 5)),
    'below_window_t1': D_count(*FIXTURES['below_window'], (F(1, 2), F(4)), (F(1, 100), F(2)), F(1)),
    'nonzero_shear_t1': D_count(*FIXTURES['nonzero_shear'], (F(1, 2), F(3, 2)), (F(1, 100), F(2)), F(1)),
}
results['U8_counts'] = counts
results['U8_D_in_1_2_both_occur'] = set(counts.values()) == {1, 2}

print(json.dumps(results, indent=1))
