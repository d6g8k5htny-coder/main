"""Demonstrate that one extra control would close URB findings UF-1 and UF-2 (Claude 54).

usage: python3 -B -I proposed_control_demo.py CENSUS_JSON PATH_TO_check_exact.py
The control re-runs the packet's own verify_fixture on its nonzero-shear fixture scaled to k = 5/7 (heights scaled
by 5/7, determinants by (5/7)^2), and pins all five shear_data outputs (B_s, D_s, Sigma, Delta, H) there to ROOTS R1
values computed here. The original passes. The main report covers the census survivors in the k-placement and
shear-data floor-division classes at L142, L148, L149, L151, L214, L215 and the Sigma class at L150. A second report
covers the other survivors with the same causes: L204 `//` (integer B_s) and L159 (negative-control distance).
"""
import importlib.util, json, os, sys, tempfile
from fractions import Fraction as F
census, original = sys.argv[1], sys.argv[2]
r = json.load(open(census))
KP = {142, 148, 149, 151, 214, 215}
cands = [x for x in r[2:] if x['verdict'] == 'SURVIVED'
         and ((x['line'] in KP and x['site'][0] != 'require') or x['line'] == 150)]
P3 = (F(1), F(-21, 10), F(12), F(9), F(18, 5))
EXTRAS3 = [(F(-11, 8), F(3, 4)), (F(1, 2), F(-4, 3))]
H3, D3 = [F(-23, 320), F(-13, 45)], [F(-27, 4), F(-12)]
LAM = F(5, 7)
P3S = tuple(LAM * v for v in P3)
work = tempfile.mkdtemp(prefix='urb-control-')


def load(src, tag):
    path = os.path.join(work, tag + '.py')
    with open(path, 'w') as fh:
        fh.write(src + '\n')
    spec = importlib.util.spec_from_file_location(tag, path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def control(m):
    m.verify_fixture('nonzero_shear_scaled', P3S, EXTRAS3, [LAM * h for h in H3], [LAM * LAM * d for d in D3])
    k, s, a, b, q = P3S
    B = b - a * a / (12 * k)
    D = (q - a * b / (4 * k) + a ** 3 / (72 * k * k)) / 2
    want = (B, D, 12 * k * D * D + (s - B) ** 2 * (B + 2 * s), 12 * k * D * D + B ** 3, 12 * k * D * D + B ** 3 - 4 * B * s * s)
    if tuple(m.shear_data(P3S)) != want:
        raise RuntimeError('shear data')


control(load(open(original).read(), 'original'))
killed = 0
for i, x in enumerate(cands):
    try:
        control(load(x['source'], 'm%d' % i))
    except Exception:
        killed += 1
extra = [x for x in r[2:] if x['verdict'] == 'SURVIVED'
         and ((x['line'] == 204 and x['site'][0] == 'binop') or x['line'] == 159)]
extra_report = []
for i, x in enumerate(extra):
    try:
        control(load(x['source'], 'e%d' % i))
        extra_report.append((x['line'], x['site'], 'survives'))
    except Exception:
        extra_report.append((x['line'], x['site'], 'killed'))
print(json.dumps({'original_passes': True, 'candidates': len(cands), 'killed': killed,
                  'same_cause_elsewhere': extra_report}))
