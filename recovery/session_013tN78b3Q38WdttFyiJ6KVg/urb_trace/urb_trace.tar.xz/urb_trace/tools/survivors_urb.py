"""Group URB census survivors by original source line (Claude 54). usage: python3 -B -I survivors_urb.py CENSUS_JSON CHECK_EXACT_PY"""
import json, sys, collections, difflib, ast
r = json.load(open(sys.argv[1]))
src = open(sys.argv[2]).read().splitlines()
orig = ast.unparse(ast.parse('\n'.join(src))).splitlines()
c = collections.Counter(x.get('verdict') for x in r[2:])
print('baseline', {m: r[0]['result'][m]['ok'] for m in r[0]['result']}, 'unparsed', {m: r[1]['result'][m]['ok'] for m in r[1]['result']})
print('verdicts', dict(c), 'total', sum(c.values()))
by = collections.defaultdict(list)
for x in r[2:]:
    if x['verdict'] != 'KILLED':
        new = x['source'].splitlines()
        d = [l for l in difflib.unified_diff(orig, new, lineterm='', n=0) if l.startswith('+') and not l.startswith('+++')]
        by[x['line']].append((x['verdict'], x['site'][0], x['site'][2], d[0][1:].strip()[:140] if d else ''))
for line in sorted(by, key=lambda v: (v is None, v)):
    print(f'L{line} [{len(by[line])}] {src[line-1].strip()[:110] if line else ""}')
    for v in by[line]:
        print('    ', v)
