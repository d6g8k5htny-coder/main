"""Classify URB census survivors into reading classes (Claude 54). usage: python3 -B -I classify_urb.py CENSUS_JSON"""
import json, sys, collections
r = json.load(open(sys.argv[1]))
surv = [x for x in r[2:] if x['verdict'] == 'SURVIVED']
cls = collections.Counter()
detail = collections.defaultdict(list)
KPLACE = {142, 148, 149, 151, 214, 215}
for x in surv:
    ln, kind = x['line'], x['site'][0]
    if kind in ('require', 'raise'):
        c = 'A_assertion_removed'
    elif 22 <= ln <= 118:
        c = 'B_source_binding_guard_or_message'
    elif ln == 150:
        c = 'C_sigma_formula_only_nonzero'
    elif ln in KPLACE and ln != 215 or (ln == 215 and kind == 'binop'):
        c = 'D_k_or_shear_placement_k_equals_1'
    elif ln in (164,):
        c = 'E_admissible_filters_never_decisive'
    elif ln in (168, 172, 181, 183):
        c = 'F_band_gap_boundary_or_exponent'
    elif ln in (159, 193):
        c = 'G_negative_control_path_only'
    elif ln in (177, 180):
        c = 'H_margin_precondition_slack'
    elif ln in (232, 233, 234, 243, 261, 262, 264, 274, 275, 276, 283):
        c = 'I_fixture_parameter_robust'
    elif ln == 308:
        c = 'J_output_format'
    else:
        c = 'K_other_check_slack'
    cls[c] += 1
    detail[c].append(ln)
print(json.dumps({k: {'count': v, 'lines': sorted(set(detail[k]))} for k, v in sorted(cls.items())}, indent=1))
print('total', sum(cls.values()))
