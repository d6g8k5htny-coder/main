"""Classify URB census survivors by explicit line-and-kind rules (Claude 54, revised after verification).
usage: python3 -B -I classify2_urb.py CENSUS_JSON"""
import json, sys, collections
r = json.load(open(sys.argv[1]))
surv = [x for x in r[2:] if x['verdict'] == 'SURVIVED']
FUN = [('contained_file', 21, 35), ('source_git', 38, 53), ('verify_historical_source', 56, 75),
       ('verify_source_entry', 77, 89), ('verify_sources', 92, 118)]
MARGIN_CALLS = {233, 234, 262, 275, 276}          # t values passed to verify_strict_margins
FIXTURE_CONSTANTS = {232, 261, 274, 283}           # band/gap endpoints and the scale constant
COUNT_T = {243, 264}                                # t values in counted rejected() calls


def klass(x):
    ln, kind, arg = x['line'], x['site'][0], x['site'][2]
    if 21 <= ln <= 118:
        name = next(n for n, a, b in FUN if a <= ln <= b)
        if name == 'verify_sources':
            if ln in (98, 100, 102, 103):
                return 'src:verify_sources:manifest_shape_key_set'
            if ln == 94:
                return 'src:verify_sources:script_symlink'
            return 'src:verify_sources:probe_or_message'
        return 'src:' + name
    if kind in ('require', 'raise'):
        return 'fixture_assertion_removed'
    if ln == 150:
        return 'sigma_formula'
    if kind == 'binop' and arg == 'FloorDiv' and ln in (148, 149, 204):
        return 'floor_division_integer_shear_data'
    if ln in (142, 148, 149, 151, 214) or (ln == 215 and kind == 'binop'):
        return 'k_placement_k_equals_1'
    if ln == 164:
        return 'admissible_filters'
    if ln in (168, 172):
        return 'admissible_band_gap_bounds'
    if ln in (159, 193):
        return 'negative_control_fidelity'
    if ln == 217:
        return 'window_definition'
    if ln in FIXTURE_CONSTANTS or ln in COUNT_T:
        return 'fixture_constants_and_count_t'
    if ln == 308:
        return 'output_format'
    if ln in MARGIN_CALLS or 175 <= ln <= 289:
        return 'fixture_assertion_weakened'
    return 'other'


c = collections.Counter(klass(x) for x in surv)
lines = collections.defaultdict(set)
for x in surv:
    lines[klass(x)].add(x['line'])
for k in sorted(c):
    print(f'{k}: {c[k]}  lines {sorted(lines[k])}')
print('total', sum(c.values()))
