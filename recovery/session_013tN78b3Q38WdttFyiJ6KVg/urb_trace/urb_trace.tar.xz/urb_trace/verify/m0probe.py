import importlib.util, sys
spec = importlib.util.spec_from_file_location("ce", sys.argv[1]); c = importlib.util.module_from_spec(spec); spec.loader.exec_module(c)
F = c.F
p1 = (F(1), F(-21, 10), F(0), F(-3), F(3, 5))
M = c.M
print("det(M0)", c.determinant(p1, M), "value(M0)", c.value(p1, M), "d2(M0)", c.distance_squared(p1, M))
print("M0 off gap boundary?", all(c.value(p1, M)**2 != e*e*c.distance_squared(p1, M)**3 for e in (F(1,10), F(2))))
