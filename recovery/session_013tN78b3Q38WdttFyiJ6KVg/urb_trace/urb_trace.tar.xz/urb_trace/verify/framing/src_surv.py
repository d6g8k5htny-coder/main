import json, sys, difflib, ast
r = json.load(open(sys.argv[1]))
orig = ast.unparse(ast.parse(open(sys.argv[2]).read())).splitlines()
for x in r[2:]:
    if x['verdict']=='SURVIVED' and 38<=x['line']<=89:
        d=[l for l in difflib.unified_diff(orig, x['source'].splitlines(), lineterm='', n=0) if l.startswith('+') and not l.startswith('+++')]
        print(x['line'], x['site'][0], x['site'][2], (d[0][1:].strip()[:140] if d else '(deleted line)'))
