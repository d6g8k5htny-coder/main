import json, sys, difflib, ast
r = json.load(open(sys.argv[1]))
orig = ast.unparse(ast.parse(open(sys.argv[2]).read())).splitlines()
want = set(int(v) for v in sys.argv[3].split(','))
for x in r[2:]:
    if x['verdict']=='SURVIVED' and x['line'] in want:
        d=[l for l in difflib.unified_diff(orig, x['source'].splitlines(), lineterm='', n=0) if l.startswith('+') and not l.startswith('+++')]
        print(x['line'], x['site'][0], x['site'][2], (d[0][1:].strip()[:150] if d else '(deleted)'))
