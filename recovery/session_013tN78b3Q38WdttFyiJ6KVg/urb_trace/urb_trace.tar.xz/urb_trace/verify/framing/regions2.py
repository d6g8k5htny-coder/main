import json, sys, collections, difflib, ast
r = json.load(open(sys.argv[1]))
src = open(sys.argv[2]).read()
orig = ast.unparse(ast.parse(src)).splitlines()
surv = [x for x in r[2:] if x['verdict']=='SURVIVED']
def diff(x):
    d=[l for l in difflib.unified_diff(orig, x['source'].splitlines(), lineterm='', n=0) if l.startswith('+') and not l.startswith('+++')]
    return d[0][1:].strip()[:150] if d else ''
fp = [x for x in surv if (x['line']==217 or 232<=x['line']<=283) and x['site'][0] not in ('require','raise')]
print('fixture-param non-require', len(fp))
fa = [x for x in surv if 175<=x['line']<=289 and x['line'] not in (215,) and not (x['line']==217 or 232<=x['line']<=283)]
fa_req = [x for x in surv if (x['line']==217 or 232<=x['line']<=283) and x['site'][0] in ('require','raise')]
print('fixture-assert other-lines', len(fa), 'req in param region', len(fa_req), 'L215 req', sum(1 for x in surv if x['line']==215 and x['site'][0]=='require'))
for x in fp: print('FP', x['line'], x['site'][0], x['site'][2], diff(x))
