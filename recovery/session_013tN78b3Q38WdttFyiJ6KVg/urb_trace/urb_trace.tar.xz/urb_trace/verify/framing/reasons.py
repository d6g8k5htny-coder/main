import sys, importlib.util, unittest, io
from pathlib import Path
P = Path(sys.argv[1])
spec = importlib.util.spec_from_file_location("ts", P / "test_sources.py")
ts = importlib.util.module_from_spec(spec); spec.loader.exec_module(ts)
c = ts.c
orig = c.verify_source_entry
msgs = {}
def wrapped(repo, entry):
    try:
        return orig(repo, entry)
    except RuntimeError as e:
        msgs.setdefault(cur[0], []).append(str(e)); raise
cur = [None]
c.verify_source_entry = wrapped
loader = unittest.TestLoader()
for name in loader.getTestCaseNames(ts.HistoricalSourceTests):
    cur[0] = name
    r = unittest.TestResult()
    ts.HistoricalSourceTests(name).run(r)
    print(name, 'OK' if r.wasSuccessful() else 'FAIL', msgs.get(name))
