import json, sys, collections
r = json.load(open(sys.argv[1]))
muts = r[2:]
print('total', len(muts), collections.Counter(x['verdict'] for x in muts))
surv = [x for x in muts if x['verdict']=='SURVIVED']
by = collections.Counter(x['line'] for x in surv)
print(sorted(by.items()))
K = {142,148,149,151,214,215}
def cls(x):
    ln=x['line']
    if 21<=ln<=118: return 'src L21-118'
    if ln==150: return 'sigma L150'
    if ln in K: return 'kplace'
    if ln==164: return 'adm L164'
    if ln in (168,172): return 'band L168/172'
    if ln in (159,193): return 'negctl 159/193'
    if ln==217 or 232<=ln<=283: return 'fixture params L217,L232-283'
    if ln==308: return 'fmt'
    if 175<=ln<=289: return 'fixture assertion L175-289 other'
    return 'OTHER'
c = collections.Counter(cls(x) for x in surv)
print(c, sum(c.values()))
# kplace detail
for x in surv:
    if x['line'] in K: print('K', x['line'], x['site'])
# mixed results
print('mixed', [x for x in muts if x['verdict']=='MIXED'][:1])
# check per-mode consistency
inc = [x for x in muts if x['result']['normal']['ok'] != x['result']['optimized']['ok']]
print('mode-inconsistent', len(inc))
print('baseline', r[0]['result']['normal']['ok'], r[0]['result']['optimized']['ok'], r[1]['result']['normal']['ok'], r[1]['result']['optimized']['ok'])
lines_outside = sorted({x['line'] for x in surv if cls(x)=='OTHER'})
print('other', lines_outside)
