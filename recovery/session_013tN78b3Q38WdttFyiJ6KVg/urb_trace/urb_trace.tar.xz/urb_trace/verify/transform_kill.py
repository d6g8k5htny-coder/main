"""Run original and each census survivor on domain-valid transformed fixtures (reflection Z->-Z, scaling k->lam)."""
import json, sys, io, contextlib, ast, collections
from fractions import Fraction as F

census, orig_path = sys.argv[1], sys.argv[2]
r = json.load(open(census))
orig = ast.unparse(ast.parse(open(orig_path).read()))
surv = [x for x in r[2:] if x['verdict'] == 'SURVIVED']

PRELUDE = '''
from fractions import Fraction as _Fr
_MODE = %r
_LAM = _Fr(%s)
def _P(p):
    k, s, a, b, q = p
    if 'reflect' in _MODE:
        a, q = -a, -q
    p = (k, s, a, b, q)
    if 'scale' in _MODE:
        p = tuple(_LAM * v for v in p)
    return p
def _Y(pts):
    if 'reflect' in _MODE:
        return tuple((x, -z) for x, z in pts)
    return pts
def _BG(bg):
    band, gaps = bg
    if 'scale' in _MODE:
        gaps = tuple(_LAM * g for g in gaps)
    return band, gaps
def _L1(v):
    return _LAM * v if 'scale' in _MODE else v
def _L2(v):
    return _LAM * _LAM * v if 'scale' in _MODE else v
'''

def transform(src, mode, lam):
    lines = src.splitlines()
    out = []
    in_main = False
    applied = collections.Counter()
    for ln in lines:
        if ln.startswith('def main('):
            in_main = True
        elif ln and not ln.startswith(' ') and in_main and not ln.startswith('def main'):
            in_main = False
        if in_main:
            st = ln.strip()
            ind = ln[:len(ln) - len(ln.lstrip())]
            if st == 'source_binding = verify_sources()':
                ln = ind + 'source_binding = {}'; applied['src'] += 1
            for nm in ('p1', 'p2', 'p3'):
                if st.startswith(nm + ' = ('):
                    ln = ind + nm + ' = _P(' + st[len(nm) + 3:] + ')'; applied['p'] += 1
            for nm in ('y11, y12', 'y21, y22', 'y31, y32'):
                if st.startswith(nm + ' = '):
                    ln = ind + nm + ' = _Y(' + st[len(nm) + 3:] + ')'; applied['y'] += 1
            for nm in ('band1, gaps1', 'band2, gaps2', 'band3, gaps3'):
                if st.startswith(nm + ' = '):
                    ln = ind + nm + ' = _BG(' + st[len(nm) + 3:] + ')'; applied['bg'] += 1
            if '= verify_fixture(' in st:
                # wrap last two list args: heights and dets
                head, rest = ln.split('= verify_fixture(', 1)
                call = ast.parse('verify_fixture(' + rest).body[0].value
                a = call.args
                a[3] = ast.parse('[_L1(_v) for _v in ' + ast.unparse(a[3]) + ']').body[0].value
                a[4] = ast.parse('[_L2(_v) for _v in ' + ast.unparse(a[4]) + ']').body[0].value
                ln = head + '= ' + ast.unparse(call); applied['vf'] += 1
            if 'below_window: pin determinants' in st:
                ln = ln.replace('F(45, 8)', '_L2(F(45, 8))').replace('F(-189, 8)', '_L2(F(-189, 8))'); applied['pin'] += 1
            if 'below_window: gap ratio squared' in st:
                ln = ln.replace('F(71289, 10793861)', '_L2(F(71289, 10793861))'); applied['q22'] += 1
        out.append(ln)
    return (PRELUDE % (mode, lam)) + '\n'.join(out), applied

def run(src, mode, lam):
    code, applied = transform(src, mode, lam)
    ns = {'__name__': 'mut', '__file__': orig_path}
    buf = io.StringIO()
    try:
        with contextlib.redirect_stdout(buf):
            exec(compile(code, 'mut', 'exec'), ns)
            ns['main']()
        ok = '"status": "PASS_EXACT_FINITE_FIXTURES"' in buf.getvalue()
        return ok, None, applied
    except Exception as e:
        return False, '%s: %s' % (type(e).__name__, e), applied

modes = [('identity', '1'), ('reflect', '1'), ('scale', '5/7'), ('reflect+scale', '5/7'), ('scale', '3')]
for mode, lam in modes:
    ok, err, applied = run(orig, mode, lam)
    print('ORIGINAL', mode, lam, ok, err, dict(applied))
results = collections.defaultdict(dict)
for i, x in enumerate(surv):
    for mode, lam in modes:
        ok, err, applied = run(x['source'], mode, lam)
        results[i][mode + '@' + lam] = (ok, err)
json.dump({str(i): {'line': surv[i]['line'], 'site': surv[i]['site'], 'res': results[i]} for i in results},
          open(sys.argv[3], 'w'), indent=1)
# summary
for i, x in enumerate(surv):
    res = results[i]
    if not res['identity@1'][0]:
        print('IDENTITY FAIL (harness issue?)', x['line'], x['site'], res['identity@1'])
    k = [m for m in res if not res[m][0]]
    if k:
        print('KILLED-UNDER', x['line'], x['site'], k, [res[m][1] for m in k][:1])
