import importlib.util, sys
from fractions import Fraction as F
spec = importlib.util.spec_from_file_location('c', sys.argv[1]); c = importlib.util.module_from_spec(spec); spec.loader.exec_module(c)
M, S = c.M, c.S
fx = {
 'p1': ((F(1), F(-21, 10), F(0), F(-3), F(3, 5)), [(F(-5, 8), F(3, 4)), (F(-5, 6), F(-4, 3))], (F(1, 2), F(2)), (F(1, 10), F(2))),
 'p2': ((F(1), F(-39, 16), F(0), F(-3), F(3, 2)), [(F(-5, 8), F(3, 4)), (F(-37, 24), F(-35, 12))], (F(1, 2), F(4)), (F(1, 100), F(2))),
 'p3': ((F(1), F(-21, 10), F(12), F(9), F(18, 5)), [(F(-11, 8), F(3, 4)), (F(1, 2), F(-4, 3))], (F(1, 2), F(3, 2)), (F(1, 100), F(2))),
}
calls = [('p1', F(1), False), ('p1', F(8, 5), False), ('p2', F(1), False), ('p3', F(1), False), ('p3', F(1), True)]
for name, t, sh in calls:
    p, ex, band, gaps = fx[name]
    for y in [M, S] + ex:
        det, val = c.determinant(p, y), c.value(p, y)
        d2 = c.distance_squared(p, y, sh)
        rad = band[0]**2 <= t*t*d2 <= band[1]**2
        lo = gaps[0]**2 * d2**3 <= val**2
        hi = val**2 <= gaps[1]**2 * d2**3
        lo2 = gaps[0]**2 * d2**2 <= val**2
        print(name, t, 'shear' if sh else '', y, 'saddle' if det < 0 else 'nonsaddle', 'P<0' if val < 0 else 'P>=0', 'radius', rad, 'gapLo', lo, 'gapHi', hi, '| lo with d2^2', lo2, '| ratio q=|P|/d^3 sq', float(val**2/d2**3) if d2 else None)
