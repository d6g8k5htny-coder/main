import json, sys, importlib.util, os
from fractions import Fraction as F
r = json.load(open(sys.argv[1])); work = sys.argv[2]
P3 = (F(1), F(-21, 10), F(12), F(9), F(18, 5)); EX = [(F(-11, 8), F(3, 4)), (F(1, 2), F(-4, 3))]
H3, D3 = [F(-23, 320), F(-13, 45)], [F(-27, 4), F(-12)]; LAM = F(5, 7); P3S = tuple(LAM * v for v in P3)
def load(src, tag):
    p = os.path.join(work, tag + '.py'); open(p, 'w').write(src + '\n')
    s = importlib.util.spec_from_file_location(tag, p); m = importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
def control(m):
    m.verify_fixture('x', P3S, EX, [LAM * h for h in H3], [LAM * LAM * d for d in D3])
    k, s, a, b, q = P3S
    B = b - a * a / (12 * k); D = (q - a * b / (4 * k) + a ** 3 / (72 * k * k)) / 2
    want = (B, D, 12*k*D*D + (s-B)**2*(B+2*s), 12*k*D*D + B**3, 12*k*D*D + B**3 - 4*B*s*s)
    if tuple(m.shear_data(P3S)) != want: raise RuntimeError('shear data')
killed_other = []
for x in r[2:]:
    if x['verdict'] != 'SURVIVED': continue
    if x['line'] in (142, 148, 149, 150, 151, 214, 215) and x['site'][0] != 'require': continue
    try: control(load(x['source'], 'c%d' % x['site'][1]))
    except Exception as e: killed_other.append((x['line'], x['site'], str(e)[:60]))
print('survivors outside the 31 killed by the proposed control:', killed_other)
