"""Run the packet's own check_exact.py functions off its fixtures (Claude 54; read-only import, main() not run).

usage: python3 -B -I packet_code_offfixture.py PATH_TO_check_exact.py
Checks, at k != 1 and a != 0, that the packet's shear_data / determinant / gradient / value agree with independent
formulas from ROOTS R1 and with the R2 scaling homogeneity, i.e. that the k-placements the census could not pin
on its k = 1 fixtures are in fact right.
"""
from fractions import Fraction as F
import importlib.util, json, random, sys
spec = importlib.util.spec_from_file_location('urb_check', sys.argv[1])
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)
rng = random.Random(1026)


def rnd():
    return F(rng.randint(-30, 30), rng.randint(1, 9))


def indep(p):
    k, s, a, b, q = p
    B = b - a*a/(12*k)
    D = (q - a*b/(4*k) + a**3/(72*k*k))/2
    return (B, D, 12*k*D*D + (s - B)**2*(B + 2*s), 12*k*D*D + B**3, 12*k*D*D + B**3 - 4*B*s*s)


ok_formulas = ok_scaling = ok_det = True
NUSED = 0
for _ in range(400):
    p = (F(rng.randint(2, 40), rng.randint(1, 7)), rnd(), rnd() or F(5), rnd(), rnd())
    if p[0] == 1:
        continue
    NUSED += 1
    ok_formulas &= tuple(c.shear_data(p)) == indep(p)
    lam = F(rng.randint(2, 20), rng.randint(1, 5))
    pl = tuple(lam * v for v in p)
    y = (rnd(), rnd())
    ok_scaling &= (c.value(pl, y) == lam * c.value(p, y) and c.gradient(pl, y) == tuple(lam * g for g in c.gradient(p, y))
                   and c.shear_data(pl)[0] == lam * c.shear_data(p)[0] and c.shear_data(pl)[1] == lam * c.shear_data(p)[1])
    k, s, a, b, q = p
    x, z = y
    ok_det &= c.determinant(p, y) == (12*k*x + a*z)*(s + b*x + q*z) - (a*x + b*z)**2
# the nonzero-shear fixture scaled to k = 7/3: roots fixed, values scale, (R1.3) still holds at the extras
p3 = (F(1), F(-21, 10), F(12), F(9), F(18, 5))
extras3 = [(F(-11, 8), F(3, 4)), (F(1, 2), F(-4, 3))]
lam = F(7, 3)
p3s = tuple(lam * v for v in p3)
b, d, sigma, delta, h = c.shear_data(p3s)
r13 = all(h * z * z == 3 * p3s[0] * (b + 4 * p3s[1] * (x + p3s[2] * z / (12 * p3s[0])))**2 for x, z in extras3)
roots = all(c.gradient(p3s, y) == (0, 0) for y in [c.M, c.S] + extras3)
print("NUSED", NUSED)
print(json.dumps({'shear_data_matches_ROOTS_R1_formulas_k_ne_1': ok_formulas,
                  'scaling_homogeneity_packet_code': ok_scaling,
                  'hessian_determinant_formula': ok_det,
                  'scaled_nonzero_shear_roots_fixed': roots,
                  'scaled_nonzero_shear_R1_3': r13}, indent=1))
