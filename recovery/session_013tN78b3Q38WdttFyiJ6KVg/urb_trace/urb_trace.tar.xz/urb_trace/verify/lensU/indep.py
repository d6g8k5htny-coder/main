"""Independent re-derivation for lens U1-U8 (verifier). Standard library only, no reuse of trace/packet functions."""
from fractions import Fraction as Fr
import itertools, random, json

# ---------- tiny multivariate polynomial ring over Q: dict {exponent tuple: coeff} ----------
VARS = ('X', 'Z', 'k', 's', 'a', 'b', 'q')
N = len(VARS)


def const(c):
    return {(0,) * N: Fr(c)} if c else {}


def var(name):
    e = [0] * N
    e[VARS.index(name)] = 1
    return {tuple(e): Fr(1)}


def add(*ps):
    out = {}
    for p in ps:
        for e, c in p.items():
            out[e] = out.get(e, 0) + c
    return {e: c for e, c in out.items() if c != 0}


def neg(p):
    return {e: -c for e, c in p.items()}


def mul(*ps):
    out = const(1)
    for p in ps:
        new = {}
        for e1, c1 in out.items():
            for e2, c2 in p.items():
                e = tuple(i + j for i, j in zip(e1, e2))
                new[e] = new.get(e, 0) + c1 * c2
        out = {e: c for e, c in new.items() if c != 0}
    return out


def sc(p, c):
    return {e: c * v for e, v in p.items() if c * v != 0}


def pw(p, n):
    return mul(*([p] * n)) if n else const(1)


def diff(p, name):
    i = VARS.index(name)
    out = {}
    for e, c in p.items():
        if e[i]:
            f = list(e); f[i] -= 1
            out[tuple(f)] = out.get(tuple(f), 0) + c * e[i]
    return {e: c for e, c in out.items() if c != 0}


def ev(p, env):
    tot = Fr(0)
    for e, c in p.items():
        t = c
        for v, n in zip(VARS, e):
            if n:
                t *= Fr(env[v]) ** n
        tot += t
    return tot


X, Z, k, s, a, b, q = (var(v) for v in VARS)
quarter = const(Fr(1, 4))
# P from PROOF L78-79 / ROOTS L26-27, typed afresh
P = add(mul(const(2), k, pw(X, 3)), mul(const(Fr(-3, 2)), k, X), mul(const(Fr(-1, 2)), k),
        mul(const(Fr(1, 2)), s, pw(Z, 2)), mul(const(Fr(1, 2)), a, add(pw(X, 2), neg(quarter)), Z),
        mul(const(Fr(1, 2)), b, X, pw(Z, 2)), mul(const(Fr(1, 6)), q, pw(Z, 3)))
g1, g2 = diff(P, 'X'), diff(P, 'Z')
Pxx, Pxz, Pzz = diff(g1, 'X'), diff(g1, 'Z'), diff(g2, 'Z')
assert diff(g2, 'X') == Pxz
HESS = add(mul(Pxx, Pzz), neg(mul(Pxz, Pxz)))

FIX = {
    'two_window': (dict(k=1, s=Fr(-21, 10), a=0, b=-3, q=Fr(3, 5)), [(Fr(-5, 8), Fr(3, 4)), (Fr(-5, 6), Fr(-4, 3))]),
    'below_window': (dict(k=1, s=Fr(-39, 16), a=0, b=-3, q=Fr(3, 2)), [(Fr(-5, 8), Fr(3, 4)), (Fr(-37, 24), Fr(-35, 12))]),
    'nonzero_shear': (dict(k=1, s=Fr(-21, 10), a=12, b=9, q=Fr(18, 5)), [(Fr(-11, 8), Fr(3, 4)), (Fr(1, 2), Fr(-4, 3))]),
}
M0, S0 = (Fr(-1, 2), Fr(0)), (Fr(1, 2), Fr(0))
out = {}


# ---------- univariate helpers in one variable (lists low->high) ----------
def coeffs_in(p, name, env):
    """univariate coefficients of p in variable `name` after substituting env for the others"""
    i = VARS.index(name)
    deg = max((e[i] for e in p), default=0)
    cs = [Fr(0)] * (deg + 1)
    for e, c in p.items():
        t = c
        for j, (v, n) in enumerate(zip(VARS, e)):
            if j != i and n:
                t *= Fr(env[v]) ** n
        cs[e[i]] += t
    while len(cs) > 1 and cs[-1] == 0:
        cs.pop()
    return cs


def det(M):
    M = [row[:] for row in M]
    n = len(M); d = Fr(1)
    for c in range(n):
        piv = next((r for r in range(c, n) if M[r][c] != 0), None)
        if piv is None:
            return Fr(0)
        if piv != c:
            M[c], M[piv] = M[piv], M[c]; d = -d
        d *= M[c][c]
        for r in range(c + 1, n):
            f = M[r][c] / M[c][c]
            for j in range(c, n):
                M[r][j] -= f * M[c][j]
    return d


def sylvester2(f, g):
    """formal degree-(2,2) Sylvester determinant; f,g low->high padded to length 3"""
    f = (f + [Fr(0)] * 3)[:3]; g = (g + [Fr(0)] * 3)[:3]
    F2, F1, F0 = f[2], f[1], f[0]; G2, G1, G0 = g[2], g[1], g[0]
    return det([[F2, F1, F0, 0], [0, F2, F1, F0], [G2, G1, G0, 0], [0, G2, G1, G0]])


def interp(xs, ys):
    """Lagrange -> coefficient list low->high"""
    n = len(xs); coef = [Fr(0)] * n
    for i in range(n):
        basis = [Fr(1)]; denom = Fr(1)
        for j in range(n):
            if j != i:
                basis = [Fr(0)] + basis
                for t in range(len(basis) - 1):
                    basis[t] -= xs[j] * basis[t + 1]
                denom *= xs[i] - xs[j]
        for t in range(n):
            coef[t] += ys[i] * basis[t] / denom
    while len(coef) > 1 and coef[-1] == 0:
        coef.pop()
    return coef


def ugcd(f, g):
    def trim(p):
        p = list(p)
        while len(p) > 1 and p[-1] == 0:
            p.pop()
        return p
    f, g = trim(f), trim(g)
    while any(g):
        r = f[:]
        while len(r) >= len(g) and any(r):
            c = r[-1] / g[-1]; d = len(r) - len(g)
            for i in range(len(g)):
                r[i + d] -= c * g[i]
            r = trim(r[:-1]) if len(r) > 1 else r
            if len(r) == 1 and r[0] == 0:
                break
        f, g = g, trim(r)
    return [c / f[-1] for c in f]


def rat_roots_quadratic_or_linear(pol):
    # pol monic low->high, degree <=2
    if len(pol) == 2:
        return [-pol[0]]
    if len(pol) == 3:
        c, bb = pol[0], pol[1]
        disc = bb * bb - 4 * c
        # exact rational sqrt
        from math import isqrt
        n, d = disc.numerator, disc.denominator
        if n < 0:
            return 'complex'
        rn, rd = isqrt(n), isqrt(d)
        if rn * rn != n or rd * rd != d:
            return 'irrational'
        r = Fr(rn, rd)
        return sorted({(-bb + r) / 2, (-bb - r) / 2})
    return 'deg?'


u1 = {}
crit = {}
for name, (prm, extras) in FIX.items():
    zs = [Fr(i) for i in range(-6, 7)]
    ys = []
    for z0 in zs:
        env = dict(prm, Z=z0)
        ys.append(sylvester2(coeffs_in(g1, 'X', env), coeffs_in(g2, 'X', env)))
    R = interp(zs, ys)
    z1, z2 = extras[0][1], extras[1][1]
    # target c Z^2 (Z-z1)(Z-z2)
    tgt = [Fr(0), Fr(0), z1 * z2, -(z1 + z2), Fr(1)]
    c = R[-1]
    ratio_ok = len(R) == 5 and all(R[i] == c * tgt[i] for i in range(5)) and c != 0
    # common X at each root Z
    pts = []
    for z0 in sorted({Fr(0), z1, z2}):
        env = dict(prm, Z=z0)
        G = ugcd(coeffs_in(g1, 'X', env), coeffs_in(g2, 'X', env))
        rr = rat_roots_quadratic_or_linear(G)
        pts += [(x, z0) for x in rr]
    crit[name] = pts
    listed = sorted([M0, S0] + extras)
    u1[name] = dict(res_coeffs=[str(v) for v in R], c=str(c), factors_as_stated=ratio_ok,
                    critical_points=[(str(x), str(z)) for x, z in sorted(pts)], equals_listed=sorted(pts) == listed,
                    g2_degree_in_X=len(coeffs_in(g2, 'X', dict(prm, Z=Fr(1)))) - 1)
out['U1'] = u1


# ---------- U2: hessian at extras and pins, from symbolic second derivatives ----------
def shear(prm):
    kk, aa, bb, qq = Fr(prm['k']), Fr(prm['a']), Fr(prm['b']), Fr(prm['q'])
    B = bb - aa * aa / (12 * kk)
    D = (qq - aa * bb / (4 * kk) + aa ** 3 / (72 * kk * kk)) / 2
    return B, D


u2 = {}
for name, (prm, extras) in FIX.items():
    B, D = shear(prm); kk, ss, aa = Fr(prm['k']), Fr(prm['s']), Fr(prm['a'])
    r = {}
    r['pinM0'] = ev(HESS, dict(prm, X=M0[0], Z=M0[1])) == 3 * kk * (B - 2 * ss)
    r['pinS0'] = ev(HESS, dict(prm, X=S0[0], Z=S0[1])) == 3 * kk * (B + 2 * ss)
    for (x, z) in extras:
        u = x + aa * z / (12 * kk)
        r[str((x, z))] = [ev(HESS, dict(prm, X=x, Z=z)) == -3 * kk * (B + 4 * ss * u),
                          6 * kk * (u * u - Fr(1, 4)) + B * z * z / 2 == 0, ss + B * u + D * z == 0, z != 0]
    u2[name] = r
out['U2'] = u2

# general pin formula symbolically: HESS at X=-1/2,Z=0 equals 3k(B-2s) times... as polynomial (multiply by 1)
# 3k B = 3k b - a^2/4 (polynomial)
threekB = add(mul(const(3), k, b), mul(const(Fr(-1, 4)), a, a))


def subs_xz(p, xv, zv):
    outp = {}
    for e, c in p.items():
        t = c * Fr(xv) ** e[0] * Fr(zv) ** e[1]
        f = (0, 0) + e[2:]
        outp[f] = outp.get(f, 0) + t
    return {e: c for e, c in outp.items() if c != 0}


out['U2_pin_formulas_symbolic'] = (subs_xz(HESS, Fr(-1, 2), 0) == add(threekB, mul(const(-6), k, s)) and
                                   subs_xz(HESS, Fr(1, 2), 0) == add(threekB, mul(const(6), k, s)))

# general extra formula: build random rational cubics with rational extra critical points
rng = random.Random(777)
gen_ok = True; ntested = 0
for _ in range(300):
    kk = Fr(rng.randint(1, 30), rng.randint(1, 9)); aa = Fr(rng.randint(-20, 20), rng.randint(1, 5))
    u = Fr(rng.randint(-20, 20), rng.randint(1, 7)); z = Fr(rng.randint(1, 20), rng.randint(1, 7)) * rng.choice([-1, 1])
    ss = Fr(rng.randint(-40, -1), rng.randint(1, 7))
    if u * u == Fr(1, 4):
        continue
    B = -12 * kk * (u * u - Fr(1, 4)) / (z * z)
    D = -(ss + B * u) / z
    bb = B + aa * aa / (12 * kk)
    qq = 2 * D + aa * bb / (4 * kk) - aa ** 3 / (72 * kk * kk)
    x = u - aa * z / (12 * kk)
    env = dict(k=kk, s=ss, a=aa, b=bb, q=qq, X=x, Z=z)
    assert ev(g1, env) == 0 and ev(g2, env) == 0
    gen_ok &= ev(HESS, env) == -3 * kk * (B + 4 * ss * u)
    Hh = 12 * kk * D * D + B ** 3 - 4 * B * ss * ss
    gen_ok &= Hh * z * z == 3 * kk * (B + 4 * ss * u) ** 2
    ntested += 1
out['U2_extra_det_formula_general_random_cubics'] = (gen_ok, ntested)

# ---------- U3 symbolic: 1728 k^3 H == H_poly as polynomials, using U=12kB, V=144k^2 D ----------
U = add(mul(const(12), k, b), neg(mul(a, a)))
V = add(mul(const(72), k, k, q), mul(const(-18), k, a, b), pw(a, 3))
Hpoly = add(mul(V, V), pw(U, 3), mul(const(-576), k, k, U, s, s))
# 1728k^3 * (12k D^2 + B^3 - 4 B s^2) with D = V/(144k^2), B = U/(12k):
# = 1728*12 k^4 V^2/(144^2 k^4) + U^3 - 4*1728 k^3 U s^2/(12k) = V^2 + U^3 - 576 k^2 U s^2
lhs = add(sc(mul(V, V), Fr(1728 * 12, 144 ** 2)), pw(U, 3), sc(mul(k, k, U, s, s), Fr(-4 * 1728, 12)))
out['U3_symbolic'] = lhs == Hpoly
# check V = 144 k^2 D and U = 12 k B numerically at random points
okUV = True
for _ in range(50):
    env = dict(k=Fr(rng.randint(1, 9), rng.randint(1, 5)), s=Fr(rng.randint(-9, 9), 7), a=Fr(rng.randint(-9, 9), 5),
               b=Fr(rng.randint(-9, 9), 3), q=Fr(rng.randint(-9, 9), 2), X=0, Z=0)
    B, D = shear(env)
    okUV &= ev(U, env) == 12 * env['k'] * B and ev(V, env) == 144 * env['k'] ** 2 * D
    H = 12 * env['k'] * D * D + B ** 3 - 4 * B * env['s'] ** 2
    okUV &= ev(Hpoly, env) == 1728 * env['k'] ** 3 * H
out['U3_UV_numeric'] = okUV
qi = VARS.index('q')
q2 = {e[:qi] + (0,) + e[qi + 1:]: c for e, c in Hpoly.items() if e[qi] == 2}
out['U3_q2_coeff'] = {str(e): str(c) for e, c in q2.items()}
out['U3_q_degree'] = max(e[qi] for e in Hpoly)

# ---------- U4 symbolic substitution identity in (k,s,B,u): reuse slots: X->B, Z->u ----------
Bv, uv = var('X'), var('Z')
lhs4 = add(mul(const(12), k, pw(add(s, mul(Bv, uv)), 2)), mul(const(-12), k, Bv, Bv, add(mul(uv, uv), neg(quarter))),
           mul(const(48), k, s, s, add(mul(uv, uv), neg(quarter))))
rhs4 = mul(const(3), k, pw(add(Bv, mul(const(4), s, uv)), 2))
out['U4_symbolic'] = lhs4 == rhs4
# also check the substitution derivation itself: H Z^2 with D Z = -s - B u and B Z^2 = -12k(u^2-1/4)
# (done above in U2 general random cubics)

# ---------- U5 ----------
config = [(Fr(3, 2), 1), (Fr(-7, 4), 2), (Fr(5, 3), 2), (Fr(-1, 6), 1), (Fr(9, 5), 3)]
per_max = sum(p for p, d in config)
pair_w = sum(p / d for p, d in config for _ in range(d))
pair_u = sum(p for p, d in config for _ in range(d))
out['U5'] = dict(per_max=str(per_max), weighted=str(pair_w), unweighted=str(pair_u))
# tautology probe: identity holds for ANY list since pairs are replicated d times
taut = True
for _ in range(1000):
    cfg = [(Fr(rng.randint(-50, 50), rng.randint(1, 9)), rng.randint(1, 6)) for _ in range(rng.randint(1, 8))]
    taut &= sum(p / d for p, d in cfg for _ in range(d)) == sum(p for p, d in cfg)
out['U5_holds_for_every_random_list'] = taut


# ---------- U6: Boole exactness degrees ----------
def boole(f, lo, hi):
    h = (hi - lo) / 4
    return 2 * h / 45 * (7 * f(lo) + 32 * f(lo + h) + 12 * f(lo + 2 * h) + 32 * f(lo + 3 * h) + 7 * f(hi))


ex = {}
for n in range(0, 8):
    ex[n] = boole(lambda t: t ** n, Fr(1, 3), Fr(2)) == (Fr(2) ** (n + 1) - Fr(1, 3) ** (n + 1)) / (n + 1)
out['U6_boole_exact_by_degree'] = ex
out['U6_band_count'] = len([(i, j) for i in range(1, 6) for j in range(1, 6)])


# ---------- U7 symbolic homogeneity: P is linear in (k,s,a,b,q) jointly ----------
def coeff_degree(p):
    return {sum(e[2:]) for e in p}


out['U7_P_coeff_degrees'] = sorted(coeff_degree(P))


# ---------- U8: independent count from own critical points ----------
def Dcount(prm, pts, band, gaps, t):
    kk = Fr(prm['k'])
    vals = {y: ev(P, dict(prm, X=y[0], Z=y[1])) for y in pts}
    window = [y for y in pts if y not in (M0, S0) and -kk < vals[y] < 0]
    hs = [vals[y] for y in window]
    assert len(set(hs)) == len(hs)
    partner = max(window, key=lambda y: vals[y])
    n = 0; members = []
    for y in pts:
        if y == partner:
            continue
        if ev(HESS, dict(prm, X=y[0], Z=y[1])) >= 0:  # not a saddle
            continue
        if vals[y] >= 0:
            continue
        d2 = (y[0] - M0[0]) ** 2 + (y[1] - M0[1]) ** 2
        # c0 <= t d <= C0 with exact comparisons of squares (all positive)
        if not (band[0] ** 2 <= t * t * d2 <= band[1] ** 2):
            continue
        # gap g = -P/d^3 in [klo,khi]: g>0 since P<0; compare g^2 with endpoints^2
        g2 = vals[y] ** 2 / d2 ** 3
        if gaps[0] ** 2 <= g2 <= gaps[1] ** 2:
            n += 1; members.append((str(y[0]), str(y[1])))
    return n, members


out['U8'] = {
    'two_window_t1': Dcount(FIX['two_window'][0], crit['two_window'], (Fr(1, 2), Fr(2)), (Fr(1, 10), Fr(2)), Fr(1)),
    'two_window_t8_5': Dcount(FIX['two_window'][0], crit['two_window'], (Fr(1, 2), Fr(2)), (Fr(1, 10), Fr(2)), Fr(8, 5)),
    'below_window_t1': Dcount(FIX['below_window'][0], crit['below_window'], (Fr(1, 2), Fr(4)), (Fr(1, 100), Fr(2)), Fr(1)),
    'nonzero_shear_t1': Dcount(FIX['nonzero_shear'][0], crit['nonzero_shear'], (Fr(1, 2), Fr(3, 2)), (Fr(1, 100), Fr(2)), Fr(1)),
}
# packet-stated heights/dets
hd = {}
for name, (prm, extras) in FIX.items():
    hd[name] = [(str(ev(P, dict(prm, X=x, Z=z))), str(ev(HESS, dict(prm, X=x, Z=z)))) for x, z in extras] + \
               [('M0det', str(ev(HESS, dict(prm, X=M0[0], Z=0)))), ('S0det', str(ev(HESS, dict(prm, X=S0[0], Z=0))))]
out['heights_dets'] = hd
print(json.dumps(out, indent=1, default=str))
