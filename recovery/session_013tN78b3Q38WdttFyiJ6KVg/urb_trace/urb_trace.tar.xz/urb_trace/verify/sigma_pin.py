import json, sys, importlib.util, os
from fractions import Fraction as F
census, orig_path, work = sys.argv[1], sys.argv[2], sys.argv[3]
r = json.load(open(census))
def load(src, tag):
    p = os.path.join(work, tag + '.py'); open(p, 'w').write(src + '\n')
    s = importlib.util.spec_from_file_location(tag, p); m = importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
o = load(open(orig_path).read(), 'o_sig')
P = {'p1': (F(1), F(-21, 10), F(0), F(-3), F(3, 5)), 'p2': (F(1), F(-39, 16), F(0), F(-3), F(3, 2)), 'p3': (F(1), F(-21, 10), F(12), F(9), F(18, 5))}
for x in r[2:]:
    if x['verdict'] == 'SURVIVED' and x['line'] in (150, 151, 148, 149):
        m = load(x['source'], 's%d' % x['site'][1])
        same = [n for n, p in P.items() if m.shear_data(p) == o.shear_data(p)]
        print(x['line'], x['site'], 'pin at k=1 fixture would NOT kill at:', same)
