"""Probe whether source-binding survivors are backed by later checks (temp git repo, no packet files touched)."""
import json, sys, os, subprocess, hashlib, importlib.util, tempfile
from pathlib import Path
census, orig_path, work = sys.argv[1], sys.argv[2], Path(sys.argv[3])
r = json.load(open(census))
def load(src, tag):
    p = work / (tag + '.py'); p.write_text(src + '\n')
    spec = importlib.util.spec_from_file_location(tag, p); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
def mutant(site):
    for x in r[2:]:
        if x['site'] == site: return x
repo = Path(tempfile.mkdtemp(prefix='probe-', dir=work)).resolve() / 'repo'; repo.mkdir()
env = {k: v for k, v in os.environ.items() if not k.startswith('GIT_')}
env.update(GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL=os.devnull)
g = lambda *a: subprocess.check_output(['git', '-C', str(repo), *a], env=env).decode().strip()
g('init', '-q'); g('config', 'user.name', 'x'); g('config', 'user.email', 'x@example.invalid'); g('config', 'commit.gpgsign', 'false')
(repo / 'sub').mkdir(); (repo / 'source.md').write_bytes(b'historical source\n'); (repo / 'sub' / 'keep').write_bytes(b'k\n')
g('add', '-A'); g('commit', '-q', '-m', 'x'); commit = g('rev-parse', 'HEAD')
data = (repo / 'source.md').read_bytes()
def entry(path='source.md', **kw):
    e = {'key': 'P', 'commit': commit, 'path': path, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
         'blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}
    e.update(kw); return e
def attempt(m, e):
    m.SOURCE_COMMIT = commit
    try: return 'ACCEPT ' + repr(m.verify_source_entry(repo, e))
    except Exception as ex: return 'REJECT %s: %s' % (type(ex).__name__, ex)
orig = load(open(orig_path).read(), 'orig')
cases = [
  ('wrong manifest bytes (len+1)', entry(bytes=len(data) + 1), ['booldrop', 632, 1], 'L82 keep only type check'),
  ('wrong manifest bytes (len+1)', entry(bytes=len(data) + 1), ['require', 628, 'pass'], 'L82 require removed'),
  ('float bytes', entry(bytes=float(len(data))), ['booldrop', 632, 0], 'L82 drop type check'),
  ('wrong commit field', entry(commit='0' * 40), ['require', 591, 'pass'], 'L79 require removed'),
  ('dotdot path sub/../source.md', entry(path='sub/../source.md'), ['booldrop', 82, 2], 'L24 drop part check'),
]
for desc, e, site, label in cases:
    m = mutant(site); assert m and m['verdict'] == 'SURVIVED', site
    print(f'{desc:32s} | original: {attempt(orig, e):60s} | mutant {label} (line {m["line"]}): {attempt(load(m["source"], "m%d" % site[1]), e)}')
