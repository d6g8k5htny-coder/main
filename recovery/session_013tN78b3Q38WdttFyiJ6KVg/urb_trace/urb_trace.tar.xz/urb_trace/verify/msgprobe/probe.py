"""Run each test_sources.py test and report the RuntimeError message raised inside verify_source_entry."""
import importlib.util, sys, unittest
from pathlib import Path
pkt = Path(sys.argv[1])
spec = importlib.util.spec_from_file_location("ts", pkt / "test_sources.py")
ts = importlib.util.module_from_spec(spec); spec.loader.exec_module(ts)
c = ts.c
orig = c.verify_source_entry
msgs = {}
def wrapped(repo, entry):
    try:
        return orig(repo, entry)
    except RuntimeError as e:
        msgs[cur[0]] = str(e); raise
c.verify_source_entry = wrapped
cur = [None]
loader = unittest.TestLoader()
for name in loader.getTestCaseNames(ts.HistoricalSourceTests):
    cur[0] = name
    r = unittest.TestResult()
    ts.HistoricalSourceTests(name).run(r)
    print(f"{name}: ok={r.wasSuccessful()} msg={msgs.get(name)!r}")
