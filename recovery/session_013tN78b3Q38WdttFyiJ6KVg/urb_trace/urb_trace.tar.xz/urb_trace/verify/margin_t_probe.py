"""Boundary band input: band1=(1/2, 8/5) puts S exactly on the upper radius boundary at t=8/5."""
import json, sys, io, contextlib, ast
census, orig_path = sys.argv[1], sys.argv[2]
r = json.load(open(census))
orig = ast.unparse(ast.parse(open(orig_path).read()))
def run(src):
    src = src.replace('source_binding = verify_sources()', 'source_binding = {}')
    old = 'band1, gaps1 = ((F(1, 2), F(2)), (F(1, 10), F(2)))'
    assert old in src
    src = src.replace(old, 'band1, gaps1 = ((F(1, 2), F(8, 5)), (F(1, 10), F(2)))')
    ns = {'__name__': 'x'}; buf = io.StringIO()
    try:
        with contextlib.redirect_stdout(buf):
            exec(compile(src, 'x', 'exec'), ns); ns['main']()
        return 'PASS' if 'PASS_EXACT_FINITE_FIXTURES' in buf.getvalue() else 'NOPASS'
    except Exception as e:
        return 'FAIL %s' % e
print('original:', run(orig))
for x in r[2:]:
    if x['verdict'] == 'SURVIVED' and x['line'] in (233, 234):
        print('L%d %s:' % (x['line'], x['site']), run(x['source']))
