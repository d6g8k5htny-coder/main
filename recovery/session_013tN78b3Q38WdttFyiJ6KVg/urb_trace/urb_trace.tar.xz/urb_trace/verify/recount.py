import json, sys, collections, difflib, ast
r = json.load(open(sys.argv[1]))
src = open(sys.argv[2]).read().splitlines()
orig = ast.unparse(ast.parse('\n'.join(src))).splitlines()
print(len(r), r[0]['site'], r[1]['site'])
print({m: r[0]['result'][m]['ok'] for m in r[0]['result']}, {m: r[1]['result'][m]['ok'] for m in r[1]['result']})
c = collections.Counter(x['verdict'] for x in r[2:])
print(c, sum(c.values()))
# duplicates in source?
srcs = [x['source'] for x in r[2:]]
print('unique sources', len(set(srcs)))
# mixed per-mode
for x in r[2:]:
    ok = [x['result'][m]['ok'] for m in ('normal','optimized')]
    if ok[0] != ok[1]: print('MIXED', x['site'], x['line'])
surv = [x for x in r[2:] if x['verdict']=='SURVIVED']
bykind = collections.Counter((x['site'][0]) for x in surv)
print('survivor kinds', bykind)
byline = collections.Counter(x['line'] for x in surv)
print('survivor lines', sorted(byline.items(), key=lambda t:(t[0] is None, t[0])))
for x in surv:
    new = x['source'].splitlines()
    d = [l[1:].strip() for l in difflib.unified_diff(orig, new, lineterm='', n=0) if l.startswith('+') and not l.startswith('+++')]
    x['_diff'] = d
json.dump([{'line':x['line'],'site':x['site'],'diff':x['_diff']} for x in surv], open(sys.argv[3],'w'), indent=1)
