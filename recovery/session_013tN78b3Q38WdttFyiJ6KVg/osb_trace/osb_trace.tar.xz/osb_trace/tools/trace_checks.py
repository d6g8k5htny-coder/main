"""Trace-side exact checks (Claude 54). Not part of the packet; standard library only.

Each check is a finite rational identity for a proof step that the packet's own
controls do not exercise. Polynomials are dicts {(i, j): coefficient} in (x, z).
"""
from fractions import Fraction as F
import json


def d(poly, dx, dz):
    out = {}
    for (i, j), c in poly.items():
        if i < dx or j < dz:
            continue
        f = c
        for s in range(dx):
            f *= i - s
        for s in range(dz):
            f *= j - s
        key = (i - dx, j - dz)
        out[key] = out.get(key, 0) + f
    return out


def ev(poly, x, z=F(0)):
    return sum((c * x ** i * z ** j for (i, j), c in poly.items()), F(0))


def rows(poly, r):
    """The six U_r rows of FOLD_ISOLATION (F4) at pins (-r/2,0), (r/2,0)."""
    a, c = -r / 2, r / 2
    fx, fz = d(poly, 1, 0), d(poly, 0, 1)
    return (
        (ev(poly, a) + ev(poly, c)) / 2,
        (ev(poly, c) - ev(poly, a)) / r,
        (ev(fx, c) - ev(fx, a)) / r,
        6 / r ** 2 * (ev(fx, a) + ev(fx, c) - 2 * (ev(poly, c) - ev(poly, a)) / r),
        (ev(fz, a) + ev(fz, c)) / 2,
        (ev(fz, c) - ev(fz, a)) / r,
    )


def fold(b, k, r, q=F(0)):
    """f = b - k r^3/2 + 2k x^3 - 3k r^2 x/2 - (z - q(x^2 - r^2/4))^2/2 (check.py's ridge polynomial plus b)."""
    return {(0, 0): b - k * r ** 3 / 2 - q ** 2 * r ** 4 / 32, (3, 0): 2 * k,
            (1, 0): -3 * k * r ** 2 / 2, (0, 2): F(-1, 2), (2, 1): q,
            (0, 1): -q * r ** 2 / 4, (4, 0): -q ** 2 / 2, (2, 0): q ** 2 * r ** 2 / 4}


results = {}

# T1. (F4) target v_r = (b - k r^3/2, -k r^2, 0, 12k, 0, 0) on the exact pinned fold profile.
t1 = []
for b, k, r, q in ((F(0), F(1), F(1, 2), F(0)), (F(3, 7), F(5, 2), F(1, 3), F(0)),
                   (F(-2), F(1, 9), F(2, 5), F(3)), (F(1), F(4), F(1, 10), F(-1, 2))):
    got = rows(fold(b, k, r, q), r)
    want = (b - k * r ** 3 / 2, -k * r ** 2, F(0), 12 * k, F(0), F(0))
    t1.append(got == want)
results['T1_target_v_r'] = all(t1)

# T2. Row-4 Taylor statement: exact F_xxx(0) on cubics; quartic adds 0; quintic adds 3 c5 r^2 = O(r^2).
t2 = []
for r in (F(1, 2), F(1, 7), F(3, 11)):
    cubic = {(0, 0): F(2), (1, 0): F(-3), (2, 0): F(5, 4), (3, 0): F(7, 3)}
    t2.append(rows(cubic, r)[3] == 6 * F(7, 3))
    t2.append(rows({(4, 0): F(9)}, r)[3] == 0)
    t2.append(rows({(5, 0): F(2)}, r)[3] == 3 * 2 * r ** 2)
    # the two displayed expansions in FOLD_ISOLATION section 3, exact on cubics
    fx = d(cubic, 1, 0)
    t2.append(ev(fx, -r / 2) + ev(fx, r / 2) == 2 * ev(fx, 0) + r ** 2 / 4 * ev(d(cubic, 3, 0), 0))
    t2.append(2 * (ev(cubic, r / 2) - ev(cubic, -r / 2)) / r == 2 * ev(fx, 0) + r ** 2 / 12 * ev(d(cubic, 3, 0), 0))
results['T2_row4_taylor'] = all(t2)

# T3. The ridge polynomial in check.curved_ridge_third has the pins, gap and reduced jet the docstring implies:
#     on z = q(x^2 - r^2/4): grad f = 0 at x = +-r/2, f(-r/2) - f(r/2) = k r^3, g''' = 12k.
t3 = []
for k, r, q in ((F(1), F(1, 2), F(2)), (F(1, 2), F(1, 3), F(1)), (F(2), F(1, 2), F(0))):
    f = fold(F(0), k, r, q)
    for x in (-r / 2, r / 2):
        z = q * (x ** 2 - r ** 2 / 4)
        t3.append(ev(d(f, 1, 0), x, z) == 0 and ev(d(f, 0, 1), x, z) == 0)
    t3.append(ev(f, -r / 2) - ev(f, r / 2) == k * r ** 3)
    for x in (F(1, 4), F(-1, 5), F(3), F(0), F(-7, 3), F(5, 2)):
        z = q * (x ** 2 - r ** 2 / 4)
        t3.append(ev(d(f, 0, 1), x, z) == 0)   # the ridge z = q(x^2 - r^2/4) is where F_z = 0
        # g(x) = f(x, psi(x)) is the cubic -k r^3/2 + 2k x^3 - 3k r^2 x/2, so g''' = 12k and g'' = 12 k x
        g = {(0, 0): -k * r ** 3 / 2, (3, 0): 2 * k, (1, 0): -3 * k * r ** 2 / 2}
        t3.append(ev(f, x, z) == ev(g, x))
        # T4 rides here: Schur complement F_xx - F_xz^2/F_zz equals g'' on the ridge (FOLD_ISOLATION section 5)
        schur = ev(d(f, 2, 0), x, z) - ev(d(f, 1, 1), x, z) ** 2 / ev(d(f, 0, 2), x, z)
        t3.append(schur == ev(d(g, 2, 0), x))
results['T3_T4_ridge_pins_gap_schur'] = all(t3)

# T5. A ridge polynomial with nonzero f_xzz, f_zzz and f_zz != -1 (outside check.py's control family):
#     D^3 f[v,v,v] with v = (1, psi') equals g''' of the reduced function; mirrors (F13) in full.
#     f = -(z - h(x))^2 * s / 2 - (z - h(x))^3 / 3 + P(x), h(x) = q x^2, so the ridge is z = h(x).
def t5_case(s, q, p3, x):
    # expand f symbolically as a polynomial in (x, z)
    def mul(A, B):
        out = {}
        for (i, j), a in A.items():
            for (k2, l), bb in B.items():
                out[(i + k2, j + l)] = out.get((i + k2, j + l), 0) + a * bb
        return out
    w = {(0, 1): F(1), (2, 0): -q}           # z - q x^2
    w2 = mul(w, w)
    w3 = mul(w2, w)
    f = {}
    for key, c in w2.items():
        f[key] = f.get(key, 0) - s * c / 2
    for key, c in w3.items():
        f[key] = f.get(key, 0) - c / 3
    f[(3, 0)] = f.get((3, 0), 0) + p3
    z = q * x ** 2
    # substitute the ridge z = q x^2 into f to get g(x) as a polynomial in x, then differentiate it
    g = {}
    for (i, j), c in f.items():
        g[(i + 2 * j, 0)] = g.get((i + 2 * j, 0), 0) + c * q ** j
    g3 = ev(d(g, 3, 0), x)
    g2 = ev(d(g, 2, 0), x)
    on_ridge = ev(d(f, 0, 1), x, z) == 0
    v = -ev(d(f, 1, 1), x, z) / ev(d(f, 0, 2), x, z)
    reduced = (ev(d(f, 3, 0), x, z) + 3 * ev(d(f, 2, 1), x, z) * v
               + 3 * ev(d(f, 1, 2), x, z) * v ** 2 + ev(d(f, 0, 3), x, z) * v ** 3)
    schur = ev(d(f, 2, 0), x, z) - ev(d(f, 1, 1), x, z) ** 2 / ev(d(f, 0, 2), x, z)
    nonzero = ev(d(f, 1, 2), x, z) != 0 and ev(d(f, 0, 3), x, z) != 0 and v not in (0, 1, -1)
    return (on_ridge and reduced == g3 == 6 * p3 and schur == g2), ev(d(f, 0, 2), x, z), nonzero


t5 = [t5_case(F(3), F(2), F(5, 2), x) for x in (F(1, 3), F(-2, 3), F(5))]
results['T5_F13_full_expansion_and_schur'] = all(ok for ok, _, _ in t5)
results['T5_f_zz_values'] = [str(fz) for _, fz, _ in t5]
results['T5_exercises_v2_v3_terms'] = all(nz for _, _, nz in t5)


# T5 controls: on the same polynomial and points, the formulas that check.py's family cannot tell apart are wrong here.
def t5_wrong(s_, q, p3, x):
    def mul(A, B):
        out = {}
        for (i, j), a in A.items():
            for (k2, l), bb in B.items():
                out[(i + k2, j + l)] = out.get((i + k2, j + l), 0) + a * bb
        return out
    w = {(0, 1): F(1), (2, 0): -q}
    w2 = mul(w, w); w3 = mul(w2, w)
    f = {}
    for key, c in w2.items():
        f[key] = f.get(key, 0) - s_ * c / 2
    for key, c in w3.items():
        f[key] = f.get(key, 0) - c / 3
    f[(3, 0)] = f.get((3, 0), 0) + p3
    z = q * x ** 2
    fxx, fxz, fzz = ev(d(f, 2, 0), x, z), ev(d(f, 1, 1), x, z), ev(d(f, 0, 2), x, z)
    v_div, v_mul = -fxz / fzz, -fxz * fzz
    def red(v, c2=3):
        return (ev(d(f, 3, 0), x, z) + 3 * ev(d(f, 2, 1), x, z) * v
                + c2 * ev(d(f, 1, 2), x, z) * v ** 2 + ev(d(f, 0, 3), x, z) * v ** 3)
    return (red(v_mul) != 6 * p3 and red(v_div, 2) != 6 * p3
            and fxx - fxz ** 2 * fzz != fxx - fxz ** 2 / fzz)


results['T5_controls_wrong_formulas_fail'] = all(t5_wrong(F(3), F(2), F(5, 2), x) for x in (F(1, 3), F(-2, 3), F(5)))

# T6. Normalizations: int_0^1 y^(-1/3) dy = 3/2 (PROOF section 4); (2/3) y^(-1/3) dy has mass 1 (O5);
#     r dr = l^(-1/3) / (3 k^(2/3)) dl at l = k r^3 (PROOF section 3), via exponent bookkeeping.
results['T6_y_integral'] = F(1) / (1 - F(1, 3)) == F(3, 2)
results['T6_O5_mass'] = F(2, 3) * F(3, 2) == 1
# r = (l/k)^(1/3), dr = (1/3) k^(-1/3) l^(-2/3) dl, so r dr has prefactor 1/3, k-power -1/3-1/3, l-power 1/3-2/3.
prefactor, k_pow, l_pow = F(1, 3), F(-1, 3) + F(-1, 3), F(1, 3) + (F(1, 3) - 1)
results['T6_rdr_jacobian'] = (prefactor, k_pow, l_pow) == (F(1, 3), F(-2, 3), F(-1, 3))
# then l = tau y: l^(-1/3) dl = tau^(-1/3) y^(-1/3) tau dy, a tau-power of 2/3 as in (C2)
results['T6_tau_power'] = F(-1, 3) + 1 == F(2, 3)

# T7. Radial ledger exponent r^(d-1) r^3 r^(-(d+3)) r^2 = r for every d, not only d = 2 (PROOF section 3).
results['T7_ledger_exponent'] = all((dd - 1) + 3 - (dd + 3) + 2 == 1 for dd in range(1, 9))

# T8. Mesh dimensions in FOLD_ISOLATION section 4: (q, p) = (3,4), (4,5), (2,3) and p > q.
dims = {'F7': (2 + 1, 2 + 2), 'F8': (2 + 2, 2 + 2 + 1), 'F9': (2, 2 + 1)}
results['T8_mesh_dims'] = dims == {'F7': (3, 4), 'F8': (4, 5), 'F9': (2, 3)} and all(p > q for q, p in dims.values())

# T9. Section 5 counting identities on random-free exhaustive small laws: 2 P(K>=2) <= E[K 1{K>=2}] and
#     TV(L(K | K>0), delta_1) = P(K>=2)/P(K>0), computed independently of check.py.
t9 = []
for law in ({0: F(1, 2), 1: F(1, 3), 3: F(1, 6)}, {1: F(1)}, {0: F(9, 10), 2: F(1, 20), 7: F(1, 20)},
            {0: F(1, 4), 1: F(1, 4), 2: F(1, 4), 5: F(1, 4)}):
    p = sum(v for kk, v in law.items() if kk > 0)
    multi = sum(v for kk, v in law.items() if kk >= 2)
    b_tau = sum(v * kk for kk, v in law.items() if kk >= 2)
    cond = {kk: v / p for kk, v in law.items() if kk > 0}
    tv = (sum(abs(cond.get(kk, 0) - (1 if kk == 1 else 0)) for kk in set(cond) | {1})) / 2
    t9.append(2 * multi <= b_tau and tv == multi / p)
results['T9_O3_tv_identity'] = all(t9)


# T10. PROOF section 3 L74: the full-pin determinant 12 r^(-5). The U_r rows of FOLD (F4) are a linear map of the six
#      pin observations (f(a), f(c), f_x(a), f_x(c), f_z(a), f_z(c)); its determinant has absolute value 12 r^(-5).
def det(m):
    m = [row[:] for row in m]
    n, sign, out = len(m), 1, F(1)
    for c in range(n):
        p = next(i for i in range(c, n) if m[i][c] != 0)
        if p != c:
            m[c], m[p] = m[p], m[c]
            sign = -sign
        out *= m[c][c]
        for i in range(c + 1, n):
            f = m[i][c] / m[c][c]
            m[i] = [x - f * y for x, y in zip(m[i], m[c])]
    return sign * out


def u_matrix(r):
    h = F(1, 2)
    return [[h, h, 0, 0, 0, 0],
            [-1 / r, 1 / r, 0, 0, 0, 0],
            [0, 0, -1 / r, 1 / r, 0, 0],
            [12 / r ** 3, -12 / r ** 3, 6 / r ** 2, 6 / r ** 2, 0, 0],
            [0, 0, 0, 0, h, h],
            [0, 0, 0, 0, -1 / r, 1 / r]]


results['T10_pin_determinant'] = all(abs(det(u_matrix(r))) == 12 / r ** 5 for r in (F(1, 3), F(1, 2), F(2, 7), F(5)))

print(json.dumps(results, indent=1))
