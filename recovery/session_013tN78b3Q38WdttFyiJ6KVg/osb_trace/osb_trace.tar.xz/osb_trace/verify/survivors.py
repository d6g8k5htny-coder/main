import json,difflib,ast,sys
r=json.load(open('../census.json'))
P='../wt/frontiers/ordinary_short_bar_occurrence_20261001/'
orig={f:ast.unparse(ast.parse(open(P+f).read())) for f in ('check.py','verify_sources.py')}
want=sys.argv[1] if len(sys.argv)>1 else 'SURVIVED'
for i,x in enumerate(r[3:],3):
  if x['verdict']!=want: continue
  o=orig[x['file']]; m=x['source']
  sm=difflib.SequenceMatcher(None,o,m,autojunk=False)
  ops=[op for op in sm.get_opcodes() if op[0]!='equal']
  a0=ops[0][1]; a1=ops[-1][2]; b0=ops[0][3]; b1=ops[-1][4]
  ctx=25
  print(i,x['file'],'L%s'%x['line'],x['site'][0],x['site'][2],'::',repr(o[max(0,a0-ctx):a1+ctx]),'=>',repr(m[max(0,b0-ctx):b1+ctx]))
