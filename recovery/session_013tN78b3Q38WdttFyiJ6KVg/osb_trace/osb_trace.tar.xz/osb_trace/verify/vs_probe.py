import json, types, hashlib, tempfile, os, sys, importlib.util, shutil
from pathlib import Path
here=Path(__file__).resolve().parent
r=json.load(open(here.parent/'census.json'))
P=here.parent/'wt/frontiers/ordinary_short_bar_occurrence_20261001'
def load(src,name,fname):
    m=types.ModuleType(name); m.__file__=fname; exec(compile(src,fname,'exec'),m.__dict__); return m
orig_src=(P/'verify_sources.py').read_text()
mut={x['line']:[] for x in r[3:] if x['file']=='verify_sources.py'}
for i,x in enumerate(r[3:],3):
    if x['file']=='verify_sources.py' and x['verdict']=='SURVIVED':
        mut.setdefault(x['line'],[]).append((i,x['site'],x['source']))
def entry(path,data,**kw):
    e={"local_path":path,"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),
       "blob":hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()}
    e.update(kw); return e
def run(m,root,e):
    try: m.verify_entry(root,e); return 'ACCEPT'
    except Exception as ex: return 'reject:%s:%s'%(type(ex).__name__,ex)
with tempfile.TemporaryDirectory(dir=here) as d:
    root=Path(d)
    (root/'sub').mkdir()
    (root/'f.txt').write_bytes(b'hello')
    (root/'one').write_bytes(b'x')
    (root/'a\\\\b').write_bytes(b'bs')   # name contains two backslashes
    (root/'a\\b').write_bytes(b'bs1')    # one backslash
    cases=[('dotdot-inside', entry('sub/../f.txt',b'hello')),
           ('dotdot-escape', entry('../'+root.name+'/f.txt',b'hello')),
           ('bool-bytes-1byte', entry('one',b'x',bytes=True)),
           ('float-bytes', entry('f.txt',b'hello',bytes=5.0)),
           ('double-backslash', entry('a\\\\b',b'bs')),
           ('single-backslash', entry('a\\b',b'bs1')),
           ('directory', entry('sub',b'')),
           ('missing', entry('nope',b'')),
           ('empty', entry('',b'')),
           ('nonstr', entry(5,b'')),
           ]
    o=load(orig_src,'o',str(P/'verify_sources.py'))
    print('ORIGINAL')
    for name,e in cases: print('  ',name,run(o,root,e))
    for line in sorted(mut):
        for i,site,src in mut[line]:
            if line in (52,53,59): continue
            m=load(src,'m%d'%i,str(P/'verify_sources.py'))
            diffs=[(name,run(o,root,e),run(m,root,e)) for name,e in cases]
            diffs=[x for x in diffs if x[1]!=x[2]]
            print(i,'L%d'%line,site,[ (n,b) for n,a,b in diffs])
