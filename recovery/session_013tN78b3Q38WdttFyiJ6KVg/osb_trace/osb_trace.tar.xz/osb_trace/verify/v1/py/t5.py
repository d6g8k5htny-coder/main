from fractions import Fraction as F
import sys, importlib.util
spec = importlib.util.spec_from_file_location("tc", sys.argv[1])
src = open(sys.argv[1]).read().split("results = {}")[0]
ns = {}; exec(src, ns)
d, ev = ns['d'], ns['ev']
def mul(A, B):
    out = {}
    for (i, j), a in A.items():
        for (k2, l), bb in B.items():
            out[(i + k2, j + l)] = out.get((i + k2, j + l), 0) + a * bb
    return out
s, q, p3 = F(3), F(2), F(5, 2)
w = {(0, 1): F(1), (2, 0): -q}; w2 = mul(w, w); w3 = mul(w2, w)
f = {}
for key, c in w2.items(): f[key] = f.get(key, 0) - s * c / 2
for key, c in w3.items(): f[key] = f.get(key, 0) - c / 3
f[(3, 0)] = f.get((3, 0), 0) + p3
for x in (F(1, 4), F(-2, 3), F(5)):
    z = q * x * x
    v = -ev(d(f, 1, 1), x, z) / ev(d(f, 0, 2), x, z)
    t = [ev(d(f, 3, 0), x, z), 3 * ev(d(f, 2, 1), x, z) * v, 3 * ev(d(f, 1, 2), x, z) * v ** 2, ev(d(f, 0, 3), x, z) * v ** 3]
    print(x, "fz", ev(d(f,0,1),x,z), "fzz", ev(d(f,0,2),x,z), "fxzz", ev(d(f,1,2),x,z), "fzzz", ev(d(f,0,3),x,z), "v", v, "terms", t, "sum", sum(t))
