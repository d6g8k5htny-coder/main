import sys, importlib.util
from fractions import Fraction as F
spec = importlib.util.spec_from_file_location("check", sys.argv[1])
check = importlib.util.module_from_spec(spec); spec.loader.exec_module(check)
pts = 0; none = 0; e0 = 0; epos = 0; strict = 0
for i in range(7):
    for j in range(7 - i):
        pts += 1
        s = check.mark_statistics([(F(i, 6), ()), (F(j, 6), ("a",)), (F(6 - i - j, 6), ("b", ("c", 1), "b"))])
        if s["mean"] == 0:
            none += 1; continue
        if s["excess"] == 0: e0 += 1
        else: epos += 1
        if s["tv"] < s["excess"]/s["mean"]: strict += 1
print("grid points", pts, "mean0(None branch)", none, "e=0", e0, "e>0", epos, "tv strictly < e/m", strict)
# pin determinant of U_r rows w.r.t. (f(a),f(c),fx(a),fx(c),fz(a),fz(c))
r = F(1, 3)
M = [[F(1,2),F(1,2),0,0,0,0],[-1/r,1/r,0,0,0,0],[0,0,-1/r,1/r,0,0],
     [6/r**2*(2/r),6/r**2*(-2/r),6/r**2,6/r**2,0,0],[0,0,0,0,F(1,2),F(1,2)],[0,0,0,0,-1/r,1/r]]
def det(A):
    A = [row[:] for row in A]; n = len(A); d = F(1)
    for c in range(n):
        p = next(k for k in range(c, n) if A[k][c] != 0)
        if p != c: A[c], A[p] = A[p], A[c]; d = -d
        d *= A[c][c]
        for k in range(c+1, n):
            f = A[k][c] / A[c][c]
            A[k] = [A[k][t] - f*A[c][t] for t in range(n)]
    return d
print("det", det(M), "12 r^-5 =", 12 / r**5)
