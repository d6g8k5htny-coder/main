
import importlib.util,sys
spec=importlib.util.spec_from_file_location("vs",sys.argv[1]); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
try: print("RESULT", m.verify_sources())
except Exception as e: print("reject", type(e).__name__, e)
