"""Fresh re-derivation of T1-T9 (does not import trace_checks.py)."""
from fractions import Fraction as Q
from itertools import product

# --- tiny bivariate polynomial algebra -------------------------------------
class P:
    def __init__(s, c=None): s.c = {k: v for k, v in (c or {}).items() if v}
    @staticmethod
    def const(a): return P({(0, 0): Q(a)})
    def __add__(s, o):
        o = o if isinstance(o, P) else P.const(o); c = dict(s.c)
        for k, v in o.c.items(): c[k] = c.get(k, 0) + v
        return P(c)
    __radd__ = __add__
    def __neg__(s): return P({k: -v for k, v in s.c.items()})
    def __sub__(s, o): return s + (-(o if isinstance(o, P) else P.const(o)))
    def __rsub__(s, o): return P.const(o) - s
    def __mul__(s, o):
        o = o if isinstance(o, P) else P.const(o); c = {}
        for (a, b), u in s.c.items():
            for (e, f), w in o.c.items(): c[(a + e, b + f)] = c.get((a + e, b + f), 0) + u * w
        return P(c)
    __rmul__ = __mul__
    def __pow__(s, n):
        out = P.const(1)
        for _ in range(n): out = out * s
        return out
    def dx(s): return P({(a - 1, b): v * a for (a, b), v in s.c.items() if a})
    def dz(s): return P({(a, b - 1): v * b for (a, b), v in s.c.items() if b})
    def D(s, i, j):
        out = s
        for _ in range(i): out = out.dx()
        for _ in range(j): out = out.dz()
        return out
    def __call__(s, x, z=Q(0)): return sum((v * Q(x) ** a * Q(z) ** b for (a, b), v in s.c.items()), Q(0))
    def subs_z(s, g):  # f(x, g(x)) as polynomial in x
        out = P()
        for (a, b), v in s.c.items(): out = out + v * X ** a * g ** b
        return out

X, Z = P({(1, 0): Q(1)}), P({(0, 1): Q(1)})

def U(f, r):
    a, c = -r / 2, r / 2
    fx, fz = f.dx(), f.dz()
    return (
        (f(a) + f(c)) / 2,
        (f(c) - f(a)) / r,
        (fx(c) - fx(a)) / r,
        Q(6) / r ** 2 * (fx(a) + fx(c) - 2 * (f(c) - f(a)) / r),
        (fz(a) + fz(c)) / 2,
        (fz(c) - fz(a)) / r,
    )

print('== T1')
ok = True
for b, k, r, q in [(Q(0), Q(1), Q(1, 2), Q(0)), (Q(3, 7), Q(5, 2), Q(1, 3), Q(0)), (Q(-2), Q(1, 9), Q(2, 5), Q(3)),
                   (Q(1), Q(4), Q(1, 10), Q(-1, 2)), (Q(5), Q(7, 3), Q(3, 4), Q(-9, 5))]:
    psi = q * (X ** 2 - r ** 2 / 4)
    f = b - k * r ** 3 / 2 + 2 * k * X ** 3 - Q(3, 2) * k * r ** 2 * X - (Z - psi) ** 2 * Q(1, 2)
    want = (b - k * r ** 3 / 2, -k * r ** 2, Q(0), 12 * k, Q(0), Q(0))
    pins = (f(-r / 2), f(r / 2), f.dx()(-r / 2), f.dx()(r / 2), f.dz()(-r / 2), f.dz()(r / 2))
    ok &= U(f, r) == want and pins == (b, b - k * r ** 3, 0, 0, 0, 0)
print('T1 rows == v_r and pins hold:', ok)

print('== T2: row 4 on monomials x^n, symbolic check 12(n-1) r^(n-3) / 2^(n-1) for odd n, 0 for even n')
for n in range(0, 8):
    for r in (Q(1, 2), Q(1, 7), Q(3, 11)):
        got = U(X ** n, r)[3]
        pred = Q(12 * (n - 1)) * r ** (n - 3) / 2 ** (n - 1) if n % 2 else Q(0)
        assert got == pred, (n, r, got, pred)
    print(' n=%d row4 = %s' % (n, U(X ** n, Q(1, 2))[3]), '(r=1/2)')
r = Q(1, 3)
print(' quintic 2x^5 at r=1/3:', U(2 * X ** 5, r)[3], 'vs 3*c5*r^2 =', 3 * 2 * r ** 2)
cub = 2 - 3 * X + Q(5, 4) * X ** 2 + Q(7, 3) * X ** 3
fx = cub.dx(); f3 = cub.D(3, 0)(0)
print(' expansions exact on cubic:', fx(-r / 2) + fx(r / 2) == 2 * fx(0) + r ** 2 / 4 * f3,
      2 * (cub(r / 2) - cub(-r / 2)) / r == 2 * fx(0) + r ** 2 / 12 * f3)
# does a z-dependent cubic term matter? x^2 z, x z^2, z^3 at z=0 rows
print(' row4 of x^2 z, x z^2, z^3, x^3 z:', [U(m, r)[3] for m in (X**2*Z, X*Z**2, Z**3, X**3*Z)])

print('== T3/T4 (check.py family) and Schur alternatives')
for k, r, q in [(Q(1), Q(1, 2), Q(2)), (Q(1, 2), Q(1, 3), Q(1)), (Q(2), Q(1, 2), Q(0))]:
    psi = q * (X ** 2 - r ** 2 / 4)
    f = -k * r ** 3 / 2 + 2 * k * X ** 3 - Q(3, 2) * k * r ** 2 * X - (Z - psi) ** 2 * Q(1, 2)
    g = f.subs_z(psi)
    gw = -k * r ** 3 / 2 + 2 * k * X ** 3 - Q(3, 2) * k * r ** 2 * X
    ridge_fz = f.dz().subs_z(psi)
    print(' k,r,q=', k, r, q, '| g == cubic as polynomial:', (g - gw).c == {}, '| f_z on ridge identically 0:', ridge_fz.c == {},
          '| deg of f(x,psi)-g before cancellation <=4')
    for x in (Q(1, 4), Q(-1, 5), Q(3)):
        z = psi(x)
        fxx, fxz, fzz = f.D(2, 0)(x, z), f.D(1, 1)(x, z), f.D(0, 2)(x, z)
        gpp = g.D(2, 0)(x)
        right = fxx - fxz ** 2 / fzz
        wrong_mult = fxx - fxz ** 2 * fzz
        wrong_plus = fxx + fxz ** 2
        print('   x=%s fzz=%s schur==g\'\': %s  [fxx - fxz^2*fzz]==g\'\': %s  [fxx + fxz^2]==g\'\': %s' %
              (x, fzz, right == gpp, wrong_mult == gpp, wrong_plus == gpp))

print('== T5')
s, q, p3 = Q(3), Q(2), Q(5, 2)
w = Z - q * X ** 2
f = -s * w ** 2 * Q(1, 2) - w ** 3 * Q(1, 3) + p3 * X ** 3
psi = q * X ** 2
g = f.subs_z(psi)
print(' g(x) = f(x, 2x^2):', g.c, '| g\'\'\' =', g.D(3, 0)(0), '| f_z on ridge identically 0:', f.dz().subs_z(psi).c == {})
for x in (Q(1, 4), Q(-2, 3), Q(5)):
    z = psi(x)
    d = lambda i, j: f.D(i, j)(x, z)
    v = -d(1, 1) / d(0, 2)
    terms = (d(3, 0), 3 * d(2, 1) * v, 3 * d(1, 2) * v ** 2, d(0, 3) * v ** 3)
    schur = d(2, 0) - d(1, 1) ** 2 / d(0, 2)
    print('  x=%s: v=%s psi\'=%s f_xzz=%s f_zzz=%s f_zz=%s terms=%s sum=%s | schur=%s g\'\'=%s | wrong schur (mult)=%s' %
          (x, v, psi.D(1, 0)(x), d(1, 2), d(0, 3), d(0, 2), [str(t) for t in terms], sum(terms), schur, g.D(2, 0)(x),
           d(2, 0) - d(1, 1) ** 2 * d(0, 2)))

print('== T6')
# antiderivative of y^(-1/3) is (3/2) y^(2/3); integral 0..1 = 3/2
print(' int y^-1/3 = 3/2; (2/3)(3/2) =', Q(2, 3) * Q(3, 2))
# r = k^-1/3 l^1/3 ; dr/dl = (1/3) k^-1/3 l^-2/3 ; r dr/dl = (1/3) k^-2/3 l^-1/3 -> matches PROOF L85
print(' r dr = (1/3) k^(-2/3) l^(-1/3) dl ; tau power after l = tau y:', Q(-1, 3) + 1)

print('== T9')
def stats(law):
    p = sum(v for kk, v in law.items() if kk > 0); m2 = sum(v for kk, v in law.items() if kk >= 2)
    B = sum(kk * v for kk, v in law.items() if kk >= 2)
    cond = {kk: v / p for kk, v in law.items() if kk > 0}
    # TV as sup over events: max over subsets of support U {1}
    support = sorted(set(cond) | {1})
    best = Q(0)
    for mask in product((0, 1), repeat=len(support)):
        A = [kk for kk, bit in zip(support, mask) if bit]
        best = max(best, abs(sum(cond.get(kk, 0) for kk in A) - (1 if 1 in A else 0)))
    return 2 * m2 <= B, best == m2 / p, best, m2 / p
for law in ({0: Q(1, 2), 1: Q(1, 3), 3: Q(1, 6)}, {1: Q(1)}, {0: Q(9, 10), 2: Q(1, 20), 7: Q(1, 20)},
            {0: Q(1, 4), 1: Q(1, 4), 2: Q(1, 4), 5: Q(1, 4)}):
    print(' ', stats(law))
