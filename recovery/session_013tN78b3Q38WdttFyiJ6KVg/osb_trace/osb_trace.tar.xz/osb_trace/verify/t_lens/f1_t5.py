"""Do the census's L179/L180 survivors get killed by a T5-like polynomial? Independent of trace_checks.py."""
import ast, json, sys
from fractions import Fraction as Fr

census = json.load(open(sys.argv[1]))
surv = [r for r in census if r.get('file') == 'check.py' and r.get('verdict') == 'SURVIVED' and r.get('line') in (179, 180)]
print('survivors at L179/L180:', len(surv))

# T5 polynomial: f = -3 w^2/2 - w^3/3 + (5/2) x^3, w = z - 2 x^2, expanded by hand.
# w^2 = z^2 - 4 x^2 z + 4 x^4 ; w^3 = z^3 - 6 x^2 z^2 + 12 x^4 z - 8 x^6
coef = {}
def add(k, c): coef[k] = coef.get(k, 0) + c
for k, c in {(0,2):1, (2,1):-4, (4,0):4}.items(): add(k, Fr(-3,2)*c)
for k, c in {(0,3):1, (2,2):-6, (4,1):12, (6,0):-8}.items(): add(k, Fr(-1,3)*c)
add((3,0), Fr(5,2))

def make_derivative(x, z):
    def derivative(dx, dz):
        ans = Fr(0)
        for (i, j), c in coef.items():
            if i < dx or j < dz: continue
            f = 1
            for s in range(dx): f *= i - s
            for s in range(dz): f *= j - s
            ans += c * f * x ** (i - dx) * z ** (j - dz)
        return ans
    return derivative

def grab(src):
    t = ast.parse(src)
    for n in ast.walk(t):
        if isinstance(n, ast.FunctionDef) and n.name == 'curved_ridge_third':
            body = [s for s in n.body if isinstance(s, ast.Assign) and isinstance(s.targets[0], ast.Name) and s.targets[0].id in ('raw', 'v', 'reduced')]
            return [ast.unparse(s) for s in body]

orig = open(sys.argv[2]).read()
print('original:', grab(orig))
for r in surv:
    stmts = grab(r['source'])
    out = []
    for x in (Fr(1,4), Fr(-2,3), Fr(5)):
        env = {'derivative': make_derivative(x, 2 * x * x)}
        try:
            for s in stmts: exec(s, env)
            out.append(env['reduced'] == 15)
        except ZeroDivisionError:
            out.append('ZDE')
    diff = [s for s in stmts if s not in grab(orig)]
    print(r['line'], r['site'], 'T5-agrees:', out, '|', diff)
