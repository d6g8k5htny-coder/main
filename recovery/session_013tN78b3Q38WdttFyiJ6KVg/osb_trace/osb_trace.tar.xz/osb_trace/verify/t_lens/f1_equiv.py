"""Are the 16 L179/L180 survivors equivalent to the original curved_ridge_third on random valid inputs?"""
import json, sys, random
from fractions import Fraction as Fr
census = json.load(open(sys.argv[1]))
orig_ns = {}; exec(compile(open(sys.argv[2]).read(), 'check_orig', 'exec'), orig_ns)
rng = random.Random(7)
inputs = []
for _ in range(400):
    k = Fr(rng.randint(1, 40), rng.randint(1, 9)); r = Fr(rng.randint(1, 40), rng.randint(1, 9))
    q = Fr(rng.randint(-30, 30), rng.randint(1, 9)); x = Fr(rng.randint(-30, 30), rng.randint(1, 9))
    inputs.append((k, r, q, x))
for rec in census:
    if rec.get('file') == 'check.py' and rec.get('verdict') == 'SURVIVED' and rec.get('line') in (179, 180):
        ns = {}; exec(compile(rec['source'], 'mut', 'exec'), ns)
        same = 0; errs = 0
        for a in inputs:
            try:
                same += ns['curved_ridge_third'](*a) == orig_ns['curved_ridge_third'](*a)
            except ZeroDivisionError:
                errs += 1
        print(rec['line'], rec['site'], 'agree on', same, 'of', len(inputs), 'ZDE', errs)
