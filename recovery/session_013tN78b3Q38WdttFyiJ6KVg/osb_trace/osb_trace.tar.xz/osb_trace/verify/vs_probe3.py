import json, tempfile, os, sys, subprocess, shutil
from pathlib import Path
here=Path(__file__).resolve().parent
r=json.load(open(here.parent/'census.json'))
MATH=here.parent/'wt'
PK='frontiers/ordinary_short_bar_occurrence_20261001'
work=Path(tempfile.mkdtemp(dir=here,prefix='p3-'))
tree=work/'tree'; tgt=tree/PK; tgt.mkdir(parents=True)
for n in ('check.py','test_check.py','verify_sources.py','SOURCES.json'):
    shutil.copyfile(MATH/PK/n, tgt/n)
for e in json.loads((MATH/PK/'SOURCES.json').read_text())['sources']:
    d=tree/e['local_path']; d.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(MATH/e['local_path'],d)
link=work/'elsewhere'/'a'/'b'; link.mkdir(parents=True)
(link/'verify_sources.py').symlink_to(tgt/'verify_sources.py')
prog=work/'loadvia.py'
prog.write_text('''
import importlib.util,sys
spec=importlib.util.spec_from_file_location("vs",sys.argv[1]); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
try: print("RESULT", m.verify_sources())
except Exception as e: print("reject", type(e).__name__, e)
''')
orig=(MATH/PK/'verify_sources.py').read_text()
def symlink_case(src):
    (tgt/'verify_sources.py').write_text(src)
    p=subprocess.run([sys.executable,'-B','-I',str(prog),str(link/'verify_sources.py')],capture_output=True,text=True,timeout=30)
    return (p.stdout+p.stderr).strip()
print('symlinked checker, original:', symlink_case(orig))
print('symlinked checker, mutant 493 (L43 require->pass):', symlink_case(r[493]['source']+'\n'))
# L59 mutants: run the test suite and look at stdout
for i in (510,511):
    (tgt/'verify_sources.py').write_text(r[i]['source']+'\n')
    p=subprocess.run([sys.executable,'-B','-S',str(tgt/'test_check.py')],capture_output=True,text=True,timeout=60,cwd=tree)
    print(i, r[i]['site'], 'rc',p.returncode, 'stdout:',p.stdout.strip()[:200], '| tail:', p.stderr.strip().splitlines()[-1])
(tgt/'verify_sources.py').write_text(orig)
p=subprocess.run([sys.executable,'-B','-S',str(tgt/'test_check.py')],capture_output=True,text=True,timeout=60,cwd=tree)
print('orig stdout:',repr(p.stdout[:200]),'tail',p.stderr.strip().splitlines()[-1])
