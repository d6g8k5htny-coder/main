
import sys,types,json
src=open(sys.argv[1]).read(); m=types.ModuleType("m"); exec(compile(src,"vs","exec"),m.__dict__)
try:
    m.verify_entry(sys.argv[2], json.loads(sys.argv[3])); print("ACCEPT")
except Exception as e: print("reject", type(e).__name__, e)
