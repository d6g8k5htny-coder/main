import json, sys, ast, difflib
recs = json.load(open(sys.argv[1]))
root = sys.argv[2]
orig = {f: ast.unparse(ast.parse(open(root + '/' + f).read())).splitlines() for f in ('check.py', 'verify_sources.py')}
want = sys.argv[3]
for r in recs[1:]:
    if r['site'] == 'baseline-unparsed' or r['verdict'] == 'KILLED' or r['file'] != want:
        continue
    new = r['source'].splitlines()
    for i, (a, b) in enumerate(zip(orig[want], new)):
        if a != b:
            sm = difflib.SequenceMatcher(None, a, b)
            ops = [(t, a[max(0,i1-25):i2+10], b[max(0,j1-25):j2+10]) for t, i1, i2, j1, j2 in sm.get_opcodes() if t != 'equal']
            print(r['line'], r['site'], ops[:2])
            break
    else:
        print(r['line'], r['site'], 'LEN', len(orig[want]), len(new))
