import json, sys, ast, difflib
recs = json.load(open(sys.argv[1]))
root = sys.argv[2]
orig = {f: ast.unparse(ast.parse(open(root + '/' + f).read())).splitlines() for f in ('check.py', 'verify_sources.py')}
want = sys.argv[3] if len(sys.argv) > 3 else None
for r in recs[1:]:
    if r['site'] == 'baseline-unparsed' or r['verdict'] == 'KILLED':
        continue
    if want and r['file'] != want: continue
    new = r['source'].splitlines()
    d = [l for l in difflib.unified_diff(orig[r['file']], new, lineterm='', n=0) if l[:1] in '+-' and not l.startswith(('+++', '---'))]
    print(r['file'], r['line'], r['site'], ' || '.join(x.strip() for x in d))
