import json, sys, collections
recs = json.load(open(sys.argv[1]))
print(recs[0]['site'], {m: recs[0]['result'][m]['ok'] for m in recs[0]['result']})
c = collections.Counter()
lines = collections.defaultdict(collections.Counter)
for r in recs[1:]:
    if r['site'] == 'baseline-unparsed':
        print('unparsed', r['file'], {m: r['result'][m]['ok'] for m in r['result']}); continue
    c[(r['file'], r['verdict'])] += 1
    if r['verdict'] != 'KILLED':
        lines[r['file']][r['line']] += 1
print(c)
for f, cnt in lines.items():
    print(f, sorted(cnt.items(), key=lambda t: (t[0] is None, t[0])))
