import json, random, sys, types
from fractions import Fraction as F
r=json.load(open('../census.json'))
P='../wt/frontiers/ordinary_short_bar_occurrence_20261001/'
def load(src,name):
    m=types.ModuleType(name); exec(compile(src,name,'exec'),m.__dict__); return m
orig=load(open(P+'check.py').read(),'orig')
rng=random.Random(1)
def rf(allow_zero=True, pos=False):
    while True:
        n=rng.randint(-12,12); d=rng.randint(1,9)
        v=F(n,d)
        if pos and v<=0: continue
        if not allow_zero and v==0: continue
        return v
def call(fn,*a):
    try: return ('ok',fn(*a))
    except Exception as e: return ('exc',type(e).__name__)
def gen_cases():
    cases=[]
    # curved_ridge_third incl x=0
    for _ in range(300):
        cases.append(('curved_ridge_third',(rf(pos=True),rf(pos=True),rf(),rf())))
    cases.append(('curved_ridge_third',(1,F(1,2),2,0)))
    for _ in range(200):
        cases.append(('fold_jet',(rf(),rf(),rf())))
    for _ in range(200):
        cases.append(('radial_density_at_r',(rf(),rng.randint(-3,5),rf(),rf(),rng.randint(-1,4))))
        cases.append(('radial_pushforward',(rf(),rng.randint(-3,5),rng.randint(-1,4))))
        cases.append(('radial_cumulative',(rf(),rng.randint(-3,5),rng.randint(-1,4))))
    labels=['a','b','c',('c',1)]
    for _ in range(600):
        n=rng.randint(1,4)
        ws=[F(rng.randint(-1,4)) for _ in range(n)]
        s=sum(ws)
        if s==0: ws[0]+=1; s=sum(ws)
        ws=[w/s for w in ws]
        fields=[(w,tuple(rng.choice(labels) for _ in range(rng.randint(0,3)))) for w in ws]
        cases.append(('mark_statistics',(fields,)))
    cases.append(('mark_statistics',([(-1,("a",)),(2,("a",))],)))
    cases.append(('mark_statistics',([(-1,()),(2,())],)))
    cases.append(('mark_statistics',([(0,('b',)),(F(1,2),('a',)),(F(1,2),('b',))],)))
    for _ in range(200):
        law={}
        for k in rng.sample(range(-1,6),rng.randint(1,4)): law[k]=F(rng.randint(-1,4))
        s=sum(law.values()) or 1
        law={k:v/s for k,v in law.items()}
        cases.append(('count_statistics',(law,)))
    return cases
cases=gen_cases()
base=[call(getattr(orig,fn),*a) for fn,a in cases]
def order(res):
    if res[0]=='ok' and isinstance(res[1],dict):
        return tuple((k, tuple(v) if isinstance(v,dict) else None) for k,v in res[1].items())
    return None
for i,x in enumerate(r[3:],3):
    if x['file']!='check.py' or x['verdict']!='SURVIVED': continue
    m=load(x['source'],'m%d'%i)
    diffs=[]; odiffs=[]
    for (fn,a),b in zip(cases,base):
        got=call(getattr(m,fn),*a)
        if got!=b: diffs.append((fn,a,b,got))
        elif order(got)!=order(b): odiffs.append((fn,a))
    if diffs or odiffs:
        print(i,'L%s'%x['line'],x['site'],'valdiffs',len(diffs),'orderdiffs',len(odiffs))
        if diffs: print('   e.g.',str(diffs[0])[:300])
        if odiffs: print('   order e.g.',str(odiffs[0])[:300])
print('done')
