import json, types, hashlib, tempfile, os, sys, subprocess
from pathlib import Path
here=Path(__file__).resolve().parent
r=json.load(open(here.parent/'census.json'))
P=here.parent/'wt/frontiers/ordinary_short_bar_occurrence_20261001'
srcs={i:x['source'] for i,x in enumerate(r) if i>=3}
work=Path(tempfile.mkdtemp(dir=here,prefix='p2-'))
(work/'outside.txt').write_bytes(b'out')
root=work/'root'; root.mkdir()
(root/'f.txt').write_bytes(b'hello')
os.mkfifo(root/'pipe')
def entry(path,data):
    return {"local_path":path,"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),
       "blob":hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()}
prog='''
import sys,types,json
src=open(sys.argv[1]).read(); m=types.ModuleType("m"); exec(compile(src,"vs","exec"),m.__dict__)
try:
    m.verify_entry(sys.argv[2], json.loads(sys.argv[3])); print("ACCEPT")
except Exception as e: print("reject", type(e).__name__, e)
'''
(work/'prog.py').write_text(prog)
def run(src,e):
    f=work/'m.py'; f.write_text(src)
    try:
        p=subprocess.run([sys.executable,'-B','-I',str(work/'prog.py'),str(f),str(root),json.dumps(e)],capture_output=True,text=True,timeout=5)
        return (p.stdout+p.stderr).strip()[-120:]
    except subprocess.TimeoutExpired: return 'TIMEOUT (blocked >5s)'
orig=(P/'verify_sources.py').read_text()
for label,e in (('real-escape ../outside.txt',entry('../outside.txt',b'out')),('fifo',entry('pipe',b''))):
    print(label,'orig:',run(orig,e))
    for i in (465,475,476,477,478):
        print('   ',i,r[i]['line'],r[i]['site'],run(srcs[i],e))
