import json, sys, collections
d = json.load(open(sys.argv[1]))
fns = [('require',10,12),('contained_file',15,27),('verify_entry',30,38),('verify_sources',41,56),
       ('rational',59,61),('count_statistics',64,72),('mark_statistics',75,90),('cubic_hessian',93,96),
       ('annulus_budget',99,102),('__main__',105,107)]
def fn(line):
    for n,a,b in fns:
        if a<=line<=b: return n
    return 'other:%s'%line
tot = collections.Counter(); kil = collections.Counter(); verdicts=collections.Counter()
lines_surv = collections.Counter()
mixed=[]
for r in d[2:]:
    f = fn(r['line']); tot[f]+=1; verdicts[r['verdict']]+=1
    if r['verdict']=='KILLED': kil[f]+=1
    elif r['verdict']=='SURVIVED': lines_surv[r['line']]+=1
    else: mixed.append(r['site'])
print('verdicts', dict(verdicts), 'total', sum(tot.values()), 'mixed', mixed)
for n,_,_ in fns: print(n, kil[n], 'of', tot[n])
for k in tot:
    if k.startswith('other'): print(k, kil[k], tot[k])
print('surv by line', sorted(lines_surv.items()))
# baseline
print('baseline', d[0]['result']['normal']['ok'], d[0]['result']['optimized']['ok'], d[1]['result']['normal']['ok'], d[1]['result']['optimized']['ok'])
# mutants killed only by test_invalid_count_laws_rejected
only=[]
for r in d[2:]:
    if r['verdict']!='KILLED': continue
    ok=True
    for m in ('normal','optimized'):
        p=r['result'][m]['parts']
        if not p['check_exact.py']['ok']: ok=False
        if p['test_exact.py']['failed']!=['test_invalid_count_laws_rejected']: ok=False
    if ok: only.append((r['line'], r['site']))
print('only L102', len(only)); 
for o in only: print(' ', o)
# also: killed where test_invalid_count_laws_rejected is among failures in both modes
amg=[r for r in d[2:] if r['verdict']=='KILLED' and all('test_invalid_count_laws_rejected' in r['result'][m]['parts']['test_exact.py']['failed'] for m in ('normal','optimized'))]
print('L102 among failures', len(amg))
# killed only by a single test (any) 
single=collections.Counter()
for r in d[2:]:
    if r['verdict']!='KILLED': continue
    fs=[tuple(r['result'][m]['parts']['test_exact.py']['failed']) for m in ('normal','optimized')]
    ck=[r['result'][m]['parts']['check_exact.py']['ok'] for m in ('normal','optimized')]
    if fs[0]==fs[1] and len(fs[0])==1 and all(ck): single[fs[0][0]]+=1
print('single-test kills', dict(single))
