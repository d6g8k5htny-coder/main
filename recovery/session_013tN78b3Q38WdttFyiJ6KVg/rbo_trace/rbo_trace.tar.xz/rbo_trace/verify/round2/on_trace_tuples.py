"""Re-run the trace's own R3 tuples (same RNG stream) and check them with my resultant code."""
import io, contextlib, sys, json
from fractions import Fraction as F
here = sys.argv[1]
trace_src = open(sys.argv[2]).read()
hook = "    p, extras_su, Hval = build(rng)\n"
assert trace_src.count(hook) == 1
trace_src = trace_src.replace(hook, hook + "    CAPTURE.append((p, extras_su, Hval))\n")
g = {'__name__': 'trace_copy', 'CAPTURE': []}
sys.argv = ['x', sys.argv[3]]
with contextlib.redirect_stdout(io.StringIO()) as buf:
    exec(compile(trace_src, 'trace_copy', 'exec'), g)
trace_out = json.loads(buf.getvalue())
cap = g['CAPTURE']
ns = {'__name__': 'mine'}
mine_src = open(here + '/indep_crit.py').read()
with contextlib.redirect_stdout(io.StringIO()):
    exec(compile(mine_src, 'mine', 'exec'), ns)
import random
r = random.Random(5)
res = dict(n=len(cap), u1_eq_u2=0, Z2_zero=0, Z1_zero=0, four_distinct=0, sum_tautology=0)
for p, extras, Hval in cap:
    k, s, a, b, q = p
    (u1, Z1), (u2, Z2) = extras
    res['u1_eq_u2'] += u1 == u2
    res['Z2_zero'] += Z2 == 0
    res['Z1_zero'] += Z1 == 0
    pts = [(F(-1, 2), F(0)), (F(1, 2), F(0))] + [(u - a*Z/(12*k), Z) for u, Z in extras]
    while True:
        lam = F(r.randint(1, 60), r.randint(1, 13))
        tv = [X + lam*Z for X, Z in pts]
        if len(set(tv)) == 4:
            break
    R, lcA, lcB = ns['crit_resultant'](k, s, a, b, q, lam)
    ok = (len(R) == 5 and len(ns['ugcd'](R, ns['uderiv'](R))) == 1 and len(lcA) == 1 and len(lcB) == 1
          and all(ns['ueval'](R, t) == 0 for t in tv))
    res['four_distinct'] += ok
print(json.dumps({'trace_R3_complete': trace_out['R3_lemma1_complete_critical_set_is_the_four_points'], **res}))
