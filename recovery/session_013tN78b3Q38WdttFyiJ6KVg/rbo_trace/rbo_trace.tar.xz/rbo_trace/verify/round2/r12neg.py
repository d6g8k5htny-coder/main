from fractions import Fraction as F
import random
rng = random.Random(1)
def rnd(lo=-30, hi=30, den=9): return F(rng.randint(lo, hi), rng.randint(1, den))
def grad(p, x, z):
    k, s, a, b, q = p
    return (6*k*x**2 - 3*k/2 + a*x*z + b*z**2/2, s*z + a*(x**2 - F(1, 4))/2 + b*x*z + q*z**2/2)
def shear(p):
    k, s, a, b, q = p
    return b - a*a/(12*k), (q - a*b/(4*k) + a**3/(72*k*k))/2
def fac(p, dds=0):
    k, s, a, b, q = p
    Bs, Ds = shear(p); Ds += dds
    for u in (F(0), F(1), F(2)):
        for Z in (F(0), F(1), F(2)):
            X = u - a*Z/(12*k)
            gX, gZ = grad(p, X, Z)
            if gX != 6*k*(u*u - F(1, 4)) + Bs*Z*Z/2 or gZ - a/(12*k)*gX != Z*(s + Bs*u + Ds*Z):
                return False
    return True
ps=[(F(rng.randint(1, 40), rng.randint(1, 7)), rnd(), rnd(), rnd(), rnd()) for _ in range(300)]
print('correct', sum(fac(p) for p in ps), 'wrongDs(+1/3)', sum(fac(p, F(1,3)) for p in ps))
