"""Independent round-2 check of R12/R3 (verifier scratch). Own polynomial arithmetic; no packet or trace import."""
from fractions import Fraction as F
import random
import json

# ---- sparse multivariate polynomials: dict {exponent tuple: Fraction}
NV = 2  # variables (t or u or X, Z)


def padd(p, q, c=1):
    r = dict(p)
    for e, v in q.items():
        r[e] = r.get(e, 0) + c * v
        if r[e] == 0:
            del r[e]
    return r


def pmul(p, q):
    r = {}
    for e1, v1 in p.items():
        for e2, v2 in q.items():
            e = tuple(a + b for a, b in zip(e1, e2))
            r[e] = r.get(e, 0) + v1 * v2
            if r[e] == 0:
                del r[e]
    return r


def const(c, n=NV):
    return {(0,) * n: F(c)} if c != 0 else {}


def var(i, n=NV):
    e = [0] * n
    e[i] = 1
    return {tuple(e): F(1)}


def ppow(p, m):
    r = const(1, len(next(iter(p))) if p else NV)
    for _ in range(m):
        r = pmul(r, p)
    return r


def pdiff(p, i):
    r = {}
    for e, v in p.items():
        if e[i]:
            e2 = list(e)
            e2[i] -= 1
            r[tuple(e2)] = r.get(tuple(e2), 0) + v * e[i]
    return {e: v for e, v in r.items() if v != 0}


def deg_in(p, i):
    return max((e[i] for e in p), default=-1)


def total_deg(p):
    return max((sum(e) for e in p), default=-1)


# ---- my own transcription of GLOBAL L61-62 in original coords (X, Z)
def P_poly(k, s, a, beta, q):
    X, Z = var(0), var(1)
    P = {}
    P = padd(P, pmul(const(2 * k), ppow(X, 3)))
    P = padd(P, pmul(const(-F(3) * k / 2), X))
    P = padd(P, const(-k / 2))
    P = padd(P, pmul(const(s / 2), ppow(Z, 2)))
    P = padd(P, pmul(const(a / 2), pmul(padd(ppow(X, 2), const(-F(1, 4))), Z)))
    P = padd(P, pmul(const(beta / 2), pmul(X, ppow(Z, 2))))
    P = padd(P, pmul(const(q / 6), ppow(Z, 3)))
    return P


def subst_X(p, Xrep, Zrep):
    """p(X, Z) with X -> Xrep(u,Z), Z -> Zrep(u,Z) (both polys in 2 vars)."""
    r = {}
    for (i, j), v in p.items():
        r = padd(r, pmul(const(v), pmul(ppow(Xrep, i), ppow(Zrep, j))))
    return r


def shear(k, a, beta, q):
    return beta - a * a / (12 * k), (q - a * beta / (4 * k) + a ** 3 / (72 * k * k)) / 2


# ---- univariate helpers (lists of Fractions, low to high)
def utrim(p):
    p = list(p)
    while p and p[-1] == 0:
        p.pop()
    return p


def umul(p, q):
    if not p or not q:
        return []
    r = [F(0)] * (len(p) + len(q) - 1)
    for i, x in enumerate(p):
        for j, y in enumerate(q):
            r[i + j] += x * y
    return utrim(r)


def uadd(p, q, c=1):
    n = max(len(p), len(q))
    return utrim([(p[i] if i < len(p) else 0) + c * (q[i] if i < len(q) else 0) for i in range(n)])


def umod(p, q):
    p = utrim(p)
    q = utrim(q)
    while len(p) >= len(q):
        c = p[-1] / q[-1]
        sh = len(p) - len(q)
        p = uadd(p, [F(0)] * sh + [c * x for x in q], -1)
    return p


def ugcd(p, q):
    p, q = utrim(p), utrim(q)
    while q:
        p, q = q, umod(p, q)
    return p


def uderiv(p):
    return utrim([i * p[i] for i in range(1, len(p))])


def ueval(p, x):
    return sum(c * x ** i for i, c in enumerate(p))


def as_uni_in_Z_coeffs(p):
    """p(t, Z) -> list over Z-degree of univariate-in-t lists."""
    dz = deg_in(p, 1)
    out = []
    for j in range(dz + 1):
        dt = max((e[0] for e in p if e[1] == j), default=-1)
        out.append(utrim([p.get((i, j), F(0)) for i in range(dt + 1)]))
    return out


def res_quadratics(A, B):
    """Resultant in Z of A2 Z^2 + A1 Z + A0 and B2 Z^2 + B1 Z + B0 (coefficients univariate in t)."""
    A = A + [[]] * (3 - len(A))
    B = B + [[]] * (3 - len(B))
    A0, A1, A2 = A
    B0, B1, B2 = B
    t1 = uadd(umul(A2, B0), umul(A0, B2), -1)
    t2 = uadd(umul(A2, B1), umul(A1, B2), -1)
    t3 = uadd(umul(A1, B0), umul(A0, B1), -1)
    return uadd(umul(t1, t1), umul(t2, t3), -1)


rng = random.Random(777)


def rnd(lo=-30, hi=30, den=9):
    return F(rng.randint(lo, hi), rng.randint(1, den))


out = {}

# (1) R12 symbolically per tuple: full polynomial identity in (u, Z), plus degree bookkeeping
ok12 = True
max_deg = [0, 0, 0]
for _ in range(200):
    k = F(rng.randint(1, 40), rng.randint(1, 7))
    s, a, beta, q = rnd(), rnd(), rnd(), rnd()
    Bs, Ds = shear(k, a, beta, q)
    P = P_poly(k, s, a, beta, q)
    PX, PZ = pdiff(P, 0), pdiff(P, 1)
    u, Z = var(0), var(1)
    Xrep = padd(u, pmul(const(-a / (12 * k)), Z))
    PXs, PZs = subst_X(PX, Xrep, Z), subst_X(PZ, Xrep, Z)
    # independent route: differentiate P(u - aZ/(12k), Z) directly in sheared variables
    Ps = subst_X(P, Xrep, Z)
    du, dZ = pdiff(Ps, 0), pdiff(Ps, 1)
    conic = padd(pmul(const(6 * k), padd(ppow(u, 2), const(-F(1, 4)))), pmul(const(Bs / 2), ppow(Z, 2)))
    line = padd(padd(const(s), pmul(const(Bs), u)), pmul(const(Ds), Z))
    ZL = pmul(Z, line)
    d1 = padd(du, conic, -1)
    d2 = padd(dZ, ZL, -1)
    chain = padd(PZs, pmul(const(-a / (12 * k)), PXs))
    ok12 &= d1 == {} and d2 == {} and padd(du, PXs, -1) == {} and padd(dZ, chain, -1) == {}
    # degree of the trace's differences gX - conic and (gZ - a/(12k) gX) - Z line, as polys in (u, Z)
    e1 = padd(PXs, conic, -1)
    e2 = padd(chain, ZL, -1)
    # before cancellation: degrees of the pieces
    for pc in (PXs, conic, chain, ZL):
        max_deg[0] = max(max_deg[0], deg_in(pc, 0))
        max_deg[1] = max(max_deg[1], deg_in(pc, 1))
        max_deg[2] = max(max_deg[2], total_deg(pc))
out['R12_symbolic_identity_200_tuples'] = ok12
out['R12_piece_degrees_max_[u,Z,total]'] = max_deg


# (2) wrong-Ds negative control (the doc claims one; reproduce it myself)
def grid_check(k, s, a, beta, q, Ds_override=None):
    Bs, Ds = shear(k, a, beta, q)
    if Ds_override is not None:
        Ds = Ds_override
    for uu in (F(0), F(1), F(2)):
        for ZZ in (F(0), F(1), F(2)):
            X = uu - a * ZZ / (12 * k)
            gX = 6 * k * X ** 2 - F(3) * k / 2 + a * X * ZZ + beta * ZZ ** 2 / 2
            gZ = s * ZZ + a * (X ** 2 - F(1, 4)) / 2 + beta * X * ZZ + q * ZZ ** 2 / 2
            if gX != 6 * k * (uu * uu - F(1, 4)) + Bs * ZZ * ZZ / 2 or gZ - a / (12 * k) * gX != ZZ * (s + Bs * uu + Ds * ZZ):
                return False
    return True


wrong_fails = 0
for _ in range(100):
    k = F(rng.randint(1, 40), rng.randint(1, 7))
    s, a, beta, q = rnd(), rnd(), rnd(), rnd()
    Bs, Ds = shear(k, a, beta, q)
    wrong_fails += (not grid_check(k, s, a, beta, q, Ds + 1))
out['wrong_Ds_fails_count_of_100'] = wrong_fails


# (3) complete complex critical set by resultant, for R3-style constructed tuples and for plain random typed tuples
def build():
    while True:
        k = F(rng.randint(1, 12), rng.randint(1, 5))
        u1, Z1 = rnd(-12, 12, 6), rnd(-12, 12, 6)
        if Z1 == 0 or u1 * u1 == F(1, 4):
            continue
        Bs = -12 * k * (u1 * u1 - F(1, 4)) / (Z1 * Z1)
        s = -abs(Bs) / 2 - F(rng.randint(1, 30), rng.randint(1, 6))
        Ds = -(s + Bs * u1) / Z1
        a = rnd(-20, 20, 4)
        beta = Bs + a * a / (12 * k)
        q = 2 * Ds + a * beta / (4 * k) - a ** 3 / (72 * k * k)
        Delta = 12 * k * Ds * Ds + Bs ** 3
        Hval = Delta - 4 * Bs * s * s
        if Ds == 0 or Bs == 0 or Delta == 0 or Hval == 0:
            continue
        u2 = -2 * Bs * Bs * s / Delta - u1
        Z2 = -(s + Bs * u2) / Ds
        return (k, s, a, beta, q), [(u1, Z1), (u2, Z2)]


def crit_resultant(k, s, a, beta, q, lam):
    P = P_poly(k, s, a, beta, q)
    PX, PZ = pdiff(P, 0), pdiff(P, 1)
    t, Z = var(0), var(1)
    Xrep = padd(t, pmul(const(-lam), Z))   # t = X + lam Z
    A = as_uni_in_Z_coeffs(subst_X(PX, Xrep, Z))
    B = as_uni_in_Z_coeffs(subst_X(PZ, Xrep, Z))
    lcA = A[2] if len(A) > 2 else []
    lcB = B[2] if len(B) > 2 else []
    return res_quadratics(A, B), lcA, lcB


n_ok = 0
dup_u = 0
z2_zero = 0
for _ in range(300):
    p, extras = build()
    k, s, a, beta, q = p
    pts = [(F(-1, 2), F(0)), (F(1, 2), F(0))] + [(u - a * Z / (12 * k), Z) for u, Z in extras]
    while True:  # projection must separate the four known points (otherwise a fake collision)
        lam = F(rng.randint(1, 50), rng.randint(1, 13))
        tvals = [X + lam * Z for X, Z in pts]
        if len(set(tvals)) == 4:
            break
    R, lcA, lcB = crit_resultant(k, s, a, beta, q, lam)
    deg4 = len(R) == 5
    sqfree = len(ugcd(R, uderiv(R))) == 1
    lc_const = len(lcA) == 1 and len(lcB) == 1  # Z^2 coefficients constant in t
    roots_ok = all(ueval(R, tv) == 0 for tv in tvals) and len(set(tvals)) == 4
    dup_u += extras[0][0] == extras[1][0]
    z2_zero += extras[1][1] == 0
    good = deg4 and sqfree and roots_ok and lc_const and len(set(pts)) == 4
    n_ok += good
    if not good:
        print("FAIL", dict(deg4=deg4, sqfree=sqfree, roots_ok=roots_ok, lc_const=lc_const, npts=len(set(pts)), ntv=len(set(tvals)), lam=str(lam), pts=[(str(x), str(z)) for x, z in pts]))
out['constructed_tuples_exactly_four_distinct_complex_crit_pts'] = f'{n_ok}/300'
out['constructed_u1_eq_u2'] = dup_u
out['constructed_Z2_zero'] = z2_zero

# plain random typed tuples (no constructed rational extras): count complex critical points
cnt = {}
for _ in range(60):
    while True:
        k = F(rng.randint(1, 20), rng.randint(1, 5))
        a, beta, q = rnd(), rnd(), rnd()
        Bs, Ds = shear(k, a, beta, q)
        s = -abs(Bs) / 2 - F(rng.randint(1, 30), rng.randint(1, 6))
        Delta = 12 * k * Ds * Ds + Bs ** 3
        Hval = Delta - 4 * Bs * s * s
        if Bs and Ds and Delta and Hval:
            break
    lam = F(rng.randint(1, 50), rng.randint(1, 13))
    R, lcA, lcB = crit_resultant(k, s, a, beta, q, lam)
    key = (len(R) - 1, len(ugcd(R, uderiv(R))) == 1)
    cnt[str(key)] = cnt.get(str(key), 0) + 1
out['random_typed_(resultant_degree, squarefree)'] = cnt

# (4) Is the coefficient match independent of how u2 is built? Sum is tautological; product is Q(u1)=0.
taut_sum = 0
prod_detects = 0
for _ in range(100):
    p, extras = build()
    k, s, a, beta, q = p
    Bs, Ds = shear(k, a, beta, q)
    Delta = 12 * k * Ds * Ds + Bs ** 3
    u1 = extras[0][0] + F(1, 3)        # a WRONG u1
    u2 = -2 * Bs * Bs * s / Delta - u1  # u2 rebuilt from it by Vieta, as the trace does
    taut_sum += Delta * (-(u1 + u2)) == 2 * Bs * Bs * s
    prod_detects += Delta * u1 * u2 != Bs * s * s - 3 * k * Ds * Ds
out['sum_check_passes_with_wrong_u1_of_100'] = taut_sum
out['product_check_fails_with_wrong_u1_of_100'] = prod_detects

print(json.dumps(out, indent=1))
