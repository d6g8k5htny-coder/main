"""Is the trace's hand-coded grad() equal to the gradient of its own P()? Exact 5-point stencil (exact to degree 4)."""
import ast, sys, random
from fractions import Fraction as F
src = open(sys.argv[1]).read()
tree = ast.parse(src)
keep = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in ('P', 'grad')]
ns = {'F': F}
exec(compile(ast.Module(body=keep, type_ignores=[]), 'trace_defs', 'exec'), ns)
P, grad = ns['P'], ns['grad']
r = random.Random(3)
def rnd(): return F(r.randint(-30, 30), r.randint(1, 9))
ok = True
uses_P = 'P(' in ast.unparse([n for n in keep if n.name == 'grad'][0])
for _ in range(300):
    p = (F(r.randint(1, 40), r.randint(1, 7)), rnd(), rnd(), rnd(), rnd())
    x, z, h = rnd(), rnd(), F(1, 3)
    d = lambda f: (-f(2*h) + 8*f(h) - 8*f(-h) + f(-2*h)) / (12*h)
    gx = d(lambda t: P(p, x + t, z)); gz = d(lambda t: P(p, x, z + t))
    ok &= grad(p, x, z) == (gx, gz)
print({'grad_matches_P': ok, 'grad_body_calls_P': uses_P})
