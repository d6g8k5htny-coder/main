"""Own independent numeric re-derivations (no import of trace_checks_rbo.py or check_exact.py)."""
from fractions import Fraction as F
from itertools import combinations, chain
import random
g = random.Random(777)
def rq(lo=-20, hi=20, den=7): return F(g.randint(lo, hi), g.randint(1, den))
out = {}

# ---- R3 independent: own construction of typed cubics with a rational extra root, Vieta partner, exact Hessian by formula
def Pval(k, s, a, be, q, X, Z):
    return 2*k*X**3 - 3*k*X/2 - k/2 + s*Z*Z/2 + a*(X*X - F(1, 4))*Z/2 + be*X*Z*Z/2 + q*Z**3/6
def num_grad(k, s, a, be, q, X, Z, h=F(1, 3)):
    # exact for cubic: central first difference has error h^2 f'''/6 -> not exact; use 4-point formula exact to deg 4
    f = lambda dx, dz: Pval(k, s, a, be, q, X + dx, Z + dz)
    gx = (-f(2*h, 0) + 8*f(h, 0) - 8*f(-h, 0) + f(-2*h, 0)) / (12*h)
    gz = (-f(0, 2*h) + 8*f(0, h) - 8*f(0, -h) + f(0, -2*h)) / (12*h)
    return gx, gz
def hess(k, s, a, be, q, X, Z):
    return 12*k*X + a*Z, a*X + be*Z, s + be*X + q*Z
cnt = dict(n=0, crit=0, pins=0, id3=0, nonegdef=0, double=0, Z2zero=0, types={})
while cnt['n'] < 400:
    k = F(g.randint(1, 9), g.randint(1, 4))
    u1, Z1 = rq(), rq()
    if Z1 == 0 or u1*u1 == F(1, 4): continue
    Bs = -12*k*(u1*u1 - F(1, 4))/(Z1*Z1)
    s = -abs(Bs)/2 - F(g.randint(1, 40), g.randint(1, 9))
    Ds = -(s + Bs*u1)/Z1
    if Bs == 0 or Ds == 0: continue
    a = rq()
    be = Bs + a*a/(12*k)
    q = 2*Ds + a*be/(4*k) - a**3/(72*k*k)
    Delta = 12*k*Ds**2 + Bs**3; H = Delta - 4*Bs*s*s
    if Delta == 0 or H == 0: continue
    # quadratic A u^2 + Bq u + C ; second root by product (not sum) to differ from the trace's Vieta-sum
    A, Bq, C = Delta, 2*Bs*Bs*s, Bs*s*s - 3*k*Ds*Ds
    assert A*u1*u1 + Bq*u1 + C == 0
    u2 = C/(A*u1) if u1 != 0 else -Bq/A
    assert A*u2*u2 + Bq*u2 + C == 0
    Z2 = -(s + Bs*u2)/Ds
    cnt['n'] += 1
    cnt['double'] += (u1 == u2); cnt['Z2zero'] += (Z2 == 0)
    ok = True
    for uu, ZZ in [(u1, Z1), (u2, Z2)]:
        X = uu - a*ZZ/(12*k)
        ok &= num_grad(k, s, a, be, q, X, ZZ) == (0, 0)
        hxx, hxz, hzz = hess(k, s, a, be, q, X, ZZ)
        d = hxx*hzz - hxz*hxz
        cnt['id3'] += (d == -3*k*(Bs + 4*s*uu) and H*ZZ*ZZ == 3*k*(Bs + 4*s*uu)**2)
        cnt['nonegdef'] += not (d > 0 and hxx < 0)
        t = 'saddle' if d < 0 else ('min' if d > 0 and hxx > 0 else ('max' if d > 0 else 'deg'))
        cnt['types'][t] = cnt['types'].get(t, 0) + 1
    cnt['crit'] += ok
    pm = [num_grad(k, s, a, be, q, F(x0), F(0)) == (0, 0) for x0 in (F(-1, 2), F(1, 2))]
    hm, hs = hess(k, s, a, be, q, F(-1, 2), F(0)), hess(k, s, a, be, q, F(1, 2), F(0))
    dm, ds = hm[0]*hm[2] - hm[1]**2, hs[0]*hs[2] - hs[1]**2
    cnt['pins'] += all(pm) and dm == 3*k*(Bs - 2*s) > 0 and hm[0] < 0 and ds == 3*k*(Bs + 2*s) < 0
out['R3_own'] = cnt

# ---- R3 forward direction (root count): float multi-start Newton on random typed cubics, count distinct critical points
import math
def count_crit(k, s, a, be, q):
    def gr(X, Z): return (6*k*X*X - 1.5*k + a*X*Z + be*Z*Z/2, s*Z + a*(X*X - .25)/2 + be*X*Z + q*Z*Z/2)
    def hs(X, Z): return (12*k*X + a*Z, a*X + be*Z, s + be*X + q*Z)
    roots = []
    for i in range(-12, 13):
        for j in range(-12, 13):
            X, Z = i/2.0, j/2.0
            for _ in range(80):
                gx, gz = gr(X, Z); hxx, hxz, hzz = hs(X, Z); d = hxx*hzz - hxz*hxz
                if abs(d) < 1e-14: break
                X, Z = X - (hzz*gx - hxz*gz)/d, Z - (-hxz*gx + hxx*gz)/d
                if abs(X) > 1e6 or abs(Z) > 1e6: break
            gx, gz = gr(X, Z)
            if abs(gx) + abs(gz) < 1e-9 and all(math.hypot(X - r[0], Z - r[1]) > 1e-6 for r in roots):
                roots.append((X, Z))
    return len(roots)
mx = 0
for _ in range(60):
    k = g.uniform(.2, 5); a = g.uniform(-5, 5); be = g.uniform(-5, 5); q = g.uniform(-5, 5)
    Bs = be - a*a/(12*k); s = -abs(Bs)/2 - g.uniform(.01, 3)
    mx = max(mx, count_crit(k, s, a, be, q))
out['max_critical_points_float_typed'] = mx

# ---- R7 independent: TV as sup over events (subset enumeration), not the L1 half-sum
okc = 0; tot = 0
for _ in range(200):
    supp = g.sample(range(0, 7), g.randint(2, 5))
    wts = [F(g.randint(1, 15)) for _ in supp]; Z = sum(wts)
    law = {n: w/Z for n, w in zip(supp, wts)}
    pos = sum(p for n, p in law.items() if n > 0)
    cond = {n: p/pos for n, p in law.items() if n > 0}
    pts = sorted(set(cond) | {1})
    tv = max(abs(sum(cond.get(n, 0) for n in A) - (1 if 1 in A else 0))
             for A in chain.from_iterable(combinations(pts, r) for r in range(len(pts) + 1)))
    p2 = sum(p for n, p in law.items() if n >= 2)
    tot += 1
    okc += (tv == p2/pos and tv <= sum(n*p for n, p in law.items() if n >= 2)/(2*pos))
out['R7_own_tv_sup_over_events'] = (okc, tot)
# (O13) n=0..500
out['O13_own'] = all(max(n-1, 0) <= n*(n >= 2) and n - (1 if n > 0 else 0) == max(n-1, 0) and 2*(n >= 2) <= n*(n >= 2) and max(n-1,0) >= 0 for n in range(501))

# ---- R8 independent with an explicit Phi bound larger than marks and with all-equal-sign extremes
ok8 = True
for _ in range(1000):
    n = g.randint(0, 15); Mb = F(g.randint(1, 9), g.randint(1, 4))
    marks = [Mb*F(g.randint(-10, 10), 10) for _ in range(n)]
    S = sum(marks, F(0))
    ok8 &= abs(S - (S/n if n else 0)) <= Mb*max(n-1, 0)
# sharpness: all marks = Mb gives equality
out['R8_own'] = ok8
out['R8_equality_case'] = all(abs(n*F(3) - (F(3) if n else 0)) == F(3)*max(n-1, 0) for n in range(10))
for kk, vv in out.items(): print(kk, vv)
