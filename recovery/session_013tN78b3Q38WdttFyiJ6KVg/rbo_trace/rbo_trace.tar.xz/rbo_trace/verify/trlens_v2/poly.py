"""Tiny exact multivariate Laurent-in-k polynomial arithmetic (own code, not from trace_checks_rbo.py)."""
from fractions import Fraction as F
VARS = ['k', 'ik', 's', 'a', 'b', 'q', 'X', 'Z', 'u', 'w', 'x0', 'z0', 'x1', 'z1'] + ['c%d' % i for i in range(10)]
IDX = {v: i for i, v in enumerate(VARS)}
N = len(VARS)

def _norm(m):
    m = list(m)
    t = min(m[0], m[1]); m[0] -= t; m[1] -= t   # k * ik = 1
    return tuple(m)

class P:
    def __init__(self, d=None):
        self.d = {}
        for m, c in (d or {}).items():
            if c:
                m = _norm(m); self.d[m] = self.d.get(m, F(0)) + c
                if not self.d[m]: del self.d[m]
    @staticmethod
    def const(c):
        return P({(0,)*N: F(c)})
    @staticmethod
    def var(v):
        m = [0]*N; m[IDX[v]] = 1; return P({tuple(m): F(1)})
    def _c(self, o):
        return o if isinstance(o, P) else P.const(o)
    def __add__(self, o):
        o = self._c(o); d = dict(self.d)
        for m, c in o.d.items(): d[m] = d.get(m, F(0)) + c
        return P(d)
    __radd__ = __add__
    def __neg__(self): return P({m: -c for m, c in self.d.items()})
    def __sub__(self, o): return self + (-self._c(o))
    def __rsub__(self, o): return self._c(o) - self
    def __mul__(self, o):
        o = self._c(o); d = {}
        for m1, c1 in self.d.items():
            for m2, c2 in o.d.items():
                m = _norm(tuple(x+y for x, y in zip(m1, m2))); d[m] = d.get(m, F(0)) + c1*c2
        return P(d)
    __rmul__ = __mul__
    def __truediv__(self, c):  # only by rational constants
        return self * (F(1)/F(c))
    def __pow__(self, n):
        r = P.const(1)
        for _ in range(n): r = r * self
        return r
    def iszero(self): return not self.d
    def diff(self, v):
        i = IDX[v]; d = {}
        for m, c in self.d.items():
            if m[i]:
                mm = list(m); mm[i] -= 1; d[tuple(mm)] = d.get(tuple(mm), F(0)) + c*m[i]
        return P(d)
    def subs(self, v, expr):
        i = IDX[v]; r = P()
        for m, c in self.d.items():
            mm = list(m); e = mm[i]; mm[i] = 0
            r = r + P({tuple(mm): c}) * (expr ** e)
        return r
    def coeff_in(self, v, e):
        i = IDX[v]; d = {}
        for m, c in self.d.items():
            if m[i] == e:
                mm = list(m); mm[i] = 0; d[tuple(mm)] = c
        return P(d)
    def __repr__(self):
        return ' + '.join('%s*%s' % (c, '*'.join('%s^%d' % (VARS[i], e) for i, e in enumerate(m) if e)) for m, c in sorted(self.d.items())) or '0'
V = P.var
