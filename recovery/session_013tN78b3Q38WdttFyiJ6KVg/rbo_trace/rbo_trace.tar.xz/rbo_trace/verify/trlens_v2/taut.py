from fractions import Fraction as F
import random
out = {}
# --- R9: the reciprocal identity holds for ANY pair predicate, provided D and the pair list use the same predicate
g = random.Random(5)
holds = 0
for t in range(2000):
    nM, nS = g.randint(1, 8), g.randint(1, 12)
    pred = [[g.random() < g.random() for _ in range(nS)] for _ in range(nM)]
    D = [sum(r) for r in pred]
    N = sum(d > 0 for d in D)
    H = 1 if N >= 2 else 0
    pairs = [(i, j) for i in range(nM) for j in range(nS) if pred[i][j]]
    holds += (N == sum(F(1, D[i]) for i, j in pairs) and N*H == sum(F(H, D[i]) for i, j in pairs))
out['R9_identity_with_arbitrary_random_predicate'] = (holds, 2000)
# --- replicate the R9 configurations (copied generator, for diagnosis only) and forget the partner exclusion CONSISTENTLY
def config(seed):
    gg = random.Random(seed)
    maxima = [((F(gg.randint(-12, 12), 4), F(gg.randint(-12, 12), 4)), F(gg.randint(1, 40), 8)) for _ in range(gg.randint(2, 7))]
    saddles = [((F(gg.randint(-12, 12), 4), F(gg.randint(-12, 12), 4)), F(gg.randint(-40, 20), 8)) for _ in range(gg.randint(3, 12))]
    partner = [gg.randrange(len(saddles)) for _ in maxima]
    return maxima, saddles, partner
def adm(M, S, is_partner, c0=F(1, 2), C0=F(5, 2), klo=F(1, 50), khi=F(4)):
    (mp, fm), (sp, fs) = M, S
    d2 = (mp[0]-sp[0])**2 + (mp[1]-sp[1])**2; gap = fm - fs
    return (not is_partner and gap > 0 and d2 > 0 and c0*c0 <= d2 <= C0*C0 and klo*klo*d2**3 <= gap*gap <= khi*khi*d2**3)
cons = 0; mism = 0; Ndiff = 0
for seed in range(400):
    Mx, Sd, pt = config(seed)
    Db = [sum(adm(M, S, False) for S in Sd) for M in Mx]          # partner exclusion forgotten in D
    Nb = sum(d > 0 for d in Db)
    pairs_b = [(i, j) for i, M in enumerate(Mx) for j, S in enumerate(Sd) if adm(M, S, False)]  # ...and in the pairs
    cons += Nb == sum(F(1, Db[i]) for i, j in pairs_b)
    D = [sum(adm(M, S, j == pt[i]) for j, S in enumerate(Sd)) for i, M in enumerate(Mx)]
    Ndiff += (sum(d > 0 for d in D) != Nb)
out['R9_partner_exclusion_forgotten_consistently_identity_holds'] = (cons, 400)
out['R9_configs_where_partnerless_N_differs_from_true_N'] = Ndiff
# --- R11: first equality holds for ANY affine-node quadrature rule (e.g. trapezoid, midpoint), not because of exactness
def trap(f, lo, hi): return (hi - lo)/2*(f(lo) + f(hi))
def boole(f, lo, hi):
    hh = (hi - lo)/4
    return (hi - lo)/90*(7*f(lo) + 32*f(lo+hh) + 12*f(lo+2*hh) + 32*f(lo+3*hh) + 7*f(hi))
grid = [(c0, C0, h) for c0, C0 in [(F(1, 3), F(2)), (F(1, 2), F(7, 4)), (F(1), F(3))] for h in [F(1, 5), F(3, 7), F(1, 100)]]
out['R11_first_equality_with_trapezoid'] = all(trap(lambda r: r*r**3, c0*h, C0*h) == h**5*trap(lambda t: t**4, c0, C0) for c0, C0, h in grid)
out['R11_trapezoid_closed_form'] = all(trap(lambda t: t**4, c0, C0) == (C0**5 - c0**5)/5 for c0, C0, h in grid)
out['R11_first_equality_with_wrong_integrand_r^5'] = all(boole(lambda r: r**5, c0*h, C0*h) == h**6*boole(lambda t: t**5, c0, C0) for c0, C0, h in grid)
out['Boole_exact_deg5'] = all(boole(lambda t: t**d, F(1, 3), F(2)) == (F(2)**(d+1) - F(1, 3)**(d+1))/(d+1) for d in range(6))
out['Boole_exact_deg6'] = boole(lambda t: t**6, F(1, 3), F(2)) == (F(2)**7 - F(1, 3)**7)/7
# --- R6 choice part: holds for any order and is implied termwise by construction
g2 = random.Random(9); ok_any = True; same = True
for _ in range(500):
    C, c = F(g2.randint(1, 30), 7), F(g2.randint(1, 30), 11)
    delta = c/(8*C); eps = c/8      # chosen BEFORE R (reverse of the proof's order)
    R = F(1)
    while C/R**2 + C/R >= c/4: R *= 2
    tot = C/R**2 + C/R + eps + C*delta
    ok_any &= tot < 3*c/4
    same &= ((tot < 3*c/4) == (c - tot > c/4))
    assert C*delta < c/4 and eps < c/4 and C/R**2 + C/R < c/4   # each term < c/4 by construction
out['R6_reverse_order_also_passes'] = ok_any
out['R6_margin_conjunct_equivalent_to_3c/4_conjunct'] = same
for kk, vv in out.items(): print(kk, vv)
