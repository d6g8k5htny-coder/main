import sys
from fractions import Fraction as F
src_path, wt = sys.argv[1], sys.argv[2]
src = open(src_path).read()
needle = "    p, extras_su, Hval = build(rng)\n"
assert src.count(needle) == 1
src = src.replace(needle, needle + "    REC.append((p, extras_su, Hval))\n")
src = src.replace("print(json.dumps(results, indent=1))", "")
sys.argv = ['x', wt]
ns = {'REC': [], '__name__': 'probe'}
exec(compile(src, 'trace_copy', 'exec'), ns)
REC = ns['REC']; shear = ns['shear']; grad = ns['grad']; P = ns['P']; fd_grad = ns['fd_grad']
print('R3 tuples', len(REC))
# 1. stencil exactness: degree 4 exact, degree 5 not
h = F(1, 4)
def st(f, x):
    return (-f(x+2*h) + 8*f(x+h) - 8*f(x-h) + f(x-2*h)) / (12*h)
for d in range(7):
    x = F(7, 3)
    ex = st(lambda t: t**d, x) == (d * x**(d-1) if d else 0)
    print('stencil exact for t^%d:' % d, ex)
# 2. conic_on_line - Q identically zero at many u, u1 != u2, Z2 != 0, extras off the pins, Q(u1)=0 directly
bad = 0; dist = 0; z2nz = 0; qu1 = 0; roots_only = 0
for p, ex, Hval in REC:
    k, s, a, b, q = p
    Bs, Ds = shear(p)
    Delta = 12*k*Ds*Ds + Bs**3
    (u1, Z1), (u2, Z2) = ex
    col = lambda uu: 2*Ds*Ds*(6*k*(uu*uu - F(1, 4)) + Bs*(-(s + Bs*uu)/Ds)**2/2)
    Q = lambda uu: Delta*uu*uu + 2*Bs*Bs*s*uu + Bs*s*s - 3*k*Ds*Ds
    bad += any(col(F(t, 7)) != Q(F(t, 7)) for t in range(-20, 21))
    dist += u1 != u2
    z2nz += Z2 != 0 and Z1 != 0
    qu1 += Q(u1) == 0 and Q(u2) == 0
    # Q equals Delta (u-u1)(u-u2) as polynomials: compare at 3 points
    roots_only += all(Q(F(t)) == Delta*(F(t)-u1)*(F(t)-u2) for t in (0, 1, 2))
print('conic_on_line != Q at some of 41 u values:', bad)
print('u1 != u2:', dist, ' Z1,Z2 nonzero:', z2nz, ' Q(u1)=Q(u2)=0 directly:', qu1, ' Q == Delta(u-u1)(u-u2):', roots_only)
# 3. Ds_shift control: where does it first fail
sgf = ns['sheared_gradient_factors']
t12 = ns['tuples12']
print('R12 tuples', len(t12), 'shift +1 passes on', sum(sgf(p, Ds_shift=F(1)) for p in t12),
      ' shift 0 passes on', sum(sgf(p) for p in t12))
# shift tiny: does an arbitrary nonzero shift also fail? (sanity that check sees Ds)
print('shift 1/10**9 passes on', sum(sgf(p, Ds_shift=F(1, 10**9)) for p in t12))
# 4. R0: wrong gradient would be caught? perturb grad's b*z^2/2 term
def bad_grad(p, x, z):
    k, s, a, b, qq = p
    gx, gz = grad(p, x, z)
    return gx + b*z*z/2, gz
import random
r = random.Random(1)
rr = lambda: F(r.randint(-30, 30), r.randint(1, 9))
pts = [((F(r.randint(1, 40), r.randint(1, 7)), rr(), rr(), rr(), rr()), rr(), rr()) for _ in range(50)]
print('fd_grad matches grad on fresh points:', all(grad(*t) == fd_grad(*t) for t in pts),
      ' perturbed grad caught on', sum(bad_grad(*t) != fd_grad(*t) for t in pts), 'of 50')
