import json, sys
from collections import Counter
census = json.load(open(sys.argv[1]))
req_first = {16,18,24,25,33,35,38,60,65,66,68,80,89,101}
cont = {19,20,26,34,36,69}
recs = [r for r in census if r.get('site') not in ('baseline','baseline-unparsed')]
tc = Counter()
for r in recs:
    if r['line'] in req_first | cont and r['verdict']=='KILLED':
        fn = r['result']['normal']['parts']['test_exact.py']['failed']
        fo = r['result']['optimized']['parts']['test_exact.py']['failed']
        ce = r['result']['normal']['parts']['check_exact.py']['ok']
        tag = 'CONT' if r['line'] in cont else ''
        print(r['line'], tag, r['site'], 'check_exact_ok=%s' % ce, fn if fn==fo else (fn,fo))
        for t in set(fn): tc[t]+=1
print(tc)
