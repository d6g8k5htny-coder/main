import ast, json, sys
from collections import Counter, defaultdict
census = json.load(open(sys.argv[1]))
src = open(sys.argv[2]).read()
tree = ast.parse(src)
FUNCS = {'rational','count_statistics','mark_statistics','annulus_budget','contained_file','verify_entry'}
func_span = {}
req_spans = defaultdict(list)  # func -> list of (start,end)
for fn in tree.body:
    if isinstance(fn, ast.FunctionDef):
        func_span[fn.name] = (fn.lineno, fn.end_lineno)
        for node in ast.walk(fn):
            if isinstance(node, ast.Call) and getattr(node.func, 'id', None) == 'require':
                req_spans[fn.name].append((node.lineno, node.end_lineno))
for f in sorted(FUNCS):
    print(f, func_span[f], req_spans[f])
recs = [r for r in census if r.get('site') not in ('baseline','baseline-unparsed')]
print('total mutants', len(recs), Counter(r['verdict'] for r in recs))
def in_func(line):
    for f,(a,b) in func_span.items():
        if a <= line <= b: return f
    return None
full = set(); first = set()
for f in FUNCS:
    for a,b in req_spans[f]:
        first.add(a)
        full.update(range(a,b+1))
def tally(lines, label):
    sel = [r for r in recs if r['line'] in lines]
    c = Counter(r['verdict'] for r in sel)
    print(label, len(sel), dict(c))
    return sel
selfull = tally(full, 'full require spans')
selfirst = tally(first, 'first lines only')
# per line breakdown
bl = defaultdict(Counter)
for r in recs:
    if in_func(r['line']) in FUNCS:
        bl[r['line']][r['verdict']] += 1
for l in sorted(bl): print(' L%d %s %s %s' % (l, in_func(l), 'REQ' if l in full else '---', dict(bl[l])))
# all mutants in the six functions
six = [r for r in recs if in_func(r['line']) in FUNCS]
print('all in six funcs', len(six), Counter(r['verdict'] for r in six))
# mutants whose mutated node lies inside a require call node (by AST node index) - use node index ranges
