import ast, sys
src = open(sys.argv[1]).read()
t = ast.parse(src)
for node in ast.walk(t):
    if isinstance(node, ast.FunctionDef) and node.name.startswith('test_'):
        calls = sorted({n.func.attr for n in ast.walk(node) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and isinstance(n.func.value, ast.Name) and n.func.value.id == 'c'})
        refs = sorted({n.attr for n in ast.walk(node) if isinstance(n, ast.Attribute) and isinstance(n.value, ast.Name) and n.value.id == 'c'})
        print(node.lineno, node.name, calls, refs)
src2 = open(sys.argv[2]).read()
t2 = ast.parse(src2)
keys = set()
for n in ast.walk(t2):
    if isinstance(n, ast.Subscript) and isinstance(n.slice, ast.Constant): keys.add(('sub', n.slice.value))
    if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == 'get' and n.args and isinstance(n.args[0], ast.Constant): keys.add(('get', n.args[0].value))
print(sorted(keys, key=repr))
