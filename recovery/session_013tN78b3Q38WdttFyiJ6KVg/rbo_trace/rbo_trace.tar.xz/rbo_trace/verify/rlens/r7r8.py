import random, itertools
from fractions import Fraction as Q
rng = random.Random(31337)
# R7: TV(Law(N|N>0), delta_1) via sup over events (independent of the half-L1 formula)
ok_id = ok_b = True; tight = 0
for _ in range(300):
    sup = rng.sample(range(0, 8), rng.randint(2, 5))
    w = [Q(rng.randint(1, 15)) for _ in sup]; tot = sum(w)
    law = {n: wi/tot for n, wi in zip(sup, w)}
    pos = sum(p for n, p in law.items() if n > 0)
    cond = {n: p/pos for n, p in law.items() if n > 0}
    pts = sorted(set(cond) | {1})
    tv = max(abs(sum(cond.get(n, 0) for n in A) - (1 if 1 in A else 0))
             for r in range(len(pts)+1) for A in itertools.combinations(pts, r))
    p2 = sum(p for n, p in law.items() if n >= 2)/pos
    ok_id &= tv == p2
    bnd = sum(n*p for n, p in law.items() if n >= 2)/(2*pos)
    ok_b &= tv <= bnd; tight += tv == bnd
print('TV sup-def == P(N>=2|N>0):', ok_id, '; <= E[N;N>=2]/(2P(N>0)):', ok_b, '; equality cases', tight)
# (O13)
print('O13 n<=500:', all(0 <= max(n-1, 0) <= n*(n >= 2) and n - (n > 0) == max(n-1, 0) and 2*(n >= 2) <= n*(n >= 2) for n in range(501)))
# R8: (O14) with Phi bounded by an arbitrary M >= max|marks|
ok = True
for _ in range(1000):
    n = rng.randint(0, 15); M = Q(rng.randint(1, 20), rng.randint(1, 5))
    marks = [M*Q(rng.randint(-100, 100), 100) for _ in range(n)]
    S = sum(marks, Q(0)); avg = S/n if n else Q(0)
    ok &= abs(S - avg) <= M*max(n-1, 0)
print('O14 pointwise:', ok)
