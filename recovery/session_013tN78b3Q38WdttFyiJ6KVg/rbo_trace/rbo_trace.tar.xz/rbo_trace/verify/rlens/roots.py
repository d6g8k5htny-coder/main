"""Independent: typed cubics with rational extra roots; find ALL critical points by resultant; classify."""
import random
from fractions import Fraction as Q
rng = random.Random(4242)

def pmul(p, r):
    o = [Q(0)]*(len(p)+len(r)-1)
    for i, x in enumerate(p):
        for j, y in enumerate(r):
            o[i+j] += x*y
    return o
def padd(p, r):
    n = max(len(p), len(r)); return [(p[i] if i < len(p) else 0) + (r[i] if i < len(r) else 0) for i in range(n)]
def psub(p, r): return padd(p, [-x for x in r])
def trim(p):
    p = list(p)
    while p and p[-1] == 0: p.pop()
    return p
def peval(p, z): return sum(c*z**i for i, c in enumerate(p))
def pdivroot(p, r):  # synthetic division by (Z - r)
    p = trim(p); n = len(p)-1; out = [Q(0)]*n; acc = Q(0)
    for i in range(n, 0, -1):
        acc = acc*r + p[i]; out[i-1] = acc
    rem = acc*r + p[0]
    return out, rem

def P_val(k, s, a, be, qq, X, Z):
    return 2*k*X**3 - 3*k*X/2 - k/2 + s*Z*Z/2 + a*(X*X - Q(1,4))*Z/2 + be*X*Z*Z/2 + qq*Z**3/6
def hess_exact(k, s, a, be, qq, X, Z):
    # my own second partials of P (derived by hand, then checked against P by 4th-order-exact differences below)
    return 12*k*X + a*Z, a*X + be*Z, s + be*X + qq*Z

stats = dict(n=0, count4=0, all_nondeg=0, only_M0_negdef=0, types=set(), vieta_match=0, delta_match=0,
             hessian_fd_ok=0, extras_distinct=0, extras_not_pins=0)
while stats['n'] < 400:
    k = Q(rng.randint(1, 20), rng.randint(1, 6))
    u1, Z1 = Q(rng.randint(-15, 15), rng.randint(1, 7)), Q(rng.randint(-15, 15), rng.randint(1, 7))
    if Z1 == 0 or u1*u1 == Q(1,4): continue
    Bs = -12*k*(u1*u1 - Q(1,4))/(Z1*Z1)
    s = -abs(Bs)/2 - Q(rng.randint(1, 40), rng.randint(1, 9))
    Ds = -(s + Bs*u1)/Z1
    a = Q(rng.randint(-25, 25), rng.randint(1, 5))
    if a == 0 or Ds == 0: continue
    be = Bs + a*a/(12*k)
    qq = 2*Ds + a*be/(4*k) - a**3/(72*k*k)
    Delta = 12*k*Ds*Ds + Bs**3; H = Delta - 4*Bs*s*s
    if Delta == 0 or H == 0: continue
    stats['n'] += 1
    # gradient: g1 = 6k X^2 + (aZ) X + (be Z^2/2 - 3k/2); g2 = (a/2) X^2 + (be Z) X + (qq Z^2/2 + s Z - a/8)
    A2, A1, A0 = [6*k], [0, a], [-3*k/2, 0, be/2]
    B2, B1, B0 = [a/2], [0, be], [-a/8, s, qq/2]
    t1 = psub(pmul(A2, B0), pmul(A0, B2)); t2 = psub(pmul(A2, B1), pmul(A1, B2)); t3 = psub(pmul(A1, B0), pmul(A0, B1))
    R = trim(psub(pmul(t1, t1), pmul(t2, t3)))
    assert R, 'resultant identically zero'
    # Z=0 is a root of multiplicity >= 2 (two pins)
    Rq, rem0 = pdivroot(R, Q(0)); Rq2, rem1 = pdivroot(Rq, Q(0))
    assert rem0 == 0 and rem1 == 0
    Rq2 = trim(Rq2)
    deg = len(Rq2) - 1
    # roots of Rq2 (quadratic in Z): Z1 must be a root
    _, r = pdivroot(Rq2, Z1); assert r == 0
    lin, _ = pdivroot(Rq2, Z1); lin = trim(lin)
    assert len(lin) == 2
    Z2 = -lin[0]/lin[1]
    # for each Z root, solve common X: X from eliminating X^2: A2*g2 - B2*g1 is linear in X
    crit = [(Q(-1,2), Q(0)), (Q(1,2), Q(0))]
    for Zr in (Z1, Z2):
        c1 = peval(A2, Zr)*peval(B1, Zr) - peval(B2, Zr)*peval(A1, Zr)
        c0 = peval(A2, Zr)*peval(B0, Zr) - peval(B2, Zr)*peval(A0, Zr)
        assert c1 != 0
        Xr = -c0/c1
        g1 = 6*k*Xr*Xr + a*Zr*Xr + be*Zr*Zr/2 - 3*k/2
        g2 = a*Xr*Xr/2 + be*Zr*Xr + qq*Zr*Zr/2 + s*Zr - a/8
        assert g1 == 0 and g2 == 0
        crit.append((Xr, Zr))
    stats['count4'] += (deg == 2 and len(set(crit)) == 4)
    stats['extras_distinct'] += crit[2] != crit[3]
    stats['extras_not_pins'] += all(c[1] != 0 for c in crit[2:])
    # Vieta on Lemma 1 quadratic (sheared u)
    u2_vieta = -2*Bs*Bs*s/Delta - u1
    u2 = crit[3][0] + a*crit[3][1]/(12*k)
    stats['vieta_match'] += (u2 == u2_vieta)
    negdef = []
    ok_nd = True; ok_fd = True; ok_d = True
    for (Xr, Zr) in crit:
        hxx, hxz, hzz = hess_exact(k, s, a, be, qq, Xr, Zr)
        # check Hessian against P with a step-h stencil exact for cubics, two step sizes
        for h in (Q(1,3), Q(2,5)):
            f = lambda dx, dz: P_val(k, s, a, be, qq, Xr+dx, Zr+dz)
            ok_fd &= hxx == (f(h,0) - 2*f(0,0) + f(-h,0))/h/h
            ok_fd &= hzz == (f(0,h) - 2*f(0,0) + f(0,-h))/h/h
            ok_fd &= hxz == (f(h,h) - f(h,-h) - f(-h,h) + f(-h,-h))/(4*h*h)
        d = hxx*hzz - hxz*hxz
        ok_nd &= d != 0
        negdef.append(d > 0 and hxx < 0)
        if Zr != 0:
            uu = Xr + a*Zr/(12*k)
            ok_d &= d == -3*k*(Bs + 4*s*uu) and H*Zr*Zr == 3*k*(Bs + 4*s*uu)**2
            stats['types'].add('saddle' if d < 0 else 'min' if hxx > 0 else 'max')
    stats['all_nondeg'] += ok_nd
    stats['hessian_fd_ok'] += ok_fd
    stats['delta_match'] += ok_d
    stats['only_M0_negdef'] += (negdef == [True, False, False, False])
stats['types'] = sorted(stats['types'])
print(stats)
