"""Tiny exact multivariate polynomial arithmetic (fresh code, no reuse of trace_checks_rbo.py)."""
from fractions import Fraction as Q

class Poly:
    VARS = ('X', 'Z', 'u', 's', 'a', 'b', 'q', 'k', 'Bs', 'Ds', 'w', 't')
    def __init__(self, terms=None):
        self.t = {}
        for m, c in (terms or {}).items():
            if c != 0:
                self.t[m] = self.t.get(m, 0) + Q(c)
        self.t = {m: c for m, c in self.t.items() if c != 0}
    @classmethod
    def var(cls, name):
        e = [0]*len(cls.VARS); e[cls.VARS.index(name)] = 1
        return cls({tuple(e): 1})
    @classmethod
    def const(cls, c):
        return cls({tuple([0]*len(cls.VARS)): c})
    def _c(self, o):
        return o if isinstance(o, Poly) else Poly.const(o)
    def __add__(self, o):
        o = self._c(o); d = dict(self.t)
        for m, c in o.t.items(): d[m] = d.get(m, 0) + c
        return Poly(d)
    __radd__ = __add__
    def __neg__(self): return Poly({m: -c for m, c in self.t.items()})
    def __sub__(self, o): return self + (-self._c(o))
    def __rsub__(self, o): return self._c(o) - self
    def __mul__(self, o):
        o = self._c(o); d = {}
        for m1, c1 in self.t.items():
            for m2, c2 in o.t.items():
                m = tuple(x+y for x, y in zip(m1, m2)); d[m] = d.get(m, 0) + c1*c2
        return Poly(d)
    __rmul__ = __mul__
    def __truediv__(self, c):
        return Poly({m: v/Q(c) for m, v in self.t.items()})
    def __pow__(self, n):
        r = Poly.const(1)
        for _ in range(n): r = r*self
        return r
    def diff(self, name):
        i = Poly.VARS.index(name); d = {}
        for m, c in self.t.items():
            if m[i]:
                mm = list(m); mm[i] -= 1; d[tuple(mm)] = d.get(tuple(mm), 0) + c*m[i]
        return Poly(d)
    def subs(self, env):
        """Substitute Poly/number values for variables (all at once)."""
        out = Poly.const(0)
        for m, c in self.t.items():
            term = Poly.const(c)
            for i, e in enumerate(m):
                if e:
                    name = Poly.VARS[i]
                    val = env.get(name, Poly.var(name))
                    term = term * (self._c(val) ** e)
            out = out + term
        return out
    def is_zero(self): return not self.t
    def value(self):
        assert all(sum(m) == 0 for m in self.t), self.t
        return sum(self.t.values(), Q(0))
