import sys, random
sys.path.insert(0, sys.argv[1])
from poly import Poly as P_
from fractions import Fraction as Q
V = P_.var
X, Z, u, s, a, b, q, k, Bs, Ds, w = (V(n) for n in ('X','Z','u','s','a','b','q','k','Bs','Ds','w'))
rng = random.Random(777)
out = {}

# --- H3 shear, symbolic in a,b,q,X,Z, for several numeric k (division by k needs numeric k)
ok = True
for kk in [Q(1), Q(5,7), Q(3), Q(11,2), Q(1,9)]:
    H3 = 2*kk*X**3 + (a/2)*X**2*Z + (b/2)*X*Z**2 + (q/6)*Z**3
    uu = X + a*Z/(12*kk)
    BS = b - a*a/(12*kk)
    DS = (q - a*b/(4*kk) + a**3/(72*kk*kk))/2
    ok &= (2*kk*uu**3 + (BS/2)*uu*Z**2 + (DS/3)*Z**3 - H3).is_zero()
    # full P in sheared coordinates: P = 2k u^3 + (Bs/2) u Z^2 + (Ds/3) Z^3 - 3k u/2 - k/2 + s Z^2/2
    P = 2*kk*X**3 - 3*kk*X/2 - kk/2 + s*Z**2/2 + (a/2)*(X**2 - Q(1,4))*Z + (b/2)*X*Z**2 + (q/6)*Z**3
    Psh = 2*kk*uu**3 + (BS/2)*uu*Z**2 + (DS/3)*Z**3 - 3*kk*uu/2 - kk/2 + s*Z**2/2
    ok &= (P - Psh).is_zero()
out['H3_shear_and_P_sheared_symbolic'] = ok

# --- sheared gradient of P: conic and Z*line (symbolic in u,Z,Bs,Ds,s,k)
Psh = 2*k*u**3 + (Bs/2)*u*Z**2 + (Ds/3)*Z**3 - 3*k*u/2 - k/2 + s*Z**2/2
out['dPdu_is_conic'] = (Psh.diff('u') - (6*k*(u**2 - Q(1,4)) + (Bs/2)*Z**2)).is_zero()
out['dPdZ_is_Z_times_line'] = (Psh.diff('Z') - Z*(s + Bs*u + Ds*Z)).is_zero()

# --- Lemma 1 elimination, symbolic: 2Ds^2*conic with Ds Z -> -(s+Bs u)
lhs = 12*k*Ds**2*(u**2 - Q(1,4)) + Bs*(s + Bs*u)**2
rhs = (12*k*Ds**2 + Bs**3)*u**2 + 2*Bs**2*s*u + Bs*s**2 - 3*k*Ds**2
out['lemma1_elimination_symbolic'] = (lhs - rhs).is_zero()

# --- Lemma 1 identity (3), symbolic in sheared coords: det of (u,Z)-Hessian on the root variety.
# Hessian of Psh wrt (u,Z): [12ku, Bs Z; Bs Z, Bs u + 2 Ds Z + s]. On the variety: Ds Z = -(s+Bs u), Bs Z^2 = -12k(u^2-1/4).
huu = Psh.diff('u').diff('u'); huz = Psh.diff('u').diff('Z'); hzz = Psh.diff('Z').diff('Z')
det = huu*hzz - huz*huz
# Reduce: write det with DsZ and BsZ^2 substitutions manually by expansion check:
# det = 12ku(Bs u + 2 DsZ + s) - Bs*(Bs Z^2)
DZ = -(s + Bs*u); BZ2 = -12*k*(u**2 - Q(1,4))
det_red = 12*k*u*(Bs*u + 2*DZ + s) - Bs*BZ2
out['det_form_matches_hessian'] = (det - (12*k*u*(Bs*u + 2*Ds*Z + s) - Bs*Bs*Z*Z)).is_zero()
out['identity3_det'] = (det_red - (-3*k*(Bs + 4*s*u))).is_zero()
HZ2 = 12*k*DZ**2 + Bs**2*BZ2 - 4*s**2*BZ2   # H Z^2 = 12k (DsZ)^2 + (Bs^2 - 4 s^2)(Bs Z^2)
out['identity3_HZ2'] = (HZ2 - 3*k*(Bs + 4*s*u)**2).is_zero()

# --- pin determinants in ORIGINAL coordinates, symbolic in s,a,b (numeric k)
ok = True
for kk in [Q(1), Q(5,7), Q(3)]:
    P = 2*kk*X**3 - 3*kk*X/2 - kk/2 + s*Z**2/2 + (a/2)*(X**2 - Q(1,4))*Z + (b/2)*X*Z**2 + (q/6)*Z**3
    BS = b - a*a/(12*kk)
    gx, gz = P.diff('X'), P.diff('Z')
    for x0, sign in [(Q(-1,2), -1), (Q(1,2), 1)]:
        env = {'X': x0, 'Z': 0}
        ok &= gx.subs(env).is_zero() and gz.subs(env).is_zero()
        hxx = P.diff('X').diff('X').subs(env); hxz = P.diff('X').diff('Z').subs(env); hzz = P.diff('Z').diff('Z').subs(env)
        ok &= (hxx*hzz - hxz*hxz - 3*kk*(BS + sign*2*s)).is_zero()
        ok &= (hxx - sign*6*kk).is_zero()
out['pins_critical_and_dets_3k(Bs-+2s)_axial_-+6k'] = ok

# --- Lemma 2 elimination symbolic: with Z=1 and u=-Ds/Bs, 2Bs^2(6k u^2 + Bs/2) = 12k Ds^2 + Bs^3
# u=-Ds/Bs not polynomial; multiply: 2Bs^2*6k*(Ds/Bs)^2 = 12k Ds^2
out['lemma2_elim'] = ((12*k*Ds**2 + Bs**3) - (2*6*k*Ds**2 + Bs**3)).is_zero()
# sheared homogeneous gradient: d/du H3s = 6k u^2 + Bs/2 Z^2, d/dZ = Z(Bs u + Ds Z)
H3s = 2*k*u**3 + (Bs/2)*u*Z**2 + (Ds/3)*Z**3
out['lemma2_equations'] = (H3s.diff('u') - (6*k*u**2 + (Bs/2)*Z**2)).is_zero() and (H3s.diff('Z') - Z*(Bs*u + Ds*Z)).is_zero()
# Delta=0 parametrisation: Bs=-12k w^2, Ds=12k w^3 is the general solution with Bs!=0 (Ds/Bs = -w) -> check Delta = 0 symbolic
out['delta0_param'] = (12*k*(12*k*w**3)**2 + (-12*k*w**2)**3).is_zero()
# and general solution: Delta=0 with Bs!=0 implies Bs<0 and w := -Ds/Bs gives Bs = -12k w^2: 12kDs^2 = -Bs^3 -> 12k w^2 Bs^2 = -Bs^3 -> Bs = -12k w^2
print(out)
