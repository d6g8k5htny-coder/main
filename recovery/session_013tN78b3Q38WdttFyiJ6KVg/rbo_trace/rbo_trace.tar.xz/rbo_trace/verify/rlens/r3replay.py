"""Trace-side exact checks for Math- replacement_bar_occurrence_20261001 (Claude 54).

usage: python3 -B -I trace_checks_rbo.py MATH_WORKTREE
Not part of the packet; standard library only; does not import check_exact.py. Each check is a finite rational
computation (or a Git object read) for a PROOF.md / GLOBAL.md step that the packet's tests take as given or do
not exercise. Randomized checks are evidence for identities, not proofs.
"""
from fractions import Fraction as F
import hashlib
import json
import random
import subprocess
import sys
from pathlib import Path

ROOT = Path(sys.argv[1]).resolve()
PACKET = 'frontiers/replacement_bar_occurrence_20261001'
rng = random.Random(20261026)
results = {}


def rnd(lo=-30, hi=30, den=9):
    return F(rng.randint(lo, hi), rng.randint(1, den))


# ---------------------------------------------------------------- the cubic of GLOBAL §2 (L61-66), original coords
def P(p, x, z):
    k, s, a, b, q = p
    return 2*k*x**3 - 3*k*x/2 - k/2 + s*z**2/2 + a*(x**2 - F(1, 4))*z/2 + b*x*z**2/2 + q*z**3/6


def grad(p, x, z):
    k, s, a, b, q = p
    return (6*k*x**2 - 3*k/2 + a*x*z + b*z**2/2, s*z + a*(x**2 - F(1, 4))/2 + b*x*z + q*z**2/2)


def fd_hess(p, x, z, h=F(1, 4)):
    # central second differences are exact for a cubic
    f = lambda dx, dz: P(p, x + dx, z + dz)
    fxx = (f(h, 0) - 2*f(0, 0) + f(-h, 0)) / (h*h)
    fzz = (f(0, h) - 2*f(0, 0) + f(0, -h)) / (h*h)
    fxz = (f(h, h) - f(h, -h) - f(-h, h) + f(-h, -h)) / (4*h*h)
    return fxx, fxz, fzz


def shear(p):
    k, s, a, b, q = p
    return b - a*a/(12*k), (q - a*b/(4*k) + a**3/(72*k*k))/2


def H3(p, x, z):
    k, s, a, b, q = p
    return 2*k*x**3 + a*x*x*z/2 + b*x*z*z/2 + q*z**3/6


# R1. GLOBAL L74-78: after u = X + aZ/(12k), H3 = 2k u^3 + (Bs/2) u Z^2 + (Ds/3) Z^3 (random rational points).
ok = True
for _ in range(300):
    p = (F(rng.randint(1, 40), rng.randint(1, 7)), rnd(), rnd(), rnd(), rnd())
    x, z = rnd(), rnd()
    Bs, Ds = shear(p)
    u = x + p[2]*z/(12*p[0])
    ok &= H3(p, x, z) == 2*p[0]*u**3 + Bs*u*z*z/2 + Ds*z**3/3
results['R1_sheared_leading_cubic'] = ok

# R2. GLOBAL L105-113 (Lemma 1): substituting the line D_s Z = -(s + B_s u) of (2) into 2 D_s^2 times the conic
#     6k(u^2 - 1/4) + (B_s/2) Z^2 gives exactly (12k Ds^2 + Bs^3) u^2 + 2 Bs^2 s u + Bs s^2 - 3k Ds^2.
ok = True
for _ in range(300):
    k, s, Bs, Ds, u = F(rng.randint(1, 40), rng.randint(1, 7)), rnd(), rnd(), rnd() or F(1), rnd()
    DZ = -(s + Bs*u)
    lhs = 2*Ds*Ds*6*k*(u*u - F(1, 4)) + Bs*DZ*DZ
    ok &= lhs == (12*k*Ds*Ds + Bs**3)*u*u + 2*Bs*Bs*s*u + Bs*s*s - 3*k*Ds*Ds
results['R2_lemma1_elimination'] = ok


# R3. Lemma 1's conclusion on random typed cubics built to have rational extra roots: choose an extra root (u1, Z1),
#     solve the conic for Bs and the line for Ds, choose typed s and a free shear a, and recover (beta, q). Then the
#     second extra root comes from Vieta on the elimination quadratic. Check: both extras are critical points of P,
#     the gradient of P vanishes at the pins, M0 is a strict maximum and S0 a saddle, no extra root has a
#     negative-definite Hessian, and (3) holds: det Hess = -3k(Bs + 4su), H Z^2 = 3k(Bs + 4su)^2.
def build(rng):
    while True:
        k = F(rng.randint(1, 12), rng.randint(1, 5))
        u1, Z1 = rnd(-12, 12, 6), rnd(-12, 12, 6)
        if Z1 == 0 or u1 * u1 == F(1, 4):
            continue
        Bs = -12*k*(u1*u1 - F(1, 4)) / (Z1*Z1)
        s = -abs(Bs)/2 - F(rng.randint(1, 30), rng.randint(1, 6))
        Ds = -(s + Bs*u1) / Z1
        a = rnd(-20, 20, 4)
        b = Bs + a*a/(12*k)
        q = 2*Ds + a*b/(4*k) - a**3/(72*k*k)
        Delta = 12*k*Ds*Ds + Bs**3
        Hval = Delta - 4*Bs*s*s
        if Ds == 0 or Bs == 0 or Delta == 0 or Hval == 0:
            continue
        u2 = -2*Bs*Bs*s/Delta - u1
        Z2 = -(s + Bs*u2) / Ds
        return (k, s, a, b, q), [(u1, Z1), (u2, Z2)], Hval


ok_roots = ok_pins = ok_no_second_max = ok_r13 = True
SAME=[];ZERO=[];BSNEG=[]
extra_types = set()
for _ in range(300):
    p, extras_su, Hval = build(rng)
    k, s, a, b, q = p
    Bs, Ds = shear(p)
    for xx, zz in [(F(-1, 2), F(0)), (F(1, 2), F(0))]:
        ok_roots &= grad(p, xx, zz) == (0, 0)
    hm, hs = fd_hess(p, F(-1, 2), F(0)), fd_hess(p, F(1, 2), F(0))
    detm, dets = hm[0]*hm[2] - hm[1]**2, hs[0]*hs[2] - hs[1]**2
    ok_pins &= detm > 0 and hm[0] < 0 and dets < 0 and detm == 3*k*(Bs - 2*s) and dets == 3*k*(Bs + 2*s)
    SAME.append(extras_su[0]==extras_su[1]); ZERO.append(any(Z==0 for _,Z in extras_su)); BSNEG.append(Bs<0)
    for u, Z in extras_su:
        x = u - a*Z/(12*k)
        ok_roots &= grad(p, x, Z) == (0, 0)
        hxx, hxz, hzz = fd_hess(p, x, Z)
        det = hxx*hzz - hxz*hxz
        negdef = det > 0 and hxx < 0
        ok_no_second_max &= not negdef
        extra_types.add('saddle' if det < 0 else ('min' if det > 0 else 'degenerate'))
        ok_r13 &= det == -3*k*(Bs + 4*s*u) and Hval*Z*Z == 3*k*(Bs + 4*s*u)**2
results['R3_lemma1_extras_are_critical'] = ok_roots
results['R3_lemma1_pins_max_and_saddle_with_3k_Bs_pm_2s'] = ok_pins
results['R3_lemma1_no_second_negative_definite_root'] = ok_no_second_max
results['R3_lemma1_identity_3'] = ok_r13
results['R3_extra_root_types_seen'] = sorted(extra_types)

# instrumentation (replay of R3's own RNG stream)
rng2_state = None

print('coincident extras', sum(SAME), 'extra with Z=0', sum(ZERO), 'Bs<0', sum(BSNEG), 'of', len(SAME))
print({k:v for k,v in results.items() if k.startswith('R3')})
