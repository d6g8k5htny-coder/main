import random
from fractions import Fraction as Q
rng = random.Random(99)

# ---------- R6: Lemma 5 budget, re-derived
# (8)/|x|^2 = C r^2/x^2 + C r/x + eps + C x  <=  C/R^2 + C/R + eps + C delta  whenever R r <= x <= delta.
ok = True; tight = 0
for _ in range(2000):
    C = Q(rng.randint(1, 50), rng.randint(1, 9)); R = Q(rng.randint(1, 60), rng.randint(1, 5))
    delta = Q(rng.randint(1, 30), rng.randint(1, 40)); eps = Q(rng.randint(0, 30), 97)
    r = delta/R * Q(rng.randint(1, 1000), 1000)
    for x in (R*r, delta, R*r + (delta - R*r)*Q(rng.randint(0, 97), 97)):
        e = (C*r*r + C*r*x + eps*x*x + C*x**3)/(x*x)
        ok &= e <= C/R**2 + C/R + eps + C*delta
        tight += e == C/R**2 + C/R + eps + C*delta
print('R6a bound holds', ok, 'equality cases', tight)
# out-of-annulus: x < R r can violate
viol = 0
for _ in range(500):
    C, R, delta, eps = Q(1), Q(4), Q(1,2), Q(0)
    r = Q(1, 100); x = R*r/2
    viol += (C*r*r + C*r*x + eps*x*x + C*x**3)/(x*x) > C/R**2 + C/R + eps + C*delta
print('R6a fails inside Rr (as expected)', viol > 0)
# R6b: the two conjuncts are the same inequality
eqv = all(((T < 3*c/4) == (c - T > c/4)) for c in [Q(n, 7) for n in range(1, 30)] for T in [Q(m, 13) for m in range(-40, 80)])
print('R6b "below 3c/4" <=> "margin c/4":', eqv)
# R6b: with the script's construction (C/R^2+C/R<c/4 by loop, delta=c/(8C), eps=c/8) the total is < c/2 for ALL inputs: true by construction
worst = Q(0)
for _ in range(5000):
    C, c = Q(rng.randint(1, 300), rng.randint(1, 13)), Q(rng.randint(1, 300), rng.randint(1, 13))
    R = Q(1)
    while C/R**2 + C/R >= c/4: R *= 2
    T = C/R**2 + C/R + c/8 + C*(c/(8*C))
    worst = max(worst, T/c)
print('R6b max total/c under the script construction:', float(worst), '(< 1/2 always; 3/4 never approached)')

# ---------- R9: (O8) reciprocal identity is true by construction for ANY admissibility predicate
fails = 0
for seed in range(400):
    g = random.Random(seed)
    nM, nS = g.randint(2, 7), g.randint(3, 12)
    adm = {(i, j): g.random() < 0.3 for i in range(nM) for j in range(nS)}   # arbitrary predicate: no geometry, no partner
    D = [sum(adm[i, j] for j in range(nS)) for i in range(nM)]
    N = sum(d > 0 for d in D); H = int(N >= 2)
    pairs = [(i, j) for (i, j), v in adm.items() if v]
    fails += not (N*H == sum(Q(H, D[i]) for i, j in pairs) and N == sum(Q(1, D[i]) for i, j in pairs))
print('R9 identity with a random coin-flip predicate: failures', fails, 'of 400')

# R9: how many of the trace's 218 "breaks" break the MARKED identity (O8) N*H = sum H/D?
def config(seed):
    g = random.Random(seed)
    maxima = [((Q(g.randint(-12, 12), 4), Q(g.randint(-12, 12), 4)), Q(g.randint(1, 40), 8)) for _ in range(g.randint(2, 7))]
    saddles = [((Q(g.randint(-12, 12), 4), Q(g.randint(-12, 12), 4)), Q(g.randint(-40, 20), 8)) for _ in range(g.randint(3, 12))]
    partner = [g.randrange(len(saddles)) for _ in maxima]
    return maxima, saddles, partner
def adm2(M, S, isp):
    (mp, fm), (sp, fs) = M, S
    d2 = (mp[0]-sp[0])**2 + (mp[1]-sp[1])**2; gap = fm - fs
    return (not isp) and gap > 0 and d2 > 0 and Q(1,4) <= d2 <= Q(25,4) and Q(1,2500)*d2**3 <= gap*gap <= 16*d2**3
b_unmarked = b_marked = nge2 = 0; birth_band_effect = 0
for seed in range(400):
    Ms, Ss, pt = config(seed)
    D = [sum(adm2(M, S, j == pt[i]) for j, S in enumerate(Ss)) for i, M in enumerate(Ms)]
    N = sum(d > 0 for d in D); H = int(N >= 2); nge2 += H
    pairs = [(i, j) for i, M in enumerate(Ms) for j, S in enumerate(Ss) if adm2(M, S, j == pt[i])]
    Db = [sum(adm2(M, S, False) for S in Ss) for M in Ms]
    b_unmarked += N != sum(Q(1, Db[i]) for i, j in pairs)
    b_marked += N*H != sum(Q(H, Db[i]) for i, j in pairs)
print('R9 replay: N>=2 in', nge2, '; partnerless denominator breaks N=sum 1/D in', b_unmarked, '; breaks marked (O8) N*H=sum H/D in', b_marked)

# ---------- R11: Boole's rule
def boole(f, lo, hi):
    hh = (hi - lo)/4
    return (hi - lo)/90*(7*f(lo) + 32*f(lo+hh) + 12*f(lo+2*hh) + 32*f(lo+3*hh) + 7*f(hi))
exact_deg = [all(boole(lambda t: t**d, lo, hi) == (hi**(d+1) - lo**(d+1))/(d+1) for lo, hi in [(Q(1,3), Q(2)), (Q(-1), Q(5,2))]) for d in range(8)]
print('Boole exact for degree d=0..7:', exact_deg)
# scaling half is construction-true: holds for a NON-exact rule too (trapezoid)
trap = lambda f, lo, hi: (hi - lo)*(f(lo) + f(hi))/2
sc = all(trap(lambda r: r*r**3, c0*h, C0*h) == h**5*trap(lambda t: t**4, c0, C0) for c0, C0 in [(Q(1,3), Q(2)), (Q(1,2), Q(7,4)), (Q(1), Q(3))] for h in [Q(1,5), Q(3,7), Q(1,100)])
ex = all(trap(lambda t: t**4, c0, C0) == (C0**5 - c0**5)/5 for c0, C0 in [(Q(1,3), Q(2)), (Q(1,2), Q(7,4)), (Q(1), Q(3))])
print('trapezoid: scaling equality holds at all 9 triples:', sc, '; trapezoid exact:', ex)
