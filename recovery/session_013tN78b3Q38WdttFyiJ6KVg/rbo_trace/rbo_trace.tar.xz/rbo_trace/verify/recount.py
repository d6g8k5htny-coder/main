import json, sys, ast
from collections import Counter, defaultdict
recs = json.load(open(sys.argv[1]))
orig = open(sys.argv[2]).read()
print(recs[0]['site'], {m: recs[0]['result'][m]['ok'] for m in recs[0]['result']})
print(recs[1]['site'], {m: recs[1]['result'][m]['ok'] for m in recs[1]['result']})
muts = recs[2:]
print('total', len(muts), Counter(r['verdict'] for r in muts))
print('files', Counter(r['file'] for r in muts))
# function mapping by line
tree = ast.parse(orig)
funcs = []
for node in tree.body:
    if isinstance(node, ast.FunctionDef):
        funcs.append((node.lineno, node.end_lineno, node.name))
    elif isinstance(node, ast.If):
        funcs.append((node.lineno, node.end_lineno, '__main__'))
    else:
        funcs.append((node.lineno, node.end_lineno, 'module:'+type(node).__name__))
def fn(line):
    if line is None: return 'None'
    for a,b,n in funcs:
        if a<=line<=b: return n
    return '?'
per = defaultdict(Counter)
for r in muts:
    per[fn(r['line'])][r['verdict']] += 1
for k,v in per.items():
    print(k, dict(v), 'total', sum(v.values()))
print('none-line', [r['site'] for r in muts if r['line'] is None])
print()
surv = [r for r in muts if r['verdict']=='SURVIVED']
for r in surv:
    print(r['line'], fn(r['line']), r['site'])
