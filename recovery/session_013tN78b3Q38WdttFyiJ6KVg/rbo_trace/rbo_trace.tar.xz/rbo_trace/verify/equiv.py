import json, sys, os, importlib.util, tempfile
from pathlib import Path
from fractions import Fraction as F
recs = json.load(open(sys.argv[1]))[2:]
orig_path = sys.argv[2]
work = tempfile.mkdtemp(prefix='eq-', dir=os.path.dirname(os.path.abspath(__file__)))
def load(src, tag):
    p = os.path.join(work, tag + '.py'); open(p, 'w').write(src + '\n')
    spec = importlib.util.spec_from_file_location(tag, p); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
orig = load(open(orig_path).read(), 'orig')
def find(line, site):
    for r in recs:
        if r['line'] == line and r['site'] == site: return load(r['source'], 'm_%d_%d' % (line, site[1]))
m65 = find(65, ['booldrop', 512, 1])
m16 = find(16, ['booldrop', 40, 1])
m25 = find(25, ['booldrop', 148, 1])
def run(f):
    try: return ('ret', f())
    except Exception as e: return ('exc', type(e).__name__, str(e))
# L65
class D(dict):
    def __len__(self): return 0
class D2(dict):
    def __bool__(self): return False
for law in [{}, D({1: F(1)}), D2({1: F(1)})]:
    print('L65', type(law).__name__, run(lambda: orig.count_statistics(law)), run(lambda: m65.count_statistics(law)))
# L16
class S(str):
    def __bool__(self): return False
root = Path(tempfile.mkdtemp(dir=work)).resolve(); (root/'x').write_bytes(b'abc')
for rel in ['', S('x')]:
    print('L16', repr(rel), run(lambda: orig.contained_file(root, rel)), run(lambda: m16.contained_file(root, rel)))
# L25: unresolved (relative) root
os.chdir(root.parent)
rel_root = Path(root.name)
print('L25 relative root', run(lambda: orig.contained_file(rel_root, 'x')), run(lambda: m25.contained_file(rel_root, 'x')))
# symlinked root
link = root.parent / 'rootlink'; link.symlink_to(root)
print('L25 symlinked root', run(lambda: orig.contained_file(link, 'x')), run(lambda: m25.contained_file(link, 'x')))
# through verify_entry (root is resolved at L31)
import hashlib
d=b'abc'; e={'local_path':'x','bytes':3,'sha256':hashlib.sha256(d).hexdigest(),'blob':hashlib.sha1(b'blob 3\0'+d).hexdigest()}
print('L25 via verify_entry rel root', run(lambda: orig.verify_entry(rel_root, e)), run(lambda: m25.verify_entry(rel_root, e)))
