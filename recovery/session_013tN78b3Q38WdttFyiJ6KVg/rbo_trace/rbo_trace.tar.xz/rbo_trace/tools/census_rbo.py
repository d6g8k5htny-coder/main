"""Independent mutation census for Math- replacement_bar_occurrence_20261001 (Claude 54, 26 Oct).

usage: python3 -B census_rbo.py MATH_WORKTREE OUT_JSON
Generates first-order AST mutants of check_exact.py and runs, on each, the README's
test command (test_exact.py -v) and check_exact.py itself, in normal and -O mode, in a
dedicated scratch worktree. A mode fails if either command exits non-zero, test_exact.py
does not end OK, or check_exact.py does not report ten verified sources. The original
file is restored after every mutant.
"""
import ast
import copy
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

PACKET = 'frontiers/replacement_bar_occurrence_20261001'
TARGETS = ('check_exact.py',)

BIN_SWAP = {ast.Add: [ast.Sub], ast.Sub: [ast.Add], ast.Mult: [ast.Div, ast.Add],
            ast.Div: [ast.Mult, ast.FloorDiv], ast.Pow: [ast.Mult], ast.FloorDiv: [ast.Div],
            ast.Mod: [ast.Mult]}
CMP_SWAP = {ast.Lt: [ast.LtE, ast.Gt], ast.LtE: [ast.Lt, ast.GtE], ast.Gt: [ast.GtE, ast.Lt],
            ast.GtE: [ast.Gt, ast.LtE], ast.Eq: [ast.NotEq], ast.NotEq: [ast.Eq],
            ast.In: [ast.NotIn], ast.NotIn: [ast.In], ast.Is: [ast.IsNot], ast.IsNot: [ast.Is]}


class Sites(ast.NodeVisitor):
    """Collect (kind, path-index) for every mutable site, in a stable order."""

    def __init__(self):
        self.sites = []
        self.i = 0

    def generic_visit(self, node):
        self.i += 1
        idx = self.i
        if isinstance(node, ast.BinOp) and type(node.op) in BIN_SWAP:
            for new in BIN_SWAP[type(node.op)]:
                self.sites.append(('binop', idx, new.__name__))
        elif isinstance(node, ast.Compare):
            for j, op in enumerate(node.ops):
                for new in CMP_SWAP.get(type(op), []):
                    self.sites.append(('cmp', idx, (j, new.__name__)))
        elif isinstance(node, ast.BoolOp):
            self.sites.append(('boolop', idx, 'swap'))
            for j in range(len(node.values)):
                self.sites.append(('booldrop', idx, j))
        elif isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.Not, ast.USub)):
            self.sites.append(('unary', idx, 'drop'))
        elif isinstance(node, ast.Constant) and type(node.value) is int:
            self.sites.append(('int', idx, node.value + 1))
            self.sites.append(('int', idx, node.value - 1))
        elif isinstance(node, ast.Raise):
            self.sites.append(('raise', idx, 'pass'))
        elif (isinstance(node, ast.Expr) and isinstance(node.value, ast.Call)
              and getattr(node.value.func, 'id', None) == 'require'):
            self.sites.append(('require', idx, 'pass'))
        elif isinstance(node, ast.If):
            self.sites.append(('ifneg', idx, 'not'))
        super().generic_visit(node)


class Apply(ast.NodeTransformer):
    def __init__(self, site):
        self.kind, self.target, self.arg = site
        self.i = 0
        self.done = False

    def generic_visit(self, node):
        self.i += 1
        idx = self.i
        node = super().generic_visit(node)
        if idx != self.target:
            return node
        self.done = True
        k, a = self.kind, self.arg
        if k == 'binop':
            node.op = getattr(ast, a)()
        elif k == 'cmp':
            j, name = a
            node.ops[j] = getattr(ast, name)()
        elif k == 'boolop':
            node.op = ast.Or() if isinstance(node.op, ast.And) else ast.And()
        elif k == 'booldrop':
            vals = [v for n, v in enumerate(node.values) if n != a]
            node = vals[0] if len(vals) == 1 else ast.BoolOp(op=node.op, values=vals)
        elif k == 'unary':
            node = node.operand
        elif k == 'int':
            node = ast.Constant(value=a)
        elif k in ('raise', 'require'):
            node = ast.Pass()
        elif k == 'ifneg':
            node.test = ast.UnaryOp(op=ast.Not(), operand=node.test)
        return node


def mutants(text):
    tree = ast.parse(text)
    v = Sites()
    v.visit(tree)
    seen = {ast.unparse(tree)}
    for site in v.sites:
        t = copy.deepcopy(tree)
        ap = Apply(site)
        t = ap.visit(t)
        assert ap.done, site
        ast.fix_missing_locations(t)
        src = ast.unparse(t)
        if src in seen:
            continue
        seen.add(src)
        yield site, src


def locate(text, site):
    """Line of the mutated node in the original file."""
    tree = ast.parse(text)
    i = 0
    found = []

    class V(ast.NodeVisitor):
        def generic_visit(self, node):
            nonlocal i
            i += 1
            if i == site[1]:
                found.append(getattr(node, 'lineno', None))
            super().generic_visit(node)
    V().visit(tree)
    return found[0] if found else None


def main():
    root = Path(sys.argv[1]).resolve()
    out = Path(sys.argv[2])
    packet = root / PACKET
    fname = TARGETS[0]
    target = packet / fname
    original = target.read_text()

    def run_all():
        res = {}
        for mode in ('normal', 'optimized'):
            flags = [sys.executable, '-B'] + (['-O'] if mode == 'optimized' else []) + ['-S']
            parts = {}
            ok = True
            for cmd in ('check_exact.py', 'test_exact.py'):
                try:
                    p = subprocess.run(flags + [str(packet / cmd)] + (['-v'] if cmd == 'test_exact.py' else []), capture_output=True, text=True, timeout=120, cwd=root)
                    text = p.stdout + p.stderr
                    good = p.returncode == 0 and (('"verified_sources": 10' in p.stdout) if cmd == 'check_exact.py' else ('\nOK' in text))
                    failed = sorted({l.split(' ', 1)[1].split(' (')[0] for l in text.splitlines() if l.startswith(('FAIL: ', 'ERROR: '))})
                    parts[cmd] = {'rc': p.returncode, 'ok': good, 'failed': failed,
                                  'tail': text.strip().splitlines()[-1][:200] if text.strip() else ''}
                except subprocess.TimeoutExpired:
                    parts[cmd] = {'rc': 'TIMEOUT', 'ok': False, 'failed': [], 'tail': 'timeout'}
                ok = ok and parts[cmd]['ok']
            res[mode] = {'ok': ok, 'parts': parts}
        return res

    records = []
    try:
        base = run_all()
        records.append({'file': None, 'site': 'baseline', 'result': base})
        target.write_text(ast.unparse(ast.parse(original)) + '\n')
        records.append({'file': fname, 'site': 'baseline-unparsed', 'result': run_all()})
        for site, src in mutants(original):
            target.write_text(src + '\n')
            res = run_all()
            killed = [not res[m]['ok'] for m in ('normal', 'optimized')]
            records.append({'file': fname, 'site': [site[0], site[1], site[2]], 'line': locate(original, site),
                            'verdict': 'KILLED' if all(killed) else ('SURVIVED' if not any(killed) else 'MIXED'),
                            'result': res, 'source': src})
    finally:
        target.write_text(original)
    out.write_text(json.dumps(records, indent=1))
    summary = {}
    for r in records[2:]:
        summary[r['verdict']] = summary.get(r['verdict'], 0) + 1
    print(json.dumps({'baseline': {m: base[m]['ok'] for m in base},
                      'unparsed_baseline_ok': all(records[1]['result'][m]['ok'] for m in records[1]['result']),
                      'summary': summary}))


if __name__ == '__main__':
    main()
