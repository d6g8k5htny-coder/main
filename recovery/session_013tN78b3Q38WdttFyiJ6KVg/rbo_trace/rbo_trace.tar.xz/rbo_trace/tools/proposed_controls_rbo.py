"""Run proposed extra controls against the original check_exact.py and every census survivor (Claude 54).

usage: python3 -B -I proposed_controls_rbo.py CENSUS_JSON PATH_TO_check_exact.py
Each control is a short assertion that the original passes. A survivor is "closed" by a control that it fails.
A separate demo (K-BS1, K-BS2, not a control) documents the backslash literal: the original accepts a path with
one backslash, and the literal in the packet source is two characters long.
"""
import ast, hashlib, importlib.util, json, os, sys, tempfile
from fractions import Fraction as F
from pathlib import Path

census, original = sys.argv[1], sys.argv[2]
records = json.load(open(census))
work = tempfile.mkdtemp(prefix='rbo-controls-')


def load(src, tag):
    path = os.path.join(work, tag + '.py')
    with open(path, 'w') as fh:
        fh.write(src + '\n')
    spec = importlib.util.spec_from_file_location(tag, path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


class Guard(dict):
    pass


def ok(fn):
    try:
        return bool(fn())
    except Exception:
        return False


def raises_value_error(fn):
    try:
        fn()
    except ValueError:
        return True
    except Exception:
        return False
    return False


def P(p, x, z):
    k, s, a, b, q = p
    return 2*k*x**3 - 3*k*x/2 - k/2 + s*z**2/2 + a*(x**2 - F(1, 4))*z/2 + b*x*z**2/2 + q*z**3/6


def fd_hess(p, x, z, h=F(1, 4)):
    f = lambda dx, dz: P(p, x + dx, z + dz)
    return ((f(h, 0) - 2*f(0, 0) + f(-h, 0)) / (h*h),
            (f(h, h) - f(h, -h) - f(-h, h) + f(-h, -h)) / (4*h*h),
            (f(0, h) - 2*f(0, 0) + f(0, -h)) / (h*h))


def entry_for(root, rel):
    data = (root / rel).read_bytes() if (root / rel).is_file() else b''
    return {'local_path': rel, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}


def tree():
    root = Path(tempfile.mkdtemp(prefix='rbo-tree-', dir=work)).resolve()
    (root / 'a').mkdir()
    (root / 'a' / 'b').write_bytes(b'abc')
    (root / 'x').write_bytes(b'abc')
    (root / 'dir').mkdir()
    (root / 'x\\\\y').write_bytes(b'abc')      # a file whose name holds two backslashes
    return root


def controls(m):
    out = Guard()
    pars = (F(5, 7), F(-2), F(2), F(3), F(5))
    pt = (F(-1, 3), F(2, 5))
    out['K1_cubic_hessian_k_ne_1_matches_P'] = ok(lambda: tuple(m.cubic_hessian(pars, pt)) == fd_hess(pars, *pt))
    out['K2_zero_probability_atom_accepted'] = ok(lambda: m.count_statistics({0: F(0), 1: F(1)}) == (1, 1, 0, 0, 0))
    out['K3_non_dict_count_law_rejected'] = raises_value_error(lambda: m.count_statistics([0]))
    out['K4_negative_field_probability_rejected'] = raises_value_error(
        lambda: m.mark_statistics([(F(-1, 2), ()), (F(3, 2), (F(1),))]))
    out['K5_zero_probability_field_accepted'] = ok(lambda: m.mark_statistics([(F(0), ()), (F(1), (F(1),))]) == (1, 1, 1, 0))
    out['K6_field_probabilities_must_sum_to_1'] = raises_value_error(lambda: m.mark_statistics([(F(1, 2), ())]))
    out['K7_float_probability_rejected'] = raises_value_error(lambda: m.count_statistics({0: 0.5, 1: 0.5}))
    bad = [(F(-1, 2), F(1), F(0), F(0)), (F(1), F(0), F(0), F(0)), (F(1), F(-1, 2), F(0), F(0)),
           (F(1), F(1), F(-1, 2), F(0)), (F(1), F(1), F(0), F(-1, 2))]
    out['K8_invalid_annulus_parameters_rejected'] = all(raises_value_error(lambda b=b: m.annulus_budget(*b)) for b in bad)
    out['K8b_zero_C_delta_eps_accepted'] = ok(lambda: m.annulus_budget(F(0), F(2), F(0), F(0)) == 0)
    root = tree()
    good = entry_for(root, 'x')
    m.verify_entry(root, good)
    out['K9_non_string_path_rejected'] = raises_value_error(lambda: m.verify_entry(root, dict(good, local_path=5)))
    out['K9b_dot_component_rejected'] = raises_value_error(lambda: m.verify_entry(root, entry_for(root, 'a/b') | {'local_path': 'a/./b'}))
    out['K9c_dotdot_inside_root_rejected'] = raises_value_error(lambda: m.verify_entry(root, entry_for(root, 'a/b') | {'local_path': 'a/../a/b'}))
    out['K9d_absolute_path_inside_root_rejected'] = raises_value_error(lambda: m.verify_entry(root, dict(good, local_path=str(root / 'x'))))
    out['K9e_directory_rejected'] = raises_value_error(lambda: m.verify_entry(root, entry_for(root, 'dir')))
    out['K9f_double_backslash_rejected'] = raises_value_error(lambda: m.verify_entry(root, entry_for(root, 'x\\\\y')))
    out['K10_float_byte_count_rejected'] = raises_value_error(lambda: m.verify_entry(root, dict(good, bytes=3.0)))
    out['K10b_wrong_int_byte_count_rejected'] = raises_value_error(lambda: m.verify_entry(root, dict(good, bytes=4)))
    # contained_file does not resolve its own root; the packet's callers pass a resolved one. Called directly with a
    # relative root, the containment conjunct at L25 is the only guard that rejects.
    rel_root = Path(os.path.relpath(root))
    out['K11_contained_file_relative_root_rejected'] = raises_value_error(lambda: m.contained_file(rel_root, 'x'))
    return out


def backslash_demo(m):
    root = tree()
    (root / 'x\\y').write_bytes(b'abc')
    try:
        m.verify_entry(root, entry_for(root, 'x\\y'))
        one = 'accepted'
    except ValueError:
        one = 'rejected'
    # the backslash literal as the packet's own source spells it: the string constant compared with `not in relative`
    tree_ = ast.parse(open(original).read())
    lits = [n.left.value for n in ast.walk(tree_) if isinstance(n, ast.Compare) and isinstance(n.left, ast.Constant)
            and isinstance(n.left.value, str) and '\\' in n.left.value and any(isinstance(o, ast.NotIn) for o in n.ops)]
    return {'K-BS1_one_backslash_path': one, 'K-BS2_packet_backslash_literal_lengths': [len(v) for v in lits]}


orig = load(open(original).read(), 'original')
base = controls(orig)
assert all(base.values()), base
report = {'original': base, 'backslash': backslash_demo(orig), 'survivors': []}
closed = 0
for i, x in enumerate([r for r in records[2:] if r['verdict'] == 'SURVIVED']):
    try:
        res = controls(load(x['source'], 'm%d' % i))
        failed = sorted(k for k, v in res.items() if not v)
    except Exception as e:  # a control that crashes the mutant also closes it
        failed = ['crash:' + type(e).__name__]
    closed += bool(failed)
    report['survivors'].append({'line': x['line'], 'site': x['site'], 'closed_by': failed})
report['survivor_count'] = len(report['survivors'])
report['closed_count'] = closed
print(json.dumps(report, indent=1))
