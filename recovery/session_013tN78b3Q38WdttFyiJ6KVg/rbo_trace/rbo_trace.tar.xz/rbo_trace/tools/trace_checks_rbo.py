"""Trace-side exact checks for Math- replacement_bar_occurrence_20261001 (Claude 54).

usage: python3 -B -I trace_checks_rbo.py MATH_WORKTREE
Not part of the packet; standard library only; does not import check_exact.py. Each check is a finite rational
computation (or a Git object read) for a PROOF.md / GLOBAL.md step that the packet's tests take as given or do
not exercise. Randomized checks are evidence for identities, not proofs.
"""
from fractions import Fraction as F
import hashlib
import json
import random
import subprocess
import sys
from pathlib import Path

ROOT = Path(sys.argv[1]).resolve()
PACKET = 'frontiers/replacement_bar_occurrence_20261001'
rng = random.Random(20261026)
results = {}


def rnd(lo=-30, hi=30, den=9):
    return F(rng.randint(lo, hi), rng.randint(1, den))


# ---------------------------------------------------------------- the cubic of GLOBAL §2 (L61-66), original coords
def P(p, x, z):
    k, s, a, b, q = p
    return 2*k*x**3 - 3*k*x/2 - k/2 + s*z**2/2 + a*(x**2 - F(1, 4))*z/2 + b*x*z**2/2 + q*z**3/6


def grad(p, x, z):
    k, s, a, b, q = p
    return (6*k*x**2 - 3*k/2 + a*x*z + b*z**2/2, s*z + a*(x**2 - F(1, 4))/2 + b*x*z + q*z**2/2)


def fd_grad(p, x, z, h=F(1, 4)):
    # 5-point central stencil, exact for polynomials of degree <= 4
    f = lambda dx, dz: P(p, x + dx, z + dz)
    return ((-f(2*h, 0) + 8*f(h, 0) - 8*f(-h, 0) + f(-2*h, 0)) / (12*h),
            (-f(0, 2*h) + 8*f(0, h) - 8*f(0, -h) + f(0, -2*h)) / (12*h))


def fd_hess(p, x, z, h=F(1, 4)):
    # central second differences are exact for a cubic
    f = lambda dx, dz: P(p, x + dx, z + dz)
    fxx = (f(h, 0) - 2*f(0, 0) + f(-h, 0)) / (h*h)
    fzz = (f(0, h) - 2*f(0, 0) + f(0, -h)) / (h*h)
    fxz = (f(h, h) - f(h, -h) - f(-h, h) + f(-h, -h)) / (4*h*h)
    return fxx, fxz, fzz


def shear(p):
    k, s, a, b, q = p
    return b - a*a/(12*k), (q - a*b/(4*k) + a**3/(72*k*k))/2


def H3(p, x, z):
    k, s, a, b, q = p
    return 2*k*x**3 + a*x*x*z/2 + b*x*z*z/2 + q*z**3/6


# R0. The hand-coded gradient above equals exact finite differences of P (GLOBAL L61-62) at 300 random points.
results['R0_grad_matches_P'] = all(
    grad(p, x, z) == fd_grad(p, x, z)
    for p, x, z in [((F(rng.randint(1, 40), rng.randint(1, 7)), rnd(), rnd(), rnd(), rnd()), rnd(), rnd()) for _ in range(300)])

# R1. GLOBAL L74-78: after u = X + aZ/(12k), H3 = 2k u^3 + (Bs/2) u Z^2 + (Ds/3) Z^3 (random rational points).
ok = True
for _ in range(300):
    p = (F(rng.randint(1, 40), rng.randint(1, 7)), rnd(), rnd(), rnd(), rnd())
    x, z = rnd(), rnd()
    Bs, Ds = shear(p)
    u = x + p[2]*z/(12*p[0])
    ok &= H3(p, x, z) == 2*p[0]*u**3 + Bs*u*z*z/2 + Ds*z**3/3
results['R1_sheared_leading_cubic'] = ok

# R2. GLOBAL L105-113 (Lemma 1): substituting the line D_s Z = -(s + B_s u) of (2) into 2 D_s^2 times the conic
#     6k(u^2 - 1/4) + (B_s/2) Z^2 gives exactly (12k Ds^2 + Bs^3) u^2 + 2 Bs^2 s u + Bs s^2 - 3k Ds^2.
ok = True
for _ in range(300):
    k, s, Bs, Ds, u = F(rng.randint(1, 40), rng.randint(1, 7)), rnd(), rnd(), rnd() or F(1), rnd()
    DZ = -(s + Bs*u)
    lhs = 2*Ds*Ds*6*k*(u*u - F(1, 4)) + Bs*DZ*DZ
    ok &= lhs == (12*k*Ds*Ds + Bs**3)*u*u + 2*Bs*Bs*s*u + Bs*s*s - 3*k*Ds*Ds
results['R2_lemma1_elimination'] = ok


# R3. Lemma 1's conclusions on random typed cubics built to have rational extra roots: choose an extra root (u1, Z1),
#     solve the conic for Bs and the line for Ds, choose typed s and a free shear a, and recover (beta, q). Then the
#     second extra root comes from Vieta on the elimination quadratic. Check: both extras are critical points of P,
#     the gradient of P vanishes at the pins, M0 is a strict maximum and S0 a saddle, no extra root has a
#     negative-definite Hessian, and (3) holds: det Hess = -3k(Bs + 4su), H Z^2 = 3k(Bs + 4su)^2.
def build(rng):
    while True:
        k = F(rng.randint(1, 12), rng.randint(1, 5))
        u1, Z1 = rnd(-12, 12, 6), rnd(-12, 12, 6)
        if Z1 == 0 or u1 * u1 == F(1, 4):
            continue
        Bs = -12*k*(u1*u1 - F(1, 4)) / (Z1*Z1)
        s = -abs(Bs)/2 - F(rng.randint(1, 30), rng.randint(1, 6))
        Ds = -(s + Bs*u1) / Z1
        a = rnd(-20, 20, 4)
        b = Bs + a*a/(12*k)
        q = 2*Ds + a*b/(4*k) - a**3/(72*k*k)
        Delta = 12*k*Ds*Ds + Bs**3
        Hval = Delta - 4*Bs*s*s
        if Ds == 0 or Bs == 0 or Delta == 0 or Hval == 0:
            continue
        u2 = -2*Bs*Bs*s/Delta - u1
        Z2 = -(s + Bs*u2) / Ds
        return (k, s, a, b, q), [(u1, Z1), (u2, Z2)], Hval


# R12 (used by R3). The gradient of P factors in sheared coordinates (u, Z), u = X + aZ/(12k):
#     dP/du = 6k(u^2 - 1/4) + (Bs/2) Z^2,   dP/dZ|_u = Z (s + Bs u + Ds Z).
#     With d/du = d/dX and d/dZ|_u = d/dZ|_X - (a/(12k)) d/dX, both differences are polynomials of degree <= 2 in each
#     of u and Z, so vanishing on the 3 x 3 grid {0, 1, 2}^2 proves them identically zero for that parameter tuple.
#     Consequence: every critical point has Z = 0 (then u = +-1/2, the pins) or satisfies the line and conic (2).
def sheared_gradient_factors(p, Ds_shift=0):
    k, s, a, b, q = p
    Bs, Ds = shear(p)
    Ds += Ds_shift
    for u in (F(0), F(1), F(2)):
        for Z in (F(0), F(1), F(2)):
            X = u - a*Z/(12*k)
            gX, gZ = fd_grad(p, X, Z)
            if gX != 6*k*(u*u - F(1, 4)) + Bs*Z*Z/2 or gZ - a/(12*k)*gX != Z*(s + Bs*u + Ds*Z):
                return False
    return True


tuples12 = [(F(rng.randint(1, 40), rng.randint(1, 7)), rnd(), rnd(), rnd(), rnd()) for _ in range(300)]
results['R12_sheared_gradient_factorization'] = all(sheared_gradient_factors(p) for p in tuples12)
results['R12_wrong_Ds_rejected'] = not any(sheared_gradient_factors(p, Ds_shift=F(1)) for p in tuples12)

ok_roots = ok_pins = ok_no_second_max = ok_r13 = ok_complete = True
extra_types = set()
for _ in range(300):
    p, extras_su, Hval = build(rng)
    k, s, a, b, q = p
    Bs, Ds = shear(p)
    for xx, zz in [(F(-1, 2), F(0)), (F(1, 2), F(0))]:
        ok_roots &= fd_grad(p, xx, zz) == (0, 0)
    # complete critical set: by R12 every critical point is a pin or solves (2); with Ds != 0 the line fixes Z from u,
    # and by R2 the conic then becomes Q(u) = Delta u^2 + 2 Bs^2 s u + Bs s^2 - 3k Ds^2 = 0. Q has exactly the roots
    # u1, u2 (coefficient match with Delta (u - u1)(u - u2)), so the four listed points are all critical points.
    Delta = 12*k*Ds*Ds + Bs**3
    (u1, _), (u2, _) = extras_su
    # R2's identity on this tuple, exactly: 2 Ds^2 * conic(u, Z(u)) - Q(u) has degree <= 2 in u, so three values suffice
    conic_on_line = lambda uu: 2*Ds*Ds*(6*k*(uu*uu - F(1, 4)) + Bs*(-(s + Bs*uu)/Ds)**2/2)
    Q = lambda uu: Delta*uu*uu + 2*Bs*Bs*s*uu + Bs*s*s - 3*k*Ds*Ds
    # the linear coefficient matches by the Vieta construction of u2; the constant term is the computed check Q(u1) = 0
    ok_complete &= (sheared_gradient_factors(p) and Delta != 0 and u1 != u2
                    and all(conic_on_line(F(uu)) == Q(F(uu)) for uu in (0, 1, 2))
                    and Delta*u1*u2 == Bs*s*s - 3*k*Ds*Ds)
    hm, hs = fd_hess(p, F(-1, 2), F(0)), fd_hess(p, F(1, 2), F(0))
    detm, dets = hm[0]*hm[2] - hm[1]**2, hs[0]*hs[2] - hs[1]**2
    ok_pins &= detm > 0 and hm[0] < 0 and dets < 0 and detm == 3*k*(Bs - 2*s) and dets == 3*k*(Bs + 2*s)
    for u, Z in extras_su:
        x = u - a*Z/(12*k)
        ok_roots &= fd_grad(p, x, Z) == (0, 0)
        hxx, hxz, hzz = fd_hess(p, x, Z)
        det = hxx*hzz - hxz*hxz
        negdef = det > 0 and hxx < 0
        ok_no_second_max &= not negdef
        extra_types.add('saddle' if det < 0 else ('min' if det > 0 else 'degenerate'))
        ok_r13 &= det == -3*k*(Bs + 4*s*u) and Hval*Z*Z == 3*k*(Bs + 4*s*u)**2
results['R3_lemma1_extras_are_critical'] = ok_roots
results['R3_lemma1_complete_critical_set_is_the_four_points'] = ok_complete
results['R3_lemma1_pins_max_and_saddle_with_3k_Bs_pm_2s'] = ok_pins
results['R3_lemma1_no_second_negative_definite_root'] = ok_no_second_max
results['R3_lemma1_identity_3'] = ok_r13
results['R3_extra_root_types_seen'] = sorted(extra_types)


# R4. Lemma 1's final step (GLOBAL L132-140): for a polynomial of degree <= 3 the Hessian is affine, so
#     (grad P(q) - grad P(p)).v = int_0^1 v^T Hess P(p + tv) v dt, and the integrand is affine in t, so the
#     midpoint rule is exact. Checked on random general bivariate cubics (all ten coefficients random).
def gen_cubic(rng):
    return [rnd() for _ in range(10)]


def cubic_val(c, x, z):
    mons = [1, x, z, x*x, x*z, z*z, x**3, x*x*z, x*z*z, z**3]
    return sum(ci*m for ci, m in zip(c, mons))


def cubic_grad(c, x, z):
    return (c[1] + 2*c[3]*x + c[4]*z + 3*c[6]*x*x + 2*c[7]*x*z + c[8]*z*z,
            c[2] + c[4]*x + 2*c[5]*z + c[7]*x*x + 2*c[8]*x*z + 3*c[9]*z*z)


def cubic_hess(c, x, z):
    return (2*c[3] + 6*c[6]*x + 2*c[7]*z, c[4] + 2*c[7]*x + 2*c[8]*z, 2*c[5] + 2*c[8]*x + 6*c[9]*z)


ok = True
for _ in range(300):
    c = gen_cubic(rng)
    p0, q0 = (rnd(), rnd()), (rnd(), rnd())
    v = (q0[0] - p0[0], q0[1] - p0[1])
    gp, gq = cubic_grad(c, *p0), cubic_grad(c, *q0)
    lhs = (gq[0] - gp[0])*v[0] + (gq[1] - gp[1])*v[1]
    mid = ((p0[0] + q0[0])/2, (p0[1] + q0[1])/2)
    hxx, hxz, hzz = cubic_hess(c, *mid)
    ok &= lhs == hxx*v[0]**2 + 2*hxz*v[0]*v[1] + hzz*v[1]**2
    # the gradient and Hessian formulas themselves, against exact finite differences of the value
    f = lambda dx, dz: cubic_val(c, p0[0] + dx, p0[1] + dz)
    h = F(1, 4)
    ok &= cubic_hess(c, *p0) == ((f(h, 0) - 2*f(0, 0) + f(-h, 0))/(h*h),
                                 (f(h, h) - f(h, -h) - f(-h, h) + f(-h, -h))/(4*h*h),
                                 (f(0, h) - 2*f(0, 0) + f(0, -h))/(h*h))
results['R4_affine_hessian_segment_identity'] = ok


# R5. Lemma 2 (GLOBAL L145-153): in sheared coordinates a homogeneous critical direction with Z = 1 needs
#     6k u^2 + Bs/2 = 0 and Bs u + Ds = 0; with Bs != 0 this forces 12k Ds^2 + Bs^3 = 0. Check the elimination on
#     random data, and that whenever Delta = 0 is constructed there is an exact nonzero gradient zero of H3.
ok = True
for _ in range(300):
    k, Bs, Ds = F(rng.randint(1, 40), rng.randint(1, 7)), rnd() or F(1), rnd()
    u = -Ds/Bs
    ok &= (6*k*u*u + Bs/2) * 2*Bs*Bs == 12*k*Ds*Ds + Bs**3
deg_found = 0
for _ in range(300):
    k = F(rng.randint(1, 12), rng.randint(1, 5))
    w = rnd(-12, 12, 4) or F(1)
    Bs = -12*k*w*w          # Delta = 12k Ds^2 + Bs^3 = 0 with Ds = Bs*w... choose Ds so that Delta = 0
    Ds = -Bs*w              # then u = -Ds/Bs = w and 6k u^2 + Bs/2 = 6k w^2 - 6k w^2 = 0
    if 12*k*Ds*Ds + Bs**3 != 0:
        continue
    a = rnd()
    b = Bs + a*a/(12*k)
    q = 2*Ds + a*b/(4*k) - a**3/(72*k*k)
    p = (k, F(-1), a, b, q)
    X, Z = w - a/(12*k), F(1)
    gx = 6*k*X*X + a*X*Z + b*Z*Z/2
    gz = a*X*X/2 + b*X*Z + q*Z*Z/2
    deg_found += (gx, gz) == (0, 0)
results['R5_lemma2_elimination'] = ok
results['R5_lemma2_Delta_zero_gives_gradient_zero_count'] = deg_found
results['R5_lemma2_Delta_zero_gives_gradient_zero'] = deg_found > 0


# R6. Lemma 5 (GLOBAL L272-288): on R r <= |x| <= delta, the error bound (8) divided by |x|^2 is at most
#     C/R^2 + C/R + eps + C delta. Check on random rational radii; then, with R, delta, eps chosen as in the proof
#     (C/R^2 + C/R < c/4, C delta < c/4, eps < c/4), check the total is below 3c/4 and the margin c/4 remains.
ok = True
for _ in range(300):
    C, R, delta, eps = F(rng.randint(1, 30), 7), F(rng.randint(2, 40), 3), F(rng.randint(1, 20), 50), F(rng.randint(0, 20), 100)
    r = F(rng.randint(1, 50), 1000) * delta / R
    if not R*r <= delta:
        continue
    for _ in range(5):
        x = R*r + (delta - R*r) * F(rng.randint(0, 100), 100)
        err = C*r*r + C*r*x + eps*x*x + C*x**3
        ok &= err / (x*x) <= C/R**2 + C/R + eps + C*delta
ok_choice = True
for _ in range(200):
    C, c = F(rng.randint(1, 30), 7), F(rng.randint(1, 30), 11)
    R = F(1)
    while C/R**2 + C/R >= c/4:
        R *= 2
    delta = c/(8*C)
    eps = c/8
    ok_choice &= C/R**2 + C/R + eps + C*delta < 3*c/4 and c - (C/R**2 + C/R + eps + C*delta) > c/4
results['R6_lemma5_budget_bounds_error'] = ok
results['R6_lemma5_choice_order_leaves_c_over_4'] = ok_choice


# R7. (O13) for n = 0..200, and the (O5) total-variation bound on random finite count laws:
#     TV(Law(N | N > 0), delta_1) = P(N >= 2 | N > 0) <= E[N 1{N >= 2}] / (2 P(N > 0)).
ok13 = all(0 <= max(n - 1, 0) <= n*(n >= 2) and n - (n > 0) == max(n - 1, 0) and 2*(n >= 2) <= n*(n >= 2)
           for n in range(201))
ok_tv = True
for _ in range(300):
    support = rng.sample(range(0, 9), rng.randint(2, 6))
    w = [F(rng.randint(1, 20)) for _ in support]
    law = {n: wi/sum(w) for n, wi in zip(support, w)}
    pos = sum(p for n, p in law.items() if n > 0)
    if pos == 0:
        continue
    cond = {n: p/pos for n, p in law.items() if n > 0}
    tv = (sum(abs(cond.get(n, 0) - (1 if n == 1 else 0)) for n in set(cond) | {1})) / 2
    multi = sum(n*p for n, p in law.items() if n >= 2)
    ok_tv &= tv == sum(p for n, p in cond.items() if n >= 2) and tv <= multi/(2*pos)
results['R7_O13_inequalities'] = ok13
results['R7_O5_total_variation_bound'] = ok_tv


# R8. (O14) pointwise: |S - 1{N > 0} S/N| <= ||Phi||_inf (N - 1)_+ for signed marks, N = 0..12.
ok = True
for _ in range(500):
    n = rng.randint(0, 12)
    marks = [rnd() for _ in range(n)]
    bound = max([abs(m) for m in marks], default=F(0))
    S = sum(marks, F(0))
    ok &= abs(S - (S/n if n else 0)) <= bound*max(n - 1, 0)
results['R8_O14_pointwise_bound'] = ok


# R9. (O8) with the global mark H = 1{N >= 2}: on random finite planar configurations (as in the URB trace's U5),
#     N*H equals the sum over admissible rejected pairs of H/D(M); and with any whole-field mark the identity holds
#     because H does not depend on the pair. A count that drops the partner exclusion breaks it somewhere.
def config(seed):
    g = random.Random(seed)
    maxima = [((F(g.randint(-12, 12), 4), F(g.randint(-12, 12), 4)), F(g.randint(1, 40), 8))
              for _ in range(g.randint(2, 7))]
    saddles = [((F(g.randint(-12, 12), 4), F(g.randint(-12, 12), 4)), F(g.randint(-40, 20), 8))
               for _ in range(g.randint(3, 12))]
    partner = [g.randrange(len(saddles)) for _ in maxima]
    return maxima, saddles, partner


def admissible(M, S, is_partner, c0=F(1, 2), C0=F(5, 2), klo=F(1, 50), khi=F(4)):
    (mp, fm), (sp, fs) = M, S
    d2 = (mp[0] - sp[0])**2 + (mp[1] - sp[1])**2
    gap = fm - fs
    return (not is_partner and gap > 0 and d2 > 0 and c0*c0 <= d2 <= C0*C0
            and klo*klo*d2**3 <= gap*gap <= khi*khi*d2**3)


ok, multi_seen, breaks = True, 0, 0
for seed in range(400):
    maxima, saddles, partner = config(seed)
    D = [sum(admissible(M, S, j == partner[i]) for j, S in enumerate(saddles)) for i, M in enumerate(maxima)]
    N = sum(d > 0 for d in D)
    Hm = 1 if N >= 2 else 0
    multi_seen += Hm
    pairs = [(i, j) for j, S in enumerate(saddles) for i, M in enumerate(maxima) if admissible(M, S, j == partner[i])]
    ok &= N*Hm == sum(F(Hm, D[i]) for i, j in pairs) and N == sum(F(1, D[i]) for i, j in pairs)
    Dbad = [sum(admissible(M, S, False) for S in saddles) for M in maxima]
    breaks += N != sum(F(1, Dbad[i]) for i, j in pairs)
results['R9_O8_global_mark_reciprocal_identity'] = ok and multi_seen > 0 and breaks > 0
results['R9_configs_with_N_ge_2'] = multi_seen
results['R9_configs_where_partnerless_count_breaks_it'] = breaks


# R10. Source pins that check_exact.py declares but does not read. SOURCES.json gives, per entry, a historical
#      `commit` and `path` (PROOF L65-72). check_exact.py verifies only the working-tree bytes at `local_path`.
#      Here each entry's blob is read at its declared commit and path with Git, and compared to the manifest blob
#      and to the working-tree file.
def git(*args):
    return subprocess.run(['git', '-C', str(ROOT), '--no-replace-objects'] + list(args),
                          capture_output=True, text=True, check=True).stdout.strip()


manifest = json.loads((ROOT / PACKET / 'SOURCES.json').read_bytes())
pins = {}
for e in manifest['sources']:
    hist = git('rev-parse', e['commit'] + ':' + e['path'])
    data = (ROOT / e['local_path']).read_bytes()
    local = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    pins[e['key']] = hist == e['blob'] == local
results['R10_historical_pins_match'] = pins
results['R10_all_pins_match'] = all(pins.values())
results['R10_manifest_sha256'] = hashlib.sha256((ROOT / PACKET / 'SOURCES.json').read_bytes()).hexdigest()

# R11. (O12) radial substitution, computed: int_{c0 h}^{C0 h} r * r^3 dr = h^5 int_{c0}^{C0} t^4 dt, both by
#      Boole's rule (exact to degree 5), at nine rational (c0, C0, h); the packet's test only restates 1 + 3 + 1 = 5.
def boole(f, lo, hi):
    hh = (hi - lo) / 4
    return (hi - lo) / 90 * (7*f(lo) + 32*f(lo + hh) + 12*f(lo + 2*hh) + 32*f(lo + 3*hh) + 7*f(hi))


results['R11_O12_radial_substitution'] = all(
    boole(lambda r: r * r**3, c0*h, C0*h) == h**5 * boole(lambda t: t**4, c0, C0) == h**5 * (C0**5 - c0**5)/5
    for c0, C0 in [(F(1, 3), F(2)), (F(1, 2), F(7, 4)), (F(1), F(3))] for h in [F(1, 5), F(3, 7), F(1, 100)])

print(json.dumps(results, indent=1))
