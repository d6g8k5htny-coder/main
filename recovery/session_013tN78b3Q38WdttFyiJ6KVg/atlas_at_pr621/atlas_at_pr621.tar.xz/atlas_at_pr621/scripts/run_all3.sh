#!/bin/bash
# ATLAS-AT: run the listed RUN:TREE pairs sequentially, one stack at a time, then extract speech.
R=/tmp/claude-0/-home-user-main/d5c985ca-97e5-58d8-a9d4-1e0a19065a22/scratchpad/atlasat
for P in "$@"; do
  T=${P%%:*}; TREE=${P##*:}
  echo "$(date -u +%FT%TZ) start $T tree=$TREE" >> $R/evidence/run_all.log
  bash $R/scripts/stack3.sh $T $TREE >> $R/evidence/run_all.log 2>&1
  python3 -I $R/scripts/extract.py $R/evidence/$T >> $R/evidence/run_all.log 2>&1
  echo "$(date -u +%FT%TZ) done $T" >> $R/evidence/run_all.log
done
