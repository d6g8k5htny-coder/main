#!/usr/bin/python3 -I
# ATLAS-AT: per-task speech and pre-registered verdicts for one executor run.
# usage: summarize.py EVIDENCE_DIR   -> writes summary.json and summary.md in EVIDENCE_DIR
# Spoken = strings Orca handed to speech-dispatcher (SPEECH lines of steps-speech.txt, from orca-debug.txt).
# Verdict rule (fixed in pickup 388/6404030858): PASS = the required information was spoken; FAIL = the task was
# operated but the information was not spoken or was spoken wrongly; NOT_OBSERVED = capture or key delivery failed.
import json, os, re, sys
d = sys.argv[1]
txt = open(os.path.join(d, 'steps-speech.txt'), encoding='utf8').read()
blocks = []
for b in re.split(r'\n(?=#\d+ \[)', '\n' + txt):
    b = b.strip('\n')
    m = re.match(r'#(\d+) \[([^\]]+)\] (\S+)? ?\((.*)\) sent', b.split('\n')[0]) or re.match(r'#(\d+) \[([^\]]+)\] (\S+)', b)
    if not m:
        continue
    label = m.group(4) if m.lastindex and m.lastindex >= 4 else ''
    speech = [re.sub(r"^.*?\] '", '', l.strip())[:-1] for l in b.split('\n') if '[SPEECH sent' in l and 'sent-key' not in l]
    checks = [l.split('[DOM check]')[1].strip() for l in b.split('\n') if '[DOM check]' in l]
    caret = [l for l in b.split('\n') if '[DOM caret]' in l]
    blocks.append({'n': int(m.group(1)), 'kind': m.group(2), 'key': m.group(3), 'label': label or '', 'speech': speech,
                   'check': checks[0] if checks else None, 'caret': caret[0].split('[DOM caret]')[1].strip()[:160] if caret else None})
steps = [json.loads(l) for l in open(os.path.join(d, 'steps.jsonl'))]
probes = {s['label']: json.loads(s['value']) for s in steps if s.get('kind') == 'DOM-PROBE' and isinstance(s.get('value'), str)}
def sel(prefix):
    return [b for b in blocks if b['label'].startswith(prefix)]
def spoken(bs):
    return [s for b in bs for s in b['speech']]
def has(bs, *needles):
    return any(any(n in s for n in needles) for s in spoken(bs))  # case-sensitive on purpose
R = {}
# Load-time announcements (no keys): is the JS-written status text announced?
load = [b for b in blocks if b['kind'].startswith('HARNESS Page.navigate')]
R['L_atlas_status_update'] = {'spoken': [s for s in spoken(load) if 'Source snapshot' in s or 'Loading the current' in s],
                             'verdict': 'PASS' if has(load, 'Source snapshot 20') else 'FAIL',
                             'need': "'Source snapshot … nodes … edges' (the text JS writes into #atlas-status) announced during load"}
R['L_current_state_update'] = {'spoken': [s for s in spoken(load) if 'source observation' in s.lower()],
                              'verdict': 'PASS' if has(load, 'Verified source observation:') else 'FAIL',
                              'need': "'Verified source observation …' (the text JS writes into .current-state) announced during load"}
t1 = sel('T1 browse Down'); t1_on = [b for b in t1 if b['check'] == 'true' and b['key'] != 'KP_Enter']
t3 = [b for b in t1 if b['key'] == 'KP_Enter']
R['T1_browse'] = {'spoken': spoken(t1_on), 'verdict': ('PASS' if has(t1_on, 'Source snapshot 20') else 'FAIL') if t1_on else 'NOT_OBSERVED',
                  'need': 'the #atlas-status text spoken when the browse caret is on it'}
R['T3_where_am_i'] = {'spoken': spoken(t3), 'verdict': ('PASS' if has(t3, 'Source snapshot 20') else 'FAIL') if t3 else 'NOT_OBSERVED',
                      'need': 'the #atlas-status text spoken by basic Where Am I on it'}
t2a = sel('T2a Say All')
R['T2a_say_all'] = {'spoken': [s for s in spoken(t2a)][:8], 'verdict': ('PASS' if has(t2a, 'Source snapshot 20') else 'FAIL') if t2a else 'NOT_OBSERVED',
                    'need': 'the #atlas-status text spoken by Say All from the Atlas h1'}
t2b = [b for b in sel('T2b browse Down') if b['check'] == 'true' and b['key'] != 'KP_Enter']
t2bw = [b for b in sel('T2b browse Down') if b['key'] == 'KP_Enter']
t2bs = sel("T2b Say All")
R['T2b_current_state_browse'] = {'spoken': spoken(t2b), 'verdict': ('PASS' if has(t2b, 'source observation:') else 'FAIL') if t2b else 'NOT_OBSERVED',
                                 'need': 'the .current-state text spoken when the browse caret is on it'}
R['T2b_current_state_where_am_i'] = {'spoken': spoken(t2bw), 'verdict': ('PASS' if has(t2bw, 'source observation:') else 'FAIL') if t2bw else 'NOT_OBSERVED',
                                     'need': 'the .current-state text spoken by basic Where Am I'}
R['T2b_current_state_say_all'] = {'spoken': spoken(t2bs)[:6], 'verdict': ('PASS' if has(t2bs, 'source observation:') else 'FAIL') if t2bs else 'NOT_OBSERVED',
                                  'need': "the .current-state text spoken by Say All from 'Source observation'"}
t4f = [b for b in sel('T4 Tab to the View select') if b['check'] == 'true']; t4w = sel('T4 Where Am I'); t4p = sel('T4 open') + sel('T4 popup')
view = (probes.get('DOM texts after load') or {}).get('view') or 'graph'
vname = {'graph': 'Graph', 'list': 'List'}.get(view, view)
named = has(t4f + t4w, vname)
grayed = has(t4p, 'grayed')
R['T4_view_select'] = {'spoken': spoken(t4f + t4w + t4p), 'value_name_spoken': named, 'grayed_spoken': grayed,
                       'verdict': ('PASS' if (named and not grayed) else 'FAIL') if (t4f and t4w and t4p) else 'NOT_OBSERVED',
                       'need': f"the selected value name ('{vname}') on focus or Where Am I, and no option spoken as grayed while the select is enabled"}
t5 = sel('T5 type OPEN')
R['T5_atlas_search_update'] = {'spoken': [s for s in spoken(t5) if len(s) > 1], 'verdict': ('PASS' if has(t5, 'displayed') else 'FAIL') if t5 else 'NOT_OBSERVED',
                               'need': 'an announcement of the updated result count after typing',
                               'dom_after': {k: (probes.get('DOM texts after T5') or {}).get(k) for k in ('atlas-count', 'atlas-space-status', 'atlas-status')}}
t6 = sel('T6 type')
eq_after = (probes.get('DOM texts after T6') or {}).get('equation-count')
eq_load = (probes.get('DOM texts after load') or {}).get('equation-count')
valid6 = eq_after is not None and eq_after != eq_load
R['T6_equation_count'] = {'spoken': [s for s in spoken(t6) if len(s) > 1],
                          'verdict': ('PASS' if has(t6, 'matching excerpts') else 'FAIL') if (t6 and valid6) else 'NOT_OBSERVED',
                          'need': 'an announcement of the updated #equation-count after typing', 'dom_before': eq_load, 'dom_after': eq_after,
                          'note': '' if valid6 else 'the typed term did not change #equation-count, so this run does not test the announcement'}
t7 = sel('T7 turn optional 3D on')
R['T7_3d_status'] = {'spoken': spoken(t7), 'verdict': ('PASS' if has(t7, '3D ·', 'Loading optional 3D', 'Use Graph or List') else 'FAIL') if t7 else 'NOT_OBSERVED',
                     'need': 'the #atlas-space-status text after turning 3D on', 'dom_after': (probes.get('DOM texts after 3D on') or {}).get('atlas-space-status')}
t7off = sel('T7 turn optional 3D off')
R['T7_3d_off'] = {'spoken': spoken(t7off), 'dom_after': (probes.get('DOM texts after 3D off') or {}).get('atlas-space-status'), 'verdict': 'INFO'}
out = {'run': os.path.basename(d.rstrip('/')), 'tree': open(os.path.join(d, 'tree.txt')).read().strip() if os.path.exists(os.path.join(d, 'tree.txt')) else None,
       'results': R, 'probes': probes}
json.dump(out, open(os.path.join(d, 'summary.json'), 'w'), indent=1, ensure_ascii=True)
with open(os.path.join(d, 'summary.md'), 'w', encoding='utf8') as f:
    f.write(f"# {out['run']} (tree {out['tree']})\n\n| Task | Verdict | Spoken (Orca to speech-dispatcher) |\n|---|---|---|\n")
    for k, v in R.items():
        f.write(f"| {k} | {v['verdict']} | {' / '.join(repr(s)[:120] for s in v['spoken'][:6])} |\n")
print(out['run'], {k: v['verdict'] for k, v in R.items()})
