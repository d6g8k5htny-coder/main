#!/usr/bin/python3.12 -I
# ISOLATE: read-only AT-SPI snapshot of the Chromium document (AX class evidence, separate from DOM/CDP).
# usage: atspi_probe.py [TITLE_SUBSTRING]
# Prints one JSON object: time, focused object, and every node of the document web subtree with
# role, name, states, text (if any) and selected object attributes (tag, xml-roles, live, container-live).
# It never calls an action, never sets a value, caret or selection, and never grabs focus.
import sys, json, time, gi
gi.require_version('Atspi', '2.0')
from gi.repository import Atspi

want = sys.argv[1] if len(sys.argv) > 1 else ''
t0 = time.time()
KEEP_ATTRS = ('tag', 'xml-roles', 'live', 'container-live', 'atomic', 'container-atomic', 'id', 'display')


def states(o):
    try:
        return sorted(s.value_nick for s in o.get_state_set().get_states())
    except Exception as e:
        return ['ERR:' + str(e)]


def text(o):
    try:
        ti = o.get_text_iface()
        if ti is None:
            return None
        n = Atspi.Text.get_character_count(o)
        return Atspi.Text.get_text(o, 0, min(n, 300))
    except Exception:
        return None


def attrs(o):
    try:
        a = o.get_attributes() or {}
        return {k: v for k, v in a.items() if k in KEEP_ATTRS}
    except Exception:
        return {}


def desc(o, depth=None):
    d = {'role': o.get_role_name(), 'name': o.get_name()}
    if depth is not None:
        d['depth'] = depth
    d['states'] = states(o)
    tx = text(o)
    if tx is not None:
        d['text'] = tx.replace('￼', '[obj]')
    a = attrs(o)
    if a:
        d['attrs'] = a
    try:
        d['children'] = o.get_child_count()
    except Exception:
        pass
    return d


def find_docs(root, limit=4000):
    docs, queue, seen = [], [root], 0
    while queue and seen < limit:
        o = queue.pop(0); seen += 1
        try:
            r = o.get_role()
        except Exception:
            continue
        if r == Atspi.Role.DOCUMENT_WEB:
            docs.append(o); continue
        try:
            for i in range(o.get_child_count()):
                c = o.get_child_at_index(i)
                if c is not None:
                    queue.append(c)
        except Exception:
            pass
    return docs


out = {'t': t0, 'iso': time.strftime('%Y-%m-%dT%H:%M:%S', time.gmtime(t0)) + '.%03dZ' % int((t0 % 1) * 1000)}
desk = Atspi.get_desktop(0)
apps = []
for i in range(desk.get_child_count()):
    a = desk.get_child_at_index(i)
    if a is not None:
        apps.append(a)
chrome = [a for a in apps if (a.get_name() or '').lower().startswith('chrom')]
out['apps'] = [a.get_name() for a in apps]
if not chrome:
    out['error'] = 'no Chromium application on the AT-SPI desktop'
    print(json.dumps(out)); sys.exit(0)
docs = find_docs(chrome[0])
docs = [d for d in docs if want in (d.get_name() or '')] or docs
if not docs:
    out['error'] = 'no document web'
    print(json.dumps(out)); sys.exit(0)
doc = docs[0]
out['document'] = desc(doc)
nodes, focused = [], []
stack = [(doc, 0)]
while stack and len(nodes) < 400:
    o, dep = stack.pop()
    d = desc(o, dep)
    nodes.append(d)
    if 'focused' in d['states']:
        focused.append({k: d[k] for k in ('role', 'name', 'states') if k in d})
    try:
        n = o.get_child_count()
        kids = [o.get_child_at_index(i) for i in range(n)]
    except Exception:
        kids = []
    for c in reversed([k for k in kids if k is not None]):
        stack.append((c, dep + 1))
out['focused_in_doc'] = focused
out['nodes'] = nodes[1:]
out['elapsed'] = round(time.time() - t0, 3)
print(json.dumps(out, ensure_ascii=False))
