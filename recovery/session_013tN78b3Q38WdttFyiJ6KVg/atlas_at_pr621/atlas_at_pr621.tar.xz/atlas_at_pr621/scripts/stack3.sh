#!/bin/bash
# ATLAS-AT lane, stack3.sh = stack2.sh plus a pointer park before the driver; stack2.sh = stack.sh plus an exclusive lock on atlasat/stack.lock (copied from the ISOLATE lane stack.sh): one complete Xvfb + D-Bus + AT-SPI + speech-dispatcher + Orca + Chromium stack for ONE run.
# Copied from the SITE rep lane stack.sh and adapted: serves only isolate/pages, Chromium has no route to
# the environment proxy (dead loopback proxy + background features off), proxy status before/after,
# net_error count, and byte length + sha256 of the Orca and speech-dispatcher logs.
# usage: stack.sh RUN_ID TREE   (TREE = base | var | var2, served from atlasat/trees/TREE/docs/site)
set -u
SC=/tmp/claude-0/-home-user-main/d5c985ca-97e5-58d8-a9d4-1e0a19065a22/scratchpad
R=$SC/atlasat; ID="$1"; TREE="$2"; SITE=$R/trees/$TREE/docs/site
[ -d "$SITE" ] || { echo "no tree $TREE"; exit 2; }
OUT=$R/evidence/$ID; SOCK=$R/sd.sock; CDP=9333
CHROME=/opt/pw-browsers/chromium-1194/chrome-linux/chrome
exec 9>"$R/stack.lock"; flock 9   # one stack at a time across the executor and the replicator
if pgrep -x Xvfb >/dev/null || pgrep -f /usr/bin/orca >/dev/null || pgrep -x speech-dispatch >/dev/null || pgrep -f chromium-1194 >/dev/null; then
  echo "REFUSE: another stack is running"; exit 3; fi
teardown() {
  [ -n "${CHPID:-}" ] && kill $CHPID 2>/dev/null; sleep 1
  [ -n "${ORPID:-}" ] && kill -TERM $ORPID 2>/dev/null; sleep 2
  pkill -f chromium-1194 2>/dev/null; pkill -f /usr/bin/orca 2>/dev/null
  [ -f "$OUT/speechd.pid" ] && kill $(cat "$OUT/speechd.pid") 2>/dev/null
  pkill -x speech-dispatch 2>/dev/null; pkill -x sd_espeak-ng 2>/dev/null
  pkill -f "$R/scripts/sink.py" 2>/dev/null
  pkill -f at-spi-bus-launcher 2>/dev/null; pkill -f at-spi2-registryd 2>/dev/null
  [ -n "${XPID:-}" ] && kill $XPID 2>/dev/null
  [ -n "${SRVPID:-}" ] && kill -TERM $SRVPID 2>/dev/null
  [ -n "${DBUS_SESSION_BUS_PID:-}" ] && kill $DBUS_SESSION_BUS_PID 2>/dev/null
  sleep 1
  pkill -9 -f chromium-1194 2>/dev/null; pkill -9 -f /usr/bin/orca 2>/dev/null; pkill -9 -x speech-dispatch 2>/dev/null
  pkill -9 -x sd_espeak-ng 2>/dev/null; pkill -9 -x Xvfb 2>/dev/null
  rm -f "$SOCK" /tmp/.X99-lock
}
rm -rf "$OUT" "$R/profiles/$ID"; mkdir -p "$OUT/sdlog"
C=$OUT/commands.txt
log() { echo "$(date -u +%Y-%m-%dT%H:%M:%S.%3NZ) $*" >> "$C"; }
log "proxy status BEFORE (read only): curl -sS \$HTTPS_PROXY/__agentproxy/status"
curl -sS "$HTTPS_PROXY/__agentproxy/status" > "$OUT/proxy-status-before.json" 2>"$OUT/proxy-status-before.err"
sha256sum /root/.local/share/orca/user-settings.conf > "$OUT/orca-settings.sha256"
(cd $SITE && sha256sum dependencies.html atlas.mjs atlas-spatial-shell.mjs current.json) > "$OUT/pages.sha256"; echo "$TREE" > "$OUT/tree.txt"
log "serve: (cd $R/scripts && /opt/node22/bin/node $R/scripts/serve.mjs $SITE $OUT/server-requests.jsonl 8770)"
(cd $R/scripts && exec /opt/node22/bin/node $R/scripts/serve.mjs $SITE $OUT/server-requests.jsonl 8770) >"$OUT/serve.out" 2>&1 &
SRVPID=$!
export DISPLAY=:99
log "Xvfb :99 -screen 0 1280x900x24 -nolisten tcp"
Xvfb :99 -screen 0 1280x900x24 -nolisten tcp >"$OUT/xvfb.log" 2>&1 & XPID=$!
sleep 1
eval "$(dbus-launch --sh-syntax)"; log "dbus-launch --sh-syntax -> $DBUS_SESSION_BUS_ADDRESS"
export GTK_MODULES=gail:atk-bridge ACCESSIBILITY_ENABLED=1
log "/usr/libexec/at-spi-bus-launcher --launch-immediately"
/usr/libexec/at-spi-bus-launcher --launch-immediately >"$OUT/atspi.log" 2>&1 &
sleep 1
export SPEECHD_ADDRESS="unix_socket:$SOCK"
log "REP_AUDIO_DIR=$OUT LANG=C.UTF-8 speech-dispatcher -s -t 0 -l 5 -L $OUT/sdlog -C $R/scripts/sdconf -S $SOCK -P $OUT/speechd.pid (SPEECHD_ADDRESS=$SPEECHD_ADDRESS)"
REP_AUDIO_DIR="$OUT" LANG=C.UTF-8 speech-dispatcher -s -t 0 -l 5 -L "$OUT/sdlog" -C "$R/scripts/sdconf" -S "$SOCK" -P "$OUT/speechd.pid" >"$OUT/speechd.out" 2>&1 &
for i in $(seq 1 40); do [ -S "$SOCK" ] && break; sleep 0.25; done
[ -S "$SOCK" ] || log "PROBLEM: no speechd socket"
log "/usr/bin/python3.12 /usr/bin/orca --replace --debug-file=$OUT/orca-debug.txt"
/usr/bin/python3.12 /usr/bin/orca --replace --debug-file="$OUT/orca-debug.txt" >"$OUT/orca.out" 2>&1 & ORPID=$!
sleep 6
grep -q "Speech Dispatcher service failed" "$OUT/orca-debug.txt" 2>/dev/null && log "PROBLEM: orca/speechd connect failed"
CHARGS=(--no-sandbox --force-renderer-accessibility --no-first-run --no-default-browser-check --user-data-dir=$R/profiles/$ID
  --window-size=1200,850 --window-position=0,0 --remote-debugging-port=$CDP
  --proxy-server=http://127.0.0.1:9 --disable-background-networking --disable-component-update --disable-sync
  --disable-default-apps --disable-features=OptimizationHints,MediaRouter,Translate
  --use-angle=swiftshader --enable-unsafe-swiftshader
  "data:text/html,<title>atlas start</title><p>atlas start</p>")
log "$CHROME ${CHARGS[*]}"
"$CHROME" "${CHARGS[@]}" >"$OUT/chrome.log" 2>&1 & CHPID=$!
for i in $(seq 1 40); do curl -s --noproxy '*' http://127.0.0.1:$CDP/json/version >/dev/null 2>&1 && break; sleep 0.25; done
sleep 3
log "park the X pointer at (1000,12), away from any popup (replicator finding)"
/usr/bin/python3.12 -I -c "import gi; gi.require_version('Atspi','2.0'); from gi.repository import Atspi; print(Atspi.generate_mouse_event(1000,12,'abs'))" >> "$OUT/pointer.txt" 2>&1
log "/opt/node22/bin/node $R/scripts/drive.mjs $R/scripts/tasks.json $ID $OUT $CDP"
/opt/node22/bin/node $R/scripts/drive.mjs $R/scripts/tasks.json $ID $OUT $CDP >"$OUT/driver.out" 2>&1
log "driver exit $?"
sleep 2
teardown
log "teardown done"
log "proxy status AFTER (read only)"
curl -sS "$HTTPS_PROXY/__agentproxy/status" > "$OUT/proxy-status-after.json" 2>"$OUT/proxy-status-after.err"
NE=$(grep -c 'net_error' "$OUT/chrome.log"); echo "net_error_lines	$NE" > "$OUT/chrome-net_error.count"; log "chrome.log net_error lines: $NE"
: > "$OUT/LOG_HASHES.tsv"
for f in "$OUT/orca-debug.txt" "$OUT/sdlog/speech-dispatcher.log" "$OUT/chrome.log" "$OUT/server-requests.jsonl"; do
  [ -f "$f" ] && printf '%s\t%s\t%s\n' "${f#$R/}" "$(stat -c %s "$f")" "$(sha256sum "$f" | cut -d' ' -f1)" >> "$OUT/LOG_HASHES.tsv"
done
rm -rf "$R/profiles/$ID"
