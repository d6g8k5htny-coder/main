#!/usr/bin/python3.12 -I
# REP: send real X key events through AT-SPI (registryd -> XTest), one argument per keystroke.
# Forms: Tab | shift+Tab | ctrl+Home | alt+Left | Insert+a | h | shift+h | type:<text>
# Prints one JSON line per argument with the time each event was sent.
import sys, time, json, gi
gi.require_version('Atspi', '2.0')
from gi.repository import Atspi
K = Atspi.KeySynthType
MODS = {'shift': 50, 'ctrl': 37, 'alt': 64, 'Insert': 118}
SYMS = {'Tab': 0xff09, 'Return': 0xff0d, 'Escape': 0xff1b, 'space': 0x20, 'Up': 0xff52, 'Down': 0xff54,
        'Left': 0xff51, 'Right': 0xff53, 'Home': 0xff50, 'End': 0xff57, 'Page_Up': 0xff55, 'Page_Down': 0xff56,
        'KP_Enter': 0xff8d, 'KP_Add': 0xffab, 'KP_Up': 0xff97, 'KP_Home': 0xff95, 'KP_Page_Up': 0xff9a,
        'KP_Begin': 0xff9d, 'BackSpace': 0xff08}
def sym(name):
    if name in SYMS: return SYMS[name]
    if len(name) == 1: return ord(name)
    raise SystemExit('unknown key ' + name)
out = []
for arg in sys.argv[1:]:
    t = time.time()
    if arg.startswith('type:'):
        for ch in arg[5:]:
            Atspi.generate_keyboard_event(ord(ch), None, K.SYM); time.sleep(0.18)
        out.append({'t': t, 'key': arg}); continue
    parts = arg.split('+')
    mods, key = parts[:-1], parts[-1]
    for m in mods: Atspi.generate_keyboard_event(MODS[m], None, K.PRESS); time.sleep(0.03)
    ok = Atspi.generate_keyboard_event(sym(key), None, K.SYM)
    for m in reversed(mods): time.sleep(0.03); Atspi.generate_keyboard_event(MODS[m], None, K.RELEASE)
    out.append({'t': t, 'key': arg, 'ok': bool(ok)})
for o in out: print(json.dumps(o))
