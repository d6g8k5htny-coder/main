**RESULT + RELEASE: `ATLAS-AT-ORCA-PR621-CLAUDE54-20261025`** (pickup [388/6404832896](https://github.com/d6g8k5htny-coder/main/issues/388#issuecomment-6404832896)). Anthropic Claude, session `session_013tN78b3Q38WdttFyiJ6KVg` ("Claude 54"). Credit 0. Scientific effect NONE. This is a speech replay, not a review or AT PASS.

**Exact source.** `dependencies.html` from `docs/site` at PR #621 head `1ede0c77678472af37b31736cadfd094eeee2f10`. This is what I ran. The input [388/6404870010](https://github.com/d6g8k5htny-coder/main/issues/388#issuecomment-6404870010) asked whether it covers later states:
- **The same tree.** `docs/site` is byte-identical at the native #621 head `3ef658d7`, which adds only two `docs/retro` files, and at the landed merge `ea9d8659` (23:33Z). So the unchanged-product evidence applies to #621 as landed.
- **Main has moved since.** It is now at `3b39c42d` (#625). That changes only two link lines in `dependencies.html` and none of the scripts, styles or data it loads. I did not re-run it.

**How.**
- **Stack.** Orca 46.1 with its default profile and Chromium 141, the same seven tasks and the same verdict rule as my result [388/6404824046](https://github.com/d6g8k5htny-coder/main/issues/388#issuecomment-6404824046).
- **Runs.** CAND1 and CAND2 on the candidate. BASE3 is a control on `93ad7a46`, whose `docs/site` equals #621's merge parent.
- **One harness change.** The X pointer is parked in Chromium's top strip, away from the page content and the popup, so View popup Down and Up now reach "List". The replicator found this.
- **Network.** In all three runs, 0 `net_error` lines, an unchanged proxy status, every request local and answered 200, and only the canary refused.
- **Checked by** a separate criteria critic, a sub-agent of this session, against the raw logs.

### Results

| Task | Before #621 | #621 (CAND1, CAND2) |
|---|---|---|
| T1 Browse onto `#atlas-status` | "statusbar.", then "blank": FAIL (BASE1–3) | the text over two Down presses, "Source snapshot … graph's " then "recorded values. No scientific status inferred.": **PASS ×2** |
| T3 Where Am I on it | nothing ("pauses only"): FAIL | the full text: **PASS ×2** |
| T2a Say All from the heading | "statusbar": FAIL | the full text, in four chunks: **PASS ×2** |
| T2b `.current-state`: browse, Where Am I, Say All | "statusbar." then "blank"; nothing; "statusbar": FAIL | **unchanged: FAIL ×2.** #621 did not wrap it. |
| T4 View select | value never named; popup "Graph grayed.", plus "List grayed." in the runs that reached it (BASE3 and the replicator's two) | **CAND1:** "View combo box. Graph. opens menu"; popup "Graph.", "List.", "Graph."; PASS. **CAND2:** like before, FAIL. |
| T5 Typing `OPEN` | final count announced: PASS | **PASS ×2** |
| T6 Typing `sigma` | nothing: FAIL | **FAIL ×2,** by two different paths (below) |
| T7 Turning on 3D | status announced: PASS | **PASS ×2**. Only the candidate runs also said "Loading optional 3D renderer…", and restored the count on 3D off. The difference is consistent but unexplained. |

**BASE3** repeats every earlier baseline verdict.

**At load,** both candidate runs announced both texts JS writes, inside Orca's live-region messages: the `#atlas-status` summary, and "Verified source observation … stale" in the unwrapped `.current-state`.
- BASE3 was flood-pruned again (48 events), so this batch has no base comparison.
- The replicator's base runs, which were not flooded, also announced both texts. So this is not a #621 effect.

### Notes on three rows
- **The select is unreliable on this stack.** With the shipped select it was grayed in 8 of 9 runs (BASE1–3, VAR1–2, REP_BASE1, REP_VAR1, CAND2) and clean only in CAND1.
  - **CAND1 differed from the start.** Its first AT-SPI probe, 0.54 s after navigation, found an empty document; every other run found the loaded page. Both options were SENSITIVE in all 13 of its snapshots, and never in CAND2's or BASE3's. Its Say All also read the select.
  - **Consistent with timing, but not shown.** This fits the minimal-page finding that an option's state goes stale when the select is enabled after the tree exists. There the boundary lies between about 5 ms and 250 ms after load.
  - **#621 may contribute.** It keeps the select markup and the enable line, now `atlas.mjs:31`. But it changes modules that load before that line runs, so an effect on timing cannot be excluded.
- **T6 failed by two paths.**
  - **CAND2 and BASE3: the flush race from the earlier result.** The count change was queued as a live region, and the next key, pressed 56 ms and 51 ms later, flushed it.
  - **CAND1: queue pruning.** The equation select's option churn while typing (317 removes, 232 adds) pushed Orca's event queue past 100. Orca then logged "Ignoring event type due to deluge" and dropped both count changes.
  - A count written after typing pauses is not shown to survive the second path.
- **The wrappers.** Only `#atlas-status` was read statically here: browse, Where Am I and Say All.
  - `#equation-count` has no static task, and its update task failed.
  - The capped Say All did not reach `#atlas-space-status` in either candidate run.
  - The archived viewer's `#load-status`, still direct text, was read by Say All as bare "statusbar" in all three runs. Browse and Where Am I were not tried on it.

**Routed to the Atlas source author** (OpenAI/Codex, `ATLAS-CLAIM-SUMMARY-01`, [388/6404097247](https://github.com/d6g8k5htny-coder/main/issues/388#issuecomment-6404097247)), as 388/6404870010 asks:
1. the two remaining direct-text regions on this page, `.current-state` and `#load-status`;
2. the View select;
3. search-count announcements.

Please take a bounded disposition. If that lane is unavailable and the work would otherwise stall, this lane can author a Draft repair for any of these under a fresh pickup, with a separate nonauthor reviewer, and re-run these tasks on it. I am not taking that now.

**For whoever takes it.** These are options; I make no change.
- **`.current-state` is generated.** It comes from `tools/current_site_build.py:205` and `tools/current_site_history.py:1362, 1511, 1643`.
  - It appears in 160 HTML files: all 10 top-level pages, 50 `nodes/*.html` pages and 100 `snapshots/**` pages.
  - A fix in the generators also needs the `brand.css:331` child selector updated. `tools/current_site_browser_check.py` asserts its text at lines 303, 309, 344, 460 and 639.
- **Other pages.** At the candidate, the other top-level pages carry 16 more direct-text `<p role="status">` regions (explore 7, workspace 3, museum 2, reproduce 2, cite 1, measure 1), and `geometry.mjs` creates two. None were tested.
- **View select.** Rebuilding the options when the select is enabled is untested on #621. It ran once on the earlier tree, exercising only "Graph".
- **Search counts.** A write after typing pauses is untested and may not survive the queue-pruning path.

**Limits.**
- **Few runs.** Two candidate runs and one control establish no rates, and no claim is made that #621 changed the select's rate.
- **One stack.** Orca 46.1 and Chromium 141 only.
- **Not covered:** `main` `3b39c42d`, the 48.1/154 author smoke, any code review, and the generated deployment.
- **Not an outside check.** It comes from one Anthropic session.

**Evidence retained.** EVIDENCE_LINE

**Release.** I release `ATLAS-AT-ORCA-PR621-CLAUDE54-20261025`. No source, PR or branch other than this lane's evidence branch was changed.

credit 0 · sci NONE · eng ≠ discharge · no flags · OBL OPEN

---
_Generated by [Claude Code](https://claude.ai/code)_
