"""Add A3.8, A3.9, A3.10 and A3.11 to the Math- packet frontiers/qs_d3_soft_layer_chain_20261005 (worktree /home/claude/wt-a38,
branch claude/qs-d3-chain-a38-a311-20261006 off #340's head 68ddc14c).

Stores the exact main#229 comment bodies of the four records, extracts a38_exact.py, a311_exact.py and A3.10's pd3_ledger.py
with their stdouts by the stated rule, appends the four objects to SOURCES.json, adds the rejection fingerprints of their mutant
and invalid invocations to replay.py (computed from the extracted scripts under both interpreter modes; they must agree),
generalizes replay.py's stdout-fence rule by the stored stdout's suffix, and updates the test's inventory count and the
workflow's display name. README.md is edited separately.
"""
import hashlib
import json
import os
import pathlib
import re
import subprocess
import sys
import urllib.request

WT = pathlib.Path('/home/claude/wt-a38')
ROOT = WT / 'frontiers/qs_d3_soft_layer_chain_20261005'
SP = pathlib.Path('/tmp/claude-0/-home-claude/b41b316f-232c-5cf7-a0ee-80f0de603a6f/scratchpad/d3pack')
TOK = os.environ['GITHUB_TOKEN']
ISSUE = 229
CLAIM = 6010712951


def api(url):
    req = urllib.request.Request(url, headers={'Authorization': 'Bearer ' + TOK, 'Accept': 'application/vnd.github+json',
                                               'User-Agent': 'x'})
    return json.load(urllib.request.urlopen(req))


def ident(data):
    return len(data), hashlib.sha256(data).hexdigest()


stored = {}


def comment(tag, cid, path, role, expect_sha=None):
    c = api('https://api.github.com/repos/d6g8k5htny-coder/main/issues/comments/%d' % cid)
    assert c['issue_url'].endswith('/issues/%d' % ISSUE), (cid, c['issue_url'])
    body = c['body'].encode('utf-8')
    p = ROOT / path
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(body)
    n, h = ident(body)
    if expect_sha:
        assert h.startswith(expect_sha), (path, h)
    stored.setdefault(tag, []).append({'path': path, 'role': role, 'comment': str(cid),
                                       'url': 'https://github.com/d6g8k5htny-coder/main/issues/229#issuecomment-%d' % cid,
                                       'created_at': c['created_at'], 'updated_at': c['updated_at'], 'bytes': n, 'sha256': h})
    print('  stored', path, n, h[:12])


def extract(tag, source_path, heading, script_path, stdout_path, expect_script_sha, expect_stdout_sha, fence):
    body = (ROOT / source_path).read_text(encoding='utf-8')
    assert body.count(heading) >= 1, heading
    section = body[body.index(heading):]
    m1 = re.search(r'```python\n(.*?)\n```\n', section, re.S)
    code = (m1.group(1) + '\n').encode('utf-8')
    m2 = re.search(r'```%s\n(.*?)\n```\n' % fence, section[m1.end():], re.S)
    out = (m2.group(1) + '\n').encode('utf-8')
    assert out.count(b'\n') == 1
    what = 'controls comment' if 'CONTROLS' in source_path else 'note'
    for path, data, role, exp in ((script_path, code, 'control script, extracted verbatim from the stored %s %s (heading: %s)' % (what, source_path, heading.strip()), expect_script_sha),
                                  (stdout_path, out, 'published stdout of %s, extracted verbatim from %s (```%s fence)' % (script_path, source_path, fence), expect_stdout_sha)):
        p = ROOT / path
        p.write_bytes(data)
        n, h = ident(data)
        assert h.startswith(exp), (path, h)
        stored[tag].append({'path': path, 'role': role, 'extracted_from': source_path, 'heading': heading.strip(), 'bytes': n, 'sha256': h})
        print('  extracted', path, n, h[:12])


# ---------------------------------------------------------------------------------------------------- A3.8 records
T = 'A3.8'
comment(T, 6005773306, 'A3_8/CLAIM.md', 'author work claim (A3.8)', 'a894826e')
comment(T, 6007704303, 'A3_8/PROOF.md', 'frozen note (QS addendum A3.8)', 'afd22712')
comment(T, 6007706590, 'A3_8/AUTHOR_CONTROLS_COMMENT.md', 'author controls comment (contains a38_exact.py and its stdout)', 'c12bbbc2')
extract(T, 'A3_8/AUTHOR_CONTROLS_COMMENT.md', '### a38_exact.py', 'A3_8/author_controls.py', 'A3_8/author_controls_stdout.json', 'f5b32f60', '11f3b6a3', 'json')
comment(T, 6007721623, 'A3_8/READ_REQUESTS.md', 'author read requests (three slices; Slice 2 summons of one Cursor agent, D2 of 6002718035)', '40e8e2c0')
comment(T, 6007722459, 'A3_8/REVIEW_SLICE2_BLOCK.md', 'Slice 2 (sections 3-5): BLOCK, Cursor agent bc-ea15a5c7 (xAI Grok 4.7); pickup and verdict in one comment; the BLOCK rested on reading lambda-tilde as the larger eigenvalue and was lifted by 6008104745', '07555bf5')
comment(T, 6007792473, 'A3_8/REVIEW_SLICE3_PICKUP.md', 'Slice 3 (section 6, the rate assembly) pickup: OpenAI / GPT-6 Astra Pro, session qs-a38-rate-audit-20261006', '6acc276a')
comment(T, 6007893752, 'A3_8/REVIEW_SLICE3_SOURCE_CLARIFICATION.md', 'Slice 3 reader\'s source-interface clarification (A3.4 section 0 fixes the ordered eigenvalue), addressed to the Slice 2 reader and the author; Astra', 'caf3d730')
comment(T, 6007935786, 'A3_8/REVIEW_SLICE3.md', 'Slice 3 (section 6: Proposition 6.1, Theorems QFE3 and ER3; the rate assembly): PASS_SCOPED_CONDITIONAL with one notation item, Astra (OpenAI / GPT-6 Astra Pro)', '59fc3c0a')
comment(T, 6008104016, 'A3_8/AUTHOR_ROUND1_SUCCESSOR_TEXT.md', 'author round-1 reply: the Slice 3 notation item applied as successor text (the note\'s bytes unchanged); the Slice 2 BLOCK answered from A3.4 section 0', '8a14d2e2')
comment(T, 6008104170, 'A3_8/REVIEW_SLICE2_READBACK_SUMMONS.md', 'Slice 2 readback summons (one Cursor agent): reconcile the BLOCK with A3.4 section 0', '9e68486d')
comment(T, 6008104745, 'A3_8/REVIEW_SLICE2.md', 'Slice 2 (sections 3-5; controls Z5, Z6): BLOCK lifted -> PASS, Cursor agent bc-31f1aced (xAI Grok 4.7; a fresh session); pickup and verdict in one comment', '0d8e9004')
comment(T, 6008678339, 'A3_8/REVIEW_SLICE1_SUMMONS.md', 'Slice 1 summons (one Cursor agent); the same comment is A3.7\'s author round note, stored as A3_7/AUTHOR_ROUND_NOTE.md', '57d43a64')
comment(T, 6008678986, 'A3_8/REVIEW_SLICE1.md', 'Slice 1 (sections 1-2; control group Z4): PASS, Cursor agent bc-7a2bee94 (xAI Grok 4.7); pickup and verdict in one comment', '76081bfa')
comment(T, 6008843064, 'A3_8/AUTHOR_ROUND_NOTE.md', 'author round note (read-complete in three slices, no amendment beyond the successor text)', 'badb3cc3')

# ---------------------------------------------------------------------------------------------------- A3.9 records
T = 'A3.9'
comment(T, 6007855091, 'A3_9/CLAIM.md', 'author work claim (A3.9)', '0867d7be')
comment(T, 6008067902, 'A3_9/PROOF.md', 'frozen note (QS addendum A3.9); no control script', 'ffe46445')
comment(T, 6009098123, 'A3_9/REVIEW_SUMMONS.md', 'read summons (the whole note; one Cursor agent, D2 of 6002718035)', 'f0a05398')
comment(T, 6009099266, 'A3_9/REVIEW.md', 'the whole note (Lemma 9.1, Theorem 9.2, Corollary 9.3): PASS, Cursor agent bc-8440ed26 (xAI Grok 4.7); pickup and verdict in one comment', 'b0366c6d')

# ---------------------------------------------------------------------------------------------------- A3.10 records
T = 'A3.10'
comment(T, 6008327269, 'A3_10/CLAIM.md', 'author work claim (A3.10)', '51fe7a0b')
comment(T, 6008550120, 'A3_10/PROOF.md', 'frozen note (QS addendum A3.10, Corollary PD3); section 4 contains the ledger script pd3_ledger.py and its stdout', '98fd6832')
extract(T, 'A3_10/PROOF.md', '### 4. Ledger script', 'A3_10/ledger_control.py', 'A3_10/ledger_control_stdout.txt', 'ff62f337', '4220cc08', 'text')
comment(T, 6009305427, 'A3_10/REVIEW_SUMMONS.md', 'read summons (the whole note; one Cursor agent, D2 of 6002718035)', '47eaf952')
comment(T, 6009306797, 'A3_10/REVIEW.md', 'the whole note (Corollary PD3 (i)-(v), its proof, the ledger script): PASS, Cursor agent bc-6bc131b5 (xAI Grok 4.7); pickup and verdict in one comment', 'f04c9d38')

# ---------------------------------------------------------------------------------------------------- A3.11 records
T = 'A3.11'
comment(T, 6009293688, 'A3_11/CLAIM.md', 'author work claim (A3.11)', '16e7b8de')
comment(T, 6009956838, 'A3_11/PROOF.md', 'frozen note (QS addendum A3.11)', '72bbc2ed')
comment(T, 6009957866, 'A3_11/AUTHOR_CONTROLS_COMMENT.md', 'author controls comment (contains a311_exact.py and its stdout)', 'da9d8e50')
extract(T, 'A3_11/AUTHOR_CONTROLS_COMMENT.md', '### a311_exact.py', 'A3_11/author_controls.py', 'A3_11/author_controls_stdout.json', 'cdc3a86c', '3e29bf23', 'json')
comment(T, 6009970681, 'A3_11/READ_REQUESTS.md', 'author read requests (three slices; Slice 1 summons of one Cursor agent, D2 of 6002718035)', '5f2672d4')
comment(T, 6009971496, 'A3_11/REVIEW_SLICE1.md', 'Slice 1 (section 1: Lemmas 1.1-1.4; controls Z1-Z3, Z9): PASS, Cursor agent bc-679ec89e (xAI Grok 4.7); pickup and verdict in one comment', 'f7cf7af0')
comment(T, 6010123557, 'A3_11/REVIEW_SLICE2_SUMMONS.md', 'Slice 2 summons (one Cursor agent)', 'a30dc3e0')
comment(T, 6010124388, 'A3_11/REVIEW_SLICE2.md', 'Slice 2 (sections 2-3: the shells and the fixed layer; controls Z4-Z6): PASS, Cursor agent bc-b4a44fb4 (xAI Grok 4.7); pickup and verdict in one comment', 'cde5e54c')
comment(T, 6010123715, 'A3_11/REVIEW_SLICE3_SUMMONS_1.md', 'Slice 3 summons, first posting (one second after the Slice 2 summons; it triggered no agent)', '4b1b58b8')
comment(T, 6010246424, 'A3_11/REVIEW_SLICE3_SUMMONS_2.md', 'Slice 3 summons, re-issued after the Slice 2 verdict (one Cursor agent)', 'b30f839d')
comment(T, 6010247147, 'A3_11/REVIEW_SLICE3.md', 'Slice 3 (sections 4-5: the exhaustion and the consequences; controls Z7-Z8; sections 6 and 8 for overclaim): PASS, Cursor agent bc-115e1e76 (xAI Grok 4.7); pickup and verdict in one comment', '1c1237fe')
comment(T, 6010521368, 'A3_11/AUTHOR_ROUND_NOTE.md', 'author round note (read-complete in three slices, no amendment), carried in the A4.3 read-request comment', '196cfb41')

# ---------------------------------------------------------------------------------------------------- fingerprints
specs = [
    # (tag, name, script, stdout, mutants, invalid, reason_from)
    ('A3.8', 'a38_exact.py', 'A3_8/author_controls.py', 'A3_8/author_controls_stdout.json',
     [['--mutant', 'M%d' % j] for j in range(1, 14)], [['--bogus'], ['--mutant', 'M14'], ['--mutant']], 'stderr'),
    ('A3.10', 'pd3_ledger.py (A3.10 section 4; stdout in a ```text fence)', 'A3_10/ledger_control.py', 'A3_10/ledger_control_stdout.txt',
     [['RATE_THIRD'], ['LOG_HALF'], ['CUM_HALF'], ['MOM_2000']], [['BOGUS']], 'stdout'),
    ('A3.11', 'a311_exact.py', 'A3_11/author_controls.py', 'A3_11/author_controls_stdout.json',
     [['--mutant', 'M%d' % j] for j in range(1, 13)], [['--bogus'], ['--mutant', 'M13'], ['--mutant']], 'stderr'),
]
contracts = {}
for tag, name, script_rel, stdout_rel, mutants, invalid, reason_from in specs:
    script = ROOT / script_rel
    for args, code_expected in [(m, 1) for m in mutants] + [(i, 2) for i in invalid]:
        results = []
        for flags in (['-B', '-S'], ['-B', '-O', '-S']):
            proc = subprocess.run([sys.executable, *flags, str(script), *args], capture_output=True, cwd=str(script.parent), timeout=600)
            results.append((proc.returncode, hashlib.sha256(proc.stdout).hexdigest(), hashlib.sha256(proc.stderr).hexdigest(), proc.stdout.decode(), proc.stderr.decode()))
        assert results[0][:3] == results[1][:3], (args, results)
        code, so, se, out_text, err_text = results[0]
        assert code == code_expected, (args, code, out_text, err_text)
        if reason_from == 'stderr':
            assert out_text == '', (args, out_text)
            reason = err_text.splitlines()[0]
            assert reason.startswith('FAILED: ' if code == 1 else 'usage:'), err_text
        else:
            assert err_text == '', (args, err_text)
            reason = out_text.splitlines()[0]
            assert reason.startswith('FAIL ' if code == 1 else 'unknown mutant label'), out_text
            if code == 1:
                assert out_text.splitlines()[-1].startswith('Corollary PD3 ledger: 94 checks, ') and 'mutant: %s' % args[0] in out_text.splitlines()[-1], out_text
        contracts[(script_rel, tuple(args))] = (code, so, se, reason)
        print('  contract', script_rel, args, code, so[:8], se[:8], reason)
    for flags in (['-B', '-S'], ['-B', '-O', '-S']):
        proc = subprocess.run([sys.executable, *flags, str(script)], capture_output=True, cwd=str(script.parent), timeout=600)
        assert proc.returncode == 0 and proc.stderr == b'' and proc.stdout == (ROOT / stdout_rel).read_bytes(), (script_rel, flags, proc.stdout, proc.stderr)
    print('  baseline ok in both modes:', script_rel)
assert len(contracts) == 36, len(contracts)

# ---------------------------------------------------------------------------------------------------- SOURCES.json
m = json.loads((ROOT / 'SOURCES.json').read_text(encoding='utf-8'))
assert [o['tag'] for o in m['objects']] == ['A3', 'A3.1', 'A3.2', 'A3.3', 'A3.4', 'A3.5', 'A3.6', 'A3.7']
m['object'] = 'QS-D3-SOFT-LAYER-CHAIN-A3-A3_11-INCORPORATION-20261006-v3'
m['incorporated_by']['claim'] = ('https://github.com/d6g8k5htny-coder/main/issues/229#issuecomment-6004719823 (A3-A3.6); '
                                 'https://github.com/d6g8k5htny-coder/main/issues/229#issuecomment-6008975407 (A3.7, Math-#340); '
                                 'https://github.com/d6g8k5htny-coder/main/issues/229#issuecomment-%d (A3.8-A3.11)' % CLAIM)
m['incorporated_by']['note'] = 'the incorporator is also the author of A3-A3.11 (custody only; no proof byte is changed)'
assert m['extraction_rule'].endswith('plus one newline')
m['extraction_rule'] += ('; for A3.10, whose ledger script is published inside the note itself (A3_10/PROOF.md, heading "### 4. Ledger script"), '
                         'the expected stdout is the single line in the following ```text fence, plus one newline (the fence language follows '
                         'the stored stdout\'s suffix: .json for ```json, .txt for ```text)')
assert 'A3.8, A3.9, A3.10' in m['excluded']
m['excluded'].pop('A3.8, A3.9, A3.10')
m['excluded']['A4.3'] = ('QS addendum A4.3 (6010510789, controls 6010511425): the planar (d = 2) counterpart of A3.11 at compact K, author-side with '
                         'its Slice 1 read PASS (6010522535) and Slice 2 requested at this incorporation; it belongs beside A4 in '
                         'frontiers/planar_rejected_endpoint_margin_20261003/ or in a successor here, as its incorporation claim will name')
RB = 'https://github.com/d6g8k5htny-coder/main/issues/229#issuecomment-'
author = 'Anthropic Claude (session_01NMeKEismAyeqgdB4sy2NJU), for Dylan Roy (delegated AI work)'
m['objects'].append({
    'tag': 'A3.8', 'directory': 'A3_8/', 'object': 'CL-QS-A3-8-D3-FAILURE-RATE-20261006-v1',
    'title': 'the d = 3 failure-measure rate on the growing soft layer: 1 - p_r = r^3 alpha^(3) + O_beta(r^(3+beta)) for every beta < 2/3, and the endpoint O(r^(11/3) log(1/r)^(8/3))',
    'author': author,
    'kind': 'the layer law with explicit H = 1 + Lambda dependence (Lemmas 1.1-1.3), the edges, radii, hard-gap strip, Hessian transfer, decision bands, margins and endpoint strip with H (Lemmas 2.1-4.2), the tails (Lemmas 5.1-5.4) and the exhaustion (Proposition 6.1, Theorems QFE3 and ER3); every weighted statement conditional on A3.4 (through it A3.3) and on A3.7',
    'nonauthor_reads_as_recorded': [
        'Slice 1 (sections 1-2; Z4): Cursor agent bc-7a2bee94 (xAI Grok 4.7; non-Claude, nonauthor), PASS, 6008678986',
        'Slice 2 (sections 3-5; Z5, Z6): Cursor agent bc-ea15a5c7 (xAI Grok 4.7), BLOCK, 6007722459 (reading lambda-tilde as the larger eigenvalue); '
        'Astra source clarification 6007893752 (A3.4 section 0 fixes the ordered eigenvalue); readback by Cursor agent bc-31f1aced (xAI Grok 4.7), BLOCK lifted -> PASS, 6008104745',
        'Slice 3 (section 6, the rate assembly): OpenAI / GPT-6 Astra Pro (session qs-a38-rate-audit-20261006), PASS_SCOPED_CONDITIONAL with one notation item, 6007935786; '
        'the item applied as successor text 6008104016 (the note\'s bytes unchanged)',
        'author round note 6008843064: read-complete, no amendment beyond the successor text; the note body is frozen as posted',
    ],
    'conditional_on': 'A3.4, and through it A3.3, and A3.7 at its reviewed scope, for every weighted statement; the deterministic inputs (A3.3, A3.5 sections 1-3, the certificates of A3.6 and A3.7) carry no such condition',
    'organizational_independence': 0,
    'stored': stored['A3.8'],
    'replays': [{'name': 'a38_exact.py', 'script': 'A3_8/author_controls.py', 'stdout': 'A3_8/author_controls_stdout.json', 'args': [],
                 'mutants': specs[0][4], 'invalid': specs[0][5]}],
})
m['objects'].append({
    'tag': 'A3.9', 'directory': 'A3_9/', 'object': 'CL-QS-A3-9-COEFFICIENT-IDENTIFICATION-20261006-v1',
    'title': "A3.8's coefficient alpha^(3) is #243's F(k; b, u)/(k A_0(b, k, u)) and, at #175's scope, a_fail = a1 + a2; #243's Theorem FL and Corollary FL.5 with a rate in d = 3",
    'author': author,
    'kind': 'Lemma 9.1 (the four selection-probability estimands are one object), Theorem 9.2 (the identification by uniqueness of limits) and Corollary 9.3 (#243\'s limit statements with A3.8\'s rate in d = 3); no new estimate and no control script; conditional on A3.8 and on #243 Corollary FL.5 at its stated status',
    'nonauthor_reads_as_recorded': [
        'the whole note: Cursor agent bc-8440ed26 (xAI Grok 4.7; non-Claude, nonauthor), PASS, 6009099266',
    ],
    'conditional_on': 'A3.8 (and through it A3.3, A3.4, A3.7) for the rate; #243 Theorem FL and Corollary FL.5 at their stated status for the identification; #175 Theorem F at its stated scope for a_fail = a1 + a2',
    'organizational_independence': 0,
    'stored': stored['A3.9'],
    'replays': [],
})
m['objects'].append({
    'tag': 'A3.10', 'directory': 'A3_10/', 'object': 'CL-QS-A3-10-PD3-REJECTED-LIFETIME-RATE-20261006-v1',
    'title': 'Corollary PD3: the d = 3 compact-window rejected-candidate lifetime density with a rate, nu_rej^(B,K)(l) = C_fail^(3) l^(2/3) + O(l^(8/9) log(1/l)^(8/3))',
    'author': author,
    'kind': 'Corollary PD3 (i)-(v): A3.8\'s rate composed with [P] sections 10-12\'s radial ledger along #175 section 7\'s identity, with the coefficient of A3.9; the ledger script pd3_ledger.py checks the exponent and constant arithmetic only; conditional on A3.8, A3.9 and the cited scopes of #175 and #243',
    'nonauthor_reads_as_recorded': [
        'the whole note: Cursor agent bc-6bc131b5 (xAI Grok 4.7; non-Claude, nonauthor), PASS, 6009306797',
    ],
    'conditional_on': 'A3.8 (and through it A3.3, A3.4, A3.7) and A3.9 for the coefficient identification; [P], [R], #175 and #243 at their stated scopes',
    'organizational_independence': 0,
    'stored': stored['A3.10'],
    'replays': [{'name': 'pd3_ledger.py (A3.10 section 4; stdout in a ```text fence)', 'script': 'A3_10/ledger_control.py', 'stdout': 'A3_10/ledger_control_stdout.txt', 'args': [],
                 'mutants': specs[1][4], 'invalid': specs[1][5]}],
})
m['objects'].append({
    'tag': 'A3.11', 'directory': 'A3_11/', 'object': 'CL-QS-A3-11-DYADIC-WINDOWS-20261006-v1',
    'title': 'the d = 3 decision on dyadic windows: fixed-layer errors O(r^4 log(1/r)), and the failure-measure rate r^beta for every beta < 1, endpoint O(r^4 log(1/r)^7)',
    'author': author,
    'kind': 'Lemma 1.1 (C82\'s coarea density localized to a sub-layer) deterministic; Lemmas 1.2-1.4 (sub-layer moments, edges and bands), 2.1-2.2 (the shell ledger and sums), Theorems E3-second, R3-second, BL3-second (the fixed layer at O(r^4 log(1/r))), Proposition 4.1, Theorems QFE3-prime and ER3-prime (the exhaustion), Corollaries 9.3-prime and PD3-prime, conditional on A3.3-A3.8 (and A3.9-A3.10 for the lifetime statements)',
    'nonauthor_reads_as_recorded': [
        'Slice 1 (section 1: Lemmas 1.1-1.4; Z1-Z3, Z9): Cursor agent bc-679ec89e (xAI Grok 4.7; non-Claude, nonauthor), PASS, 6009971496',
        'Slice 2 (sections 2-3: the shells and the fixed layer; Z4-Z6): Cursor agent bc-b4a44fb4 (xAI Grok 4.7), PASS, 6010124388',
        'Slice 3 (sections 4-5: the exhaustion and the consequences; Z7-Z8; sections 6 and 8 for overclaim): Cursor agent bc-115e1e76 (xAI Grok 4.7), PASS, 6010247147',
        'author round note (in 6010521368): read-complete, no amendment; the note body is frozen as posted',
    ],
    'conditional_on': 'A3.4, and through it A3.3, and A3.5-A3.8 at their reviewed scopes, for every weighted statement; A3.9 and A3.10 for Corollaries 9.3-prime and PD3-prime; Lemma 1.1 is deterministic',
    'organizational_independence': 0,
    'stored': stored['A3.11'],
    'replays': [{'name': 'a311_exact.py', 'script': 'A3_11/author_controls.py', 'stdout': 'A3_11/author_controls_stdout.json', 'args': [],
                 'mutants': specs[2][4], 'invalid': specs[2][5]}],
})
(ROOT / 'SOURCES.json').write_text(json.dumps(m, indent=1, ensure_ascii=False) + '\n', encoding='utf-8')
n_files = sum(len(o['stored']) for o in m['objects'])
n_scripts = sum(len(o['replays']) for o in m['objects'])
n_mut = sum(len(r['mutants']) for o in m['objects'] for r in o['replays'])
n_inv = sum(len(r['invalid']) for o in m['objects'] for r in o['replays'])
print('  SOURCES.json: %d objects, %d stored files, %d scripts, %d mutants, %d invalid' % (len(m['objects']), n_files, n_scripts, n_mut, n_inv))
assert (n_mut, n_inv) == (94, 24), (n_mut, n_inv)

# ---------------------------------------------------------------------------------------------------- replay.py
rp = (ROOT / 'replay.py').read_text(encoding='utf-8')


def replace_once(old, new):
    global rp
    assert rp.count(old) == 1, (rp.count(old), old[:80])
    rp = rp.replace(old, new)


anchor = "}\n\n# Replacing A3.6's 5/4 by 1/4 with MUT=None omits the usual mutant-description line."
lines = []
for (path, args), (code, so, se, reason) in contracts.items():
    lines.append("    (%r, %r):\n        (%d, %r, %r, %r)," % (path, args, code, so, se, reason))
replace_once(anchor, "\n".join(lines) + "\n" + anchor)
replace_once("# and, for A3.7, from its extracted author control a37_exact.py (main#229 comment 6004629351), computed under both\n"
             "# interpreter modes at incorporation and found identical.",
             "# and, for A3.7, from its extracted author control a37_exact.py (main#229 comment 6004629351), computed under both\n"
             "# interpreter modes at incorporation and found identical; likewise for A3.8 (a38_exact.py, comment 6007706590),\n"
             "# A3.10 (pd3_ledger.py, published inside the note 6008550120) and A3.11 (a311_exact.py, comment 6009957866).")
replace_once('"""Verify the stored QS A3-A3.7 records', '"""Verify the stored QS A3-A3.11 records')
replace_once("  - a control script or its stdout, extracted verbatim from a stored controls comment by the extraction rule that\n"
             "    comment states (the rule of main#229 comment 5971055189).",
             "  - a control script or its stdout, extracted verbatim from a stored controls comment by the extraction rule that\n"
             "    comment states (the rule of main#229 comment 5971055189); A3.10's ledger script and its stdout are extracted the\n"
             "    same way from the stored note itself (its section 4), the stdout from a ```text fence.")
replace_once("  2. Every extracted script and stdout equals the fenced payload inside its stored controls comment, under the\n"
             "     extraction rule.",
             "  2. Every extracted script and stdout equals the fenced payload inside its stored source comment, under the\n"
             "     extraction rule (the stdout fence language follows the stored stdout's suffix: .json for ```json, .txt for ```text).")
replace_once("# All 65 mutants and 17 invalid invocations were executed", "# All 94 mutants and 24 invalid invocations were executed")
replace_once('    """Re-extract every script and stdout from its stored controls comment and compare with the stored payloads."""',
             '    """Re-extract every script and stdout from its stored source comment and compare with the stored payloads."""')
replace_once("            stdout = [f for f in extracted if f['extracted_from'] == script['extracted_from']\n"
             "                      and f['heading'] == script['heading'] and f['path'].endswith('.json')]",
             "            stdout = [f for f in extracted if f['extracted_from'] == script['extracted_from']\n"
             "                      and f['heading'] == script['heading'] and not f['path'].endswith('.py')]")
replace_once("            stdout = stdout[0]\n"
             "            body = (root / script['extracted_from']).read_text(encoding='utf-8')",
             "            stdout = stdout[0]\n"
             "            fence = {'json': 'json', 'txt': 'text'}.get(stdout['path'].rsplit('.', 1)[-1])\n"
             "            if fence is None:\n"
             "                failures.append('%s: unsupported stdout suffix for %s' % (obj['tag'], stdout['path']))\n"
             "                continue\n"
             "            body = (root / script['extracted_from']).read_text(encoding='utf-8')")
replace_once("            m2 = re.search(r'```json\\n(.*?)\\n```\\n', section[m1.end():], re.S) if m1 else None",
             "            m2 = re.search(r'```%s\\n(.*?)\\n```\\n' % fence, section[m1.end():], re.S) if m1 else None")
replace_once("print('QS d = 3 chain (A3-A3.7) incorporation replay (%s): %d failure(s)' % (mode, len(failures)))",
             "print('QS d = 3 chain (A3-A3.11) incorporation replay (%s): %d failure(s)' % (mode, len(failures)))")
replace_once("print('QS d = 3 chain (A3-A3.7) incorporation replay (%s): %d stored identities, %d extractions, %d checker stdouts, '",
             "print('QS d = 3 chain (A3-A3.11) incorporation replay (%s): %d stored identities, %d extractions, %d checker stdouts, '")
assert rp.count('A3-A3.11') == 3, rp.count('A3-A3.11')
assert rp.count('A3-A3.7') == 0
(ROOT / 'replay.py').write_text(rp, encoding='utf-8')
print('  replay.py updated;', len(contracts), 'contracts added')
json.dump({'%s %s' % k: v for k, v in contracts.items()}, open(SP / 'a38_a311_contracts.json', 'w'), indent=1)

# ---------------------------------------------------------------------------------------------------- test + workflow
tp = WT / 'tests/test_qs_d3_replay_protocol.py'
t = tp.read_text(encoding='utf-8')
old = "        self.assertEqual(len(listed), 82)   # A3-A3.6: 48 mutants + 14 invalid; A3.7: 17 mutants + 3 invalid"
assert t.count(old) == 1
t = t.replace(old, "        self.assertEqual(len(listed), 118)  # A3-A3.6: 48 mutants + 14 invalid; A3.7: 17 + 3; A3.8: 13 + 3; A3.10: 4 + 1; A3.11: 12 + 3")
tp.write_text(t, encoding='utf-8')
wp = WT / '.github/workflows/qs-d3-soft-layer-chain.yml'
w = wp.read_text(encoding='utf-8')
old = "name: QS d = 3 soft-layer chain (A3-A3.7) replay\n"
assert w.count(old) == 1
wp.write_text(w.replace(old, "name: QS d = 3 soft-layer chain (A3-A3.11) replay\n"), encoding='utf-8')
print('  test inventory 82 -> 118; workflow name updated')
print('DONE')
