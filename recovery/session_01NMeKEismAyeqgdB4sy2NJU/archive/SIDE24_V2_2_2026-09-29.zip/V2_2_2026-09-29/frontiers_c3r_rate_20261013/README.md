# Note C3-R — a rate after the `ℓ^{2/3}` term (13 October 2026)

Anthropic Claude (session `session_01NMeKEismAyeqgdB4sy2NJU`; serving model Claude Opus 5.5 from about 12:30Z), for Dylan Roy (delegated AI work). Scientific effect NONE.

- **Statement.** Note C3's expansion of the candidate density, `ν_cand = cℓ^{−1/3} + B + I^{cand}ℓ^{1/4} + c₂ℓ^{1/3} + c₃ℓ^{2/3} + o(ℓ^{2/3})`, holds with
  remainder `O(ℓ^{2/3+δ})` in every `d ≥ 2` and for every `L` (same `c₃`); admissible `δ(2) = 1/30`, `δ(3) = 1/50`, `δ(4) = 1/51`, `δ(5) = 1/70`,
  `δ(6) = 1/89`. Route: C3's proofs of Lemmas F₃ and T₁ with their error terms kept and free localization exponents (Lemmas F₃-R, T₁-R),
  integrated in the fold variable with a split at `S = c_Sℓ^{−σ}` (Lemma 4). Not sharp (the formal next term is `ℓ^{3/4}`); no elder-density rate
  (note SL's `o(ℓ^{2/3})` and C7's mass are not quantified).
- **Reads (main#307).** Slice A PASS (6146023223); Slice B AMEND of one sentence of Remark 2 (6146366500), applied as v1.1 (6146713287); readback
  PASS (6146720347). All Cursor agents (xAI Grok 4.7); organizational independence 0. Before posting, an author-side same-session referee round
  (both slices AMEND, applied; not review evidence).
- **Controls.** `controls/c3r_exact.py` (E1–E3, exact rationals) and `c3r_mutants.py` (M1–M4), pinned at Math- `9232eff0` by the controls comment.
- **Custody.** Math-#452 (`frontiers/lifetime_c3r_rate_20261013/`, head `daea965d`), engineering read summoned (6146995043); `packet/` holds its
  `SOURCES.json`, `README.md`, `replay.py` and PR body.

## Landed (13 October, 14:49Z)

- **Math-#452 landed** at merge commit `dbe6c0a1` (integrator OpenAI Codex, chat `01a0bbb5…`); engineering read PASS (Cursor `bc-fb57d27c…`);
  the landed tree is the reviewed tree `bc35c180`; author landed readback PASS (6148475785), replay of the landed tree PASS in both modes.

### Files

| file | bytes | sha256 |
|---|---|---|
| `CHECKPOINT_6145310922.md` | 1480 | `e1d0fb1c18407d0d67d0868d786a081d15290cc96897c9d0452144c4c8d5172b` |
| `CLAIM_6145251763.md` | 1463 | `67ab04cef51ee18e843211be29b36264e20267d9307d01b38e236fc358f053e8` |
| `CONTROLS_COMMENT_main307_6146012232.md` | 6182 | `6ed6bcffa009a8d495ce3e3f2caaac9a61d9cf8d090da76f1861315f3009ba5f` |
| `NOTE_C3R_v1_0_main307_6145991558.md` | 28497 | `a39ddb53e05922104a57e716f9ef8f0b8e8e0b107d7c1cdd7d1bb5f15b402a2e` |
| `NOTE_C3R_v1_1_main307_6146713287.md` | 29179 | `318d3da569b7fd651dc15c97b7b2c5abf5a59753376ab2bcd95826d4cdcee7b3` |
| `READ_COMPLETE_AND_PACKET_CLAIM_6146954758.md` | 4154 | `9a88a587675317d0eced9846954fb827cad71a9816b52e57e5ff6b9f94c998de` |
| `TASK_DEFINITION_6145245957.md` | 6159 | `8a079706083d802d1b504680c35882b799879feb046d10fb52d26a5b4b705cfb` |
| `controls/C3R_PLAN_20261013.md` | 10137 | `9b1896d8b9fc094df7b25e213c7b15f60a3d27460ebdf69c4127b7a2d437f27d` |
| `controls/c3r_exact.py` | 11625 | `6d911f0a6c1b0cda5ddd579b26aeaab2c3cc557f6b95c0970a944de25380a335` |
| `controls/c3r_mutants.py` | 2027 | `6afab0e79659ff0e5064a7ca4144aef485150b521c55e611e651b1d687c6c8f3` |
| `controls/c3r_mutants_stdout.txt` | 421 | `25a233227ef286319aa312fd07e4cd508176ca2eb656dcf4d3f4fdfffca6c215` |
| `controls/c3r_stdout.txt` | 2152 | `684d06a01eefb160188e7769099cd42e8c7ccf5b3803edd3010a646e4513791d` |
| `landing/INTEGRATION_REQUEST_main307_6147324981.md` | 1524 | `61352bedd3e378ae7f4ea80c4a360b222490d67b0f72a2616ade4da048621d4c` |
| `landing/PR452_AUTHOR_HANDOFF_6147317961.md` | 1672 | `b00b7480bd9fcd873e02734d6ef9f7b2ef5b479ecaca2d6577191eff3d898684` |
| `landing/PR452_AUTHOR_LANDED_READBACK_6148475785.md` | 1513 | `b19f029ba8af6af38f3714e536f90cd7627291b6db597b43b9302ee0235f661d` |
| `landing/PR452_ENGINEERING_READ_PASS_CURSOR_bc-fb57d27c_6147261180.md` | 7563 | `7d9d2105b9ad245f4c34051fb9eb3cae3585c4b26f971b315fa44b2e7b74fd3f` |
| `landing/PR452_ENGINEERING_READ_SUMMONS_6146995043.md` | 2699 | `0005345c4932d407c87bb14bf57803bf13fee45a403440c169a380e4ba2558f6` |
| `landing/PR452_INTEGRATION_ADDENDUM_6148432700.md` | 3812 | `546b5dd0ae3353a6ac3f590ef5f6c1c890e0f3b48e3be0e7f49741492091cc4d` |
| `landing/PR452_INTEGRATION_PICKUP_CODEX_6148270479.md` | 2612 | `5a8453d866f3ef52e31169f563bb5767acfe47c55117bf2127e1dad186831206` |
| `landing/PR452_LANDED_6148307166.md` | 3335 | `0247132e2bd25b4154e367dc26a853b91dc2c46c562a9f67b6512c0c015eefb9` |
| `packet/PR452_BODY.md` | 2723 | `a247072c2ec17bf282c318f4cd0b3afa400bb5cdcb8df3cdc6d4bddcc2e071aa` |
| `packet/README.md` | 5790 | `4e7367c0619745a58c956d2d712a4b5731382c7f9f4fb5357b3ef92086948e93` |
| `packet/SOURCES.json` | 12494 | `9123a36e15772b4104dd48592623bd25565e46560e44c577202c4ffe9a7e0c80` |
| `packet/replay.py` | 10570 | `d00f4bcc1bccd9783751f568c8aa72d9ce517774139e06a36feff0ce34ce8081` |
| `reads/READBACK_PASS_CURSOR_bc-1cf2c41a_6146720347.md` | 5148 | `3cf309ce5b373d68acb7497e9b4c37563f2d3faa8b1c7112a4a716e673689b96` |
| `reads/READBACK_SUMMONS_6146718886.md` | 3231 | `0208cff35d11899a0524eedab8f04d38638642f01a99ecb56db38fbf0e26fa01` |
| `reads/SLICE_A_PASS_CURSOR_bc-994338a5_6146023223.md` | 9841 | `4f2d310f3ae961d41f14022c17fbd825c2022a24b751eb84eff93c68c594c93a` |
| `reads/SLICE_A_SUMMONS_6146021645.md` | 3522 | `1a566328f83ae243623ff21500cc0b6a2b25a0b2809fed7366766ca33a4b4eeb` |
| `reads/SLICE_B_AMEND_CURSOR_bc-ef61bc68_6146366500.md` | 7776 | `a1d5c9480396997201d5ab5021bd46673fb96e6cb929100a3074e38a05e2fb81` |
| `reads/SLICE_B_RESUMMONS_6146364489.md` | 1272 | `1893f6476ca175d2d86dd82688f06566a94339338a67b7f550dc7098ae75c7f8` |
| `reads/SLICE_B_SUMMONS_6146022030.md` | 3877 | `6d4c37da52798883fbf41e65affc29279cb3b0b9e61b747f5820f0d6790fd149` |
