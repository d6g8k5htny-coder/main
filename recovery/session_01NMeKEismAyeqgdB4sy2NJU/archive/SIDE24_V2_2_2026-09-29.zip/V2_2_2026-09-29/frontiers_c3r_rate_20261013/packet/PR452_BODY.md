**Lifetime note C3-R: exact records, the controls and a replayable checker.** Custody only. Scientific effect NONE; no status, flag, premise or prize change; no register, graph, STATUS or PROOF_INDEX edit.

**Object.** `frontiers/lifetime_c3r_rate_20261013/` (tree `bc35c180babeaea219162cae22ce31e1d0db5e35`), `tests/test_lifetime_c3r_replay.py`, `.github/workflows/lifetime-c3r-rate.yml`. D5 claim: main#307 [6146954758](https://github.com/d6g8k5htny-coder/main/issues/307#issuecomment-6146954758) (lease to 22:00Z 13 October).

**What the note is.** Note C3-R quantifies note C3: in every `d ≥ 2` and for every `L`, the candidate density's expansion holds with remainder `O(ℓ^{2/3+δ})` instead of `o(ℓ^{2/3})` (admissible `δ(2) = 1/30`, `δ(3) = 1/50`, `δ(4) = 1/51`, `δ(5) = 1/70`, `δ(6) = 1/89`), conditional on C3's sources at their stated scopes.

## Disposition
- **Head:** `daea965dca0cb0cdffc9c800782f37b5e2bb7c80`. **Author:** Anthropic Claude (session `session_01NMeKEismAyeqgdB4sy2NJU`), for Dylan Roy (delegated AI work). **Integrator:** a non-author lane (the author does not merge).
- **Mathematical reads (main#307):** Slice A PASS [6146023223](https://github.com/d6g8k5htny-coder/main/issues/307#issuecomment-6146023223); Slice B AMEND [6146366500](https://github.com/d6g8k5htny-coder/main/issues/307#issuecomment-6146366500), applied as v1.1 [6146713287](https://github.com/d6g8k5htny-coder/main/issues/307#issuecomment-6146713287); readback PASS [6146720347](https://github.com/d6g8k5htny-coder/main/issues/307#issuecomment-6146720347). All Cursor agents (xAI Grok 4.7), organizational-independence credit 0.
- **Engineering read of this PR:** to be summoned (pending).
- **Unresolved finding IDs:** none.
- **Validation (local):** `python3 -B -S` and `python3 -B -O -S` of `replay.py`: "14 stored records, 4 control files, 2 replays and 2 negative controls PASS"; the 12 protocol tests pass in both modes.
- **Next action:** engineering read; then hand off to a non-author integrator.

## Contents
- `C3R/`: 14 served comment bodies (task, claim, checkpoint, v1.0 as read, controls comment, summonses, the three verdicts, v1.1 of record, the applied-AMEND record, the read-complete note).
- `controls/`: `c3r_exact.py`, `c3r_mutants.py` and their stdout, byte-identical to the pin at Math- `9232eff05a5753f41c9ea5528f797b7bf1df1967` (checked by `replay.py` against the controls comment's table).
- `SOURCES.json` (schema 2), `replay.py` (tree, pin table, named identities, both replays with byte-identical stdout and empty stderr, two negative controls), `README.md`.

🤖 Generated with [Claude Code](https://claude.com/claude-code)

https://claude.ai/code/session_01NMeKEismAyeqgdB4sy2NJU
