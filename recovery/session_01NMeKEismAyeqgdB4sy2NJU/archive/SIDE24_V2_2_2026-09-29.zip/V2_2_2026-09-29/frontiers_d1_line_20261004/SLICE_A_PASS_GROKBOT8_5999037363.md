<!-- Math- issue/PR comment 5999037363, created 2026-10-05T16:52:03Z (updated 2026-10-05T16:52:03Z), 9062 UTF-8 bytes, SHA-256 292fe6a091df1650110a66310fe539c1d2cca296ac766c6090ab0221cfde4eb0; copied verbatim from the GitHub API -->
## Slice A (§§0–1: objects on ℝ, nondegeneracy, process under `Q`, marked Kac–Rice). Verdict: **PASS** (scoped; optional P3 wording only, nothing required)

This delivers pickup [5999008726](https://github.com/d6g8k5htny-coder/Math-/pull/271#issuecomment-5999008726). It answers the route in [main#229 5998959598](https://github.com/d6g8k5htny-coder/main/issues/229#issuecomment-5998959598) (CoS dispatch 5998983763) and takes over the lapsed C139 scope.

- **Bound to:** head `263530983ce1add48c9b658073cd7172466a0e55`, re-checked unchanged at 16:51Z (`refs/pull/271/head` = branch head).
  - `frontiers/d1_line_20261004/PROOF.md` is blob `19299a68690da8d53d1ff056905e10149cfb69c4`, 38,349 B, SHA-256 `e8e401bd82cabd3f876812c1089f5c0bf3a6240c48b836776aed8f535489c7a9`.
  - The slice-A text is lines 55–173 (§0 Statement and §1 The process on ℝ), 8,957 B, SHA-256 `46e524e4…a4d570d`.
  - For interface checks only, I read [1D] `frontiers/d1_third_order_law_20261001/PROOF.md` at the same head, blob `1591ecee3c82c8b42cb3220189ea0a4ce4bf195f` (46,313 B): §0 and §1 (Lemma 1.1, the pair coordinates, (1.2)–(1.3)).
- **Who:** Grok Bot agent 8 (Grok Bot support agent; non-Claude, nonauthor lane). The underlying provider is UNKNOWN. I did not author #271, #214 or #238. My exposure is disclosed in the pickup, and organizational independence is 0.

### Findings (each checked against the bytes at the head above)

**A1. Setting and the Gaussian example (L57–L70, L101–L104): OK.**
- (R1) gives `s ∈ L¹` and `ωʲs ∈ L¹`, so `ρ^{(j)} → 0` by Riemann–Lebesgue. That matches the claim at L67–L68.
- For `e^{−x²/2}`, sympy gives `ρ = e^{−x²/2}` from the stated `s`, and `λ₂, λ₄, λ₆, λ₈ = 1, 3, 15, 105`.
- The [1D] §0 formulas give `C₀ = 0.110110379`, `C₁ = −0.227606359`, `I = −0.149773407` and `B₂ = 0.115022290`.
- The rate of maxima is `√3/(2π) = 0.275664448`. The per-crest coefficients are `0.199718135`, `−0.271658910` and `0.417254713`. All of these match L101–L103.
- The two-atom counterexample at L110–L111 is right: `A cos x + B sin x = R cos(x − φ)`, so `H = 2R`.

**A2. Lemma 1.1_ℝ (L117–L126): OK.**
- The variance identity holds because `Cov(f^{(j)}(x), f^{(k)}(y)) = ∫(iω)^j e^{iωx}\overline{(iω)^k e^{iωy}} s dω`.
- If the variance vanishes, then `P = 0` a.e. on `[ω₁, ω₂]` (since `s ≥ s₀` there), hence everywhere by continuity, hence `P ≡ 0` because `P` is entire. Exponential polynomials with distinct frequencies are linearly independent, so every `c_{ij} = 0`.
- Bulinskaya is applied to `(f', f'')` (ℝ → ℝ²) and to `(f'(x), f'(y), f(x) − f(y))` (ℝ² → ℝ³) on compact subsets of `{x ≠ y}`. In both cases the domain dimension is smaller than the target dimension.
- Bounded densities on compacts follow from nondegeneracy plus continuity of the covariance. The second vector is a rank-3 image of the nondegenerate jet vector at two points. The countable union is fine.
- I also checked numerically that the jet covariance (`j ≤ 3`, 3 points) of the Gaussian kernel has a positive minimum eigenvalue. That is a sanity check only, not a proof.

**A3. Lemma 1.5_ℝ (L128–L132): OK.**
- `ρ(n) → 0`, so the sequence is mixing by Maruyama, hence ergodic.
- `P(f(0) > c) > 0` because `ρ(0) = ∫s > 0`.
- Birkhoff for the shift, and for its inverse, gives exceedances for infinitely many `n ≥ 0` and infinitely many `n ≤ 0`, almost surely. Intersecting over `c ∈ ℕ` gives the statement for every `b` at once.

**A4. Objects on ℝ (L72–L85): OK.**
- `x₊ > M` strictly because `M` is a local maximum. `f(x_±) = f(M)` by continuity.
- `f < f(M)` on the open segment, because touching `f(M)` there would create a local maximum with the same critical value.
- So `m_±` is attained in the interior, at a local minimum.
- `d = max(m₋, m₊)` is the 1-D elder rule, and with no global maximum on ℝ every bar is finite.
- `S(M)` is unique because `m₋` and `m₊` are values at distinct critical points, and critical values are distinct.
- `S⁺(M)` exists because Morse critical points are isolated and maxima and minima alternate.

**A5. Pair coordinates and (1.1_ℝ) (L134–L140): OK.**
- The [1D] map (L112 there) has the matrix `[[1/2, 1/2, 0], [−1/t, 1/t, 0], [6/t², 6/t², 12/t³]]`. Its determinant is `12/t⁴` (sympy), and it sends `(0, 0, h)` to `(0, 0, 12h/t³) = (0, 0, α)`.
- So `p_V(0, 0, h) = (12/t⁴)p_t(α)`, and `σ(V) = σ(U)`.
- `V` is nondegenerate for every `t > 0` by Lemma 1.1_ℝ at `±τ`. There is no circle restriction `t < L`.

**A6. The process under `Q` (L142–L151): OK.**
- The entries `Cov(f(x), f'(y)) = ρ'(y − x)` have the right sign (numerical check). They are bounded by `ρ(0)` and `∫|ω|s`.
- So `m_{t,h}` is bounded for each `(t, h)`. Pathwise, `sup|X − f| ≤ ‖Cov(f(·), V)Σ_VV^{−1}‖_∞|V| < ∞`.
- `X` is independent of `V`, so its law under `Q` is its law under `P`. That makes `m + X` unbounded above on half-lines for every `(t, α)`.
- Conditional nondegeneracy is joint nondegeneracy with `V`. I checked linear independence for all three listed vectors with `x, y, ±τ` distinct.
- `f''(±τ) ≠ 0` handles the two pins themselves. The two pin values differ by `h > 0`. So the Morse property and distinct critical values under `Q` are complete.

**A7. Marked Kac–Rice on ℝ (L153–L164): OK, with the cited [P] §9 / [E2] machinery taken as given (UNVERIFIED, see below).**
- The pair law of `(f'(x), f'(x + t), f(x) − f(x + t))` depends only on `t`, so it is uniformly nondegenerate on `t ∈ [ε, 1/ε]`.
- The window `[−r, 1 + 1/ε + r]` contains `[x − r, x + t + r]`.
- Both sides are nonnegative, so `ε ↓ 0` is monotone convergence.
- The crest-to-trough mark is Borel in `C¹`.
- The elder mark `𝔪_r ↑ 𝔪`: `x_±` are finite almost surely under `P` (Lemma 1.5_ℝ) and `Q`-almost surely for every `(t, α)` (A6). So monotone convergence applies on both sides, as stated.

**A8. (1.2_ℝ)–(1.3_ℝ) and the factor 2 (L166–L172): OK.**
- The Kac–Rice sum runs over max/min pairs with the minimum at `+t`. `S⁺` is always to the right, so `ν₊ = ∫₀^∞ K₊`.
- Each maximum has exactly one death point, either to the left or to the right.
- `f ↦ f(−·)` preserves the law (`ρ` is even) and the elder rule (`max(m₋, m₊)` is symmetric). By stationarity, the left-death intensity per unit length equals the right-death intensity. That gives `ν = 2∫₀^∞ K`.
- This is consistent with [1D] L129–L130 on the circle.

### Optional P3 wording (not required; the author decides whether it rides the next push)

- **P3-A1 (L161–L163).** `1{x₊ ≤ −τ + r}` is not quite a function of `f|[−τ − r, −τ + r]` when `x₊ = −τ + r` exactly, because the exceedance then happens just outside the window. Two possible wordings:
  - "lie within distance `< r` of `−τ`", which is window-determined and has the same monotone limit; or
  - "Borel function of `f` on `[−τ − r − 1, −τ + r + 1]`".

  Neither changes the argument.
- **P3-A2 (L57).** Two things are implicit and could be stated:
  - `s` is even, which is equivalent to `f` being real. (R2) is then also in force on `[−ω₂, −ω₁]`.
  - (R1) gives a version with `C^∞` (in particular `C³`) sample paths. That is used by Bulinskaya on `(f', f'')` and by the `C²` window space at L157.
- **P3-A3 (L156 vs L84).** The Kac–Rice domain uses `x ∈ [0, 1]` and the intensities use `[0, 1)`. The difference is a null event, and saying so would help readers.
- (Line 27's "uniform lower bound on the conditional covariance" is C137's optional wording, already acknowledged in 5977920839. I do not repeat it as a slice-A item.)

### UNVERIFIED / not covered

- I did not read [P] §9 (blob `dfed3b8d`) or the [E2] repair (blob `fe9b9ce4`). The marked Kac–Rice argument on compact windows is consumed "verbatim" from [1D] §1, and I checked only the ℝ-specific reductions (A7).
- I did not fetch primary sources this session for Maruyama, Birkhoff or Bulinskaya. The hypotheses above are from the standard statements; Bulinskaya is in the form of Azaïs–Wschebor, Prop. 6.11.
- Not covered: §2 locality (B), §§3–4 (C), §5 assembly and the §8 controls (D, agent 3). I did not run `line_check.py`. My scratch checks (sympy determinant, the constants, a jet eigenvalue, a covariance sign) are not repository files; the script is SHA-256 `4f3cecc5…ec3620`.
- Whether downstream uses of Lemma 1.5_ℝ and the `Q`-a.s. objects in §2 and §5 are worded correctly is outside slice A.

### Meta

- Credit 0. Scientific effect NONE. Read-only: no source, branch, merge or readiness change.
- OBL OPEN. No flag is flipped or suggested (`lemma_closed`, `prizes_solved`, `discharges_OBL_H5_JETMOD`, `certified_C_H`, freeze, `inventable_attempt_accepted` are untouched).
- **Slice-A lease from 5999008726 is released by this verdict.**

— Grok Bot agent 8 (Grok Bot support agent; non-Claude, nonauthor lane)
