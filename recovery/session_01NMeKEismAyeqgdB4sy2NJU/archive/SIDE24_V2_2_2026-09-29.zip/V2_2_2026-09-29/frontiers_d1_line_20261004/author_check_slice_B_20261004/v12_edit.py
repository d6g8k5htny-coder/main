#!/usr/bin/env python3
"""Apply the #271 v1.2 wording changes (C137 rider + author-side slice-B self-check F1-F5) to a packet directory.

Usage: python3 v12_edit.py <packet_dir>
Every replacement must match exactly once; otherwise the script stops without writing.
"""
import pathlib
import sys

d = pathlib.Path(sys.argv[1])
proof = (d / 'PROOF.md').read_text(encoding='utf-8')
readme = (d / 'README.md').read_text(encoding='utf-8')

R = []  # (file, old, new)

# --- header -------------------------------------------------------------------------------------------------------
R.append(('PROOF', 'Object: CL-D1-LINE-20261004-v1.1.\n', 'Object: CL-D1-LINE-20261004-v1.2.\n'))
R.append(('PROOF', 'Disposition: AUTHOR-SIDE PROOF CANDIDATE; NONAUTHOR REVIEW REQUIRED.',
          '**v1.2 (wording; no statement, hypothesis, constant, rate or control changes).** It applies C137\'s optional\n'
          'wording for the role of Ingham\'s inequality (review 5404906339). It also applies an author-side check of §2, the open\n'
          'slice B, by a same-provider subagent (not review evidence). §2 had discharged the global-maximum alternative only for\n'
          '[1D] Lemma 3.3 and the realized `f`; it now covers [1D⁺] Lemma W and the fields `f_φ` of [1D⁺] Proposition M. Four\n'
          'wording points come from the same check: the domain of a Taylor remainder and the notation `t₁` (§2), the inputs of\n'
          'the transferred proofs (§2), the void cap `t₀ ≤ L/4` (§5), and the scope labels of the dependencies (header, §2, §7).\n'
          'Disposition: AUTHOR-SIDE PROOF CANDIDATE; NONAUTHOR REVIEW REQUIRED.'))
# C137 rider (optional wording, 5404906339)
R.append(('PROOF',
          '- Ingham\'s inequality, for a uniform lower bound on the conditional covariance of many well-separated derivative samples;',
          '- Ingham\'s inequality, for a lower bound on all but at most three eigen-directions of the conditional covariance of\n'
          '  many well-separated derivative samples;'))
# F5: dependency labels in the header
R.append(('PROOF',
          '  part of Lemma 4.3 on `[t_*, t₀]`; §5.\n',
          '  part of Lemma 4.3 on `[t_*, t₀]`; §5, the adjacency estimate.\n'))
R.append(('PROOF',
          '  §§1–4 (Lemma E, Proposition 2.2⁺, Lemmas Φ and W, Proposition M, and the assembly).\n',
          '  §§1–3 (Lemma E, Proposition 2.2⁺, Lemmas Φ and W, Proposition M), and the part of §4 on `(0, t_*]`.\n'))

# --- section 2 ----------------------------------------------------------------------------------------------------
# F3: the inputs (finitely many points)
R.append(('PROOF',
          '- the nondegeneracy of finitely many derivatives at one or two points (Lemma 1.1_ℝ, in place of [1D] Lemma 1.1);',
          '- the nondegeneracy of finitely many derivatives at finitely many distinct points: the pins, the midpoint and the\n'
          '  sample points of [1D] Lemma 4.2 (Lemma 1.1_ℝ, in place of [1D] Lemma 1.1);'))
# F5: the replaced global parts
R.append(('PROOF',
          '  global maximum, by Lemma 1.5_ℝ, under which no global maximum exists.\n',
          '  global maximum, by Lemma 1.5_ℝ, under which no global maximum exists;\n'
          '- the far form of [1D] Lemma 4.2 and the part of [1D] Lemma 4.3 on `[t₀, L)` with its co-banded bound, by Lemma 3.1_ℝ\n'
          '  and Lemma F_ℝ; and the circle assemblies ([1D] §5 apart from the adjacency estimate, [1D⁺] §4 on `[t_*, L)`), by §5.\n'))
# F1: Lemma W and the fields f_phi
R.append(('PROOF',
          '- [1D] Lemma 3.3 holds on `ℝ`, and its global-maximum alternative does not occur.\n',
          '- [1D] Lemma 3.3 holds on `ℝ`, and its global-maximum alternative does not occur: under `Q` every maximum of `f` has a\n'
          '  finite bar (§1). The same holds for [1D⁺] Lemma W, read with "a function `f_φ` on `ℝ`", and for its use in [1D⁺]\n'
          '  Proposition M on the fields `f_φ = f + (φ − φ_G)m(ψ − ψ(τ))`, for every `φ` given `ω`. There\n'
          '  `ψ(x) = Cov_Q(f_e(x), E₁)/v₁` is built from `ρ′(τ ± x)` and `ρ″(τ ± x)`, so it is bounded by (R1), and each `f_φ`\n'
          '  differs from `f` by a bounded function. So, on the `Q`-almost sure event of §1, each `f_φ` is unbounded above on both\n'
          '  half-lines, and every maximum of `f_φ` has a finite bar. In particular, when both arcs fall below `−1` (the edge `J₋`\n'
          '  with `μ₋(φ) ≤ 0`, or the negative case of [1D] Lemma 3.3 (R)), `𝔖` is not the death point of `𝔐`.\n'))
# F2: the Taylor remainders of [1D] Lemma 1.3, and t_1
R.append(('PROOF',
          '  Also `t_* := (12h)^{1/(5−δ)}` with `δ ∈ (0, 1/10]`, as in [1D] Proposition 2.2; §5 takes `δ = 1/10`.\n',
          '  Also `t_* := (12h)^{1/(5−δ)}` with `δ ∈ (0, 1/10]`, as in [1D] Proposition 2.2; §5 takes `δ = 1/10`. Here\n'
          '  `t₁ := h^{1/10}` is [1D]\'s notation (its Lemma 4.3), unrelated to `T₁` of Lemma 4.1_ℝ. The same band reading applies\n'
          '  to the Taylor remainders `τ^K sup|f^{(K+1)}|` in the proof of [1D] Lemma 1.3: the supremum is over `[−τ, τ]`.\n'))
# F3: the extra inputs of [1D+]
R.append(('PROOF',
          '  Each is a supremum or a moment over `[−2t, 2t]`, bounded by Sudakov–Fernique and Borell–TIS on a compact interval.\n',
          '  The first, third and fourth are suprema or moments over `[−2t, 2t]`, bounded by Sudakov–Fernique and Borell–TIS on\n'
          '  a compact interval. The second also gives `sup_{t≤t₀}sup_{[−2t,2t]}|μ_t^{(5)}| < ∞` in (Φ.2), through the continuity\n'
          '  of `(t, x) ↦ μ_t^{(5)}(x)` (by (R1)) and the nondegenerate limit of [1D] Lemma 1.3.\n'))

# --- section 5 (F4) -----------------------------------------------------------------------------------------------
R.append(('PROOF',
          'Fix `δ = 1/10` and `t₀` as in [1D⁺] §4 (small enough for [1D] Lemma 4.3), and `T₀ ≥ t₀` as in Lemma F_ℝ. By (2.1),\n'
          'Lemma 3.1_ℝ and Lemma F_ℝ,\n',
          'Fix `δ = 1/10` and `t₀` as in [1D⁺] §4 (small enough for [1D] Lemma 4.3), and `T₀ ≥ t₀` as in Lemma F_ℝ. On `ℝ` the cap\n'
          '`t₀ ≤ L/4`, which [1D⁺] §4 inherits from the far form of [1D] Lemma 4.2, is void: that form is not used. By (2.1),\n'
          'Lemma 3.1_ℝ and Lemma F_ℝ,\n'))

# --- section 7 (F5) -----------------------------------------------------------------------------------------------
R.append(('PROOF', '| consumed: §§0–5 as listed above |', '| consumed: the parts listed in §2 (§§0–4, and the adjacency estimate of §5) |'))
R.append(('PROOF', '| consumed: §§0–4 |', '| consumed: §§0–3, and §4 on `(0, t_*]` |'))

out = {'PROOF': proof, 'README': readme}
for f, old, new in R:
    n = out[f].count(old)
    if n != 1:
        sys.exit('replacement not unique (%d matches) in %s: %r' % (n, f, old[:80]))
    out[f] = out[f].replace(old, new)
(d / 'PROOF.md').write_text(out['PROOF'], encoding='utf-8')
(d / 'README.md').write_text(out['README'], encoding='utf-8')
print('applied', len(R), 'replacements')
