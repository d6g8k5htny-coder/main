# Slice B audit: CL-D1-LINE-20261004-v1.1, §2 ("What transfers from the circle")

Referee: Anthropic Claude subagent with a clean context. It shares a provider with the author, so this is **not review
evidence**.
Packet: `frontiers/d1_line_20261004/PROOF.md` at Math- #271 head `263530983ce1add48c9b658073cd7172466a0e55` (read only).
Sources: [1D] = `origin/main:frontiers/d1_third_order_law_20261001/PROOF.md`, blob `1591ecee3c82…`; [1D⁺] =
`origin/main:frontiers/d1_sharp_remainder_20261001/PROOF.md`, blob `8dc558a735f8…`. Both equal the pins in `SOURCES.json`.

## Verdict: AMEND (minor, non-blocking)

Every result that §2 lists is local, and (H_ℝ) supplies every ingredient its proof uses. Beyond what §2 already
replaces, no listed proof uses compactness of `T`, finiteness of the critical set, Fourier positivity, `L^{−1}`,
`t ∈ (0, L)`, `K(t) = K(L − t)`, wrap-around, the co-banded arc, covariance decay, or a constant taken over the whole
circle. The three points and the two banded facts are correct, and §§3–5 make no undeclared transfer.

One sentence is required (F1). The hypothesis of [1D⁺] Lemma W is stated for "a function `f_φ` on `T`", and
Proposition M applies the lemma to counterfactual fields `f_φ` with `φ ≠ φ_G`. §2 discharges the global-maximum
alternative only for [1D] Lemma 3.3, and only for the realized `f`. An external reviewer would probably ask for this
sentence. On the circle, Codex asked for the matching clarification in Lemma 3.3 ([1D] v1.3). F2–F5 are optional
wording changes. No finding changes any statement, constant or rate.

## Item table

| # | Item | Ruling |
|---|---|---|
| 1 | [1D] Lemma 1.2, (1.4) | PASS. Reflection about the midpoint; `f(−·)` has the law of `f` because `ρ` is even. `Q` exists for every `t > 0` (Lemma 1.1_ℝ). |
| 2 | [1D] Lemma 1.3 | PASS. Its quantities are covariances; the bounds on `p_t` need only the limit `Cov U → Cov(a₁,a₂,a₃)`. See F2 (a `sup` with no domain). |
| 3 | [1D] Remark 1.4 | PASS. Uses only that `ρ` is even. |
| 4 | [1D] §2: sign kernels, `γ_θ`, `ζ_θ`, Lemma 2.1 | PASS. Pure Gaussian and Mellin identities. |
| 5 | [1D] Prop. 2.2 (a)–(e) | PASS. Integrates explicit model kernels over `(0, t_*]` or `(0, ∞)`; uses Lemma 1.3 only for `t ≤ t₀`. No `L` appears. |
| 6 | [1D] Lemma 3.1 | PASS. Deterministic, on `[−2t, 2t]`. |
| 7 | [1D] Lemma 3.2 | PASS. On `T` the window needs `4t < L`; on `ℝ` that is vacuous. |
| 8 | [1D] Lemma 3.3 | PASS. Point 1 is correct; F1 adds the citation of §1. |
| 9 | [1D] Corollary 3.4 | PASS. |
| 10 | [1D] Lemma 4.1 | PASS. Markov's inequality on `[−τ, τ]`. |
| 11 | [1D] Lemma 4.2, near form | PASS. Only the far form uses "`t₀ ∈ (0, L/4]`, uniformly in `t ∈ (0, L)`", and the far form is not used. |
| 12 | [1D] Lemma 4.3 on `[t_*, t₀]` | PASS with point 2's band reading. `K = sup_{[−τ,τ]}|f^{(10)}|`; the density of `(a₄,…,a₉)` given `U`; the near form of Lemma 4.2. |
| 13 | [1D] §5, adjacency estimate | PASS. `K₅` is a supremum over `[−2t, 2t]`, its `Q`-mean is `≤ C(1 + α)`, and the bound uses Borell–TIS together with `p_t ≤ Ce^{−α²/(4σ₃²)}`. |
| 14 | [1D⁺] Lemma E | PASS. |
| 15 | [1D⁺] Prop. 2.2⁺ | PASS. Uses Lemma 1.3 for `t ≤ t₀`. |
| 16 | [1D⁺] Lemma Φ | PASS; see F3 (the ingredient list understates two inputs). |
| 17 | [1D⁺] Lemma W | **F1** |
| 18 | [1D⁺] Prop. M | **F1** for the counterfactual `f_φ`; otherwise PASS. Its moments and tails are over `[−2t, 2t]`, and its integrals are over `(0, t_*]` or `(0, ∞)`. |
| 19 | [1D⁺] §4 on `(0, t_*]` | PASS; see F4 (the inherited `t₀ ≤ L/4`). |
| P1 | Lemma 3.3's global-maximum alternative | PASS; extended in F1. |
| P2 | Band reading, (2.1), `t_*` | PASS (below). |
| P3 | Extra inputs of [1D⁺] | PASS in substance. Lemma W is missing (F1); wording in F3. |
| B1 | An adjacent typed pair is banded | PASS. |
| B2 | An elder pair is banded; no co-banded case on `ℝ` | PASS (below). |
| X | Converse: §§3–5 | PASS: no undeclared transfer. Scope labels in F5. |

## Findings

### F1. Lemma W and Proposition M: `f_φ` "on `T`" and the counterfactual fields (REQUIRED, minor)

Quotations from [1D⁺]:
- Lemma W, hypotheses (l. 289): "for each `φ`, `F_φ` is the window field of a pair `(𝔐, 𝔖) = (−½, ½)` of a function `f_φ`
  on `T`."
- Edge `J₋` (l. 352–357): "The arc falls below `−1` before exceeding `0`, as in [1D] Lemma 3.3 (E) for `φ < 0`. So
  `m₋ < −1`. … Hence `𝔖` is the death point iff `μ₋(φ) > 0`."
- Prop. M (l. 377–389): "conditionally on `ω`: … the field (3.1) for each value of `φ_G`, are functions of `(ω, φ_G)` …
  by (W.1) `E_Q[w 1{elder} | ω] = ∫_{φ₋}^{φ₊} W p_s dφ`."

**Why §2 needs more.** If `μ₋(φ) ≤ 0`, both arcs fall below `−1` before exceeding `0`.
- On `T`, the "only if" direction then rests on [1D] Lemma 3.3's alternative (l. 299): "if it is [the global maximum],
  `𝔐` has no finite partner". (W.1) also cites Lemma 3.3 directly for `φ` away from the edges.
- On `ℝ`, the death point of §0 needs `x_±` to be finite. §1 proves this `Q`-almost surely, but only for `f`.
- Prop. M needs it for `f_φ = f + (φ − φ_G)m(ψ − ψ(τ))` for every `φ` (or almost every `φ`) given `ω`.

§2's first point covers neither Lemma W nor `f_φ`, and it cites Lemma 1.5_ℝ, a statement under `P`, rather than §1.

**Does (H_ℝ) supply it?** Yes. `ψ(x) = Cov_Q(f_e(x), E₁)/v₁ = [Cov(f_e(x), E₁) − Cov(f_e(x), U₂)Cov(U₂, E₁)/Var U₂]/v₁`
combines `ρ''(τ ± x)` and `ρ'(τ ± x)`, which are bounded by (R1). So `f_φ − f` is bounded.

**Replacement for §2's first point:**
> - [1D] Lemma 3.3 holds on `ℝ`, and its global-maximum alternative does not occur: under `Q` every maximum has a finite
>   bar (§1). The same holds for [1D⁺] Lemma W, whose hypothesis "a function `f_φ` on `T`" becomes "on `ℝ`". It also holds
>   for Proposition M, which applies Lemma W to `f_φ = f + (φ − φ_G)m(ψ − ψ(τ))` for every `φ` given `ω`.
>   Here `ψ(x) = Cov_Q(f_e(x), E₁)/v₁` combines `ρ'(τ ± x)` and `ρ''(τ ± x)`, so it is bounded by (R1). So, on the
>   `Q`-almost sure event of §1:
>   - every `f_φ` is unbounded above on both half-lines, and each of its maxima has a finite bar;
>   - when both arcs fall below `−1` (the edge `J₋` with `μ₋(φ) ≤ 0`, or the negative case of [1D] Lemma 3.3),
>     `d(𝔐) < F(𝔖)`.

### F2. The Taylor remainders of [1D] Lemma 1.3, and `t₁` (OPTIONAL)

Quotation ([1D] Lemma 1.3, proof, l. 156): "Taylor's formula at `0` (all `a_j`, remainders bounded by
`τ^K sup|f^{(K+1)}|`)". This supremum has no domain. Point 2 resolves the same ambiguity for Lemma 4.3 (l. 372). On `ℝ`
the global supremum is infinite. (R1) and Sudakov–Fernique with Borell–TIS on `[−τ, τ]` supply the bound.

Separately, packet l. 198 uses `t₁` without defining it.

**Append to point 2:**
> The same reading applies to the Taylor remainders in the proof of [1D] Lemma 1.3: the supremum is over `[−τ, τ]`. (The
> quantities of Lemma 1.3 are covariances, so they can also be expanded from the Taylor series of `ρ` at `0`, as [1D]'s
> checker C4 does.) Here `t₁ := h^{1/10}` is [1D]'s notation, unrelated to `T₁` of Lemma 4.1_ℝ.

### F3. The ingredient list understates two inputs (OPTIONAL)

Quotations from the packet: "the nondegeneracy of finitely many derivatives at one or two points" (l. 185); "Each is a
supremum or a moment over `[−2t, 2t]`" (l. 212).

**Why.**
- Several listed proofs condition the midpoint jets, or the samples `f'(τξ_i)`, on the pin values. That involves three
  points, or `N + 2` points, unless `τ₀` is shrunk until only the limit matters. The instances:
  - [1D] Lemma 4.3, near part (l. 365–366): "`(a₄, …, a₉)` has a density bounded uniformly in `τ ≤ τ₀` …
    (`Cov(a₄..a₉ | U) → …`)";
  - the near form of [1D] Lemma 4.2;
  - (Φ.1): "`V := Var_Q a₄ → σ₄²`".
- The invertibility item is neither a supremum nor a moment. Neither is the bound that (Φ.2) derives from it (l. 257–260),
  "`sup_{t ≤ t₀}sup_{[−2t,2t]}|μ_t^{(5)}| < ∞`", which uses continuity in `(t, x)` and the limit in Lemma 1.3.

Both are supplied by Lemma 1.1_ℝ (for any finite set of points) and by (R1).

**Replacement.**
- At l. 185: "the nondegeneracy of finitely many derivatives at finitely many distinct points (the pins, the midpoint
  and the points `τξ_i` of [1D] Lemma 4.2), by Lemma 1.1_ℝ in place of [1D] Lemma 1.1;"
- At l. 212: "The first, third and fourth are suprema or moments over `[−2t, 2t]`, bounded by Sudakov–Fernique and
  Borell–TIS on a compact interval. The second gives `sup_{t≤t₀}sup_{[−2t,2t]}|μ_t^{(5)}| < ∞` through the continuity of
  `(t, x) ↦ μ_t^{(5)}(x)` (by (R1)) and the nondegenerate limit of [1D] Lemma 1.3."

### F4. The inherited cap `t₀ ≤ L/4` (OPTIONAL)

Quotations:
- [1D⁺] §4 (l. 441–442): "`t₀` as in Proposition 2.2⁺, small enough also for [1D] Lemma 4.3 (whose own `t₀` is a fixed
  constant in `(0, L/4]`)";
- [1D] Lemma 4.2 (l. 337–338): "(Far form) Fix `t₀ ∈ (0, L/4]`."

The packet's §5 takes "`t₀` as in [1D⁺] §4". The cap comes from the far form, which is not transferred, and on `ℝ` it
is void.

**Add in §5, after "small enough for [1D] Lemma 4.3":**
> On `ℝ` the cap `t₀ ≤ L/4`, which [1D⁺] §4 inherits from the far form of [1D] Lemma 4.2, is void, and that form is not
> used. Take `t₀ ≤ 1` so small that, for `t ≤ t₀`, [1D] Lemma 1.3 and the near form of Lemma 4.2 hold, and [1D⁺]
> Proposition 2.2⁺ and Lemmas Φ and W apply.

### F5. Scope labels outside §2 (OPTIONAL)

Quotations:
- Dependencies (l. 36–41): for [1D], "…; §5."; for [1D⁺], "Used: §0, and §§1–4 (Lemma E, …, and the assembly)";
- the §7 table: "[1D⁺] … consumed: §§0–4".

§2 correctly narrows these to "in §5, the adjacency estimate" and "the part of §4 on `(0, t_*]`". The parts it leaves
out use the far Lemma 4.3 and the co-banded bound: [1D⁺] §4 on `[t_*, L)`, and the ranges `[t₀, L)` and `[t_*, L/2]`
of [1D] §5. Also, §2's list of replaced global parts names only [1D] §§0–1. `SOURCES.json` already states the full
picture.

**Replacement.**
- "§5" becomes "§5 (the adjacency estimate)".
- "§§1–4 (…, and the assembly)" becomes "§§1–3 (…) and §4 on `(0, t_*]`".
- "§§0–4" becomes "§§0–3 and §4 on `(0, t_*]`".
- Add to §2's list of replaced global parts:
  > - the far form of [1D] Lemma 4.2, the far part of [1D] Lemma 4.3 (`t ≥ t₀`) with its co-banded bound, and the ranges
  >   `[t₀, L)` and `[t_*, L/2]` of [1D] §5 and [1D⁺] §4, by Lemma 3.1_ℝ, Lemma F_ℝ and §5.

## The three points, the banded facts and the converse

**P1 is correct.** Finite bars hold `Q`-almost surely by §1. F1 extends the point to Lemma W.

**P2 is correct.**
- [1D] applies Landau's inequality on subintervals `Δ ⊂ [−τ, τ]` with `osc ≤ h`.
- On `[t₁, t₀]`, the interval term `2h/|Δ| ≤ Ch^{9/10}` is below `h^{1/2}` for small `h`.
- Truncating `sup_{[−τ,τ]}|f''|` at `C(log 1/h)^{1/2}` costs `O(h^{10})`, by Sudakov–Fernique and Borell–TIS on a compact
  interval.
- (2.1)'s `K^{band}`, "banded" and `t_* = (12h)^{1/(5−δ)}` match [1D] Lemma 4.3 and Proposition 2.2 verbatim
  (`t ≤ t_* ⟺ α ≥ t^{2−δ}`).
- The near-part exponent `3 − 11/(5 − δ)` equals `37/49 ≥ 3/4` at `δ = 1/10`; it is `≥ 3/4` exactly when `δ ≤ 1/9`.
- "`sup_ℝ|f''| = ∞` a.s." is right: `f''` is stationary and ergodic, since `ρ^{(4)} → 0`.

**P3 is correct in substance.** It omits Lemma W (F1); wording in F3.

**B1 is correct:** `f' < 0` on `(−τ, τ)`.

**B2 is correct.**
- `S(M)` minimizes `f` on `[M, x₊]`, and `f ≤ f(M)` there by the definition of `x₊`.
- The critical values are distinct, so a death point at `+t` comes from `m₊`.
- `ℝ` has no other arc, so there is no co-banded case.

**The converse (§§3–5) is clean.**
- Lemma 3.1_ℝ re-proves [1D]'s far argument on `[t₀, T₀]`: the density bound from Lemma 1.1_ℝ and compactness, and
  Sudakov–Fernique with Borell–TIS on `[0, T₀]`. `SOURCES.json` declares this as a replacement; it is not a transfer.
- §4 uses no circle result.
- §5 uses only listed items: [1D] Lemma 3.1, the adjacency estimate, (1.4) through Lemma 1.2, [1D⁺] Proposition 2.2⁺
  and Proposition M, and the constants of [1D] §0.

## What I verified

- **Blobs.** `git rev-parse` and `git hash-object` give `1591ecee…` and `8dc558a7…`, equal to `SOURCES.json`. The
  packet's HEAD is `26353098…`.
- **Reading.** The packet's §§0–2 in full, §§3–6 and the README; every listed proof in [1D] and [1D⁺].
- **Searches.** Both circle files, for `T`, `L`, `L/2`, `L/4`, `(0, L)`, `sup_T`, "compact", "global", "Fourier",
  `ρ̂`, "co-band", "finitely" and "decay", plus every `sup` with its domain. The only `sup`s without a domain are [1D]
  l. 156 (F2) and l. 372 (point 2). Every other global hit lies in a part that is replaced or not used.
- **Checks.** `3 − 11/(5 − δ)` in exact rationals. By hand: `f_φ − f` from [1D⁺] (3.1), and the boundedness of `ψ`;
  the parity split; the identity `U(Rf) = (−U₁, U₂, −U₃)`; and the near-part exponents of [1D] Lemma 4.3.
