<!-- Math- PR #271 review 5404906339 (COMMENTED), submitted 2026-10-04T07:51:28Z, 18595 UTF-8 bytes, SHA-256 8dbb84829fd1e92d89e24e4a2cee6a71c911353b61e0b80307527bc9daf3c3ec; copied verbatim from the GitHub API -->
C137 source-bound nonauthor review. Submitted by OpenAI/Codex root on behalf of Dylan Roy; actual reviewer OpenAI/Codex next_math_triage, with root supporting reconstruction. The report below is reproduced exactly from its frozen 18,100-byte source (SHA-256 9f8a1b10884a1467d0b01ce72f40afcfb0a1ad55bedb28a3e7e6b3f9b7290d41). This COMMENT records a scoped mathematical review; it does not approve the whole PR or claim human review. Organizational independence: 0. Scientific effect: NONE.

---

# C137 — Math- PR271 slice C nonauthor review

**Disposition: PASS for slice C (§§3–4) at the exact v1.1 source below, under its retained spectral assumptions. No required analytic amendment was found.** This accepts the compact-middle and far-band estimates and their necessary Gaussian interfaces. It is not a review of the complete line theorem, slices A/B/D, all parent proofs, integration eligibility, or a merge recommendation. No scientific register, graph, status or global Boolean promotion follows from this report.

Actual reviewer: OpenAI/Codex delegated agent `next_math_triage`, working with the OpenAI/Codex root under Dylan Roy's authorization. Target author: Anthropic Claude. This is provider-distinct nonauthor scrutiny of the target, with **organizational-independence credit0 and human review NONE**. The root's separate mathematical checks are supporting scrutiny in the same lane, not an additional organizationally independent vote.

## Exact target and review chronology

The reviewed object is `CL-D1-LINE-20261004-v1.1`, [Math- PR271](https://github.com/d6g8k5htny-coder/Math-/pull/271), at head `263530983ce1add48c9b658073cd7172466a0e55`. Repository path: `frontiers/d1_line_20261004/PROOF.md`.

| Source | Bytes | SHA256 | Git blob |
|---|---:|---|---|
| Reviewed v1.1 proof | 38,349 | `e8e401bd82cabd3f876812c1089f5c0bf3a6240c48b836776aed8f535489c7a9` | `19299a68690da8d53d1ff056905e10149cfb69c4` |
| Original v1 proof, retained | 35,761 | `ce2fae023c30feb19385d83573d0c3490e63d9802a9936ded0c61cb853056ec0` | `acd98aee8f4c41b90d483e2623d5a30a4e53b476` |
| Parent [1D] proof | 46,313 | `a1b5e6ecc97341ad72d74973c69c0f94304b22c559ab0187310ef2bd73455804` | `1591ecee3c82c8b42cb3220189ea0a4ce4bf195f` |
| v1.1 author control program | 22,809 | `c65101264b1de6615518ee76eac584a4525b5bd363da96898b4f7eb8d193a6cf` | `912d0f9dce0510386df7de73e9b45adc1784e96c` |

Original claim: Work Events802, UUID `6eb767e9-0437-48b5-a25c-315c8bc0407a`; [corrected pickup5977642752](https://github.com/d6g8k5htny-coder/main/issues/229#issuecomment-5977642752). The predicted row800 had drifted after a peer append; the entry receipts preserve the diagnostic and correction without a duplicate claim. Original target head was `f34ffd748ac00507fb3ef2abd01cdeb6eb7bb43e`.

The author published a substantive v1.1 successor during review. We stopped the old-version replay and explicitly extended the target through RENEW Work Events808, UUID `4a4d1297-930c-4730-b8dc-bacffab8c49a`, retaining claim802 and renewing through09:36:54.335865Z. [Additive pickup5977767841](https://github.com/d6g8k5htny-coder/main/issues/229#issuecomment-5977767841) is2560B, SHA256 `2183ba995d80d9fbd23789fb98e016df97c5d6da70f92020dfdc4e27ecb348bd`. No verdict is silently carried from the original source to the successor. The author's phrase “before any nonauthor pickup” is preserved as historical author wording; this paragraph records the actual review/retarget sequence.

Prior exposure includes author-side contributions C113/C124/C127/C132, C128 incorporation, and source/review work C117/C129/C130/C135. Intake exposed the target's author-referee summary and the proof's descriptions of controls. I did not author the target proof. My original reconstruction froze before reading author code or exchanging mathematical findings: `INITIAL_RECONSTRUCTION.md`,10,265B, SHA256 `59396a6e480fba7684d6220d77c79cdfcd9f88b8f0c455f75d52fffb975b04ff`, at07:33:10Z. I then read the root's independently frozen original reconstruction and the original author control code; no original-version control was executed.

For v1.1, I independently read/reconstructed the analytic delta and sent its rank/projection/64-8/N23 calculation to the root before its concurrence. That was read-only reasoning while the renewal was pending. After renewal I saved `SUCCESSOR_RECONSTRUCTION.md`,6,251B, SHA256 `806fc18b3bcbf2ea99b9b75c697130c5832b683376c7b8ff262c85027f7128f3`, at07:40:22Z, before inspecting the successor checker. The root's concurrence and incidental exposure to the successor checker patch are disclosed; this is not a claim of a blind successor file freeze. The original and successor notes remain separate.

## Scope and consumed assumptions

The current [H_R setting, lines57–70](https://github.com/d6g8k5htny-coder/Math-/blob/263530983ce1add48c9b658073cd7172466a0e55/frontiers/d1_line_20261004/PROOF.md#L57) is one fixed real centered stationary Gaussian process on the line with absolutely continuous spectrum. Retain R1 (every spectral moment finite), R2 (a strictly positive density lower bound on a nonzero-length interval away from frequency0), and R3 (`ess sup (1+omega^6)s<infinity`). All constants may depend on that fixed process and fixed positive t0. No covariance-uniform conclusion is proved.

The v1.1 proof removes the former explicit O(1/|x|) covariance-decay rate. This is justified within slice C: its replacement uses qualitative Riemann–Lebesgue decay for the three-pin inverse, and rank-three conditioning for the many-sample estimate. It does not claim a quantitative T1 uniform over spectral densities.

The [1D] parent is `frontiers/d1_third_order_law_20261001/PROOF.md` at the blob in the table. Only its §1 pin-coordinate convention and the compact four-sample argument as identified in the target were needed. With V=(f'(-t/2),f'(t/2),f(-t/2)-f(t/2)), the linear map to U has determinant12/t^4. Therefore `(12/t^4)p_t(alpha)=p_V(0,0,h)` when alpha=12h/t^3. The estimates concern the band kernel

`K_band(t,h)=p_V(0,0,h) E_Q[|f''(-t/2)f''(t/2)| 1_band]`.

There is no extra normalization or assumption that the endpoint weight is independent of the event. The band is the finite-segment Borel condition that the path stays between its two pinned values. The full elder-event identification and its marked Kac–Rice use are retained interfaces outside this slice.

I checked the consumed nondegeneracy fact from R2: a zero finite-jet variance would make an exponential polynomial vanish on a spectral interval, hence identically; independence of distinct-point exponential polynomials forces all coefficients to vanish. This justifies the pin/sample conditional covariances used here. It does not constitute a wholesale review of the global Morse/elder assertions in slice A. The cached [1D+] parent, blob `8dc558a735f8a8fdf82b698726b2881c2655281f`, was identity-bound only for context; none of its full local expansion or assembly is newly accepted here.

## Compact-middle reconstruction

[Lemma3.1_R, lines221–246](https://github.com/d6g8k5htny-coder/Math-/blob/263530983ce1add48c9b658073cd7172466a0e55/frontiers/d1_line_20261004/PROOF.md#L221) is unchanged from v1. Its exact section is1921B, SHA256 `c972e5ff74d7052233abaf58424125950ef72522529daf7d4ca80491f4c70de8`.

Four interior points can be chosen with the printed pin and mutual margins even at t=t0. On the resulting compact configuration set, the joint finite-jet nondegeneracy supplies a uniform bound for the density of their four slopes conditional on V and both endpoint curvatures. This density bound is independent of the realized conditioning values.

The symmetric Taylor estimate in [Lemma4.2_R, lines260–269](https://github.com/d6g8k5htny-coder/Math-/blob/263530983ce1add48c9b658073cd7172466a0e55/frontiers/d1_line_20261004/PROOF.md#L260) gives

`|g'(y)| <= sqrt(osc*S)+2osc/length`.

The proof handles zero oscillation, affine functions, the admissible optimizer and the boundary optimizer correctly. On the band it bounds the four slopes by2sqrt(hB), where B=max(1,sup|f''|), for small h.

For the centered conditional residual use the signed process `(x,sigma)->sigma X''(x)`. Gaussian conditioning decreases every signed increment variance, so Sudakov–Fernique bounds its expected absolute supremum by the unconditional fixed-window value. The conditional mean is uniformly bounded, and concentration yields B<=C sqrt(log(1/h)) except on probability O(h^20).

The good-B band is contained in a four-slope box of side scale sqrt(h b_h); its probability conditional on the endpoint curvatures is O(h^2 log(1/h)). The argument does not condition the Gaussian density on the truncation event itself. Integrating against the endpoint absolute product preserves this bound. Cauchy–Schwarz bounds the bad-B contribution by O(h^10). Uniform endpoint moments and pin density on [t0,T0] then give the stated O(h^2 log(1/h)) integral.

## Successor density and rough-cell estimates

[Lemma4.1_R, lines252–258](https://github.com/d6g8k5htny-coder/Math-/blob/263530983ce1add48c9b658073cd7172466a0e55/frontiers/d1_line_20261004/PROOF.md#L252) correctly uses integrability of s, omega s and omega^2 s to get rho,rho',rho''→0. The pin covariance approaches diag(lambda2,lambda2,2rho(0)), giving its eventual lower bound cV. This requires no decay rate.

For [Lemma4.3_R, lines271–296](https://github.com/d6g8k5htny-coder/Math-/blob/263530983ce1add48c9b658073cd7172466a0e55/frontiers/d1_line_20261004/PROOF.md#L271), Ingham applies with gap w and spectral-interval length4pi/w, strictly greater than2pi/w. Its constant is uniform in the finite number and arrangement of separated samples, and complex phases from interval translation are permitted. Multiplication by s0 omega1^2 gives an unconditional sample covariance floor lambda_*.

Conditioning subtracts a positive semidefinite matrix of rank at most3. At least k-3 eigenvalues of the conditional covariance remain >=lambda_*. One direct proof is that its quadratic form agrees with the original covariance on ker(P), of dimension at least k-3; Courant–Fischer gives the claimed retained eigenvalue floor. The three other eigenvalues may vanish, so a full k-dimensional density bound is not asserted.

Project onto the k-3 retained eigen-directions. The projected Gaussian has density bounded by `(2pi lambda_*)^(-(k-3)/2)` regardless of mean. The original small cube projects inside the Euclidean ball of radius epsilon sqrt(k). For x>0, integrating `u^x exp(-u)` over u>=x gives `Gamma(x+1)>=x^x exp(-x)`. Thus the ball-volume bound in the source is valid for integer or half-integer x. Since k>=6 implies k/(k-3)<=2, the resulting probability is at most

`(epsilon sqrt(2e/lambda_*))^(k-3)`.

This explains why the old pin-distance summability bound is no longer required. It also shows why deleting the three lost powers would be false for a general three-pin Gaussian conditioning argument.

[Lemma4.4_R, lines298–343](https://github.com/d6g8k5htny-coder/Math-/blob/263530983ce1add48c9b658073cd7172466a0e55/frontiers/d1_line_20261004/PROOF.md#L298) retains the correct conditional mean, RKHS, and concentration structure. R1 and the far-pin inverse imply sup|m''|<=C_m h. The conditioned RKHS is the orthogonal complement of the pin representers; after restriction to the finite interval, its norm is the quotient norm.

Plancherel and R3 bound both global L2 norms of g'' and g''' by2pi S6||g||_H^2. The cell Sobolev inequality and disjoint interiors give

`F(g)^2 <=4pi S6(w^-1+w)||g||_H^2`.

Taking extension infima preserves this bound in the restricted conditioned RKHS. Therefore F is Cameron–Martin Lipschitz with a constant independent of the number of cells or their total span. This is the reason concentration has an N-proportional exponent; independence of cells is not assumed.

Signed-process comparison and two-sided Gaussian mean concentration give E sup_J|X''|<=mu_w and variance<=4lambda4. Hence E F(X)<=sqrt(N M2). With R>=5(sqrt(M2)+1), C_m h<=1, the rough-cell event forces a deviation at least sqrt(N)R/2 because `(1/2+1/5)^2<=1/2`. This gives exp(-N R^2/(8sigma_F^2)). The factor4 would not justify the same deviation. C_m may harmlessly be selected strictly positive.

## Weighted far-band integration

[LemmaF_R, lines345–379](https://github.com/d6g8k5htny-coder/Math-/blob/263530983ce1add48c9b658073cd7172466a0e55/frontiers/d1_line_20261004/PROOF.md#L345) uses t>=24w to obtain N>=23 contained cells. On the band, every cell with S_i<=R gives a slope at most epsilon=sqrt(hR)+2h/w. Outside the rough-cell event, a subset of ceil(N/2)>=12 good cells exists. With q=4epsilon sqrt(2e/lambda_*), the union bound over at most2^N subsets is

`2^N(q/4)^(N/2-3)=64q^(N/2-3)`.

Cauchy–Schwarz for the two-curvature weight turns this into8q^(N/4-3/2), and turns the rough probability exponential denominator8 into16. Pin density and curvature product moments are uniformly bounded for large t and small h. No event/weight factorization is used.

For R=A sqrt(log(1/h)) with A^2>=2sigma_F^2, q=O(h^(1/2)log(1/h)^(1/4)). Each count level N(t)=n occupies at most w length. Both geometric ratios can be made <=1/2. Starting at23 gives initial terms h^(23A^2/(16sigma_F^2)) and8q^(17/4), hence

`integral_[T0,infinity) K_band(t,h)dt = O(h^(17/8)log(1/h)^(17/16)) = o(h^2)`.

This proves the source's weaker stated O(h^2). The positive one-eighth power absorbs the logarithm. Starting the printed coarse exponent ledger at22 leaves a positive log factor at exactly h^2 and would not establish O(h^2) by that ledger. This is not an intrinsic impossibility with22 cells: strict n_R<N/2 then supplies at least12 good cells, so a sharper parity-aware selection is different. Keeping the original17-cell cutoff after losing three directions would likewise be insufficient for the printed ledger.

The root's separately recorded alternatives are consistent: for the actual regular grid, spectral-interval orthogonality gives the unconditioned covariance floor directly; and F is a supremum of centered Gaussian linear functionals, giving a direct Borell–TIS application. These support the calculation without enlarging its scope. General separated sets still use Ingham as stated.

## External inputs and finite controls

The external theorem hypotheses were checked against primary author-hosted sources:

- [Enrique Zuazua's research survey](https://paginaspersonales.deusto.es/enrique.zuazua/documentos_public/archivos/publicaciones/zuazua.chile.pdf), printed p484, Ingham theorem(3.33)–(3.34): uniform constants depending on interval length and gap, complex square-summable coefficients, strict threshold.
- [Michel Ledoux's Gaussian concentration note](https://perso.math.univ-toulouse.fr/ledoux/files/2025/07/GB-concentration-v1.pdf), §2 and §3 Theorem1/(7)–(8): RKHS Lipschitz convention and concentration about the mean. Finite dense grids also give the application here by continuity and the established second-moment bound.
- [Sergey Lototsky's Gaussian inequalities notes](https://dornsife.usc.edu/sergey-lototsky/wp-content/uploads/sites/211/2023/06/GaussIneq.pdf), pp2–3: bounded Gaussian suprema and the Sudakov–Fernique increment hypothesis, applied to the signed processes.

The exact downloaded PDF hashes and read scopes are in `EXTERNAL_REFERENCES.json`. **Full external PDFs are local-only and excluded from delivery/public redistribution.** No full-text reading of the original1936 Ingham paper or the cited Young/Bogachev/Ledoux books is claimed. A failed Columbia PDF fetch is recorded as failed access, not evidence read.

Actual execution used Python3.11. `run_controls.py` saved every command, cwd, program hash, stdout/stderr, exit and duration. `RESULTS.json` records30 invocations; `CUSTODY_VERIFICATION.json` additionally verifies the actual failure reasons and every transcript/program identity.

- Author v1.1 program: baseline in normal and optimized modes; all M1–M7 mutations rejected with their expected control failures in both modes; unknown label rejected with exit2. Both baseline outputs equal the exact4,245B published `RESULTS.json`, SHA256 `4ddcf4d664d4c115c172393be15f463764a49b0f730b540b3de1a40224c5bae2`.
- Reviewer program:429 finite exact checks in each mode. A rotated rank-three orthogonal projection supplies a valid positive semidefinite Gaussian-conditioning example, including singular discarded directions; a small-cube counterexample demonstrates that losing three powers matters. Other checks cover the density Jacobian, Gamma-volume arithmetic at sampled dimensions, cell geometry,64/8 factors, geometric sums and the h/log ledger.
- Four reviewer mutations are rejected in both modes: omitted pin Jacobian, omitted rank loss, omitted Cauchy–Schwarz square root, and a22-cell cutoff in the printed coarse exponent ledger. Unknown labels fail closed. Normal/optimized stdout and stderr are byte-identical for each baseline/mutation/unknown pair.

All30 invocations have the expected exit. This means4 successful baselines,22 intentionally rejected mutations and4 intentionally rejected unknown labels. These are finite checks, not theorem counts. The author C3/M4 constants replay is **out-of-scope arithmetic support only**, not acceptance of slice D or the whole expansion. No project master, Lean, full parent test suite or duplicate v1 replay was run.

Reviewer program:6,912B SHA256 `239fd4ea6b06fc1cb0d8e10bfc819a623de9e5b6eef814165fd0c193316b1b39`. Aggregate execution record:37,227B SHA256 `e0218be2fc74a3bbe7cc15de4193b76bd7e6cca4514fa91d5f404484eb2b4f20`. Their full transcripts, preserved initial/successor reconstructions and exact source inventory accompany the report.

## Remaining boundary and optional wording

No required amendment is identified in slice C. A nonblocking introductory clarification would replace the shorthand “lower bound on the conditional covariance” at line27 with a lower bound on **all but at most three eigen-directions**. Lemma4.3 already states and proves the precise projected-density estimate, so that shorthand does not invalidate the argument.

The PASS is limited to the two band-kernel estimates and their analytic inputs described above, at the exact reviewed head. The global line persistence objects, full marked Kac–Rice construction, local circle-to-line transfer, three-term constants, final theorem assembly, repository integration and future source changes remain outside this review. No new d>=2 result, small-k rate, growing-window uniformity or global completion status is asserted.
