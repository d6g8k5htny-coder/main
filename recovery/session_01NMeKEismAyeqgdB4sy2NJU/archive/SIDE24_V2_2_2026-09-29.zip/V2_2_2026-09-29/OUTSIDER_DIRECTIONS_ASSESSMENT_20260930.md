# Assessment of an outsider's "where next" note against what the repository actually proves

Prepared by Anthropic Claude (session `session_01NMeKEismAyeqgdB4sy2NJU`), 30 September 2026, 21:00 UTC, for Dylan Roy.
Input: an outsider's ten-direction note on the SIDE24 program (not Dylan's; not a review). Scientific effect: NONE — this
is an assessment for planning, not a record of any result. Tags: **[PROVED]** already in the repository at the stated
status; **[FOLLOW-THROUGH]** cheap and justified now; **[RESEARCH]** a real next project; **[OVERREACH]** not supported by
anything we have.

## 0. One correction to the note's premises

The note quotes "the number 0.0734069…" as the constant. That is `c_{2,∞} = 0.07340691930603427103…`, the **planar**
(`d = 2`) coefficient of `coefficients/side24_v1` (reviewed by two providers). The manuscript is `d = 3`, side 24:
`c_{3,24} = 0.04177593184059834334…` (same record; the side-24 correction is `−(620813376/35)e^{−288}`, invisible). So
the outsider was reading a planar summary; "the current planar case is only one point" is a misreading — see §1.

## 1. Direction 2 ("test across dimensions"): already a theorem — **[PROVED]**

The parent theorem (`imports/lifetime_parent_20260925/UNIFORM_MATRIX_CAP_AND_LIFETIME.md`, Theorem C, `[R·2P]`) is
stated and proved for **every** `d ≥ 2` and every side `L > 0`: `ν_eld^{all}(ℓ) ~ c_{d,L}ℓ^{−1/3}`, with `c_{d,L}` given by
the explicit finite-dimensional formula (15.2). The exponent is dimension-independent, and the bookkeeping shows
exactly why. In the separation variable `r = dist(M, S)` the pair measure is

    [polar volume r^{d−1}] × [pin density 12 r^{−(d+3)} π_r]  × [determinant scale r²]  dr  =  r^{−2} · (…) dr,

and the gap is `ℓ = k r³`. The `d` cancels between the polar factor and the pin degeneracy (`(3.2)`, `(10.1)`,
`(11.1)` of the parent). With `ν(ℓ) = ∫ r^{−2}A(ℓ/r³) dr` and `r = (ℓ/k)^{1/3}` one gets `ℓ^{(a+1)/m}` with `a = −2`,
`m = 3`: the exponent `−1/3` is `(a + 1)/m`, in every dimension. The same count gives `a = −2` in `d = 1` as well
(adjacent max/min pairs; gradient-difference density `1/r`, height-difference density `r^{−3}`, curvature product `r²`),
so `−1/3` should hold for smooth one-dimensional processes too — where prior art is most likely to exist (the
small-amplitude statistics of Rice / Longuet-Higgins are the open literature item in the V2.2 queue).

**Follow-through (cheap):** a V3 remark stating the dimension-independence with the count above, and that the
manuscript's `d = 3` is one instance of Theorem C. Nothing to prove.

## 2. Direction 1/8 ("universality classes by singularity type"): half already inside our model — **[PROVED] + [RESEARCH]**

The "generic max–saddle collision, gap `~ r³`" row of the note's table *is* Theorem C, and its exponent is the
Whitney-fold count above. The next row, "higher degeneracy, gap `~ r⁴`", is **not a separate class for a generic field**
— it is the corner `k → 0` of the same law, and it is exactly where today's `ℓ^{1/4}` correction comes from
(Math- #198, candidate): at the cusp scale `r ≍ k ≍ ℓ^{1/4}` the gap is `ℓ = kr³ ≍ r⁴`, the contact law's own weight
`(6k)²` makes the pair measure `r^{−2}·k² dr = O(1) dr` there, and a window of separations `r ≍ ℓ^{1/4}` contributes
`≍ ℓ^{1/4}`. So within one Gaussian model the "table" already reads:

| local event | gap scaling | contribution to `ν(ℓ)` | status |
|---|---|---|---|
| generic fold (max–saddle at separation `r`) | `ℓ ≍ r³` | leading `c ℓ^{−1/3}` | Theorem C `[R·2P]` |
| nearly degenerate fold (cubic coefficient `k ≍ r`) | `ℓ ≍ r⁴` | correction `c₁ℓ^{1/4}`, `c₁ < 0` explicit (the elder window on this scale is exactly one third of the type window, `\|φ\| < 1/3`) | #198 `[CAND]` (order), #207 `[CAND]` (coefficient; added 2026-10-01) |
| far pairs (separation `≍ 1`), rejected by the elder rule | — | constant `B_{d,L}` for the candidate density, `0` for elder | Theorem Z `[R]`, #191 `[CAND]` |
| far pairs, elder | — | `O(ℓ^{2/3})` (barrier), expected faster than any power | #187/#188 `[CAND]` |
| fixed-separation pair, lifetime tail | — | `ε^{2/3}` | #182 (merged) |

That is a genuine "family of exponents", but all of it lives in one universality class (generic smooth fields). A
truly different class needs a field whose collisions are *forced* to be degenerate (a symmetry killing the cubic term
along the collision axis — e.g. `f = g²`-type or even-symmetric constructions), or a **rough** field (fractional
Brownian-type, Hurst `H`) where there are no critical points and the barcode statistics follow `H`: as far as I know
the count of bars longer than `ε` for one-dimensional fBm is `≍ ε^{−1/H}` (`ε^{−2}` for Brownian motion), i.e. a
density `≍ ℓ^{−1/H−1}`, against our `ℓ^{−1/3}` (whose counting function stays finite). So the classification the note
imagines is really two-dimensional: smoothness class (finite jets → fold exponent `−1/3`; rough → Hurst-driven) and
degeneracy class (imposed symmetries). **[RESEARCH]**: a toy non-generic model (say `f = g²` or a `Z_2`-symmetric
field) would give the first "Class II" entry with an honest computation; the rough-field row is a different technique
(no Kac–Rice) and a different community.

## 3. Direction 3 ("remove the Gaussian assumption"): the exponent should survive, and the proof's architecture says so — **[RESEARCH, best candidate]**

This is the note's strongest idea, and our repository is unusually well placed for it because it already separates
the deterministic geometry from the Gaussian estimates:

- **Deterministic, distribution-free:** the marked cylinder cap theorem (`0633aca3`) — the elder rule near a
  collision; the barrier lemma (#182 §3: a bar of lifetime `ℓ` is born at a maximum with `λ_min(−D²f) ≤ (ℓK²/c_L)^{1/3}`);
  the maximin definition of the elder partner ([P] §8); Lemma E's reflection symmetry and Lemma W's sign window
  (#191/#198 — exact polynomial identities in the pinned quintic, checked by exact controls); the pin structure
  `ℓ = kr³`, `f_2 = −(r²/24)f_4`, `f_3 = 12k − (r²/40)f_5`.
- **Gaussian:** the regression couplings ([P] §4, [R] (R3)–(R4)), the uniform moment and density bounds ([P] §§3–7,
  [R] (R5)), and the coefficient formula (15.2).

The leading exponent needs only: (i) the scaling of the two-site 1-jet pin density `12r^{−(d+3)}π_r` — which holds
for any field with `C³` paths whose 3-jet at a point has a continuous positive density (the scaled rows converge to
`(f, f_x, f_xx, f_xxx)(0)` and the density converges); (ii) the determinant weights' conditional moments; (iii) the cap
theorem (deterministic) with a probability bound for its failure. Formula (15.2) shows what a non-Gaussian
coefficient would look like: replace `Γ(7/6)τ_u^{4/3}` — the Gaussian value of `144∫_0^∞ k^{4/3}φ(12k)dk` for the
conditional law of `∂_u³f` — by the same integral against the field's conditional third-derivative density, and
`p_G(0) p_{V_u}(0) D_u` by the field's own jet densities and cone moment. The exponent `−1/3` never sees the law; the
coefficient is where the law enters. **What would have to be rebuilt:** every uniform estimate that currently comes
from linear regression (moments of `C^q` norms under conditioning, the coupling `F_r → F_0`, the density bound (R5),
the matrix-cap failure probability). That is a real paper, not a remark — but its statement is clear: *for stationary
random fields with `C^7` paths, finite moments of the derivative suprema, and a continuous positive density of the
3-jet at a point, `ν_eld(ℓ) ~ c ℓ^{−1/3}` with `c` given by the non-Gaussian analogue of (15.2).* The remainder theory
(Theorem R, R+, R++) would not transfer without the coupling.

**Follow-through (cheap, for V3 Discussion):** one paragraph saying precisely this — which steps are deterministic,
which are Gaussian, and that the exponent is expected (not proved) to be distribution-free within that class.

## 4. Direction 4 ("renormalization / zoom-in limit"): this is what the contact limit already is — **[PROVED, trivial for smooth fields]**

Zooming to scale `r` around a near-colliding pair and rescaling heights by `r³` is exactly the parent's contact
limit: the scaled rows `U_r → U_0 = (f, f_x, f_xx, f_xxx)(0)`, the pinned laws `Q_{r,b,k} → Q_{0,b,k}` ([R] (R3)–(R4)),
and the "universal critical-collision field" is the random cubic jet at the collision point. For smooth fields the RG
picture is Taylor's theorem: every model flows to its 3-jet, and the invariant is the exponent (a Jacobian count),
while the "non-universal" data is the jet law entering (15.2). The picture becomes non-trivial only for rough
fields, where zooming gives a self-similar limit and the exponent depends on `H` (§2). Nothing to do here beyond
saying it clearly.

## 5. Directions 5/6 ("persistence as a probe", "inverse theorem"): modest and real — **[RESEARCH, small]**

What the near-diagonal expansion can tell you about the field, concretely:
- the exponent `−1/3` (equivalently the `ℓ^{2/3}` counting function) identifies the smoothness class (finite 3-jets with
  nondegenerate density; a rough field would give a Hurst-driven exponent);
- the coefficient `c` is one scalar functional of the 3-jet law, (15.2): the angular average of
  `p_G(0) p_{V_u}(0) τ_u^{4/3} D_u`. For an isotropic Gaussian field it is a function of the spectral moments
  `λ_2, λ_4, λ_6` (the supplement's `a, m_4, χ`), with amplitude scaling `c ↦ a^{−2/3}c` under `f ↦ af`; so `c`, together
  with the critical-point density (which gives `λ_2, λ_4` by Kac–Rice), pins the sixth spectral moment;
- if the `ℓ^{1/4}` correction's coefficient is proved (§2), it is a second functional; the candidate density's
  constant `B_{d,L}` (Theorem Z) is a global functional of the whole covariance.
An "inverse theorem" (barcode asymptotics → local law) is overreach: finitely many numbers cannot determine a law. A
"moment identification" theorem is realistic and could be stated for isotropic Gaussian fields from (15.2) alone.

## 6. Direction 7 ("dynamics"): a good reinterpretation, and a consistency check worth writing down — **[FOLLOW-THROUGH, remark]**

For a one-parameter family `f_t`, a max–saddle pair annihilates (or is born) through a Whitney fold: in normal form
`f_t(x) = x³/3 − (t_0 − t)x`, separation `r = 2√(t_0 − t)`, gap `ℓ = (4/3)(t_0 − t)^{3/2} ∝ r³`. The time a pair spends
with gap in `dℓ` near the fold is `dt ∝ ℓ^{−1/3}dℓ`. So `−1/3` is the fold exponent of singularity theory, and for a
field stationary in time the ensemble law `ν(ℓ) ≍ ℓ^{−1/3}` is the time-average of the fold occupation — the same
count as §1 seen dynamically (`m = 3` is the fold's `3/2` power; `a = −2` is `dt/dℓ`'s `−1/3` after the `r^{−2}`
measure). This is the cleanest way to say "the exponent is geometry, not probability". Caveats: in `d ≥ 2` a pair can
approach and separate without colliding (near misses) and those pairs also sit in the small-gap population; the
`ℓ^{1/4}` correction lives exactly at the scale where the cubic coefficient is comparable to the separation, i.e.
near the cusp (A₃) organizing centre of the fold family. A dynamical theorem (annihilation rate per unit
volume-time, its relation to `c`) is **[RESEARCH]** and would need a space-time Kac–Rice on the fold set; the remark
costs nothing.

## 7. Directions 9/10 ("connect to physics", "random singularity theory"): out of scope — **[OVERREACH for now]**

The repository's method is already "jet distribution → singularity (fold/cap) → topological event → observable";
that is the note's hierarchy, instantiated once. Claims about phase transitions leaving signatures in `ν(ℓ; λ)` have no
support here and should not appear in V3.

## 8. What I would actually do, in order

1. **V3 Discussion paragraph (now, author-side, no review dependency):** dimension-independence of the exponent with
   the `r^{d−1}·r^{−(d+3)}·r²` count (§1); the fold reinterpretation (§6); the deterministic/Gaussian split of the proof
   and the expected (unproved) distribution-independence of the exponent (§3); the two-scale structure — fold at
   `r ≍ ℓ^{1/3}` gives the leading law, cusp-scale `r ≍ ℓ^{1/4}` gives the first correction (§2, at candidate status).
   Add to the V3 edit pack as **E14**. This answers the outsider's "stop and ask what the mechanism is telling you"
   without claiming anything unproved.
2. **Literature (already queued):** the `d = 1` small-amplitude law in Rice / Longuet-Higgins — the one place the
   `−1/3` may already exist in print.
3. **Next paper candidate, if the program continues:** the non-Gaussian leading law (§3), stated for fields with
   `C^7` paths, finite derivative-suprema moments and a continuous positive 3-jet density. Start by isolating, in the
   parent, every step that uses linearity of regression; the deterministic half (cap, barrier, Lemma E/W identities)
   carries over verbatim.
4. **Smaller, self-contained:** (a) the sharp `ℓ^{1/4}` term (the referee's formal computation in #198 Remark 1: the
   cusp-scale kernel and the elder/rejected split at `k ≍ r`) — **done at candidate status, 2026-10-01: Math- #207,
   Theorem CU** (`c₁ = −(192/7)2^{1/4}∫∫π₀E₀[|Y|^{7/4}|Δ|^{1/4}1{A<0} | b] < 0`; `c₁/c ≈ −5.07` in `d = 3`). It also
   sharpens §2's picture: the `r⁴` "class" is a universal random quartic (the collision field of the fold family), on
   which the elder rule is the single number `1/3`; at its small-`κ` end the elder share of typed pairs tends to
   `13/27`, so it interpolates between the cap regime and Theorem Z's (non-commuting) equal-height limit; (b) a toy "Class II" model with an imposed symmetry
   forcing quartic collisions; (c) the moment-identification statement of §5 from (15.2).
5. **Not now:** rough fields (different technique), dynamics as a theorem, physics.

## 9. Sources used for this assessment

`imports/lifetime_parent_20260925/UNIFORM_MATRIX_CAP_AND_LIFETIME.md` (`dfed3b8d`): Theorem C (1.3), (3.2), (10.1), (11.1),
§15 (15.2) and its amplitude-scaling remark; `coefficients/side24_v1` (`c_{2,∞}`, `c_{3,24}`); `SIDE24_GAP_FILL_SUPPLEMENT.md`
§C.2–C.4 (`a, m_4, χ, Ω`; density convention); `frontiers/three_fronts_20260924/LIFETIME_REMAINDER.md` (`247b3ecf`);
`frontiers/c7_zero_gap_limit_20260929/PROOF.md` (`5b6328ea`, Theorem Z); `frontiers/fixed_r_inverse_lifetime_20260930/PROOF.md`
(`0d401877`, §3 barrier, (3)); Math- #191, #198 (candidates; `frontiers_remainder_vanishing_20260930/`,
`frontiers_remainder_rate_20260930/` in this archive); Math- #187/#188/#181 (candidates). The fBm counting statement is
from memory of the literature and is not a repository fact.
