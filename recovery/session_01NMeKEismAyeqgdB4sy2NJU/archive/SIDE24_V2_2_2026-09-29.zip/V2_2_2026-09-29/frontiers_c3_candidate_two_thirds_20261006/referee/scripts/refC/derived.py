"""Referee C: the derived numbers of §5 and §6 from J (j_indep.py) and #242 Corollary 1'."""
import sympy as sp
import mpmath as mp

mp.mp.dps = 30
J = mp.mpf('4.1977819815839')

# Corollary 1' closed forms, and the per-direction a1 from first principles (birth-integrated law; #242 Cor 1' proof)
F2 = 25 * mp.sqrt(3) / (48 * mp.pi ** 2)
F3 = 125 * mp.sqrt(30) / (192 * mp.pi ** 3)
p0 = lambda d: (2 * mp.pi) ** (-mp.mpf(2 * d + 1) / 2) / mp.sqrt(18)          # p_{V_0}(v(0)); det Cov(V_0) = 18
dd2 = (16 * mp.pi / 3) ** (-mp.mpf(1) / 2)                                     # d=2: A ~ N(0, 8/3), P = 1
dd3 = mp.quad(lambda rho: 4 * rho ** 3 * mp.e ** (-rho ** 2 / 2) * mp.npdf(-rho, 0, mp.sqrt(mp.mpf(5) / 3)), [0, mp.inf])
a1_2 = mp.mpf(12) / 9 * p0(2) * dd2 * mp.mpf(15) / 8
a1_3 = mp.mpf(12) / 9 * p0(3) * dd3 * mp.mpf(15) / 8
print('d=2: |S^1| a1 = %s   (1/10) int int F0 = %s' % (mp.nstr(2 * mp.pi * a1_2, 15), mp.nstr(F2 / 10, 15)))
print('d=3: |S^2| a1 = %s   (1/10) int int F0 = %s' % (mp.nstr(4 * mp.pi * a1_3, 15), mp.nstr(F3 / 10, 15)))
print('d=3 birth-integrated d-hat = %s  vs (25/8)(10pi/3)^(-1/2) = %s' % (mp.nstr(dd3, 15), mp.nstr(mp.mpf(25) / 8 * (10 * mp.pi / 3) ** (-mp.mpf(1) / 2), 15)))

# symbolic: (J/30) * Cor 1' = J * 5 sqrt3/(288 pi^2), J * 25 sqrt30/(1152 pi^3)
print('sympy:', sp.simplify(sp.Rational(1, 30) * 25 * sp.sqrt(3) / (48 * sp.pi ** 2) - 5 * sp.sqrt(3) / (288 * sp.pi ** 2)),
      sp.simplify(sp.Rational(1, 30) * 125 * sp.sqrt(30) / (192 * sp.pi ** 3) - 25 * sp.sqrt(30) / (1152 * sp.pi ** 3)))

c3_2, c3_3 = J * F2 / 30, J * F3 / 30
c2inf, c3inf = mp.mpf('0.073406919306'), mp.mpf('0.041775931841')
print('c3: d=2 %s  d=3 %s' % (mp.nstr(c3_2, 12), mp.nstr(c3_3, 12)))
print('c3/c: d=2 %s  d=3 %s' % (mp.nstr(c3_2 / c2inf, 10), mp.nstr(c3_3 / c3inf, 10)))
print('(12/5) a1, d=2 per direction: %s ;  a1 = %s' % (mp.nstr(mp.mpf(12) / 5 * a1_2, 10), mp.nstr(a1_2, 10)))
# effective k^2/kappa coefficient a1 (R(k)-1)/k^2 at the k used in #237's layer exploration
Rk = {'0.05': mp.mpf('1.007793223'), '0.1': mp.mpf('1.038545938'), '0.2': mp.mpf('1.15017612'), '0.4': mp.mpf('0.8981079013'),
      '0.8': mp.mpf('0.01696391483')}
for kk, r in Rk.items():
    print('  k=%-4s  a1 (R-1)/k^2 = %s' % (kk, mp.nstr(a1_2 * (r - 1) / mp.mpf(kk) ** 2, 6)))
print('1/R(0.8) =', mp.nstr(1 / Rk['0.8'], 6))

# Remark 3
R23 = {2: mp.mpf('-0.048779'), 3: mp.mpf('-0.061375')}
It = mp.mpf('-0.5336676')
print('#242: R23 = (int int F0) Itilde: d=2 %s  d=3 %s' % (mp.nstr(F2 * It, 8), mp.nstr(F3 * It, 8)))
for d, c3, c in ((2, c3_2, c2inf), (3, c3_3, c3inf)):
    co = c3 - R23[d]
    print('d=%d  c3 - R23 = %s   /c = %s' % (d, mp.nstr(co, 8), mp.nstr(co / c, 8)))

# #216 comparison: predicted ratio (three-term law + (c3-R23) l^{2/3}) / three-term law on [1e-4, 1e-2], count-weighted
coef = {2: dict(c=c2inf, c1=mp.mpf('-0.1772744') - mp.mpf('0.0921244'), c2=mp.mpf('0.22152441')),
        3: dict(c=c3inf, c1=mp.mpf('-0.1394041') - mp.mpf('0.0724443'), c2=mp.mpf('0.16123405'))}
for d in (2, 3):
    cc = coef[d]
    law = lambda l: cc['c'] * l ** (-mp.mpf(1) / 3) + cc['c1'] * l ** (mp.mpf(1) / 4) + cc['c2'] * l ** (mp.mpf(1) / 3)
    extra = (c3_2 - R23[2]) if d == 2 else (c3_3 - R23[3])
    a, b = mp.mpf('1e-4'), mp.mpf('1e-2')
    base = mp.quad(law, [a, b])
    add = extra * mp.quad(lambda l: l ** (mp.mpf(2) / 3), [a, b])
    # also log-binned average of the pointwise relative excess
    pw = mp.quad(lambda t: extra * mp.e ** (mp.mpf(2) / 3 * t) / law(mp.e ** t), [mp.log(a), mp.log(b)]) / (mp.log(b) - mp.log(a))
    print('d=%d: c1 = %s; predicted count ratio on [1e-4,1e-2] = %s ; log-bin-average relative excess = %s ; at l=1e-2: %s'
          % (d, mp.nstr(cc['c1'], 8), mp.nstr(1 + add / base, 6), mp.nstr(pw, 4), mp.nstr(extra * b ** (mp.mpf(2) / 3) / law(b), 4)))
