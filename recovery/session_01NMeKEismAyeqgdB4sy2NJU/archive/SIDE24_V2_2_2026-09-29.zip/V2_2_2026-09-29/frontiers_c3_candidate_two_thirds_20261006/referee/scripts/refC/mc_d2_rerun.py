"""Referee C: independent re-implementation of the d = 2 birth-integrated layer Monte Carlo (Remark 6).

D_r(k) = T_r(k) - S_r(k) = 12 p_{V_r}(v(k)) E[(-det Mt_a det Mt_c)(1{typed} - 1{A<0})], exact Gaussian conditioning of the
seven Hessian functionals on the five [R] rows (equivalent to #237 (1.1) by a unimodular row change), Gaussian kernel
exp(-|z|^2/2) on R^2. Covariances from Hermite polynomials, written from scratch. Compared with r L_F(k),
L_F(k) = (a1/k) e^{-12k^2} g(k)/g(0), a1 and R(k) from j_indep.py / derived.py.
Usage: python3 mc_d2_rerun.py N reps seed k r [k r ...]
"""
import sys
import numpy as np
import mpmath as mp

mp.mp.dps = 60


def He(n, t):
    h0, h1 = mp.mpf(1), t
    if n == 0:
        return h0
    for j in range(1, n):
        h0, h1 = h1, t * h1 - j * h0
    return h1


def cov(f1, f2):
    (p, al), (q, be) = f1, f2
    dz = [p[i] - q[i] for i in range(2)]
    v = (-1) ** sum(al) * mp.e ** (-(dz[0] ** 2 + dz[1] ** 2) / 2)
    for i in range(2):
        v *= He(al[i] + be[i], dz[i])
    return v


def covmat(L1, L2):
    M = mp.matrix(len(L1), len(L2))
    for i, a in enumerate(L1):
        for j, b in enumerate(L2):
            M[i, j] = sum(ca * cb * cov(fa, fb) for ca, fa in a for cb, fb in b)
    return M


def prepare(r, k):
    r, k = mp.mpf(r), mp.mpf(k)
    z = mp.mpf(0)
    a, c, o = (-r / 2, z), (r / 2, z), (z, z)
    rows = [[(1 / r, (c, (0, 0))), (-1 / r, (a, (0, 0)))],
            [(1 / r, (c, (1, 0))), (-1 / r, (a, (1, 0)))],
            [(6 / r ** 2, (a, (1, 0))), (6 / r ** 2, (c, (1, 0))), (-12 / r ** 3, (c, (0, 0))), (12 / r ** 3, (a, (0, 0)))],
            [(mp.mpf(1) / 2, (a, (0, 1))), (mp.mpf(1) / 2, (c, (0, 1)))],
            [(1 / r, (c, (0, 1))), (-1 / r, (a, (0, 1)))]]
    hess = [[(1 / r ** 2, (a, (2, 0)))], [(1 / r ** 2, (c, (2, 0)))], [(1 / r, (a, (1, 1)))], [(1 / r, (c, (1, 1)))],
            [(mp.mpf(1), (a, (0, 2)))], [(mp.mpf(1), (c, (0, 2)))], [(mp.mpf(1), (o, (0, 2)))]]
    SU = covmat(rows, rows)
    SUi = SU ** -1
    SHU = covmat(hess, rows)
    K = SHU * SUi
    Sc = covmat(hess, hess) - K * SHU.T
    v = mp.matrix([-k * r ** 2, 0, 12 * k, 0, 0])
    q = (v.T * SUi * v)[0]
    p = mp.e ** (-q / 2) / ((2 * mp.pi) ** (mp.mpf(5) / 2) * mp.sqrt(mp.det(SU)))
    mu = K * v
    # factor the 7x7 conditional covariance in mpmath (eigen-decomposition at 60 digits), then convert
    E, Q = mp.eighe(Sc)
    w = np.array([max(float(E[i]), 0.0) for i in range(7)])
    V = np.array([[float(Q[i, j]) for j in range(7)] for i in range(7)])
    return float(p), np.array([float(mu[i]) for i in range(7)]), V * np.sqrt(w)[None, :], float(q / 2)


def D_once(prep, Z):
    p, mu, L, _ = prep
    X = mu[None, :] + Z @ L.T
    da = X[:, 0] * X[:, 4] - X[:, 2] ** 2
    dc = X[:, 1] * X[:, 5] - X[:, 3] ** 2
    typed = (X[:, 0] < 0) & (da > 0) & (dc < 0)
    neg = X[:, 6] < 0
    val = (-da * dc) * (typed.astype(float) - neg.astype(float))
    return 12 * p * val.mean()


if __name__ == '__main__':
    N, reps, seed = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
    pts = [(float(sys.argv[i]), float(sys.argv[i + 1])) for i in range(4, len(sys.argv), 2)]
    a1 = 0.001454721257
    Rk = {0.2: 1.15017612, 0.4: 0.8981079013, 0.8: 0.01696391483}
    rng = np.random.default_rng(seed)
    for k, r in pts:
        prep = prepare(r, k)
        LF = a1 / k * Rk[k]
        vals = np.array([D_once(prep, rng.standard_normal((N, 7))) for _ in range(reps)])
        D, De = vals.mean(), vals.std(ddof=1) / np.sqrt(reps)
        print('k=%.2f r=%.4f reps=%d N=%d  ratio=%.4f +- %.4f   (quad form/k^2 at this r: %.6f)' % (
            k, r, reps, N, D / r / LF, De / r / LF, prep[3] / k ** 2), flush=True)
