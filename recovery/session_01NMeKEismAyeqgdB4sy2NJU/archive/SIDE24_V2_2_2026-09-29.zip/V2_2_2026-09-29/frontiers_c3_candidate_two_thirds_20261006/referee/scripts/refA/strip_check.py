"""Referee A: on the M-strip {lambda_max(A) < 0 <= lambda_max(A_M)}, is frak a = s m_M > 0 (so the strip is
outside the typed set, i.e. inside the layer |x| >= y) -- and how close does it come to 0?

Samples the exact conditional law (engine/mc_layer) with lambda_max(A) drawn uniformly in a window of width ~ r
below 0 (importance sampling; only membership statistics are reported), d = 2 and d = 3.
Reports: #strip samples, min of a/(|P| gamma_e^2/4 + r) on the strip, fraction with alpha_M >= 0,
and the Schur-complement sign of A_M in K_M.
"""
import sys
import numpy as np
from mc_layer import setup


def run(d, r, k, N, seed=5):
    par = setup(d, r, k)
    rng = np.random.default_rng(seed)
    Sz = par['Sz']
    W = 2 * r * (1 + 1 / k)
    if d == 2:
        lam = rng.uniform(-W, 0, N)
        a = lam[:, None]
    else:
        Spc = Sz[1:, 1:]
        pc = rng.standard_normal((N, 2)) @ np.linalg.cholesky(Spc).T
        rho = np.hypot(pc[:, 0], pc[:, 1])
        t = -rho + rng.uniform(-W, 0, N)
        z = np.stack([t, pc[:, 0], pc[:, 1]], 1)
        a = z @ par['Ti'].T
        lam = t + rho
    Y = par['muY'][None, :] + (a - par['muA'][None, :]) @ par['G'].T + rng.standard_normal((N, par['nY'])) @ par['LY'].T
    m = d - 1
    s = (-1) ** m
    nP = 1 + (d - 1) + (d - 1) * d // 2
    al = Y[:, 0]
    be = Y[:, 1:d]
    Av = Y[:, d:nP]
    Am = np.zeros((N, m, m))
    tt = 0
    for i in range(m):
        for j in range(i, m):
            Am[:, i, j] = Av[:, tt]
            Am[:, j, i] = Av[:, tt]
            tt += 1
    w, V = np.linalg.eigh(Am)
    lamM = w[:, -1]
    if m == 1:
        detA = Am[:, 0, 0]
        badjb = be[:, 0] ** 2
    else:
        detA = Am[:, 0, 0] * Am[:, 1, 1] - Am[:, 0, 1] ** 2
        badjb = Am[:, 1, 1] * be[:, 0] ** 2 - 2 * Am[:, 0, 1] * be[:, 0] * be[:, 1] + Am[:, 0, 0] * be[:, 1] ** 2
    mM = al * detA / r - badjb
    frak_a = s * mM
    strip = (lam < 0) & (lamM >= 0)
    # A's own edge quantities (for the scale |P| gamma_e^2/4): eigvec of A at 0
    A0 = np.zeros((N, m, m))
    tt = 0
    for i in range(m):
        for j in range(i, m):
            A0[:, i, j] = a[:, tt]
            A0[:, j, i] = a[:, tt]
            tt += 1
    w0, V0 = np.linalg.eigh(A0)
    P = np.prod(w0[:, :-1], axis=1) if m > 1 else np.ones(N)
    # gamma ~ beta_S - beta_M (to O(r^2)); use the endpoint average of beta difference as gamma proxy
    beS = Y[:, nP + 1: nP + d]
    gam = beS - be
    ge = np.einsum('ni,ni->n', gam, V0[:, :, -1])
    scale = np.abs(P) * ge ** 2 / 4
    # Schur complement of A_M in K_M: alpha - r beta^T A_M^{-1} beta
    inv = np.linalg.inv(Am)
    schur = al - r * np.einsum('ni,nij,nj->n', be, inv, be)
    sec = w[:, 0] if m > 1 else -np.ones(N)
    out = dict(d=d, r=r, k=k, N=N, strip=int(strip.sum()), strip_a_le_0=int((strip & (frak_a <= 0)).sum()),
               strip_alphaM_ge_0=int((strip & (al >= 0)).sum()), strip_schur_ge_0=int((strip & (schur >= 0)).sum()),
               strip_second_eig_AM_ge_0=int((strip & (sec >= 0)).sum()))
    if strip.any():
        ratio = frak_a[strip] / (scale[strip] + r)
        out['min_a_over_scale'] = float(ratio.min())
        out['q01_a_over_scale'] = float(np.quantile(ratio, 0.01))
        # the first-order prediction a ~ |P|(|U_red| - 6 kappa |lambda|) >= |P| gamma_e^2/4 on the strip
    return out


if __name__ == '__main__':
    for d in (2, 3):
        for k in (0.2, 0.8):
            for r in (0.04, 0.01, 0.0025):
                print(run(d, r, k, int(sys.argv[1]) if len(sys.argv) > 1 else 400000), flush=True)
