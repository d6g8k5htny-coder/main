"""Referee A: symbolic check of (I.1)/(1.2) and (I.2) of note C3 (independent of c3_exact.py).

(I.1): for A = O diag(l_1..l_m) O^T with O orthogonal,
  det A = l_m P,  adj A = P e e^T + l_m R,  R = sum_{j<m} (prod_{i<m, i != j} l_i) e_j e_j^T,
  hence Y' = P(-g_e^2/4) + l_m W0 and U = P U_red + l_m W, with symbolic spectra, gamma, B, f4, k.
  m = 2: O a fully symbolic rotation (rational parametrization t); m = 1, 3: symbolic everything except
  a fixed nontrivial rational orthogonal O (two different frames for m = 3).
(I.2): int_{-a/b}^0 (a^2 - b^2 x^2) dx = 2a^3/(3b), and = P^2|U|^3/(9 kappa) at a=|P||U|, b=6 kappa|P|.
Also: the cross term of x^2 for x = s(P U_red + l W) + eps carries no factor s (s^2 = 1).
"""
import sympy as sp


def frame(m, which):
    if m == 1:
        return sp.Matrix([[1]])
    if m == 2:
        t = sp.symbols('t')
        c = (1 - t ** 2) / (1 + t ** 2)
        s = 2 * t / (1 + t ** 2)
        return sp.Matrix([[c, -s], [s, c]])
    # m = 3: rational orthogonal matrices (Cayley transforms of fixed rational skew matrices)
    S = {0: sp.Matrix([[0, sp.Rational(1, 2), sp.Rational(-1, 3)], [sp.Rational(-1, 2), 0, sp.Rational(2, 5)],
                       [sp.Rational(1, 3), sp.Rational(-2, 5), 0]]),
         1: sp.Matrix([[0, 3, sp.Rational(-7, 4)], [-3, 0, sp.Rational(1, 6)], [sp.Rational(7, 4), sp.Rational(-1, 6), 0]])}[which]
    I = sp.eye(3)
    return (I - S) * (I + S).inv()


def check(m, which=0):
    l = sp.symbols('l1:%d' % (m + 1))
    O = frame(m, which)
    assert (O.T * O - sp.eye(m)).applyfunc(sp.cancel) == sp.zeros(m, m)
    A = O * sp.diag(*l) * O.T
    cols = [O[:, j] for j in range(m)]
    e = cols[m - 1]
    P = sp.Integer(1)
    for j in range(m - 1):
        P *= l[j]
    R = sp.zeros(m, m)
    for j in range(m - 1):
        c = sp.Integer(1)
        for i in range(m - 1):
            if i != j:
                c *= l[i]
        R += c * cols[j] * cols[j].T
    adjA = A.adjugate()
    z = lambda ex: sp.cancel(sp.together(ex)) == 0
    ok_det = z(A.det() - l[m - 1] * P)
    ok_adj = all(z(v) for v in (adjA - (P * e * e.T + l[m - 1] * R)))
    g = sp.Matrix(sp.symbols('g1:%d' % (m + 1)))
    bs = sp.symbols('b1:%d' % (m * (m + 1) // 2 + 1))
    B = sp.zeros(m, m)
    t = 0
    for i in range(m):
        for j in range(i, m):
            B[i, j] = bs[t]
            B[j, i] = bs[t]
            t += 1
    f4, k = sp.symbols('f4 k')
    ge = (e.T * g)[0, 0]
    Bee = (e.T * B * e)[0, 0]
    Yp = f4 / 12 * A.det() - (g.T * adjA * g)[0, 0] / 4
    U = Yp + 3 * k * (adjA * B).trace()
    W0 = P * f4 / 12 - (g.T * R * g)[0, 0] / 4
    W = W0 + 3 * k * (R * B).trace()
    Ured = 3 * k * Bee - ge ** 2 / 4
    ok_Y = z(Yp - (P * (-ge ** 2 / 4) + l[m - 1] * W0))
    ok_U = z(U - (P * Ured + l[m - 1] * W))
    # wrong variants must fail (sanity of the checker): R with the product over all i<=m; Ured with +gamma^2/4
    R_bad = sp.zeros(m, m)
    for j in range(m - 1):
        c = sp.Integer(1)
        for i in range(m):
            if i != j:
                c *= l[i]
        R_bad += c * cols[j] * cols[j].T
    bad1 = (m >= 2) and all(z(v) for v in (adjA - (P * e * e.T + l[m - 1] * R_bad)))
    bad2 = z(U - (P * (3 * k * Bee + ge ** 2 / 4) + l[m - 1] * W))
    return ok_det, ok_adj, ok_Y, ok_U, (not bad1), (not bad2)


def check_cross():
    P, Ur, lam, W, s, eps = sp.symbols('P Ur lam W s eps')
    x = s * (P * Ur + lam * W) + eps
    x0 = sp.expand(x ** 2).subs(eps, 0).subs(s ** 2, 1)
    with_s = sp.expand(P ** 2 * Ur ** 2 + 2 * s * P * Ur * lam * W + lam ** 2 * W ** 2)
    without_s = sp.expand(P ** 2 * Ur ** 2 + 2 * P * Ur * lam * W + lam ** 2 * W ** 2)
    return sp.expand(x0 - without_s) == 0, sp.expand((x0 - with_s).subs(s, -1)) == 0


def check_I2():
    a, b, x, P, U, kap = sp.symbols('a b x P U kappa', positive=True)
    val = sp.integrate(a ** 2 - b ** 2 * x ** 2, (x, -a / b, 0))
    ok1 = sp.simplify(val - 2 * a ** 3 / (3 * b)) == 0
    ok2 = sp.simplify((2 * a ** 3 / (3 * b)).subs({a: P * U, b: 6 * kap * P}) - P ** 2 * U ** 3 / (9 * kap)) == 0
    return ok1, ok2


if __name__ == '__main__':
    for m, w in ((1, 0), (2, 0), (3, 0), (3, 1)):
        r = check(m, w)
        print('m=%d frame=%d  det=%s adj=%s Y\'=%s U=%s  | mutant R_all_i rejected=%s, mutant +g^2/4 rejected=%s' % ((m, w) + r))
    c = check_cross()
    print('(2.3) cross term: x^2 = (P Ured + l W)^2 + ... [no s]: %s ; draft form 2sPUred*lW equals it for s=-1: %s' % c)
    print('(I.2): %s %s' % check_I2())
