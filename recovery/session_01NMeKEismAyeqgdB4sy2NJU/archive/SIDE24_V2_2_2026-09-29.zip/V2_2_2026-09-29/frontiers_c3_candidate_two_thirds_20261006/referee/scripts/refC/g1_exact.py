"""Referee C, independent check of (G.1): Gaussian kernel C(z) = exp(-|z|^2/2) on R^d.

Exact rational Gaussian conditioning (sympy) of the odd jets gamma_e = d_u^2 d_e f(0), B_ee = d_u d_e^2 f(0) and of the
entries of A = Hess_Theta f(0) on the pins V_0 = (grad f(0), d_u grad f(0), d_u^3 f(0)) with target v(k) = (0, 0, 12k).
Directional derivatives are expanded into partial derivatives, so u and e need not be coordinate axes.
Written from scratch (does not reuse the note's control code).
"""
import itertools
import sympy as sp

R = sp.Rational


def dC0(alpha):
    """partial^alpha of exp(-|z|^2/2) at 0."""
    out = sp.Integer(1)
    for a in alpha:
        if a % 2:
            return sp.Integer(0)
        out *= (-1) ** (a // 2) * sp.factorial2(a - 1)
    return out


def directional(vecs, d):
    """d_{v1} ... d_{vn} f(0) as {multi-index: coefficient}."""
    out = {}
    for idx in itertools.product(range(d), repeat=len(vecs)):
        c = sp.Integer(1)
        for v, i in zip(vecs, idx):
            c *= v[i]
        if c == 0:
            continue
        alpha = [0] * d
        for i in idx:
            alpha[i] += 1
        alpha = tuple(alpha)
        out[alpha] = out.get(alpha, 0) + c
    return out


def cov(L1, L2):
    s = sp.Integer(0)
    for a, ca in L1.items():
        for b, cb in L2.items():
            s += ca * cb * (-1) ** sum(b) * dC0(tuple(x + y for x, y in zip(a, b)))
    return sp.nsimplify(s)


def check(d, u, e, frame):
    std = [tuple(int(i == j) for j in range(d)) for i in range(d)]
    pins = [directional([s], d) for s in std] + [directional([u, s], d) for s in std] + [directional([u, u, u], d)]
    gam = directional([u, u, e], d)
    Bee = directional([u, e, e], d)
    Aent = [directional([frame[i], frame[j]], d) for i in range(len(frame)) for j in range(i, len(frame))]
    X = [gam, Bee] + Aent
    SVV = sp.Matrix(len(pins), len(pins), lambda i, j: cov(pins[i], pins[j]))
    SXV = sp.Matrix(len(X), len(pins), lambda i, j: cov(X[i], pins[j]))
    SXX = sp.Matrix(len(X), len(X), lambda i, j: cov(X[i], X[j]))
    # the pin covariance may be singular in the standard basis? check rank first
    assert SVV.rank() == len(pins), "pins degenerate"
    Si = SVV.inv()
    k = sp.symbols('k')
    v = sp.Matrix([0] * (2 * d) + [12 * k])
    mean = sp.simplify(SXV * Si * v)
    Sc = sp.simplify(SXX - SXV * Si * SXV.T)
    quad = sp.simplify((v.T * Si * v)[0] / 2)
    res = {
        'mean(gamma_e, B_ee)': [mean[0], mean[1]],
        'condcov(gamma_e, B_ee)': [[Sc[0, 0], Sc[0, 1]], [Sc[1, 0], Sc[1, 1]]],
        'max |condcov((gamma_e,B_ee), A)|': max(abs(Sc[i, j]) for i in range(2) for j in range(2, len(X))),
        'mean(A entries)': list(mean[2:]),
        'v^T Cov^-1 v / 2': quad,
        'uncond Var gamma_e, B_ee': [SXX[0, 0], SXX[1, 1]],
    }
    return res


cases = []
# d = 2: u = e1, e = e2; and a rotated pair u = (3/5, 4/5), e = (-4/5, 3/5)
cases.append((2, [1, 0], [0, 1], [[0, 1]]))
cases.append((2, [R(3, 5), R(4, 5)], [R(-4, 5), R(3, 5)], [[R(-4, 5), R(3, 5)]]))
# d = 3: axial; non-axial e; non-axial u and e
cases.append((3, [1, 0, 0], [0, 1, 0], [[0, 1, 0], [0, 0, 1]]))
cases.append((3, [1, 0, 0], [0, R(5, 13), R(12, 13)], [[0, 1, 0], [0, 0, 1]]))
cases.append((3, [R(3, 5), R(4, 5), 0], [R(-12, 25), R(9, 25), R(4, 5)], [[R(-4, 5), R(3, 5), 0], [0, 0, 1]]))
# d = 4: non-axial e = (0, 2/3, 2/3, 1/3)
cases.append((4, [1, 0, 0, 0], [0, R(2, 3), R(2, 3), R(1, 3)], [[0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]]))

for d, u, e, fr in cases:
    u = [sp.nsimplify(x) for x in u]
    e = [sp.nsimplify(x) for x in e]
    fr = [[sp.nsimplify(x) for x in f] for f in fr]
    assert sum(x * x for x in u) == 1 and sum(x * x for x in e) == 1 and sum(a * b for a, b in zip(u, e)) == 0
    for f in fr:
        assert sum(x * x for x in f) == 1 and sum(a * b for a, b in zip(u, f)) == 0
    res = check(d, u, e, fr)
    print('d=%d u=%s e=%s' % (d, u, e))
    for kk, vv in res.items():
        print('   %-36s %s' % (kk, vv))
