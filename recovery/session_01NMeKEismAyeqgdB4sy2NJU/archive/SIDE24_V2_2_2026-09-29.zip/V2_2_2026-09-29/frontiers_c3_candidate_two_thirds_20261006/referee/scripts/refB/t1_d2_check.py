"""Referee B, independent check of Lemma T1 in d = 2 (Gaussian kernel C(z) = exp(-|z|^2/2)).

Law Qbar_{0,0} (V_0 = (grad f, d_u grad f, d_u^3 f)(0) = 0, f(0) free), derived here from scratch:
  even jets: A = f_yy, f4 = f_xxxx; the only correlated even pin is f_xx (f_xy is uncorrelated with both).
    Var f_yy = 3, Var f_xx = 3, Cov(f_yy, f_xx) = 1, Var f4 = 105, Cov(f4, f_xx) = -15, Cov(f4, f_yy) = -3
    => given f_xx = 0: Var A = 8/3, Var f4 = 30, Cov(A, f4) = 2.
  odd jet: gamma = f_xxy; Cov(gamma, f_y) = -1, Var gamma = 3, uncorrelated with f_x, f_xxx => gamma ~ N(0, 2), independent.
  p_{V_0}(0) = (2 pi)^{-5/2} det(Cov V_0)^{-1/2}, det = det[[1,-3],[-3,15]] * 1 * 3 * 1 = 18.
Quantity: G(kappa) := kappa (scrA(kappa) - A2(0)) = kappa * 12 p0 E[(Y'^2 - 36 kappa^2 A^2)_+ 1{A<0}],
  Y' = (f4/12) A - gamma^2/4  (d = 2: Delta = A, adj A = 1).
Claim (Lemma T1 + (3.2) + #242 Cor. 1'): G(kappa) -> a1 = (1/10) int F0 db = 25 sqrt(3)/(480 pi^2) / (2 pi) per direction.

Method: substitute A = -t/kappa; given (A, gamma), f4 | A ~ N(3A/4, 57/2), so Y' ~ N(mu, s^2) with
  mu = A^2/16 - gamma^2/4, s = |A| sqrt(57/2)/12; E[(Y^2 - c^2)_+] in closed form; then 2-D quadrature in (t, gamma)
  with a breakpoint at the kink |mu| = 6t of the s = 0 integrand.
"""
import sys
import mpmath as mp

mp.mp.dps = 30

VA, VF, CAF = mp.mpf(8) / 3, mp.mpf(30), mp.mpf(2)
SF = mp.sqrt(VF - CAF ** 2 / VA)                    # sqrt(57/2)
P0 = (2 * mp.pi) ** (-mp.mpf(5) / 2) / mp.sqrt(18)
A1 = 25 * mp.sqrt(3) / (48 * mp.pi ** 2) / 10 / (2 * mp.pi)


def e_plus(mu, s, c):
    """E[(Y^2 - c^2)_+] for Y ~ N(mu, s^2), c >= 0, s > 0."""
    z0 = (c - mu) / s          # upper tail Y > c
    z1 = (-c - mu) / s         # lower tail Y < -c
    q0 = mp.ncdf(-z0)
    q1 = mp.ncdf(z1)
    return (mu * mu + s * s - c * c) * (q0 + q1) + s * ((mu + c) * mp.npdf(z0) + (c - mu) * mp.npdf(z1))


def G(kappa):
    kappa = mp.mpf(kappa)
    pA = lambda a: mp.npdf(a, 0, mp.sqrt(VA))

    def inner(g):                          # g = gamma >= 0; integrate over t in (0, inf)
        def f(t):
            A = -t / kappa
            mu = A * A / 16 - g * g / 4
            s = t * SF / (12 * kappa)
            return pA(A) * e_plus(mu, s, 6 * t)
        # kink of the s = 0 integrand: 6t = g^2/4 - t^2/(16 kappa^2)  =>  t* = 8 kappa^2 (sqrt(36 + g^2/(16 kappa^2)) - 6)
        ts = 8 * kappa ** 2 * (mp.sqrt(36 + g * g / (16 * kappa ** 2)) - 6)
        w = ts * 40 * SF / (72 * kappa)    # ~ 40 smoothing widths
        pts = [0, ts * (1 - mp.mpf('0.5')), max(ts - w, ts * mp.mpf('0.5')), ts, ts + w, ts + 4 * w + 1]
        pts = sorted(set(pts))
        return mp.quad(f, pts)
    pg = lambda g: 2 * mp.npdf(g, 0, mp.sqrt(2))          # gamma >= 0, symmetric
    val = mp.quad(lambda g: pg(g) * inner(g), [0, 0.5, 1, 2, 3, 5, 8, 14])
    return 12 * P0 * val


if __name__ == "__main__":
    print("a1 (=(1/10) int F0 db, per direction) = %s" % mp.nstr(A1, 15))
    print("a1 from (12/9) p0 p_A(0) E[gamma^6]/64 = %s" % mp.nstr(mp.mpf(12) / 9 * P0 * mp.npdf(0, 0, mp.sqrt(VA)) * 120 / 64, 15))
    ks = [float(x) for x in sys.argv[1:]] or [5, 10, 30, 100, 1000, 10000]
    for k in ks:
        g = G(k)
        print("kappa=%-7g G=%s  G/a1=%s  kappa*(G/a1-1)=%s" % (k, mp.nstr(g, 13), mp.nstr(g / A1, 13), mp.nstr(k * (g / A1 - 1), 8)))
        sys.stdout.flush()
