"""Referee C: drive the author's d = 3 functions (prepare, D_of) with more replicates; nothing is written elsewhere."""
import importlib.util
import sys
import numpy as np

path = '/tmp/claude-0/-home-claude/b41b316f-232c-5cf7-a0ee-80f0de603a6f/scratchpad/c3/referee/exploration_copy/layer_birth_mc_d3.py'
spec = importlib.util.spec_from_file_location('lbm3', path)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)          # the module's main block is guarded by __name__ == '__main__'

N, reps, seed = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
pts = [(float(sys.argv[i]), float(sys.argv[i + 1])) for i in range(4, len(sys.argv), 2)]
a1 = 0.0009151871836
Rk = {0.2: 1.15017612, 0.4: 0.8981079013}
rng = np.random.default_rng(seed)
for k, r in pts:
    prep = m.prepare(r, k)
    LF = a1 / k * Rk[k]
    vals = np.array([m.D_of(prep, rng.standard_normal((N, 15))) for _ in range(reps)])
    D, De = vals.mean(), vals.std(ddof=1) / np.sqrt(reps)
    print('d=3 k=%.2f r=%.4f reps=%d N=%d  ratio=%.4f +- %.4f' % (k, r, reps, N, D / r / LF, De / r / LF), flush=True)
