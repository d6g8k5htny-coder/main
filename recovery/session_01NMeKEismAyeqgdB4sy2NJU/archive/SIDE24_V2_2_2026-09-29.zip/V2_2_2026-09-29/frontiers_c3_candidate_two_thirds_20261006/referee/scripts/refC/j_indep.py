"""Referee C, independent numerics for Proposition G (Gaussian kernel).

Route used here (different from the author's c3_checks2.py, which integrates B in closed form given gamma):
  w := gamma^2/4 with gamma ~ N(0, 2) is Gamma(1/2, 1).  For s = 3kB,
  H(s) := E_w[(s - w)_+^3] = pi^{-1/2} [s^3 g(1/2,s) - 3 s^2 g(3/2,s) + 3 s g(5/2,s) - g(7/2,s)]   (lower incomplete gamma),
  so h(k) := E[(3kB - gamma^2/4)_+^3] = int_0^inf p_B(B) H(3kB) dB,  g(k) = 15/8 + 27k^2 + 2h(k).
  J  = (16/15) int_0^inf e^{-12k^2} h(k) k^{-8/3} dk
     = (16/15) * 3^{5/3}/sqrt(4 pi) * (16/3)^{2/3} * int_0^inf H(s) s^{-4/3} K_{4/3}(2s/sqrt3) ds   (B integrated: Bessel K).
Also: E[X^3] symbolically, the Gamma identity at random (a, b), J from its first form (no identity used), small-k behaviour.
"""
import random
import sympy as sp
import mpmath as mp

mp.mp.dps = 30

# ---------- E[X^3], g(0) symbolically ----------
k = sp.symbols('k', positive=True)
gam, B = sp.symbols('gamma B', real=True)


def gmom(n, var):
    return 0 if n % 2 else sp.factorial2(n - 1) * var ** (n // 2)


X = gam ** 2 / 4 - 3 * k * B
poly = sp.Poly(sp.expand(X ** 3), gam, B)
EX3 = 0
for (pg, pb), c in poly.terms():
    EX3 += c * gmom(pg, 2) * gmom(pb, 2)
EX3 = sp.expand(EX3)
g0 = sp.Rational(gmom(6, 2), 64)
print('E[X^3] =', EX3, '  g(0) = E[gamma^6]/64 =', g0, '  27/g(0) =', sp.Rational(27) / g0)

# ---------- Gamma identity ----------
print('Gamma(-5/6) + (6/5)Gamma(1/6) =', mp.gamma(mp.mpf(-5) / 6) + mp.mpf(6) / 5 * mp.gamma(mp.mpf(1) / 6))
rnd = random.Random(7)
worst = 0
for _ in range(6):
    a = mp.mpf(rnd.uniform(0.5, 30))
    b = mp.mpf(rnd.uniform(-20, 40))
    lhs = mp.quad(lambda t: (mp.expm1(-a * t * t) + mp.e ** (-a * t * t) * b * t * t) * t ** (-mp.mpf(8) / 3),
                  [0, 0.05, 0.3, 1, 3, mp.inf])
    rhs = mp.gamma(mp.mpf(1) / 6) / 2 * a ** (-mp.mpf(1) / 6) * (b - 6 * a / 5)
    worst = max(worst, abs(lhs - rhs))
print('Gamma identity: max |lhs - rhs| over 6 random (a, b):', mp.nstr(worst, 5))
a, b = mp.mpf(12), mp.mpf(72) / 5
idv = mp.quad(lambda t: (mp.expm1(-a * t * t) + mp.e ** (-a * t * t) * b * t * t) * t ** (-mp.mpf(8) / 3),
              [0, 0.05, 0.3, 1, 3, mp.inf])
print('identity at a=12, b=72/5 (should be 0):', mp.nstr(idv, 5))


# ---------- H(s), h(k), g(k) ----------
def H(s):
    if s <= 0:
        return mp.mpf(0)
    gi = lambda aa: mp.gammainc(aa, 0, s)
    return (s ** 3 * gi(mp.mpf(1) / 2) - 3 * s ** 2 * gi(mp.mpf(3) / 2) + 3 * s * gi(mp.mpf(5) / 2) - gi(mp.mpf(7) / 2)) / mp.sqrt(mp.pi)


def pB(x):
    return mp.e ** (-x * x / 4) / mp.sqrt(4 * mp.pi)


def h(kk):
    kk = mp.mpf(kk)
    if kk == 0:
        return mp.mpf(0)
    return mp.quad(lambda x: pB(x) * H(3 * kk * x), [0, 1, 3, 6, 12, 25])


def g(kk):
    return mp.mpf(15) / 8 + 27 * mp.mpf(kk) ** 2 + 2 * h(kk)


# spot check H against direct quadrature over w ~ Gamma(1/2, 1)
for s in (mp.mpf('0.3'), mp.mpf(2)):
    direct = mp.quad(lambda w: (s - w) ** 3 * w ** (-mp.mpf(1) / 2) * mp.e ** (-w), [0, s]) / mp.sqrt(mp.pi)
    print('H(%s): closed %s  direct %s' % (s, mp.nstr(H(s), 15), mp.nstr(direct, 15)))
# spot check g against a direct 2D quadrature of E|3kB - gamma^2/4|^3
for kk in (mp.mpf('0.1'), mp.mpf('0.4')):
    direct = mp.quad(lambda t, x: abs(3 * kk * x - t * t / 4) ** 3 * mp.npdf(t, 0, mp.sqrt(2)) * mp.npdf(x, 0, mp.sqrt(2)),
                     [-12, 0, 12], [-12, 0, 12])
    print('g(%s): via H %s   direct 2D %s' % (kk, mp.nstr(g(kk), 12), mp.nstr(direct, 12)))

R = lambda kk: mp.e ** (-12 * mp.mpf(kk) ** 2) * g(kk) / (mp.mpf(15) / 8)
for kk in ('0.05', '0.1', '0.2', '0.4', '0.8', '1.2'):
    r = R(mp.mpf(kk))
    print('k=%-4s R(k)=e^{-12k^2}g/g0 = %s   (R-1)/k^2 = %s' % (kk, mp.nstr(r, 10), mp.nstr((r - 1) / mp.mpf(kk) ** 2, 8)))

# small-k: (R - 1 - 12/5 k^2)/k^{7/2}
for kk in ('0.003', '0.01', '0.03'):
    kk = mp.mpf(kk)
    print('k=%s  (R-1-2.4k^2)/k^3.5 = %s' % (kk, mp.nstr((R(kk) - 1 - mp.mpf(12) / 5 * kk ** 2) / kk ** mp.mpf(3.5), 8)))
hl = 16 / mp.mpf(15) * (64 / mp.mpf(35)) * mp.mpf(3) ** mp.mpf(3.5) / mp.sqrt(4 * mp.pi) * \
    mp.quad(lambda x: pB(x) * x ** mp.mpf(3.5), [0, mp.inf])
print('predicted k^{7/2} coefficient (leading, from w^{-1/2} near 0):', mp.nstr(hl, 8))

# sign change of E(k): R(k) = 1
kz = mp.findroot(lambda kk: R(kk) - 1, mp.mpf('0.3'))
print('E(k) changes sign at k =', mp.nstr(kz, 8))

# ---------- J by the Bessel route ----------
pref = mp.mpf(16) / 15 * mp.mpf(3) ** (mp.mpf(5) / 3) / mp.sqrt(4 * mp.pi) * (mp.mpf(16) / 3) ** (mp.mpf(2) / 3)
Jb = pref * mp.quad(lambda s: H(s) * s ** (-mp.mpf(4) / 3) * mp.besselk(mp.mpf(4) / 3, 2 * s / mp.sqrt(3)),
                    [0, 0.1, 1, 3, 8, 20, 60])
print('J (Bessel route)              =', mp.nstr(Jb, 15))
