"""Referee B: numerical checks of the bookkeeping of section 4 with the Gaussian-kernel E(k) of (G.2) (scipy, double).

E(k) = (a1/k)(exp(-12k^2) g(k)/g(0) - 1),  g(k) = E|3kB - gamma^2/4|^3,  gamma, B iid N(0, 2)  (Proposition G; taken as
stated -- slice C checks it).  Checks:
 (1) |E(k)| <= C min(k, 1/k): sup of |E(k)|/min(k, 1/k) on a grid; small-k slope E(k)/k -> (12/5) a1.
 (2) Jacobian: int_0^inf s E(s^{-3}) ds  ==  (1/3) int_0^inf E(k) k^{-5/3} dk.
 (3) (4.2) with phi = E: l^{-2/3} int_0^rho r E(l/r^3) dr -> int_0^inf s E(s^{-3}) ds; the defect is the truncation at
     s = rho l^{-1/3}, of order l^{1/3} (so O(l) after the factor l^{2/3}).
 (4) c3 = |S^{d-1}| a1 (1/3) int (E/a1) k^{-5/3} against the note's c3 = 0.0127896 (d = 2), 0.0160923 (d = 3).
"""
import numpy as np
from scipy.integrate import quad
from scipy.special import ndtr

C3S = 3 * np.sqrt(2)


def npdf(z):
    return np.exp(-0.5 * z * z) / np.sqrt(2 * np.pi)


def e_abs3(mu, sig):
    m = mu / sig
    return sig ** 3 * ((m ** 3 + 3 * m) * (2 * ndtr(m) - 1) + 2 * (m ** 2 + 2) * npdf(m))


def g(k):
    if k == 0:
        return 15 / 8
    sB = C3S * k
    f = lambda t: e_abs3(-(t * t) / 2, sB) * npdf(t)
    return 2 * quad(f, 0, 14, points=[min(np.sqrt(sB), 13), 1, 3], limit=400, epsabs=0, epsrel=1e-13)[0]


def gm(k):
    """g(k) - g(0) computed stably: E|X|^3 - E[X^3] = 2E[(-X)_+^3] plus E[X^3] - g(0) = 27k^2."""
    sB = C3S * k
    # E[(-X)_+^3] with X = t^2/2 - sB z: (-X)_+ = (sB z - t^2/2)_+
    def inner(t):
        a = (t * t / 2) / sB
        return sB ** 3 * ((a * a + 2) * npdf(a) - a * (a * a + 3) * ndtr(-a))
    h = 2 * quad(lambda t: inner(t) * npdf(t), 0, 14, points=[min(np.sqrt(sB), 13), 1, 3], limit=400, epsabs=0, epsrel=1e-13)[0]
    return 27 * k * k + 2 * h


def R1(k):
    """exp(-12k^2) g(k)/g(0) - 1, stably."""
    return np.expm1(-12 * k * k) + np.exp(-12 * k * k) * gm(k) / (15 / 8)


def E1(k):          # E(k)/a1
    return R1(k) / k


A1 = {2: 25 * np.sqrt(3) / (48 * np.pi ** 2) / 10 / (2 * np.pi), 3: 125 * np.sqrt(30) / (192 * np.pi ** 3) / 10 / (4 * np.pi)}
SA = {2: 2 * np.pi, 3: 4 * np.pi}

if __name__ == "__main__":
    print("g(0.3) direct %.15g vs 15/8 + gm %.15g" % (g(0.3), 15 / 8 + gm(0.3)))
    ks = 10.0 ** np.linspace(-3, 2, 41)
    q = [abs(E1(k)) / min(k, 1 / k) for k in ks]
    print("(1) sup_k |E(k)|/(a1 min(k,1/k)) on [1e-3, 1e2] = %.6f  (at k = %.4g);  E(k)/(a1 k) at k=1e-3: %.6f (12/5 = 2.4)"
          % (max(q), ks[int(np.argmax(q))], E1(1e-3) / 1e-3))
    Ik = quad(lambda k: E1(k) * k ** (-5 / 3), 0, np.inf, points=None, limit=800, epsabs=1e-14, epsrel=1e-12)[0] / 3
    Ik2 = (quad(lambda k: E1(k) * k ** (-5 / 3), 0, 1, limit=800, epsabs=0, epsrel=1e-12)[0]
           + quad(lambda k: E1(k) * k ** (-5 / 3), 1, np.inf, limit=800, epsabs=0, epsrel=1e-12)[0]) / 3
    Is = (quad(lambda s: s * E1(s ** -3), 0, 1, limit=800, epsabs=0, epsrel=1e-12)[0]
          + quad(lambda s: s * E1(s ** -3), 1, np.inf, limit=800, epsabs=0, epsrel=1e-12)[0])
    print("(2) (1/3) int (E/a1) k^{-5/3} dk = %.12g (split: %.12g);  int s (E/a1)(s^-3) ds = %.12g;  J/3 = %.12g"
          % (Ik, Ik2, Is, 4.1977819815839 / 3))
    rho = 0.5
    for l in (1e-3, 1e-6, 1e-9):
        t = l ** (1 / 3)
        brk = [0] + [t * x for x in (0.2, 0.5, 1, 2, 5)] + [rho]
        lhs = sum(quad(lambda r: r * E1(l / r ** 3), a, b, limit=400, epsabs=0, epsrel=1e-12)[0] for a, b in zip(brk[:-1], brk[1:])) / l ** (2 / 3)
        tail = (12 / 5) / (rho / t)      # int_{S}^inf s (12/5) s^{-3} ds = (12/5)/S, S = rho l^{-1/3}
        print("(3) l=%.0e  l^{-2/3} int_0^rho r (E/a1)(l/r^3) dr = %.12g ; defect = %.4e ; predicted tail (12/5)l^{1/3}/rho = %.4e"
              % (l, lhs, Is - lhs, tail))
    for d in (2, 3):
        print("(4) d=%d  c3 = |S| a1 (1/3) int (E/a1) k^{-5/3} dk = %.9g" % (d, SA[d] * A1[d] * Ik2))
