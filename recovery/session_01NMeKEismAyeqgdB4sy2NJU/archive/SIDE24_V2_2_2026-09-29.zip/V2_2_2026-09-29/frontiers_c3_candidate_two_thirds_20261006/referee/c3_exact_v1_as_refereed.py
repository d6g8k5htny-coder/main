"""Exact controls for note C3 (CL-C3-CANDIDATE-TWO-THIRDS-20261006-v1).

Standard library only; exact rational arithmetic; deterministic; output identical under -O.
Usage: python3 -B -S c3_exact.py [--mutant M1..M6]
On success: one JSON line on stdout, exit 0.
On a failed control: nothing on stdout, 'FAILED: <group>' on stderr, exit 1.
On invalid arguments: usage on stderr, exit 2.
"""
import json
import random
import sys
from fractions import Fraction as F

USAGE = "usage: c3_exact.py [--mutant M1..M6]\n"
MUTANTS = {"M1", "M2", "M3", "M4", "M5", "M6"}


def parse(argv):
    if len(argv) == 0:
        return None
    if len(argv) == 2 and argv[0] == "--mutant" and argv[1] in MUTANTS:
        return argv[1]
    sys.stderr.write(USAGE)
    sys.exit(2)


MUT = parse(sys.argv[1:])
RNG = random.Random(20261006)


class Failed(Exception):
    pass


def need(cond, group):
    if not cond:
        raise Failed(group)


def rat(lo=-9, hi=9, den=4):
    return F(RNG.randint(lo, hi), RNG.randint(1, den))


# ---------- small exact linear algebra ----------

def mat_mul(X, Y):
    return [[sum(X[i][t] * Y[t][j] for t in range(len(Y))) for j in range(len(Y[0]))] for i in range(len(X))]


def transpose(X):
    return [list(row) for row in zip(*X)]


def ident(n):
    return [[F(int(i == j)) for j in range(n)] for i in range(n)]


def inverse(X):
    n = len(X)
    M = [list(X[i]) + ident(n)[i] for i in range(n)]
    for c in range(n):
        p = next(i for i in range(c, n) if M[i][c] != 0)
        M[c], M[p] = M[p], M[c]
        piv = M[c][c]
        M[c] = [v / piv for v in M[c]]
        for i in range(n):
            if i != c and M[i][c] != 0:
                f = M[i][c]
                M[i] = [a - f * b for a, b in zip(M[i], M[c])]
    return [row[n:] for row in M]


def det(X):
    n = len(X)
    if n == 1:
        return X[0][0]
    return sum((-1) ** j * X[0][j] * det([row[:j] + row[j + 1:] for row in X[1:]]) for j in range(n))


def adj(X):
    n = len(X)
    if n == 1:
        return [[F(1)]]
    cof = [[(-1) ** (i + j) * det([row[:j] + row[j + 1:] for k, row in enumerate(X) if k != i]) for j in range(n)]
           for i in range(n)]
    return transpose(cof)


def cayley(m):
    """rational orthogonal matrix (I - S)(I + S)^{-1}, S skew."""
    S = [[F(0)] * m for _ in range(m)]
    for i in range(m):
        for j in range(i + 1, m):
            S[i][j] = rat(-5, 5, 3)
            S[j][i] = -S[i][j]
    I = ident(m)
    return mat_mul([[I[i][j] - S[i][j] for j in range(m)] for i in range(m)],
                   inverse([[I[i][j] + S[i][j] for j in range(m)] for i in range(m)]))


# ---------- E1: the adjugate at the edge, (I.1) and (1.2) ----------

def e1():
    n = 0
    for m in (1, 2, 3):
        for _ in range(40):
            lam = sorted({rat(-12, 12, 3) for _ in range(m + 3)})[:m]
            if len(lam) < m:
                continue
            O = cayley(m)
            need(mat_mul(transpose(O), O) == ident(m), "E1_edge")
            A = mat_mul(mat_mul(O, [[lam[i] if i == j else F(0) for j in range(m)] for i in range(m)]), transpose(O))
            cols = [[O[i][j] for i in range(m)] for j in range(m)]
            e = cols[m - 1]
            lm = lam[m - 1]
            P = F(1)
            for j in range(m - 1):
                P *= lam[j]
            R = [[F(0)] * m for _ in range(m)]
            for j in range(m - 1):
                c = F(1)
                for i in range(m - 1 if MUT != "M1" else m):
                    if i != j:
                        c *= lam[i]
                for a in range(m):
                    for b in range(m):
                        R[a][b] += c * cols[j][a] * cols[j][b]
            Ad = adj(A)
            need(det(A) == lm * P, "E1_edge")
            need(Ad == [[P * e[a] * e[b] + lm * R[a][b] for b in range(m)] for a in range(m)], "E1_edge")
            g = [rat() for _ in range(m)]
            Bm = [[F(0)] * m for _ in range(m)]
            for a in range(m):
                for b in range(a, m):
                    Bm[a][b] = Bm[b][a] = rat()
            f4, k = rat(), rat(0, 9, 4)
            ge = sum(g[a] * e[a] for a in range(m))
            Bee = sum(e[a] * Bm[a][b] * e[b] for a in range(m) for b in range(m))
            gAg = sum(g[a] * Ad[a][b] * g[b] for a in range(m) for b in range(m))
            gRg = sum(g[a] * R[a][b] * g[b] for a in range(m) for b in range(m))
            trAB = sum(Ad[a][b] * Bm[b][a] for a in range(m) for b in range(m))
            trRB = sum(R[a][b] * Bm[b][a] for a in range(m) for b in range(m))
            need(gAg == P * ge * ge + lm * gRg and trAB == P * Bee + lm * trRB, "E1_edge")
            Y = f4 / 12 * det(A) - gAg / 4
            W0 = P * f4 / 12 - gRg / 4
            need(Y == P * (-ge * ge / 4) + lm * W0, "E1_edge")
            U = Y + 3 * k * trAB
            Ured = 3 * k * Bee - ge * ge / 4
            need(U == P * Ured + lm * (W0 + 3 * k * trRB), "E1_edge")
            n += 5
    return n


# ---------- E2: the layer integral (I.2) ----------

def e2():
    n = 0
    c23 = F(1, 2) if MUT == "M2" else F(2, 3)
    for _ in range(500):
        a = F(RNG.randint(0, 60), RNG.randint(1, 7))
        beta = F(RNG.randint(1, 60), RNG.randint(1, 7))
        lo = -a / beta
        val = (a * a * 0 - beta * beta * 0 / 3) - (a * a * lo - beta * beta * lo ** 3 / 3)   # antiderivative a^2 x - b^2 x^3/3
        need(val == c23 * a ** 3 / beta, "E2_layer")
        P = rat(-9, 9, 3) or F(1)
        Ured, kap = rat(), F(RNG.randint(1, 50), RNG.randint(1, 5))
        need(c23 * (abs(P) * abs(Ured)) ** 3 / (6 * kap * abs(P)) == P * P * abs(Ured) ** 3 / (9 * kap), "E2_layer")
        n += 2
    return n


# ---------- E3: the Gaussian-kernel jet laws (G.1) ----------

def dfact(n):
    out = 1
    for j in range(n, 0, -2):
        out *= j
    return out


def dC(alpha):
    """d^alpha of exp(-|z|^2/2) at 0."""
    out = F(1)
    for a in alpha:
        if a % 2:
            return F(0)
        out *= (-1) ** (a // 2) * dfact(a - 1)
    return out


def cov(L1, L2):
    """L = {alpha: coef}; Cov(sum c d^alpha f(0), sum c' d^beta f(0)) = sum c c' (-1)^|beta| d^{alpha+beta} C(0)."""
    s = F(0)
    for a, c in L1.items():
        for b, cc in L2.items():
            s += c * cc * (-1) ** sum(b) * dC(tuple(x + y for x, y in zip(a, b)))
    return s


def unit(d, i, n=1):
    v = [0] * d
    v[i] += n
    return tuple(v)


def add(*idx):
    return tuple(sum(t) for t in zip(*idx))


def condition(X, pins):
    """regression coefficients of the functionals X on the pins, and the conditional covariance."""
    Sp = [[cov(p, q) for q in pins] for p in pins]
    Spi = inverse(Sp)
    coefs = []
    for x in X:
        c = [cov(x, p) for p in pins]
        coefs.append([sum(c[j] * Spi[j][i] for j in range(len(pins))) for i in range(len(pins))])
    Sc = [[cov(x, y) - sum(coefs[a][i] * cov(pins[i], y) for i in range(len(pins))) for b, y in enumerate(X)]
          for a, x in enumerate(X)]
    return coefs, Sc


def e3():
    n = 0
    for d in (2, 3, 4):
        u = 0
        dirs = [{1: F(1)}]
        if d >= 3:
            dirs.append({1: F(3, 5), 2: F(4, 5)})
        grad = [{unit(d, j): F(1)} for j in range(d)]
        dgrad = [{add(unit(d, u), unit(d, j)): F(1)} for j in range(d)]
        f3 = {unit(d, u, 3): F(1)}
        pins = grad + dgrad + [f3]
        for e in dirs:
            ge = {}
            Bee = {}
            for j, cj in e.items():
                key = add(unit(d, u, 2), unit(d, j))
                ge[key] = ge.get(key, F(0)) + cj
                for l, cl in e.items():
                    key = add(unit(d, u), unit(d, j), unit(d, l))
                    Bee[key] = Bee.get(key, F(0)) + cj * cl
            pins_used = pins if MUT != "M3" else [p for p in pins if p != grad[u]]
            coefs, Sc = condition([ge, Bee], pins_used)
            need(Sc == [[F(2), F(0)], [F(0), F(2)]], "E3_jets")
            i3 = pins_used.index(f3)
            need(coefs[0][i3] == 0 and coefs[1][i3] == 0, "E3_jets")       # no dependence on the target 12k
            n += 2
        cf, Sv = condition([f3], grad + dgrad)
        need(Sv == [[F(6)]], "E3_jets")                                   # v(k)^T Cov^{-1} v(k)/2 = (12k)^2/12 = 12k^2
        need(F(12) ** 2 / (2 * Sv[0][0]) == 12, "E3_jets")
        n += 2
    return n


# ---------- E4: moments and the Gamma identity (G.3) ----------

def e4():
    n = 0
    s2 = F(2)                                                     # variance of gamma and of B
    mom = {0: F(1), 1: F(0), 2: s2, 3: F(0), 4: 3 * s2 ** 2, 5: F(0), 6: 15 * s2 ** 3}
    # E[(g^2/4 - 3kB)^3] = sum_j C(3,j) E[(g^2/4)^{3-j}] (-3k)^j E[B^j]; polynomial in k: {power: coef}
    binom = [1, 3, 3, 1]
    poly = {}
    c27 = 24 if MUT == "M4" else 27
    for j in range(4):
        cg = mom[2 * (3 - j)] / F(4) ** (3 - j)
        cb = mom[j] * (-3) ** j
        poly[j] = poly.get(j, F(0)) + binom[j] * cg * cb
    if MUT == "M4":
        poly[2] = poly[2] * F(c27, 27)
    poly = {p: c for p, c in poly.items() if c != 0}
    g0 = mom[6] / 64
    need(g0 == F(15, 8) and poly == {0: F(15, 8), 2: F(27)}, "E4_moments")
    b, a = poly[2] / g0, F(12)
    need(b == F(72, 5) and b == 6 * a / 5, "E4_moments")
    for _ in range(200):
        aa, bb = F(RNG.randint(1, 40), RNG.randint(1, 6)), rat(-40, 40, 6)
        # after the factor Gamma(1/6) a^{-1/6}: (1/2)Gamma(-5/6)/Gamma(1/6) a + b/2 with Gamma(-5/6) = -(6/5)Gamma(1/6)
        need(F(1, 2) * F(-6, 5) * aa + bb / 2 == F(1, 2) * (bb - 6 * aa / 5), "E4_moments")
        n += 1
    need(F(1, 2) * (b - 6 * a / 5) == 0, "E4_moments")
    return n + 4


# ---------- E5: the constant of (3.2) ----------

def e5():
    c = F(12, 8) if MUT == "M5" else F(12, 9)
    need(c * F(1, 64) == F(1, 48), "E5_constant")
    need(F(1, 48) / F(5, 24) == F(1, 10), "E5_constant")
    need(F(15) * F(2) ** 3 == 120 and F(120, 64) == F(15, 8), "E5_constant")
    return 3


# ---------- E6: the domination of section 4 ----------

def e6():
    n = 0
    ex = 2 if MUT == "M6" else 3
    need(1 - ex < -1, "E6_domination")                                  # s * s^{-ex} integrable at infinity
    need(F(-1, 3) + F(-4, 3) == F(-5, 3), "E6_domination")              # s ds = (1/3) k^{-5/3} dk, s = k^{-1/3}
    for _ in range(400):
        t = F(RNG.randint(1, 30), 100)                                   # l = t^3, l^{1/3} = t
        rho = F(RNG.randint(1, 100), 100)
        s = F(RNG.randint(1, 400), 20)
        if s > rho / t:
            continue
        r, k = t * s, 1 / s ** 3
        kap = k / r
        need(kap == 1 / (t * s ** 4) and k == t ** 3 / r ** 3, "E6_domination")
        lhs = min(r, r * kap) + min(k, 1 / k)
        need(lhs <= 2 * min(F(1), s ** -ex), "E6_domination")
        n += 1
    return n + 2


def main():
    groups = [("E1_edge", e1), ("E2_layer", e2), ("E3_jets", e3), ("E4_moments", e4), ("E5_constant", e5),
              ("E6_domination", e6)]
    counts = {}
    try:
        for name, fn in groups:
            counts[name] = fn()
    except Failed as ex:
        sys.stderr.write("FAILED: %s\n" % ex.args[0])
        sys.exit(1)
    out = {"object": "CL-C3-CANDIDATE-TWO-THIRDS-20261006-v1", "checks": counts, "total": sum(counts.values()),
           "passed": True}
    sys.stdout.write(json.dumps(out, sort_keys=True, separators=(",", ":")) + "\n")


if __name__ == "__main__":
    main()
