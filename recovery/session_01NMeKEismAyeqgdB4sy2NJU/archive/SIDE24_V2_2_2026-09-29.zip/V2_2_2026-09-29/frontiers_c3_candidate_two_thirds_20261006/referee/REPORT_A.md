# Referee report, Slice A (§§0–2) of note C3 (`CL-C3-CANDIDATE-TWO-THIRDS-20261006-v1`)

(Saved by the author from the subagent's hand-back message; the harness blocked subagents from writing report files.
Text as returned, lightly reflowed.)

**Verdict: AMEND.** There is no blocking finding.

The statements of §0 are well formed and match the sources. Lemma 0, the identities (I.1)–(I.2) and Lemma F₃ are correct,
including the constant `12/(9k)` and the factor `P²`. Three kinds of evidence support this:
- a symbolic check of (I.1), (1.2) and (I.2);
- a line-by-line check of Steps 1–5 against #237, #218 and note LU;
- an independent Monte Carlo of `(𝐓_r − 𝐒_r)/r` for the Gaussian kernel in `d = 2` and `d = 3` (40 points; every ratio to
  `𝐋_F` lies in `[0.991, 1.005]`).

Two intermediate statements in the proof are false as written (findings 1 and 2), and their conclusions survive.
Replacement texts follow. The rest are nits, plus one interface item for Slice B and one cross-slice observation for
Slice C.

## Findings

### 1. SHOULD-FIX: §2 Step 5, "The main part". The bound on `∂_λJ` is false; the conclusion holds.

**Problem.** The text says `|∂_λJ| ≤ C(1 + |Rest|)^N|P|q(Rest)` near `λ = 0`. This is false.
- `J` contains the Vandermonde factor `∏_{j<m}(λ − λ_j)`. Its `λ`-derivative is a sum of products of `m − 2` of the factors,
  which is not `O(|P|)`.
- Example, `m = 2`: `J ∝ (λ − λ₁)p_A p_odd` with `P = λ₁`. Then `∂_λJ` contains the term `p_A p_odd = O(1)`, while
  `|P| = |λ₁|` can be small.
- On `𝔈` the correct factor is `|P|Σ_{j<m}|λ_j|^{−1} ≤ (m − 1)|P|/η`. So the stated bound fails by a factor up to `r^{−1/4}`.

**Why the conclusion survives.** The `|P|` is not needed, because `a² = P²U_red²` already carries `P²`. The bound that does
hold is `|∂_λJ| ≤ C(1 + |Rest|)^N q(Rest)` for `λ_{m−1} < λ ≤ 1`. With it, the error term `(a/β)²a²sup|∂_λJ|` integrates to
`O(r²k^{−2})`.

**Two smaller gaps in the same bullet.**
- The use of (I.2) on `(−a/β, 0)` needs `a/β < |λ_{m−1}|`. On `𝔈` this means `|U_red| < 6kr^{−3/4}`; the complement costs
  `O(r^p)`.
- The remainder `O(r^{5/4})` is a valid upper bound, but nothing shown produces it. The listed costs give
  `O(r²(1 + k^{−2}))`: `y < 0`: `O(r²/k)`; the perturbation: `O(r²(1 + k^{−2}))`; the main part, with the corrected
  bound: `O(r²k^{−2})`; `𝔊^c`: `O(r^p)`.

**Exact replacement** for the whole bullet "*The main part.*":

```
- *The main part.* Let `J(λ, Rest)` be the joint density of `(λ_m, Rest)` under `Q̄_{r,k}`: the Weyl density of `A` (as in
  the proof of Lemma 0, for the law of `A` under `Q̄_{r,k}`) times the Gaussian density of the odd jets, which are independent
  of `A` (R.2). It is `C¹` in `λ` on `(λ_{m−1}, ∞)`, and `|∂_λJ| ≤ C(1 + |Rest|)^N q(Rest)` for `λ_{m−1} < λ ≤ 1`, with `q` a
  Gaussian factor. (There is no factor `|P|` here: `∂_λ∏_{j<m}(λ − λ_j)` is a sum of products of `m − 2` of the factors and
  is not small when one `|λ_j|` is. The factor `P²` of the result comes from `a²`.) On `𝔈 ∩ {|U_red| < 6kr^{−3/4}}` we have
  `a/β = |U_red|/(6κ) = r|U_red|/(6k) < η ≤ |λ_{m−1}|`, so by (I.2)

      ∫_{−∞}^0 (a² − β²λ²)₊ J(λ, Rest) dλ = J(0⁻, Rest) P²|U_red|³/(9κ) + O((a/β)² a² sup_{|λ|≤a/β}|∂_λJ|),

  and the error integrates over `Rest` to `O(r²k^{−2})`; the event `{|U_red| ≥ 6kr^{−3/4}}` costs `O(r^p)`. Integrating over
  `Rest` on `𝔈`, `E[Λ₁] = (r/(9k))𝔼_{Q̄_{r,k}}[P²|U_red|³1_𝔈; λ_m = 0⁻] + O(r²(1 + k^{−2}))`, the `O` including the costs
  above and `𝔊^c`. (The edge expectation under `Q̄_{r,k}` exists by the argument of Lemma 0.)
```

### 2. SHOULD-FIX: §2 Step 4, bullet `Λ₂`. "By (2.2) `B_ee < 0`" does not follow; the conclusion holds, and an exact argument is available.

**Problem.**
- `λ < 0 ≤ λ_M` and (2.2) give `−(r/2)B_ee > −Cr^{7/4}𝔗²`, that is `B_ee < Cr^{3/4}𝔗²`. They do not give `B_ee < 0`.
- When `0 ≤ B_ee < Cr^{3/4}𝔗²`, the stated equality `U_red = −(γ_e²/4 + 3k|B_ee|)` is false.
- The conclusion `|P|γ_e² ≤ C(r^{3/4}|P| + r)𝔗^N` still follows. Use `|U_red| ≥ γ_e²/4 − 3kB_ee` and
  `6κ|λ| ≤ −3kB_ee + Ckr^{3/4}𝔗²`.

**A stronger, exact argument.** On `𝔊 ∩ 𝔈` the strip lies inside the layer exactly, not just to first order, so `Λ₂ = 0`
there for `r ≤ r(k)`. The reason is that the Schur complement of `A_M` in `K_M` is strictly negative on the strip.

Numerical support, from my samples of the exact conditional law:
- on the strip, `𝔞 > 0`, `α_M < 0` and the Schur complement is negative in every sample whose `A_M` has a negative second
  eigenvalue;
- the 1% quantile of `𝔞/(|P|γ_e²/4 + r)` tends to 1 as `r → 0`;
- in the main Monte Carlo there are `1.0·10⁷` strip samples. None in `d = 2` and 6 in `d = 3` have `|x| < y`, and all 6
  lie at `r ≥ 0.02` with total contribution `|Λ₂|/r ≤ 2·10⁻¹⁰`.

**Exact replacement (recommended)** for the bullet "*`Λ₂`* (the strip). …" and the paragraph after it:

```
- *`Λ₂`* (the strip) vanishes for small `r`. On `𝔊 ∩ 𝔈 ∩ {λ < 0 ≤ λ_M}` the matrix `A_M` has exactly one nonnegative
  eigenvalue `λ_M`, positive almost surely, and its other eigenvalues are `≤ −r^{1/4}/2` (Step 3). Write
  `K_M = [[α_M, √r β_Mᵀ], [√r β_M, A_M]]` with `α_M = ∂_u²g(M)/r` and `β_M = ∇_Θ∂_ug(M)/r`; the pins give
  `α_M = −6k + O(r𝔗)` and `|β_M| ≤ C𝔗` (#237's proof of Lemma Π; note LU §2). With `e_{M,j}` the unit eigenvectors of `A_M`,
  the Schur complement of `A_M` in `K_M` is
  `σ_M = α_M − r(β_M·e_{M,m})²/λ_M − rΣ_{j<m}(β_M·e_{M,j})²/λ_j(A_M) ≤ −6k + Cr𝔗 + 2r^{3/4}|β_M|² < 0` for `r ≤ r(k)`
  (on `𝔊`). Since `det A_M` has the sign `−s`, `det K_M = det A_M·σ_M` has the sign `s`: `𝔞 > 0`, so `|x| ≥ y`. Hence
  `Λ₂ = 0` on `𝔊 ∩ 𝔈` for `r ≤ r(k)`.

  So the strip lies inside the layer `{|x| ≥ y}`. To first order this is the computation `|U_red| ≥ γ_e²/4 − 3kB_ee` and
  `6κ|λ| ≤ −3kB_ee + O(r^{3/4})` on the strip (by (2.2)).
```

(For `m = 1` the sum over `j < m` is empty, and `σ_M < α_M < 0`.)

**Minimal alternative**, if the author keeps the probabilistic argument: replace the first two sentences of the bullet by
"It needs `λ < 0 ≤ λ_M`, so by (2.2) `|λ| ≤ −(r/2)B_ee + Cr^{7/4}𝔗²` (so `B_ee < Cr^{3/4}𝔗²`; `B_ee` need not be negative)
and `|λ| ≤ r𝔗`; hence `6κ|λ| ≤ −3kB_ee + Ckr^{3/4}𝔗²`. Since `|U_red| ≥ −U_red = γ_e²/4 − 3kB_ee`,
`|x| ≥ |P|(γ_e²/4 − 3kB_ee) − Cr𝔗^N`, while `y ≤ 6κ|λ||P| + Cr𝔗^N ≤ |P|(−3kB_ee + Ckr^{3/4}𝔗²) + Cr𝔗^N`." Then replace
"With the layer device and `E[|P|^{−1/2}1_𝔈] ≤ C`, `E|Λ₂| ≤ Cr(r^{3/8} + r^{1/2}) = o(r)`" by "With the layer device, and
`(r/|P|)^{1/2} ≤ r^{1/4}` on `𝔈`, `E|Λ₂| ≤ Cr(r^{3/8} + r^{1/4}) = o(r)`"; and in the last paragraph replace
"`|U_red| ≥ 3k|B_ee|` while `6κ|λ| ≤ 3k|B_ee|`" by "`|U_red| ≥ −3kB_ee` while `6κ|λ| ≤ −3kB_ee`".

### 3. NIT: (2.3). Cross-term sign.

`x = s(PU_red + λW) + ε₊` and `s² = 1`, so the cross term of `x²` is `2PU_red·λW`, not `2sPU_red·λW`. The two differ for odd
`m`. Replace `ϱ = 2sPU_red·λW + …  + O((1 + a + |λW|)ε₊)` by
`ϱ = 2PU_red·λW + λ²W² − 2β|λ|(rsV + ε₋) − (rsV + ε₋)² + O((1 + a + |λW|)|ε₊|)`.

### 4. NIT: §2 Step 2, bullet "On `𝔊 \ 𝔈`". Wrong reference.

(1.1) is the `r = 0` edge formula; what is used here is the Weyl density of `A` under `Q̄_{r,k}`. Replace "In Weyl
coordinates (1.1) both sets above then confine two eigenvalues:" by "In Weyl coordinates for the law of `A` under
`Q̄_{r,k}` (as in the proof of Lemma 0), both sets above then confine two eigenvalues:".

### 5. NIT: §2 preamble. The definition of `𝔗` and its moment bound.

Replace "and let `𝔗 := 1 + ‖g‖_{C^{N₀}(𝔅)}` as in note LU §2, with `E[𝔗^p | J] ≤ C_p(1 + |J|)^p` …" by "and let
`𝔗 := 1 + ‖g‖_{C^{N₀}(𝔅)}` (the fixed-`k` analogue of note LU §2's `𝔗`), with `E[𝔗^p | J] ≤ C_p(1 + k + |J|)^p` for the
free-jet vector `J` (#218 (1.2); #237 Lemma R (R.4)). Note LU §2's deterministic form of Lemma Π applies to `g`, with
constants depending on `k`."

### 6. NIT: §2 Step 2, "Off `𝔊`". Exponent.

Replace "`P(𝔊^c | J) ≤ C_pr^p(1 + |J|)^p` for every `p`" by "`P(𝔊^c | J) ≤ C_pr^p(1 + k + |J|)^{p/θ}` for every `p`
(Markov's inequality with `E[𝔗^{p/θ} | J]`)".

### 7. INTERFACE (Slice B's call): §3 uses §2 Step 2's second bullet with a `δ` that depends on `A`.

§2's bullet integrates `λ_m` over an interval of length `2δ/D` with `δ` not depending on the eigenvalues; §3 applies it with
`δ := |Y′|/(6κ)`, which depends on `A`, including `λ_m`. One-line fix: on `{A < 0}` with `m ≥ 2`,
`|Y′| ≤ M := C(1 + |f₄| + |γ|)²(1 + |λ₁|)^m`, which does not depend on `λ_m`; apply the bullet with `δ := M/(6κ)` in dyadic
layers of `M` given `A`, as in #218 Lemma O and #237 Lemma Λ₀; for `m = 1`, `𝔈_κ = Ω` and the bullet is not used.

### 8. CROSS-SLICE (for Slice C): Remark 6, Remark 1 and the header.

Two `d = 2`, `r = 0.0025` entries of Remark 6's table deviate from 1 by more than 4 quoted standard errors
(`1.058 ± 0.012` at `k = 0.2`; `0.929 ± 0.016` at `k = 0.8`); the `±` come from 4 replicates. An independent
importance-sampled Monte Carlo gives `0.9964 ± 0.0034` and `0.9963 ± 0.0017` at these points. Remark 1's
"`|U_red| ≥ 3k|B_ee| ≥ 6κ|λ|`" should read "`|U_red| ≥ −3kB_ee ≥ 6κ|λ| − O(r^{3/4})`". If finding 2's text is adopted, "to
first order" can be dropped from the header and Remark 1.

## Answers to the five questions (summary)

1. Layer coefficient: correct ((I.1), (I.2), (2.1), the signs; `d = 3` Monte Carlo rejects `|P|` or `|P|³` in place of `P²`).
2. Typedness criterion (Step 3): correct (Haynsworth; zero mismatches in `3.9·10⁸` samples).
3. Strip (Step 4): correct up to finding 2; `Λ₃` negligible.
4. Steps 2 and 5: sound up to finding 1; Lemma 0 correct.
5. §0 statements: well formed and consistent, except the interface item 7.

## Independent numerics (files in `refA/`)

`engine.py`, `lf_indep.py` (`𝐋_F` without assuming (G.1)), `mc_layer.py` (typedness by eigenvalues; defensive multi-window
importance sampling of `λ_max(A)`), `strip_check.py`, `sym_I1.py`. Over 40 points (`d = 2, 3`; `k ∈ {0.2, 0.4, 0.6, 0.8}`;
`r ∈ {0.0025, …, 0.04}`): `χ²/dof = 1.35`, mean `z = −0.11`, max `|z| = 2.38` (table in `mc_summary.txt`).

## Hashes

`C3_under_review.md` `31ad5812…288cea` and `c3_exact_under_review.py` `8e74a629…4944a`, identical before and after.

## Disclosure

Anthropic Claude subagent running inside the author's own session; author-side referee pass with clean context; not a
nonauthor review; no review credit.
