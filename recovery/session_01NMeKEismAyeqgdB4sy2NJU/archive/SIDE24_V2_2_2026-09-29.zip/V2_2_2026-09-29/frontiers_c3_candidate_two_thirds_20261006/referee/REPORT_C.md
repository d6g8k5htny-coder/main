# Referee report, Slice C (§§5–6 and the header): note C3, `CL-C3-CANDIDATE-TWO-THIRDS-20261006-v1`

(Saved by the author from the subagent's hand-back message; the harness refused report files from subagents. Text as
returned, lightly condensed in the "What I checked" part.)

**Verdict: AMEND.** The mathematics of §5 is correct; every value in §5 and Remarks 2–3 reproduces. One BLOCKING finding
(C-1), six SHOULD-FIX, twelve NITs. Every change is wording.

## Findings

### C-1 BLOCKING: Corollary G′ and the header claim sharpness for a field the theorems do not cover

Theorem P⁺ (note LU) and Theorem C3 are stated for the [P] torus field; "the Gaussian kernel" of Proposition G is the model
on `R^d` (#242 §0). No source on file proves P⁺ or C3 for the model field. What Proposition G proves: the functional (C3),
evaluated on the model's jet law, is positive. For the torus field the sign follows only through the transfer that Remark 5
says is not proved. Replacements:
- (a) §0: "**Corollary G′ (the model value is positive).** For the Gaussian kernel, the coefficient `c₃` of (C3), evaluated
  on the model's jet law, is positive. Hence, for any field to which Theorem C3 applies and whose `c₃` is nonzero, the
  remainder `O(ℓ^{2/3})` of note LU's Theorem P⁺ is of exact order `ℓ^{2/3}`. Theorems P⁺ and C3 are stated for the torus
  field of #237 §0; that its `c₃` has the model's sign needs the transfer of Remark 5, which is not proved here."
- (b) header: "So the model value of `c₃` is positive (Corollary G′); for a field whose `c₃` is nonzero, the remainder
  `O(ℓ^{2/3})` of Theorem P⁺ is attained. For the torus field this needs the transfer of Remark 5, which is not proved here."
- (c) *Not claimed*: "and the sign of the model value of `c₃` is proved, not certified. Nothing about the torus field beyond
  the general Theorem C3: neither the sign of its `c₃` nor the sharpness of Theorem P⁺ for it (Remark 5)."
- (d) §5: "*Corollary G′.* `∫∫F₀ > 0` (#242 Theorem 1) and `J > 0`, so the model value of `c₃` is positive. The rest is
  Theorem C3. ∎"

### C-2 SHOULD-FIX: Remark 5 states as fact the continuity it then disclaims

Replacement: "5. **The torus field.** Theorem C3 holds for the torus field itself, with `c₃` given by (C3). Proposition G and
Corollary G′ are about the model case. The torus field's jet covariances differ from the model's by `O(e^{−L²/8})` (#242 §0).
If `c₃` depends continuously on them, as expected but not proved here, then at `L = 24` the digits above are unchanged. For
large `L` the torus field's `c₃` is then positive, so Theorem P⁺ is sharp for it. That transfer is not proved or certified
here."

### C-3 SHOULD-FIX: Remark 3's SIDE24 sentence omits the far elder term and the model-to-torus step

Replacement: "For SIDE24 (`d = 3`, `L = 24`), with the model values (Remark 5), this would make the next relative term of the
near elder density `≈ 1.854ℓ`. For `ν_eld` itself the far term also enters at this order: #187 bounds `ν_eld^{far,r_0^*}`
only by `O(ℓ^{2/3})`, and #188's `O(ℓ^N)` is not used here. Both lie inside note LU's `O(ℓ log(1/ℓ))`."

### C-4 SHOULD-FIX: Remark 3 implies only #242's input (ii) is missing; input (i) is missing too

Replacement bullet: "What a proof would still need are #242's inputs (i) and (ii), in their `o(ℓ^{2/3})` form. (i) On the
soft layer `κ ≥ 1`, note TL's Corollary TL1 has remainder `O(ℓ^{2/3})`, and its Remark 2 records, through #243 Theorem FL,
the rejected fold limit `κ(𝐓_r^{rej} − 𝓐^{rej}) → ∫(F − F₀)db` at fixed `k`. The soft layer's `ℓ^{2/3}` coefficient is not
derived from these here. (ii) On the intermediate separations, note LU leaves the elder mass at `O(ℓ^{2/3}log(1/ℓ))`
(addendum EM.1). Nothing here is claimed for either part."

### C-5 SHOULD-FIX: Prior work says note TL names this term, but it does not

Replace "in #242 Conjecture 7's Remark 1, and in notes TL and LU (Remark 2 of each)." with "in #242 Conjecture 7's Remark 1,
and in note LU's Remark 2. Note TL's Remark 2 concerns the analogous `k²/κ` term of the rejected kernel, which carries
`R_{2/3}`, not this term."

### C-6 SHOULD-FIX: Consumed and Cited-only lists

Consumed: note LU §0 (the setting) and Lemma S (S.4); #242's positivity `𝔇 > 0`. Cited only: note LU's Corollary LU;
addendum EM.1; #242 §4's inputs (i)–(ii), matched-asymptotics count, Conjecture 7's Remark 1; #216's Monte Carlo; and, with
C-3 and C-4 applied, #187, #188, note TL's Corollary TL1, #243 Theorem FL.

### C-7 SHOULD-FIX: Remark 6's error bars are unreliable, and its outlying entries do not reproduce

Each `±` is a standard error over a few replicates (defaults 4 × `2·10⁶` in `d = 2`, 8 × `10⁶` in `d = 3`). Four entries sit
2.9–4.9 nominal errors from 1. Reruns with 24 replicates: `d = 2`: `k = 0.2, r = 0.0025`: `0.978 ± 0.016`; `k = 0.4,
r = 0.0025`: `0.991 ± 0.011`; `k = 0.8, r = 0.0025`: `0.997 ± 0.009`; `k = 0.2, r = 0.01`: `0.996 ± 0.007`; `k = 0.2,
r = 0.04`: `1.001 ± 0.004`; `k = 0.8, r = 0.04`: `1.005 ± 0.003`; `d = 3`: `k = 0.4, r = 0.02`: `0.996 ± 0.005`; `k = 0.4,
r = 0.005`: `1.009 ± 0.024`. Rerun with at least 24 replicates and replace the table, or annotate it.

### NITs

- C-8: `0.990 ± 0.007` should be `0.989 ± 0.007` (double rounding).
- C-9: `layer_birth_mc.py` imports `covmat`, `pi_density` from `cusp_parity_mc.py` (#237's archive); publish or pin it.
- C-10: Remark 2 replacement: the leading term `(12/5)a₁ = 0.0034913` is reached only as `k → 0` (the `k^{7/2}` coefficient
  of `e^{−12k²}g(k)/g(0) − 1` is about `+93`); the effective coefficient is `0.0045`, `0.0056`, `0.0055` at `k = 0.05`, `0.1`,
  `0.2`; `𝐄(k)` changes sign at `k ≈ 0.369`; the README's `+0.005` lies in this range; the comparison is only qualitative.
- C-11: Remark 1: add the sliver `{λ_max(A) ≥ 0 > λ_max(A_M)}` (costs `O(r²)`, Step 4); the strip lies inside the layer to
  first order: `|U_red| ≥ 3k|B_ee|`, while `6κ|λ| ≤ 3k|B_ee|` up to `O(kr^{3/4}𝔗²)`.
- C-12: (G.1): "their regressions use disjoint sets of pins that are uncorrelated with each other (`∂_ef(0)`; and `∂_uf(0)`,
  `∂_u³f(0)`), so their conditional covariance is `0` and they are independent".
- C-13: §7, E4: the 200 random checks of the Gamma identity's "rational part" cannot fail; say so (as #237's Q6 does).
- C-14: one numeric precision in header and §5; label "(exploration; §5)"; `c₃/c_{d,∞}`; reword "cancels the `k²`-part of
  the layer" to "cancels exactly the contribution of `E[X³] = 15/8 + 27k²`, together with the density factor and the
  cusp-tail subtraction".
- C-15: "the author-side referee's" numerics in #237's README (header and Remark 2).
- C-16: header: "#218's Lemma F, with #237 Lemma K, bounds this difference".
- C-17: "the near elder density `ν_eld − ν_eld^{far,r_0^*}`"; define `c₁` (#220 (0.2)); rename `𝔡` → `𝔡̄`.
- C-18: Remark 3, #216: add that the term would raise the count ratio to about `1.004` (`d = 2`) and `1.009` (`d = 3`); it
  is not a test; the ratios are also consistent with no such term; #216's fields are tori of side 64 and 16 and include far
  pairs; over wider ranges #237 Remark 4 records elder residuals that single-power fits place at `p ≈ 0.14–0.33`.
- C-19: header disclosure of the three author-side referee passes and how their findings were applied.

## What I checked (summary)

Controls replayed (both modes byte-identical; mutants M1–M6 rejected at their groups; usage exit 2). (G.1) recomputed
exactly (sympy) in `d = 2, 3, 4`, axial and non-axial frames. `g`, `E[X³]`, the Gamma identity and `J` by a different route
(Bessel `K_{4/3}`): `J = 4.1977819815839`. `a₁`, `c₃`, `c₃/c` and Remark 2–3 numbers reproduced (`derived.py`). Remark 3's
equivalence checked; `R_{2/3}` from #242's `Ĩ` agrees with #244. Remark 6 recomputed from the JSON; reruns as above.
Quotations and citations checked; the Prior-work citation of note TL is not accurate (C-5).

## Not checked

The proofs of §§0–4; #237's README beyond the excerpt; #216/#223/#244 values beyond the facts given; whether #243 and #188
have merged; the [P] covariance being exactly the periodized Gaussian; the author's `c3_formula.py` (did not finish in 10
minutes); the author's `d = 2` Monte Carlo (imports a module not provided; reimplemented instead).

## Hashes

`C3_under_review.md` `31ad5812…288cea`, `c3_exact_under_review.py` `8e74a629…4944a`, identical before and after.

## Disclosure

Anthropic Claude subagent in the author's session; author-side referee pass; not a nonauthor review; no review credit.
