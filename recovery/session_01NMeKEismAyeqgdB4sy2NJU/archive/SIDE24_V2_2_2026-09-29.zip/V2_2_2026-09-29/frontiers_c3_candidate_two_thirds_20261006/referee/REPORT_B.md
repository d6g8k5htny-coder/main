# Referee report, Slice B (§§3–4) of note C3 (`CL-C3-CANDIDATE-TWO-THIRDS-20261006-v1`)

(Saved by the author from the subagent's hand-back message; the harness refused report files from subagents. Text as
returned, lightly condensed in §§B–C.)

## Verdict: AMEND

There is no blocking finding.
- **Correct:** Lemma T₁ ((3.1), the cusp-tail limit, `a₁ = (1/10)∫F₀db`); the proof of Theorem C3 ((4.1), (4.2), the
  domination, the four pointwise limits, dominated convergence, the Jacobian).
- **Confirmed numerically:** the T₁ limit with independent code (Gaussian kernel, `d = 2, 3`).
- **To amend:** three SHOULD-FIX justification gaps (B-1 a bound applied outside its hypothesis; B-2 a mis-stated
  inequality; B-3 an unnamed dominating function), each closed by a device already in the consumed sources.
- **NITs:** B-4 to B-9 (B-9 is cross-slice: §2 Step 5, inherited by §3).

## A. Findings

### B-1 (SHOULD-FIX). §3, the off-`𝔈_κ` bound

#218's second-bound argument for Lemma D needs `δ` independent of the least-modulus eigenvalue; here `δ := |Y′|/(6κ)` depends
on `A` (through `Δ = λP` and `A^♯ = Peeᵀ + λR`), and "conditionally on the other jets" does not remove this (`f₄` is
correlated with `A`). The bound is true; the standard proof uses dyadic layers of `|Y′|` (#218's proof of Lemma O; #237
Lemma Λ₀).

**New:** "Off `𝔈_κ` (so `m ≥ 2`), use the dyadic layers of `|Y′|` of #218's proof of Lemma O. On `{2^{j−1} ≤ |Y′| < 2^j}`
(`j ≥ 1`; `{|Y′| < 1}` for `j = 0`) the integrand is at most `4^j`, and the event lies in `{A < 0, |Δ| ≤ δ_j}` with
`δ_j := 2^j/(6κ)`, which does not depend on `A`. Given `A`, `(f₄, γ)` is Gaussian with mean affine in `A` and bounded
covariance, and `Y′` is a polynomial in `(f₄, γ)` with coefficients polynomial in `A`, so
`P(|Y′| ≥ 2^{j−1} | A) ≤ C_p2^{−jp}(1 + ‖A‖)^{n_p}`. The second sub-bullet of §2 Step 2's bullet *On `𝔊 \ 𝔈`* (the proof of
#218 Lemma D's second bound, with a second eigenvalue within `η′ := max(η, η^{2/(m−1)})` of `0`), with the weight
`(1 + ‖A‖)^{n_p}`, gives `E[(1 + ‖A‖)^{n_p}1{A < 0, |Δ| ≤ δ_j}1_{𝔈_κ^c}] ≤ Cδ_jη′`. Summing over `j` with `p > 3` gives
`E[Y′²1{A<0, |Δ| ≤ |Y′|/(6κ)}1_{𝔈_κ^c}] ≤ Cκ^{−1}η′ = o(κ^{−1})`." **Consumed, #218 line:** add "Lemma O's proof (the dyadic
layers of `|Y|`)".

### B-2 (SHOULD-FIX). §3, the bound on `ϱ`

"`|ϱ| ≤ C(1 + γ_e²)²(1 + |W₀|)²/κ`" is false as stated: the first term `−Pγ_e²λW₀/2` is bounded on `|λ| ≤ γ_e²/(12κ)` only by
`|P|γ_e⁴|W₀|/(24κ)`, and `P` is unbounded on `𝔈_κ` (e.g. `γ_e = W₀ = 1`, `λ = −1/(12κ)`, `|P| = 10⁶` gives `ϱ ≈ 4·10⁴/κ`).
The conclusion `O(κ^{−2})` stands, since `P` has all moments. **New:** "and there, for `κ ≥ 1`,
`|ϱ| ≤ |P|γ_e⁴|W₀|/(24κ) + γ_e⁴W₀²/(144κ²) ≤ (1 + |P|)(1 + γ_e²)²(1 + |W₀|)²/κ`."

### B-3 (SHOULD-FIX). §3, the `b`-integral in the proof of (3.2)

Exchanging `lim_{ε↓0}` with `∫db` needs a dominating function uniform in `ε`; the Gaussian factor of `π₀` supplies only the
decay in `b`; the missing half is the polynomial bound on the `ε`-quotients (#242's proof of Corollary 1′, from
(1.1a)–(1.1b)). Also (R.1) is stated for `r > 0`; at `r = 0` the disintegration is used "as in (R.1)" (#237 Step U4).
**New:** "For each `ε > 0`, the disintegration of (R.1) at `r = 0`, `k = 0` (as in #237 Step U4) gives
`∫_Rπ₀(u; v₀(b, 0))ε^{−1}E₀[γ₁⁶(μ₂⋯μ_m)²1{A<0, μ₁ < ε} | b]db = p_{V_0}(v(0))ε^{−1}E_{Q̄_{0,0}}[P²γ_e⁶1{−ε < λ_m < 0}]`.
Let `ε ↓ 0`. The right side tends to `p_{V_0}(v(0))𝔼_0[P²γ_e⁶; λ_m = 0⁻]` (Lemma 0). On the left, dominated convergence
applies. By #242 (1.1a)–(1.1b) and (G1), `ε^{−1}E₀[γ₁⁶(μ₂⋯μ_m)²1{A<0, μ₁ < ε} | b] ≤ C(1 + |b|)^N` for `0 < ε ≤ 1`: this is
the bound of #242's proof of Corollary 1′, with `E[γ₁⁶ | A] = 15(e₁ᵀΣ_γe₁)³ ≤ C`. And `π₀(u; v₀(b, 0)) ≤ Ce^{−cb²}` ([R]
(R5), as in #242's proof of Theorem 1). So `∫_Rπ₀(u; v₀(b, 0))𝔇(b, u)db = p_{V_0}(v(0))𝔼_0[P²γ_e⁶; λ_m = 0⁻]`."
**Consumed, #242 line:** "(1.1a)" → "(1.1a)–(1.1b) and the uniform bound of its proof of Corollary 1′".

### B-4 (NIT). §3, (3.1): cite Lemma K for `𝐀₂(0, u) = ∫A₂(b, 0, u)db`, and the disintegration of (R.1) at `r = 0` (Tonelli;
as in #237 Step U4).

### B-5 (NIT). §3: the window against `λ_{m−1}`. Insert after "that is `|λ| ≤ γ_e²/(12κ)`,": "(on `𝔈_κ` this window lies in
`(λ_{m−1}, 0)`, where the density is `C¹` in `λ`, unless `γ_e² ≥ 12κ^{3/4}`; given `A`, `γ_e` is centred Gaussian with bounded
variance, so that event costs `O(κ^{−p})` against the weight `Y′²`)".

### B-6 (NIT). §3, notation clash: write `μ_i` for #242's eigenvalues of `−A` (`μ_i = −λ_{m+1−i}`); so
`{A < 0, μ₁ < ε} = {−ε < λ_m < 0}`, the eigenvector of `μ₁` is `±e`, `γ₁² = γ_e²` and `(μ₂⋯μ_m)² = (λ₁⋯λ_{m−1})² = P²`.

### B-7 (NIT). "(1.2) at `k = 0` gives `Y′ = …` and `Δ = λP`" → "(I.1) and (1.2) give `Δ = λP` and `Y′ = P(−γ_e²/4) + λW₀`."

### B-8 (NIT). §4: "(as `ρ ≤ 1`)" → "(as `ρ ≤ 1`, which we may assume by taking `r₄ ≤ 1`)".

### B-9 (NIT, cross-slice: §2 Step 5). "`|∂_λJ| ≤ C(1 + |Rest|)^N|P|q(Rest)`" is not right (the `λ_m`-derivative of the
Vandermonde factor at `0` is `Σ_{j<m}∏_{i<m, i≠j}|λ_i|`, not `O(|P|)`); no factor `|P|` is needed, since `(a/β)²a²` carries
`P²`. Conclusions unchanged.

## B. Answers (summary)

(3.1) is #237 Step U4's identity verbatim; the disintegration holds; `p_{V_0}(0) = (2π)^{−(2d+1)/2}18^{−1/2}` equals #242's
prefactor to 15 digits. T₁'s limit: yes (exact identities; `β ≥ 6κ^{1/2} ≥ 2|W₀|`; main term `P²(γ_e²/4)³/(9κ)`; errors
`O(κ^{−2})`; off-`𝔈_κ` part `O(κ^{−1}η′)` with B-1). `a₁ = (1/10)∫F₀db`: yes (the layer integrates to `γ⁶/(576κ)`, #242's
rejected weight to `10γ⁶/(576κ)`). §4: yes on every point ((4.1) faithful to note LU §4; domination exactly `(U⁼)/r`;
pointwise limits; Jacobian). `|𝐄(k, u)| ≤ C min(k, 1/k)`: nothing missing.

## C. Checks

Controls replayed in both modes (byte-identical; mutants M1–M6 rejected at their groups). Independent T₁ numerics
(`t1_vec_check.py`, numpy; `t1_d2_check.py`, mpmath; agree to 13 digits at `κ = 5`): `G(κ)/a₁ − 1 ≈ −0.011487/κ²` in
`d = 2` (`κ = 10 … 10⁴`) and `≈ −0.00929/κ` in `d = 3`. §4: `(1/3)∫𝐄k^{−5/3}dk/a₁ = 1.39926066053 = J/3`; `c₃` reproduced.

## D. Not checked

§§0–2 (except B-9), §§5–6 and the header; the consumed results' own proofs; measurability.

## E. Hashes

Frozen files unchanged (`31ad5812…`, `8e74a629…`).

## F. Disclosure

Author-side referee pass by an Anthropic Claude subagent in the author's session; not a nonauthor review; no review credit.
