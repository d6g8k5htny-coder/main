# Lifetime note C3: the `ℓ^{2/3}` term of the candidate density

Object: `CL-C3-CANDIDATE-TWO-THIRDS-20261006-v1`. Claim: main#229 6026342638.
Author: Anthropic Claude (claude.ai session `session_01NMeKEismAyeqgdB4sy2NJU`), 6 October 2026, for Dylan Roy (delegated AI
work). The same session wrote #218, #229, #237 and #242, and notes TL, TS, EM, EM.1 and LU. The consumed packets in turn
consume OpenAI-authored sources, among them [R], [P] and [Z].
Disposition: AUTHOR-SIDE PROOF CANDIDATE; NONAUTHOR REVIEW REQUIRED. Scientific effect: NONE — no register, graph, STATUS,
PROOF_INDEX, prize or Boolean change; no numerical constant is certified. Same GitHub account as every lane;
organizational independence 0.

**What is new.**
- **Lemma F₃ (the fold layer at order `r`)** (§2). At every fixed gap `k > 0`, the typed-minus-surrogate difference is
  `𝐓_r(k) − 𝐒_r(k) = r𝐋_F(k) + o(r)`, with an explicit coefficient
  `𝐋_F(k) = (12/(9k))p_{V_0}(v(k))𝔼_k[P²|3kB_ee − γ_e²/4|³; λ_max(A) = 0⁻]` (§0).
  - The difference is the layer `{|x| ≥ y}` of the typed region near `λ_max(A) = 0`. Here `e` is the null eigenvector of
    `A`, `P` the product of its other eigenvalues, and `𝔼_k[·; λ_max(A) = 0⁻]` the edge density of `λ_max(A)`.
  - The strip where `A < 0` but `A_M` is not negative definite lies inside that layer, to first order. So it adds nothing.
  - #218's Lemma F bounds this difference by `O(r(1 + k^{−1}))`; Lemma F₃ identifies it to `o(r)`.
- **Lemma T₁ (the cusp tail)** (§3). `κ(𝓐(κ) − 𝐀₂(0)) → a₁ := (12/9)p_{V_0}(v(0))𝔼_0[P²(γ_e²/4)³; λ_max(A) = 0⁻]`, and
  `a₁ = (1/10)∫F₀db` with #242's `F₀`.
- **Theorem C3** (§4). In every `d ≥ 2`,
  `ν_cand(ℓ) = cℓ^{−1/3} + B_{d,L} + I^{cand}ℓ^{1/4} + c₂ℓ^{1/3} + c₃ℓ^{2/3} + o(ℓ^{2/3})`, with
  `c₃ = (1/3)∫_S∫_0^∞[𝐋_F(k, u) − a₁(u)/k]k^{−5/3}dk dσ(u)`. This identifies the remainder of note LU's Theorem P⁺ at its own
  order. It is #237 Remark 2's fold-scale term ("plausibly the next term"), and the "`ℓ^{2/3}` term of `ν_cand`" that #242
  Conjecture 7's Remark 1 leaves open ("the typed boundary `λ ≍ r` also produces an `|r|³` term in the candidate kernel").
- **Proposition G (Gaussian kernel)** (§5). For `C(z) = e^{−|z|²/2}` on `R^d` and every `d ≥ 2`,
  `c₃ = (J/30)∫_S∫_RF₀ db dσ`, with `J := (16/15)∫_0^∞e^{−12k²}E[(3kB − γ²/4)₊³]k^{−8/3}dk > 0` (`γ`, `B` independent
  `N(0, 2)`).
  - A Gamma-function identity cancels the `k²`-part of the layer exactly, which leaves `J` as the integral of a positive
    function. So `c₃ > 0`: in the model case the remainder `O(ℓ^{2/3})` of Theorem P⁺ is attained (Corollary G′).
  - Numerically `J = 4.19778198`, and `c₃ = 0.01278964` (`d = 2`) and `0.01609231` (`d = 3`); so `c₃/c = 0.174229` and
    `0.385205`.

**Not claimed.**
- No rate: the remainder is `o(ℓ^{2/3})`, by dominated convergence (Remark 4).
- Nothing about `ν_eld` or `ρ_rej` beyond one equivalence. With Theorem C3, Conjecture 7 of #242 (with `o(ℓ^{2/3})` in place
  of `O(ℓ^{3/4})`) is equivalent to an `ℓ^{2/3}` term `(c₃ − R_{2/3})ℓ^{2/3}` of the near elder density (Remark 3). That
  conjecture stays open.
- No change to any statement of #218, #237, #242, note LU or the notes it consumes.
- No certified number. The numerical values of §5 are exploration (quadrature), and the sign of `c₃` in the model case is
  proved, not certified. Nothing about the torus field beyond the general Theorem C3 (Remark 5).
- Nothing pointwise in `b`; no uniformity in `d` or `L`; nothing beyond the existential scope of the consumed sources.

**Consumed.**
- Note LU (main#229 6025486512, with successor text 6026230530; Slice A PASS 6025530037, Slice B AMEND 6025531584, readback
  PASS 6026231785, Slice C PASS 6025535376): Theorem U⁼, and §4's proof of Theorem P⁺ (the decomposition at a fixed split
  `ρ`, the absorption of `J₂`, the main terms and `J₃`–`J₅`); §2's paragraph on `𝔗` (the deterministic form of Lemma Π).
- #237 `frontiers/candidate_parity_rate_20261001/PROOF.md` (blob `a97bf528`): the setting of §§0–2; Lemma R; Lemma Π in
  the deterministic form of its proof; the polynomials (2.1); Lemma K ((K.1)); Step U2 (a) (the layer device); Step U4
  (the formula for `𝓐`).
- #218 `frontiers/candidate_third_order_20261001/PROOF.md` (blob `70ca57ef`): §0 and (F.2) (the value `𝐀₂(0)`); Lemma D and
  its proof (Weyl's integration formula and the Vandermonde cancellation); (1.2); Step F1.
- #229 `frontiers/third_order_rate_20261001/PROOF.md` (blob `110ed33a`): (W⁺.2) at `κ = 0`.
- #242 `frontiers/soft_rejected_pairs_20261002/PROOF.md` (blob `271412db`): Theorem 1's definitions (1.0a) and (1.0) of `𝔇`
  and `F₀`, with its proof's Weyl-coordinate argument (1.1a); Corollary 1′ (the values of `∫∫F₀`); §0 (the model case).

**Cited only.**
- #237's README (review record: the referee's `k²/κ` coefficient of the layer), #237 Remark 2, note TL's Remark 2 (the
  rejected fold limit `F − F₀`), note LU's Remark 2.
- #242's Lemma 5 and Conjecture 7, #244 (`R_{2/3}`, numerically), and #229's Corollary R⁺ (`ρ_rej = ν_cand − ν_eld`), for
  Remark 3.
- #216 and #223 (the values of `c_{2,∞}`, `c_{3,∞}`), for the ratios `c₃/c`.

**Prior work and overlap.** I searched main#229, #259 and #275 and the Math- tree at `34618d0d`. The term is named, not
identified, in #237 Remark 2 ("It is plausibly the next term, but neither its non-vanishing nor the sharpness of Lemma Λ is
proved"), in #237's README (the referee's numerics: "The `k²/κ` coefficient of the layer was nonzero, about `+0.005`"), in
#242 Conjecture 7's Remark 1, and in notes TL and LU (Remark 2 of each). No packet or claim identifies it. This note's
claim is 6026342638.

## 0. Setting and statements

Setting and notation are #237's (§§0–2) and note LU's (§0). In particular: `m = d − 1`, `s := (−1)^m`; the pins
`M = −ru/2`, `S = ru/2`; the rows `V_r`, the target `v(k) = (0_d, 0_d, 12k)`, the density `p_{V_r}` and the law `Q̄_{r,k}`
(#237 (1.1)); the scaled endpoint Hessians `K_M`, `K_S`, and `Π = −det K_M det K_S`; the kernel and its fixed-cone
surrogate (#237 (R.1))

    𝐓_r(k, u) = 12p_{V_r}(v(k))E_{Q̄_{r,k}}[r^{−2}Π 1_{typed}],        𝐒_r(k, u) = 12p_{V_r}(v(k))E_{Q̄_{r,k}}[r^{−2}Π 1{A<0}];

`𝐀_0`, `𝐀₂` (Lemma K), `𝓐(κ, u) = ∫_R(𝒜^{cand} − 𝒜^{con})(b, κ, u)db` and `κ = k/r`. The jets at `0` are `A = ∇_Θ²f(0)`,
`B = ∂_uA`, `γ = ∇_Θ∂_u²f(0)`, `f₄`, …; `Δ = det A`, `A^♯ = adj A`, `Δ_B = tr(A^♯B)`, `Y′ = (f₄/12)Δ − γᵀA^♯γ/4`, and
`U = Y′ + 3kΔ_B`, `V` as in #237 (2.1), built from the jets of the field at gap `k`. Constants `C, c, N` depend only on `d`
and `L`, except where a dependence on `k` is stated.

*The edge.* The eigenvalues `λ₁ ≤ ⋯ ≤ λ_m` of `A` are simple almost surely. Put `λ := λ_m`, let `e` be a unit eigenvector for
`λ_m` (determined up to sign), and put

    P := λ₁⋯λ_{m−1}  (P := 1 if m = 1),    B_ee := eᵀBe,    γ_e := eᵀγ,    U_red := 3kB_ee − γ_e²/4.                (0.1)

`U_red` is even in `e`. For a law `Q` of the jets and a measurable `φ ≥ 0` put

    𝔼_Q[φ; λ_m = 0⁻] := lim_{ε↓0} ε^{−1} E_Q[φ 1{−ε < λ_m < 0}]                                                    (0.2)

when the limit exists. Write `𝔼_k` for `𝔼_{Q̄_{0,k}}` and define, for `k ∈ R` and `u ∈ S^{d−1}`,

    𝔏(k, u) := 𝔼_k[P²|U_red|³; λ_m = 0⁻],        𝐋_F(k, u) := (12/(9k)) p_{V_0}(v(k)) 𝔏(k, u)   (k > 0),
    a₁(u) := (12/9) p_{V_0}(v(0)) 𝔏(0, u),        𝐄(k, u) := 𝐋_F(k, u) − a₁(u)/k.                                (0.3)

At `k = 0`, `U_red = −γ_e²/4` and `𝔏(0, u) = 𝔼_0[P²γ_e⁶; λ_m = 0⁻]/64`.

**Lemma 0 (the edge expectations).** The limits (0.3) exist. `𝔏(·, u)` is continuous and even on `R`, with
`𝔏(k, u) ≤ C(1 + |k|)^N`, uniformly in `u`. Moreover `𝔏(k, u) = 𝔼_A[P²h_k(e); λ_m = 0⁻]`, where
`h_k(e) := E_{Q̄_{0,k}}[|U_red|³ | A]` depends on `A` only through `e`.

**Lemma F₃ (the fold layer at order `r`).** For every `k > 0` and `u`,

    lim_{r↓0} (𝐓_r(k, u) − 𝐒_r(k, u))/r = 𝐋_F(k, u).                                                              (F₃)

**Lemma T₁ (the cusp tail).** For every `u`, `lim_{κ→∞} κ(𝓐(κ, u) − 𝐀₂(0, u)) = a₁(u)`. Moreover `a₁(u) = (1/10)∫_RF₀(b, u)db`,
with `F₀` as in #242 (1.0).

**Theorem C3 (the `ℓ^{2/3}` term of the candidate density).** In every `d ≥ 2` and for every `L`, `|𝐄(k, u)| ≤ C min(k, 1/k)`
for `k > 0`, and as `ℓ ↓ 0`

    ν_cand(ℓ) = c ℓ^{−1/3} + B_{d,L} + I^{cand} ℓ^{1/4} + c₂ ℓ^{1/3} + c₃ ℓ^{2/3} + o(ℓ^{2/3}),
    c₃ := (1/3) ∫_{S^{d−1}} ∫_0^∞ 𝐄(k, u) k^{−5/3} dk dσ(u).                                                       (C3)

**Proposition G (the Gaussian kernel).** Let `C(z) = e^{−|z|²/2}` on `R^d` (the model case of #242 §0), `d ≥ 2`. Then:
- (G.1) For every `k` and every unit `e ⊥ u`, under `Q̄_{0,k}` the pair `(γ_e, B_ee)` is independent of `A`, and its law is that
  of two independent `N(0, 2)` variables, not depending on `k`. Moreover `p_{V_0}(v(k)) = e^{−12k²}p_{V_0}(v(0))`.
- (G.2) Put `g(k) := E|3kB − γ²/4|³` for independent `γ, B ~ N(0, 2)`. Then `g(0) = 15/8` and
  `𝐄(k, u) = (a₁/k)(e^{−12k²}g(k)/g(0) − 1)`, with `a₁ = (1/10)∫F₀db` independent of `u`.
- (G.3) `c₃ = (J/30)∫_{S^{d−1}}∫_RF₀ db dσ`, where

      J := ∫_0^∞ (e^{−12k²}g(k)/g(0) − 1) k^{−8/3} dk = (16/15) ∫_0^∞ e^{−12k²} E[(3kB − γ²/4)₊³] k^{−8/3} dk > 0.        (G)

  With #242's Corollary 1′, `c₃ = J·5√3/(288π²)` in `d = 2` and `c₃ = J·25√30/(1152π³)` in `d = 3`.

**Corollary G′ (sharpness in the model case).** For the Gaussian kernel, `c₃ > 0`. So the remainder `O(ℓ^{2/3})` of note
LU's Theorem P⁺ is of exact order `ℓ^{2/3}`.

## 1. The edge and two identities

*Proof of Lemma 0.* By #237 Lemma R (R.2) at `r = 0`, the odd jets are independent of the even ones, and their law under
`Q̄_{0,k}` has a mean linear in `k` and a covariance independent of `k`; the law of `A` does not depend on `k`. So
`E_{Q̄_{0,k}}[P²|U_red|³1{−ε < λ_m < 0}] = E_A[P²h_k(e)1{−ε < λ_m < 0}]`, with `h_k(e)` a Gaussian expectation of
`|3kB_ee − γ_e²/4|³` that is continuous in `(k, e)` and `≤ C(1 + |k|)^N`. Under Weyl's integration formula
`A = O diag(λ)Oᵀ`, `dA = c_m|V(λ)|dλ dO` (#218 Lemma D's proof; #242 (1.1a)), the law of `A` has the density
`c_m|V(λ)|p_A(O diag(λ)Oᵀ)` in `(λ, O)`, with `p_A` a nondegenerate Gaussian density. This density is continuous in `λ_m`
across `0` on `{λ_{m−1} < 0}`, and `P²h_k(e)` does not depend on `λ_m`. Dominated convergence (the Gaussian factor dominates
`P²(1 + |V|)`) gives the limit,

    𝔏(k, u) = c_m ∫∫_{λ₁<⋯<λ_{m−1}<0} P² h_k(Oε_m) |V(λ₁, …, λ_{m−1}, 0)| p_A(O diag(λ₁, …, λ_{m−1}, 0)Oᵀ) dλ′ dO,      (1.1)

which is continuous in `k` and bounded as stated. Evenness: by Lemma R (R.3) at `r = 0`, the reflection maps `Q̄_{0,k}` to
`Q̄_{0,−k}`, fixes `A` and negates the odd jets, and `U_red(−k; −B, −γ) = U_red(k; B, γ)`. ∎

**Two identities.** Let `A` have simple top eigenvalue `λ`, unit eigenvector `e`, and the other eigenpairs `(λ_j, e_j)`.
- (I.1) *The adjugate at the edge.* `Δ = λP` and `A^♯ = P eeᵀ + λR`, with `R := Σ_{j<m}(∏_{i<m, i≠j}λ_i)e_je_jᵀ`.
  Consequently

      Y′ = P(−γ_e²/4) + λW₀,    U = P·U_red + λW,    W₀ := Pf₄/12 − γᵀRγ/4,    W := W₀ + 3k tr(RB).                   (1.2)

  Indeed `A^♯` has the eigenvalues `∏_{i≠j}λ_i` on `e_j`; for `j = m` this is `P`, and for `j < m` it contains the factor `λ`.
  Then `γᵀA^♯γ = Pγ_e² + λγᵀRγ` and `Δ_B = PB_ee + λ tr(RB)`. These are polynomial identities in the eigen-coordinates
  (control E1).
- (I.2) *The layer integral.* For `a ≥ 0` and `β > 0`, `∫_{−∞}^0 (a² − β²λ²)₊ dλ = 2a³/(3β)`. With `a = |P||U_red|` and
  `β = 6κ|P|` this is `P²|U_red|³/(9κ)` (control E2).

## 2. Proof of Lemma F₃

Fix `k > 0` and `u`; constants below may depend on `k`. Let `g ~ Q̄_{r,k}`, write `E` for `E_{Q̄_{r,k}}`, and let
`𝔗 := 1 + ‖g‖_{C^{N₀}(𝔅)}` as in note LU §2, with `E[𝔗^p | J] ≤ C_p(1 + |J|)^p` for the free-jet vector `J` (#218 (1.2);
#237 Lemma R (R.4)). By (R.1), `𝐓_r − 𝐒_r = 12p_{V_r}(v(k))E[Λ]` with

    Λ := r^{−2}Π (1_{typed} − 1{A < 0}),

and `p_{V_r}(v(k)) → p_{V_0}(v(k))` (R.4). So it suffices to show `E[Λ] = (r/(9k))𝔏(k, u) + o(r)`.

*Step 1 (the endpoint quantities).* Put `m_i := det K_i/r`, `𝔞 := s m_M`, `𝔟 := s m_S`, `x := (𝔞 + 𝔟)/2`, `y := (𝔟 − 𝔞)/2`.
Then `r^{−2}Π = −m_Mm_S = y² − x²`, and `𝔞 < 0 < 𝔟` if and only if `|x| < y`. By Lemma Π at gap `k` (deterministic form,
applied to the pinned field `g`; note LU §2),

    x = s U + ε₊,    y = 6κ sΔ + r s V + ε₋,    |ε_±| ≤ C r² 𝔗^N.                                                   (2.1)

Also `|m_i| ≤ C(1 + κ)𝔗^N`, so `|Λ| ≤ C(1 + κ)²𝔗^N` everywhere.

*Step 2 (localization).* Let `η := r^{1/4}`, `θ := 1/(16(m + 1))`, `𝔊 := {𝔗 ≤ r^{−θ}}` and
`𝔈 := {λ_{m−1} ≤ −η, |P| ≥ η²}` (`𝔈 := Ω` if `m = 1`). Note `‖A_M − A‖ + ‖A_S − A‖ ≤ r𝔗`, where `A_i := ∇_Θ²g(i)`.
- *Off `𝔊`.* `P(𝔊^c | J) ≤ C_pr^p(1 + |J|)^p` for every `p`, so `E[|Λ|1_{𝔊^c}] ≤ C(1 + κ)²r^p = o(r)`.
- *Where `Λ` can be nonzero.* On `𝔊`: if `λ ≥ 2r𝔗`, then `λ_max(A_M) > 0`, so `g` is not typed, and `A ≮ 0`; hence `Λ = 0`. If
  `λ ≤ −2r𝔗`, then `A_M, A_S < 0`, so `typed ⟺ |x| < y` (note LU (S.4)) and `Λ = (x² − y²)1{|x| ≥ y}`, which vanishes unless
  `6κ|Δ| ≤ |x| + |y − 6κ|Δ|| ≤ C𝔗^N`. So on `𝔊`, `Λ ≠ 0` only on `{|λ| < 2r𝔗} ∪ {A < 0, |Δ| ≤ C(r/k)𝔗^N}`, and there
  `|Λ| ≤ C𝔗^N` (on the first set `6κ|Δ| ≤ 12k𝔗^m`).
- *On `𝔊 \ 𝔈`.* Off `𝔈`, a second eigenvalue lies within `η′ := max(η, η^{2/(m−1)})` of `0` (if `|P| < η²`, some `|λ_j| < η^{2/(m−1)}`,
  `j < m`). In Weyl coordinates (1.1) both sets above then confine two eigenvalues:
  - `{|λ_m| < ε}` with a second eigenvalue in an interval of length `≤ 2η′`: probability `≤ C(1 + |μ_A|)^Nεη′`, since the joint
    density of two eigenvalues is bounded;
  - `{A < 0, |Δ| ≤ δ}`: as in the proof of #218 Lemma D's second bound, integrate the eigenvalue of least modulus over an
    interval of length `2δ/D`, where the factor `D` cancels against the Vandermonde product. The remaining integral confines a
    second eigenvalue to an interval of length `≤ 2η′`. So the probability is `≤ C(1 + |μ_A|)^Nδη′`.

  With the layer device of #237 Step U2 (a) for the factor `𝔗^N` (condition on `A`, and sum over dyadic layers of `𝔗`),
  `E[|Λ|1_{𝔊\𝔈}] ≤ C(r + r/k)η′ = o(r)`.

*Step 3 (typedness near the edge, on `𝔊 ∩ 𝔈`).* Here the second-largest eigenvalues of `A_M` and `A_S` are at most
`−r^{1/4} + r𝔗 < 0`, and `λ` is simple with gap at least `r^{1/4}/2` when `|λ| < 2r𝔗`. First-order eigenvalue perturbation
gives

    λ_M := λ_max(A_M) = λ − (r/2)B_ee + O(r^{7/4}𝔗²),                                                               (2.2)

since `A_M − A = −(r/2)B + O(r²𝔗)` and the second-order term is `≤ ‖A_M − A‖²/gap`. By Haynsworth's inertia additivity,
`H_M < 0 ⟺ λ_M < 0 ∧ 𝔞 < 0`, and, because `A_S` has at most one nonnegative eigenvalue, `ind H_S = d − 1 ⟺ 𝔟 > 0` (if
`A_S < 0` the Schur complement must be positive, if `A_S` has one positive eigenvalue it must be negative; either way
`det H_S` has the sign `s`). Hence on `𝔊 ∩ 𝔈`

    Λ = (y² − x²)(1{λ_M < 0, |x| < y} − 1{λ < 0}) = Λ₁ + Λ₂ + Λ₃,
    Λ₁ := (x² − y²)1{λ < 0, |x| ≥ y},  Λ₂ := −(y² − x²)1{λ < 0, |x| < y, λ_M ≥ 0},  Λ₃ := (y² − x²)1{λ ≥ 0, λ_M < 0, |x| < y}.

*Step 4 (`Λ₃` and `Λ₂` are `o(r)`).* On the edge, by (I.1) and (2.1), with `sP = −|P|`:
`y = 6κ sλP + rsV + ε₋` and `x = s(PU_red + λW) + ε₊`.
- *`Λ₃`.* For `λ ≥ 0`, `sΔ = sλP = −λ|P| ≤ 0`. So `y > |x| ≥ 0` forces `y ≤ rC𝔗^N`, and `|Λ₃| ≤ y² ≤ Cr²𝔗^N`.
- *`Λ₂`* (the strip). It needs `λ < 0 ≤ λ_M`, so by (2.2) `B_ee < 0` and `|λ| ≤ (r/2)|B_ee| + Cr^{7/4}𝔗²`. Then
  `U_red = −(γ_e²/4 + 3k|B_ee|)`, so `|x| ≥ |P|(γ_e²/4 + 3k|B_ee|) − Cr𝔗^N`, while
  `y ≤ 6κ|λ||P| + Cr𝔗^N ≤ |P|(3k|B_ee| + Ckr^{3/4}𝔗²) + Cr𝔗^N`. So `|x| < y` forces
  `|P|γ_e² ≤ C(r^{3/4}|P| + r)𝔗^N`. Given `A`, `γ_e` is Gaussian with variance bounded below (Step F1 of #218; the free jets
  are uniformly nondegenerate), so this has conditional probability `≤ C(r^{3/8} + (r/|P|)^{1/2})𝔗^N`. The strip has
  `λ`-width `≤ Cr𝔗²`. With the layer device and `E[|P|^{−1/2}1_{𝔈}] ≤ C`, `E|Λ₂| ≤ Cr(r^{3/8} + r^{1/2}) = o(r)`.

  This is the statement that the strip lies inside the layer `{|x| ≥ y}` to first order: on the strip `|U_red| ≥ 3k|B_ee|`
  while `6κ|λ| ≤ 3k|B_ee|` up to `O(r^{3/4})`.

*Step 5 (the layer `Λ₁`).* Put `a := |P||U_red|` and `β := 6κ|P|`, functions of `Rest := (λ₁, …, λ_{m−1}, O, odd jets)`. By
(I.1) and (2.1), with `sλP = |λ||P|` for `λ < 0`,

    x² − y² = a² − β²λ² + ϱ,    ϱ = 2sPU_red·λW + λ²W² − 2β|λ|(rsV + ε₋) − (rsV + ε₋)² + O((1 + a + |λW|)ε₊).        (2.3)

- *Where `y < 0`.* With `λ < 0` this forces `6κ|λ||P| ≤ Cr𝔗^N`, a `λ`-interval of length `≤ Cr²𝔗^N/(k|P|)`. The density (1.1)
  carries the Vandermonde factor `|P|` at `λ_m = 0`, which cancels the `1/|P|` as in #218 Lemma D's second bound; with
  `|Λ| ≤ C𝔗^N`, this set costs `O(r²)`.
- *The perturbation.* Elsewhere `Λ₁ = (a² − β²λ² + ϱ)₊`, and `|(a² − β²λ² + ϱ)₊ − (a² − β²λ²)₊|` is at most `|ϱ|` where either
  is positive. On `𝔊 ∩ 𝔈`, `β = 6κ|P| ≥ 6kr^{−1/2}`, while `|W| ≤ C𝔗^m ≤ Cr^{−1/16}`. So `|λ||W| ≤ β|λ|/2` for small `r`, and
  positivity forces `β|λ| ≤ 2a + Cr𝔗^N`, that is `|λ| ≤ (r/(3k))(|U_red| + Cr^{1/2}𝔗^N)`. There (2.3) gives
  `|ϱ| ≤ C(r/k)(1 + a)²𝔗^N + Cr(1 + a)𝔗^N`. So this costs `O(r²(1 + k^{−2}))` after the layer device.
- *The main part.* Let `J(λ, Rest)` be the joint density of `(λ_m, Rest)` under `Q̄_{r,k}`: by (1.1), the Weyl density of `A`
  times the conditional Gaussian density of the other jets given `A`. It is `C¹` in `λ` on `(λ_{m−1}, ∞)`, and
  `|∂_λJ| ≤ C(1 + |Rest|)^N|P|q(Rest)` near `λ = 0`, with `q` a Gaussian factor. By (I.2),

      ∫_{−∞}^0 (a² − β²λ²)₊ J(λ, Rest) dλ = J(0⁻, Rest) P²|U_red|³/(9κ) + O((a/β)² a² sup_{|λ|≤a/β}|∂_λJ|),

  and `a/β = |U_red|/(6κ) = r|U_red|/(6k)`. Integrating over `Rest` on `𝔈`,
  `E[Λ₁] = (r/(9k))𝔼_{Q̄_{r,k}}[P²|U_red|³1_𝔈; λ_m = 0⁻] + O(r^{5/4})`, the `O` including the costs above and `𝔊^c`.
- *The limit.* As `r ↓ 0`, `1_𝔈 ↑ 1` on `{λ_{m−1} < 0}`, and the law of the finite jet vector `(A, γ, B)` under `Q̄_{r,k}` is a
  smooth function of `r` with uniformly nondegenerate covariance (R.4). So `𝔼_{Q̄_{r,k}}[P²|U_red|³1_𝔈; λ_m = 0⁻] → 𝔏(k, u)`
  by (1.1) and dominated convergence.

Steps 2–5 give `E[Λ] = (r/(9k))𝔏(k, u) + o(r)`, hence (F₃). ∎

## 3. Proof of Lemma T₁

By #237 Step U4, `𝓐(κ) = −12p_{V_0}(v(0))E_{Q̄_{0,0}}[min(Y′², 36κ²Δ²)1{A<0}]`, and by #218 (F.2) integrated in `b`
(#237 (R.1)), `𝐀₂(0) = −12p_{V_0}(v(0))E_{Q̄_{0,0}}[Y′²1{A<0}]`. Hence

    𝓐(κ) − 𝐀₂(0) = 12 p_{V_0}(v(0)) E_{Q̄_{0,0}}[(Y′² − 36κ²Δ²)₊ 1{A<0}].                                              (3.1)

Put `η := κ^{−1/4}` and `𝔈_κ := {λ_{m−1} ≤ −η, |P| ≥ η²}`, as in §2 Step 2 with `1/κ` in place of `r`. The integrand of
(3.1) is at most `Y′²` and vanishes unless `A < 0` and `|Δ| ≤ |Y′|/(6κ)`. Off `𝔈_κ`, the second bullet of §2 Step 2 (the
proof of #218 Lemma D's second bound, with a second eigenvalue within `η′ := max(η, η^{2/(m−1)})` of `0`), applied with
`δ := |Y′|/(6κ)` and conditionally on the other jets, gives `E[Y′²1{A<0, |Δ| ≤ |Y′|/(6κ)}1_{𝔈_κ^c}] ≤ Cκ^{−1}η′ = o(κ^{−1})`.

On `𝔈_κ`, (1.2) at `k = 0` gives `Y′ = P(−γ_e²/4) + λW₀` and `Δ = λP`. With `a := |P|γ_e²/4` and `β := 6κ|P|`, the integrand is
`(a² − β²λ² + ϱ)₊` with `ϱ = −2Pγ_e²λW₀/4 + λ²W₀²`. Off `{|W₀| ≥ κ^{1/2}}`, whose cost is `O(κ^{−p})` for every `p`,
`β ≥ 6κ^{1/2} ≥ 2|W₀|` on `𝔈_κ`. So positivity forces `β|λ| < a + |λ||W₀| ≤ a + β|λ|/2`, that is `|λ| ≤ γ_e²/(12κ)`, and there
`|ϱ| ≤ C(1 + γ_e²)²(1 + |W₀|)²/κ`. As in §2 Step 5 (with `r/k` replaced by `1/κ`, and no field remainder), the perturbation
costs `O(κ^{−2})`, and (I.2) gives

    E[(Y′² − 36κ²Δ²)₊1{A<0}1_{𝔈_κ}] = (1/(9κ)) 𝔼_0[P²(γ_e²/4)³ 1_{𝔈_κ}; λ_m = 0⁻] + O(κ^{−2}).

Also `𝔼_0[P²(γ_e²/4)³1_{𝔈_κ}; λ_m = 0⁻] → 𝔏(0, u)` as `κ → ∞`, by (1.1) and monotone convergence. Multiplying by
`12p_{V_0}(v(0))κ` gives `κ(𝓐(κ) − 𝐀₂(0)) → a₁`.

*The identity `a₁ = (1/10)∫F₀db`.* #242 (1.0a) defines `𝔇(b, u) := lim ε^{−1}E₀[γ₁⁶(λ₂⋯λ_m)²1{A<0, λ₁ < ε} | b]`, where
`λ₁ < ⋯ < λ_m` are the eigenvalues of `−A` and `γ₁` is `γ`'s component along the eigenvector of `λ₁`. In this note's
notation `λ₁(−A) = −λ_m`, `γ₁² = γ_e²` and `(λ₂⋯λ_m)² = P²`. Birth integration (#237 (R.1) at `r = 0`, `k = 0`, with
dominated convergence in `b` by the Gaussian factor of `π₀`) gives `∫_Rπ₀(u; v₀(b, 0))𝔇(b, u)db = p_{V_0}(v(0))𝔼_0[P²γ_e⁶;
λ_m = 0⁻]`. So, with `F₀ = (5/24)π₀𝔇`,

    a₁ = (12/9)(1/64) p_{V_0}(v(0)) 𝔼_0[P²γ_e⁶; λ_m = 0⁻] = (1/48)(24/5) ∫F₀ db = (1/10) ∫F₀ db.   ∎               (3.2)

## 4. Proof of Theorem C3

*The decomposition.* Note LU §4's proof of Theorem P⁺ (at its fixed split `ρ := min(r₄, r₀/2)`, `ℓ ≤ ρ³`; #237 §5's
decomposition, `J₂` absorbed) gives

    ν_cand − cℓ^{−1/3} − B_{d,L} − I^{cand}ℓ^{1/4} − c₂ℓ^{1/3} = ∫_0^ρ ∫_{S^{d−1}} D_r(ℓ/r³, u) dσ(u) dr + O(ℓ),
    D_r(k, u) := 𝐓_r(k, u) − 𝐓_r(0, u) − r^{−2}𝐀_0(k, u) − [𝐀₂(k, u) − 𝐀₂(0, u)] − 𝓐(k/r, u),                       (4.1)

with the main terms `c₂ℓ^{1/3} + O(ℓ²ρ^{−5})` and `I^{cand}ℓ^{1/4} + O(ℓ²ρ^{−7})`, and `J₃`, `J₄`, `J₅` of order `ℓ` or
smaller.

*The fold variable.* Put `r = ℓ^{1/3}s`, so `k = ℓ/r³ = s^{−3}` and `κ = ℓ^{−1/3}s^{−4}`, and `φ_r(k, u) := D_r(k, u)/r`. Then

    ∫_0^ρ D_r(ℓ/r³, u) dr = ℓ^{2/3} ∫_0^{ρℓ^{−1/3}} s φ_{ℓ^{1/3}s}(s^{−3}, u) ds.                                     (4.2)

*Domination.* By Theorem U⁼ (note LU), `|φ_r(k)| ≤ C(r min(1, κ) + min(k, 1/k))`. In the fold variable
`r min(1, κ) = min(ℓ^{1/3}s, s^{−3}) ≤ min(1, s^{−3})` for `s ≤ ρℓ^{−1/3}` (as `ρ ≤ 1`), and `min(k, 1/k) = min(s^{−3}, s³)`.
So `|sφ| ≤ 2Cs·min(1, s^{−3})`, which is integrable on `(0, ∞)` (control E6).

*The pointwise limit.* Fix `k > 0` and `u`, and let `r ↓ 0`. Then:
- `(𝐓_r(k) − 𝐒_r(k))/r → 𝐋_F(k)` by Lemma F₃;
- `(𝐒_r(k) − r^{−2}𝐀_0(k) − 𝐀₂(k))/r = O(r)` by Lemma K ((K.1): `|r²𝐒_r − 𝐀_0 − r²𝐀₂| ≤ Cr⁴(1 + k)^Ne^{−ck²}`);
- `𝐓_r(0)/r ≤ Cr²log(2/r) → 0` by #229 (W⁺.2) at `κ = 0`, integrated in `b` (as in note LU §4);
- `(𝓐(k/r) − 𝐀₂(0))/r = (1/k)·κ(𝓐(κ) − 𝐀₂(0)) → a₁/k` by Lemma T₁, since `κ = k/r → ∞`.

So `φ_r(k, u) → 𝐋_F(k, u) − a₁(u)/k = 𝐄(k, u)`. In particular `|𝐄(k, u)| ≤ C min(k, 1/k)`, the limit of the domination.

*Conclusion.* By (4.2) and dominated convergence (also in `u`), `ℓ^{−2/3}∫_0^ρ∫D_r(ℓ/r³, u)dσ dr` tends to
`∫_S∫_0^∞ s𝐄(s^{−3}, u)ds dσ(u)`. With `s = k^{−1/3}`, `s ds = (1/3)k^{−5/3}dk`, and this is `c₃`. With (4.1), this is (C3). ∎

## 5. The Gaussian kernel: proof of Proposition G and Corollary G′

*Covariances.* For `C(z) = e^{−|z|²/2}`, `E[∂^αf(0)∂^βf(0)] = (−1)^{|β|}∂^{α+β}C(0)`, and `∂^αC(0) = ∏_i (−1)^{α_i/2}(α_i − 1)!!`
when every `α_i` is even, and `0` otherwise. Take `u` and a unit `e ⊥ u` as two coordinate axes (the model is isotropic).
- (G.1) The pins of `Q̄_{0,k}` are `∇f(0) = 0`, `∂_u∇f(0) = 0` and `∂_u³f(0) = 12k`. The odd jet `γ_e = ∂_u²∂_ef(0)` has
  variance `3` and covariance `−1` with `∂_ef(0)`, and none with the other odd pins; so given the pins it is `N(0, 2)`. The
  odd jet `B_ee = ∂_u∂_e²f(0)` has variance `3` and covariances `−1` with `∂_uf(0)` and `3` with `∂_u³f(0)`. Since
  `Cov(∂_u³f, ∂_uf) = −3` and `Var(∂_uf) = 1`, `B_ee + ∂_uf(0)` is uncorrelated with both `∂_uf(0)` and `∂_u³f(0)`. So the
  regression of `B_ee` on the pins is `−∂_uf(0)`, which vanishes under the pins: `B_ee` is `N(0, 3 − 2 + 1) = N(0, 2)` given the
  pins, for every `k`. `Cov(γ_e, B_ee) = 0` and their regressions use disjoint pins, so they are independent; both are odd,
  hence independent of `A`. Finally `∂_u³f(0)` is correlated only with `∂_uf(0)` among the other pins
  (`Var(∂_u³f) = 15`, covariance `−3`), so its conditional variance is `6`, and `v(k)ᵀCov(V_0)^{−1}v(k)/2 = (12k)²/12 = 12k²`
  (control E3, exactly in `d = 2, 3, 4`, including a non-axial `e` in `d ≥ 3`).
- (G.2) By (G.1) and Lemma 0, `h_k(e) = g(k)` for every `e`, so `𝔏(k, u) = g(k)𝔡`, with `𝔡 := 𝔼_A[P²; λ_m = 0⁻]` independent
  of `k` and `u`. Hence `𝐄(k) = (12/(9k))𝔡(p_{V_0}(v(k))g(k) − p_{V_0}(v(0))g(0)) = (a₁/k)(e^{−12k²}g(k)/g(0) − 1)`.
  `g(0) = E[γ⁶]/64 = 15·2³/64 = 15/8`. `a₁ = (1/10)∫F₀db` is (3.2).
- (G.3) Write `X := γ²/4 − 3kB`. Then `g(k) = E|X|³ = E[X³] + 2E[(−X)₊³]`, and from the moments of `N(0, 2)`,
  `E[X³] = E[γ⁶]/64 + 3E[γ²/4]·9k²E[B²] = 15/8 + 27k²` (control E4). So

      e^{−12k²}g(k)/g(0) − 1 = [e^{−12k²}(1 + (72/5)k²) − 1] + (16/15)e^{−12k²}E[(3kB − γ²/4)₊³].

  For `a > 0` and `b ∈ R`, `∫_0^∞(e^{−ak²}(1 + bk²) − 1)k^{−8/3}dk = (1/2)Γ(1/6)a^{−1/6}(b − 6a/5)`: substitute `t = ak²`, and
  use `∫_0^∞(e^{−t} − 1)t^{−11/6}dt = Γ(−5/6) = −(6/5)Γ(1/6)` and `∫_0^∞e^{−t}t^{−5/6}dt = Γ(1/6)`. Here `a = 12` and
  `b = 72/5 = 6·12/5`, so the bracket integrates to `0` (control E4). The remaining integrand is positive, which is (G):
  `J > 0`. It converges, since `E[(3kB − γ²/4)₊³] ≤ E[(3kB)₊³] = O(k³)` at `0`, with Gaussian decay at `∞`. Finally, by (C3),
  `c₃ = (1/3)∫_S∫_0^∞(a₁/k)(…)k^{−5/3}dk dσ = (J/3)∫_Sa₁dσ = (J/30)∫_S∫_RF₀ db dσ`, and #242's Corollary 1′ gives
  `∫∫F₀ = 25√3/(48π²)` (`d = 2`) and `125√30/(192π³)` (`d = 3`). ∎

*Corollary G′.* `∫∫F₀ > 0` (#242 Theorem 1) and `J > 0`, so `c₃ > 0`. ∎

*Values* (exploration; not part of the proof; mpmath quadrature at 30 digits). `J = 4.1977820`. In `d = 2`,
`c₃ = 0.0127896` and `c₃/c_{2,∞} = 0.174229`; in `d = 3`, `c₃ = 0.0160923` and `c₃/c_{3,∞} = 0.385205`, with
`c_{2,∞} = 0.073406919`, `c_{3,∞} = 0.041775932` (#216, #223). The small-`k` behaviour is
`e^{−12k²}g(k)/g(0) − 1 = (12/5)k² + O(k^{7/2})`, so `𝐄(k) = (12/5)a₁k + O(k^{5/2})`.

## 6. Remarks

1. **Where `c₃` comes from.** At the fold scale the typed region differs from the cone `{A < 0}` in two places: the layer
   `{|x| ≥ y}` (the gap is too small to separate the endpoint determinants) and the strip `{A < 0 ≤ λ_max(A_M)}`. Step 4
   shows that the strip lies inside the layer to first order: there `|U_red| ≥ 3k|B_ee| ≥ 6κ|λ|`. So the whole first-order
   effect is the layer's coefficient `𝔏(k)`, and `c₃` measures how it depends on `k`: through the explicit `3kB_ee` in
   `U_red`, through the law of the odd jets, and through the density factor `p_{V_0}(v(k))`. #237 Remark 2 traces the term to
   "the `k`-dependence of the layer coefficient (Lemma Λ)" and to Step U2 (b). At fixed `k` the latter's term `rsV` in `y`
   moves the layer by `O(r²/k)`, so it does not enter `c₃`.
2. **The referee's numerics in #237.** #237's README records a `d = 2` Gaussian-kernel Monte Carlo in which "The `k²/κ`
   coefficient of the layer was nonzero, about `+0.005`". Here the layer's correction is `r𝐄(k) = (12/5)a₁rk + O(rk^{5/2})`,
   and `rk = k²/κ`: per direction `u`, birth-integrated, `(12/5)a₁ = 0.0034913` in `d = 2`. The sign and the order agree. The
   README does not say whether its fit was taken at fixed `b`, so the comparison is only qualitative.
3. **The elder and rejected densities.** By #229's Corollary R⁺, `ρ_rej = ν_cand − ν_eld`. So, given Theorem C3, #242's
   Conjecture 7 with `o(ℓ^{2/3})` in place of `O(ℓ^{3/4})` is equivalent to
   `ν_eld − ν_eld^{far,r_0^*} = cℓ^{−1/3} + c₁ℓ^{1/4} + c₂ℓ^{1/3} + (c₃ − R_{2/3})ℓ^{2/3} + o(ℓ^{2/3})`.
   - For the Gaussian kernel #244's closed form gives `R_{2/3} = −0.048779` (`d = 2`) and `−0.061375` (`d = 3`) (exploration).
     So the conjectured coefficient is `c₃ − R_{2/3} ≈ 0.061569` and `0.077467`, that is `0.8387c` and `1.8544c`.
   - For SIDE24 this would make the next relative term `≈ 1.854ℓ`, inside note LU's `O(ℓ log(1/ℓ))`. #216's Monte Carlo of
     the elder density (three-term law `1.006 ± 0.004` in `d = 2`, `1.008 ± 0.010` in `d = 3`, on `[10⁻⁴, 10⁻²]`) is
     consistent with a positive term of this size. It is not a test.
   - What a proof would still need is #242's input (ii): the intermediate separations, where note LU leaves the elder mass at
     `O(ℓ^{2/3}log(1/ℓ))` (addendum EM.1). On the soft layer `κ ≥ 1`, note TL's Remark 2 records the rejected fold limit
     `κ(𝐓_r^{rej} − 𝓐^{rej}) → ∫(F − F₀)db` at fixed `k`. Nothing here is claimed for that part.
4. **Why `o(ℓ^{2/3})`.** Theorem C3 uses Lemmas F₃ and T₁ only pointwise in `k`, and Theorem U⁼ only as a dominating function.
   A rate would need (F₃) uniformly in `k` with a rate, and the matching of the fold-side and cusp-side expansions on
   `1 ≪ κ`, `k ≪ 1`. Formally (#242's matched-asymptotics count), the next terms are `ℓ^{3/4}` from the cusp side and then `ℓ`.
5. **The torus field.** Theorem C3 holds for the torus field itself, with `c₃` given by (C3). Proposition G is about the
   model case. The torus field's jet covariances differ from the model's by `O(e^{−L²/8})` (#242 §0), and `c₃` is a
   continuous functional of them, so at `L = 24` the digits above are unchanged. That transfer is not proved or certified
   here.
6. **Numerical illustration** (exploration; not part of the proof; numpy and mpmath, outside the repository; scripts and
   output in the controls comment). An exact-conditioning Monte Carlo of the birth-integrated `𝐓_r(k) − 𝐒_r(k)` for the
   Gaussian kernel, compared with `r𝐋_F(k)`:

   | `d` | `k` | ratio `(𝐓_r − 𝐒_r)/(r𝐋_F)` at `r = ` |
   |---|---|---|
   | 2 | 0.2 | `1.058 ± 0.012` (0.0025), `0.987 ± 0.035` (0.005), `0.981 ± 0.005` (0.01), `0.990 ± 0.007` (0.02), `0.994 ± 0.003` (0.04) |
   | 2 | 0.4 | `1.030 ± 0.026`, `0.987 ± 0.015`, `1.011 ± 0.015`, `1.005 ± 0.005`, `1.002 ± 0.010` |
   | 2 | 0.8 | `0.929 ± 0.016`, `0.997 ± 0.011`, `1.005 ± 0.018`, `1.003 ± 0.008`, `1.000 ± 0.004` |
   | 3 | 0.2 | `1.026 ± 0.049` (0.005), `1.027 ± 0.025` (0.01), `0.979 ± 0.015` (0.02) |
   | 3 | 0.4 | `1.022 ± 0.038`, `0.988 ± 0.014`, `0.971 ± 0.010` |

   At `k = 0.8`, `e^{−12k²}g(k)/g(0) = 0.0170`, so the comparison distinguishes `𝐋_F(k)` from the cusp-tail value `a₁/k` by a
   factor of about `59`.

## 7. Exact controls (`c3_exact.py`; stdlib; exact rationals; deterministic; byte-identical under `-O`)

The script and its stdout are published in the next comment, with the extraction rule.
- **E1** (I.1) on random rational spectra and rational orthogonal frames (Cayley transforms), `m = 1, 2, 3`: `Δ = λP`,
  `A^♯ = Peeᵀ + λR`, `γᵀA^♯γ = Pγ_e² + λγᵀRγ`, `tr(A^♯B) = PB_ee + λtr(RB)`, and hence (1.2).
- **E2** (I.2) exactly: `∫_{−a/β}^0(a² − β²λ²)dλ = 2a³/(3β)`, and `= P²|U_red|³/(9κ)` at `a = |P||U_red|`, `β = 6κ|P|`.
- **E3** (G.1) by exact Gaussian conditioning on the pins, from the derivative moments of `e^{−|z|²/2}`, in `d = 2, 3, 4`:
  the conditional variances `2, 2` of `γ_e`, `B_ee`, their zero covariance, their zero regression on `∂_u³f` (the law does not
  depend on `k`), and the conditional variance `6` of `∂_u³f` (the factor `e^{−12k²}`); with `e` a coordinate axis and, in
  `d ≥ 3`, `e = (3/5)e₂ + (4/5)e₃`.
- **E4** `E[(γ²/4 − 3kB)³] = 15/8 + 27k²` as a polynomial in `k` (Gaussian moments), `g(0) = 15/8`, `27/g(0) = 72/5 = 6·12/5`,
  and the rational part of the Gamma identity: `(1/2)(b − 6a/5)` against `−(3/5)a + b/2` (both after the factor
  `Γ(1/6)a^{−1/6}`).
- **E5** The constant of (3.2): `(12/9)(1/64) = 1/48` and `(1/48)/(5/24) = 1/10`.
- **E6** The domination of §4 on exact perfect powers: `min(ℓ^{1/3}s, s^{−3}) + min(s³, s^{−3}) ≤ 2min(1, s^{−3})` for
  `s ≤ ρℓ^{−1/3}`, `ρ ≤ 1`; `κ = ℓ^{−1/3}s^{−4}`; and `s ds = (1/3)k^{−5/3}dk` as exponent arithmetic.

Mutants, each rejected with exit 1, empty stdout and `FAILED: <group>` on stderr:

| Mutant | Change | Fails at |
|---|---|---|
| M1 | `R` with the factor `∏_{i≠j}λ_i` taken over all `i ≤ m` | `E1_edge` |
| M2 | the layer constant `2/3 → 1/2` | `E2_layer` |
| M3 | `B_ee` conditioned without the pin `∂_uf(0)` | `E3_jets` |
| M4 | `E[X³]`'s coefficient `27 → 24` | `E4_moments` |
| M5 | `12/9 → 12/8` in `a₁` | `E5_constant` |
| M6 | the dominating exponent `s^{−3} → s^{−2}` | `E6_domination` |

**What the controls do not test.** The analytic estimates of §§2–4 (the localization, the strip and layer bounds, the edge
limits, dominated convergence), Weyl's formula, Haynsworth's additivity and the eigenvalue perturbation bound, Lemma Π,
Lemma K, (W⁺.2), Theorem U⁼, the Gamma-function values themselves, #242's (1.0a) and Corollary 1′, and the numerical
values of §5.

## 8. Review slices

- **A: §§0–2.** The statements, Lemma 0, the identities (I.1)–(I.2), and Lemma F₃'s proof: the localization, typedness near
  the edge, the strip, and the layer. Controls E1–E2, mutants M1–M2.
- **B: §§3–4.** Lemma T₁ and the identity `a₁ = (1/10)∫F₀db`, and Theorem C3's proof: the decomposition, the domination, the
  pointwise limit. Controls E5–E6, mutants M5–M6.
- **C: §§5–6 and the header.** Proposition G and Corollary G′ (the jet laws, `g`, the Gamma identity, positivity, the values),
  the remarks, and the header for overclaim. Controls E3–E4, mutants M3–M4.

🤖 Generated with [Claude Code](https://claude.com/claude-code)
