# Readback of note C3 v2 (`CL-C3-CANDIDATE-TWO-THIRDS-20261006-v1`)

(Saved by the author from the subagent's hand-back message; subagents cannot write report files here. Text as returned,
lightly condensed in the delta table and the checks.)

## Verdict: AMEND

No blocking finding. Every finding A-1…A-8, B-1…B-9 and C-1…C-19 is applied or made moot. The four deviations (C-1 and
C-2 become Proposition G″; C-7 becomes referee A's table; C-13 becomes the E4 derivation) are justified on the merits. The
changed and new mathematics is correct (Step 4's exact strip argument, Step 5, §3, Proposition G″), except one gap in
G″'s proof (S1); the header misdescribes the review record of the material added after the slice reads (S2). Controls and
numbers behave as specified.

## SHOULD-FIX

**S1. §5, proof of Proposition G″: `𝒩` must contain only parity-split covariances.** The facts "law of `A` centred and
`k`-free", "`(B, γ)` independent of `A`, mean `k·m_θ`, `k`-free covariance" hold only when even-order and odd-order jets are
uncorrelated; the text asserted them on a neighbourhood of `θ_∞` in the full covariance space, citing (R.2), a fact about the
torus field. Only parity-split `θ` are needed (`θ_∞` and every `θ(L, u)`, since the covariance is even). Replacements:
(1) the opening paragraph of the proof, defining *parity-split* and taking `𝒩` within the parity-split covariances;
(2) "`c₃` is continuous in `u ↦ θ(u) ∈ 𝒩` for uniform convergence in `u`"; (3) *What is new*: "Near the model's jet law at
`0`, the coefficient `c₃` is a continuous functional of the jet law among those of stationary fields, …".

**S2. Header: the review record of the new material.** "Every finding is applied here" hid that C-1 and C-2 were resolved by
a new result rather than the proposed hedges, and that Proposition G″, E7–E9 and the referee numerics in Remark 6 were never
seen by a slice read. Replacement text given (applied verbatim, with the readback sentence).

## NITs

- N1 (§0, Corollary G′): "Hence, for any field to which Theorem C3 applies and whose `c₃` is nonzero," → "By Theorem C3, for
  any field to which it applies and whose `c₃` is nonzero,".
- N2 (§2 Step 4): `O(r^{3/4})` → `O(kr^{3/4}𝔗²)`.
- N3 (§2 Step 5, "Where `y < 0`"): "The density (1.1) carries" → "The Weyl density of `A` under `Q̄_{r,k}` (as in the proof of
  Lemma 0) carries".
- N4 (Remark 3, #216 bullet): #237 Remark 4's `p ≈ 0.14–0.33` covers elder and rejected fits, six of eight; one elder fit
  gives `0.54`.
- N5 (Remark 5): off the lattice axes some jet covariances that vanish in the model are nonzero on the torus (e.g.
  `Cov(γ_e, ∂_uf) = −∂_u³∂_eC_L(0)`), so "factors `1 + O(e^{−288})`" → "`O(e^{−288})` (the terms `n ≠ 0` of the periodization;
  #207 §8 Remark 3)".
- N6 (G″'s sources): cite the periodized form (#242 §0, "the periodized kernel of the torus field"; #207 §8 Remark 3), not only
  the value bound `O(e^{−L²/8})`; Consumed (#242) adjusted accordingly.
- N7 (Cited only): Remark 3's count ratios also use `c₁` (#207 §8) and `c₂` (#223).
- N8 (G″, the uniform bound): (0.2) is defined for `φ ≥ 0` and `Φ_k` is signed: "since (0.2) is linear on integrands whose
  edge limits exist (here those of `𝔏(k, u)` and `𝔏(0, u)`)".
- N9 (§8, Slice C): "Controls E3, E4;" → "Controls E3, E4 and E5's (G.3) checks;".

Optional observation: E5 is consistency identities only, and no mutant exercised E4's Gamma bookkeeping, because M4 fails
earlier. (The author added mutant M10, the inverted Gamma recurrence, which fails at E4's recurrence check.)

## Delta (summary)

A-1 verbatim; A-2 exact Schur version adopted; A-3 verbatim plus E8; A-4–A-6 verbatim; A-7 resolved by B-1; A-8 applied. B-1
verbatim plus Consumed #218 Lemma O; B-2 verbatim plus E9; B-3 verbatim plus Consumed #242 (1.1a)–(1.1b) and the Corollary 1′
bound; B-4–B-9 applied. C-1, C-2 deviation (Proposition G″), justified subject to S1, S2; C-3, C-4, C-5, C-12 verbatim; C-6
applied (N7); C-7 deviation (referee A's table, referee B's T₁ values), all values match; C-8, C-9 moot; C-10, C-11, C-14–C-17
applied, numbers verified; C-13 deviation (E4 derivation), correct and fails if the exponents change; C-18 applied (N4); C-19
applied (S2). Changes not traceable to a finding are all justified and change no statement (e.g. §5 Values no longer says
"30 digits", since the script uses `dps = 20`).

## Checks

- Diff: word-level `git diff` of v1 against v2; every hunk assigned.
- Step 4 re-derived and cross-checked against note LU Lemma S (S.4), LU Lemma E's bordered form and #237's proof of Lemma Π
  (`α_M = −6k + O(r𝔗)`, `β_M = −γ/2 + O(r𝔗)`); `σ_M ≤ α_M + 2r^{3/4}|β_M|² < 0` for `r ≤ r(k)` on `𝔊` since `2θ ≤ 1/16`;
  signs; `m = 1`. (On the strip the pair is never typed anyway; the question was `|x| ≥ y`, which the Schur argument settles.)
- Step 5 and (2.3) (both signs of `s`), §3 (dyadic layers, `ϱ` bound, window, birth integration, constants), Proposition G″
  (each step; scope), citations (#237, note LU, #242 §§0, 1, 4, #207 §8, #218 Lemma F and (F.2), note TL, #229).
- Controls: both modes exit 0, stdout byte-identical to the expected (total 4340); M1–M9 each exit 1 at the group in §7's
  table, with a traced failing assertion (M7 at `m = 2`, M8 at `s = −1`, M9 at `|P| = 10⁶/3`); bad arguments exit 2.
- Numbers: `c3_values.py` rerun byte-identical (47 s); independent scipy recomputation (direct 2-D quadrature of `h(k)`):
  `J = 4.1977819816`, `c₃ = 0.0127896` and `0.0160923`, ratios `0.174229` and `0.385205`, `(12/5)a₁ = 0.0034913`, effective
  coefficients `0.004535`, `0.005607`, `0.005462`, sign change `0.369153`, `c_{7/2} = 93.0446`, `c₃ − R_{2/3}` and count ratios
  `1.00377`, `1.00863`; Remark 6's 40 entries match `mc_summary.txt`; T₁ values match referee B's runs.

## Not checked

#237's README quote and its silence on the fit's range; #216's facts; #244's `R_{2/3}` beyond the arithmetic from #242's `Ĩ`;
[P]'s own definition of the torus covariance (taken from #242 §0 and #207 §8); the consumed results' internal proofs; no
Monte Carlo or quadrature rerun (outputs compared); §4 beyond B-8; E1–E3 and E6 (unchanged).

## Hashes

`C3_v2_under_readback.md` `b62642d19761f9b74fb301de28f10cbc6842cd12020b99a00e1024602ded2d40` and `c3_exact_v2.py`
`9cf736991c055de4c161bba9bb3015e231f83f3c45784fca5c4a1bceacfeaab5`, identical before and after. Nothing posted, pushed or
contacted.

## Disclosure

Anthropic Claude subagent running inside the author's own session; author-side clean-context readback;
organizational-independence credit 0; not a nonauthor review; no review credit.
