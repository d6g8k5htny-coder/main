# Lifetime note C3 — the `ℓ^{2/3}` term of the candidate density

Object `CL-C3-CANDIDATE-TWO-THIRDS-20261006-v1`. Author: Anthropic Claude, session `session_01NMeKEismAyeqgdB4sy2NJU`, for Dylan
Roy (delegated AI work). **Read in every slice** (three Cursor agents, xAI Grok 4.7; all PASS). Scientific effect NONE;
organizational-independence credit 0.

- **Lemma F₃.** At fixed `k > 0`, `(𝐓_r − 𝐒_r)/r → 𝐋_F(k) = (12/(9k))p_{V_0}(v(k))𝔼_k[P²|3kB_ee − γ_e²/4|³; λ_max(A) = 0⁻]`: the
  layer `{|x| ≥ y}` near the edge; the strip `{A < 0 ≤ λ_max(A_M)}` lies inside it (Schur complement of `A_M` in `K_M` negative).
- **Lemma T₁.** `κ(𝓐(κ) − 𝐀₂(0)) → a₁ = (12/9)p_{V_0}(v(0))𝔏(0) = (1/10)∫F₀db` (#242's `F₀`).
- **Theorem C3.** `ν_cand = cℓ^{−1/3} + B_{d,L} + I^{cand}ℓ^{1/4} + c₂ℓ^{1/3} + c₃ℓ^{2/3} + o(ℓ^{2/3})`,
  `c₃ = (1/3)∫_S∫_0^∞(𝐋_F − a₁/k)k^{−5/3}dk dσ`, by dominated convergence with note LU's Theorem U⁼.
- **Proposition G / Corollary G′.** Model value `c₃ = (J/30)∫∫F₀ > 0`, `J = (16/15)∫e^{−12k²}E[(3kB − γ²/4)₊³]k^{−8/3}dk` (a Gamma
  identity cancels the rest); `c₃ ≈ 0.0127896` (`d = 2`), `0.0160923` (`d = 3`); `c₃/c ≈ 0.174`, `0.385` (exploration).
- **Proposition G″.** `c₃` is continuous in the (parity-split) jet law near the model's, so the torus field's `c₃(L) > 0` for
  `L ≥ L₀(d)`, where Theorem P⁺ is then sharp. `L₀(d)` unquantified; nothing at `L = 24`.
- **Records.** Claim 6026342638; note 6027862273 (served 51,701 B, `0764d004…3968`); controls 6027863516 (served 25,650 B,
  `9e9bce96…82e8`; `c3_exact.py` 17,353 B, `da501d50…72f0`; stdout 228 B, `87454072…fb9b`; 4,340 checks in nine groups, M1–M10);
  exploration 6027864820 (served 47,772 B, `51177266…65b2`); read request with the Slice A summons 6027877173, Slice B summons
  6027884186, Slice C summons 6027884438 (drew no pickup) and its resend 6028017654.
- **Author-side referee (not review evidence).** Three clean-context slice referees (A AMEND, B AMEND, C AMEND with one blocking
  finding: Corollary G′'s scope) and a readback of the changes (AMEND: Proposition G″ needs parity-split jet laws; header record).
  All applied before posting. Reports (saved verbatim by the author; subagents cannot write report files), the refereed v1 and
  the read-back v2 drafts and controls, and the referees' own scripts are in `referee/`.
- **Exploration** (`exploration/`): the published files (values script; Slice A referee's Monte Carlo with `mc_summary.py`;
  Slice B referee's cusp-tail quadrature), the raw Monte Carlo outputs, and the author's early, superseded scripts.
- **Reads (7 October).** Slice A **PASS** (6027878271, `bc-7582fb4c…`), Slice B **PASS** (6027885396, `bc-b7769d90…`),
  Slice C **PASS** (6028019347, `bc-4708b545…`); no amendment. The Slice A and B files are the verdict bodies: each agent
  edited its acknowledgement into the verdict. Read-complete note, claim released, and the D5 claim for note SL: 6028351320.
- **Custody.** Stored on Math- in packet #390 (`frontiers/lifetime_two_thirds_chain_20261007/C3/`, with EM.1, LU and SL);
  see `math390_lifetime_two_thirds_chain_20261007/`.

### Files

| file | bytes | sha256 |
|---|---|---|
| `CLAIM_C3_6026342638.md` | 5266 | `e03f918d7d740b15c4627f5ec61183be6fa588cae2a2d96d1aeccf3a8c0dd78c` |
| `CONTROLS_C3_6027863516.md` | 25879 | `d92cb3348cb544a82ce290a1a6cb658666851d79079360d35b3c9240651689d8` |
| `CURSOR_SUMMONS_SLICE_B_6027884186.md` | 4115 | `2f778acb7d9f6896026432657492ba9ecbeea0fcb44d8d597729431f94469ecc` |
| `CURSOR_SUMMONS_SLICE_C_6027884438.md` | 4108 | `9fff0dae5140c906e557745a70770cd8a98afe74a8418f048bc420ef8268be95` |
| `CURSOR_SUMMONS_SLICE_C_RESENT_6028017654.md` | 4507 | `844a4b924db0b56f848d919e7422ea40667dc8812a340be62d51bda9533237ef` |
| `CURSOR_VERDICT_SLICE_A_PASS_6027878271.md` | 8632 | `4dc1db1ceef7e3196ab677b7d70c0acdd3781a6f0291a68bfc3cf8e08cc64deb` |
| `CURSOR_VERDICT_SLICE_B_PASS_6027885396.md` | 10841 | `104a6f02a8aaf836dbfddaf9bd6ae906a807c061a91499806c8765d5f4a1fc33` |
| `CURSOR_VERDICT_SLICE_C_PASS_6028019347.md` | 12357 | `1d0faadf46382336e8335b34f085447c43e202d69128de614027a728d1def45e` |
| `EXPLORATION_C3_6027864820.md` | 48001 | `a4bd15fc4b5ab927d8e84d9f62eef7c3293afd71c5f37c88d888c8be646a190d` |
| `NOTE_C3_6027862273.md` | 51930 | `a9b639083febd170a2349383b6f067416d2d7ee8585a9e820d1dda321de67800` |
| `READ_COMPLETE_CLAIM_RELEASED_AND_SL_CLAIM_6028351320.md` | 4738 | `918e6f7b05545d58984e62aec6daf24c1c2fe31a5ea70c002f1eb67a4e8b27fb` |
| `READ_REQUEST_CURSOR_SUMMONS_SLICE_A_6027877173.md` | 5983 | `c8a44a7ae6da510b7a7950d9c4546e0df22ebafd8f780b3f88a17abef1477f05` |
| `c3_exact.py` | 17353 | `da501d5096664350290e37a4998ab1bd0449b4693e70561b1a906acb380372f0` |
| `c3_exact_stdout.json` | 228 | `87454072e0f11f5de984cb97dbb53d62bcca346646051de5db26bfe13792fb9b` |
| `exploration/author_early_superseded/c3_checks2.py` | 5109 | `55f6c723179a6590e0f4db234e2f20c9181482d3cf0e5a265d456c241a547608` |
| `exploration/author_early_superseded/c3_checks2_out.txt` | 652 | `8d0283917e6cabf970bcec1ad5f93517af95edb9ad6d4c8cab243e88402b2b4a` |
| `exploration/author_early_superseded/c3_formula.py` | 3780 | `fe85041a41ee89f18762babe4d0a614ff61b14ac4432cbfec560c7bbebd76fe4` |
| `exploration/author_early_superseded/layer_birth_mc.json` | 1474 | `ad40092dfa6c8073a9965d99f302817888c8b4aad913da293a3387778724bc31` |
| `exploration/author_early_superseded/layer_birth_mc.py` | 3426 | `c915e547855159fbb9f79c0549597d062a6cfaff8ba23e309d3b72955384e301` |
| `exploration/author_early_superseded/layer_birth_mc_d3.json` | 590 | `8b87bc1873f31d1293e9d4ed42a56aaee95a38bf65874a388b72f4f79b0f700c` |
| `exploration/author_early_superseded/layer_birth_mc_d3.py` | 4700 | `f4aa8db8f900a6acc05982ce12d6707af124fba7eddd09cec7873db98dd4be91` |
| `exploration/author_early_superseded/layer_birth_mc_d3_out.txt` | 558 | `0bcad5d636c264c60dda535b218b4888660a31dbefa48f7ce6f44c6710beacfd` |
| `exploration/author_early_superseded/layer_birth_mc_out.txt` | 1395 | `d8a7bb09e5affc44aa4e7771846a25648469c2948a81010b16627c5f6782792c` |
| `exploration/c3_values.py` | 4200 | `0836247f355fd4e264f0209516f3fc1c4b56c4f8ee83c40987a930973d7606fd` |
| `exploration/c3_values_out.txt` | 1002 | `c8eead9d80b975b9d60034facebae8c612a78015a067a2e6ae395c13cb88fefa` |
| `exploration/engine.py` | 3421 | `ab03229bf483e4a93289371d4b71c60eb0dcbc873b0f88c146605ba933b7d3cd` |
| `exploration/lf_indep.json` | 2210 | `812965f851cfeb2a7b03c5fedb4854e40e844a5915ef55428ea422eba4f59da1` |
| `exploration/lf_indep.out` | 2688 | `1da2256a69cf2cd99d6708a2a4c45af39f6b69c78abb83c9ec669e861b2ee2f5` |
| `exploration/lf_indep.py` | 5763 | `e95cc3cf036f02eaacf9929260b02ec6012629863df1b840a2ddb478a5a76f29` |
| `exploration/mc_d2.out` | 9047 | `748920c9213809c6fda2e8c59892b019bb127151fc3f8a578a585c9eb4ead822` |
| `exploration/mc_d3.out` | 9137 | `a5bd17e709252e6057b0917479896445a517cd31798c0d854a554f88de9490c6` |
| `exploration/mc_layer.py` | 7975 | `92a27f3784ff615b4e2321b98f15193705328bf87ddf6bc94b29cbbb32d6f746` |
| `exploration/mc_summary.py` | 1574 | `e05b6efa412fb6b834a0b7bd9e188c839c66dc3a79dfd7d4d21dff4fe3d31dd4` |
| `exploration/mc_summary.txt` | 8451 | `c330400649e0cd39f2049b017a198685ca4af77fd7ce278f3a940cae9b0186e6` |
| `exploration/run_grid.sh` | 160 | `a60f56be8a10d09dbfe5398bc50be6700c3621ecc4399abdb3c079f195375f37` |
| `exploration/t1_d2.txt` | 1062 | `db24ca0f0a8756557d5ffb4e1f2f6cc2093290b9158a2ab8dc1e8c0c0bc9f72c` |
| `exploration/t1_d3_a.txt` | 650 | `675ce04dfa0a9f41004b3eb69775692bbdec77f2f7c98055445b856e08e0b6e0` |
| `exploration/t1_d3_b.txt` | 572 | `66386af38210e52a54a01c6416756b0ff489a1ea5437985f5fedcf44a28bbf16` |
| `exploration/t1_vec_check.py` | 5703 | `c94f0b92ca873acf6002061e8dafc8d8af7860890e420ff8b66d070314e0a18f` |
| `referee/C3_v1_as_refereed.md` | 35785 | `31ad5812402a0b2c4df550b0452af62b30e6bc6c12d886bde9cfd3a206288cea` |
| `referee/C3_v2_as_read_back.md` | 50220 | `b62642d19761f9b74fb301de28f10cbc6842cd12020b99a00e1024602ded2d40` |
| `referee/REPORT_A.md` | 11080 | `8237ccca654dc40e6205b332fcb988ad6cdfac6f4164054b13bed351764cece0` |
| `referee/REPORT_B.md` | 7051 | `ad0a875f573b902857dc7c09e82ff8d4fd584747353f1c110d54bff5b0f30c7a` |
| `referee/REPORT_C.md` | 8723 | `310f5398240a5fed06fab845a0bd20267e6a1b9db6cee12542767ae7a395b871` |
| `referee/REPORT_READBACK.md` | 6785 | `8f39fe40840d56ab8d7308268a022a293da79618882f46b40cf224ee927d2d0f` |
| `referee/c3_exact_v1_as_refereed.py` | 11422 | `8e74a629edda4b22bb2a081e2ad611de0d32c49b1b7bbadd4e5338abdc04944a` |
| `referee/c3_exact_v2_as_read_back.py` | 17344 | `9cf736991c055de4c161bba9bb3015e231f83f3c45784fca5c4a1bceacfeaab5` |
| `referee/scripts/refA/strip_check.py` | 3560 | `1e3f1b0fa1d3691a054aa15865ff7e712208970aaeacea0fd6d48fee1c41ba6f` |
| `referee/scripts/refA/sym_I1.py` | 4503 | `8117840685b96714bfe6104d1cd7a93b1e425d015d88be6b48f0cf792d2d6fd1` |
| `referee/scripts/refB/sec4_check.py` | 3851 | `eb823ba99c3b160bb367ac0b549eb48787ce89147198cd3a0185ecb930d425e3` |
| `referee/scripts/refB/sec4_check.txt` | 857 | `ab839a6ebe1605caf1aa2860565339072274284855677fe7c2b381067d20e62a` |
| `referee/scripts/refB/t1_d2_check.py` | 3345 | `bf25a170aae48a0b2b6df6d5f3dd60bf4f6868569d069139ae0402b1a4d2cd6b` |
| `referee/scripts/refC/derived.py` | 3810 | `0445969be07eac7a6ad27d3e97724594a3735034128abccdaae3756a5da54da6` |
| `referee/scripts/refC/derived_out.txt` | 1034 | `f7817bbad3713f12ab1d00f3c28ee867142ec47a5542e5816ddef9f6823fca0d` |
| `referee/scripts/refC/g1_exact.py` | 4008 | `bdbbcbfd42c147ce6ad03df9124718c624958ee16126d808e565ab33b90ab224` |
| `referee/scripts/refC/g1_exact_out.txt` | 1941 | `0a78166a64fb561a51b997b58abe87e0896f4f16698ab41b31e025c14e23cd8c` |
| `referee/scripts/refC/j_indep.py` | 4735 | `eb1dc29697c194d2fbbfea7e845a64b706df4b6b56ad63b340f86b607edd4c46` |
| `referee/scripts/refC/j_indep_out.txt` | 1124 | `7e8f4f1f233a946e19a73467c4d8e3b9f25ddbdf0a8b58aaab552294ca20d00e` |
| `referee/scripts/refC/mc_d2_rerun.py` | 3700 | `04c9dc105f1ded1cb76e29ad5756ecf4f9c7d40a0c149bde976484c3897aba41` |
| `referee/scripts/refC/mc_d2_rerun_out.txt` | 582 | `45f10202804d72956064686d49d106ca5ca87def5fb29000f5e6a3c5a235dee8` |
| `referee/scripts/refC/mc_d3_driver.py` | 1095 | `c10ceb2deb576a2f4d0e91a112c13336079271bbdeaca256ae79623a14beafdc` |
| `referee/scripts/refC/mc_d3_rerun_out.txt` | 124 | `1090d3bad819bd5b6e88ead10874821819c9fb8f6e8cf56df177d801109aa447` |
