"""Referee A: independent Monte Carlo of (T_r(k) - S_r(k))/r for the Gaussian kernel, d = 2 and d = 3.

T_r - S_r = 12 p_{V_r}(v(k)) E[Lam],  Lam = r^{-2} Pi (1_typed - 1{A<0}),  r^{-2} Pi = -m_M m_S,  m_i = det K_i / r,
K_i = [[alpha_i, sqrt(r) beta_i^T], [sqrt(r) beta_i, A_i]],  alpha_i = f_uu(i)/r, beta_i = f_{u Theta}(i)/r.
typed: K_M negative definite and K_S of index d-1, decided by EIGENVALUES (not by Haynsworth), so the note's
typedness criterion (Step 3) is tested, not assumed.  Exact Gaussian conditioning on #237's rows V_r (60 digits).
Importance sampling: lambda_max(A) is drawn from a defensive mixture (1/2 a window around 0, 1/2 the exact law),
the remaining jets exactly given A; the estimator is unbiased for any window.
Also records the decomposition Lam1 + Lam2 + Lam3 of Step 3 and checks the criterion
  typed <=> (lambda_max(A_M) < 0 and |x| < y)   whenever A_M, A_S have at most one nonnegative eigenvalue.
"""
import sys
import json
import time
import numpy as np
import mpmath as mp
from engine import hess_functionals, condition, target

mp.mp.dps = 60


def setup(d, r, k):
    X, names, V = hess_functionals(d, r)
    mu, Sc, pV = condition(X, V, target(d, k))
    n = len(X)
    nA = (d - 1) * d // 2
    iY = list(range(n - nA))
    iA = list(range(n - nA, n))
    # transform A-block to the sampling coordinates: d=2: a; d=3: (t, p, c) from (a11, a12, a22)
    if d == 2:
        T = mp.matrix([[1]])
    else:
        T = mp.matrix([[0.5, 0, 0.5], [0.5, 0, -0.5], [0, 1, 0]])
    SAA = mp.matrix([[Sc[i, j] for j in iA] for i in iA])
    SYA = mp.matrix([[Sc[i, j] for j in iA] for i in iY])
    SYY = mp.matrix([[Sc[i, j] for j in iY] for i in iY])
    muA = mp.matrix([mu[i] for i in iA])
    muY = mp.matrix([mu[i] for i in iY])
    Sz = T * SAA * T.T                       # cov of z = T a
    Ti = T ** -1
    # Y | a: mean muY + SYA SAA^{-1}(a - muA), cov SYY - SYA SAA^{-1} SAY ; in terms of z: a = Ti z
    G = SYA * SAA ** -1
    CY = SYY - G * SYA.T
    LY = mp.cholesky(CY)
    f = lambda Mx: np.array([[float(Mx[i, j]) for j in range(Mx.cols)] for i in range(Mx.rows)])
    return dict(d=d, r=r, k=k, pV=float(pV), muA=f(muA)[:, 0], muY=f(muY)[:, 0], Sz=f(Sz), Ti=f(Ti), G=f(G),
                LY=f(LY), names=names, nY=len(iY))


def sample(par, N, rng, Wc):
    d, r, k = par['d'], par['r'], par['k']
    Sz = par['Sz']
    if d == 2:
        sA = np.sqrt(Sz[0, 0])
        Ws = [Wc * r * (1 + 1 / k) * f for f in (0.0625, 0.25, 1.0)]
        comp = rng.integers(0, 4, N)
        lam = rng.normal(0, sA, N)
        for j, W in enumerate(Ws):
            lam = np.where(comp == j + 1, rng.uniform(-W, W, N), lam)
        pex = np.exp(-lam ** 2 / (2 * sA ** 2)) / (np.sqrt(2 * np.pi) * sA)
        q = 0.25 * pex + sum(0.25 * (np.abs(lam) <= W) / (2 * W) for W in Ws)
        w = pex / q
        a = (par['Ti'] @ lam[None, :]).T              # (N, 1)
        lmax = lam
    else:
        # z = (t, p, c); (p, c) from marginal, t | (p, c) from mixture around -rho
        Spc = Sz[1:, 1:]
        Lpc = np.linalg.cholesky(Spc)
        pc = rng.standard_normal((N, 2)) @ Lpc.T
        b = Sz[0, 1:] @ np.linalg.inv(Spc)              # regression of t on (p, c)
        st = np.sqrt(Sz[0, 0] - b @ Sz[1:, 0])
        mt = pc @ b
        rho = np.sqrt(pc[:, 0] ** 2 + pc[:, 1] ** 2)
        Wb = Wc * r * (1 + 1 / k) * (1 + 1 / (2 * rho + np.sqrt(r)))
        Ws = [Wb * f for f in (0.0625, 0.25, 1.0)]
        comp = rng.integers(0, 4, N)
        t = mt + st * rng.standard_normal(N)
        for j, W in enumerate(Ws):
            t = np.where(comp == j + 1, -rho + rng.uniform(-1, 1, N) * W, t)
        pex = np.exp(-(t - mt) ** 2 / (2 * st ** 2)) / (np.sqrt(2 * np.pi) * st)
        q = 0.25 * pex + sum(0.25 * (np.abs(t + rho) <= W) / (2 * W) for W in Ws)
        w = pex / q
        z = np.stack([t, pc[:, 0], pc[:, 1]], axis=1)
        a = z @ par['Ti'].T                            # (a11, a12, a22)
        lmax = t + rho
    Y = par['muY'][None, :] + (a - par['muA'][None, :]) @ par['G'].T + rng.standard_normal((N, par['nY'])) @ par['LY'].T
    return a, Y, w, lmax


def evaluate(par, a, Y, lmax):
    d, r = par['d'], par['r']
    m = d - 1
    s = (-1) ** m
    nP = 1 + (d - 1) + (d - 1) * d // 2

    def block(off):
        al = Y[:, off]
        be = Y[:, off + 1: off + d]
        Avals = Y[:, off + d: off + nP]
        N = Y.shape[0]
        K = np.zeros((N, d, d))
        K[:, 0, 0] = al
        K[:, 0, 1:] = np.sqrt(r) * be
        K[:, 1:, 0] = np.sqrt(r) * be
        Am = np.zeros((N, m, m))
        t = 0
        for i in range(m):
            for j in range(i, m):
                Am[:, i, j] = Avals[:, t]
                Am[:, j, i] = Avals[:, t]
                t += 1
        K[:, 1:, 1:] = Am
        # m_i = det K / r = alpha det A / r - beta^T adj(A) beta  (exact algebra, avoids dividing a float det by r)
        if m == 1:
            detA = Am[:, 0, 0]
            badjb = be[:, 0] ** 2
        else:
            detA = Am[:, 0, 0] * Am[:, 1, 1] - Am[:, 0, 1] ** 2
            badjb = Am[:, 1, 1] * be[:, 0] ** 2 - 2 * Am[:, 0, 1] * be[:, 0] * be[:, 1] + Am[:, 0, 0] * be[:, 1] ** 2
        mi = al * detA / r - badjb
        ev = np.linalg.eigvalsh(K)
        evA = np.linalg.eigvalsh(Am)
        return mi, ev, evA
    mM, evM, evAM = block(0)
    mS, evS, evAS = block(nP)
    typed = (evM < 0).all(axis=1) & ((evS < 0).sum(axis=1) == d - 1)
    neg = lmax < 0
    Lam = -mM * mS * (typed.astype(float) - neg.astype(float))
    x = s * (mM + mS) / 2
    y = s * (mS - mM) / 2
    lamM = evAM[:, -1]
    L1 = (x * x - y * y) * (neg & (np.abs(x) >= y))
    L2 = -(y * y - x * x) * (neg & (np.abs(x) < y) & (lamM >= 0))
    L3 = (y * y - x * x) * ((~neg) & (lamM < 0) & (np.abs(x) < y))
    # criterion check where A_M and A_S have at most one nonnegative eigenvalue
    ok_dom = (evAM[:, 0] < 0) & (evAS[:, 0] < 0) if m >= 2 else np.ones(len(x), bool)
    crit = (lamM < 0) & (np.abs(x) < y)
    mism = ok_dom & (crit != typed)
    hits = np.array([int((neg & (lamM >= 0)).sum()), int((L2 != 0).sum()), int((L3 != 0).sum()),
                     int(((~neg) & (lamM < 0)).sum())])
    return Lam, L1, L2, L3, mism, ok_dom, hits


def run(d, r, k, N, chunks, Wc, seed):
    par = setup(d, r, k)
    rng = np.random.default_rng(seed)
    S = np.zeros(4)
    S2 = np.zeros(4)
    mism = 0
    ndom = 0
    nn = 0
    resid = 0.0
    hits = np.zeros(4, int)
    for _ in range(chunks):
        a, Y, w, lmax = sample(par, N, rng, Wc)
        Lam, L1, L2, L3, mm, od, hh = evaluate(par, a, Y, lmax)
        hits += hh
        vals = np.stack([Lam, L1, L2, L3]) * w[None, :]
        S += vals.sum(axis=1)
        S2 += (vals ** 2).sum(axis=1)
        mism += int(mm.sum())
        ndom += int(od.sum())
        resid = max(resid, float(np.max(np.abs(Lam - (L1 + L2 + L3))[od])) if od.any() else 0.0)
        nn += N
    mean = S / nn
    se = np.sqrt((S2 / nn - mean ** 2) / nn)
    fac = 12 * par['pV'] / r
    return dict(d=d, r=r, k=k, n=nn, Wc=Wc, pV=par['pV'], D_over_r=float(mean[0] * fac), se=float(se[0] * fac),
                L1=float(mean[1] * fac), L1se=float(se[1] * fac), L2=float(mean[2] * fac), L2se=float(se[2] * fac),
                L3=float(mean[3] * fac), L3se=float(se[3] * fac), criterion_mismatches=mism, criterion_domain=ndom,
                max_decomp_residual=resid, hits_strip_L2_L3_Mstrip=[int(h) for h in hits])


if __name__ == '__main__':
    d = int(sys.argv[1])
    k = float(sys.argv[2])
    rs = [float(x) for x in sys.argv[3].split(',')]
    N = int(sys.argv[4])
    chunks = int(sys.argv[5])
    Wc = float(sys.argv[6]) if len(sys.argv) > 6 else 8.0
    seed = int(sys.argv[7]) if len(sys.argv) > 7 else 7
    res = []
    for r in rs:
        t0 = time.time()
        out = run(d, r, k, N, chunks, Wc, seed + int(1e6 * r) + int(1e3 * k))
        out['sec'] = round(time.time() - t0, 1)
        print(json.dumps(out), flush=True)
        res.append(out)
