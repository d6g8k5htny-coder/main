"""Exploration (not proof), Gaussian kernel: (a) J by the positive representation; (b) the cusp tail T1 in d = 2.

(a) g(k) = E|X|^3, X = t^2/2 - 3 sqrt(2) k z (t, z iid N(0,1)) = E[X^3] + 2E[(-X)_+^3], E[X^3] = 15/8 + 27 k^2, and
    int_0^inf (e^{-12k^2}(1 + (72/5)k^2) - 1) k^{-8/3} dk = 0, so
    J = int (e^{-12k^2} g(k)/g(0) - 1) k^{-8/3} dk = (16/15) int e^{-12k^2} h(k) k^{-8/3} dk,  h(k) = E[(3 sqrt(2) k z - t^2/2)_+^3].
(b) scrA(kappa) - A2(0) = 12 p0 E[(Y'^2 - 36 kappa^2 A^2)_+ 1{A<0}] (k = 0 law, d = 2), against a1/kappa.
"""
import mpmath as mp

mp.mp.dps = 30

# (a)
c = mp.mpf(3) * mp.sqrt(2)


def h(k):
    # E[(c k z - t^2/2)_+^3] = int_t phi(t) E[(c k z - t^2/2)_+^3] dt; inner: E[(s z - m)_+^3], s = ck, m = t^2/2
    s = c * k

    def inner(t):
        m = t * t / 2
        a = m / s                       # E[(s z - m)_+^3] = s^3 E[(z - a)_+^3]
        # E[(z-a)_+^3] = (a^2+2) phi(a) - a(a^2+3)(1 - Phi(a))
        return s ** 3 * ((a * a + 2) * mp.npdf(a) - a * (a * a + 3) * (1 - mp.ncdf(a)))
    return 2 * mp.quad(lambda t: inner(t) * mp.npdf(t), [0, mp.sqrt(s), 1, 3, 8])


gid = mp.quad(lambda k: (mp.expm1(-12 * k * k) + mp.e ** (-12 * k * k) * mp.mpf(72) / 5 * k * k) * k ** (-mp.mpf(8) / 3), [0, 0.1, 0.5, 2, mp.inf])
print('identity integral (should be 0):', mp.nstr(gid, 15))
print('closed form: (1/2)Gamma(1/6) 12^{-1/6} (72/5 - 6*12/5) =', mp.nstr(mp.gamma(mp.mpf(1) / 6) / 2 * mp.mpf(12) ** (-mp.mpf(1) / 6) * (mp.mpf(72) / 5 - mp.mpf(72) / 5), 5))
J = mp.mpf(16) / 15 * mp.quad(lambda k: mp.e ** (-12 * k * k) * h(k) * k ** (-mp.mpf(8) / 3), [0, 0.05, 0.2, 0.5, 1, 2, mp.inf])
print('J (positive representation) =', mp.nstr(J, 15))
# also check g(k) = 15/8 + 27k^2 + 2h(k) at a few k against direct quadrature


def E_abs3(mu, sig):
    m = mu / sig
    return sig ** 3 * ((m ** 3 + 3 * m) * (2 * mp.ncdf(m) - 1) + 2 * (m ** 2 + 2) * mp.npdf(m))


for k in (mp.mpf('0.1'), mp.mpf('0.4'), mp.mpf('1.0')):
    g_direct = 2 * mp.quad(lambda t: E_abs3(-(t * t) / 2, c * k) * mp.npdf(t), [0, 2, 5, 12])
    print('k=%s  g direct=%s  15/8+27k^2+2h=%s' % (k, mp.nstr(g_direct, 15), mp.nstr(mp.mpf(15) / 8 + 27 * k * k + 2 * h(k), 15)))

S2, S3 = 2 * mp.pi, 4 * mp.pi
a1_2 = mp.mpf('0.001454721257')
a1_3 = mp.mpf('0.0009151871836')
c2inf, c3inf = mp.mpf('0.073406919306'), mp.mpf('0.0417759318406')
for d, S, a1, cc in ((2, S2, a1_2, c2inf), (3, S3, a1_3, c3inf)):
    c3 = S / 3 * a1 * J
    print('d=%d  c3=%s  c3/c=%s' % (d, mp.nstr(c3, 10), mp.nstr(c3 / cc, 10)))
F0int_2 = 25 * mp.sqrt(3) / (48 * mp.pi ** 2)
F0int_3 = 125 * mp.sqrt(30) / (192 * mp.pi ** 3)
print('S*a1 vs F0/10:  d=2 %s %s   d=3 %s %s' % (mp.nstr(S2 * a1_2, 10), mp.nstr(F0int_2 / 10, 10), mp.nstr(S3 * a1_3, 10), mp.nstr(F0int_3 / 10, 10)))
print('c3 = (J/30) int F0:  d=2 %s  d=3 %s' % (mp.nstr(J / 30 * F0int_2, 10), mp.nstr(J / 30 * F0int_3, 10)))

# (b) the cusp tail in d = 2, k = 0 law: A ~ N(0, 8/3); f4 | A Gaussian; gamma ~ N(0, 2) independent.
# Joint law of (A, f4) given the k = 0 pins (f_xx = f_xy = 0; odd pins irrelevant for even jets):
# Cov(f_yy, f_xxxx) = d^(4,2)C(0) = 3*(-1) = -3, Var f_xxxx = 105, Cov(f_xxxx, f_xx) = -15, Var f_xx = 3, Cov(f_yy, f_xx) = 1.
# conditional on f_xx = 0: Var A = 3 - 1/3 = 8/3; Var f4 = 105 - 225/3 = 30; Cov(A, f4) = -3 - (1)(-15)/3 = 2.
VA, Vf4, CAf = mp.mpf(8) / 3, mp.mpf(30), mp.mpf(2)
p0 = (2 * mp.pi) ** (-mp.mpf(5) / 2) / mp.sqrt(18)


def tail(kappa):
    # E[(Y'^2 - 36 kappa^2 A^2)_+ 1{A<0}], Y' = (f4/12) A - gamma^2/4; integrate gamma (t = gamma/sqrt2) and A, f4 | A Gaussian
    def given_A(A):
        mf = CAf / VA * A
        sf = mp.sqrt(Vf4 - CAf ** 2 / VA)

        def given_t(t):
            beta = -(2 * t * t) / 4
            # Y' = (A/12) f4 + beta, f4 ~ N(mf, sf^2): Y' ~ N(mu, s^2), mu = A mf/12 + beta, s = |A| sf/12
            mu = A * mf / 12 + beta
            s = abs(A) * sf / 12
            cth = 6 * kappa * abs(A)
            # E[(Y^2 - cth^2)_+] for Y ~ N(mu, s^2)
            def part(lo_sign):
                pass
            # E[Y^2 1{|Y| > cth}] - cth^2 P(|Y| > cth)
            a_hi = (cth - mu) / s
            a_lo = (-cth - mu) / s
            # E[Y^2 1{Y > cth}] with Y = mu + s Z: int_{a_hi}^inf (mu + s z)^2 phi
            def tail_moment(a, upper):
                # upper=True: int_a^inf ; False: int_-inf^a
                Q = (1 - mp.ncdf(a)) if upper else mp.ncdf(a)
                ph = mp.npdf(a)
                m1 = ph if upper else -ph
                m2 = (Q + a * ph) if upper else (Q - a * ph)
                return mu * mu * Q + 2 * mu * s * m1 + s * s * m2, Q
            M_hi, Q_hi = tail_moment(a_hi, True)
            M_lo, Q_lo = tail_moment(a_lo, False)
            return M_hi + M_lo - cth ** 2 * (Q_hi + Q_lo)
        return 2 * mp.quad(lambda t: given_t(t) * mp.npdf(t), [0, 1, 3, 8])
    return mp.quad(lambda A: given_A(A) * mp.npdf(A, 0, mp.sqrt(VA)), [-12, -1, -0.1, -0.01, 0])


for kappa in (5, 10, 20, 40, 80):
    val = 12 * p0 * tail(mp.mpf(kappa))
    print('kappa=%3d  (scrA - A2(0))*kappa = %s   a1 = %s' % (kappa, mp.nstr(val * kappa, 10), mp.nstr(a1_2, 10)))
