"""Exploration (not proof): the birth-integrated fold-scale layer, d = 2, Gaussian kernel exp(-|z|^2/2).

D_r(k) := T_r(k) - S_r(k) = 12 p_{V_r}(v(k)) E[(-da dc)(1{typed} - 1{A<0})]   (no birth row: b integrated out)
is compared with r L_F(k), L_F(k) = (12/(9k)) p_{V_0}(v(k)) D_A g(k)  (c3_formula.py).
Rows: (f(c)-f(a))/r = -k r^2, (f_x(c)-f_x(a))/r = 0, T_r = 12k, (f_y(a)+f_y(c))/2 = 0, (f_y(c)-f_y(a))/r = 0
(#237 (1.1) after its unimodular row change). Exact Gaussian conditioning in mpmath; Monte Carlo with common random numbers.
"""
import sys, json
import numpy as np
import mpmath as mp

sys.path.insert(0, '/home/claude/rev/V2_2_2026-09-29/frontiers_candidate_parity_rate_20261001/exploration')
from cusp_parity_mc import covmat, pi_density   # noqa: E402

mp.mp.dps = 60


def setup(r):
    r = mp.mpf(r)
    a, c, o = (-r / 2, mp.mpf(0)), (r / 2, mp.mpf(0)), (mp.mpf(0), mp.mpf(0))
    rows = [
        [(1 / r, (c, (0, 0))), (-1 / r, (a, (0, 0)))],
        [(1 / r, (c, (1, 0))), (-1 / r, (a, (1, 0)))],
        [(6 / r ** 2, (a, (1, 0))), (6 / r ** 2, (c, (1, 0))), (-12 / r ** 3, (c, (0, 0))), (12 / r ** 3, (a, (0, 0)))],
        [(mp.mpf(1) / 2, (a, (0, 1))), (mp.mpf(1) / 2, (c, (0, 1)))],
        [(1 / r, (c, (0, 1))), (-1 / r, (a, (0, 1)))],
    ]
    hess = [[(1 / r ** 2, (a, (2, 0)))], [(1 / r ** 2, (c, (2, 0)))], [(1 / r, (a, (1, 1)))], [(1 / r, (c, (1, 1)))],
            [(mp.mpf(1), (a, (0, 2)))], [(mp.mpf(1), (c, (0, 2)))], [(mp.mpf(1), (o, (0, 2)))]]
    SU = covmat(rows, rows)
    SUi = SU ** -1
    SHU = covmat(hess, rows)
    K = SHU * SUi
    Sc = covmat(hess, hess) - K * SHU.T
    return SU, SUi, K, Sc


def D_of(r, k, Z):
    SU, SUi, K, Sc = setup(r)
    v = [-mp.mpf(k) * mp.mpf(r) ** 2, 0, 12 * mp.mpf(k), 0, 0]
    p = float(pi_density(SU, SUi, v))
    mu = K * mp.matrix(v)
    mu = np.array([float(mu[i]) for i in range(7)])
    S = np.array([[float(Sc[i, j]) for j in range(7)] for i in range(7)])
    w, V = np.linalg.eigh(S)
    w = np.clip(w, 0, None)
    X = mu[None, :] + (Z * np.sqrt(w)[None, :]) @ V.T
    da = X[:, 0] * X[:, 4] - X[:, 2] ** 2
    dc = X[:, 1] * X[:, 5] - X[:, 3] ** 2
    typed = (X[:, 0] < 0) & (X[:, 4] < 0) & (da > 0) & (dc < 0)
    neg = X[:, 6] < 0
    val = (-da * dc) * (typed.astype(float) - neg.astype(float))
    return 12 * p * val.mean(), 12 * p * val.std() / np.sqrt(len(val))


if __name__ == '__main__':
    N = int(sys.argv[1]) if len(sys.argv) > 1 else 2_000_000
    reps = int(sys.argv[2]) if len(sys.argv) > 2 else 4
    a1 = 0.0014547212570                      # c3_formula.py, d = 2
    R = {0.2: 1.1501761, 0.4: 0.8981079, 0.8: 0.016963915}
    rng = np.random.default_rng(20261006)
    out = {}
    for k in (0.2, 0.4, 0.8):
        LF = a1 / k * R[k]
        for r in (0.0025, 0.005, 0.01, 0.02, 0.04):
            vals = []
            for _ in range(reps):
                Z = rng.standard_normal((N, 7))
                vals.append(D_of(r, k, Z)[0])
            vals = np.array(vals)
            D, De = vals.mean(), vals.std(ddof=1) / np.sqrt(reps)
            out['k=%g,r=%g' % (k, r)] = [D, De, LF]
            print('k=%.2f r=%.4f  D/r=%.6e +- %.1e   L_F=%.6e   (D/r)/L_F=%.4f +- %.4f' % (
                k, r, D / r, De / r, LF, D / r / LF, De / r / LF), flush=True)
    json.dump(out, open('/tmp/claude-0/-home-claude/b41b316f-232c-5cf7-a0ee-80f0de603a6f/scratchpad/c3/explore/layer_birth_mc.json', 'w'), indent=1)
