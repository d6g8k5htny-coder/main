"""Exploration (not proof): the birth-integrated fold-scale layer in d = 3, Gaussian kernel exp(-|z|^2/2).

D_r(k) = 12 p_{V_r}(v(k)) E[(-m_a m_c)(1{typed} - 1{A<0})] against r L_F(k), L_F(k) = (a1/k) R(k), a1 = 0.0009151871836
(c3_formula.py, d = 3).  Exact Gaussian conditioning on the seven birth-integrated rows, mpmath; Monte Carlo in numpy.
Scaled endpoint matrices Mt = [[f_xx/r^2, f_xy/r, f_xz/r], [., f_yy, f_yz], [., ., f_zz]]: same inertia as the Hessian,
det Mt = det H / r^2 = m.
"""
import sys, json
import numpy as np
import mpmath as mp

mp.mp.dps = 50


def He(n, t):
    if n == 0:
        return mp.mpf(1)
    h0, h1 = mp.mpf(1), t
    for j in range(1, n):
        h0, h1 = h1, t * h1 - j * h0
    return h1


def cov(f1, f2):
    (p, al), (q, be) = f1, f2
    dz = [p[i] - q[i] for i in range(3)]
    s = (-1) ** sum(al)
    v = s * mp.e ** (-(dz[0] ** 2 + dz[1] ** 2 + dz[2] ** 2) / 2)
    for i in range(3):
        v *= He(al[i] + be[i], dz[i])
    return v


def covmat(L1, L2):
    M = mp.matrix(len(L1), len(L2))
    for i, a in enumerate(L1):
        for j, b in enumerate(L2):
            s = mp.mpf(0)
            for ca, fa in a:
                for cb, fb in b:
                    s += ca * cb * cov(fa, fb)
            M[i, j] = s
    return M


def setup(r):
    r = mp.mpf(r)
    z0 = mp.mpf(0)
    a, c, o = (-r / 2, z0, z0), (r / 2, z0, z0), (z0, z0, z0)
    one, half = mp.mpf(1), mp.mpf(1) / 2
    rows = [
        [(1 / r, (c, (0, 0, 0))), (-1 / r, (a, (0, 0, 0)))],
        [(1 / r, (c, (1, 0, 0))), (-1 / r, (a, (1, 0, 0)))],
        [(6 / r ** 2, (a, (1, 0, 0))), (6 / r ** 2, (c, (1, 0, 0))), (-12 / r ** 3, (c, (0, 0, 0))), (12 / r ** 3, (a, (0, 0, 0)))],
        [(half, (a, (0, 1, 0))), (half, (c, (0, 1, 0)))],
        [(1 / r, (c, (0, 1, 0))), (-1 / r, (a, (0, 1, 0)))],
        [(half, (a, (0, 0, 1))), (half, (c, (0, 0, 1)))],
        [(1 / r, (c, (0, 0, 1))), (-1 / r, (a, (0, 0, 1)))],
    ]
    hess = []
    for p in (a, c):
        hess += [[(1 / r ** 2, (p, (2, 0, 0)))], [(1 / r, (p, (1, 1, 0)))], [(1 / r, (p, (1, 0, 1)))],
                 [(one, (p, (0, 2, 0)))], [(one, (p, (0, 1, 1)))], [(one, (p, (0, 0, 2)))]]
    hess += [[(one, (o, (0, 2, 0)))], [(one, (o, (0, 1, 1)))], [(one, (o, (0, 0, 2)))]]
    SU = covmat(rows, rows)
    SUi = SU ** -1
    SHU = covmat(hess, rows)
    K = SHU * SUi
    Sc = covmat(hess, hess) - K * SHU.T
    return SU, SUi, K, Sc


def pi_density(SU, SUi, v):
    n = len(v)
    vv = mp.matrix(v)
    q = (vv.T * SUi * vv)[0]
    return mp.e ** (-q / 2) / ((2 * mp.pi) ** (mp.mpf(n) / 2) * mp.sqrt(mp.det(SU)))


def mats(X, off):
    xx, xy, xz, yy, yz, zz = (X[:, off + i] for i in range(6))
    M = np.empty((X.shape[0], 3, 3))
    M[:, 0, 0], M[:, 0, 1], M[:, 0, 2] = xx, xy, xz
    M[:, 1, 0], M[:, 1, 1], M[:, 1, 2] = xy, yy, yz
    M[:, 2, 0], M[:, 2, 1], M[:, 2, 2] = xz, yz, zz
    return M


def D_of(prep, Z):
    p, mu, L = prep
    X = mu[None, :] + Z @ L.T
    Ma, Mc = mats(X, 0), mats(X, 6)
    ea, ec = np.linalg.eigvalsh(Ma), np.linalg.eigvalsh(Mc)
    ma, mc = np.linalg.det(Ma), np.linalg.det(Mc)
    typed = (ea[:, 2] < 0) & (ec[:, 1] < 0) & (ec[:, 2] > 0)
    yy, yz, zz = X[:, 12], X[:, 13], X[:, 14]
    neg = (yy + zz < 0) & (yy * zz - yz * yz > 0)
    val = (-ma * mc) * (typed.astype(float) - neg.astype(float))
    return 12 * p * val.mean()


def prepare(r, k):
    SU, SUi, K, Sc = setup(r)
    v = [-mp.mpf(k) * mp.mpf(r) ** 2, 0, 12 * mp.mpf(k), 0, 0, 0, 0]
    p = float(pi_density(SU, SUi, v))
    mu = K * mp.matrix(v)
    mu = np.array([float(mu[i]) for i in range(15)])
    S = np.array([[float(Sc[i, j]) for j in range(15)] for i in range(15)])
    w, V = np.linalg.eigh(S)
    L = V * np.sqrt(np.clip(w, 0, None))[None, :]
    return p, mu, L


if __name__ == '__main__':
    N = int(sys.argv[1]) if len(sys.argv) > 1 else 1_000_000
    reps = int(sys.argv[2]) if len(sys.argv) > 2 else 8
    a1 = 0.0009151871836
    R = {0.2: 1.1501761, 0.4: 0.8981079}
    rng = np.random.default_rng(20261007)
    out = {}
    for k in (0.2, 0.4):
        LF = a1 / k * R[k]
        for r in (0.005, 0.01, 0.02):
            prep = prepare(r, k)
            vals = np.array([D_of(prep, rng.standard_normal((N, 15))) for _ in range(reps)])
            D, De = vals.mean(), vals.std(ddof=1) / np.sqrt(reps)
            out['k=%g,r=%g' % (k, r)] = [D, De, LF]
            print('d=3 k=%.2f r=%.4f  D/r=%.6e +- %.1e   L_F=%.6e   ratio=%.4f +- %.4f' % (
                k, r, D / r, De / r, LF, D / r / LF, De / r / LF), flush=True)
    json.dump(out, open('/tmp/claude-0/-home-claude/b41b316f-232c-5cf7-a0ee-80f0de603a6f/scratchpad/c3/explore/layer_birth_mc_d3.json', 'w'), indent=1)
