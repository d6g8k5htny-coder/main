"""Exploration (not proof): the l^{2/3} coefficient c3 of nu_cand, Gaussian kernel, d = 2 and d = 3.

Normalization of #218/#237: T_r(k,u) = 12 p_{V_r}(v(k)) E[r^{-2} Pi 1_typed] (birth-integrated), and
  c = (|S^{d-1}|/3) int_0^inf k^{-2/3} A_0(k) dk,   A_0(k) = 12 p_{V_0}(v(k)) 36 k^2 E[Delta^2 1{A<0}].
Fold-scale layer (formal, to be proved): T_r - S_r = r L_F(k) + o(r) at fixed k, with
  L_F(k) = (12/(9k)) p_{V_0}(v(k)) D_A g(k),   g(k) = E|3k B_ee - gamma_e^2/4|^3,
  D_A = density of lambda_max(A) at 0^- weighted by P^2 (P = product of the other eigenvalues),
and the cusp tail  scrA(kappa) - A2(0) = a1/kappa + o(1/kappa),  a1 = (12/9) p_{V_0}(v(0)) D_A g(0).
So E(k) = L_F(k) - a1/k = (a1/k)(e^{-12k^2} g(k)/g(0) - 1) and c3 = (|S^{d-1}|/3) int_0^inf E(k) k^{-5/3} dk.
For the Gaussian kernel, gamma_e, B_ee are iid N(0, 2) for every k (no mean shift), in d = 2 and d = 3.
"""
import mpmath as mp

mp.mp.dps = 40


def E_abs3(mu, sig):
    """E|mu + sig Z|^3."""
    if sig == 0:
        return abs(mu) ** 3
    m = mu / sig
    Phi = mp.ncdf(m)
    phi = mp.npdf(m)
    return sig ** 3 * ((m ** 3 + 3 * m) * (2 * Phi - 1) + 2 * (m ** 2 + 2) * phi)


def g(k):
    """E|3k B - gamma^2/4|^3, gamma, B iid N(0, 2): integrate over gamma, closed form in B."""
    sB = 3 * k * mp.sqrt(2)
    f = lambda t: E_abs3(-(2 * t * t) / 4, sB) * mp.npdf(t)       # gamma = sqrt(2) t
    return 2 * mp.quad(f, [0, 2, 5, 12])


def h(k):
    """g(k) - g(0), computed stably."""
    sB = 3 * k * mp.sqrt(2)
    f = lambda t: (E_abs3(-(t * t) / 2, sB) - (t * t / 2) ** 3) * mp.npdf(t)
    return 2 * mp.quad(f, [0, mp.sqrt(sB), 2, 5, 12])


def setup(d):
    if d == 2:
        detSV = 18
        n = 5
        DA = 1 / mp.sqrt(2 * mp.pi * mp.mpf(8) / 3)                    # A ~ N(0, 8/3)
        EA2neg = mp.mpf(8) / 3 / 2                                     # E[A^2 1{A<0}]
        S = 2 * mp.pi
    else:
        detSV = 18
        n = 7
        # A = t I + [[p, c], [c, -p]], t ~ N(0, 5/3), p, c iid N(0, 1); eigenvalues t +- rho
        vt = mp.mpf(5) / 3
        pt = lambda x: mp.npdf(x, 0, mp.sqrt(vt))
        DA = mp.quad(lambda rho: pt(-rho) * 4 * rho ** 2 * rho * mp.e ** (-rho ** 2 / 2), [0, mp.inf])
        # E[Delta^2 1{A<0}], Delta = t^2 - rho^2, A<0 iff t + rho < 0
        EA2neg = mp.quad(lambda rho: rho * mp.e ** (-rho ** 2 / 2) *
                         mp.quad(lambda t: (t * t - rho * rho) ** 2 * pt(t), [-mp.inf, -rho]), [0, mp.inf])
        S = 4 * mp.pi
    p0 = (2 * mp.pi) ** (-mp.mpf(n) / 2) / mp.sqrt(detSV)
    return p0, DA, EA2neg, S


for d in (2, 3):
    p0, DA, EA2neg, S = setup(d)
    pV = lambda k: p0 * mp.e ** (-12 * k * k)
    A0 = lambda k: 12 * pV(k) * 36 * k * k * EA2neg
    c = S / 3 * mp.quad(lambda k: k ** (-mp.mpf(2) / 3) * A0(k), [0, 1, mp.inf])
    g0 = g(0)
    a1 = mp.mpf(12) / 9 * p0 * DA * g0
    R = lambda k: mp.e ** (-12 * k * k) * g(k) / g0
    Rm1 = lambda k: mp.expm1(-12 * k * k) + mp.e ** (-12 * k * k) * h(k) / g0
    k0 = mp.mpf('1e-4')
    J = 3 * 2.4 * k0 ** (mp.mpf(1) / 3) + mp.quad(lambda k: Rm1(k) * k ** (-mp.mpf(8) / 3), [k0, 0.01, 0.05, 0.25, 0.5, 1, 2, mp.inf])
    c3 = S / 3 * a1 * J
    print('d=%d  c=%s  (target %s)' % (d, mp.nstr(c, 12), '0.073406919306' if d == 2 else '0.041775931841'))
    print('      D_A=%s  p0=%s  g(0)=%s (E[gamma^6]/64 = %s)' % (mp.nstr(DA, 10), mp.nstr(p0, 10), mp.nstr(g0, 10), mp.nstr(mp.mpf(120) / 64, 10)))
    print('      a1=%s  (integrated over u: %s)' % (mp.nstr(a1, 10), mp.nstr(S * a1, 10)))
    print('      J=%s  c3=%s  c3/c=%s' % (mp.nstr(J, 10), mp.nstr(c3, 10), mp.nstr(c3 / c, 10)))
    for k in (0.05, 0.1, 0.2, 0.4, 0.8, 1.2):
        print('      k=%-5s R(k)=%s  (R-1)/k^2=%s' % (k, mp.nstr(R(mp.mpf(k)), 8), mp.nstr((R(mp.mpf(k)) - 1) / k ** 2, 8)))
