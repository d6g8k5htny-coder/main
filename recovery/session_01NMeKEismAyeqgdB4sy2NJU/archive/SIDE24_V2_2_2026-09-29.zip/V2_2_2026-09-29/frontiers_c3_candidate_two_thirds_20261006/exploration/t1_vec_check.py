"""Referee B: vectorized independent check of Lemma T1 (the cusp tail) for the Gaussian kernel, d = 2 and d = 3.

G(kappa) := kappa (scrA(kappa) - A2(0)) = kappa * 12 p0 E_{Qbar_{0,0}}[(Y'^2 - 36 kappa^2 Delta^2)_+ 1{A<0}]   ((3.1)),
claimed limit a1 = (1/10) int F0 db (per direction), with #242 Cor. 1':
  d = 2: int int F0 db dsigma = 25 sqrt(3)/(48 pi^2),   |S^1| = 2 pi
  d = 3: int int F0 db dsigma = 125 sqrt(30)/(192 pi^3), |S^2| = 4 pi

Jet laws under Qbar_{0,0} (derived independently by the referee from the derivative moments of exp(-|z|^2/2)):
  d = 2: (A, f4) ~ N(0, [[8/3, 2], [2, 30]]), gamma ~ N(0, 2) independent; p0 = (2pi)^{-5/2} 18^{-1/2}.
  d = 3: A = t I + traceless, t ~ N(0, 5/3), traceless coordinates iid N(0,1) (eigenvalues t +- rho, rho ~ Rayleigh(1),
         uniform frame), f4 | t ~ N(6t/5, 138/5) (independent of the traceless part), gamma ~ N(0, 2 I_2) independent;
         p0 = (2pi)^{-7/2} 18^{-1/2}.  In the eigenframe, adj A = P e e^T + lambda e1 e1^T, with lambda = t + rho (top),
         P = t - rho; gamma^T adj(A) gamma = P ge^2 + lambda gp^2, ge, gp iid N(0, 2) whatever the frame.
f4 is integrated in closed form (Y' is affine in f4). The A-variable at the edge is lambda = -s/kappa, and
kappa * int d(lambda) = int ds. The s-integral uses Gauss-Legendre panels around the kink of the sigma = 0 integrand.
"""
import sys
import numpy as np
from numpy.polynomial.hermite_e import hermegauss
from numpy.polynomial.legendre import leggauss
from scipy.special import ndtr

SQ2PI = np.sqrt(2 * np.pi)


def npdf(z):
    return np.exp(-0.5 * z * z) / SQ2PI


def e_plus(mu, s, c):
    """E[(Y^2 - c^2)_+] for Y ~ N(mu, s^2), s > 0."""
    z0 = (c - mu) / s
    z1 = (-c - mu) / s
    q = ndtr(-z0) + ndtr(z1)
    return (mu * mu + s * s - c * c) * q + s * ((mu + c) * npdf(z0) + (c - mu) * npdf(z1))


def panels(lo_kink, kink, width, n):
    """Gauss-Legendre nodes/weights on [0, kink-width], [kink-width, kink-width/10], ..., [kink+width/10, kink+width]."""
    x, w = leggauss(n)
    a0 = np.maximum(kink - width, 0.5 * kink)
    edges = [np.zeros_like(kink), a0, kink - (kink - a0) / 10, kink, kink + width / 10, kink + width]
    S, W = [], []
    for a, b in zip(edges[:-1], edges[1:]):
        h = (b - a) / 2
        S.append(a[..., None] + h[..., None] * (x + 1))
        W.append(h[..., None] * w)
    return np.concatenate(S, axis=-1), np.concatenate(W, axis=-1)


def G_d2(kappa, ng=120, n=60):
    VA, VF, CAF = 8 / 3, 30.0, 2.0
    SF = np.sqrt(VF - CAF ** 2 / VA)
    p0 = (2 * np.pi) ** (-2.5) / np.sqrt(18)
    xg, wg = hermegauss(ng)
    g = np.sqrt(2) * xg
    wg = wg / SQ2PI
    ts = 8 * kappa ** 2 * (np.sqrt(36 + g * g / (16 * kappa ** 2)) - 6)
    ts = np.maximum(ts, 1e-300)
    width = ts * 40 * SF / (72 * kappa)
    T, WT = panels(None, ts, width, n)
    A = -T / kappa
    mu = A * A / 16 - (g * g / 4)[:, None]
    s = T * SF / (12 * kappa)
    val = npdf(A / np.sqrt(VA)) / np.sqrt(VA) * e_plus(mu, s, 6 * T)
    inner = np.sum(val * WT, axis=1)
    return 12 * p0 * np.sum(wg * inner)


def G_d3(kappa, nge=64, ngp=24, nrho=64, n=40, rho_max=9.0):
    p0 = (2 * np.pi) ** (-3.5) / np.sqrt(18)
    vt = 5 / 3
    sf4 = np.sqrt(138 / 5)
    xe, we = hermegauss(nge)
    xp, wp = hermegauss(ngp)
    ge_all, we = np.sqrt(2) * xe, we / SQ2PI
    gp, wp = np.sqrt(2) * xp, wp / SQ2PI
    xr, wr = leggauss(nrho)
    rho = rho_max / 2 * (xr + 1)
    wr = rho_max / 2 * wr * rho * np.exp(-rho * rho / 2)          # Rayleigh(1) weight folded in
    total = 0.0
    for ge, wge in zip(ge_all, we):
        R, GP = np.meshgrid(rho, gp, indexing="ij")              # (nrho, ngp)
        Wgrid = np.outer(wr, wp)

        def parts(sv):
            lam = -sv / kappa
            P = lam - 2 * R[..., None] if sv.ndim == 3 else lam - 2 * R
            t = lam - (R[..., None] if sv.ndim == 3 else R)
            Dl = lam * P
            gpp = GP[..., None] if sv.ndim == 3 else GP
            mu = t * Dl / 10 - (P * ge * ge + lam * gpp * gpp) / 4
            sig = np.abs(Dl) * sf4 / 12
            c = 6 * sv * np.abs(P)
            return mu, sig, c, t
        # kink: |mu(s)| = c(s); Newton from s = ge^2/24 (vectorized, with a safeguard)
        sk = np.full(R.shape, ge * ge / 24 + 1e-300)
        for _ in range(30):
            h = 1e-7 * np.maximum(sk, 1e-12)
            m1, _, c1, _ = parts(sk)
            m2, _, c2, _ = parts(sk + h)
            f1 = np.abs(m1) - c1
            f2 = np.abs(m2) - c2
            d = (f2 - f1) / h
            step = np.where(d != 0, f1 / d, 0.0)
            sk = np.clip(sk - step, 0.5 * sk, 2 * sk + 1e-300)
        width = sk * 40 * sf4 / (72 * kappa) + 1e-300
        S, WS = panels(None, sk, width, n)                      # (nrho, ngp, npts)
        mu, sig, c, t = parts(S)
        dens = np.exp(-t * t / (2 * vt)) / np.sqrt(2 * np.pi * vt)
        val = dens * e_plus(mu, np.maximum(sig, 1e-300), c)
        inner = np.sum(val * WS, axis=-1)
        total += wge * np.sum(Wgrid * inner)
    return 12 * p0 * total


A1 = {2: 25 * np.sqrt(3) / (48 * np.pi ** 2) / 10 / (2 * np.pi),
      3: 125 * np.sqrt(30) / (192 * np.pi ** 3) / 10 / (4 * np.pi)}

if __name__ == "__main__":
    d = int(sys.argv[1])
    ks = [float(x) for x in sys.argv[2:]]
    print("d=%d  a1 = (1/10) int F0 db per direction = %.13g" % (d, A1[d]))
    for k in ks:
        if d == 2:
            g1, g2 = G_d2(k), G_d2(k, ng=160, n=90)
        else:
            g1, g2 = G_d3(k), G_d3(k, nge=80, ngp=32, nrho=80, n=56)
        print("kappa=%-8g G=%.13g (refined %.13g, diff %.1e)  G/a1-1=%.6e  kappa*(G/a1-1)=%.6f"
              % (k, g1, g2, g2 - g1, g2 / A1[d] - 1, k * (g2 / A1[d] - 1)))
        sys.stdout.flush()
