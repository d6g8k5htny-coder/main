"""Exploration (not proof, not a control): the numbers quoted in note C3's section 5 and Remarks 2-3, Gaussian kernel.

mpmath only.  gamma, B independent N(0, 2); X := gamma^2/4 - 3kB; g(k) = E|X|^3 = 15/8 + 27k^2 + 2h(k),
h(k) := E[(3kB - gamma^2/4)_+^3] (the positive representation; with gamma = sqrt2 t, B = sqrt2 z, t, z iid N(0, 1)).
R(k) := e^{-12k^2} g(k)/g(0), so E(k) = (a1/k)(R(k) - 1) (G.2) and J = int_0^inf (R(k) - 1) k^{-8/3} dk (G).
Inputs quoted from the sources: c_{d,inf} (#216, #223), c1 (#207 section 8), c2 (#223's closed forms),
int int F0 (#242 Corollary 1'), R_{2/3} (#244, numerically), #216's elder-density range [1e-4, 1e-2].
"""
import mpmath as mp

mp.mp.dps = 20
S32 = 3 * mp.sqrt(2)


def h(k):
    """E[(3kB - gamma^2/4)_+^3] = 2 int_0^inf phi(t) (ck)^3 E[(z - t^2/(2ck))_+^3] dt, c = 3 sqrt2."""
    k = mp.mpf(k)
    if k == 0:
        return mp.mpf(0)
    s = S32 * k

    def inner(t):
        a = t * t / (2 * s)                     # E[(z - a)_+^3] = (a^2 + 2) phi(a) - a(a^2 + 3)(1 - Phi(a))
        return s ** 3 * ((a * a + 2) * mp.npdf(a) - a * (a * a + 3) * (1 - mp.ncdf(a)))
    return 2 * mp.quad(lambda t: inner(t) * mp.npdf(t), [0, mp.sqrt(s), 1, 3, 8])


def g(k):
    return mp.mpf(15) / 8 + 27 * mp.mpf(k) ** 2 + 2 * h(k)


def R(k):
    k = mp.mpf(k)
    return mp.e ** (-12 * k * k) * g(k) / (mp.mpf(15) / 8)


# the Gamma identity at (a, b) = (12, 72/5): the bracket integrates to 0
br = mp.quad(lambda k: (mp.expm1(-12 * k * k) + mp.e ** (-12 * k * k) * mp.mpf(72) / 5 * k * k) * k ** (-mp.mpf(8) / 3),
             [0, 0.001, 0.01, 0.05, 0.3, 1, 3, mp.inf])
print('Gamma identity at (12, 72/5): int = %s' % mp.nstr(br, 3))
J = mp.mpf(16) / 15 * mp.quad(lambda k: mp.e ** (-12 * k * k) * h(k) * k ** (-mp.mpf(8) / 3), [0, 0.05, 0.2, 0.5, 1, 2, mp.inf])
print('J = %s' % mp.nstr(J, 12))

# the k^{7/2} coefficient of R(k) - 1: (16/15) h(k) ~ (16/15)(32/(35 sqrt pi)) (3k)^{7/2} E[B_+^{7/2}]
c72 = 256 * mp.mpf(6) ** mp.mpf(3.5) * mp.gamma(mp.mpf(9) / 4) / (525 * mp.pi)
print('c_{7/2} = 256 6^{7/2} Gamma(9/4)/(525 pi) = %s' % mp.nstr(c72, 8))
for k in ('0.001', '0.003', '0.01'):
    k = mp.mpf(k)
    print('  k=%s  (R - 1 - (12/5)k^2)/k^{7/2} = %s' % (k, mp.nstr((R(k) - 1 - mp.mpf(12) / 5 * k * k) / k ** mp.mpf(3.5), 8)))

FF = {2: 25 * mp.sqrt(3) / (48 * mp.pi ** 2), 3: 125 * mp.sqrt(30) / (192 * mp.pi ** 3)}      # int int F0 (#242 Cor. 1')
SPH = {2: 2 * mp.pi, 3: 4 * mp.pi}
CINF = {2: mp.mpf('0.0734069193'), 3: mp.mpf('0.0417759318')}                                 # #216, #223
a1 = {d: FF[d] / 10 / SPH[d] for d in (2, 3)}
print('a1 per direction: d=2 %s  d=3 %s;  (12/5) a1 (d=2) = %s' % (mp.nstr(a1[2], 10), mp.nstr(a1[3], 10),
                                                                  mp.nstr(mp.mpf(12) / 5 * a1[2], 8)))
for k in ('0.05', '0.1', '0.2', '0.4', '0.8'):
    r = R(k)
    print('  k=%-4s R(k) = %s   a1 (R - 1)/k^2 (d=2) = %s' % (k, mp.nstr(r, 10), mp.nstr(a1[2] * (r - 1) / mp.mpf(k) ** 2, 6)))
print('E(k) changes sign at k = %s' % mp.nstr(mp.findroot(lambda k: R(k) - 1, mp.mpf('0.37')), 6))
print('1/R(0.8) = %s' % mp.nstr(1 / R('0.8'), 5))

R23 = {2: mp.mpf('-0.048779'), 3: mp.mpf('-0.061375')}                                        # #244 (numerically)
C1 = {2: mp.mpf('-0.26939883'), 3: mp.mpf('-0.21184835')}                                     # #207 section 8
C2 = {2: mp.mpf(13) / 18 * mp.mpf(12) ** (mp.mpf(1) / 6) * mp.gamma(mp.mpf(5) / 6) / mp.pi ** mp.mpf(1.5),
      3: mp.mpf(5) / 48 * (33 - 7 * mp.sqrt(6)) * mp.mpf(12) ** (mp.mpf(1) / 6) * mp.gamma(mp.mpf(5) / 6) / mp.pi ** mp.mpf(2.5)}
for d in (2, 3):
    c3 = J / 30 * FF[d]
    t = c3 - R23[d]
    law = lambda l: CINF[d] * l ** (-mp.mpf(1) / 3) + C1[d] * l ** (mp.mpf(1) / 4) + C2[d] * l ** (mp.mpf(1) / 3)
    lo, hi = mp.mpf('1e-4'), mp.mpf('1e-2')
    base = mp.quad(law, [lo, hi])
    extra = t * (hi ** (mp.mpf(5) / 3) - lo ** (mp.mpf(5) / 3)) * mp.mpf(3) / 5
    print('d=%d  c3 = %s  c3/c = %s  c2 = %s  c3 - R23 = %s = %s c  count ratio on [1e-4, 1e-2] = %s'
          % (d, mp.nstr(c3, 9), mp.nstr(c3 / CINF[d], 7), mp.nstr(C2[d], 9), mp.nstr(t, 7), mp.nstr(t / CINF[d], 6),
             mp.nstr(1 + extra / base, 6)))
