"""Referee A: independent Gaussian-kernel engine (C(z) = exp(-|z|^2/2) on R^d).

Written from scratch for the referee pass (does not import or copy the author's exploration code).
Cov(d^a f(x), d^b f(y)) = (-1)^{|b|} (d^{a+b} C)(x - y),  d_x^n e^{-x^2/2} = (-1)^n He_n(x) e^{-x^2/2}.
Rows V_r of #237 (1.1): avg gradient, gradient difference / r, T_r; target v(k) = (0_d, 0_d, 12k).
"""
import mpmath as mp

mp.mp.dps = 60


def He(n, x):
    a, b = mp.mpf(1), x
    if n == 0:
        return a
    for j in range(1, n):
        a, b = b, x * b - j * a
    return b


def dC(gam, z):
    v = mp.mpf(1)
    for g, zz in zip(gam, z):
        v *= (-1) ** g * He(g, zz)
    return v * mp.exp(-sum(zz * zz for zz in z) / 2)


def cov(L1, L2):
    """L = list of (coef, point, multiindex)."""
    s = mp.mpf(0)
    for c1, x, a in L1:
        for c2, y, b in L2:
            z = [xi - yi for xi, yi in zip(x, y)]
            s += c1 * c2 * (-1) ** sum(b) * dC([ai + bi for ai, bi in zip(a, b)], z)
    return s


def ei(d, *idx):
    v = [0] * d
    for i in idx:
        v[i] += 1
    return tuple(v)


def rows(d, r):
    """#237 (1.1) rows; u = e_0, Theta = e_1..e_{d-1}."""
    r = mp.mpf(r)
    M = [-r / 2] + [mp.mpf(0)] * (d - 1)
    S = [r / 2] + [mp.mpf(0)] * (d - 1)
    R = []
    for j in range(d):
        R.append([(mp.mpf(1) / 2, M, ei(d, j)), (mp.mpf(1) / 2, S, ei(d, j))])
    for j in range(d):
        R.append([(1 / r, S, ei(d, j)), (-1 / r, M, ei(d, j))])
    R.append([(6 / r ** 2, M, ei(d, 0)), (6 / r ** 2, S, ei(d, 0)), (-12 / r ** 3, S, ei(d)), (12 / r ** 3, M, ei(d))])
    return R, M, S


def rows0(d):
    """the r = 0 limit V_0 = (grad f(0), d_u grad f(0), d_u^3 f(0))."""
    O = [mp.mpf(0)] * d
    R = [[(mp.mpf(1), O, ei(d, j))] for j in range(d)]
    R += [[(mp.mpf(1), O, ei(d, 0, j))] for j in range(d)]
    R.append([(mp.mpf(1), O, ei(d, 0, 0, 0))])
    return R, O


def target(d, k):
    return [mp.mpf(0)] * (2 * d) + [12 * mp.mpf(k)]


def gauss_density(Sig, v):
    n = Sig.rows
    vv = mp.matrix(v)
    q = (vv.T * (Sig ** -1) * vv)[0, 0]
    return mp.exp(-q / 2) / mp.sqrt((2 * mp.pi) ** n * mp.det(Sig))


def condition(X, V, v):
    """conditional mean/cov of functionals X given V = v; returns (mu, Sc, pV)."""
    SVV = mp.matrix([[cov(a, b) for b in V] for a in V])
    SXV = mp.matrix([[cov(a, b) for b in V] for a in X])
    SXX = mp.matrix([[cov(a, b) for b in X] for a in X])
    K = SXV * SVV ** -1
    mu = K * mp.matrix(v)
    Sc = SXX - K * SXV.T
    return mu, Sc, gauss_density(SVV, v)


def hess_functionals(d, r):
    """scaled endpoint Hessian entries and A(0):
    at P in {M, S}: alpha = f_uu/r, beta_j = f_{u theta_j}/r, A_P[i][j] = f_{theta_i theta_j} (i<=j);
    at 0: A0[i][j] (i<=j). Returns (list of functionals, index map)."""
    R, M, S = rows(d, r)
    r = mp.mpf(r)
    O = [mp.mpf(0)] * d
    X, names = [], []
    for nm, P in (('M', M), ('S', S)):
        X.append([(1 / r, P, ei(d, 0, 0))]); names.append((nm, 'alpha'))
        for j in range(1, d):
            X.append([(1 / r, P, ei(d, 0, j))]); names.append((nm, 'beta', j))
        for i in range(1, d):
            for j in range(i, d):
                X.append([(mp.mpf(1), P, ei(d, i, j))]); names.append((nm, 'A', i, j))
    for i in range(1, d):
        for j in range(i, d):
            X.append([(mp.mpf(1), O, ei(d, i, j))]); names.append(('0', 'A', i, j))
    return X, names, R
