"""Summarize mc_layer.py output against lf_indep.py's L_F (author's summarizer for the Slice A referee's runs).

Usage: python3 mc_summary.py mc_d2.out mc_d3.out lf_indep.json > mc_summary.txt
"""
import json
import sys

lf = json.load(open(sys.argv[3]))
zs = []
for path in sys.argv[1:3]:
    rows = [json.loads(line) for line in open(path) if line.startswith('{')]
    d = rows[0]['d']
    print('d=%d   ratio (T_r-S_r)/(r L_F)   [L_F from lf_indep.py; MC from mc_layer.py]' % d)
    a1 = lf['d=%d,a1' % d]
    for x in rows:
        rec = lf['d=%d,k=%g' % (d, x['k'])]
        LF = rec['LF']
        ratio, se = x['D_over_r'] / LF, x['se'] / LF
        z = (ratio - 1) / se
        zs.append(z)
        h = x['hits_strip_L2_L3_Mstrip']
        line = ('  k=%g r=%.4f n=%.1e  (T-S)/r=%.6e+-%.1e  L_F=%.6e  ratio=%.4f+-%.4f (z=%+.2f)  vs a1/k: %.4f  L2/r=%.1e '
                'L3/r=%.1e strip=%d L2hits=%d crit_mism=%d'
                % (x['k'], x['r'], x['n'], x['D_over_r'], x['se'], LF, ratio, se, z, x['D_over_r'] / (a1 / x['k']),
                   x['L2'], x['L3'], h[0], h[1], x['criterion_mismatches']))
        if d == 3:
            line += ' | ratio if |P|: %.3f, if |P|^3: %.3f' % (ratio * rec['Lfrak'] / rec['Lfrak_P1'],
                                                                ratio * rec['Lfrak'] / rec['Lfrak_P3'])
        print(line)
n = len(zs)
print('all %d points: mean z = %.3f, rms z = %.3f, max |z| = %.2f, chi2/dof = %.3f'
      % (n, sum(zs) / n, (sum(z * z for z in zs) / n) ** 0.5, max(abs(z) for z in zs), sum(z * z for z in zs) / n))
