"""Referee A: independent evaluation of L_F(k) = (12/(9k)) p_{V_0}(v(k)) Lfrak(k), Gaussian kernel, d = 2, 3.

Lfrak(k) = E_k[P^2 |U_red|^3 ; lambda_m = 0-]  (C3 (0.2)-(0.3)), computed from this engine's own r = 0 conditional
laws given V_0 = v(k) -- (G.1) is NOT assumed: the law of (B_ee, gamma_e) is computed for each e, and the edge
density of A is integrated with its general covariance in coordinates A = t I + [[p, c], [c, -p]] (d = 3).
Also prints alternative coefficients (|P|, |P|^3 in place of P^2) so the d = 3 Monte Carlo can discriminate.
"""
import sys
import json
import mpmath as mp
import numpy as np
from engine import rows0, target, condition, ei, cov

mp.mp.dps = 20


def E_abs3(mu, sig):
    """E|mu + sig Z|^3 (closed form; checked against quadrature in selftest)."""
    if sig == 0:
        return abs(mu) ** 3
    m = mu / sig
    return sig ** 3 * ((m ** 3 + 3 * m) * (1 - 2 * mp.ncdf(-m)) + 2 * (m ** 2 + 2) * mp.npdf(m))


def selftest():
    for mu, sig in ((0.3, 1.1), (-2.0, 0.7), (0.0, 2.0)):
        q = mp.quad(lambda z: abs(mu + sig * z) ** 3 * mp.npdf(z), [-mp.inf, -mu / sig, mp.inf])
        assert abs(q - E_abs3(mp.mpf(mu), mp.mpf(sig))) < 1e-15, (mu, sig)


def odd_law(d, k, e):
    """law of (B_ee, gamma_e) given V_0 = v(k): B_ee = sum e_i e_j f_{u ij}, gamma_e = sum e_i f_{uu i}."""
    O = [mp.mpf(0)] * d
    th = range(1, d)
    Bee = [(e[i - 1] * e[j - 1], O, ei(d, 0, i, j)) for i in th for j in th]
    ge = [(e[i - 1], O, ei(d, 0, 0, i)) for i in th]
    V, _ = rows0(d)
    mu, Sc, pV = condition([Bee, ge], V, target(d, k))
    return mu, Sc, pV


def h_k(d, k, e):
    """E|3k B_ee - gamma_e^2/4|^3: integrate gamma_e, closed form in B_ee | gamma_e."""
    mu, Sc, _ = odd_law(d, k, e)
    mB, mg = mu[0], mu[1]
    sBB, sBg, sgg = Sc[0, 0], Sc[0, 1], Sc[1, 1]
    cB = sBg / sgg
    sBc = mp.sqrt(sBB - sBg ** 2 / sgg)
    k = mp.mpf(k)

    def f(g):
        mean = 3 * k * (mB + cB * (g - mg)) - g * g / 4
        return E_abs3(mean, 3 * k * sBc) * mp.npdf(g, mg, mp.sqrt(sgg))
    sg = mp.sqrt(sgg)
    return mp.quad(f, [mg - 14 * sg, mg - 4 * sg, mg, mg + 4 * sg, mg + 14 * sg])


def A_law(d, k):
    O = [mp.mpf(0)] * d
    th = range(1, d)
    X = [[(mp.mpf(1), O, ei(d, i, j))] for i in th for j in th if i <= j]
    V, _ = rows0(d)
    mu, Sc, pV = condition(X, V, target(d, k))
    return mu, Sc, pV


def Lfrak(d, k, power=2):
    """edge expectation E[|P|^power h_k(e); lambda_max(A) = 0-]."""
    muA, SA, pV = A_law(d, k)
    if d == 2:
        # m = 1: P = 1, e = (1); density of A at 0
        assert abs(muA[0]) < 1e-30
        dens0 = mp.npdf(0, 0, mp.sqrt(SA[0, 0]))
        return dens0 * h_k(2, k, [mp.mpf(1)]), pV, {'pA0': dens0, 'varA': SA[0, 0]}
    # d = 3: A = [[a, c], [c, b]]  ->  (t, p, c), t = (a+b)/2, p = (a-b)/2
    T = mp.matrix([[0.5, 0, 0.5], [0.5, 0, -0.5], [0, 1, 0]])   # (a, c, b) -> (t, p, c); engine order is (11, 12, 22)
    S = T * SA * T.T
    Si = S ** -1
    detS = mp.det(S)
    norm = 1 / mp.sqrt((2 * mp.pi) ** 3 * detS)

    def ptpc(t, p, c):
        v = mp.matrix([t, p, c])
        return norm * mp.exp(-(v.T * Si * v)[0, 0] / 2)
    # h_k(e) as a function of the eigenvector angle; e = (cos(psi/2), sin(psi/2)), (p, c) = rho (cos psi, sin psi)
    hcache = {}

    def h_of_psi(psi):
        key = mp.nstr(psi, 25)
        if key not in hcache:
            hcache[key] = h_k(3, k, [mp.cos(psi / 2), mp.sin(psi / 2)])
        return hcache[key]
    # edge: t = -rho, lambda_min = -2 rho, |P| = 2 rho. dp dc = rho drho dpsi.
    def inner(psi):
        hv = h_of_psi(psi)
        return hv * mp.quad(lambda rho: (2 * rho) ** power * ptpc(-rho, rho * mp.cos(psi), rho * mp.sin(psi)) * rho,
                            [0, 1, 3, 8, 20])
    npsi = 12                                    # periodic trapezoid rule (spectrally accurate in psi)
    val = sum(inner(2 * mp.pi * j / npsi) for j in range(npsi)) * 2 * mp.pi / npsi
    return val, pV, {'cov_tpc': [[float(S[i, j]) for j in range(3)] for i in range(3)],
                     'h_spread': [float(min(hcache.values())), float(max(hcache.values()))]}


if __name__ == '__main__':
    selftest()
    ks = [float(x) for x in sys.argv[1:]] or [0.2, 0.4, 0.8]
    out = {}
    for d in (2, 3):
        for k in [0.0] + ks:
            L2, pV, info = Lfrak(d, k, 2)
            rec = {'Lfrak': float(L2), 'pV0': float(pV)}
            if k > 0:
                rec['LF'] = float(12 / (9 * mp.mpf(k)) * pV * L2)
            if d == 3:
                rec['Lfrak_P1'] = float(Lfrak(d, k, 1)[0])
                rec['Lfrak_P3'] = float(Lfrak(d, k, 3)[0])
                rec['h_spread'] = info['h_spread']
                if k == 0.0:
                    rec['cov_tpc'] = info['cov_tpc']
            else:
                rec.update({'pA0': float(info['pA0']), 'varA': float(info['varA'])})
            out['d=%d,k=%g' % (d, k)] = rec
            print(d, k, rec, flush=True)
        # a1 and checks of (G.1) as a by-product: odd law for several e, two k
        a1 = 12 / mp.mpf(9) * out['d=%d,k=0' % d]['pV0'] * out['d=%d,k=0' % d]['Lfrak']
        out['d=%d,a1' % d] = float(a1)
        print('d=%d a1=%s' % (d, mp.nstr(a1, 12)))
    for d, es in ((2, [[1]]), (3, [[1, 0], [0.6, 0.8], [mp.cos(1.1), mp.sin(1.1)]])):
        for k in (0.0, 0.7):
            for e in es:
                mu, Sc, pV = odd_law(d, k, [mp.mpf(x) for x in e])
                print('odd law d=%d k=%g e=%s: mean=(%s,%s) cov=[[%s,%s],[%s,%s]] pV0=%s' % (
                    d, k, [float(x) for x in e], mp.nstr(mu[0], 8), mp.nstr(mu[1], 8), mp.nstr(Sc[0, 0], 10),
                    mp.nstr(Sc[0, 1], 6), mp.nstr(Sc[1, 0], 6), mp.nstr(Sc[1, 1], 10), mp.nstr(pV, 12)))
    json.dump(out, open('lf_indep.json', 'w'), indent=1)
