#!/bin/bash
# d k rlist N chunks Wc seed
d=$1
for k in 0.2 0.4 0.6 0.8; do
  python3 mc_layer.py $d $k 0.0025,0.005,0.01,0.02,0.04 500000 $2 8 $((1000*d))
done
