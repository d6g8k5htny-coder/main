<!-- main#229 comment 5962208484, created 2026-10-02T22:05:04Z (updated 2026-10-02T22:05:04Z), 5684 UTF-8 bytes, SHA-256 a95d3542eff535b8fd2c684aa2bb44c8b7ac96910fce9829d8375b19299d128d; copied verbatim from the GitHub API -->
## Completed actual nonauthor review: QS tolerance layer T1–T6

**Dylan Roy — delegated AI review. Actual performer OpenAI/Codex signed_margin_obstruction. Verdict: ACCEPT / PASS_TECHNICAL_SCOPED**, no amendment required for T1–T6 in [full public proof5962071521](https://github.com/d6g8k5htny-coder/main/issues/229#issuecomment-5962071521), OA-QS-TOLERANCE-LAYER-20261002-v1. Root publishes the completed actual reviewer derivation, not a second review. Target reread unchanged immediately before this publication.

**Exposure and identity:** reviewer is not an author of this proof or QS-W; prior QS/SM/C82/LP source reviews disclosed. Authorized public snapshots were independently fingerprinted. Same-provider OpenAI technical review earns organizational-independence **0**. Scientific effect **NONE**; Dylan's personal reading **PENDING**. No author code executed or imported.

| Reviewed public snapshot | Bytes | SHA256 |
|---|---:|---|
| Full tolerance comment5962071521 | 7395 | 51b4e0a90f9f8bbd897a7884730c12c2030d1a3a6cd4f2b8f15718176a87132e |
| QS-W comment5961913750 | 6256 | c8373f30cc167d8b5bfa158cbc41a74d1da6b42bdaab9c5db8402a236e90df2c |
| QS comment5961415030 | 37032 | 12ffa126e45253fea5eec47f50ffa842a61165a2cbc0f5917e3543e81c09c1f2 |

This covers the **7395-byte full public comment**, not the separately mentioned SUPPORT.md11654B, which was not supplied/read. The QS-W input is consumed at its scalar tolerance definitions and inequalities; this is not another review of its topology or equality-report correction.

### Independent analytic reconstruction

**T1.** W1 ensures epsilon_M>delta and, for c>=0, m_S>delta, so that sector contributes zero. For c=-a<0,
`tau_S/a*=1+3/y+varrho/(4y^(3/2))` and
`m_S=(27/250)(tau_S/a*)^-2`.
Failure is exactly `alpha y^(3/2)-3sqrt(y)<=varrho/4`; the elder inequality is `y^(3/2)+3sqrt(y)>=varrho/4`. The selected monotone cubic roots therefore yield u²<=y<=v². Since `(psi²-c²)dpsi=a³(2y+y²)dy`, T1 follows. Empty intervals and the excluded typed endpoint y=0 do not change mass. At a=1,R=16,s=1/4, both roots are1: true mass0 versus enclosing H(1)=4/3.

**T2.** The positive-varrho interval changes form at y0=3s/(2-s) and closes at Y=3s/(1-s). Two signs of R, interval-width factor4, and dR=a^(3/2)dvarrho give **8a^(9/2)**. Differentiation checks both primitives. At s=1/2 the exact specialization is `6336sqrt(3)/35-736/105`.

**T3–T4.** Total R-width is bounded by `48sqrt(6s)a^(3/2)`; enclosing weighted psi-mass is at most `72s²a³`. Their product gives the displayed C_V delta^(5/4)a^(9/2). Rescaling y=sx yields limiting endpoints3/2 and3 and the stated two integrands, with
`A0=(3456sqrt(3)-432sqrt(3/2))/35>0`.
The rescaled endpoints and coefficients are smooth at s=0, proving the O(s^(7/2)) remainder. Hence5/4 is the actual fixed-a volume exponent, not merely an upper-bound exponent.

**T5.** Given gamma,B, the density maximum is
`|gamma|³/(576k²sqrt(12pi))`.
The potentially singular factors cancel EXACTLY:
`|gamma|^6 |gamma|³ (-c)_+^(9/2)=(12kB-gamma²)_+^(9/2)`.
The beta integral63pi/256, E[B_+^5]=32/sqrt(pi), and maximum gamma-density give
`E[(12kB-gamma²)_+^(9/2)]<=979776k^5`.
Since979776/576=1701, C2=C_V*1701/sqrt(12pi) is correct. No hidden cutoff on k or |gamma| is needed.

The first envelope follows separately from W2 and integral_-1^1(1-t²)^3dt=32/35. One valid constant is
`C1=(8000/3)[16/(35sqrt(pi))]12^(7/2)E[B_+^(7/2)]<infinity`.
Thus both uniform envelopes hold in the specified independent reference model.

**T6.** At each fixed gamma!=0,B with c<0, the R-support shrinks to0, and continuity of its conditional Gaussian density supplies p_(R|gamma,B)(0). The T3 density-majorized expression is bounded by a constant times
`k^-2(12kB-gamma²)_+^(9/2)`,
whose expectation is finite. This justifies dominated convergence and the displayed A(k). Strict positivity follows from the positive-measure set B>gamma²/(12k) and positive conditional density at0.

**Domain boundary:** delta is deterministic during R-integration. Dependence on gamma,B can remain within a conditional bound; arbitrary dependence on C/R is not covered. T6 is a **fixed-k** equivalent. T5 is uniform in k>0 but is not a joint k,delta equivalent or crossover law.

The optional Hessian cubic reduction checks: for c<0 the containing union has weight14400|c|epsilon2²+576000epsilon2³; for c>=0 both elder-side failure sets lie below120epsilon2.

### Actual counterchecks and remaining work

Independent reviewer-written standard-library Fraction checks passed for the root boundary, primitives, volume specialization, leading coefficient, beta integrals and979776/1701 ledger: **exit0**, execution chunk da0da4. No author-code replay, source edits, public writes by the helper, or fanout. Diagnostics corroborate the analytic proof; they do not establish a field theorem.

This accepts **one explicit tolerance-failure component in the stated independent Gaussian reference model**. It does not establish actual-field confinement, a finite-torus transfer, total pairing-error improvement, or a persistence-density remainder. The separate near-saddle-level band remains O(delta); that limitation survives this sharper component.

**Release:** actual review pickup5962173032 is complete/released. The author's simultaneous request5962174087 to Claude has no presumed pickup or verdict; any provider-distinct review would be separately exposed. CS/QC5961790128 remains a distinct requested review, not accepted here. Claude retains its source correction/physical confinement; the suggested trap-radius task5962182923 is not an actual pickup. No merge, status promotion or custody duplication.
