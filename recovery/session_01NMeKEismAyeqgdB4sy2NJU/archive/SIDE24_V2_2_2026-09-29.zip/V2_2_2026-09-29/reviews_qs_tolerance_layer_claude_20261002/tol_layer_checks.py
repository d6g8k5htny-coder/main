"""Independent checks for (i) QS-W-R01 (fixed-R recomputation of A1 check (3)) and (ii) a bounded review of
OA-QS-TOLERANCE-LAYER-20261002-v1 (main#229 comment 5962071521), T1-T6, and the optional W3 sharpening.
Exploration outside the repository: numpy/scipy. Every quantity is recomputed from QS's scalar tolerances by brute force;
the closed forms under test are evaluated separately and compared.
"""
import numpy as np
from scipy import optimize, integrate

AS = 2 / 3 ** 1.5


def taus(c, R, psi):
    kS, kM = (psi + c) / 48, (psi - c) / 48
    tS = AS + abs(c) / (24 * np.sqrt(3) * kS) + np.abs(R) / (3456 * kS ** 1.5)
    tM = AS + abs(c) / (24 * np.sqrt(3) * kM) + np.abs(R) / (3456 * kM ** 1.5)
    return tS, tM


def fail_mass_quad(c, R, delta, n=4_000_001):
    """Brute-force weighted psi-measure of {elder side, delta >= min(mS, epsM)} at FIXED (c, R); c < 0. Midpoint rule."""
    a = abs(c)
    s = np.sqrt(1000 * delta / 27)
    Y = 3 * s / (1 - s)
    hi = a * (1 + Y) * 1.02 + 1e-12
    edges = np.linspace(a, hi, n)
    psi = 0.5 * (edges[1:] + edges[:-1]); d = edges[1] - edges[0]
    q = 4 * (psi - 2 * c) * np.sqrt(psi + c)
    tS, tM = taus(c, R, psi)
    mS = 2 / (125 * tS ** 2); eM = np.minimum(1 / (8 * tM ** 2), 1)
    ind = (np.abs(R) <= q) & (psi >= 2 * c) & (delta >= np.minimum(mS, eM))
    return np.sum((psi ** 2 - c * c) * ind) * d


def H(y):
    return y * y + y ** 3 / 3


def T1(c, R, delta):
    a = abs(c); rho = abs(R) / a ** 1.5
    s = np.sqrt(1000 * delta / 27); al = (2 - s) / s
    if rho == 0:
        u, v = 0.0, np.sqrt(3 / al)
    else:
        u = optimize.brentq(lambda x: x ** 3 + 3 * x - rho / 4, 0, max(1.0, rho))
        v0 = np.sqrt(3 / al)
        fv = lambda x: al * x ** 3 - 3 * x - rho / 4
        v = v0 if fv(v0) >= 0 else optimize.brentq(fv, v0, v0 + max(2.0, rho))
    return a ** 3 * max(H(v * v) - H(u * u), 0.0)


def W2_bound(c, delta):
    s = np.sqrt(1000 * delta / 27)
    return (1000 / 3) * delta * abs(c) ** 3 / (1 - s) ** 3


def P1(y):
    return 12 / 5 * y ** 2.5 + 10 / 7 * y ** 3.5 + 2 / 9 * y ** 4.5


def P2(y, beta):
    return 24 / 5 * y ** 2.5 + (12 - 4 * beta) * y ** 3.5 / 7 - 2 * beta / 9 * y ** 4.5


def T2(a, delta):
    s = np.sqrt(1000 * delta / 27)
    y0, Y, beta = 3 * s / (2 - s), 3 * s / (1 - s), 2 * (1 - s) / s
    return 8 * a ** 4.5 * (P1(y0) + P2(Y, beta) - P2(y0, beta))


def main():
    rng = np.random.default_rng(20261002)
    # (1) R01: fixed-R failure mass vs the W2 enclosing bound; and T1 vs brute force
    worst_ratio = 0.0; worst_rel = 0.0; n = 0
    for i in range(240):
        c = -10 ** rng.uniform(-1.5, 1.5)
        delta = 10 ** rng.uniform(-6, np.log10(27 / 4000))
        a = abs(c); s = np.sqrt(1000 * delta / 27)
        kind = i % 3
        if kind == 0:
            R = 0.0
        elif kind == 1:   # R equal to q at a random point of the failure range (the old 'equality' point)
            y = rng.uniform(0, 3 * s / (1 - s)); psi0 = a * (1 + y)
            R = 4 * (psi0 - 2 * c) * np.sqrt(psi0 + c) * rng.choice([1, -1])
        else:
            R = rng.uniform(-1, 1) * 4 * a ** 1.5 * 4 * np.sqrt(3 * s)
        F = fail_mass_quad(c, R, delta)
        F1 = T1(c, R, delta)
        B = W2_bound(c, delta)
        worst_ratio = max(worst_ratio, F / B); n += 1
        if F1 > 0:
            worst_rel = max(worst_rel, abs(F - F1) / F1)
        elif F > 1e-9 * B:
            worst_rel = max(worst_rel, 1.0)
    Ff = fail_mass_quad(-1.0, 16.0, 27 / 16000)
    print('(1) fixed-R: %d cases; max F/(W2 bound) = %.4f (< 1); max |F_quad - T1|/T1 = %.2e; falsifier c=-1,R=16,s=1/4: '
          'F_quad = %.3e, T1 = %.3e, W2 bound = %.6f (4/3)' % (n, worst_ratio, worst_rel, Ff, T1(-1.0, 16.0, 27 / 16000), W2_bound(-1, 27 / 16000)))
    # (2) T2 vs a 2-D brute-force integral (R by midpoint, psi by T1-free quadrature through F at fixed R)
    worst2 = 0.0
    for i in range(12):
        a = 10 ** rng.uniform(-0.5, 0.5); c = -a
        delta = 10 ** rng.uniform(-5, np.log10(27 / 4000))
        s = np.sqrt(1000 * delta / 27); Y = 3 * s / (1 - s)
        Rmax = 4 * a ** 1.5 * (Y + 3) * np.sqrt(Y) * 1.01
        nR = 801
        edges = np.linspace(-Rmax, Rmax, nR + 1); Rs = 0.5 * (edges[1:] + edges[:-1]); dR = edges[1] - edges[0]
        V = sum(T1(c, R, delta) for R in Rs) * dR
        worst2 = max(worst2, abs(V - T2(a, delta)) / T2(a, delta))
    s = 0.5; delta_half = 27 * s * s / 1000
    print('(2) T2 closed form vs R-integral of T1 (12 cases, 801 R-nodes): max rel. diff %.2e; at s = 1/2: T2/a^4.5 = %.10f, '
          '6336 sqrt3/35 - 736/105 = %.10f' % (worst2, T2(1.0, delta_half), 6336 * np.sqrt(3) / 35 - 736 / 105))
    # spot-check T1 itself inside the R-integral against brute force for a few R
    # (3) T3 and T4
    CV = 3456 * np.sqrt(6) * (1000 / 27) ** 1.25
    A0 = (3456 * np.sqrt(3) - 432 * np.sqrt(1.5)) / 35
    worst3 = 0.0
    for d in np.logspace(-9, np.log10(27 / 4000), 200):
        worst3 = max(worst3, T2(1.0, d) / (CV * d ** 1.25))
    lim = [T2(1.0, 27 * s * s / 1000) / s ** 2.5 for s in [1e-2, 1e-3, 1e-4, 1e-5]]
    I4 = 8 * (integrate.quad(lambda x: 6 * x ** 1.5, 0, 1.5)[0] + integrate.quad(lambda x: 12 * x ** 1.5 - 4 * x ** 2.5, 1.5, 3)[0])
    print('(3) T3: max T2/(C_V a^4.5 delta^1.25) = %.4f (<= 1); T4: T2/(a^4.5 s^2.5) at s = 1e-2..1e-5: %s; A0 = %.8f; '
          'elementary integral = %.8f' % (worst3, ', '.join('%.6f' % x for x in lim), A0, I4))
    # (4) T5 constants: E[B_+^5] (B ~ N(0,2)), E[(12kB - gamma^2)_+^(9/2)] <= 979776 k^5 (gamma ~ N(0,2))
    EB5 = integrate.quad(lambda b: b ** 5 * np.exp(-b * b / 4) / np.sqrt(4 * np.pi), 0, np.inf)[0]
    beta_int = integrate.quad(lambda t: (1 - t * t) ** 4.5, -1, 1)[0]
    worst5 = 0.0
    for k in [0.01, 0.1, 0.5, 1, 3, 10]:
        def inner(b):
            A = 12 * k * b
            return integrate.quad(lambda x: (A - x * x) ** 4.5 * np.exp(-x * x / 4) / np.sqrt(4 * np.pi), -np.sqrt(A), np.sqrt(A))[0]
        E = integrate.quad(lambda b: inner(b) * np.exp(-b * b / 4) / np.sqrt(4 * np.pi), 0, 60 / max(1, np.sqrt(k)) + 40)[0]
        worst5 = max(worst5, E / (979776 * k ** 5))
    print('(4) T5: E[B_+^5] = %.10f vs 32/sqrt(pi) = %.10f; int(1-t^2)^4.5 = %.10f vs 63 pi/256 = %.10f; '
          'max E[(12kB-g^2)_+^4.5]/(979776 k^5) over k in {0.01..10} = %.4f (<= 1); 979776/576 = %s' % (
              EB5, 32 / np.sqrt(np.pi), beta_int, 63 * np.pi / 256, worst5, 979776 / 576))
    # (5) W3 sharpening: union measure <= 14400|c|e2^2 + 576000 e2^3, exact interval arithmetic
    def wint(c, lo, hi):
        return 0.0 if hi <= lo else (hi ** 3 - lo ** 3) / 3 - c * c * (hi - lo)
    worst6 = 0.0; worst6eq = 0.0
    for i in range(200000):
        c = rng.choice([-1, 1]) * 10 ** rng.uniform(-4, 1)
        e2 = 10 ** rng.uniform(-5, np.log10(1.2))
        lo0 = max(abs(c), 2 * c)                       # typed and elder: psi > |c|, psi >= 2c
        ivs = [(lo0, 120 * e2 - c), (lo0, c + 48 * e2)]  # E2 failure psi + c < 120 e2; E3 failure psi - c <= 48 e2
        ivs = sorted((l, h) for l, h in ivs if h > l)
        meas = 0.0; cur = None
        for l, h in ivs:
            if cur is None or l > cur[1]:
                if cur: meas += wint(c, *cur)
                cur = [l, h]
            else:
                cur[1] = max(cur[1], h)
        if cur: meas += wint(c, *cur)
        bound = 14400 * abs(c) * e2 ** 2 + 576000 * e2 ** 3
        worst6 = max(worst6, meas / bound)
        if c < 0:
            worst6eq = max(worst6eq, abs(meas / bound - 1))
    print('(5) W3 with cubic coefficient 576000 (exact interval integrals, 200000 cases): max measure/bound = %.12f (<= 1); '
          'for c < 0 max |ratio - 1| = %.1e (equality)' % (worst6, worst6eq))
    # (6) T6: Q_delta(k)/delta^(5/4) -> A(k) at fixed k, by (gamma, B) quadrature with the closed form T1 integrated in R
    def F_vec(a, Rabs, s):
        rho = Rabs / a ** 1.5; al = (2 - s) / s
        x = rho / 8
        u = np.cbrt(x + np.sqrt(x * x + 1)) + np.cbrt(x - np.sqrt(x * x + 1))
        tq = rho * np.sqrt(al) / 8
        v_trig = 2 / np.sqrt(al) * np.cos(np.arccos(np.minimum(tq, 1.0)) / 3)
        D = rho ** 2 / (64 * al ** 2) - 1 / al ** 3
        v_card = np.cbrt(rho / (8 * al) + np.sqrt(np.maximum(D, 0))) + np.cbrt(rho / (8 * al) - np.sqrt(np.maximum(D, 0)))
        v = np.where(tq <= 1, v_trig, v_card)
        return a ** 3 * np.maximum(H(v * v) - H(u * u), 0.0)
    # spot-check F_vec against T1
    errF = 0.0
    for i in range(300):
        c = -10 ** rng.uniform(-1, 1); d = 10 ** rng.uniform(-6, np.log10(27 / 4000)); s_ = np.sqrt(1000 * d / 27)
        R = rng.uniform(0, 1) * 4 * abs(c) ** 1.5 * 6 * np.sqrt(6 * s_)
        f1 = T1(c, R, d); fv = F_vec(abs(c), np.array([R]), s_)[0]
        errF = max(errF, abs(f1 - fv) / max(f1, 1e-300) if f1 > 0 else abs(fv))
    k = 1.0
    g = np.linspace(-9, 9, 721); g = g[np.abs(g) > 1e-9]; dg = g[1] - g[0]
    Bv = np.linspace(0, 12, 961)[1:]; dB = Bv[1] - Bv[0]
    G, BB = np.meshgrid(g, Bv, indexing='ij')
    wgt = np.exp(-G * G / 4) / np.sqrt(4 * np.pi) * np.exp(-BB * BB / 4) / np.sqrt(4 * np.pi) * dg * dB
    cc = 1 - 12 * k * BB / G ** 2
    neg = cc < 0
    aa = np.where(neg, -cc, 1.0)
    m = 8 - 144 * k * BB / G ** 2; sig = 576 * k * k * np.sqrt(6) / np.abs(G) ** 3
    A0 = (3456 * np.sqrt(3) - 432 * np.sqrt(1.5)) / 35
    p0 = np.exp(-m * m / (2 * sig * sig)) / (sig * np.sqrt(2 * np.pi))
    Ak = A0 * (1000 / 27) ** 1.25 * np.sum(wgt * neg * G ** 6 * aa ** 4.5 * p0)
    out = []
    for d in [1e-3, 1e-4, 1e-5, 1e-6, 1e-7]:
        s_ = np.sqrt(1000 * d / 27)
        Y = 3 * s_ / (1 - s_)
        width = 4 * aa ** 1.5 * (Y + 3) * np.sqrt(Y)          # |R| support half-width
        tot = np.zeros_like(G)
        nr = 161
        for j in range(nr):
            r = (j + 0.5) / nr * width                         # midpoint in |R|, both signs
            pr = (np.exp(-(r - m) ** 2 / (2 * sig * sig)) + np.exp(-(r + m) ** 2 / (2 * sig * sig))) / (sig * np.sqrt(2 * np.pi))
            tot += F_vec(aa, r, s_) * pr * width / nr
        Q = np.sum(wgt * neg * G ** 6 * tot)
        out.append(Q / d ** 1.25)
    print('(6) T6 at k = 1: F_vec vs T1 max rel. diff %.1e; Q_delta/delta^(5/4) at delta = 1e-3..1e-7: %s; A(1) by quadrature = %.6e' % (
        errF, ', '.join('%.6e' % x for x in out), Ak))


if __name__ == '__main__':
    main()
