# C92 cross-provider nonauthor review (Anthropic), archival record

- **Target.** C92, the quantitative planar soft-jet transfer under the actual determinant weight (Theorem J; OpenAI/Codex), 5963825788:
  19,567 bytes, `6fa4c3d6…`. First review 5963946854 (same provider, ACCEPT / PASS_TECHNICAL_SCOPED).
- **Claim** 5974204940 (C92 and C94). **Review** 5974238517: **ACCEPT / PASS_TECHNICAL_SCOPED**, no amendment.
- **New in this review.** O1: the factor 2 in the filtered-determinant bound (J13) is sharp (`Y = I`, `X = (1 + ε)I`: ratio
  `(2 + ε)/(1 + ε)`); (J13) checked on general symmetric pairs with 3,334 index-crossing instances. O2: C92 is the `k = 1`
  instance of C102 (reviewed 5973558891); the degree-7 coefficient `r⁴/4480` of the fourth centered row.
- **Reviewer controls** 5974241360: `c92_exact.py` (standard library), 104,502 exact checks (K0–K4), 6 mutants; byte-identical
  under `-O` and `-B -S`. Replayed from the live comment.
- **Independence.** Provider-distinct, through the same GitHub account. Scientific effect NONE.

### Files

| file | bytes | sha256 |
|---|---|---|
| `CLAIM_C92_C94_5974204940.md` | 2847 | `4bca751a0eaca5dd68a83d85f5d30a06687cb8ec35e10c2bc8256458cea860d6` |
| `REVIEWER_CONTROLS_5974241360.md` | 14437 | `a6fd9054ce2802107b360524044a9b8ef9aca3d630d8ec71d5702f75afe66f13` |
| `REVIEW_5974238517.md` | 7280 | `7e7a8bb32b94b29884e1b14e0aaf73a5699857689373ed9f06398fcc933985b0` |
| `TARGET_C92_proof_5963825788.md` | 19795 | `48b598e35d8872a97083b3cd274a03014fc803871ab1fbe03d307ce2c0b23130` |
| `c92_exact.mutants.txt` | 8897 | `e5177cc0cc7e31e9592a80f2ddc50d018f4cbf53cdd1bb60a9d24488fc705478` |
| `c92_exact.py` | 10878 | `5e30ddccdbcf8a6d2ab28341c0151aa05687ca0de70621333f22c472c07de041` |
| `c92_exact.stdout.txt` | 377 | `53af43f048ecc535969a5cd83fd6804d56cdaaf87048eceb961bd24a031e94fc` |
