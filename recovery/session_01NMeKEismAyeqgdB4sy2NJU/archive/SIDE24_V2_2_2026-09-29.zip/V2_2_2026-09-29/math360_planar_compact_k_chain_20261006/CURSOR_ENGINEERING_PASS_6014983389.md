<!-- Math- issue/PR comment 6014983389, created 2026-10-06T11:11:28Z (updated 2026-10-06T11:11:28Z), 7021 UTF-8 bytes, SHA-256 6d90969bcbe36062d60b458ab9fafa6f4c2cd14975e38db22c77b13f8ff8b27c; copied verbatim from the GitHub API -->
**Verdict: PASS** on the engineering read of PR #360's delta at frozen head `2fb1e3d35492723f9b70eb998e9c89bf30c88512`.

Dylan Roy — delegated AI review. Performer: Cursor Cloud Agent, Grok 4.7 (`grok-4.7-high-fast`), session `bc-8a921a51-de24-46b8-bf05-bd5aa50c68b6` (xAI/Grok via Cursor; non-Claude, nonauthor). Same-account organizational-independence credit 0. Scientific effect NONE. Local interpreter: Python 3.12.3. The remote head is still `2fb1e3d35492723f9b70eb998e9c89bf30c88512`. No repository edit.

### 1. Byte identity of the stored comment records

`SOURCES.json` has **37** files with a `comment` field, not 41. The 45 stored files are those 37 comment bodies plus 8 extracted payloads (4 scripts and 4 stdouts). The README's count of 45 stored files is the count the packet itself states. I compared every comment-bearing file with `GET /repos/d6g8k5htny-coder/main/issues/comments/{id}`: the served `body` (UTF-8, no added newline) equals the file, and the pinned byte count and SHA-256 match. `created_at`, `updated_at` and `html_url` also match, including the two edited A4.3 reviews (Slice 1 `updated_at` `2026-10-06T06:26:30Z`, Slice 2 `2026-10-06T07:03:05Z`). API `user.login` is `d6g8k5htny-coder` on 35 comments and `cursor[bot]` on 6010522535 and 6011056566, which those reviews record (a user-authored comment returned 403).

### 2. The eight extracted payloads

Re-extracted from the first fence after the recorded heading, plus one newline. All eight match the stored bytes and the pinned identities:

- PD, heading `### 4. Ledger script`, ` ```python ` then ` ```text `: `PD/ledger_control.py` 3,103 B `b321e831…`, stdout 57 B `16e88fee…` (1 line).
- A4.1, the first heading `### a41_exact.py` (not the later `### a41_numeric.py`): `A4_1/author_controls.py` 17,190 B `57b44096…`, stdout 562 B `e94b0257…` (` ```text `, 9 lines).
- A4.2, `### a42_exact.py`: `A4_2/author_controls.py` 10,859 B `ea494527…`, stdout 442 B `60a3711b…` (` ```text `, 8 lines).
- A4.3, `### a43_exact.py`: `A4_3/author_controls.py` 9,853 B `a69c67ae…`, `author_controls_stdout.json` 145 B `3352a310…` (` ```json `, one line).

`a41_numeric.py` is the second ` ```python ` fence in `A4_1/AUTHOR_CONTROLS_COMMENT.md` (5,743 B, SHA-256 `83d4b06cda23d0366ce0a6631442e5dc4ea24d694b14718351dcbda9899d96c7`). It contains `mpmath`. It is not a stored path, and `replay.py` does not name it or run it.

### 3. The 34 rejection contracts

Ran every listed invocation under `python3 -B -S` and `python3 -B -O -S`. Exit codes and both stream SHA-256s match `REJECTION_CONTRACTS`. The two modes' replay records are identical (4 baselines, 25 mutants, 9 invalid invocations, and the negative-control run). Each named reason is the first failing line, and it is the check named in that controls comment's mutant list:

- PD: `RATE_THIRD` → relative error `l^(beta/3)`; `CUM_HALF` → cumulative constant `3/5`; `FRAC_ONE` → fraction error. `BOGUS` and `RATE_THIRD EXTRA` exit 2 on the unknown-label line.
- A4.1: `K2_UNIT` → W0; `LE_36` → W1; `OLD_ENDPOINT`, `P_TWO`, `W_HALF`, `ALPHA_4` → W3. `BOGUS` and `K2_UNIT EXTRA` exit 2.
- A4.2: `K2_UNIT` → B0; `DB_HALF` → B2; `PD_79`, `CUM_169`, `FRAC_109`, `LOG_ONE` → B5. `BOGUS` and `K2_UNIT EXTRA` exit 2.
- A4.3: `M1`→`Z1_lemma11_constants`, `M2`→`Z2_planar_integrals`, `M3`→`Z3_margin_totals`, `M4`→`Z4_endpoint_shell`, `M5`→`Z5_shell_sums`, `M6`→`Z6_exponent_tables`, `M7`→`Z7_pd_constants`, `M8`→`Z2_planar_integrals`, `M9`→`Z7_pd_constants`, `M10`→`Z8_k1_constants`. Each has empty stdout and stderr exactly `FAILED: <group>\n`. `--bogus`, `--mutant M11` and a bare `--mutant` exit 2 with stderr exactly `usage: a43_exact.py [--mutant M1..M10]\n`.

Negative control, both modes: on a copy, `K192 = F(96) if MUT == "M1" else F(192)` with the bare `F(192)` replaced by `F(96)` exits 1, with empty stdout and stderr exactly `FAILED: Z1_lemma11_constants\n`.

### 4. Derivation from the QS packet

Diffed `replay.py`, both tests and the workflow against #359's head `f67af7f7f5a7aff286cf49d1f49c18af979ad45c` (that PR's current head). These `replay.py` functions are byte-identical to the QS source: `check_rejection`, `rejection_inventory_failures`, `report_control`, `identity`, `interpreter_flags`, `tree_failures`, `extraction_failures`, `evidence_directory`, `save_process_evidence`, `run`, `replay_failures`. What differs is the docstring; paths and names; the contract-table comment and the table; `NEGATIVE_CONSTANT` and the negative-control block (`A4_3`, `192` → `96`, `Z1_lemma11_constants`); and the summary strings. The protocol test differs in the replay path, the inventory count 34, the A4.3 negative-control fixture, and the workflow-path assertions. The evidence test differs in the packet path and the workflow-path assertions. The workflow differs in the display name and the four paths. Action pins, Python `3.11.16`, the mode matrix, permissions and the evidence steps are unchanged.

### 5. Gates

On Python 3.12.3:

- `python3 -B -S` and `python3 -B -O -S -m unittest discover -s tests -p test_planar_compact_k_replay_protocol.py -v`: 13 tests, OK.
- the same two modes for `test_planar_compact_k_replay_evidence.py`: 13 tests, OK.
- `replay.py` in both modes, exit 0, ending `Planar compact-K chain (PD, A4.1-A4.3) incorporation replay (…): 45 stored identities, 8 extractions, 4 checker stdouts, 25 mutants, 9 invalid invocations and 2 negative controls PASS`.
- `git status --porcelain` empty afterwards.

### 6. `SOURCES.json` and the README against the records

The recorded readers, verdicts and comment ids match the stored reviews:

- PD: PASS_SCOPED_COMPOSITION, OpenAI Codex, 5973563650 (pickup 5973515589, release 5973565936); C-PD-1 accepted in 5973590979.
- A4.1 with E1: PASS_SCOPED, OpenAI Codex, 5973672811 (pickup 5973617597, release 5973677514); author acknowledgment 5974025302, no amendment.
- A4.2: slice A PASS (scoped, conditional), Grok Bot agent 15, 5975798694 (pickup 5975782576); slice B the same, agent 1, 5975812240 (pickup 5975790931), with five optional wording findings and no required amendment; slice C the same, agent 11, 5976045296 (pickup 5975788361), three optional wording items; slice D PASS_SCOPED, OpenAI Codex, 5975703487 (pickup 5975694119). The README records no required amendment and names slice C's three optional items.
- A4.3: Slice 1 PASS, Cursor `bc-ac3b4ec5`, 6010522535; Slice 2 PASS, Cursor `bc-896b2b0f`, 6011056566; author round note 6011224732, read-complete, no amendment.

Conditionality matches the README. The exclusions match, including that `a41_numeric.py` stays inside the controls comment and is not extracted or run. Organizational independence is recorded as 0 on each object.

**Not checked.** The mathematics of PD, A4.1, A4.2 and A4.3. The workflow's Python 3.11.16 interpreter (this machine has 3.12.3 only); the frozen fingerprints matched on 3.12.3 in both modes. No scientific verdict.

No AMEND. The head was not changed.
