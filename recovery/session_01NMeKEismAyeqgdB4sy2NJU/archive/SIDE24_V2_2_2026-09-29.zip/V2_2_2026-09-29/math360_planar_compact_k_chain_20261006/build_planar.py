"""Build the Math- packet frontiers/planar_compact_k_chain_20261006 (worktree /home/claude/wt-planar, off main).

Stores the exact main#229 comment bodies of Corollary PD and QS addenda A4.1, A4.2 and A4.3, extracts their four control
scripts with their stdouts by the stated fence rules, computes the exact rejection fingerprints of every mutant and invalid
invocation under both interpreter modes (they must agree), and writes SOURCES.json, replay.py (adapted from the QS d = 3
packet's hardened replay.py), the two test files, the workflow and README.md.
"""
import hashlib
import json
import os
import pathlib
import re
import subprocess
import sys
import urllib.request

WT = pathlib.Path('/home/claude/wt-planar')
REL = 'frontiers/planar_compact_k_chain_20261006'
ROOT = WT / REL
QS_WT = pathlib.Path('/home/claude/wt-a38')     # #359 head f67af7f7: the QS packet's replay.py, tests and workflow
QS_REL = 'frontiers/qs_d3_soft_layer_chain_20261005'
SP = pathlib.Path('/tmp/claude-0/-home-claude/b41b316f-232c-5cf7-a0ee-80f0de603a6f/scratchpad/planar')
TOK = os.environ['GITHUB_TOKEN']
CLAIM = int(sys.argv[1])


def api(url):
    req = urllib.request.Request(url, headers={'Authorization': 'Bearer ' + TOK, 'Accept': 'application/vnd.github+json', 'User-Agent': 'x'})
    return json.load(urllib.request.urlopen(req))


def ident(data):
    return len(data), hashlib.sha256(data).hexdigest()


stored = {}


def comment(tag, cid, path, role, expect=None):
    c = api('https://api.github.com/repos/d6g8k5htny-coder/main/issues/comments/%d' % cid)
    assert c['issue_url'].endswith('/issues/229'), (cid, c['issue_url'])
    body = c['body'].encode('utf-8')
    p = ROOT / path
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(body)
    n, h = ident(body)
    if expect:
        assert h.startswith(expect), (path, h)
    stored.setdefault(tag, []).append({'path': path, 'role': role, 'comment': str(cid),
                                       'url': 'https://github.com/d6g8k5htny-coder/main/issues/229#issuecomment-%d' % cid,
                                       'created_at': c['created_at'], 'updated_at': c['updated_at'], 'bytes': n, 'sha256': h})
    print('  stored', path, n, h[:12])


def extract(tag, source, heading, script_path, stdout_path, exp_script, exp_stdout, fence):
    body = (ROOT / source).read_text(encoding='utf-8')
    assert body.count(heading) == 1, heading
    section = body[body.index(heading):]
    m1 = re.search(r'```python\n(.*?)\n```\n', section, re.S)
    m2 = re.search(r'```%s\n(.*?)\n```\n' % fence, section[m1.end():], re.S)
    code = (m1.group(1) + '\n').encode('utf-8')
    out = (m2.group(1) + '\n').encode('utf-8')
    what = 'controls comment' if 'CONTROLS' in source else 'note'
    for path, data, role, exp in ((script_path, code, 'control script, extracted verbatim from the stored %s %s (heading: %s)' % (what, source, heading), exp_script),
                                  (stdout_path, out, 'published stdout of %s, extracted verbatim from %s (```%s fence)' % (script_path, source, fence), exp_stdout)):
        (ROOT / path).write_bytes(data)
        n, h = ident(data)
        assert h.startswith(exp), (path, h)
        stored[tag].append({'path': path, 'role': role, 'extracted_from': source, 'heading': heading, 'bytes': n, 'sha256': h})
        print('  extracted', path, n, h[:12])


# ------------------------------------------------------------------------------------------------ Corollary PD
T = 'PD'
comment(T, 5973366326, 'PD/CLAIM.md', 'author work claim (Corollary PD)')
comment(T, 5973476391, 'PD/PROOF.md', 'frozen note (Corollary PD); section 4 contains the ledger script pd_ledger.py and its stdout', '7da0f672')
extract(T, 'PD/PROOF.md', '### 4. Ledger script', 'PD/ledger_control.py', 'PD/ledger_control_stdout.txt', 'b321e831', '16e88fee', 'text')
comment(T, 5973480217, 'PD/DELIVERY_RELEASE.md', 'author delivery note; claim 5973366326 released')
comment(T, 5973515589, 'PD/REVIEW_PICKUP.md', 'review pickup: OpenAI Codex (UI/reader Work Mode thread /root), steps 1-4 and their source interfaces')
comment(T, 5973563650, 'PD/REVIEW.md', 'nonauthor review (steps 1-4 and their public source interfaces): PASS_SCOPED_COMPOSITION, OpenAI Codex; clarification C-PD-1')
comment(T, 5973565936, 'PD/REVIEW_RELEASE.md', 'review release (OpenAI Codex)')
comment(T, 5973590979, 'PD/AUTHOR_ACK.md', 'author acknowledgment of the review; clarification C-PD-1 accepted')

# ------------------------------------------------------------------------------------------------ A4.1
T = 'A4.1'
comment(T, 5972759905, 'A4_1/SUPPORT_NOTE.md', 'support note from OpenAI/Codex (root and next_math_triage) before the claim: a feasibility route through C103\'s inputs; author-side support, not a claim or a review')
comment(T, 5972949776, 'A4_1/CLAIM.md', 'author work claim (A4.1)')
comment(T, 5973261552, 'A4_1/PROOF.md', 'frozen note (QS addendum A4.1)', '474a6e0d')
comment(T, 5973265245, 'A4_1/AUTHOR_CONTROLS_COMMENT.md', 'author controls comment (contains a41_exact.py and its stdout; its second script, the mpmath exploration a41_numeric.py, is not extracted or replayed)', '1f907f1c')
extract(T, 'A4_1/AUTHOR_CONTROLS_COMMENT.md', '### a41_exact.py', 'A4_1/author_controls.py', 'A4_1/author_controls_stdout.txt', '57b44096', 'e94b0257', 'text')
comment(T, 5973287146, 'A4_1/DELIVERY_RELEASE.md', 'author delivery note; claim 5972949776 released')
comment(T, 5973478388, 'A4_1/ERRATUM_E1.md', 'author erratum E1 (C102 section 8\'s premise is one event theorem, which C103 supplies; A4.1 section 5 third remark and section 7 fifth bullet)')
comment(T, 5973617597, 'A4_1/REVIEW_PICKUP.md', 'review pickup: OpenAI Codex (Work Mode /root)')
comment(T, 5973672811, 'A4_1/REVIEW.md', 'nonauthor review of A4.1 with erratum E1: PASS_SCOPED, OpenAI Codex')
comment(T, 5973677514, 'A4_1/REVIEW_RELEASE.md', 'review release (OpenAI Codex)')
comment(T, 5974025302, 'A4_1/AUTHOR_ACK.md', 'author acknowledgment of the review (PASS_SCOPED); no amendment')

# ------------------------------------------------------------------------------------------------ A4.2
T = 'A4.2'
comment(T, 5974351360, 'A4_2/CLAIM.md', 'author work claim (A4.2)')
comment(T, 5974565257, 'A4_2/PROOF.md', 'frozen note (QS addendum A4.2)', '2dd72e3f')
comment(T, 5974567585, 'A4_2/AUTHOR_CONTROLS_COMMENT.md', 'author controls comment (contains a42_exact.py and its stdout)', '07063ade')
extract(T, 'A4_2/AUTHOR_CONTROLS_COMMENT.md', '### a42_exact.py', 'A4_2/author_controls.py', 'A4_2/author_controls_stdout.txt', 'ea494527', '60a3711b', 'text')
comment(T, 5975600099, 'A4_2/READ_REQUEST_IN_NOTE_BL_ACK.md', 'author comment, mainly the acknowledgment of Note BL\'s reviews, whose sections 3-4 request the A4.2 slice reads (answered by slices A-C)')
comment(T, 5975694119, 'A4_2/REVIEW_SLICE_D_PICKUP.md', 'slice D (Corollary PD_ER, section 3) pickup: OpenAI Codex')
comment(T, 5975703487, 'A4_2/REVIEW_SLICE_D.md', 'slice D (Corollary PD_ER, section 3): PASS_SCOPED, conditional; no required amendment; OpenAI Codex')
comment(T, 5975782576, 'A4_2/REVIEW_SLICE_A_PICKUP.md', 'slice A (Lemmas JB_K and DB_K) pickup: Grok Bot agent 15')
comment(T, 5975788361, 'A4_2/REVIEW_SLICE_C_PICKUP.md', 'slice C (the assembly of Theorem ER_K) pickup: Grok Bot agent 11')
comment(T, 5975790931, 'A4_2/REVIEW_SLICE_B_PICKUP.md', 'slice B (Lemmas ES_K and FT_K) pickup: Grok Bot agent 1')
comment(T, 5975798694, 'A4_2/REVIEW_SLICE_A.md', 'slice A (Lemmas JB_K and DB_K against C103\'s interfaces): PASS (scoped, conditional); Grok Bot agent 15')
comment(T, 5975812240, 'A4_2/REVIEW_SLICE_B.md', 'slice B (Lemmas ES_K and FT_K): PASS (scoped, conditional); Grok Bot agent 1')
comment(T, 5976045296, 'A4_2/REVIEW_SLICE_C.md', 'slice C (the assembly of Theorem ER_K, section 2): PASS (scoped, conditional), three optional wording items; Grok Bot agent 11')

# ------------------------------------------------------------------------------------------------ A4.3
T = 'A4.3'
comment(T, 6010186331, 'A4_3/CLAIM.md', 'author work claim (A4.3)')
comment(T, 6010510789, 'A4_3/PROOF.md', 'frozen note (QS addendum A4.3)', '271fbb20')
comment(T, 6010511425, 'A4_3/AUTHOR_CONTROLS_COMMENT.md', 'author controls comment (contains a43_exact.py and its stdout)', 'dc1fe984')
extract(T, 'A4_3/AUTHOR_CONTROLS_COMMENT.md', '### a43_exact.py', 'A4_3/author_controls.py', 'A4_3/author_controls_stdout.json', 'a69c67ae', '3352a310', 'json')
comment(T, 6010521368, 'A4_3/READ_REQUESTS.md', 'author read requests (two slices; Slice 1 summons of one Cursor agent, D2 of 6002718035); the same comment is A3.11\'s author round note')
comment(T, 6010522535, 'A4_3/REVIEW_SLICE1.md', 'Slice 1 (sections 0-3: the planar shells and the fixed layer at compact K; controls Z1-Z5): PASS, Cursor agent bc-ac3b4ec5 (xAI Grok 4.7); pickup and verdict in one comment')
comment(T, 6011055303, 'A4_3/REVIEW_SLICE2_SUMMONS.md', 'Slice 2 summons (one Cursor agent, after the OpenAI window passed)')
comment(T, 6011056566, 'A4_3/REVIEW_SLICE2.md', 'Slice 2 (sections 4-5 with 6 and 8 for overclaim; controls Z6-Z8): PASS, Cursor agent bc-896b2b0f (xAI Grok 4.7); pickup and verdict in one comment')
comment(T, 6011224732, 'A4_3/AUTHOR_ROUND_NOTE.md', 'author round note (read-complete in two slices, no amendment); it also requests the Math-#340 integrator')

# ------------------------------------------------------------------------------------------------ fingerprints
specs = [
    ('PD', 'pd_ledger.py (Corollary PD section 4; stdout in a ```text fence)', 'PD/ledger_control.py', 'PD/ledger_control_stdout.txt',
     [['RATE_THIRD'], ['CUM_HALF'], ['FRAC_ONE']], [['BOGUS'], ['RATE_THIRD', 'EXTRA']], 'stdout'),
    ('A4.1', 'a41_exact.py (stdout in a ```text fence)', 'A4_1/author_controls.py', 'A4_1/author_controls_stdout.txt',
     [['K2_UNIT'], ['LE_36'], ['OLD_ENDPOINT'], ['P_TWO'], ['W_HALF'], ['ALPHA_4']], [['BOGUS'], ['K2_UNIT', 'EXTRA']], 'stdout'),
    ('A4.2', 'a42_exact.py (stdout in a ```text fence)', 'A4_2/author_controls.py', 'A4_2/author_controls_stdout.txt',
     [['K2_UNIT'], ['DB_HALF'], ['PD_79'], ['CUM_169'], ['FRAC_109'], ['LOG_ONE']], [['BOGUS'], ['K2_UNIT', 'EXTRA']], 'stdout'),
    ('A4.3', 'a43_exact.py', 'A4_3/author_controls.py', 'A4_3/author_controls_stdout.json',
     [['--mutant', 'M%d' % j] for j in range(1, 11)], [['--bogus'], ['--mutant', 'M11'], ['--mutant']], 'stderr'),
]
contracts = {}
for tag, name, script_rel, stdout_rel, mutants, invalid, stream in specs:
    script = ROOT / script_rel
    for args, code_expected in [(m, 1) for m in mutants] + [(i, 2) for i in invalid]:
        res = []
        for flags in (['-B', '-S'], ['-B', '-O', '-S']):
            proc = subprocess.run([sys.executable, *flags, str(script), *args], capture_output=True, cwd=str(script.parent), timeout=600)
            res.append((proc.returncode, hashlib.sha256(proc.stdout).hexdigest(), hashlib.sha256(proc.stderr).hexdigest(), proc.stdout.decode(), proc.stderr.decode()))
        assert res[0][:3] == res[1][:3], (script_rel, args)
        code, so, se, out, err = res[0]
        assert code == code_expected, (script_rel, args, code, out[:300], err[:300])
        if stream == 'stderr':
            assert out == '', (script_rel, args, out)
            reason = err.splitlines()[0]
            assert reason.startswith('FAILED: ' if code == 1 else 'usage:'), err
        else:
            assert err == '', (script_rel, args, err)
            if code == 1:
                fails = [ln for ln in out.splitlines() if 'FAIL' in ln and 'PASS' not in ln]
                assert fails, out
                reason = fails[0].strip()
                assert ('mutant: %s' % args[0]) in out, out[-300:]
            else:
                reason = out.splitlines()[0]
                assert reason.startswith('unknown mutant label'), out
        contracts[(script_rel, tuple(args))] = (code, so, se, reason)
        print('  contract', script_rel, args, code, so[:8], se[:8], reason[:80])
    for flags in (['-B', '-S'], ['-B', '-O', '-S']):
        proc = subprocess.run([sys.executable, *flags, str(script)], capture_output=True, cwd=str(script.parent), timeout=600)
        assert proc.returncode == 0 and proc.stderr == b'' and proc.stdout == (ROOT / stdout_rel).read_bytes(), (script_rel, flags)
    print('  baseline ok in both modes:', script_rel)
assert len(contracts) == 34, len(contracts)
# the negative control: A4.3's Lemma 1.1 constant 192 replaced by 96 with MUT = None
src = (ROOT / 'A4_3/author_controls.py').read_text(encoding='utf-8')
old = 'K192 = F(96) if MUT == "M1" else F(192)'
assert src.count(old) == 1
tmp = SP / 'neg_a43.py'
tmp.write_text(src.replace(old, 'K192 = F(96) if MUT == "M1" else F(96)'), encoding='utf-8')
neg = []
for flags in (['-B', '-S'], ['-B', '-O', '-S']):
    proc = subprocess.run([sys.executable, *flags, str(tmp)], capture_output=True, timeout=600)
    neg.append((proc.returncode, proc.stdout, proc.stderr))
assert neg[0] == neg[1] and neg[0] == (1, b'', b'FAILED: Z1_lemma11_constants\n'), neg
print('  negative control fails at Z1 in both modes')

# ------------------------------------------------------------------------------------------------ SOURCES.json
RB = 'https://github.com/d6g8k5htny-coder/main/issues/229#issuecomment-'
author = 'Anthropic Claude (session_01NMeKEismAyeqgdB4sy2NJU), for Dylan Roy (delegated AI work)'
objects = [
    {'tag': 'PD', 'directory': 'PD/', 'object': 'CL-PLANAR-REJECTED-LIFETIME-RATE-20261003-v1',
     'title': 'Corollary PD: the planar compact-window rejected-candidate lifetime density with a rate, nu_rej^{B,K}(l) = C_fail^{B,K} l^(2/3) + O(l^(3/4))',
     'author': author,
     'kind': 'Corollary PD (o)-(v): the planar rates of C101/C103 (and A4.1 for (v)) composed with [P] sections 10-12\'s radial ledger along #175 section 7\'s identity; the ledger script checks the exponent and constant arithmetic only',
     'nonauthor_reads_as_recorded': ['steps 1-4 and their public source interfaces: OpenAI Codex (UI/reader Work Mode thread /root), PASS_SCOPED_COMPOSITION, 5973563650 (pickup 5973515589, release 5973565936); clarification C-PD-1, accepted by the author in 5973590979'],
     'conditional_on': 'the cited planar rates (C101, C103; A4.1 for (v)) and [P], #175 section 7 at their stated scopes',
     'organizational_independence': 0, 'stored': stored['PD'],
     'replays': [{'name': specs[0][1], 'script': specs[0][2], 'stdout': specs[0][3], 'args': [], 'mutants': specs[0][4], 'invalid': specs[0][5]}]},
    {'tag': 'A4.1', 'directory': 'A4_1/', 'object': 'CL-QS-A4-1-COMPACT-K-PLANAR-RATE-20261003-v1',
     'title': "QS addendum A4.1: A4's planar rate made uniform over a compact positive gap interval - every beta < 2/3 in C103's setting",
     'author': author,
     'kind': 'Lemma LE_K and Corollary LE_K, Lemmas B-prime_K and Band_K, Theorem QFE-prime_K (growing layer, compact K) and the fixed-Lambda sector errors at compact K; read with erratum E1',
     'nonauthor_reads_as_recorded': ['A4.1 with erratum E1: OpenAI Codex (Work Mode /root), PASS_SCOPED, 5973672811 (pickup 5973617597, release 5973677514); author acknowledgment 5974025302, no amendment'],
     'conditional_on': 'C103 (and through it C101, C102) and A4 at their reviewed scopes',
     'organizational_independence': 0, 'stored': stored['A4.1'],
     'replays': [{'name': specs[1][1], 'script': specs[1][2], 'stdout': specs[1][3], 'args': [], 'mutants': specs[1][4], 'invalid': specs[1][5]}]},
    {'tag': 'A4.2', 'directory': 'A4_2/', 'object': 'CL-QS-A4-2-COMPACT-K-ENDPOINT-RATE-20261003-v1',
     'title': "QS addendum A4.2: C124's planar endpoint rate made uniform over a compact positive gap interval, and Corollary PD at the endpoint (nu_rej = C_fail l^(2/3) + O(l^(8/9) log(1/l)^(8/3)))",
     'author': author,
     'kind': "C124's Lemmas JB, DB, ES, FT re-proved on C103's interfaces (JB_K, DB_K, ES_K, FT_K), Theorem ER_K (the endpoint at compact K) and Corollary PD_ER",
     'nonauthor_reads_as_recorded': [
         'slice A (Lemmas JB_K, DB_K): Grok Bot agent 15, PASS (scoped, conditional), 5975798694 (pickup 5975782576)',
         'slice B (Lemmas ES_K, FT_K): Grok Bot agent 1, PASS (scoped, conditional), 5975812240 (pickup 5975790931)',
         'slice C (the assembly of Theorem ER_K): Grok Bot agent 11, PASS (scoped, conditional) with three optional wording items, 5976045296 (pickup 5975788361)',
         'slice D (Corollary PD_ER): OpenAI Codex, PASS_SCOPED, conditional, 5975703487 (pickup 5975694119)',
     ],
     'conditional_on': 'C103, C124, C82 and A4.1 at their reviewed scopes; Corollary PD_ER also on Corollary PD',
     'organizational_independence': 0, 'stored': stored['A4.2'],
     'replays': [{'name': specs[2][1], 'script': specs[2][2], 'stdout': specs[2][3], 'args': [], 'mutants': specs[2][4], 'invalid': specs[2][5]}]},
    {'tag': 'A4.3', 'directory': 'A4_3/', 'object': 'CL-QS-A4-3-PLANAR-DYADIC-WINDOWS-20261006-v1',
     'title': 'QS addendum A4.3: the planar decision on dyadic windows at compact K - sector errors O(r^4 log(1/r)), the failure-measure rate r^beta for every beta < 1, endpoint O(r^4 log(1/r)^4), and nu_rej = C_fail l^(2/3) + O(l log(1/l)^4)',
     'author': author,
     'kind': "A3.11's dyadic-window decision transported to C103's compact-K planar chain: Lemmas 1.1-1.4 and 2.1-2.2, Theorem SE-second_K, Proposition 4.1, Theorems QFE-second_K and ER-prime_K, Corollary PD_ER-prime, Remark 4's k = 1 constants",
     'nonauthor_reads_as_recorded': [
         'Slice 1 (sections 0-3; Z1-Z5): Cursor agent bc-ac3b4ec5 (xAI Grok 4.7; non-Claude, nonauthor), PASS, 6010522535',
         'Slice 2 (sections 4-5, with 6 and 8 for overclaim; Z6-Z8): Cursor agent bc-896b2b0f (xAI Grok 4.7), PASS, 6011056566',
         'author round note 6011224732: read-complete, no amendment; the note body is frozen as posted',
     ],
     'conditional_on': 'C103, A4.1 and A4.2 at their reviewed scopes, and the read-complete A3.11 for the shell bookkeeping (QS d = 3 packet)',
     'organizational_independence': 0, 'stored': stored['A4.3'],
     'replays': [{'name': specs[3][1], 'script': specs[3][2], 'stdout': specs[3][3], 'args': [], 'mutants': specs[3][4], 'invalid': specs[3][5]}]},
]
manifest = {
    'schema': 2,
    'object': 'PLANAR-COMPACT-K-CHAIN-PD-A4_1-A4_3-INCORPORATION-20261006-v1',
    'kind': 'additive incorporation of public native note, review and checker records; no new mathematics; no status change',
    'scientific_effect': 'NONE',
    'incorporated_by': {'performer': 'Anthropic Claude', 'session': 'https://claude.ai/code/session_01NMeKEismAyeqgdB4sy2NJU',
                        'attribution': 'Dylan Roy - delegated AI work', 'claim': RB + str(CLAIM),
                        'note': 'the incorporator is also the author of Corollary PD and A4.1-A4.3 (custody only; no proof byte is changed)'},
    'source_issue': 'https://github.com/d6g8k5htny-coder/main/issues/229',
    'extraction_rule': ('the rule each controls comment states (that of main#229 comment 5971055189): a control script is the exact text between '
                        'the first ```python fence after its heading and the next ``` line, plus a final newline; its expected stdout is the text '
                        'in the following fence, plus one newline - a ```text fence for Corollary PD (inside the note, heading "### 4. Ledger '
                        'script"), A4.1 and A4.2, and the single JSON line of a ```json fence for A4.3; the fence language follows the stored '
                        'stdout\'s suffix (.txt for ```text, .json for ```json)'),
    'related_packets': {
        'frontiers/planar_soft_layer_chain_20261003/': 'C91-C103, C124, C127: the planar chain these addenda consume',
        'frontiers/planar_rejected_endpoint_margin_20261003/': 'A4, which A4.1 makes uniform over compact K',
        'frontiers/qs_d3_soft_layer_chain_20261005/': 'the QS d = 3 chain; A3.11 there is the source of A4.3\'s shell bookkeeping',
    },
    'excluded': {
        'routing comments': 'Chief-of-Staff routing, roll-ups and acknowledgments are not stored; each pickup and verdict of record is',
        'clean-context referee reports': 'same-provider, same-session referee reports and exploration scripts (not review evidence) are kept in the project archive, not here',
        'a41_numeric.py': 'the 50-digit mpmath exploration inside A4_1/AUTHOR_CONTROLS_COMMENT.md is stored there verbatim but not extracted or replayed (it is not standard-library code)',
    },
    'objects': objects,
}
(ROOT / 'SOURCES.json').write_text(json.dumps(manifest, indent=1, ensure_ascii=False) + '\n', encoding='utf-8')
n_files = sum(len(o['stored']) for o in objects)
n_mut = sum(len(r['mutants']) for o in objects for r in o['replays'])
n_inv = sum(len(r['invalid']) for o in objects for r in o['replays'])
print('  SOURCES.json: %d objects, %d files, %d mutants, %d invalid' % (len(objects), n_files, n_mut, n_inv))
assert (n_mut, n_inv) == (25, 9)

# ------------------------------------------------------------------------------------------------ replay.py
rp = (QS_WT / QS_REL / 'replay.py').read_text(encoding='utf-8')


def rep(old, new):
    global rp
    assert rp.count(old) == 1, (rp.count(old), old[:80])
    rp = rp.replace(old, new)


rep('"""Verify the stored QS A3-A3.11 records and replay their published author controls (standard library only).',
    '"""Verify the stored planar compact-K chain records (Corollary PD, QS addenda A4.1-A4.3) and replay their published author\ncontrols (standard library only).')
rep("  - an exact copy of a public comment body on main#229 (a note, claim, controls comment, review, readback,\n    erratum, successor text or author response);\n"
    "  - a control script or its stdout, extracted verbatim from a stored controls comment by the extraction rule that\n"
    "    comment states (the rule of main#229 comment 5971055189); A3.10's ledger script and its stdout are extracted the\n"
    "    same way from the stored note itself (its section 4), the stdout from a ```text fence.",
    "  - an exact copy of a public comment body on main#229 (a note, claim, controls comment, review, pickup, release,\n    erratum, support note or author response);\n"
    "  - a control script or its stdout, extracted verbatim from a stored controls comment by the extraction rule that\n"
    "    comment states (the rule of main#229 comment 5971055189); Corollary PD's ledger script and its stdout are extracted\n"
    "    the same way from the stored note itself (its section 4). The stdouts of PD, A4.1 and A4.2 are ```text fences.")
rep("     - a one-byte change to a stored note (A3_6/PROOF.md);\n     - a control script with one changed constant (A3.6's hard-gap integral coefficient 5/4 replaced by 1/4).",
    "     - a one-byte change to a stored note (A4_3/PROOF.md);\n     - a control script with one changed constant (A4.3's Lemma 1.1 constant 192 replaced by 96).")
rep("Usage: python3 -B -S frontiers/qs_d3_soft_layer_chain_20261005/replay.py   (exit 0 iff every check passes)",
    "Usage: python3 -B -S frontiers/planar_compact_k_chain_20261006/replay.py   (exit 0 iff every check passes)")
start = rp.index('# Exact rejection fingerprints from the UNCHANGED source packet')
end = rp.index("# Replacing A3.6's 5/4 by 1/4 with MUT=None omits the usual mutant-description line.")
lines = []
for (path, args), (code, so, se, reason) in contracts.items():
    lines.append("    (%r, %r):\n        (%d, %r, %r, %r)," % (path, args, code, so, se, reason))
block = ("# Exact rejection fingerprints of the four extracted author controls (pd_ledger.py inside Corollary PD 5973476391,\n"
         "# a41_exact.py from 5973265245, a42_exact.py from 5974567585, a43_exact.py from 6010511425), computed under both\n"
         "# interpreter modes at incorporation and found identical.\n"
         "# Each key is (script path, complete argv tail); each value is (exit, stdout SHA256,\n"
         "# stderr SHA256, readable reason). References are frozen independently of this run.\n"
         "# All 25 mutants and 9 invalid invocations were executed and their named reasons\n"
         "# checked against their source. Different checkers intentionally use different\n"
         "# streams/formats. Exact fingerprints enforce those full contracts, including\n"
         "# JSON structure/types, labels, counts, usage text, and empty/nonempty streams.\n"
         "# No current failing output, generic exit code or broad regex creates a reference.\n"
         "# Any source/runtime output drift fails closed and requires a reviewed amendment.\n"
         "REJECTION_CONTRACTS = {\n" + "\n".join(lines) + "\n}\n\n")
rp = rp[:start] + block + rp[end:]
rep("# Replacing A3.6's 5/4 by 1/4 with MUT=None omits the usual mutant-description line.\n# This separately executed altered-source control must fail specifically at X9.\n"
    "NEGATIVE_HARDGAP = (1, hashlib.sha256(b'').hexdigest(),\n                    hashlib.sha256(b'FAILED: X9_hardgap\\n').hexdigest(), 'X9_hardgap')",
    "# Replacing A4.3's Lemma 1.1 constant 192 by 96 with MUT=None must fail specifically at Z1, on stderr alone.\n"
    "NEGATIVE_CONSTANT = (1, hashlib.sha256(b'').hexdigest(),\n                     hashlib.sha256(b'FAILED: Z1_lemma11_constants\\n').hexdigest(), 'Z1_lemma11_constants')")
rep("        target = copy / 'A3_6' / 'PROOF.md'", "        target = copy / 'A4_3' / 'PROOF.md'")
rep("        if 'identity mismatch: A3_6/PROOF.md' not in tree_failures(copy, manifest):\n            failures.append('negative control: a one-byte change to A3_6/PROOF.md was not detected')\n        script = copy / 'A3_6' / 'author_controls.py'",
    "        if 'identity mismatch: A4_3/PROOF.md' not in tree_failures(copy, manifest):\n            failures.append('negative control: a one-byte change to A4_3/PROOF.md was not detected')\n        script = copy / 'A4_3' / 'author_controls.py'")
rep("        old = 'coef = F(1, 4) if MUT == \"M5\" else F(5, 4)'\n        if text.count(old) != 1:\n            failures.append('negative control: the hard-gap coefficient line was not found exactly once')\n        else:\n            script.write_text(text.replace(old, 'coef = F(1, 4) if MUT == \"M5\" else F(1, 4)'), encoding='utf-8')\n            result = run(script)\n            mismatches = check_rejection(result, NEGATIVE_HARDGAP)\n            failures.extend('negative control: changed hard-gap constant: ' + why for why in mismatches)\n            if not mismatches:\n                report_control('A3_6/author_controls.py', [], result, 'changed 5/4 to 1/4: X9_hardgap')",
    "        old = 'K192 = F(96) if MUT == \"M1\" else F(192)'\n        if text.count(old) != 1:\n            failures.append('negative control: the Lemma 1.1 constant line was not found exactly once')\n        else:\n            script.write_text(text.replace(old, 'K192 = F(96) if MUT == \"M1\" else F(96)'), encoding='utf-8')\n            result = run(script)\n            mismatches = check_rejection(result, NEGATIVE_CONSTANT)\n            failures.extend('negative control: changed Lemma 1.1 constant: ' + why for why in mismatches)\n            if not mismatches:\n                report_control('A4_3/author_controls.py', [], result, 'changed 192 to 96: Z1_lemma11_constants')")
rep("print('QS d = 3 chain (A3-A3.11) incorporation replay (%s): %d failure(s)' % (mode, len(failures)))",
    "print('Planar compact-K chain (PD, A4.1-A4.3) incorporation replay (%s): %d failure(s)' % (mode, len(failures)))")
rep("print('QS d = 3 chain (A3-A3.11) incorporation replay (%s): %d stored identities, %d extractions, %d checker stdouts, '",
    "print('Planar compact-K chain (PD, A4.1-A4.3) incorporation replay (%s): %d stored identities, %d extractions, %d checker stdouts, '")
assert 'A3_' not in rp and 'A3-A3' not in rp and 'QS d = 3' not in rp and 'qs_d3' not in rp, [ln for ln in rp.splitlines() if 'A3_' in ln or 'qs_d3' in ln][:5]
(ROOT / 'replay.py').write_text(rp, encoding='utf-8')
print('  replay.py written', len(rp.encode()))
json.dump({'%s %s' % k: v for k, v in contracts.items()}, open(SP / 'planar_contracts.json', 'w'), indent=1)

# ------------------------------------------------------------------------------------------------ tests and workflow
subs = [('frontiers/qs_d3_soft_layer_chain_20261005', REL),
        ('test_qs_d3_replay_protocol.py', 'test_planar_compact_k_replay_protocol.py'),
        ('test_qs_d3_replay_evidence.py', 'test_planar_compact_k_replay_evidence.py'),
        ('qs-d3-soft-layer-chain.yml', 'planar-compact-k-chain.yml')]
t = (QS_WT / 'tests/test_qs_d3_replay_protocol.py').read_text(encoding='utf-8')
for a, b in subs:
    t = t.replace(a, b)
old = "        self.assertEqual(len(listed), 118)  # A3-A3.6: 48 mutants + 14 invalid; A3.7: 17 + 3; A3.8: 13 + 3; A3.10: 4 + 1; A3.11: 12 + 3"
assert t.count(old) == 1
t = t.replace(old, "        self.assertEqual(len(listed), 34)   # PD: 3 mutants + 2 invalid; A4.1: 6 + 2; A4.2: 6 + 2; A4.3: 10 + 3")
old = ("    def test_changed_constant_crash_is_rejected(self):\n        with tempfile.TemporaryDirectory() as tmp:\n            root = Path(tmp); (root/'A3_6').mkdir()\n"
       "            proof = b'x'*150\n            (root/'A3_6/PROOF.md').write_bytes(proof)\n            script = ('from fractions import Fraction as F\\nMUT=None\\n'\n"
       "                      'coef = F(1, 4) if MUT == \"M5\" else F(5, 4)\\n'\n                      'if coef==F(1,4): raise RuntimeError(\"synthetic crash\")\\n'\n"
       "                      'print(\"ok\")\\n')\n            (root/'A3_6/author_controls.py').write_text(script)\n            (root/'A3_6/author_controls_stdout.json').write_bytes(b'ok\\n')\n"
       "            manifest = {'objects': [{'tag':'A3.6','replays':[], 'stored':[\n                {'path':'A3_6/PROOF.md','bytes':len(proof),'sha256':hashlib.sha256(proof).hexdigest()}]}]}")
assert t.count(old) == 1, 'negative-control test block'
t = t.replace(old,
       "    def test_changed_constant_crash_is_rejected(self):\n        with tempfile.TemporaryDirectory() as tmp:\n            root = Path(tmp); (root/'A4_3').mkdir()\n"
       "            proof = b'x'*150\n            (root/'A4_3/PROOF.md').write_bytes(proof)\n            script = ('from fractions import Fraction as F\\nMUT=None\\n'\n"
       "                      'K192 = F(96) if MUT == \"M1\" else F(192)\\n'\n                      'if K192==F(96): raise RuntimeError(\"synthetic crash\")\\n'\n"
       "                      'print(\"ok\")\\n')\n            (root/'A4_3/author_controls.py').write_text(script)\n            (root/'A4_3/author_controls_stdout.json').write_bytes(b'ok\\n')\n"
       "            manifest = {'objects': [{'tag':'A4.3','replays':[], 'stored':[\n                {'path':'A4_3/PROOF.md','bytes':len(proof),'sha256':hashlib.sha256(proof).hexdigest()}]}]}")
assert 'qs_d3' not in t and 'A3_6' not in t, [ln for ln in t.splitlines() if 'qs_d3' in ln or 'A3_6' in ln][:5]
(WT / 'tests/test_planar_compact_k_replay_protocol.py').write_text(t, encoding='utf-8')
e = (QS_WT / 'tests/test_qs_d3_replay_evidence.py').read_text(encoding='utf-8')
for a, b in subs:
    e = e.replace(a, b)
assert 'qs_d3' not in e and 'qs-d3' not in e, [ln for ln in e.splitlines() if 'qs_d3' in ln or 'qs-d3' in ln][:5]
(WT / 'tests/test_planar_compact_k_replay_evidence.py').write_text(e, encoding='utf-8')
w = (QS_WT / '.github/workflows/qs-d3-soft-layer-chain.yml').read_text(encoding='utf-8')
for a, b in subs:
    w = w.replace(a, b)
old = "name: QS d = 3 soft-layer chain (A3-A3.11) replay\n"
assert w.count(old) == 1
w = w.replace(old, "name: Planar compact-K chain (PD, A4.1-A4.3) replay\n")
assert 'qs_d3' not in w and 'qs-d3' not in w
(WT / '.github/workflows/planar-compact-k-chain.yml').write_text(w, encoding='utf-8')
print('  tests and workflow written')
print('DONE')
