"""Build the Math- custody packet frontiers/tl_soft_layer_20261006 (worktree /home/claude/wt-tl, off main).

Stores the exact public comment bodies of lifetime note TL (main#229 and main#259), extracts its control script and
stdout by the stated fence rule, computes the exact rejection fingerprints of every mutant and invalid invocation under
both interpreter modes (they must agree), and writes SOURCES.json, replay.py (adapted from Math-#360's planar packet,
itself the QS d = 3 packet's hardened replay), the two test files, the workflow and README.md.

Usage: python3 build_tl.py <incorporation-claim-comment-id>
"""
import hashlib
import json
import os
import pathlib
import re
import subprocess
import sys
import urllib.request

WT = pathlib.Path('/home/claude/wt-tl')
REL = 'frontiers/tl_soft_layer_20261006'
ROOT = WT / REL
PL_WT = pathlib.Path('/home/claude/wt-planar')     # Math-#360 at 2fb1e3d3: the planar packet's replay.py, tests and workflow
PL_REL = 'frontiers/planar_compact_k_chain_20261006'
SP = pathlib.Path('/tmp/claude-0/-home-claude/b41b316f-232c-5cf7-a0ee-80f0de603a6f/scratchpad/tla')
TOK = os.environ['GITHUB_TOKEN']
CLAIM = int(sys.argv[1])

# ------------------------------------------------------------------------------------------------ the records
# (issue, comment id, stored path, role, expected sha256 prefix or None)
RECORDS = [
    (229, 6015458484, 'TL/CLAIM.md', 'author work claim (note TL)', None),
    (259, 6015463045, 'TL/PICKUP_IBA2_009_main259.md', 'author pickup on main#259 (IBA2-009, the kappa >= 1 side, TAIL-L)', None),
    (229, 6017975404, 'TL/PROOF.md', 'frozen note (lifetime note TL)', '9cb199e0'),
    (229, 6017990426, 'TL/AUTHOR_CONTROLS_COMMENT.md', 'author controls comment (contains tl_exact.py and its stdout)', '11c52b0c'),
    (229, 6018011961, 'TL/READ_REQUESTS.md', 'author read requests (three slices; the Slice C summons of one Cursor agent, D2 of 6002718035); releases the claim', None),
    (259, 6018024601, 'TL/DELIVERED_POINTER_main259.md', 'author delivery pointer on main#259', None),
    (229, 6018013576, 'TL/REVIEW_SLICE_C.md', 'Slice C (section 3, Lemma Delta; controls T2, T3, T4, T7): PASS, Cursor agent bc-d851d2ca (xAI Grok 4.7); pickup and verdict in one comment (GitHub refused a new comment)', None),
    (229, 6018508332, 'TL/REVIEW_SLICES_AB_SUMMONS.md', 'Slices A-B summons (one Cursor agent, D2 of 6002718035)', None),
]
READS_AS_RECORDED = [
    'Slice C (section 3, Lemma Delta; T2, T3, T4, T7): Cursor agent bc-d851d2ca (xAI Grok 4.7; non-Claude, nonauthor), PASS, 6018013576',
]
EXTRA_RECORDS = json.loads((SP / 'tl_reads.json').read_text()) if (SP / 'tl_reads.json').exists() else {'records': [], 'reads': []}
RECORDS += [tuple(r) for r in EXTRA_RECORDS['records']]
READS_AS_RECORDED += EXTRA_RECORDS['reads']


def api(url):
    req = urllib.request.Request(url, headers={'Authorization': 'Bearer ' + TOK, 'Accept': 'application/vnd.github+json', 'User-Agent': 'x'})
    return json.load(urllib.request.urlopen(req))


def ident(data):
    return len(data), hashlib.sha256(data).hexdigest()


stored = []


def comment(issue, cid, path, role, expect=None):
    c = api('https://api.github.com/repos/d6g8k5htny-coder/main/issues/comments/%d' % cid)
    assert c['issue_url'].endswith('/issues/%d' % issue), (cid, c['issue_url'])
    body = c['body'].encode('utf-8')
    p = ROOT / path
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(body)
    n, h = ident(body)
    if expect:
        assert h.startswith(expect), (path, h)
    stored.append({'path': path, 'role': role, 'comment': str(cid),
                   'url': 'https://github.com/d6g8k5htny-coder/main/issues/%d#issuecomment-%d' % (issue, cid),
                   'created_at': c['created_at'], 'updated_at': c['updated_at'], 'bytes': n, 'sha256': h})
    print('  stored', path, n, h[:12])


for rec in RECORDS:
    comment(*rec)

# ------------------------------------------------------------------------------------------------ extraction
source = 'TL/AUTHOR_CONTROLS_COMMENT.md'
heading = '### tl_exact.py'
body = (ROOT / source).read_text(encoding='utf-8')
assert body.count(heading) == 1
section = body[body.index(heading):]
m1 = re.search(r'```python\n(.*?)\n```\n', section, re.S)
m2 = re.search(r'```json\n(.*?)\n```\n', section[m1.end():], re.S)
code = (m1.group(1) + '\n').encode('utf-8')
out = (m2.group(1) + '\n').encode('utf-8')
for path, data, role, exp in (('TL/author_controls.py', code, 'control script tl_exact.py, extracted verbatim from the stored controls comment %s (heading: %s)' % (source, heading), 'ec25809b'),
                              ('TL/author_controls_stdout.json', out, 'published stdout of TL/author_controls.py, extracted verbatim from %s (```json fence)' % source, '8f36ad54')):
    (ROOT / path).write_bytes(data)
    n, h = ident(data)
    assert h.startswith(exp), (path, h)
    stored.append({'path': path, 'role': role, 'extracted_from': source, 'heading': heading, 'bytes': n, 'sha256': h})
    print('  extracted', path, n, h[:12])

# ------------------------------------------------------------------------------------------------ fingerprints
SCRIPT = 'TL/author_controls.py'
STDOUT = 'TL/author_controls_stdout.json'
mutants = [['--mutant', 'M%d' % j] for j in range(1, 11)]
invalid = [['--bogus'], ['--mutant', 'M11'], ['--mutant']]
contracts = {}
script = ROOT / SCRIPT
for args, code_expected in [(m, 1) for m in mutants] + [(i, 2) for i in invalid]:
    res = []
    for flags in (['-B', '-S'], ['-B', '-O', '-S']):
        proc = subprocess.run([sys.executable, *flags, str(script), *args], capture_output=True, cwd=str(script.parent), timeout=600)
        res.append((proc.returncode, hashlib.sha256(proc.stdout).hexdigest(), hashlib.sha256(proc.stderr).hexdigest(), proc.stdout.decode(), proc.stderr.decode()))
    assert res[0][:3] == res[1][:3], (SCRIPT, args)
    rc, so, se, o, e = res[0]
    assert rc == code_expected and o == '', (args, rc, o[:200], e[:200])
    reason = e.splitlines()[0]
    assert reason.startswith('FAILED: ' if rc == 1 else 'usage:'), e
    contracts[(SCRIPT, tuple(args))] = (rc, so, se, reason)
    print('  contract', args, rc, so[:8], se[:8], reason)
for flags in (['-B', '-S'], ['-B', '-O', '-S']):
    proc = subprocess.run([sys.executable, *flags, str(script)], capture_output=True, cwd=str(script.parent), timeout=600)
    assert proc.returncode == 0 and proc.stderr == b'' and proc.stdout == (ROOT / STDOUT).read_bytes(), flags
print('  baseline ok in both modes')
assert len(contracts) == 13
src = (ROOT / SCRIPT).read_text(encoding='utf-8')
NEG_OLD = 'window_a = F(9) if MUT == "M10" else F(11)'
NEG_NEW = 'window_a = F(9) if MUT == "M10" else F(9)'
assert src.count(NEG_OLD) == 1
tmp = SP / 'neg_tl.py'
tmp.write_text(src.replace(NEG_OLD, NEG_NEW), encoding='utf-8')
neg = []
for flags in (['-B', '-S'], ['-B', '-O', '-S']):
    proc = subprocess.run([sys.executable, *flags, str(tmp)], capture_output=True, timeout=600)
    neg.append((proc.returncode, proc.stdout, proc.stderr))
assert neg[0] == neg[1] and neg[0] == (1, b'', b'FAILED: T4_constants\n'), neg
print('  negative control fails at T4 in both modes')

# ------------------------------------------------------------------------------------------------ SOURCES.json
RB = 'https://github.com/d6g8k5htny-coder/main/issues/229#issuecomment-'
author = 'Anthropic Claude (session_01NMeKEismAyeqgdB4sy2NJU), for Dylan Roy (delegated AI work)'
objects = [
    {'tag': 'TL', 'directory': 'TL/', 'object': 'CL-TL-SOFT-LAYER-20261006-v1',
     'title': 'Lifetime note TL: the rejected kernel uniformly on the soft layer (kappa >= 1, k <= 1), the kappa >= 1 side of IBA2-009 (TAIL-L), and the elder density with remainder l^(4/9) log(1/l)',
     'author': author,
     'kind': ('Theorem TL (|T_r^rej(k,u) - A^rej(kappa,u)| <= C r^2 (1 + kappa) for the birth-integrated kernels), Lemmas W1, W2, GE, Delta, '
              'Proposition RW, Corollaries TL1-TL3 (the kappa >= 1 separations of rho_rej, Math-#296 tail (4.2) at b -> infinity, '
              'the moving band J_l = F0bar + O(l^(1/5)), nu_eld and rho_rej with O(l^(4/9) log(1/l))); the control script checks finite algebra only'),
     'nonauthor_reads_as_recorded': READS_AS_RECORDED,
     'conditional_on': ('[N] (#240), #237, #242, #220, #229, #218, [K] (K2) with its erratum, [R] (R5), Math-#296 and, for the last form of TL3, '
                        '#187, at their stated scopes (blobs listed in the note header)'),
     'not_claimed': 'the kappa -> 0 side (TAIL-S): IBA2-009 stays OPEN; no l^(1/2) statement for the whole density; nothing pointwise in b',
     'organizational_independence': 0, 'stored': stored,
     'replays': [{'name': 'tl_exact.py (stdout in a ```json fence)', 'script': SCRIPT, 'stdout': STDOUT, 'args': [],
                  'mutants': mutants, 'invalid': invalid}]},
]
manifest = {
    'schema': 2,
    'object': 'LIFETIME-NOTE-TL-INCORPORATION-20261006-v1',
    'kind': 'additive incorporation of public native note, review and checker records; no new mathematics; no status change',
    'scientific_effect': 'NONE',
    'incorporated_by': {'performer': 'Anthropic Claude', 'session': 'https://claude.ai/code/session_01NMeKEismAyeqgdB4sy2NJU',
                        'attribution': 'Dylan Roy - delegated AI work', 'claim': RB + str(CLAIM),
                        'note': 'the incorporator is also the author of note TL (custody only; no proof byte is changed)'},
    'source_issues': ['https://github.com/d6g8k5htny-coder/main/issues/229', 'https://github.com/d6g8k5htny-coder/main/issues/259'],
    'extraction_rule': ('the rule the controls comment states (that of main#229 comment 5971055189): the control script is the exact text between '
                        'the first ```python fence after its heading and the next ``` line, plus a final newline; its expected stdout is the single '
                        'JSON line of the following ```json fence, plus one newline'),
    'related_packets': {
        'frontiers/elder_cusp_parity_20261002/': '[N] (#240): the pathwise decision lemmas and Theorem N that note TL makes uniform as kappa -> infinity',
        'frontiers/soft_rejected_pairs_20261002/': '#242: the cusp limit of the rejected kernel (Theorem 1), the target of Theorem TL',
        'frontiers/third_order_rate_20261001/': '#229: the remainder l^(3/7) that Corollary TL3 improves, and the intermediate elder bound it keeps',
        'reviews/iba2_009_matching_20261005/': 'Math-#296: the band formula and the tail criterion (4.2) that Corollaries TL1-TL2 address',
    },
    'excluded': {
        'routing comments': 'coordination comments that do not record a pickup, verdict or author response are not stored',
        'clean-context referee reports': 'same-provider, same-session referee reports and exploration scripts (not review evidence) are kept in the project archive, not here',
    },
    'objects': objects,
}
(ROOT / 'SOURCES.json').write_text(json.dumps(manifest, indent=1, ensure_ascii=False) + '\n', encoding='utf-8')
print('  SOURCES.json: %d files' % len(stored))

# ------------------------------------------------------------------------------------------------ replay.py
rp = (PL_WT / PL_REL / 'replay.py').read_text(encoding='utf-8')


def rep(old, new):
    global rp
    assert rp.count(old) == 1, (rp.count(old), old[:80])
    rp = rp.replace(old, new)


rep('"""Verify the stored planar compact-K chain records (Corollary PD, QS addenda A4.1-A4.3) and replay their published author\ncontrols (standard library only).',
    '"""Verify the stored records of lifetime note TL and replay its published author controls (standard library only).')
rep("  - an exact copy of a public comment body on main#229 (a note, claim, controls comment, review, pickup, release,\n    erratum, support note or author response);\n"
    "  - a control script or its stdout, extracted verbatim from a stored controls comment by the extraction rule that\n"
    "    comment states (the rule of main#229 comment 5971055189); Corollary PD's ledger script and its stdout are extracted\n"
    "    the same way from the stored note itself (its section 4). The stdouts of PD, A4.1 and A4.2 are ```text fences.",
    "  - an exact copy of a public comment body on main#229 or main#259 (a note, claim, pickup, controls comment, read\n    request, review, release or author response);\n"
    "  - the control script or its stdout, extracted verbatim from the stored controls comment by the extraction rule that\n"
    "    comment states (the rule of main#229 comment 5971055189). The stdout is a ```json fence.")
rep("     - a one-byte change to a stored note (A4_3/PROOF.md);\n     - a control script with one changed constant (A4.3's Lemma 1.1 constant 192 replaced by 96).",
    "     - a one-byte change to a stored note (TL/PROOF.md);\n     - a control script with one changed constant (T4's window tail constant 11 replaced by 9).")
rep("Usage: python3 -B -S frontiers/planar_compact_k_chain_20261006/replay.py   (exit 0 iff every check passes)",
    "Usage: python3 -B -S frontiers/tl_soft_layer_20261006/replay.py   (exit 0 iff every check passes)")
start = rp.index('# Exact rejection fingerprints of the four extracted author controls')
end = rp.index("# Replacing A4.3's Lemma 1.1 constant 192 by 96 with MUT=None must fail specifically at Z1, on stderr alone.")
lines = []
for (path, args), (rc, so, se, reason) in contracts.items():
    lines.append("    (%r, %r):\n        (%d, %r, %r, %r)," % (path, args, rc, so, se, reason))
block = ("# Exact rejection fingerprints of the extracted author controls (tl_exact.py from 6017990426), computed under both\n"
         "# interpreter modes at incorporation and found identical.\n"
         "# Each key is (script path, complete argv tail); each value is (exit, stdout SHA256,\n"
         "# stderr SHA256, readable reason). References are frozen independently of this run.\n"
         "# All 10 mutants and 3 invalid invocations were executed and their named reasons\n"
         "# checked against their source. Exact fingerprints enforce the full contracts,\n"
         "# including the empty stdout, the FAILED or usage line and its group name.\n"
         "# No current failing output, generic exit code or broad regex creates a reference.\n"
         "# Any source/runtime output drift fails closed and requires a reviewed amendment.\n"
         "REJECTION_CONTRACTS = {\n" + "\n".join(lines) + "\n}\n\n")
rp = rp[:start] + block + rp[end:]
rep("# Replacing A4.3's Lemma 1.1 constant 192 by 96 with MUT=None must fail specifically at Z1, on stderr alone.\n"
    "NEGATIVE_CONSTANT = (1, hashlib.sha256(b'').hexdigest(),\n                     hashlib.sha256(b'FAILED: Z1_lemma11_constants\\n').hexdigest(), 'Z1_lemma11_constants')",
    "# Replacing T4's window tail constant 11 by 9 with MUT=None must fail specifically at T4, on stderr alone.\n"
    "NEGATIVE_CONSTANT = (1, hashlib.sha256(b'').hexdigest(),\n                     hashlib.sha256(b'FAILED: T4_constants\\n').hexdigest(), 'T4_constants')")
rep("        target = copy / 'A4_3' / 'PROOF.md'", "        target = copy / 'TL' / 'PROOF.md'")
rep("        if 'identity mismatch: A4_3/PROOF.md' not in tree_failures(copy, manifest):\n            failures.append('negative control: a one-byte change to A4_3/PROOF.md was not detected')\n        script = copy / 'A4_3' / 'author_controls.py'",
    "        if 'identity mismatch: TL/PROOF.md' not in tree_failures(copy, manifest):\n            failures.append('negative control: a one-byte change to TL/PROOF.md was not detected')\n        script = copy / 'TL' / 'author_controls.py'")
rep("        old = 'K192 = F(96) if MUT == \"M1\" else F(192)'\n        if text.count(old) != 1:\n            failures.append('negative control: the Lemma 1.1 constant line was not found exactly once')\n        else:\n            script.write_text(text.replace(old, 'K192 = F(96) if MUT == \"M1\" else F(96)'), encoding='utf-8')\n            result = run(script)\n            mismatches = check_rejection(result, NEGATIVE_CONSTANT)\n            failures.extend('negative control: changed Lemma 1.1 constant: ' + why for why in mismatches)\n            if not mismatches:\n                report_control('A4_3/author_controls.py', [], result, 'changed 192 to 96: Z1_lemma11_constants')",
    "        old = 'window_a = F(9) if MUT == \"M10\" else F(11)'\n        if text.count(old) != 1:\n            failures.append('negative control: the window tail constant line was not found exactly once')\n        else:\n            script.write_text(text.replace(old, 'window_a = F(9) if MUT == \"M10\" else F(9)'), encoding='utf-8')\n            result = run(script)\n            mismatches = check_rejection(result, NEGATIVE_CONSTANT)\n            failures.extend('negative control: changed window tail constant: ' + why for why in mismatches)\n            if not mismatches:\n                report_control('TL/author_controls.py', [], result, 'changed 11 to 9: T4_constants')")
rep("print('Planar compact-K chain (PD, A4.1-A4.3) incorporation replay (%s): %d failure(s)' % (mode, len(failures)))",
    "print('Lifetime note TL incorporation replay (%s): %d failure(s)' % (mode, len(failures)))")
rep("print('Planar compact-K chain (PD, A4.1-A4.3) incorporation replay (%s): %d stored identities, %d extractions, %d checker stdouts, '",
    "print('Lifetime note TL incorporation replay (%s): %d stored identities, %d extractions, %d checker stdouts, '")
assert 'A4_' not in rp and 'planar' not in rp.lower() and 'Z1_' not in rp, [ln for ln in rp.splitlines() if 'A4_' in ln or 'planar' in ln.lower()][:5]
(ROOT / 'replay.py').write_text(rp, encoding='utf-8')
print('  replay.py written', len(rp.encode()))
json.dump({'%s %s' % k: v for k, v in contracts.items()}, open(SP / 'tl_contracts.json', 'w'), indent=1)

# ------------------------------------------------------------------------------------------------ tests and workflow
subs = [(PL_REL, REL),
        ('test_planar_compact_k_replay_protocol.py', 'test_tl_soft_layer_replay_protocol.py'),
        ('test_planar_compact_k_replay_evidence.py', 'test_tl_soft_layer_replay_evidence.py'),
        ('planar-compact-k-chain.yml', 'tl-soft-layer.yml')]
t = (PL_WT / 'tests/test_planar_compact_k_replay_protocol.py').read_text(encoding='utf-8')
for a, b in subs:
    t = t.replace(a, b)
old = "        self.assertEqual(len(listed), 34)   # PD: 3 mutants + 2 invalid; A4.1: 6 + 2; A4.2: 6 + 2; A4.3: 10 + 3"
assert t.count(old) == 1
t = t.replace(old, "        self.assertEqual(len(listed), 13)   # TL: 10 mutants + 3 invalid")
old = ("            root = Path(tmp); (root/'A4_3').mkdir()\n            proof = b'x'*150\n            (root/'A4_3/PROOF.md').write_bytes(proof)\n"
       "            script = ('from fractions import Fraction as F\\nMUT=None\\n'\n                      'K192 = F(96) if MUT == \"M1\" else F(192)\\n'\n"
       "                      'if K192==F(96): raise RuntimeError(\"synthetic crash\")\\n'\n                      'print(\"ok\")\\n')\n"
       "            (root/'A4_3/author_controls.py').write_text(script)\n            (root/'A4_3/author_controls_stdout.json').write_bytes(b'ok\\n')\n"
       "            manifest = {'objects': [{'tag':'A4.3','replays':[], 'stored':[\n                {'path':'A4_3/PROOF.md','bytes':len(proof),'sha256':hashlib.sha256(proof).hexdigest()}]}]}")
assert t.count(old) == 1, 'negative-control test block'
t = t.replace(old,
       "            root = Path(tmp); (root/'TL').mkdir()\n            proof = b'x'*150\n            (root/'TL/PROOF.md').write_bytes(proof)\n"
       "            script = ('from fractions import Fraction as F\\nMUT=None\\n'\n                      'window_a = F(9) if MUT == \"M10\" else F(11)\\n'\n"
       "                      'if window_a==F(9): raise RuntimeError(\"synthetic crash\")\\n'\n                      'print(\"ok\")\\n')\n"
       "            (root/'TL/author_controls.py').write_text(script)\n            (root/'TL/author_controls_stdout.json').write_bytes(b'ok\\n')\n"
       "            manifest = {'objects': [{'tag':'TL','replays':[], 'stored':[\n                {'path':'TL/PROOF.md','bytes':len(proof),'sha256':hashlib.sha256(proof).hexdigest()}]}]}")
assert 'planar' not in t and 'A4_3' not in t, [ln for ln in t.splitlines() if 'planar' in ln or 'A4_3' in ln][:5]
(WT / 'tests/test_tl_soft_layer_replay_protocol.py').write_text(t, encoding='utf-8')
e = (PL_WT / 'tests/test_planar_compact_k_replay_evidence.py').read_text(encoding='utf-8')
for a, b in subs:
    e = e.replace(a, b)
assert 'planar' not in e, [ln for ln in e.splitlines() if 'planar' in ln][:5]
(WT / 'tests/test_tl_soft_layer_replay_evidence.py').write_text(e, encoding='utf-8')
w = (PL_WT / '.github/workflows/planar-compact-k-chain.yml').read_text(encoding='utf-8')
for a, b in subs:
    w = w.replace(a, b)
old = "name: Planar compact-K chain (PD, A4.1-A4.3) replay\n"
assert w.count(old) == 1
w = w.replace(old, "name: Lifetime note TL replay\n")
assert 'planar' not in w
(WT / '.github/workflows/tl-soft-layer.yml').write_text(w, encoding='utf-8')
print('  tests and workflow written')

# ------------------------------------------------------------------------------------------------ README.md
RM = 'https://github.com/d6g8k5htny-coder/main/issues/229#issuecomment-'
tpl = (SP / 'readme_tl_template.md').read_text(encoding='utf-8')
fill = {
    '@@CLAIM@@': str(CLAIM),
    '@@NFILES@@': str(len(stored)),
    '@@READS_SUMMARY@@': ('Three slices, each read by a Cursor cloud agent running xAI Grok 4.7 (`grok-4.7-high-fast`; non-Claude, nonauthor), '
                          'summoned one bounded task at a time under D2 of [6002718035](%s6002718035): Slices A–B, C and D, all PASS.' % RM),
    '@@AMENDMENTS@@': ('None. No reader requested a change; the author\'s round note [6019049654](%s6019049654) records that the note and the controls '
                       'stay frozen as posted.' % RM),
    '@@READ_TABLE@@': '\n'.join([
        '| A–B | §§0–2: the setting, the window lemmas W₁ and W₂, Lemma GE, Proposition RW; controls T1, T5 | PASS (Cursor `bc-df5cfd1f…`, [6018510549](%s6018510549)) |' % RM,
        '| C | §3: Lemma Δ (Parts R and F) and what Steps 3–4 use; controls T2, T3, T4, T7 | PASS (Cursor `bc-d851d2ca…`, [6018013576](%s6018013576)) |' % RM,
        '| D | §§4–7 and the header: Steps 1–6, the bounds of §5, Corollaries TL1–TL3 and the Math-#296 tail, the ledger, the remarks; control T6 | PASS (Cursor `bc-b84a2c6b…`, [6018770333](%s6018770333)) |' % RM]),
}
for k, v in fill.items():
    assert tpl.count(k) == (2 if k == '@@CLAIM@@' else 1), k
    tpl = tpl.replace(k, v)
assert '@@' not in tpl
(ROOT / 'README.md').write_text(tpl, encoding='utf-8')
print('  README.md written')
print('DONE')
