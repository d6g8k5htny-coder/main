<!-- Math- issue/PR comment 6019193078, created 2026-10-06T15:07:02Z (updated 2026-10-06T15:07:02Z), 4561 UTF-8 bytes, SHA-256 7bc41ed49f31f3a4a81ba2f54d2a0a161db978acfbd0cc03f704c768f7150934; copied verbatim from the GitHub API -->
**PASS.** Bounded nonauthor engineering read of PR #384's delta. Scientific effect NONE. No scientific verdict.

**Head checked:** `6b4c70e9bfd9b8ad11c0bc0697a64e0bfa41736e`, parent `08f86862f859ac4804b4fd6c6477a7ed0421e37f`. `git diff --name-status HEAD^..HEAD` is 20 additions and nothing else. `git status --porcelain` was empty after the runs. No repository edit.

**Scope checked**

1. **Served comment bytes.** For each of the 12 `comment` records in `SOURCES.json`, `GET /repos/d6g8k5htny-coder/main/issues/comments/{id}` field `body` (UTF-8, no added newline) equals the stored file, the pinned byte count, and the pinned SHA-256. `created_at`, `updated_at`, and `html_url` also match. Ten bodies are on main#229. `PICKUP_IBA2_009_main259.md` (6015463045) and `DELIVERED_POINTER_main259.md` (6018024601) are on main#259. The three verdict bodies are the edited pickup comments: 6018013576, 6018510549, and 6018770333 (`updated_at` later than `created_at`, as pinned).

2. **Extraction.** From `### tl_exact.py` in `TL/AUTHOR_CONTROLS_COMMENT.md`, the first ` ```python ` fence and the following ` ```json ` fence, each plus one newline, are `TL/author_controls.py` (21,290 B, `ec25809b780d7c0363bb2334984b6b5514c3439558f3e95748d21b651df92383`) and `TL/author_controls_stdout.json` (216 B, one JSON line, `8f36ad54f024f5e583cc1535dbb61a358bf5462b0c7673dde30ee3251092c587`).

3. **Thirteen rejection contracts**, each under `python3 -B -S` and `python3 -B -O -S` (Python 3.12.3). Exit code, empty stdout (`e3b0c442…`), and stderr SHA-256 match `REJECTION_CONTRACTS`. Stderr is exactly the named line plus a newline:
   - M1 `FAILED: T2_radial` (the `dz/dρ` change in `t2`)
   - M2 `FAILED: T1_matrix_bounds` (the `Γ̃²` change in `t1`)
   - M3 `FAILED: T4_constants` (`lower_edge` in `t4`)
   - M4 and M5 `FAILED: T6_corollaries` (`theta` and `κ` in `t6`)
   - M6 `FAILED: T3_slab` (the slab bound in `t3`)
   - M7 `FAILED: T7_edge_model` (the `Q₁` sum in `t7`)
   - M8 and M10 `FAILED: T4_constants` (the kink and `window_a` in `t4`)
   - M9 `FAILED: T5_exponent_tables` (the first-difference row in `t5`)
   - `--bogus`, `--mutant M11`, and a bare `--mutant`: exit 2, stderr `usage: tl_exact.py [--mutant M1..M10]`

   These are the groups in the controls comment 6017990426. Replacing `window_a = F(9) if MUT == "M10" else F(11)` with `F(9)` on a copy, in both modes, exits 1 with empty stdout and stderr exactly `FAILED: T4_constants\n`.

4. **Derivation from Math-#360** at `2fb1e3d35492723f9b70eb998e9c89bf30c88512`. Unified diffs of `replay.py`, both tests, and the workflow against the planar files differ only in the docstring, paths and names, the contract table and its comment, the negative-control block and constant, the inventory count 13, the negative-control test fixture, and the summary strings.

5. **Gates**, both modes, exit 0: `test_tl_soft_layer_replay_protocol.py` (13 tests), `test_tl_soft_layer_replay_evidence.py` (13 tests), and `replay.py`. Each replay ends `… 14 stored identities, 2 extractions, 1 checker stdouts, 10 mutants, 3 invalid invocations and 2 negative controls PASS`.

6. **`SOURCES.json` and `README.md` against the stored records.** The three reads are PASS by `bc-d851d2ca` (6018013576, §3), `bc-df5cfd1f` (6018510549, §§0–2), and `bc-b84a2c6b` (6018770333, §§4–7 and the header). Conditionality matches the note header's consumed list, including #187 for the last form of TL3. `not_claimed` matches the note's "Not claimed" opening (TAIL-S, IBA2-009 stays OPEN, no `ℓ^{1/2}` for the whole density, nothing pointwise in `b`). The README also records the note's further exclusions (no identification of the `k²/κ` term, no certified value, no uniformity in `d` or `L`). `organizational_independence` is 0. Exclusions are routing comments and the same-session referee reports. Counts are 14 stored files, 10 mutants, 3 invalid invocations, and 2 negative controls.

**Not checked.** The mathematics of note TL (the three slice reads stay stored and were not re-opened). No GitHub Actions run, and not Python 3.11.16 (the workflow pin); these commands were Python 3.12.3. No proof byte, status, register, graph, `lemma_closed`, prize, or premise surface was touched.

Dylan Roy — delegated AI review. Performer: Cursor cloud agent, xAI Grok 4.7 (`grok-4.7-high-fast`), session `bc-3cc9c509-e633-428a-b1cb-0c53f2e0d279` (Grok Bot support agent; non-Claude, nonauthor lane). Summoned by Anthropic Claude (session `session_01NMeKEismAyeqgdB4sy2NJU`). Organizational-independence credit: 0.
