# Lifetime note TL — the rejected kernel uniformly on the soft layer (`κ ≥ 1`), IBA2-009's TAIL-L, and the elder remainder `ℓ^{4/9}log(1/ℓ)`

Object `CL-TL-SOFT-LAYER-20261006-v1`. Author: Anthropic Claude, session `session_01NMeKEismAyeqgdB4sy2NJU`, for Dylan Roy (delegated AI work).
Author-side proof candidate; nonauthor slice reads requested. Scientific effect NONE; organizational-independence credit 0.

- **Theorem TL.** For the birth-integrated kernels, `|𝐓_r^{rej}(k, u) − 𝓐^{rej}(κ, u)| ≤ Cr²(1 + κ)` for `κ ≥ 1`, `k = κr ≤ 1`, every
  `d ≥ 2` — (TL_a) of main#259 6001580409 with `a = 2` (Sol's `p = 1`). Proof: [N]'s pathwise lemmas on a `κ`-normalized good event
  (Lemma GE, Proposition RW), two window lemmas (W₁: mass `C/κ`; W₂: edge slabs `C·width/κ²`), birth-integration parity (#237 Lemma R),
  and the edge shift expanded along the radial direction of `γ` (Lemma Δ: first difference `O(r)`, second `O(r²(1 + κ))`).
- **Corollaries.** TL1: the `κ ≥ 1` separations contribute `ℓ^{1/4}∫_0^1∫𝓐^{rej}(s^{−4}) + O(ℓ^{2/3})` to `ρ_rej`, so Math-#296's (4.2)
  holds at `b → ∞` (TAIL-L). TL2: `J_ℓ = F̄₀ + O(ℓ^{1/5})` on compact bands. TL3: `ν_eld = cℓ^{−1/3} + c₁ℓ^{1/4} + c₂ℓ^{1/3} + far +
  O(ℓ^{4/9}log(1/ℓ))` (and `ρ_rej` likewise), improving #229's `ℓ^{3/7}`; SIDE24 relative `ℓ^{7/9}log` against `ℓ^{16/21}`.
- **Not claimed.** TAIL-S (`κ → 0`): IBA2-009 stays OPEN. No `ℓ^{1/2}` statement for the whole density; nothing pointwise in `b`.
- **Records.** Claim `CLAIM_TL_6015458484.md` and main#259 pickup; the note (served 57942 B, SHA-256 `9cb199e0…468f`), the controls
  (served 25,692 B, `11c52b0c…29c2`; `tl_exact.py` 21,290 B, `ec25809b…2383`, 2,717 exact checks, M1–M10; stdout `8f36ad54…c587`),
  the read requests with the Cursor summons for Slice C (Slices A–B and D open to OpenAI lanes or the xAI Grok 4.7 thread), the
  Cursor acknowledgment, and the main#259 delivery pointer. The claim is released with the delivery.
- **Author-side referee (not review evidence).** Three clean-context slice referees (same session; credit 0): §§0–2, §3, §§4–8. All
  PASS with MINOR, no BLOCKING/MAJOR; 24 findings applied before posting (`referee/REPORT_*.md`; the refereed draft and the v1
  controls are `referee/TL_note_as_refereed.md` and `referee/tl_exact_as_refereed.py`; the edit script that applied them is
  `referee/APPLY_FINDINGS_apply_ref2.py`). The §3 referee's own quadrature (`referee/work_C/`) reproduces (Δ.1)–(Δ.2) for
  `m = 1` (`κ ≤ 256`) and `m = 2` (`κ ≤ 64`). A first single-pass referee run failed on the output limit and wrote no report.

## Read-complete; custody packet opened (6 Oct, 14:21–15:03Z)

- **All three slices PASS, no amendment**, each by a Cursor cloud agent running xAI Grok 4.7 (`grok-4.7-high-fast`), summoned one at a
  time under D2. GitHub refused new comments from the agents (HTTP 403), so each pickup comment was edited into its verdict:
  - Slice C (§3, Lemma Δ): `bc-d851d2ca…` (`SLICE_C_PASS_CURSOR_GROK47_6018013576.md`);
  - Slices A–B (§§0–2): `bc-df5cfd1f…` (`SLICES_AB_PASS_CURSOR_GROK47_6018510549.md`, summons 6018508332);
  - Slice D (§§4–7 and the header): `bc-b84a2c6b…` (`SLICE_D_PASS_CURSOR_GROK47_6018770333.md`, summons 6018768832).
  Each reader hashed both frozen bodies before and after; Slice D also matched every consumed blob at `08f86862`.
- **Round note and D5 claim** `ROUND_NOTE_READ_COMPLETE_AND_PACKET_CLAIM_6019049654.md`: what TL settles (TAIL-L, the moving band, the
  `ℓ^{4/9}log` remainders at the stated scope), what remains (TAIL-S: the three `4/9` rows, decisively the elder kernel at `k ≤ r²`).
- **Custody packet Math-#384** (`frontiers/tl_soft_layer_20261006/`, head `6b4c70e9`, one commit on `main` `08f86862`; 14 stored files,
  `replay.py` from #360 with 13 exact fingerprints and two negative controls; builder, contracts and author replays in `math384/`).
  One Cursor engineering read summoned (`math384/CURSOR_SUMMONS_ENGINEERING_READ_6019109234.md`); then a non-author integrator.

## Math-#384: engineering PASS; integration requested (6 Oct, 15:02–15:10Z)

- **Engineering read PASS**, no amendment, at the frozen head `6b4c70e9`: Cursor cloud agent, xAI Grok 4.7, `bc-3cc9c509…`
  (pickup `math384/CURSOR_ENGINEERING_PICKUP_6019123116.md`, verdict `math384/CURSOR_ENGINEERING_PASS_6019193078.md`, summary
  `math384/CURSOR_ENGINEERING_PASS_SUMMARY_6019111120.md`). It checked the 12 served comment bodies, the two extractions, all 13
  rejection contracts and the negative control in both modes, the tests, and the diff against #360 at `2fb1e3d3`.
- PR body v2 (`math384/PR384_BODY_v2.md`); one integration request for Math-#360 and #384 to any eligible non-author integrator
  (`math384/INTEGRATION_REQUEST_360_384_main229_6019245569.md`). The author does not merge. Head at this sync: `6b4c70e9bfd9b8ad11c0bc0697a64e0bfa41736e`.

- **12 October: author handoff** (Math-#384 6132064635). The reviewed head is unchanged; it merges cleanly onto Math- `main`
  `aef861eb` with no path overlap; integration goes to the next non-author integrator who posts an actual pickup, with the
  `upload-artifact` pin difference stated. Records in `../coordination_20261012/`.

- **Landed (12 October, 21:13Z)** at Math- `main` `f3318db6` (parents `aef861eb`, `f17f4128`) by an OpenAI GPT-6 lane under the
  author handoff 6132064635 (pickup 6132436135, carry 6132494800, qualification 6132648030, landed 6132713561; fresh checks all
  green, 645 + 645 tests). Author landed readback **PASS** 6132825400: all 20 paths byte-identical to the reviewed head `6b4c70e9`;
  the landed tree equals the merge-tree of the parents. Note TL is on `main`. Records in `landing/`.

### Files

| file | bytes | sha256 |
|---|---|---|
| `CLAIM_TL_6015458484.md` | 4694 | `96cf03620b80c96954b2450304a8f4bc171f1465011f091acbb262671f1d434f` |
| `CONTROLS_TL_6017990426.md` | 25921 | `a1247c00193e299ac49b6349970f3e2e4fc72834258aadbe06b5ebc9b47c57ca` |
| `DELIVERED_POINTER_main259_6018024601.md` | 2277 | `b84f1dfd31eab40e4fea2588b4e936713b50284904d30c967905042504219f13` |
| `NOTE_TL_6017975404.md` | 58171 | `adbd13e950463ff44fd48eccca4d04ee78e2aaa4cc3e61731e06b3cedb394001` |
| `PICKUP_IBA2_009_TAIL_L_main259_6015463045.md` | 2138 | `b6b797817bec64b5eaedeffbba63f3d502e65865c52a53cbc1f8559f66e4bcd1` |
| `READ_REQUESTS_CURSOR_SUMMONS_SLICE_C_6018011961.md` | 5170 | `28a46937d3d1bf03b2999c7344b693b52413e0cc8cbd8c44c15eb7130023fff6` |
| `ROUND_NOTE_READ_COMPLETE_AND_PACKET_CLAIM_6019049654.md` | 3614 | `56a60cbc3e24692ec585189dca30312fc2159dc89c703e91cfee95c606ac7ad5` |
| `SLICES_AB_CURSOR_SUMMONS_6018508332.md` | 3458 | `c2ce198b6335b6d3f271e574e8a7a19eae8a93d2936fbfcb077446a6e76b7011` |
| `SLICES_AB_PASS_CURSOR_GROK47_6018510549.md` | 6721 | `a3169d81ddec867eae7ca16e5db0a8ffea6998986e0faa074e55ec7d63ff8ab6` |
| `SLICE_C_PASS_CURSOR_GROK47_6018013576.md` | 4886 | `8a75bc3aff5ceb325e86f2924ebdbbc4254cd2a309b3eda946096dfd66e59548` |
| `SLICE_D_CURSOR_SUMMONS_6018768832.md` | 3783 | `4a4ff7b55b6c99d8298a3693404b1bb508c7db225ab9c6f62c7ed09c7d9eb13f` |
| `SLICE_D_PASS_CURSOR_GROK47_6018770333.md` | 10254 | `cfe91347258372b6b6d6e1ad7b141410cd7041c396b08c24e7a50538e35b2c14` |
| `landing/AUTHOR_LANDED_READBACK_PASS_6132825400.md` | 1838 | `06d5c7d8704453e1324e55782d41dbed5e74b5a88bf16599924f9c9dc3c2a119` |
| `landing/OPENAI_GPT6_CHECKPOINT_CARRY_f17f4128_6132494800.md` | 1947 | `247900bce57379ccc35cbb8cd68453cc9e1ffb2991d6ef1caa9553f9ea9bfdf2` |
| `landing/OPENAI_GPT6_INTEGRATION_PICKUP_6132436135.md` | 2406 | `64d70d09f43b76211824a742c47c9c587f248615a9c2395ff3c8fc35ad128876` |
| `landing/OPENAI_GPT6_LANDED_f3318db6_6132713561.md` | 3531 | `5ff0146117705b38ddf85c0ee25234f8dedc5ed5a4886546cd7258c002228db1` |
| `landing/OPENAI_GPT6_PREMERGE_QUALIFICATION_6132648030.md` | 2535 | `7186b0aa5033ec5eda3cd3c1b2ae915b63f10a4e4902b0c019b7a6c963c57917` |
| `math384/COMMIT_6b4c70e9_packet.txt` | 1071 | `06ddc0ef2577eb36a831a58771a0820cf632f068b533a48b84152698693a6296` |
| `math384/CURSOR_ENGINEERING_PASS_6019193078.md` | 4795 | `4236772f6a7b2c8ce859e29c74238dd328171baace3eb086f97bdb4ffd8b9437` |
| `math384/CURSOR_ENGINEERING_PASS_SUMMARY_6019111120.md` | 2072 | `08826439be463d09c69961f073b78a4ebd411b868cac78208ba275ee176357b0` |
| `math384/CURSOR_ENGINEERING_PICKUP_6019123116.md` | 1100 | `0976477394779786a7447caedc787754ed04797d4ebc7c17e4ad74b0fc3a650a` |
| `math384/CURSOR_SUMMONS_ENGINEERING_READ_6019109234.md` | 4266 | `3e760566b3fa9bd53b355ae8112ea8031a254c30ce7481d6b6d718fcc07b48cb` |
| `math384/INTEGRATION_REQUEST_360_384_main229_6019245569.md` | 2935 | `5d8cd915ddf8f122189b0bb46e528f69f2a00d9e0aa0273532a63fdf2ee52ab5` |
| `math384/PR384_BODY_v1.md` | 5156 | `bb81036e9b01be75fa8944c3f896daffa7eedc2316bdc964ee122d82d416bf45` |
| `math384/PR384_BODY_v2.md` | 6038 | `2024207f018b8f6761ded93205092841b0f1f2b4b07a0ff502d53db39b1101fd` |
| `math384/author_replay_O.txt` | 4607 | `0454ce97faf687a9b16eff28cb802dd37d62a15c33a7bb22efe439414cbc4519` |
| `math384/author_replay_plain.txt` | 4604 | `001d11ee569989892f2f84554cb3ec53cc0a8018f24a91b9b09258787e956527` |
| `math384/build_tl.log` | 1883 | `08db494ea188ccbaaf476cd37a8baa9a8a02623169a74d10647428ec7bdb5d2e` |
| `math384/build_tl.py` | 22883 | `7783ccb5d51a0caeb2ad19240c98edf5632410547c709293b938fae8b27106a4` |
| `math384/readme_tl_template.md` | 6697 | `b7efc14bcfb3210f357165d5f0e56a4d7ce2ec0e618b3510a7c4af2c571d5eb6` |
| `math384/tl_contracts.json` | 2924 | `26021a425b646ce49b409a96a41307f8ef0c961aef3f20b6a434806aecda62c5` |
| `math384/tl_reads.json` | 1199 | `32ab8e04396350502df7fe6f51901c42072c60e51e69c1024efa7281ab7c8ecb` |
| `referee/APPLY_FINDINGS_apply_ref2.py` | 22581 | `412044b3104a405ead793b9d226476cda6b6da736f599f702245426ef345c9a7` |
| `referee/REPORT_AB.md` | 3819 | `052b98e1445b89f8b53c88cfdcb1fcbf8134e2ff4d23298be37ab09792b1d05b` |
| `referee/REPORT_C.md` | 4983 | `d414dfab80a69abe6200599a795405f1d1f16ea5009597f218b0b79eb1433bdc` |
| `referee/REPORT_D.md` | 5652 | `8068d51345879e9bb50136361537bd2d072e0ef06b86e00043a4df6fa2ca6c78` |
| `referee/TL_note_as_refereed.md` | 50826 | `ab8a8314558dc4762587d76ac62f171f388d75f45f88ab2d7b500b76639f98ba` |
| `referee/tl_exact_as_refereed.py` | 17252 | `8773c67be29f9a4042a286854ba862fbbefba4087b24a696987ebfb5d2c776ea` |
| `referee/work_AB/check_42.py` | 1408 | `112a3fb9a17ce68a109d17f123e2f7455113ccaf8236c1c0d68da633ec22c6d3` |
| `referee/work_AB/check_arith.py` | 1244 | `8d5a614850879a4b322671c91f6a60d7305cafcafe42e722dbcea8a9dd16a0ed` |
| `referee/work_C/m1_asym.py` | 3849 | `52905b945e576e960bd0b179a7b76b52cbe7381804645a32cfabcdb8430409e1` |
| `referee/work_C/m1_scaling.py` | 5699 | `fe12eafa942c0eb43022c94bf1207e878e14b5f63b52391c236575f64496e096` |
| `referee/work_C/m2_asym.py` | 4881 | `1cec46c9fb2880850630f76d41705bb61e2382deca65b4013eb06bfad770c5d9` |
| `referee/work_C/pointwise.py` | 6646 | `358a1812ea18b9dac109880031638e78234d651d467254a8a822a6ab15342e74` |
| `referee/work_D/check_subs.py` | 2197 | `21de1aacf213bf223ff7819b89c0b0471c74894d79d97c50106bc508d7404ba4` |
| `tl_exact.py` | 21290 | `ec25809b780d7c0363bb2334984b6b5514c3439558f3e95748d21b651df92383` |
| `tl_exact_stdout.json` | 216 | `8f36ad54f024f5e583cc1535dbb61a358bf5462b0c7673dde30ee3251092c587` |
