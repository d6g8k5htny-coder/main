import sympy as sp

def sym(name, m):
    s = sp.symbols(f"{name}0:{m*(m+1)//2}")
    M = sp.zeros(m, m); it = iter(s)
    for i in range(m):
        for j in range(i, m):
            v = next(it); M[i, j] = v; M[j, i] = v
    return M

for m in (1, 2, 3):
    A, B, Cm = sym("a", m), sym("b", m), sym("c", m)
    g = sp.Matrix(sp.symbols(f"g0:{m}")); eta = sp.Matrix(sp.symbols(f"e0:{m}"))
    f4, f5, kap, k, t = sp.symbols("f4 f5 kappa k t")
    D = A.det(); J = A.adjugate()
    DB = sp.diff((A + t*B).det(), t).subs(t, 0)
    DC = sp.diff((A + t*Cm).det(), t).subs(t, 0)
    DBB = sp.diff((A + t*B).det(), t, 2).subs(t, 0)
    JB = sp.diff((A + t*B).adjugate(), t).subs(t, 0)
    Yp = f4/12*D - (g.T*J*g)[0]/4
    U = Yp + 3*k*DB
    V = sp.Rational(3, 4)*k*(DC + DBB) + f4/24*DB + f5/120*D - (g.T*J*eta)[0]/12 - (g.T*JB*g)[0]/8
    Ai = A.inv()
    Q1 = f5/120 - (eta.T*Ai*g)[0]/12 + (g.T*Ai*B*Ai*g)[0]/8
    P1 = D**2/120*f5 - D/12*(g.T*J*eta)[0] + sp.Rational(1, 8)*(g.T*J*B*J*g)[0]
    w0 = 36*kap**2*D**2 - Yp**2
    lhs = 36*kap**2*D**2 + 12*k*D*V - U**2
    rhs = w0 + 12*k*P1 + 9*k**2*(D*(DC + DBB) - DB**2)
    e1 = sp.expand(lhs - rhs)
    e2 = sp.simplify(P1 - D**2*Q1)
    z = f4 - 3*(g.T*Ai*g)[0]
    e3 = sp.simplify(Yp - D*z/12)
    e4 = sp.simplify(w0 - D**2/144*(5184*kap**2 - z**2))
    print("m", m, "(4.2):", e1 == 0, "P1=D^2Q1:", e2 == 0, "Y'=Dz/12:", e3 == 0, "w0 form:", e4 == 0)
