from fractions import Fraction as F
import math

ce = F(1, 200); de = F(1, 96)
print("36*ce", 36*ce, "<= 1?", 36*ce <= 1)
print("1728*ce", 1728*ce, " zmax/kappa", math.sqrt(5184 + 1728*ce))
print("36+12ce", 36 + 12*ce, "<=37", 36 + 12*ce <= 37)
print("24-36ce", 24 - 36*ce)
print("2ce/3", 2*ce/3, "<", de, 2*ce/3 < de)
print("36ce < 72de", 36*ce, 72*de, 36*ce < 72*de)
print("off-J window [24-72de,24+72de]", 24 - 72*de, 24 + 72*de)
print("175^2*72", 175**2*72, "cube root", (175**2*72)**(1/3))
print("440*72", 440*72)
print("Q'2: need (175/8)(72/C4)^(1/2)<=1/2 -> C4 >=", 72*(F(175, 4))**2, float(72*(F(175, 4))**2))
print("24^2", 24**2)
# W2 ratio
for x0 in (24, 72):
    worst = F(x0 - 9, x0 - 17)
    loose = F(x0 + 17, x0 - 17)
    print("x0", x0, "exact max ratio", worst, float(worst), "note bound", loose, float(loose), "<9", loose < 9)
# theta requirement: 72*theta + 36*zeta <= 1 with zeta<=ce
print("need theta <=", (1 - 36*ce)/72, float((1 - 36*ce)/72))
print("C10 bound if only zeta,eps/k <= ce:", float((1 - 36*ce)/72/(2*ce**2)))
# kappa^2 Delta^2 bound in Bb bullet 2 exponent check
# kappa^2 lam^2 * (t1 f4/(kappa lam))^(5/2) = kappa^(-1/2) t1^(5/2) f4^(5/2) lam^(-1/2)
print("exp kappa:", 2 - F(5, 2), "exp lam:", 2 - F(5, 2))
