VERDICT: PASS with MINOR

# Referee report: slice C (TL_note.md §3, Lemma Δ)

Clean-context referee (subagent abb2e9fa6efc68d49 of session_01NMeKEismAyeqgdB4sy2NJU; author-side lane, not a nonauthor review); reviewed TL_note.md sha256 ab8a8314…98ba. No mathematical error found in §3. Every identity, constant and κ-exponent checked holds. The referee's own quadrature reproduces (Δ.1) and (Δ.2) uniformly in κ for m = 1 and m = 2; in the r → 0 limit the orders r and r²κ are attained, so (Δ.2) cannot be improved. (Recorded by the author from the referee's hand-back; the referee could not write files.)

## Findings

**C-01 (MINOR) — "The envelope".** The bounds `Γ̃ ≤ Γ̂`, `|Q₁| ≤ Q̂₁`, `|dQ₁/dz| ≤ Q̂₁/(11κ)` are stated "on the support of `G_s`", but "The edge" and (3.5) use them on all of `[23κ, 73κ]` for fixed `(T, ω)`. They hold there by the same argument. *Fix:* "For `z ∈ [23κ, 73κ]` (in particular on the support of `G_s`), with `|f₄| ≤ 12κ`, …".

**C-02 (MINOR) — Part F.** The tail bound `|f₄| ≥ max(11κ, 3|q| − 25κ)` is proved only near the edges. The kink terms, the interior term `2r|β|` of the first difference, and the cutoff term need `|f₄| ≥ max(11κ, 3|q| − 73κ) ≥ (κ + |q|)/3` on the window. All true; one sentence missing. *Fix:* add it, and write `1{24κ ≤ |z| < 72κ}` in the cutoff term.

**C-03 (NIT) — Part F.** For the lower edge the contribution is `+[Φ₋(a) + Φ₋(−a)]`; write `∓[Φ_±(a) + Φ_±(−a)]`.

**C-04 (NIT) — Part R, integration.** One `N` for two exponents; write `(1 + |O′|)^{N′}`.

**C-05 (NIT) — after the proof.** "O(t/κ) per unit of the window mass" should be "O(t) per unit of the window mass" (O(r) = O(t/κ) is the absolute size).

**C-06 (MINOR) — controls for §3.** T7's model omits the `c₁ρ` term, checks (3.5) with the exact Lipschitz constant, tests the signed first difference with `sup|w₀ + rβ|` instead of (3.7), and integrates only to `48κ` (no kink). T5 lacks the (Δ.1) slab rows of (3.7): `(2, 2)`, `(5/2, 3/2)`, `(3, 1)` with criterion `a − 2 − s ≤ 0` (checked by hand: `κ^{−2}`, `κ^{−1}`, `1`). No control tests: the parity; `37 ≥ 36 + 12c_e`; `ρ_z` and (3.3); (3.4); the envelope bounds for the true radial `Q₁`; the identity for `S(r) + S(−r) − 2S(0)` with its kink term; Part F. *Fix:* add the T5 rows; say in §7 what T7 does not model; list what no control covers.

**C-07 (NIT, remark).** The implied constant in (Δ.2) comes almost entirely from the cutoff (Chebyshev with `(rQ̂₁/(c_eκ))²`, factor `∝ 1/c_e² = 4·10⁴`). In an m = 1 law: `sup_{r,κ}|E[G_r + G_{−r} − 2G₀]|/(r²(1 + κ)) ≈ 4·10⁴` at `rκ ≈ 2^{−11}`, while the `r → 0` limit of the ratio is `≈ 1`. Suggest one sentence in §6.

## Numerical tests (work_C/)
- pointwise.py (mpmath, 30 digits; m = 1, 2; κ ∈ {1, 4, 20}; 32 cases with the true radial `Q₁` including `c₁ρ`): the identity for `S(r) + S(−r) − 2S(0)` to relative 1e-23; (3.5), (3.7), (3.3), the three term bounds, the envelope bounds and the derivative bound > 0.98 hold; the second difference scales as `r²`.
- m1_scaling.py, m1_asym.py (a law in 𝔏_× with corr(A, f₄) ≠ 0 and full Σ_O; closed-form f₄-integral checked against mpmath to 1e-14): `r^{−2}E[G_r + G_{−r} − 2G₀]/κ` → −1.88, −1.31, −1.08, −1.01, −0.990, −0.986, −0.985, −0.984 for κ = 1, 2, 4, …, 128 (finite r reproduces to 1e-4); with nonzero odd mean ≈ −1.08κ; `E|G_r − G_{−r}|/r` → 1.81, 2.27, 2.31, 2.32, 2.32 for κ = 1, 4, 16, 64, 256.
- m2_asym.py (QMC over A < 0; normalization 0.2113 vs MC 0.2110): `lim E|G_r − G_{−r}|/r` ≈ 3.1 → 3.6 over κ = 1 → 64; `lim r^{−2}(second difference)/κ` ≈ −3.9 → −2.1 ± 0.4.
- tl_exact.py: both modes byte-identical (2704 checks); M1, M6, M7, M8 exit 1 at T2, T3, T7, T4; an extra argument exits 2.

## Checked
(3.0) and parity; `G₀` = (0.2); (2.2) for `|s||Q₁| ≤ c_eκ`; (3.1) against [N] (0.1) (signs, factor 1/8, `P₁ = Δ²Q₁`); `dρ/dz`, the `c₁`, `c₂` bounds, (3.2); `ρ_z`, (3.3); `Γ̂`, `Q̂₁`, (3.4), (1.1). Part R: 𝒦^c ledgers; `z_e(s)`, derivative bound 0.9836; (3.5) with `2592/11 ≤ 236`; `Z = 48κ`, `w₀ ≥ 20κ²Δ²`; the identity and its three bounds; `24rQ̂₁`; (3.6), (3.7); slab supremum and dyadic sum. Part F: conditional law of `f₄`; only `z` depends on `f₄`; cutoff term; `e_±(s)` linear in `s`; the decomposition; kinks (`96 = 2·48`); tail estimate; first difference. Every κ-exponent of §3. Steps 3–4 of §4: (Δ.1) with p = 1 covers `|ℓ_r| ≤ C|O|`; (Δ.2) needs no weight; `Q̄_{r,0} ∈ 𝔏_×`; `r ≤ 1/κ` from `k ≤ 1`.

## Not checked
§2 (Lemma GE, Proposition RW); §§4–7 beyond Steps 3–4 and the controls; the proofs of W₁ and (B1)–(B5); numerically: (Δ.1) with weight p > 0, m ≥ 3, η correlated with f₄, Part F (O(e^{−cκ²}) in the test laws).
