"""m = 2: r -> 0 limits A2(kappa) = lim r^-2 E[G_r + G_-r - 2G_0] (no cutoff) and
A1(kappa) = lim r^-1 E|G_r - G_-r|, with f4 and Q1 integrated in closed form,
y = z - f4 by Gauss-Legendre panels, (lambda_1, lambda_2, phi, theta) by scrambled Sobol QMC."""
import sys
import numpy as np
from scipy.stats import qmc
from scipy.special import ndtr
SQ2PI = np.sqrt(2 * np.pi)

# law of (A11, A12, A22, f4): centred
SE = np.array([[1.0, 0.0, 1 / 3, 0.4], [0.0, 1 / 3, 0.0, 0.1], [1 / 3, 0.0, 1.0, 0.4], [0.4, 0.1, 0.4, 1.3]])
SETA = np.diag([0.8, 0.6])
rng0 = np.random.default_rng(7)
L = rng0.normal(size=(6, 6)) * 0.4
SO = L @ L.T + 0.6 * np.eye(6)          # (g1, g2, B11, B12, B22, f5)
SA = SE[:3, :3]; SAi = np.linalg.inv(SA); detSA = np.linalg.det(SA)
c4 = SE[3, :3] @ SAi; s4 = np.sqrt(SE[3, 3] - SE[3, :3] @ SAi @ SE[:3, 3])
Sg = SO[:2, :2]; Sgi = np.linalg.inv(Sg); detSg = np.linalg.det(Sg)
reg = SO[2:, :2] @ Sgi                   # E[(B,f5) | g] = reg g   (centred)
Scond = SO[2:, 2:] - SO[2:, :2] @ Sgi @ SO[:2, 2:]
assert np.all(np.linalg.eigvalsh(SE) > 0) and np.all(np.linalg.eigvalsh(SO) > 0)

def pA(a11, a12, a22):
    x = np.stack([a11, a12, a22])
    q = np.einsum('i...,ij,j...->...', x, SAi, x)
    return np.exp(-0.5 * q) / ((2 * np.pi) ** 1.5 * np.sqrt(detSA))

def gl(n, lo, hi):
    x, w = np.polynomial.legendre.leggauss(n)
    return 0.5 * (hi - lo) * x + 0.5 * (hi + lo), 0.5 * (hi - lo) * w

def check_norm(n=2 ** 16):
    s = qmc.Sobol(3, seed=1).random(n)
    l1, v, ph = 8 * s[:, 0], 8 * s[:, 1], np.pi * s[:, 2]
    l2 = l1 + v
    c, sn = np.cos(ph), np.sin(ph)
    a11 = -(l1 * c * c + l2 * sn * sn); a22 = -(l1 * sn * sn + l2 * c * c); a12 = -(l1 - l2) * c * sn
    est = np.mean(pA(a11, a12, a22) * (l2 - l1)) * 8 * 8 * np.pi
    x = np.random.default_rng(3).multivariate_normal(np.zeros(3), SA, size=400000)
    mc = np.mean((x[:, 0] < 0) & (x[:, 0] * x[:, 2] - x[:, 1] ** 2 > 0))
    return est, mc

def limits(kap, n=2 ** 14, seed=0, taumax=30.0, vmax=7.0, ny=24):
    s = qmc.Sobol(4, seed=seed).random(n)
    tau, v, ph, th = taumax * s[:, 0], vmax * s[:, 1], np.pi * s[:, 2], 2 * np.pi * s[:, 3]
    vol = taumax / kap * vmax * np.pi * 2 * np.pi / n
    l1 = tau / kap; l2 = l1 + v
    c, sn = np.cos(ph), np.sin(ph)
    a11 = -(l1 * c * c + l2 * sn * sn); a22 = -(l1 * sn * sn + l2 * c * c); a12 = -(l1 - l2) * c * sn
    wA = pA(a11, a12, a22) * (l2 - l1) * vol
    Delta2 = (l1 * l2) ** 2
    om = np.stack([np.cos(th), np.sin(th)])
    # (-A)^{-1} = R diag(1/l1, 1/l2) R^T ; omega in eigenbasis
    o1 = c * om[0] + sn * om[1]; o2 = -sn * om[0] + c * om[1]
    mu = o1 ** 2 / l1 + o2 ** 2 / l2
    m4 = c4[0] * a11 + c4[1] * a12 + c4[2] * a22
    panels = [(24 * kap - 9, 24 * kap + 9), (24 * kap + 9, 72 * kap - 9), (72 * kap - 9, 72 * kap + 9)]
    A1 = A2 = 0.0
    for lo, hi in panels:
        if hi <= lo:
            continue
        ys, wys = gl(ny, lo, hi)
        for y, wy in zip(ys, wys):
            rho2 = y / (3 * mu); rho = np.sqrt(rho2)
            g = rho * om
            pg = np.exp(-0.5 * np.einsum('i...,ij,j...->...', g, Sgi, g)) / (2 * np.pi * np.sqrt(detSg))
            jac = rho2 / (2 * y)
            # v = A^{-1} g = -(-A)^{-1} g, in original basis
            g1 = c * g[0] + sn * g[1]; g2 = -sn * g[0] + c * g[1]
            w1, w2 = -g1 / l1, -g2 / l2
            vv = np.stack([c * w1 - sn * w2, sn * w1 + c * w2])
            mO = reg @ g                                   # (B11, B12, B22, f5) means
            cO = np.stack([vv[0] ** 2 / 8, 2 * vv[0] * vv[1] / 8, vv[1] ** 2 / 8, np.full_like(vv[0], 1 / 120)])
            mQ = np.einsum('i...,i...->...', cO, mO)
            vQ = np.einsum('i...,ij,j...->...', cO, Scond, cO) + np.einsum('i...,ij,j...->...', vv, SETA, vv) / 144
            sQ = np.sqrt(vQ)
            EabsQ = sQ * np.sqrt(2 / np.pi) * np.exp(-0.5 * mQ ** 2 / vQ) + mQ * (1 - 2 * ndtr(-mQ / sQ))
            m = m4 + y
            phi = lambda z: np.exp(-0.5 * ((z - m) / s4) ** 2) / (s4 * SQ2PI)
            dphi24 = -(24 * kap - m) / s4 ** 2 * phi(24 * kap)
            Pwin = ndtr((72 * kap - m) / s4) - ndtr((24 * kap - m) / s4)
            base = wA * pg * jac * wy * Delta2 / 144
            A2 += np.sum(base * (mQ ** 2 + vQ) * (-5971968 * kap ** 2 * dphi24 + 20736 * kap * phi(72 * kap)
                                                   - 62208 * kap * phi(24 * kap)))
            A1 += np.sum(base * EabsQ * (331776 * kap ** 2 * phi(24 * kap) + 3456 * kap * Pwin))
    return A1, A2

if __name__ == '__main__':
    print('normalisation check P(A<0): param', check_norm())
    for kap in (1.0, 2.0, 4.0, 8.0, 16.0, 32.0, 64.0):
        vals = np.array([limits(kap, seed=sd) for sd in range(4)])
        mA1, mA2 = vals.mean(0)
        eA1, eA2 = vals.std(0) / 2
        print(f"kap={kap:5.1f}  A1={mA1:.4f}+-{eA1:.4f}   A2/kap={mA2/kap:+.4f}+-{eA2/kap:.4f}", flush=True)
