"""Pointwise check of Part R on K: identity for S(r)+S(-r)-2S(0), (3.5), the three term bounds, (3.7), (3.3).
Fixed (T, omega); true radial Q1(z) (with the c1*rho term) and true Gaussian rho_z.  mpmath, 30 digits."""
import random, sys
import mpmath as mp
mp.mp.dps = 30
CE = mp.mpf(1) / 200

def rand_spd(m, rng, lo, hi):
    # random symmetric with eigenvalues in [lo, hi]
    th = rng.uniform(0, 3.14159)
    if m == 1:
        return mp.matrix([[rng.uniform(lo, hi)]])
    R = mp.matrix([[mp.cos(th), -mp.sin(th)], [mp.sin(th), mp.cos(th)]])
    D = mp.diag([rng.uniform(lo, hi), rng.uniform(lo, hi)])
    return R * D * R.T

def case(rng, m, kap):
    # A < 0 with lambda ~ 1/kappa scale
    lam_small = mp.mpf(rng.uniform(0.2, 3.0)) / kap
    if m == 1:
        A = mp.matrix([[-lam_small]])
    else:
        th = rng.uniform(0, 3.14159)
        R = mp.matrix([[mp.cos(th), -mp.sin(th)], [mp.sin(th), mp.cos(th)]])
        A = -(R * mp.diag([lam_small, mp.mpf(rng.uniform(0.5, 2.0))]) * R.T)
    lam = min(abs(e) for e in mp.eig(A)[0])
    Ainv = A ** -1
    if m == 1:
        om = mp.matrix([[rng.choice([-1, 1])]])
    else:
        ph = rng.uniform(0, 6.2832)
        om = mp.matrix([[mp.cos(ph)], [mp.sin(ph)]])
    eta = mp.matrix([[rng.uniform(-2, 2)] for _ in range(m)])
    B = rand_spd(m, rng, -2, 2)
    f5 = mp.mpf(rng.uniform(-3, 3))
    f4 = mp.mpf(rng.uniform(-11.9, 11.9)) * kap
    Sig = rand_spd(m, rng, 0.5, 2.0)
    c0s = min(mp.eig(Sig)[0])
    mug = mp.matrix([[rng.uniform(-1.5, 1.5)] for _ in range(m)])
    return A, Ainv, lam, om, eta, B, f5, f4, Sig, c0s, mug

def run(seed, m, kap, frac):
    rng = random.Random(seed)
    kap = mp.mpf(kap)
    A, Ainv, lam, om, eta, B, f5, f4, Sig, c0s, mug = case(rng, m, kap)
    Delta = mp.det(A)
    mu = (om.T * (-Ainv) * om)[0]
    c0 = f5 / 120
    c1 = -(eta.T * Ainv * om)[0] / 12
    c2 = (om.T * Ainv * B * Ainv * om)[0] / 8
    normB = max(abs(e) for e in mp.eig(B)[0])
    neta = mp.sqrt((eta.T * eta)[0])
    Ghat = mp.sqrt(85 * kap / (3 * lam))
    Qhat = abs(f5) / 120 + neta * Ghat / 12 + normB * Ghat ** 2 / 8
    r = frac * CE * kap / Qhat          # r Qhat = frac * c_e * kappa  (T in K)
    r = min(r, 1 / kap)
    rho = lambda z: mp.sqrt((z - f4) / (3 * mu))
    Q1 = lambda z: c0 + c1 * rho(z) + c2 * rho(z) ** 2
    dQ1 = lambda z: (c1 + 2 * c2 * rho(z)) * rho(z) / (2 * (z - f4))
    Siginv = Sig ** -1
    detS = mp.det(Sig)
    def pg(g):
        d = g - mug
        return mp.exp(-(d.T * Siginv * d)[0] / 2) / ((2 * mp.pi) ** (mp.mpf(m) / 2) * mp.sqrt(detS))
    rz = lambda z: pg(rho(z) * om) * rho(z) ** m / (2 * (z - f4))
    w0 = lambda z: Delta ** 2 / 144 * (5184 * kap ** 2 - z ** 2)
    beta = lambda z: 12 * kap * Delta ** 2 * Q1(z)
    out = {}
    # envelope checks on [23k, 73k]
    zs = [23 * kap + 50 * kap * i / 400 for i in range(401)]
    out['Q1<=Qhat'] = all(abs(Q1(z)) <= Qhat for z in zs)
    out['dQ1<=Qhat/(z-f4)'] = all(abs(dQ1(z)) <= Qhat / (z - f4) for z in zs)
    out['edge-map-deriv>0.98'] = all(1 - 36 * s * dQ1(z) > mp.mpf('0.98') for z in zs for s in (r, -r))
    # (3.3)
    def dlog(z):
        h = mp.mpf('1e-12') * kap
        return (mp.log(rz(z + h)) - mp.log(rz(z - h))) / (2 * h)
    def dlog_bound(z):
        g = rho(z) * om
        v = Siginv * (g - mug)
        return (rho(z) * mp.sqrt((v.T * v)[0]) / 2 + abs(m - 2) / mp.mpf(2)) / (z - f4)
    out['(3.3)'] = all(abs(dlog(z)) <= dlog_bound(z) * (1 + mp.mpf('1e-8')) for z in zs[::20])
    ze = lambda s: mp.findroot(lambda z: z - 24 * kap - 36 * s * Q1(z), 24 * kap)
    zp, zm = ze(r), ze(-r)
    dp, dm = zp - 24 * kap, zm - 24 * kap
    out['ze in (23.8k,24.2k)'] = all(23.8 * kap < x < 24.2 * kap for x in (zp, zm))
    out['(3.5)'] = abs(dp + dm) <= 236 * r ** 2 * Qhat ** 2 / kap
    Z = 48 * kap
    def S(s, z0):
        f = lambda z: max(w0(z) + s * beta(z), 0) * rz(z)
        return mp.quad(f, [z0, Z, 71.8 * kap, 72 * kap, 72.2 * kap, 73 * kap])
    S_p, S_m, S_0 = S(r, zp), S(-r, zm), S(0, 24 * kap)
    second = S_p + S_m - 2 * S_0
    Fz = lambda z: w0(z) * rz(z)
    Phi = lambda x: mp.quad(Fz, [24 * kap, x])
    t1 = -(Phi(zp) + Phi(zm))
    t2 = r * mp.quad(lambda z: beta(z) * rz(z), [zp, zm])
    t3 = mp.quad(lambda z: (max(w0(z) + r * beta(z), 0) + max(w0(z) - r * beta(z), 0) - 2 * max(w0(z), 0)) * rz(z),
                 [Z, 71.8 * kap, 72 * kap, 72.2 * kap, 73 * kap])
    out['identity_relerr'] = mp.nstr(abs(second - (t1 + t2 + t3)) / max(abs(second), mp.mpf('1e-40')), 3)
    # bounds of the three terms
    grid = lambda lo, hi, n=200: [lo + (hi - lo) * i / n for i in range(n + 1)]
    Fp = lambda z: mp.diff(Fz, z)
    supFp = max(abs(Fp(z)) for z in grid(23.8 * kap, 24.2 * kap, 60))
    sup_rz_24 = max(rz(z) for z in grid(23.8 * kap, 24.2 * kap))
    sup_rz_72 = max(rz(z) for z in grid(71 * kap, 73 * kap))
    b1 = Fz(24 * kap) * 236 * r ** 2 * Qhat ** 2 / kap + (36 * r * Qhat) ** 2 * supFp
    b2 = r * 72 * r * Qhat * 12 * kap * Delta ** 2 * Qhat * sup_rz_24
    b3 = 48 * r * Qhat * 12 * kap * r * Delta ** 2 * Qhat * sup_rz_72
    out['t1<=b1'] = abs(t1) <= b1
    out['t2<=b2'] = abs(t2) <= b2
    out['t3<=b3'] = abs(t3) <= b3 * (1 + mp.mpf('1e-6'))
    # (3.6)-type constant: second / (r^2 kap Delta^2 Qhat^2 * sum sup (1+rho^2+|mug|^2) rz)
    nm = (mug.T * mug)[0]
    sup6 = sum(max((1 + rho(z) ** 2 + nm) * rz(z) for z in grid(x0 - kap, x0 + kap)) for x0 in (24 * kap, 72 * kap))
    out['C(3.6)'] = mp.nstr(abs(second) / (r ** 2 * kap * Delta ** 2 * Qhat ** 2 * sup6), 4)
    # (3.7)
    g = lambda z: abs(max(w0(z) + r * beta(z), 0) * (z >= zp) - max(w0(z) - r * beta(z), 0) * (z >= zm)) * rz(z)
    lhs7 = mp.quad(g, [23 * kap, min(zp, zm), max(zp, zm), Z, 71.8 * kap, 72 * kap, 72.2 * kap, 73 * kap])
    rhs7 = 72 * r * Qhat * 37 * kap ** 2 * Delta ** 2 * sup_rz_24 + 24 * kap * r * mp.quad(
        lambda z: Delta ** 2 * abs(Q1(z)) * rz(z), [23 * kap, 73 * kap])
    out['(3.7)'] = lhs7 <= rhs7
    out['r'] = mp.nstr(r, 4); out['second'] = mp.nstr(second, 4); out['lhs7/r'] = mp.nstr(lhs7 / r, 4)
    return out

if __name__ == '__main__':
    bad = 0
    for m in (1, 2):
        for kap in (1, 4, 20):
            for seed in range(4):
                for frac in (0.9, 0.2):
                    o = run(1000 * m + 10 * kap + seed, m, kap, frac)
                    flags = [k for k, v in o.items() if v is False]
                    bad += len(flags)
                    print(m, kap, seed, frac, 'FAIL:' + ','.join(flags) if flags else 'ok',
                          'idrel', o['identity_relerr'], 'C36', o['C(3.6)'], 'r', o['r'], '2nd', o['second'])
    print('total failing flags', bad)
