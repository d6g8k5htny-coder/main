"""m = 1: (a) A2(kappa) = lim_{r->0} r^{-2} E[(G_r + G_-r - 2G_0)] without cutoff, via
J''(0) = -5971968 k^2 Q^2 phi'(24k) + 20736 k Q^2 phi(72k) - 62208 k Q^2 phi(24k)   (times a^2/144),
(b) D2 split into the cutoff part and the rest, for a range of r."""
import sys
import numpy as np
import m1_scaling as M

def fields(kap, law, nv, ny, taumax=36.0):
    vv, wv = M.gl(nv, 0.0, np.sqrt(taumax))
    tau, wtau = vv ** 2, wv * 2 * vv
    panels = [(24 * kap - 12, 24 * kap + 12), (24 * kap + 12, 72 * kap - 12), (72 * kap - 12, 72 * kap + 12)]
    ys, wys = [], []
    for lo, hi in panels:
        if hi > lo:
            x, w = M.gl(ny, max(lo, 1e-9), hi); ys.append(x); wys.append(w)
    y, wy = np.concatenate(ys), np.concatenate(wys)
    T, Y = np.meshgrid(tau, y, indexing='ij')
    A = -T / kap
    base0 = (wtau * np.exp(-0.5 * (tau / kap) ** 2) / (M.SQ2PI * kap))[:, None] * wy[None, :]
    res = []
    for sgn in (1.0, -1.0):
        g = sgn * np.sqrt(T * Y / (3 * kap))
        jac = np.sqrt(T / (3 * kap)) / (2 * np.sqrt(Y))
        mug, sgg = law['muO'][0], law['sgg']
        pg = np.exp(-0.5 * (g - mug) ** 2 / sgg) / np.sqrt(2 * np.pi * sgg)
        mB5 = law['muO'][1:, None, None] + law['reg'][:, None, None] * (g - mug)
        c0, c1 = g * g / (8 * A * A), 1 / 120.0
        mQ = c0 * mB5[0] + c1 * mB5[1]
        S = law['Scond']
        vQ = c0 ** 2 * S[0, 0] + 2 * c0 * c1 * S[0, 1] + c1 ** 2 * S[1, 1] + (g / (12 * A)) ** 2 * M.SETA
        res.append((A, Y, mQ, vQ, base0 * pg * jac))
    return res

def A2(kap, law, nv=140, ny=64):
    sig4 = np.sqrt(M.S4 - M.CA4 ** 2 / M.SA ** 2)
    tot, parts = 0.0, np.zeros(3)
    for A, Y, mQ, vQ, base in fields(kap, law, nv, ny):
        m = M.CA4 / M.SA ** 2 * A + Y
        phi = lambda z: np.exp(-0.5 * ((z - m) / sig4) ** 2) / (sig4 * M.SQ2PI)
        dphi = lambda z: -(z - m) / sig4 ** 2 * phi(z)
        Q2 = mQ ** 2 + vQ
        pre = base * A * A / 144 * Q2
        p = [np.sum(pre * (-5971968 * kap ** 2 * dphi(24 * kap))), np.sum(pre * 20736 * kap * phi(72 * kap)),
             np.sum(pre * (-62208 * kap * phi(24 * kap)))]
        parts += np.array(p)
    return parts.sum(), parts

def split(kap, r, law, nv=100, ny=48, nu=40, umax=10.0):
    sig4 = np.sqrt(M.S4 - M.CA4 ** 2 / M.SA ** 2)
    xg, wg = np.polynomial.legendre.leggauss(nu)
    out = np.zeros(3)   # E[G0], pass part, fail part
    cut = M.CE * kap / r
    for A, Y, mQ, vQ, base in fields(kap, law, nv, ny):
        sQ = np.sqrt(vQ)
        bps = np.stack([np.full_like(mQ, -umax), np.clip((-cut - mQ) / sQ, -umax, umax),
                        np.clip((cut - mQ) / sQ, -umax, umax), np.full_like(mQ, umax)])
        M4 = M.CA4 / M.SA ** 2 * A
        acc = np.zeros((3,) + mQ.shape)
        for k in range(3):
            lo, hi = bps[k], bps[k + 1]
            half = 0.5 * (hi - lo)
            for xi, wi in zip(xg, wg):
                u = 0.5 * (hi + lo) + half * xi
                Q = mQ + sQ * u
                w = wi * half * M.pdf(u)
                h0 = M.H(0.0, kap, A, Y, Q, M4, sig4)
                hp = M.H(r, kap, A, Y, Q, M4, sig4)
                hm = M.H(-r, kap, A, Y, Q, M4, sig4)
                ok = np.abs(r * Q) <= M.CE * kap
                acc[0] += w * h0
                acc[1] += w * np.where(ok, (hp - h0) + (hm - h0), 0.0)
                acc[2] += w * np.where(ok, 0.0, -2 * h0)
        out += np.array([np.sum(base * acc[i]) for i in range(3)])
    return out

if __name__ == '__main__':
    muO = [0.0, 0.0, 0.0] if len(sys.argv) < 2 else [float(x) for x in sys.argv[1].split(',')]
    law = M.setup(muO)
    print('muO', muO)
    for kap in (1.0, 2.0, 4.0, 8.0, 16.0, 32.0, 64.0, 128.0):
        a2, parts = A2(kap, law)
        print(f"kap={kap:6.1f}  A2/kap={a2/kap:+.6e}  parts/kap={parts[0]/kap:+.4e},{parts[1]/kap:+.4e},{parts[2]/kap:+.4e}", flush=True)
