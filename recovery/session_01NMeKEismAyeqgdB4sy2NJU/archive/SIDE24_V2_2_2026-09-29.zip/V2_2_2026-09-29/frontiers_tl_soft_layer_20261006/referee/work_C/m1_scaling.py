"""m = 1: E[G_r + G_{-r} - 2G_0] and E|G_r - G_{-r}| by deterministic quadrature.
Law in L_x: E=(a,f4,eta) centred, O=(gamma,B,f5) ~ N(muO, SigO), E indep of O.
f4 integrated in closed form; (tau, y, u) by Gauss-Legendre, u split at the cutoff."""
import sys
import numpy as np
from scipy.special import ndtr
CE = 1.0 / 200
SQ2PI = np.sqrt(2 * np.pi)

# law
SA, S4, CA4, SETA = 1.0, 1.3, 0.45, 0.8
SigO = np.array([[1.0, 0.35, 0.2], [0.35, 1.4, 0.1], [0.2, 0.1, 2.0]])

def setup(muO):
    sgg = SigO[0, 0]
    reg = SigO[1:, 0] / sgg                       # regression of (B, f5) on gamma
    Scond = SigO[1:, 1:] - np.outer(SigO[1:, 0], SigO[0, 1:]) / sgg
    return dict(muO=np.array(muO), sgg=sgg, reg=reg, Scond=Scond)

def pdf(u):
    return np.exp(-0.5 * u * u) / SQ2PI

def pdiff(u1, u2):
    both_pos = u1 > 0
    return np.where(both_pos, ndtr(-u1) - ndtr(-u2), ndtr(u2) - ndtr(u1))

def quad_int(R2, z1, z2, m, sig):
    """int_{z1}^{z2} (R2 - z^2) phi(z; m, sig^2) dz, elementwise; zero if z2 <= z1."""
    z2 = np.maximum(z2, z1)
    u1, u2 = (z1 - m) / sig, (z2 - m) / sig
    M0 = pdiff(u1, u2)
    p1, p2 = pdf(u1), pdf(u2)
    M1 = p1 - p2
    M2 = M0 + u1 * p1 - u2 * p2
    return (R2 - m * m) * M0 - 2 * m * sig * M1 - sig * sig * M2

def const_int(z1, z2, m, sig):
    z2 = np.maximum(z2, z1)
    return pdiff((z1 - m) / sig, (z2 - m) / sig)

def H(s, kap, a, y, Q, m4, sig4):
    """E[G_s | a, gamma, Q1] with f4 ~ N(m4, sig4^2); z = f4 + y."""
    on = np.abs(s * Q) <= CE * kap
    E = 24 * kap + 36 * s * Q
    R2 = 5184 * kap ** 2 + 1728 * kap * s * Q
    R = np.sqrt(np.maximum(R2, 0.0))
    m = m4 + y
    val = quad_int(R2, E, R, m, sig4) + quad_int(R2, -R, -E, m, sig4)
    return np.where(on & (R2 > 0), a * a / 144 * val, 0.0)

def Habs(r, kap, a, y, Q, m4, sig4):
    """E[|G_r - G_{-r}| | a, gamma, Q1], positive branch (negative branch is O(e^{-250}))."""
    on = r * np.abs(Q) <= CE * kap
    sg = np.where(Q >= 0, 1.0, -1.0)
    sp, sm = sg * r, -sg * r                       # sp: larger E and R; sm: smaller E and R
    Ep, Em = 24 * kap + 36 * sp * Q, 24 * kap + 36 * sm * Q
    R2p, R2m = 5184 * kap ** 2 + 1728 * kap * sp * Q, 5184 * kap ** 2 + 1728 * kap * sm * Q
    Rp, Rm = np.sqrt(R2p), np.sqrt(R2m)
    m = m4 + y
    v = quad_int(R2m, Em, Ep, m, sig4) + np.abs(R2p - R2m) * const_int(Ep, Rm, m, sig4) + quad_int(R2p, Rm, Rp, m, sig4)
    return np.where(on, a * a / 144 * v, 0.0)

def gl(n, lo, hi):
    x, w = np.polynomial.legendre.leggauss(n)
    return 0.5 * (hi - lo) * x + 0.5 * (hi + lo), 0.5 * (hi - lo) * w

def compute(kap, r, law, nv=100, ny=48, nu=40, umax=10.0, taumax=36.0):
    vv, wv = gl(nv, 0.0, np.sqrt(taumax))
    tau, wtau = vv ** 2, wv * 2 * vv
    a = -tau / kap
    pa = np.exp(-0.5 * a * a / SA ** 2) / (SA * SQ2PI)
    m4 = CA4 / SA ** 2 * a
    sig4 = np.sqrt(S4 - CA4 ** 2 / SA ** 2)
    panels = [(24 * kap - 12, 24 * kap + 12), (24 * kap + 12, 72 * kap - 12), (72 * kap - 12, 72 * kap + 12)]
    ys, wys = [], []
    for lo, hi in panels:
        if hi > lo:
            x, w = gl(ny, max(lo, 1e-9), hi)
            ys.append(x); wys.append(w)
    y, wy = np.concatenate(ys), np.concatenate(wys)
    T, Y = np.meshgrid(tau, y, indexing='ij')
    A = -T / kap
    out = np.zeros(4)                               # E[G0], second diff, E|Gr-G-r|, E[(Gr - G-r)]
    for sgn in (1.0, -1.0):
        g = sgn * np.sqrt(T * Y / (3 * kap))
        jac = np.sqrt(T / (3 * kap)) / (2 * np.sqrt(Y))
        mug, sgg = law['muO'][0], law['sgg']
        pg = np.exp(-0.5 * (g - mug) ** 2 / sgg) / np.sqrt(2 * np.pi * sgg)
        mB5 = law['muO'][1:, None, None] + law['reg'][:, None, None] * (g - mug)
        cvec = np.stack([g * g / (8 * A * A), np.full_like(g, 1 / 120.0)])  # coefficients of (B, f5)
        mQ = cvec[0] * mB5[0] + cvec[1] * mB5[1]
        S = law['Scond']
        vQ = (cvec[0] ** 2 * S[0, 0] + 2 * cvec[0] * cvec[1] * S[0, 1] + cvec[1] ** 2 * S[1, 1]
              + (g / (12 * A)) ** 2 * SETA)
        sQ = np.sqrt(vQ)
        # u pieces split at cutoff
        cut = CE * kap / r
        bps = np.stack([np.full_like(mQ, -umax), np.clip((-cut - mQ) / sQ, -umax, umax),
                        np.clip((cut - mQ) / sQ, -umax, umax), np.full_like(mQ, umax)])
        xg, wg = np.polynomial.legendre.leggauss(nu)
        acc = np.zeros((4,) + mQ.shape)
        M4 = (CA4 / SA ** 2) * A
        for k in range(3):
            lo, hi = bps[k], bps[k + 1]
            half = 0.5 * (hi - lo)
            for xi, wi in zip(xg, wg):
                u = 0.5 * (hi + lo) + half * xi
                Q = mQ + sQ * u
                w = wi * half * pdf(u)
                h0 = H(0.0, kap, A, Y, Q, M4, sig4)
                hp = H(r, kap, A, Y, Q, M4, sig4)
                hm = H(-r, kap, A, Y, Q, M4, sig4)
                acc[0] += w * h0
                acc[1] += w * ((hp - h0) + (hm - h0))
                acc[2] += w * Habs(r, kap, A, Y, Q, M4, sig4)
                acc[3] += w * (hp - hm)
        base = (wtau * np.exp(-0.5 * (tau / kap) ** 2) / (SQ2PI * kap))[:, None] * wy[None, :] * pg * jac
        out += np.array([np.sum(base * acc[i]) for i in range(4)])
    return out

if __name__ == '__main__':
    muO = [0.0, 0.0, 0.0] if len(sys.argv) < 2 else [float(x) for x in sys.argv[1].split(',')]
    law = setup(muO)
    print('muO', muO)
    for kap in (1.0, 2.0, 4.0, 8.0, 16.0, 32.0):
        for j in (1, 3, 5, 7, 9, 11):
            r = 2.0 ** (-j) / kap
            g0, d2, d1, d1s = compute(kap, r, law)
            print(f"kap={kap:5.1f} r*kap=2^-{j:<2d} E[G0]*kap={g0*kap:.6e}  D2/(r^2 kap)={d2/(r*r*kap):+.5e}  "
                  f"E|Gr-G-r|/r={d1/r:.5e}  E[Gr-G-r]/r={d1s/r:+.4e}", flush=True)
