VERDICT: PASS with MINOR

# Referee report: slices A and B (TL_note.md §§0–2)

Clean-context referee (subagent a6bb85de01b529e57 of session_01NMeKEismAyeqgdB4sy2NJU; author-side lane, not a nonauthor review); reviewed TL_note.md sha256 ab8a8314…98ba. Scope: everything before "## 3. Parity and the edge shift". No BLOCKING or MAJOR issue. Two MINOR gaps (AB-01, AB-02) need one-line fixes; the rest are NITs. (Recorded by the author from the referee's hand-back; the referee could not write files.)

## Findings

**AB-01 (MINOR) — §1, definition of `𝒩` and "So every pathwise statement of [N] holds with this `𝒩`".** [N] Lemma Q′ and Lemma R₂, and #220 §1, assume `𝒩 ≥ max(1, ‖f‖_{C^q})` with order 0 included; #220 (F1)–(F2) and Lemma Ω use `𝒩_r = 1 + k + ‖F_r‖_{C⁹}`. For `f − f(M)` one has `sup|f − f(M)| ≤ (√d L/2) sup|∇f|`, so the cited statements hold with `C_L𝒩`, `C_L := max(1, √dL/2)`. *Fix:* apply them to `f − f(M)` and absorb `C_L` into `C₄`, `C₁₂`, `c₄`, `N`.

**AB-02 (MINOR) — Lemma GE (c), the `ϑ` bullets.** `ζ, ε̃/κ ≤ c_e` only gives `ϑ ≤ C₁₀(2c_e² + o(1))`, and [N] does not quantify `C₁₀`. The conclusion holds because (b) shows `ζ` and `ε̃/κ` tend to 0. *Fix:* use the explicit bounds of (b), add the lower-order terms of `ε₂′/κ` (`𝒩r²/κ ≤ c₄r`, `𝒩²r²/(λκ) ≤ c₄/C₄`), "for `C₄` large and `c₄` small".

**AB-03 (NIT) — §1 after (B5).** "(B4) holds for every law in `𝔏`" is too strong for the clause on the means; the small-ball bounds hold (conditional mean affine, of size `≤ C(1 + |rest|)`); the stated form of the means holds in `𝔏_×`.

**AB-04 (NIT) — Lemma W₂.** The proof gives `(1 + |O′|)^{M+m+2N}`, not `(1 + |O′|)^N`. In the second statement the conditioning is on `T ∖ {A}`; say why (B4) applies (`E ⊥ O` in `𝔏_×`).

**AB-05 (NIT) — Proposition RW, edge set, `|f₄| > 13κ`.** "beats every power of `|μ₄|`" is false; use §3's wording `≤ C_N(1 + |μ₄|)^{N′}(κ + |q|)^{−N}`.

**AB-06 (NIT) — Lemma GE constants.** State `N₂ ≥ max(N₁, m − 1)` and `r₄ ≤ min(r_0^*, r_Q, 1/10)`; rename the note's `c₄` (collides with [N] §3's `c₄`).

**AB-07 (NIT) — Proposition RW.** "(K1) gives `ω_r ≤ C(1 + κ)²𝒩^N`": (K1) is an expectation bound; cite [K] §2's pathwise bound. §8 slice B says "both tables"; §2 has one.

## Checked
(0.1) against #237 (R.1) (Tonelli; the constant-shift remark is not needed); (0.2) against #242 (0.1)–(0.2) and #237 Step U4 (window and `w₀` identity); parity of `z, w₀, Δ, Γ̃` (even) and `Q₁, P₁` (odd) against [N] (0.1); sympy algebra for m = 1, 2, 3 (`P₁ = Δ²Q₁`, `Y′ = Δz/12`, `w₀`, [N] (4.2)); (B1)–(B3), (B5) against #237 (R.2), (R.4), §2 and #218 Step F1; (B4) against #218 Lemma D; 𝔏, 𝔏_×; (1.1); W₁ (both cases); W₂ (polar Jacobian, slab bounds, ratio — exact max 15/7 at `x₀ = 24κ`, 41/7 valid — Gaussian sup, dyadic layers with `N > s + 1`); (2.1)–(2.2) and 𝔊 (`λ₄` = [N]'s `λ₂′` with `|η|`); GE (a)–(c) margin by margin against (Q′1)–(Q′4), R₂, Q″ (`J_±`, `t ↔ z`), [N] Step N1, #218 Step C1, #220 (F1); arithmetic (`175²·72`, `576`, `31680`, `(72/C₄)^{1/2}`, `C₄ ≥ 72(175/4)²` for (Q′2), `2c_e/3 < δ_e`, `36c_e < 72δ_e`); Proposition RW (decomposition, `|ε_ω|`, 𝔅_a–𝔅_d, 𝒩-layers, both edge cases, W₂ hypotheses, every `(a, s)` entry); `tl_exact.py` passes (2704 checks). Scripts: work_AB/check_arith.py, check_42.py.

## Not checked
§§3–7 (except the forward reference (3.2)); internal proofs of consumed results ([N] Q′, Q″, R₂, Ω; #220 (F1)–(F2); #237 Lemma R; #218 Lemma D; #242 Theorem 1); [P], [R], #187; `tl_exact.py` beyond its pass status.
