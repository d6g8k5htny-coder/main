import sys
p = '/tmp/claude-0/-home-claude/b41b316f-232c-5cf7-a0ee-80f0de603a6f/scratchpad/tla/TL_draft.md'
s = open(p).read()

def rep(old, new, count=1):
    global s
    c = s.count(old)
    if c != count:
        sys.stderr.write("COUNT %d != %d for:\n%s\n" % (c, count, old[:200]))
        sys.exit(1)
    s = s.replace(old, new)

# ---- rename the note's c4 -> c13 (8 occurrences, all the note's own constant) ----
assert s.count('c₄') == 9 or True
n_c4 = s.count('c₄')
s = s.replace('c₄', 'c₁₃')

# ---- header: TL2 bullet (D-10) ----
rep("""`J_ℓ(y) = F̄₀ + O(ℓ^{1/5})` uniformly on compact `y`-bands. The band
  `a ≤ k³/r ≤ b` therefore carries the cusp kernel's own share `(ℓ^{1/2}/10)F̄₀∫_a^b y^{−3/2}dy` up to `O(ℓ^{7/10})`, and no
  other half-power mass.""",
"""`J_ℓ(y) = F̄₀ + O(ℓ^{1/5})` uniformly on compact `y`-bands. The band
  `y₁ ≤ k³/r ≤ y₂` therefore carries the cusp kernel's own share `(ℓ^{1/2}/10)F̄₀∫_{y₁}^{y₂}y^{−3/2}dy` up to `O(ℓ^{7/10})`,
  and no other half-power mass.""")

# ---- header: TL3 bullet (D-01) ----
rep("""  `O(ℓ^{2/3})`, and `ρ_rej` has the same remainder. This improves #229's `3/7`. The remainder now comes from #229's bound on
  the intermediate elder mass.""",
"""  `O(ℓ^{2/3})`, and `ρ_rej` has the same remainder. This improves #229's `3/7`. Three terms attain the exponent `4/9`: the
  cusp-kernel error on `κ ≤ 1` (`ρ²`), the cusp tail (`ℓ²ρ^{−7}`), and #229's bound on the intermediate elder mass, which
  also carries the logarithm.""")

# ---- header: Consumed (D-02) ----
rep("""- [N] = #240 `frontiers/elder_cusp_parity_20261002/PROOF.md` (blob `16a1db06`): §0 notation and (0.1); Lemma Q′; §2 (2.2)–(2.3)
  and the `𝔅_λ′` computation; Lemma CU.1″; Lemma R₂ (3.2); the model near the edges and Lemma Q″ (3.5); Lemma Ω (4.1)–(4.2);
  Step N1 (typing) and Step N2 (the case `|Δ|` small).
- #237 `frontiers/candidate_parity_rate_20261001/PROOF.md` (blob `a97bf528`): Lemma R (R.1)–(R.4); the moment bound for `T`
  under `Q̄_{r,k}` (§2); Lemma U (U.1), Lemma K (K.1) and §5's main-term computation; Step U4.
- #242 `frontiers/soft_rejected_pairs_20261002/PROOF.md` (blob `271412db`): (0.2) and Theorem 1 with Remark 3.
- #220 `frontiers/elder_third_order_20261001/PROOF.md` (blob `c8767dde`): (F2), Lemma G and its proof; §0's identities for
  `ν_eld` and `cℓ^{−1/3}`.""",
"""- [N] = #240 `frontiers/elder_cusp_parity_20261002/PROOF.md` (blob `16a1db06`): §0 notation and (0.1); Lemma Q′; Proposition
  CE⁺⁺ with (2.2)–(2.3), (CE⁺⁺.1), its radius `r₂′` and the `𝔅_λ′` computation; Lemma R₂ (3.2); the model near the edges
  and Lemma Q″ (3.5); Lemma Ω (4.1)–(4.2); Step N1 (typing, the weight, the margins, `N₂`).
- #237 `frontiers/candidate_parity_rate_20261001/PROOF.md` (blob `a97bf528`): Lemma R (R.1)–(R.4); the moment bound for `T`
  under `Q̄_{r,k}` (§2); Step U2 (Case 3) and Step U4; Lemma U (U.1) with its radius `r₃`, Lemma K (K.1) and §5's main-term
  computation; Theorem P (P.1).
- #242 `frontiers/soft_rejected_pairs_20261002/PROOF.md` (blob `271412db`): §0, with (0.2) and the identity
  `I^{cand} − c₁ = ∫_0^∞∫∫𝒜^{rej}(b, s^{−4}, u) db dσ(u) ds`; Theorem 1 (1.0) with Remark 3.
- #220 `frontiers/elder_third_order_20261001/PROOF.md` (blob `c8767dde`): §0's identities for `ν_eld` and `cℓ^{−1/3}`, and
  `P`; §1's `r_Q`; (F1), (F2); Step E2 (the `𝒩`-layers); the proof of Lemma G (the Gaussian score along an interpolation of
  Gaussian laws); §4's `r_0^* ≤ r_0^{[K]}`.""")
rep("""- [K] `frontiers/c7_total_bounded_20260929/PROOF.md` (blob `28748b08`): (K1), (K2), with `ERRATUM_NORMALIZED_FORM.md`
  (blob `b6764ce6`), which does not touch them.""",
"""- #218 Step F1 is consumed through #237.
- [K] `frontiers/c7_total_bounded_20260929/PROOF.md` (blob `28748b08`): §2's pathwise bound on `W_r/r²`; (K2); §4's use of
  the cap implication of [P] §8. `ERRATUM_NORMALIZED_FORM.md` (blob `b6764ce6`) does not touch them.
- [R] `frontiers/three_fronts_20260924/LIFETIME_REMAINDER.md` (blob `247b3ecf`): (R5), the Gaussian bound on `π_r(v_r)`.""")
rep("""- #218 `frontiers/candidate_third_order_20261001/PROOF.md` (blob `70ca57ef`): Lemma D (1.1); Step C1 (its three cases).""",
"""- #218 `frontiers/candidate_third_order_20261001/PROOF.md` (blob `70ca57ef`): Step F1 (the free jets `J′`); Lemma D (1.1);
  Step C1 (its three cases).""")
rep("""- #218 Step F1 is consumed through #237.
""", "")

# ---- header: Cited only (D-02) ----
rep("""**Cited only.** #243 (Theorem FL), #244, #170/#175, and the QS chain A4–A4.3 (rates at fixed `k` in a compact set, a
different regime); main#259 6001580409 ((TL_a) and its consequences), 6001189633 (Sol's criterion), 6001319075 and 6001313460
(the TAIL-L and TAIL-S obstructions).""",
"""**Cited only.** #243 (Theorem FL, with its Remark 1), #242 Proposition 4 and Lemma 5, #244, #170/#175, #198 Lemma F′, and
the QS chain A4–A4.3 (rates at fixed `k` in a compact set, a different regime); [P] §8 through [K] §4; main#259 6001580409
((TL_a) and its consequences), 6001189633 (Sol's criterion), 6001319075 and 6001313460 (the TAIL-L and TAIL-S
obstructions).""")

# ---- header: Prior work (D-08) ----
rep("""archive, and main#229 and main#259 for claims). No packet on `main` bounds the rejected kernel uniformly as `κ → ∞` with
`k → 0`, or improves the elder exponent `3/7`.""",
"""archive, and main#229 and main#259 for claims). No packet on `main` approximates the rejected kernel by its cusp limit with
a rate uniform as `κ → ∞` with `k → 0`, or improves the elder exponent `3/7`. ([K] (K2) bounds the rejected kernel by
`C/κ` uniformly; §5 uses that bound.)""")

# ---- §0: constants (D-04) ----
rep("""- *Constants.* `C, c, N` denote constants that depend only on `d` and `L` (and on the exponents named), may change from
  line to line, and never depend on `r`, `k`, `κ`, `b` or `u`.""",
"""- *Constants.* `C, c, N` denote constants that depend only on `d` and `L` (and on the exponents named), may change from
  line to line, and never depend on `r`, `k`, `κ`, `b` or `u`. `P := 1 + |b| + k` as in #220 §0.""")

# ---- §0: TL2 statement (D-10) ----
rep("""(#242 (1.0)): for every `0 < a < b < ∞` there is `C_{a,b}` with `|J_ℓ(y) − F̄₀| ≤ C_{a,b}ℓ^{1/5}` for `y ∈ [a, b]` and small
`ℓ`. Hence #296's band contribution is `ν_{[a,b]}(ℓ) = (ℓ^{1/2}/10)F̄₀∫_a^b y^{−3/2} dy + O(ℓ^{7/10})`.""",
"""(#242 (1.0)): for every `0 < y₁ < y₂ < ∞` there is `C` with `|J_ℓ(y) − F̄₀| ≤ Cℓ^{1/5}` for `y ∈ [y₁, y₂]` and small `ℓ`.
Hence #296's band contribution (its `ν_{[a,b]}` with `[a, b] = [y₁, y₂]`) is
`(ℓ^{1/2}/10)F̄₀∫_{y₁}^{y₂}y^{−3/2} dy + O(ℓ^{7/10})`.""")

# ---- §1: N (AB-01) ----
rep("""Put `𝒩 := 1 + k + max_{1≤|α|≤9}‖∂^αf‖_{C⁰(X)}`. Adding a constant to `f` changes neither `e`, nor the window fields of [N],
nor any jet in `J′` of positive order. So every pathwise statement of [N] holds with this `𝒩` (orders `≥ 1` only).""",
"""Put `𝒩 := 1 + k + max_{1≤|α|≤9}‖∂^αf‖_{C⁰(X)}`. The pathwise statements of [N], of #220 (F1)–(F2) and of [K] §2 ask `𝒩`
to bound the sup norm of the field as well. Apply them to `f − f(M)`. It has the same `e`, the same window fields and the
same jets of positive order, and `sup|f − f(M)| ≤ (√d L/2)sup|∇f|`. So they hold with `C_L𝒩` in place of `𝒩`, where
`C_L := max(1, √d L/2)`, and `C_L` is absorbed into the constants (`C₄`, `C₁₂`, `c₁₃` and `N` below).""")

# ---- §1: (B4) for laws in 𝔏 (AB-03) ----
rep("""`Q̄_{r,k}` for `r ≤ r_0^*`, `k ≤ 1`, and every law whose mean and covariance interpolate linearly between two such laws.
(B4) holds for every law in `𝔏`, since it uses only the covariance bounds.""",
"""`Q̄_{r,k}` for `r ≤ r_0^*`, `k ≤ 1`, and every law whose mean and covariance interpolate linearly between two such laws.
The small-ball bounds of (B4) hold for every law in `𝔏`, since they use only the covariance bounds (the conditional means
are then affine in the other jets, of size `≤ C(1 + |rest|)`). The stated form of the means holds in `𝔏_×`.""")

# ---- §1: W2 (AB-04) ----
rep("""    E[Y 1{z ∈ Z(T, γ/|γ|)} 1_{𝒮_{x₀}}] ≤ (C/κ) E[h̄(T)Ȳ(T)(1 + |O′|)^{N} min(1, (κλ)^{−N}) 1{A < 0, |f₄| ≤ 13κ}].         (1.3)""",
"""    E[Y 1{z ∈ Z(T, γ/|γ|)} 1_{𝒮_{x₀}}] ≤ (C/κ) E[h̄(T)Ȳ(T)(1 + |O′|)^{M+m+2N} min(1, (κλ)^{−N}) 1{A < 0, |f₄| ≤ 13κ}].   (1.3)""")
rep("""otherwise `ρ₋ > 1` and `ρ₋ − |μ_γ| ≥ ρ₋/2`, and the Gaussian factor beats every power of `ρ₋`. With `ρ₋^{−2N} ≤ (7κλ/3)^{−N}`, the inner integral is
`≤ h̄Ȳ·C(1 + |μ_γ|)^{N′}min(1, (κλ)^{−N})/(14κ)`; integrate over `ω` and then over `T`.

For the second statement, (B4) in dyadic layers of `λ` gives, for `N > s + 1`,""",
"""otherwise `ρ₋ > 1` and `ρ₋ − |μ_γ| ≥ ρ₋/2`, and the Gaussian factor beats every power of `ρ₋`. With `ρ₋^{−2N} ≤ (7κλ/3)^{−N}`
and `|μ_γ| ≤ C(1 + |O′|)`, the inner integral is `≤ h̄Ȳ·C(1 + |O′|)^{M+m+2N}min(1, (κλ)^{−N})/(14κ)`; integrate over `ω` and
then over `T`.

For the second statement, condition on `T ∖ {A}` (`γ` is already integrated out). Under a law in `𝔏_×` the law of `A` given
`T ∖ {A}` is its law given the other even jets (`E ⊥ O`), so (B4) applies. In dyadic layers of `λ` it gives, for `N > s + 1`,""")

# ---- §2: Lemma GE statement (AB-06) ----
rep("""**Lemma GE (the decision on `𝔊`).** There are `C₄, C₁₂, N₂` (large), `c₁₃` (small) and `r₄ > 0` such that, for `0 < r ≤ r₄`,""",
"""**Lemma GE (the decision on `𝔊`).** Let `N₂ := max(N₁, m − 1)` as in [N] Step N1 (`N₁` of #220 (F1)). There are `C₄`,
`C₁₂` (large), `c₁₃` (small) and `r₄ ∈ (0, min(r_0^*, r_Q, 1/10)]` (`r_Q` of #220 §1) such that, for `0 < r ≤ r₄`,""")
rep("""`|Δ| ≥ C₁₂r𝒩^{N₂}`, `N₂ ≥ N₁`, `C₁₂` large, because `12k|Δ| ≥ 12C₁₂r²𝒩^{N₂}` (`κ ≥ 1`).""",
"""`|Δ| ≥ C₁₂r𝒩^{N₂}`, `N₂ ≥ N₁`, `C₁₂` large, because `12k|Δ| ≥ 12C₁₂r²𝒩^{N₂}` (`κ ≥ 1`).""", 1)

# ---- §2: GE (c) theta bullets (AB-02) ----
rep("""`ℰ`. Finally `ϑ = C₁₀[ζ² + ε₂′/κ + ε̃²/κ²]` is small on `𝔊 ∩ {typed}`:
- `𝒩r²Γ̃³/κ ≤ 72^{3/2}k^{1/2}/C₄^{3/2}`;
- `𝒩²r²Γ̃²/(λκ) ≤ 72/C₄²`;
- `ζ, ε̃/κ ≤ c_e`.

So `72κϑ + 36r|Q₁| ≤ κ` for `C₄` large. ∎""",
"""`ℰ`. Finally `ϑ = C₁₀[ζ² + ε₂′/κ + ε̃²/κ²]` is small on `𝔊 ∩ {typed}`. Here `ε₂′ = C₉[𝒩r²(1 + Γ̃)³ + 𝒩²r²(1 + Γ̃)²/λ]`
([N] (3.2)); use `(1 + Γ̃)³ ≤ 4(1 + Γ̃³)` and `(1 + Γ̃)² ≤ 2(1 + Γ̃²)`:
- `𝒩r²/κ ≤ c₁₃r` and `𝒩r²Γ̃³/κ ≤ 72^{3/2}k^{1/2}/C₄^{3/2}`;
- `𝒩²r²/(λκ) ≤ c₁₃/C₄` and `𝒩²r²Γ̃²/(λκ) ≤ 72/C₄²`;
- by (b), `ζ ≤ 9/C₄ + (72c₁₃/C₄)^{1/2}/12 + c₁₃/120` and `ε̃/κ ≤ 440C₁c₁₃ + 31680C₁/C₄`.

Each bound tends to `0` as `C₄ → ∞` and `c₁₃ → 0`. So `72κϑ + 36r|Q₁| = κ(72ϑ + 36ζ) ≤ κ` for `C₄` large and `c₁₃`
small. ∎""")

# ---- §2: Proposition RW (AB-07) ----
rep("""- (K1) gives `ω_r ≤ C(1 + κ)²𝒩^N`;""",
"""- [K] §2's pathwise bound `W_r/r² ≤ C(k + r)²(1 + ‖f‖_{C⁴})^{2m+4}` gives `ω_r ≤ C(1 + κ)²𝒩^N` (with `C_L`, as in §1);""")

# ---- §2: edge set |f4| > 13κ (AB-05) ----
rep("""  - The conditional density of `f₄` there is `≤ C exp(−c(max(13κ, 3|q| − 25κ) − |μ₄|)₊²)` (B4). This beats every power of
    `κ`, of `|q|` and of `|μ₄|`.""",
"""  - The conditional density of `f₄` there is `≤ C exp(−c(max(13κ, 3|q| − 25κ) − |μ₄|)₊²)` (B4). Since
    `max(13κ, 3|q| − 25κ) ≥ (κ + |q|)/2`, it is `≤ C_N(1 + |μ₄|)^{N′}(κ + |q|)^{−N}`, and `μ₄` is linear in the other even
    jets.""")

# ---- §3: envelope (C-01) ----
rep("""On the support of `G_s` with `|f₄| ≤ 12κ`, `23κ ≤ z ≤ 73κ` (by (2.2) and `z ≥ f₄ > −23κ`), so `|q| = (z − f₄)/3 ≤ 85κ/3` and,
by (1.1), `Γ̃ ≤ Γ̂`, `|Q₁| ≤ Q̂₁` and `|dQ₁/dz| ≤ Q̂₁/(z − f₄) ≤ Q̂₁/(11κ)`. Also, by (1.1),""",
"""Let `|f₄| ≤ 12κ` and `z ∈ [23κ, 73κ]`; this interval contains the support of `G_s` there, by (2.2) and `z ≥ f₄ > −23κ`.
Then `|q| = (z − f₄)/3 ≤ 85κ/3` and `z − f₄ ≥ 11κ`, so by (1.1) and (3.2), `Γ̃ ≤ Γ̂`, `|Q₁| ≤ Q̂₁` and
`|dQ₁/dz| ≤ Q̂₁/(z − f₄) ≤ Q̂₁/(11κ)` on the whole interval. Also, by (1.1),""")

# ---- §3: integration exponent (C-04) ----
rep("""  `∫dσ(ω) sup_{|z−x₀|≤κ}(1 + ρ)^{M}ρ_z ≤ (C/κ)(1 + |O′|)^{N}min(1, (κλ)^{−N})`.""",
"""  `∫dσ(ω) sup_{|z−x₀|≤κ}(1 + ρ)^{M}ρ_z ≤ (C/κ)(1 + |O′|)^{N′}min(1, (κλ)^{−N})`, with `N′ = M + m + 2N`.""")

# ---- §3: Part F (C-02, C-03) ----
rep("""- *The cutoff.* It is common to `G_{±r}` and absent from `G₀`. Its failure costs
  `2E[G₀1{r|Q₁| > c_eκ}(1 − χ)] ≤ (C r²/κ²)E[κ²Δ²Q₁²1{|z| ≥ 24κ, |f₄| ≥ 11κ}] ≤ C_N r²κ^{−N}`. Here (1.1) with
  `|q| ≤ (73κ + |f₄|)/3` bounds `Δ²Q₁²` by `(κ + |f₄|)²(1 + |J′|)^N`, and `|f₄| ≥ 11κ` gives the factor `κ^{−N}`.
- *The edges.* On `{r|Q₁| ≤ c_eκ}` the rejected set in `f₄` is `{f₄ ≥ e₊(s)} ∪ {f₄ ≤ e₋(s)}` (within the typed range), with
  `e_±(s) = ±24κ − 3|q| ± 36sQ₁`. These are exactly linear in `s`: `e_±(±r) = e_±(0) ± a_±`, `|a_±| = 36r|Q₁| ≤ 0.18κ`.
  With `ψ := 1 − χ(·/κ)` and `F_± := ψw₀p₄`, each edge contributes to the second difference `−[Φ_±(a) + Φ_±(−a)]` with
  `Φ_±(x) := ∫_{e_±(0)}^{e_±(0)+x}F_±`. So it is `≤ a²sup_{|f₄−e_±(0)|≤|a|}|F_±′|`, plus `r|β|·2|a|·sup ψp₄`. The kinks at
  `|z| = 72κ` contribute `≤ r|β|·96r|Q₁|·sup ψp₄`.
- `|F_±′| ≤ C[κΔ² + κ²Δ²(1 + |f₄ − μ₄|)]p₄` near the edges, since `|ψ′| ≤ 2/κ`, `|w₀′| ≤ κΔ²/2` and `w₀ ≤ 36κ²Δ²`. There
  `|f₄| ≥ max(11κ, 3|q| − 25κ)`. So `(1 + |f₄ − μ₄|)p₄ ≤ C exp(−c(max(11κ, 3|q| − 25κ) − |μ₄|)₊²)`, which is
  `≤ C_N(1 + |μ₄|)^{N′}(κ + |q|)^{−N}`.""",
"""- *The Gaussian factor.* Wherever `G_s^F ≠ 0` (`|s| ≤ r`), `|z| ≤ 73κ` and `|f₄| > 11κ`, so
  `|f₄| ≥ max(11κ, 3|q| − 73κ) ≥ (κ + |q|)/3`. Hence `(1 + |f₄ − μ₄|)p₄ ≤ C exp(−c((κ + |q|)/3 − |μ₄|)₊²)
  ≤ C_N(1 + |μ₄|)^{N′}(κ + |q|)^{−N}`, and `μ₄` is linear in the other even jets. This covers the cutoff, the edges, the
  kinks and the interior term of the first difference below.
- *The cutoff.* It is common to `G_{±r}` and absent from `G₀`. Its failure costs
  `2E[G₀1{r|Q₁| > c_eκ}(1 − χ)] ≤ (C r²/κ²)E[κ²Δ²Q₁²1{24κ ≤ |z| < 72κ, |f₄| ≥ 11κ}] ≤ C_N r²κ^{−N}`. Here (1.1) bounds
  `Δ²Q₁²` by a polynomial in `|q|` and the other jets, and the Gaussian factor gives `κ^{−N}`.
- *The edges.* On `{r|Q₁| ≤ c_eκ}` the rejected set in `f₄` is `{f₄ ≥ e₊(s)} ∪ {f₄ ≤ e₋(s)}` (within the typed range), with
  `e_±(s) = ±24κ − 3|q| ± 36sQ₁`. These are exactly linear in `s`: `{e_±(r), e_±(−r)} = {e_±(0) + a, e_±(0) − a}` with
  `a := 36rQ₁`, `|a| ≤ 0.18κ`. With `ψ := 1 − χ(·/κ)`, `F_± := ψw₀p₄` and `Φ_±(x) := ∫_{e_±(0)}^{e_±(0)+x}F_±`, the upper
  edge contributes `−[Φ₊(a) + Φ₊(−a)]` to the second difference and the lower edge `+[Φ₋(a) + Φ₋(−a)]`. Each is
  `≤ a²sup_{|f₄−e_±(0)|≤|a|}|F_±′|` in absolute value, plus `r|β|·2|a|·sup ψp₄`. The kinks at `|z| = 72κ` contribute
  `≤ r|β|·96r|Q₁|·sup ψp₄`.
- `|F_±′| ≤ C[κΔ² + κ²Δ²(1 + |f₄ − μ₄|)]p₄` near the edges, since `|ψ′| ≤ 2/κ`, `|w₀′| ≤ κΔ²/2` and `w₀ ≤ 36κ²Δ²`.""")

# ---- §3: after the proof (C-05) ----
rep("""So the first-order effect of the edge shift is `O(r)`, which is `O(t/κ)` per unit of the window mass, and the second-order
effect is `O(r²κ)`, which is `O(t²/κ)`.""",
"""So the first-order effect of the edge shift is `O(r) = O(t/κ)`, that is `O(t)` per unit of the window mass `≍ 1/κ`, and the
second-order effect is `O(r²κ) = O(t²/κ)`, that is `O(t²)` per unit.""")

# ---- §4: r0 (D-04), Steps 2, 5, 6 (D-02, D-05) ----
rep("""Fix `κ ≥ 1`, `0 < r ≤ r₀ := min(r₄, r_0^*, r₂′)` and `k = κr ≤ 1`, and write `E_{r,k} := E_{Q̄_{r,k}}`.""",
"""Fix `κ ≥ 1`, `0 < r ≤ r₀ := r₄` and `k = κr ≤ 1`, and write `E_{r,k} := E_{Q̄_{r,k}}`. Then `r₀ ≤ r_0^* ≤ r_0^{[K]}`, the
radius of [K] (#220 §4).""")
rep("""`|h″(t)| ≤ Ck²E_{𝕃_t}[G_r(1 + |O|)²] ≤ Ck²/κ` (the Gaussian score; (2.2) and Lemma W₁). So""",
"""`|h″(t)| ≤ Ck²E_{𝕃_t}[G_r(1 + |O|)²] ≤ Ck²/κ` (the Gaussian score, as in the proof of #220 Lemma G; (2.2) and Lemma W₁). So""")
rep("""`O(r²)` (B2). Along the linear interpolation of the covariances, the Gaussian score and Lemma W₁ give""",
"""`O(r²)` (B2). Along the linear interpolation of the covariances, the Gaussian score (as in the proof of #220 Lemma G) and
Lemma W₁ give""")
rep("""*Step 6 (the prefactor).* By (B3) and (B2), `|p_{V_r}(v(k)) − p_{V_0}(v(0))| ≤ C(r² + k²)`, and all expectations above are
`O(1/κ)`.""",
"""*Step 6 (the prefactor).* By (B3) and #237 (R.4) (`p_{V_r}` is smooth and even in `r`),
`|p_{V_r}(v(k)) − p_{V_0}(v(0))| ≤ C(r² + k²)`, and all expectations above are `O(1/κ)`.""")

# ---- §5: tail criterion (D-10) ----
rep("""So for `b ≥ 1`,
`ℓ^{−1/4}∫_b^∞|E_ℓ|κ^{−5/4}dκ ≤ Cℓ^{1/4}∫_b^{ℓ^{−1/3}}(κ^{−7/4} + κ^{−3/4})dκ + Cℓ^{−1/4}∫_{ℓ^{−1/3}}^∞κ^{−9/4}dκ ≤ C(ℓ^{1/4}b^{−3/4} + ℓ^{1/6})`,
which tends to `0`. This is the `b → ∞` half of #296 (4.2).""",
"""So for `κ̄ ≥ 1` (#296's cutoff `b`),
`ℓ^{−1/4}∫_{κ̄}^∞|E_ℓ|κ^{−5/4}dκ ≤ Cℓ^{1/4}∫_{κ̄}^{ℓ^{−1/3}}(κ^{−7/4} + κ^{−3/4})dκ + Cℓ^{−1/4}∫_{ℓ^{−1/3}}^∞κ^{−9/4}dκ ≤ C(ℓ^{1/4}κ̄^{−3/4} + ℓ^{1/6})`,
which tends to `0`. This is the `b → ∞` half of #296 (4.2).""")
rep("""- On `y ∈ [a, b]` and for small `ℓ`, `κ ≥ 1` and `k = ℓ^{1/10}y^{3/10} ≤ 1`.""",
"""- On `y ∈ [y₁, y₂]` and for small `ℓ`, `κ ≥ 1` and `k = ℓ^{1/10}y^{3/10} ≤ 1`.""")

# ---- §5: TL3 radii (D-04) ----
rep("""*Proof of Corollary TL3.* Put `ρ := ℓ^{2/9}`; for small `ℓ`, `ρ ≤ min(r₀, r₃, r₂′)` and `ρ < r_0^*`.""",
"""*Proof of Corollary TL3.* Put `ρ := ℓ^{2/9}`; for small `ℓ`, `ρ ≤ min(r₀, r₃, r₂′)`, where `r₃` is the radius of #237
Lemma U and `r₂′` that of [N] Proposition CE⁺⁺.""")

# ---- §5: after ledger (D-06) ----
rep("""cannot be improved by moving it. Removing the `ℓ^{4/9}` rows needs the `κ → 0` side: a cusp kernel with error better than
`O(r)` uniformly on `κ ≤ 1`, and a sharper intermediate elder bound. That is TAIL-S.""",
"""cannot be improved by moving it. Removing the `ℓ^{4/9}` rows needs the `κ → 0` side: an elder (hence rejected) cusp-kernel
error better than `O(r)` uniformly on `κ ≤ 1`, and a sharper intermediate elder bound. That is TAIL-S.""")

# ---- §6: Remark 2 (D-03) ----
rep("""2. **Sharpness of the order** (cited, not proved here). For the Gaussian kernel (#242's model case), #243 Theorem FL and
   #242 Proposition 4 give, at fixed small `k > 0`, `κ(𝐓_r^{rej}(k) − 𝓐^{rej}(k/r)) → F̄₀(H(k) − 1)` as `r ↓ 0`. Here
   `H(k) − 1 = (12/25)k² + O(k³)`, which is not `0`. So the `κr² = k²/κ` part of (TL) cannot be replaced by `o(κr²)`
   uniformly. It is the term that carries `R_{2/3}` (#242 Lemma 5).""",
"""2. **Sharpness of the order** (a remark from cited results, not a statement of this note).
   - At fixed `k > 0`, #243 Theorem FL, with dominated convergence in `b` ((K2) and [R] (R5)), gives
     `κ𝐓_r^{rej}(k, u) → ∫F(k; b, u)db` as `r ↓ 0`. #242 Theorem 1 gives `κ𝓐^{rej}(k/r, u) → ∫F₀(b, u)db`. So
     `κ(𝐓_r^{rej}(k, u) − 𝓐^{rej}(k/r, u)) → ∫(F − F₀)(k; b, u)db`.
   - In #242's model case (the Gaussian kernel on `R^d`), Proposition 4 gives `F = F₀H(k)` with
     `H(k) − 1 = (12/25)k² + O(k³) ≠ 0`. #243 Remark 1 records that the torus field's jets differ from the model's in law
     by `O(e^{−L²/8})` (#242 §0). This note does not prove the transfer of `H` to the torus field.
   - If the limit is nonzero for the field at hand (as in the model case), then the `κr² = k²/κ` part of (TL) cannot be
     replaced by `o(κr²)` uniformly. That part carries `R_{2/3}` (#242 Lemma 5).""")

# ---- §6: Remark 3 (D-08) ----
rep("""3. **`d ≥ 3`.** The proof uses neither the eigenframe of `A` nor #242's Proposition 2′, and no lower bound on the stiff
   eigenvalues.""",
"""3. **`d ≥ 3`.** The proof of Theorem TL uses neither the eigenframe of `A` nor #242's Proposition 2′, and no lower bound on
   the stiff eigenvalues. (The corollaries also use #242 Theorem 1, whose proof works in the eigenframe.)""")

# ---- §6: Remark 4 (D-06) ----
rep("""   - For `κ ≤ 1` the best kernel error on file is `O(r)` ((CE⁺⁺.1), (C⁺.1)), which over `[ℓ^{1/4}, ρ]` gives `ρ²`.""",
"""   - For `κ ≤ 1` the best elder-kernel (hence rejected-kernel) error on file is `O(r)` ((CE⁺⁺.1), (C⁺.1)), which over
     `[ℓ^{1/4}, ρ]` gives `ρ²`. (The candidate kernel has `O(r²)` there after the `b`-integral, by #237 Lemma U.)""")

# ---- §6: Remark 5 (D-07) ----
rep("""   - At fixed `κ`, (TL) implies, after the `b`-integral, [N] (N.1)–(N.2) for the rejected kernel on compact windows.
   - (TL3.1) implies #229 (E3⁺.0) and #220 (E3.0); (TL3.2) implies #229 (R⁺.1).""",
"""   - On compact `κ`-windows inside `[1, ∞)`, (TL) implies the `b`-integral of the difference of [N] (N.2) and (N.1), which
     is the rejected kernel's.
   - (TL3.1) implies the expansions of #229 (E3⁺.0) and #220 (E3.0), with a smaller remainder; their bounds on the far
     term are separate inputs (#187; #198 Lemma F′). (TL3.2) implies #229 (R⁺.1).""")

open(p, 'w').write(s)
print("c4 renamed:", n_c4)
