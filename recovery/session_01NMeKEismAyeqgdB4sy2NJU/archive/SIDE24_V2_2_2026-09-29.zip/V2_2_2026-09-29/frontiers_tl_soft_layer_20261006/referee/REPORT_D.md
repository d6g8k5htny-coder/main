VERDICT: PASS with MINOR

# Referee report: slice D (TL_note.md §§4–8, header, statements of TL1–TL3)

Clean-context referee (subagent a33afc211c348d197 of session_01NMeKEismAyeqgdB4sy2NJU; author-side lane, not a nonauthor review); reviewed TL_note.md sha256 ab8a8314…98ba. No BLOCKING or MAJOR error. Given §§1–3 as stated, the assembly in §4 and the proofs of TL1–TL3 are correct; the controls reproduce exactly as claimed. (Recorded by the author from the referee's hand-back.)

## Findings

**D-01 (MINOR) — header, TL3 bullet.** "The remainder now comes from #229's bound on the intermediate elder mass" contradicts the ledger: three rows reach 4/9 (`ℓ²ρ^{−7}`, `ρ²` from the `O(r)` error of (CE⁺⁺.1)/(C⁺.1) on `κ ≤ 1`, and #229's `I^{eld}`); only `log(1/ℓ)` is #229's alone. *Fix:* "The exponent 4/9 is attained by the `κ ≤ 1` cusp error (`ρ²`), the cusp tail (`ℓ²ρ^{−7}`) and #229's intermediate elder bound, which also carries the logarithm."

**D-02 (MINOR) — header, Consumed / Cited only.** Used but not listed: [N] Proposition CE⁺⁺ (CE⁺⁺.1) (and its radius `r₂′`); #237 Theorem P (P.1); [K] §4's implication `1 − e ≤ 1_{cap^c}` ([P] §8); [R] (R5); #242 §0's identity `I^{cand} − c₁ = ∫∫∫𝒜^{rej}`. Listed but never cited in the body: #220 Lemma G (Steps 2 and 5 use its proof as "the Gaussian score" without citing it), [N] Lemma CU.1″, [N] Step N2. Used in Remark 2 but missing from Cited only: #242 Proposition 4 and Lemma 5. §2's "(K1)" should be "[K] §2". *Fix:* amend both lists; cite #220 Lemma G at Steps 2 and 5.

**D-03 (MINOR) — Remark 2.** Combines #243 Theorem FL (torus field) with #242 Proposition 4 (Gaussian kernel on `R^d`) and states the limit "for the Gaussian kernel"; #243 Remark 1 says Proposition 4 covers the model case, the jets' laws differing by `O(e^{−L²/8})`. *Fix:* state the limit for the periodized field with the model value and an `O(e^{−L²/8})` caveat, or mark the remark as formal; write the `u`-integral; note #243's author-side status.

**D-04 (NIT).** `r₂′`, `r₃`, `P` undefined; `r₂′` plays no role in §4; the first bound of §5 needs `r ≤ r_0^{[K]}` (true since `r₀ ≤ r_0^* ≤ r_0^{[K]}`, #220 §4). *Fix:* define at first use.

**D-05 (NIT) — Step 6.** `|p_{V_r}(v(0)) − p_{V_0}(v(0))| ≤ Cr²` comes from #237 (R.4), not (B2)/(B3). *Fix:* cite (R.4).

**D-06 (NIT) — Remark 4 and the sentence after the ledger.** "best kernel error O(r)" holds for the elder (hence rejected) kernel; for the candidate kernel #237 Lemma U gives O(r²). *Fix:* "best elder-kernel error".

**D-07 (NIT) — Remark 5.** (TL) gives the b-integrated rejected difference of (N.1)–(N.2) only on compact windows in `[1, ∞)`; (TL3.1) implies the expansion of (E3.0) but not its far bound (#198 Lemma F′). *Fix:* reword.

**D-08 (NIT) — Prior work; Remark 3.** (K2) already bounds `𝐓^{rej} ≤ C/κ` uniformly. *Fix:* "No packet approximates the rejected kernel by its cusp limit with a rate uniform as `κ → ∞` …". Remark 3 is true of Theorem TL only (the corollaries use #242 Theorem 1, whose proof uses the eigenframe in `d ≥ 3`). *Fix:* "The proof of Theorem TL …".

**D-09 (NIT) — §7, T5/T6.** T6 derives only the `ℓ^{2/3}` and `ℓ^{1/6}` exponents; `ℓ^{3/4}` and the `I^{eld}` row are hard-coded; the row formulas (`2 − 7θ`, `3 − 11θ`, `2 − 5θ`) are copied, not derived; TL2's `7/10` is not checked; T5 checks `(a, s)` lists copied from the note; §3 has lists, not tables. *Fix:* tone down or add derivations.

**D-10 (NIT).** The letter `b` (birth height) is also the band endpoint and the tail cutoff (following #296). *Fix:* rename.

## Checked
§4 Steps 1–6 (h′(0), `|h″| ≤ Ck²/κ` with 𝕃_t ∈ 𝔏; 𝒫-invariance of `Q̄_{r,0}`; `G_s(E, −O) = G_{−s}(E, O)`; ℓ_r odd; (Δ.1) with p = 1 and (Δ.2); covariance interpolation among centred laws in 𝔏; (B3)'s quadratic log-density; collection into `Cr²(1 + κ)`; hypotheses of RW, W₁, Δ met). §5: (K2) as stated (expectation bound, `r ≤ min(k, r_0)`, every frame); the erratum leaves K1, K2 unchanged; [K] §4's cap implication used correctly; `𝓐^{rej} ≤ C/κ` from #242 (1.0); `𝓐^{rej} ≤ Cκ³`. TL1 ranges and exponents; #296 (2.2)–(2.3), (4.1)–(4.2): `E_ℓ`, the Jacobian `(ℓ^{1/4}/4)κ^{−5/4}`, the `ℓ^{−1/4}` normalization, the bound; dropping the fold subtraction is correct. TL2: `J_ℓ = κ∫𝐓dσ`, `κ = ℓ^{−1/5}y^{2/5}`, errors `2Ck²` and `C/κ`, remainder `ℓ^{7/10}`. TL3: (5.1) matches #220 §0; Lemma U applies (`k ≥ r²` for `ρ ≤ ℓ^{1/5}`); #237 §5's main-term computation at `ρ = ℓ^{2/9}` gives exactly the stated terms; (CE⁺⁺.1) and (C⁺.1) hold uniformly for `κ > 0` with `κr ≤ 1`; the #242 §0 identity; the tail `ℓ^{5/9}`; `J₄`; `I^{eld}` on `[ℓ^{2/9}, r_0^*]` is proved in #229 §5 (`ρ_c = ℓ^{2/9}`, `a = ℓ^{1/9}`); (TL3.2) from (P.1). Ledger: least exponent 4/9 attained exactly by the bold rows; SIDE24 `ℓ^{7/9}` vs `ℓ^{16/21}`. Remarks 1–5 against #242, #243, #229, #220, [N]. Independent check of Jacobians and exponents (work_D/check_subs.py). tl_exact.py: both modes identical stdout (sha256 a0ed2c2b…4490, one JSON line, 2704); M1–M8 exit 1 in both modes with empty stdout and stderr "FAILED: <group>"; unknown/missing label, extra argument or --help exit 2; seeded RNG; no reliance on assert.

## Not checked
main#259 comments, [P], [R], #187; blob identities; the internals of §§0–3 (taken as stated). No control tests the analytic content of §§4–5 (verified by hand).
