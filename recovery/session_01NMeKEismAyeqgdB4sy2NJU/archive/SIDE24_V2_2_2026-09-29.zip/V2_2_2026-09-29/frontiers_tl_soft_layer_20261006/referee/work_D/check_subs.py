"""Independent numeric checks of the substitutions used in TL_note §5 (referee D)."""
import math
from fractions import Fraction as F


def simpson(f, a, b, n=20000):
    if n % 2:
        n += 1
    h = (b - a) / n
    s = f(a) + f(b)
    for i in range(1, n):
        s += (4 if i % 2 else 2) * f(a + i * h)
    return s * h / 3


ell = 1e-3
g = lambda kap: kap / (1.0 + kap) ** 3          # test profile in kappa

# (4.1): int_0^{l^{1/4}} g(l/r^4) dr  ==  (l^{1/4}/4) int_1^inf g(k) k^{-5/4} dk
lhs = simpson(lambda r: g(ell / r ** 4) if r > 0 else 0.0, 1e-9, ell ** 0.25, 200000)
# substitute kappa = e^t to integrate to infinity
rhs = (ell ** 0.25 / 4) * simpson(lambda t: g(math.exp(t)) * math.exp(t) ** (-0.25), 0.0, 60.0, 200000)
print("(4.1) jacobian:", lhs, rhs)

# TL1 substitution r = l^{1/4} s: int_{l^{1/3}}^{l^{1/4}} g(l/r^4) dr == l^{1/4} int_{l^{1/12}}^1 g(s^-4) ds
lhs = simpson(lambda r: g(ell / r ** 4), ell ** (1 / 3), ell ** 0.25)
rhs = ell ** 0.25 * simpson(lambda s: g(s ** -4), ell ** (1 / 12), 1.0)
print("TL1 substitution:", lhs, rhs)

# #296 (2.3): band integral with J const = 1:  int r^{-2} B_r(l/r^3) dr over y in [a,b], B_r(k) = J r^3/k
a, b = 0.5, 2.0
r_of_y = lambda y: ell ** 0.3 * y ** -0.1
r_hi, r_lo = r_of_y(a), r_of_y(b)
lhs = simpson(lambda r: r ** -2 * (r ** 3 / (ell / r ** 3)), r_lo, r_hi)
rhs = ell ** 0.5 / 10 * simpson(lambda y: y ** -1.5, a, b)
print("(2.3) band:", lhs, rhs)

# J_ell = kappa * int T dsigma : B_r = r^2 int T, J = k B / r^3 = (k/r) int T
# exponents (as Fractions)
th = F(2, 9)
rows = {"l^2 rho^-7": 2 - 7 * th, "rho^2": 2 * th, "I_eld": F(4, 9), "l^3 rho^-11": F(1, 4) + 11 * (F(1, 4) - th),
        "rho^3": 3 * th, "l^2 rho^-5": 2 - 5 * th, "TL r^2": F(3, 4)}
print("ledger:", {k: str(v) for k, v in rows.items()}, "min", min(rows.values()))
# tail exponent: l^{1/4} * (rho l^{-1/4})^{-11}
print("tail:", F(1, 4) - 11 * (th - F(1, 4)))
# #296 tail: l^{-1/4} * l^{1/2} * (l^{-1/3})^{1/4} and l^{-1/4} * (l^{-1/3})^{-5/4}
print("296 tail:", F(-1, 4) + F(1, 2) - F(1, 12), F(-1, 4) + F(5, 12))
print("TL2 band error:", F(1, 2) + F(1, 5))
print("SIDE24:", F(4, 9) + F(1, 3), F(3, 7) + F(1, 3), F(1, 4) + F(1, 3), F(1, 3) + F(1, 3))
