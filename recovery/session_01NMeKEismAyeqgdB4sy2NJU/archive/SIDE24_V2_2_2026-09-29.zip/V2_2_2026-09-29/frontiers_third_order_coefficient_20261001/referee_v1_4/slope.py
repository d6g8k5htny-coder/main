import math
def fit(xs, ys):
    X=[math.log(x) for x in xs]; Y=[math.log(y) for y in ys]
    n=len(X); mx=sum(X)/n; my=sum(Y)/n
    return sum((a-mx)*(b-my) for a,b in zip(X,Y))/sum((a-mx)**2 for a in X)
edges=[1e-6,1e-4,3e-4,1e-3,3e-3,1e-2,3e-2]
cent=[math.sqrt(a*b) for a,b in zip(edges[:-1],edges[1:])]
d2=[6/3795,17/4244,90/9876,355/19215,1936/45256,6932/84812]
d3=[2/503,0/568,23/1392,66/2704,374/6252,1353/11560]
print('d2 five rows above 1e-4:', fit(cent[1:], d2[1:]))
print('d2 all six:', fit(cent, d2))
print('d2 printed pct five rows:', fit(cent[1:], [0.40,0.91,1.9,4.3,8.2]))
nz=[(c,y) for c,y in zip(cent,d3) if y>0]
print('d3 nonzero rows:', fit([c for c,y in nz],[y for c,y in nz]))
print('d3 top four rows:', fit(cent[2:], d3[2:]))
