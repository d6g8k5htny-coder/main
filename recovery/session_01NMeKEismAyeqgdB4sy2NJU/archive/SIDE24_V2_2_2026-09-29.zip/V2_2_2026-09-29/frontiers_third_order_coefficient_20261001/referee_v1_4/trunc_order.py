import sys, math
sys.dont_write_bytecode = True
sys.path.insert(0, '/home/claude/wt-216/frontiers/third_order_coefficient_20261001')
import c2_check as C
res = {}
for r in ('0.007', '0.011', '0.016', '0.022', '0.03'):
    k8, k10, k12 = C.Kernel(3, 8, r, 'gauss'), C.Kernel(3, 10, r, 'gauss'), C.Kernel(3, 12, r, 'gauss')
    for (b, k) in ((0.0, 1.0), (1.0, 0.3), (-1.5, 2.0)):
        m8, m10, m12 = k8.cone_moments(b, 0.0, 32), k10.cone_moments(b, 0.0, 32), k12.cone_moments(b, 0.0, 32)
        a8, a10, a12 = k8.A(b, k, m8), k10.A(b, k, m10), k12.A(b, k, m12)
        res[(r, b, k)] = (abs(a8 / a12 - 1), abs(a10 / a12 - 1))
        print('r=%s (b,k)=(%g,%g)  N8 vs N12 %.3e   N10 vs N12 %.3e' % (r, b, k, abs(a8/a12-1), abs(a10/a12-1)), flush=True)
rs = ['0.007', '0.011', '0.016', '0.022', '0.03']
for (b, k) in ((0.0, 1.0), (1.0, 0.3), (-1.5, 2.0)):
    for i in range(len(rs) - 1):
        r1, r2 = rs[i], rs[i+1]
        e1, e2 = res[(r1, b, k)][0], res[(r2, b, k)][0]
        print('(b,k)=(%g,%g) N=8 slope %s->%s: %.2f' % (b, k, r1, r2, math.log(e2/e1)/math.log(float(r2)/float(r1))))
