import math
from fractions import Fraction
s6 = math.sqrt(6)
g = 12**(1/6)*math.gamma(5/6)
c2 = {1: 0.75*g/math.pi**1.5, 2: (13/18)*g/math.pi**1.5, 3: (5/48)*(33-7*s6)*g/math.pi**2.5}
cc = {1: math.gamma(1/6)*12**(-1/6)/(6*math.pi**1.5), 2: math.gamma(1/6)*12**(-1/6)/(9*math.pi**1.5),
      3: (29/72 - s6/12)*math.gamma(1/6)*12**(-1/6)/math.pi**2.5}
for d in (1,2,3):
    print('d', d, 'c2 %.16f' % c2[d], 'c %.16f' % cc[d], 'c2/c %.12f' % (c2[d]/cc[d]))
r3 = 18*(141-s6)/25*math.gamma(5/6)/(12**(2/3)*math.gamma(1/6))
print('c2/c d=3 via kappa: %.12f' % r3)
c1c = -5.07106214
# cancellation fraction
for l in (1e-5,1e-4,1e-3,1e-2):
    frac = r3*l**(2/3)/(-c1c*l**(7/12))
    print('l=%g frac=%.4f  0.761*l^(1/12)=%.4f' % (l, frac, 0.761*l**(1/12)))
print('coef ratio', r3/5.07106214, 3.859/5.071)
# crossings of fraction 0.40 and 0.50
k = r3/5.07106214
for f in (0.40, 0.50):
    l = (f/k)**12
    print('frac=%.2f at l=%.4e' % (f, l))
# table sums
print('table:')
for l in (1e-5,1e-4,1e-3,1e-2):
    a = c1c*l**(7/12); b = r3*l**(2/3)
    print('l=%g  a=%.6f b=%.6f sum=%.6f  rounded a=%.4f b=%.4f sum=%.4f  sum_of_rounded=%.4f' % (l,a,b,a+b,a,b,a+b,round(a,4)+round(b,4)))
    a2 = -5.071*l**(7/12); b2 = 3.859*l**(2/3)
    print('     rounded coefs: a=%.6f b=%.6f sum=%.6f' % (a2,b2,a2+b2))
# crossing of combined correction 1% and 10%
def F(l): return -(c1c*l**(7/12) + r3*l**(2/3))
def solve(target, f):
    lo, hi = 1e-9, 0.5
    for _ in range(200):
        mid = math.sqrt(lo*hi)
        if f(mid) < target: lo = mid
        else: hi = mid
    return lo
print('1%% combined at %.4e, 10%% at %.4e' % (solve(0.01,F), solve(0.10,F)))
G = lambda l: -c1c*l**(7/12)
print('l^(1/4) alone: 1%% at %.4e, 10%% at %.4e' % (solve(0.01,G), solve(0.10,G)))
# BBKS
ratio = (29+6*s6)/(29-6*s6)
print('BBKS ratio %.6f, x142.796 = %.4f' % (ratio, ratio*142.796))
