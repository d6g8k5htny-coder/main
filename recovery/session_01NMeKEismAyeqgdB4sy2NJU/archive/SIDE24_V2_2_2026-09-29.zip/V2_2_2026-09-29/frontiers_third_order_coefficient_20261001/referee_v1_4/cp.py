import math
from fractions import Fraction
def binom_cdf(k, n, p):
    # P(X <= k)
    return math.fsum(math.comb(n, i) * p**i * (1-p)**(n-i) for i in range(k+1))
def bisect(f, lo, hi, it=200):
    for _ in range(it):
        mid = (lo+hi)/2
        if f(mid) > 0: lo = mid
        else: hi = mid
    return (lo+hi)/2
def cp(k, n, alpha=0.05):
    if k == 0: lo = 0.0
    else:
        # lower: P(X >= k | p) = alpha/2  -> 1 - cdf(k-1) = alpha/2
        lo = bisect(lambda p: alpha/2 - (1 - binom_cdf(k-1, n, p)), 0.0, 1.0)
    if k == n: hi = 1.0
    else:
        hi = bisect(lambda p: binom_cdf(k, n, p) - alpha/2, 0.0, 1.0)
    return lo, hi
for k, n in ((2,503),(0,568),(6,3795),(17,4244),(23,1392)):
    lo, hi = cp(k, n)
    print('%d/%d = %.4f%%  CP95 [%.4f%%, %.4f%%]' % (k, n, 100*k/n, 100*lo, 100*hi))
# one-sided 95% for 0/568
print('one-sided 95%% upper for 0/568: %.4f%%' % (100*(1-0.05**(1/568))))
print('rule of three 3/568 = %.4f%%' % (300/568))
# check the window table percentages
rows = [(6,3795,'0.16%'),(17,4244,'0.40%'),(90,9876,'0.91%'),(355,19215,'1.9%'),(1936,45256,'4.3%'),(6932,84812,'8.2%'),
        (2,503,'0.4%'),(0,568,'0.0%'),(23,1392,'1.7%'),(66,2704,'2.4%'),(374,6252,'6.0%'),(1353,11560,'11.7%')]
for k,n,s in rows:
    print('%d/%d = %.3f%%  printed %s' % (k,n,100*k/n,s))
