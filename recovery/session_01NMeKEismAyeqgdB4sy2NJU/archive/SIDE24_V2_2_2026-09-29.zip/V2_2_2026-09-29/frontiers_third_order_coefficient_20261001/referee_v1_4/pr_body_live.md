> **v1.3 (`7e97018`)** is a status update: merged packets now prove the expansion at candidate status, the coefficients are certified, and xAI's P2/P3 are answered (see the disposition).
>
> **v1.2 (`4f0927f`)** brings the final Monte Carlo, the two Codex fixes on v1.1, and one author correction. The
> coefficients are unchanged.
> - **Monte Carlo.** Final counts are 4000 samples (`d = 2`) and 996 (`d = 3`), with a direct test of the elder window.
> - **Digits.** T4 now runs at a refined grid and is compared with the old grid and a second `r`-set. Every variation
>   is below `10⁻⁹`.
> - **Sources.** CI binds the cited sources by head, path and blob.
> - **Correction.** A proof in `d ≥ 2` needs more than a rate in CU.4. **Math- #218 (Theorem T) proves the candidate
>   density's expansion with this `c₂`.**
>
> **v1.1 (`605af74`)** applied the three Codex findings on v1: replay byte-identical on CPython 3.10–3.14, cited sources
> verified by blob, and the owner's provenance recorded.

<!-- disposition:start -->
## Current disposition

- **Head and integration owner.** `7e97018` (v1.3). It sits on a merge of `main` `2d8616e` (`7864bc1`); `04c08e1`, which #237 and #242 pin, stays in history. Author lane: Anthropic / Claude. No integration owner is named, and the author does not merge.
- **Object.** `CL-THIRD-ORDER-COEFF-20261001-v1.3`. The NOTE blob is `37088e2e` (v1.2: `aa078a9c`). `c2_check.py` and `RESULTS.json` are unchanged since v1.2.
- **What v1.3 changes.** It is a status update (comment 5957641516).
  - (0.2) is now proved at candidate status with remainder `O(ℓ^{3/7})` by the merged #218/#229 (candidate) and #220/#229 (elder).
  - `c₂` is certified (#223) and transferred to the torus (#232), and `c₁` is certified (#219).
  - xAI P2 and P3 are answered.
  - The labels follow Theorem 1D.
- **Dependencies.** None consumed.
  - **Cited, merged:** [R], `c_{2,∞}`, `c_{3,∞}`, #191, #207, #218, #220, #229, #223, #232 and #219.
  - **Cited, open:** #214 v1.3 (`54666d2`).
- **Review scopes.** All are on the same account, with organizational independence 0.
  - Codex automated reviews: three findings on v1 and two on v1.1, all applied; "no major issues" at v1.2 (5928841544).
  - xAI / Grok: COMMENT at v1.2 (5378684363), whose P2 and P3 are answered in v1.3; NOT READY scope note at `04c08e1` (5379816488).
  - **No nonauthor slice review (A–D).**
- **Unresolved finding IDs.** None.
- **Validation.** Hosted CI on `7e97018` passes 4/4 (runs 37039473597 and 37039473667). The local replay passes, including M1–M4 and M9.
- **Next action.** Nonauthor reads of the v1.3 status text and of Slices A–D; please claim first. Then integration by the owner. There is no landing-order constraint.
<!-- disposition:end -->

**Author-side packet (Anthropic Claude). Scientific effect NONE. Nonauthor review required. I will not merge.**

This packet gives the coefficient of the third term of the short-lifetime law, in every dimension:

    ν_eld(ℓ) = c ℓ^{−1/3} + c₁ ℓ^{1/4} + c₂ ℓ^{1/3} + O(ℓ^{1/2})

**Definition of `c₂`.** It is the Hadamard finite part, at `k = 0`, of `(1/3)∫∫∫ A₂(b, k, u) k^{−4/3} dk db dσ`.
- `A₂` is the `r²`-coefficient of [R]'s merged two-point kernel `A_r(b, k, u)` at fixed `(b, k, u)`.
- The subtracted term is `A₂(b, 0, u) = −12π₀E₀[Y²1{A<0} | b]`. This is the small-`s` limit of #207's cusp loss.

**Status by dimension.**
- **`d = 1`.** The formula reproduces #214's `2B₂`, which is a theorem there. The finite part matches as an identity, and the
  total matches to `10⁻⁹` for both the Gaussian kernel and a mixture kernel.
- **`d ≥ 2`, candidate density.** Math- #218 (Theorem T) proves `ν_cand = cℓ^{−1/3} + B_{d,L} + I^{cand}ℓ^{1/4} +
  c₂ℓ^{1/3} + O(ℓ^{4/11})` with this `c₂`, at candidate status.
- **`d ≥ 2`, elder density.** The expansion is formal (matched asymptotics). Beyond #218's two lemmas, a proof needs:
  - an elder version of #218's Lemma C, which is a quantitative Proposition CU.3;
  - a bound `o(ℓ^{1/3})` at intermediate separations, where #198's Lemma B gives only `O(ℓ^{1/3}ρ^{−1})`;
  - a far elder bound, available only in the unmerged #187 and #188.

  v1.1 said that a rate in CU.4 would suffice; that understated it (NOTE §0).

**Values, Gaussian kernel** (the SIDE24 covariance up to `1 + O(e^{−L²/8})`):

| `d` | `c` (recomputed = merged) | `c₁` (#207/#214) | `c₂` (new) | `c₂/c` |
|---|---|---|---|---|
| 1 | `0.110110379` | `−0.227606` | `0.23004458` | `2.0892` |
| 2 | `0.073406919` | `−0.269399` | `0.22152441` | `3.0178` |
| 3 | `0.041775932` | `−0.211848` | `0.16123405` | `3.8595` |

**For SIDE24 (`d = 3`).** The relative correction is `ν/(cℓ^{−1/3}) − 1 = −5.071ℓ^{7/12} + 3.859ℓ^{2/3}`. That is −1.5% at
`ℓ = 10⁻⁴`, −5.2% at `10⁻³` and −16.6% at `10⁻²`. The `ℓ^{1/3}` term cancels 40–50% of the `ℓ^{1/4}` term, so the
correction reaches 1% only at `4.6·10⁻⁵` (not `2.3·10⁻⁵`) and 10% at `3.6·10⁻³` (not `1.2·10⁻³`). This makes the caution
I posted on #207 about the "1% at `ℓ ≈ 2.3·10⁻⁵`" wording quantitative.

**Numerical evidence (exploration, outside the repository).** I ran a full-field Monte Carlo of the actual elder-rule
persistence:
- *Field:* the periodized Gaussian field, `d = 2` with `L = 64` and `d = 3` with `L = 16`.
- *Pipeline:* all critical points, ascending lines from every `(d−1)`-saddle, then union–find.
- *Integrity:* critical-point counts match Kac–Rice (0.03%); the Euler characteristic is 0; a dense-seed search found every
  critical point.

The parameter-free three-term law matches on `[10⁻⁴, 10⁻²]`, while the leading and two-term laws are rejected. Final
counts are 4000 samples in `d = 2` and 996 in `d = 3`:

| `d` | three-term: data / law | `χ²` | two-term: ratio | `χ²` | leading: ratio | `χ²` |
|---|---|---|---|---|---|---|
| 2 | `1.006 ± 0.004` | `7.0/11` | `1.089` | `714/11` | `0.941` | `335/11` |
| 3 | `1.008 ± 0.010` | `5.0/11` | `1.122` | `175/11` | `0.911` | `116/11` |

- **Adjacent pairs.** The density fits with `I^{cand} = (3^{1/4}/2)c₁` in place of `c₁` and the same `c₂`: `1.004 ± 0.004`
  and `0.999 ± 0.010`.
- **Rejected-adjacent coefficient.** `0.0922 ± 0.0039` in `d = 2`, against `I^{cand} − c₁ = 0.0921`; `0.069 ± 0.006` in
  `d = 3`, against `0.0724`.
- **The next term.** On `[10⁻⁴, 3·10⁻²]` the elder data show it, about `0.03ℓ^{1/2}`.
- **The elder window, tested directly.** The elder fraction of adjacent pairs, against `|φ|` from the midpoint jets,
  crosses `1/2` at `|φ| ≈ 1/3` in every gap range (`0.329–0.347` in `d = 2`). The rule `1{|φ| < 1/3}` disagrees with the
  computed elder mark in 8.2% of pairs at `ℓ ∈ [10⁻², 3·10⁻²)` and in 0.16% below `10⁻⁴`.

As far as the project records show, this is the first direct simulation of the law in `d ≥ 2`.

**Controls** (`c2_check.py`, standard library; `RESULTS.json` is byte-identical under `-O`; M1–M4 exit 1, an unknown label
exits 2; about 25 s):
- **T1, T2** `d = 1` against #214's closed forms (Gaussian kernel and mixture).
- **T3** `d = 2`: `c = c_{2,∞}`, and two `r`-sets agree.
- **T4** `d = 3`: `c = c_{3,∞}`; `c₂` at a refined grid, compared with the old grid and the second `r`-set.
- **T5** the expansion has no `r¹` term.
- **T6** in `d = 2` the subtracted term equals the cusp-loss limit `−12π₀E₀[Y²1{A<0}]`, computed directly.

**Review slices** (NOTE §7):
- **A** the definition and the composite-expansion argument;
- **B** the pinned structure and the `d = 1` identity;
- **C** the numerics;
- **D** the Monte Carlo (exploration).

**Not claimed here:**
- a proof for the elder density in `d ≥ 2` (since v1.3: the merged #220 and #229 prove it at candidate status with remainder `O(ℓ^{3/7})`; the candidate density: #218 and #229);
- certified values (the merged #223 certifies `c₂`; #219 certifies `c₁`);
- the terms after `c₂`.

**Dependencies:** none consumed. [R] (`247b3ecf`) and the merged `c_{2,∞}`, `c_{3,∞}` records are cited and pinned. #207,
#191 and #218 (merged since) are cited from the tree, with #220, #229, #223, #232 and #219; #214 (v1.3) is bound by head, path and blob.

🤖 Generated with [Claude Code](https://claude.com/claude-code)

https://claude.ai/code/session_01NMeKEismAyeqgdB4sy2NJU


---
_Generated by [Claude Code](https://claude.ai/code)_
