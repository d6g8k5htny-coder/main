# Clean-context referee pass on Math- #216 v1.4 (`7e97018..dbd4d59`): author-side, same provider, not review evidence

This is a Claude subagent run by the author lane on 4 October 2026, before the v1.4 push. It had a clean context, and it
was given the four nonauthor reviews and read-only access to the sources. Its report, condensed:

- **Verdict.** No BLOCKER; 5 SHOULD-FIX items and 11 NITs. All were applied before the push, in commit `1bfdf28`, which
  amends `dbd4d59`.
- **What checked out.**
  - The mutants are honest (M1, M2 and M4 fail T1–T4; M3 fails T3; M9 exits 2).
  - Stdout is byte-identical to `RESULTS.json` under `-B -S` and `-B -O -S` on CPython 3.10, 3.11, 3.12, 3.13 and
    3.14rc2.
  - All recomputed numbers agree: cancellation fractions and crossings, table sums, rounding distances, the BBKS saddle
    value `436.2526`, the Clopper–Pearson intervals, the dense-seed expected counts, bin spans, the `0.66` slope, and
    the window percentages.
  - The `r^{N−2}` slope is 6.00.
  - Every attribution spot-checks, and all 15 blobs match `main` `42f19d7`.
- **SHOULD-FIX (applied).**
  1. Only the cusp part of the `d = 1` comparison is an identity. The fold part is an identification that consumes #214
     Lemma 1.3.
  2. #218 Lemma F covers `d ≥ 2` only. This is stated at §0's fold expansion and at (0.1).
  3. The rejected-adjacent paragraph no longer names an `ℓ^{1/2}` correction.
  4. The adjacent-pair residual's ranges are attributed correctly to this note and to #237 Remark 4.
  5. The PR body is rewritten at the push.
- **NITs (applied).**
  - The table's `c₁/c` column comes from #219's enclosures.
  - The display labels are (T.1) of #218 and (T⁺.1) of #229.
  - #218 has no `Ã_r`; the bound is attributed to the Slice B read B-2.
  - #187 is added to the list of author-side candidates.
  - Blank lines are added before three bold paragraphs.
  - The window crossings read `0.329–0.395`.
  - The v1.2 block notes "spreads, not errors".
  - U-1 is acknowledged rather than applied.
  - The truncation reads `≤ 7·10⁻¹⁵`.
  - Two errors in `SOURCES.json` `kind` are fixed.
  - The raw-records custody is stated, and so is the maxima-count loss bound.

The subagent's working files are in this folder: mutant outputs and the `cp.py` and `dense.py` checks.
