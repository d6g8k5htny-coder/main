def N(c,c1,c2,L): return c*1.5*L**(2/3) + c1*0.8*L**1.25 + c2*0.75*L**(4/3)
for name,(c,c1,c2),V in (('d2',(0.0734069,-0.269399,0.221524),2400),('d3',(0.0417759,-0.211848,0.161234),250),('d3 per 16^3',(0.0417759,-0.211848,0.161234),4096),
                         ('d2 per 64^2',(0.0734069,-0.269399,0.221524),4096)):
    print(name, 'l<1e-2: %.3f  l<1e-3: %.3f' % (V*N(c,c1,c2,1e-2), V*N(c,c1,c2,1e-3)))
# window totals for error bars: [8.57e-5, 9.65e-3] spans
for name,(c,c1,c2),V in (('d2',(0.0734069,-0.269399,0.221524),4000*64**2),('d3',(0.0417759,-0.211848,0.161234),996*16**3)):
    n = V*(N(c,c1,c2,9.65e-3)-N(c,c1,c2,8.57e-5))
    print(name,'window pairs %.0f  1/sqrt %.4f' % (n, n**-0.5))
# bin edges
import math
edges=[10**(math.log10(1e-5)+i*(math.log10(0.3)-math.log10(1e-5))/24) for i in range(25)]
w=(math.log10(0.3)-math.log10(1e-5))/24
print('bin width dec %.4f' % w)
cent=[math.sqrt(a*b) for a,b in zip(edges[:-1],edges[1:])]
sel=[(i,edges[i],edges[i+1]) for i in range(24) if 1e-4<=cent[i]<=1e-2]
print(len(sel), sel[0][1], sel[-1][2])
sel=[(i,edges[i],edges[i+1]) for i in range(24) if 1e-4<=cent[i]<=3e-2]
print(len(sel), sel[0][1], sel[-1][2])
