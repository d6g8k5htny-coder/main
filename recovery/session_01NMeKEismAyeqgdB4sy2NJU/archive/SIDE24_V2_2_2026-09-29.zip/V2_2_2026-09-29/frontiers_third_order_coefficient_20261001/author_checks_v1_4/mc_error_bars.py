"""Exploration (outside the repository; numpy): v1.4 error bars and window counts for Math- #216 NOTE section 3.
Inputs: the raw records sim2d/batchA2.npz and sim3d/batch3B.npz (session workspace; sha256 pinned in SOURCES.json
raw_records_outside_project_archive) and the archived results/window{2,3}_final.json."""
import json, math, sys
import numpy as np
SP = sys.argv[1]
ARCH = sys.argv[2]
for f, d in (('sim2d/batchA2.npz', 2), ('sim3d/batch3B.npz', 3)):
    infos = json.loads(str(np.load(SP + '/' + f, allow_pickle=True)['infos']))
    keep = [i for i in infos if i['euler'] == 0 and i['asc_fail'] == 0]
    print('d=%d samples %d retained %d' % (d, len(infos), len(keep)))
    if d == 2:
        for k in ('n_max', 'n_sad', 'n_min'):
            a = np.array([i[k] for i in keep], float)
            print('  %s %.3f +- %.3f' % (k, a.mean(), a.std(ddof=1) / math.sqrt(len(a))))
        print('  Kac-Rice: max %.4f, saddles %.4f per 64^2' % (4096 / (2 * math.sqrt(3) * math.pi), 2 * 4096 / (2 * math.sqrt(3) * math.pi)))
    else:
        C = np.array([i['counts'] for i in keep], float)       # by index: min, sad1, sad2, max
        for j, nm in enumerate(('minima', 'saddles index 1', 'saddles index 2', 'maxima')):
            print('  %s %.3f +- %.3f' % (nm, C[:, j].mean(), C[:, j].std(ddof=1) / math.sqrt(len(C))))
        npk = (29 - 6 * math.sqrt(6)) / (5 ** 1.5 * 2 * (2 * math.pi) ** 2 * (3 / math.sqrt(15)) ** 3) * 16 ** 3
        print('  Kac-Rice (BBKS): extrema %.4f, saddles per index %.4f' % (npk, npk * (29 + 6 * math.sqrt(6)) / (29 - 6 * math.sqrt(6))))


def cdf(k, n, p):
    return math.fsum(math.comb(n, i) * p ** i * (1 - p) ** (n - i) for i in range(k + 1))


def bis(f):
    lo, hi = 0.0, 1.0
    for _ in range(200):
        m = (lo + hi) / 2
        lo, hi = (lo, m) if f(m) else (m, hi)
    return (lo + hi) / 2


for d in (2, 3):
    w = json.load(open(ARCH + '/results/window%d_final.json' % d))
    for dis in w['disagreement']:
        n = dis['n']; k = round(dis['rate'] * n)
        line = 'd=%d [%g,%g) %d/%d = %.3f%%' % (d, dis['lo'], dis['hi'], k, n, 100 * k / n)
        if n < 3000:
            lo = 0.0 if k == 0 else bis(lambda p: 1 - cdf(k - 1, n, p) >= 0.025)
            hi = bis(lambda p: cdf(k, n, p) <= 0.025)
            line += '  nominal 95%% Clopper-Pearson [%.3f%%, %.3f%%]' % (100 * lo, 100 * hi)
        print(line)
