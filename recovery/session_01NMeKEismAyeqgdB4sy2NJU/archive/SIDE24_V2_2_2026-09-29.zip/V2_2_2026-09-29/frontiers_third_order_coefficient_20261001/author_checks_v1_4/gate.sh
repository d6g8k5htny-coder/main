#!/bin/bash
# local replay of the workflow's checker steps (both modes, mutants, unknown label) + per-mutant failing checks
cd /home/claude/wt-216/frontiers/third_order_coefficient_20261001
S=/tmp/claude-0/-home-claude/b41b316f-232c-5cf7-a0ee-80f0de603a6f/scratchpad/pr216/v14
for flags in "-B -S" "-B -O -S"; do
  tag=$(echo $flags | tr -d ' -')
  python3 $flags c2_check.py > $S/out_$tag.json; echo "mode $flags rc=$?"
  for m in M1 M2 M3 M4; do
    python3 $flags c2_check.py --mutant $m > $S/mut_${m}_$tag.json 2>$S/mut_${m}_$tag.err; rc=$?
    fails=$(python3 -c "
import json,sys
d=json.load(open('$S/mut_${m}_$tag.json'))
print(','.join(k for k,v in sorted(d['checks'].items()) if not v['passed']))")
    echo "  mutant $m rc=$rc failing=[$fails]"
  done
  python3 $flags c2_check.py --mutant M9 >/dev/null 2>&1; echo "  M9 rc=$?"
done
cmp $S/out_BS.json $S/out_BOS.json && echo "modes byte-identical"
sha256sum $S/out_BS.json $S/out_BOS.json
echo done
