# exploration (outside the repository): d = 3 truncation order N = 8 versus N = 10 in the v1.3 checker
import sys, time
sys.path.insert(0, '/home/claude/wt-216/frontiers/third_order_coefficient_20261001')
import c2_check as C
t0 = time.time()
c8, c28 = C.coefficients(3, 'gauss', 8, C.RS, nb=40, nt=80, nq=32)
t1 = time.time()
c10, c210 = C.coefficients(3, 'gauss', 10, C.RS, nb=40, nt=80, nq=32)
t2 = time.time()
print('N=8 : c=%.15f c2=%.14f (%.0f s)' % (c8, c28, t1 - t0))
print('N=10: c=%.15f c2=%.14f (%.0f s)' % (c10, c210, t2 - t1))
print('shift c2 = %.2e, c rel = %.2e' % (c210 - c28, c10 / c8 - 1))
# pointwise kernel comparison at r = 0.011 and 0.007
for r in ('0.011', '0.007'):
    k8, k10 = C.Kernel(3, 8, r, 'gauss'), C.Kernel(3, 10, r, 'gauss')
    worst = 0.0
    for (b, k) in ((0.0, 1.0), (1.0, 0.3), (-1.5, 2.0)):
        m8, m10 = k8.cone_moments(b, 0.0, 32), k10.cone_moments(b, 0.0, 32)
        a8, a10 = k8.A(b, k, m8), k10.A(b, k, m10)
        worst = max(worst, abs(a8 / a10 - 1))
        print('r=%s (b,k)=(%g,%g) rel diff %.2e' % (r, b, k, abs(a8 / a10 - 1)))
    print('r=%s worst %.2e' % (r, worst))
