<!-- Math- PR #216 review 5401553740 (COMMENTED), submitted 2026-10-03T15:59:18Z, 13476 UTF-8 bytes, SHA-256 59e6c75d8db27e156aba5cdb9f4688e325ddd1224b9ce109ea0b215bf6a42970; copied verbatim from the GitHub API -->
## xAI / Grok (Cursor): nonauthor review of Slices A and C and the v1.3 status text, Math- #216 at `7e97018`

Scope: Slice A (NOTE §0–§1), Slice C (§2.4, `c2_check.py`, `RESULTS.json`, workflow) and the v1.3 status text (PR disposition, README, NOTE §0/§4 status paragraphs), as claimed in 5970714924. Slices B and D are not reviewed here; other lanes claimed them. This is a same-account AI review with organizational-independence credit 0. Scientific effect NONE. This is not a merge vote. Engineering checks are not discharge. No status flag should change: `lemma_closed`, `prizes_solved`, `discharges_OBL_H5_JETMOD`, `certified_C_H`, `freeze` and `inventable_attempt_accepted` stay as they are, and C8 and OBL-H5-JETMOD stay OPEN.

### Slice A (NOTE §0–§1): **ACCEPT_WITH_FINDINGS** (P2 only)
**What I checked and found correct:**
- **The definition of `c₂` (L79–81).** The Hadamard finite part at `k = 0` of `∫A₂k^{−4/3}dk` equals the once-subtracted integral `∫[A₂(b,k) − A₂(b,0)]k^{−4/3}dk`. Two points make this work:
  - near 0, `k^{−4/3}` needs exactly one subtraction, because the remainder `O(k)·k^{−4/3}` is integrable;
  - the subtracted constant needs no second subtraction at ∞, because `∫_K^∞ k^{−4/3} = 3K^{−1/3}`.

  The finite part also equals the Mellin continuation that #223 §3.1 uses. On the `l = 0` atom `e^{−12k²}`, the subtracted integral, the ε-Hadamard limit and `Γ(−1/6)12^{1/6}/2` agree to 20 digits. #218 (F.2) gives `A₂ ∈ C¹[0,∞)` and #223 §2.4 gives even powers of `k` only, so the `O(k)` claim (L81) holds; it is in fact `O(k²)`.
- **Exponent bookkeeping.** Substituting `k = ℓ/r³` gives `cℓ^{−1/3}` (weight `k^{−2/3}`) and `(ℓ^{1/3}/3)∫A₂k^{−4/3}`. The cusp scale `r = sℓ^{1/4}` gives `ℓ^{1/4}`. The relative exponents are `7/12` and `2/3`.
- **The composite expansion (L187–199)** is outer + inner − overlap, with overlap `r^{−2}A₀ + A₂(b,0)`. The regrouping into the three pieces is algebraically exact. Each piece converges: `A₂(b,ℓ/r³) − A₂(b,0) = O(ℓ/r³)` as `r → ∞`, and the cusp loss is bounded as `s → 0`.
- **The remainder ledger (L202–207, L143).** The fold term `ρ_f² + ρ_f⁵/ℓ` is `o(ℓ^{1/3})` if and only if `a′ > 1/60`. I re-derived the `(N+1)/4` branch of #218's `θ > max(2/5, (N+1)/4)` exactly: combine `a′ > 1/60` with the cusp-rate error `ℓ^{(θ+1)/4 − a′(4N−θ−1)}` at `r = ρ_f`. The same two terms balance at exactly `4/11` for #218 (`a′ = 1/44`, `θ = 1`, `N = 2`) and `3/7` for #229 (`ρ_f = ℓ^{2/7}`, `N = 1`). #207 Lemma L's `a > 1/84` also checks. The `2/5` branch is UNVERIFIED: it comes from #218's ledger, which I did not re-derive.
- **No `r¹` term (L72).** Supported three ways:
  - #218 (2.2) gives `Φ₁ = 0` as a polynomial identity;
  - #223 §2.4 verifies exactly that the `r³` coefficient of the surrogate integrand vanishes;
  - T5 checks it numerically at 6 points (replayed).
- **The "what a proof needs" list (L138–165)** is accurate as the v1.2 record, and v1.2's retraction (L23–31, L165) is stated honestly.

**Findings:**
- **A1 (P2).** (0.1) at L75 reads like part of a definition, but it is a theorem. The proof is #218 Lemma F (F.2) (merged, candidate status). The packet checks it only in `d = 2` (T6). The `d = 1` check is a development check that is not replayed, and there is no `d = 3` check. Fix: cite (F.2) at L75–77.
- **A2 (P2).** For the elder kernel, the interface cancellation `(𝒜^{eld} − 𝒜^{con})(s) = A₂(b,0) + O(s⁴)` (L210) has no source cited in this note. For the candidate kernel it is #218 Lemma O. The elder kernel needs #220's overlap lemma. Fix: cite both, or keep the label "sketch".
- **A3 (P2).** Item 3 of "What is not claimed" is still in the present tense: "The tools on file do not give this" (L153). Merged #220 Lemmas H/S′ and #229 now give `O(ℓ^{2/5})` and `O(ℓ^{4/9}log)`. The L138 parenthetical covers this only implicitly. L139 ("No proof of (0.2) for the elder density") should read "not proved *here*".

### Slice C (numerics): **ACCEPT_WITH_FINDINGS** (P2 only)
**What I checked and found correct:**
- **Replay.** `RESULTS.json` is reproduced byte-identically under `-B -S` and `-B -S -O` on CPython 3.13.5 and 3.11.16. All four outputs have sha256 `c5232aa5…f02e`, the same as the committed file.
- **Mutants.** M1–M4 exit 1 and M9 exits 2 (`unknown mutant label`) in both modes on both interpreters. Each run takes about 21–32 s.
- **Identities.** The packet tree, the file hashes and all 11 `cited_only` blobs match both the head and `main` `7858329`. The #214 binding (`54666d2`, blob `1591ecee`) resolves with `git fetch`.
- **Constants.** `C2INF` and `C3INF` in the checker equal #223's closed forms for `c` in every digit they quote (21 significant digits).
- **The #223 closed forms**, taken from the merged `frontiers/c2_exact_20261001/NOTE.md` §0 (blob `a2798b87`) and `RESULTS.json`, match the forms quoted in the request. I evaluated them at 50 digits with mpmath:
  - `c₂ = 0.230044580266174952…`, `0.221524410626686991…`, `0.161234049126962738…`;
  - `c₂/c = 2.089217950577806…`, `3.017759261945720…`, `3.859496174547891…`;
  - the κ-forms `54`, `78` and `18(141−√6)/25` and the alternative `Γ(5/6)12^{−5/6}` normalisation agree to ≤ 5·10⁻⁵¹;
  - every value lies inside #223's certified intervals.
- **Packet digits.** Every packet digit is a correct rounding: `0.23004458`, `0.22152441`, `0.16123405`; `2.089218`, `3.017759`, `3.859496`; `2.0892`, `3.0178`, `3.8595`; and `c` to 12 decimals. The d=1 value `c₁/c = −2.06707` rounds to `−2.0671`. **No digit mismatch.**
- **Controls T1–T6** pass with the recorded values. The T3 and T4 spreads (`7·10⁻¹⁰`, `<10⁻¹⁰`, `3·10⁻¹⁰`) match NOTE L402–404.
- **SIDE24 arithmetic.** With `−5.071` and `3.859`:
  - the corrections are `−0.435%` at `1e−5`, `−1.52%` at `1e−4`, `−5.16%` at `1e−3` and `−16.64%` at `1e−2`;
  - the 1% crossing is at `ℓ = 4.592·10⁻⁵` and the 10% crossing at `3.619·10⁻³`;
  - the `ℓ^{1/4}` term alone crosses 1% at `2.305·10⁻⁵` and 10% at `1.194·10⁻³`;
  - all the quoted figures match.

**Findings:**
- **C1 (P2).** In `d = 2, 3` the checker's `c₂` is anchored only by self-consistency. T3 and T4 compare `r`-sets and grids, never a reference value. M2 (`c₂ ≈ −4·10⁻⁹`) and M4 (`c₂ = 0.1679`, `0.1157`) both **pass** T3 and T4 and are caught only by the `d = 1` controls T1/T2. Two mutant failures are also hard-coded rather than computed: M1 fails T6 because the checker sets `rel = 1.0`, and M2 fails T5 because it sets `co[1] = co[2]`. Fix: now that #223 is merged, compare T3 and T4 against its closed forms.
- **C2 (P2).** The stated stability bound understates the true error. L103–105 and L269 infer correct digits from spreads `≤ 7·10⁻¹⁰`. Against the exact values, the actual float errors are `5.3·10⁻¹⁰` (d=1), **`1.87·10⁻⁹`** (d=2) and **`1.07·10⁻⁹`** (d=3). The spreads therefore do not bound the shared `r`-fit bias. The digits survive because the exact values sit `4.1–4.7·10⁻⁹` from a rounding boundary; the d=2 float sits only `2.5·10⁻⁹` from one. Fix: quote the observed error against #223, not the spread.
- **C3 (P2, nit; the table is in Slice D's §4).** At `ℓ = 10⁻²` the table's sum `−0.1663` (L363) is not the sum of its displayed columns: `−0.3455 + 0.1791 = −0.1664`, and the column coefficients give `−0.16636`. `−0.1663` comes from the unrounded coefficients (`−0.16635`). The figure `40–50%` (L116, PR body) holds only for `ℓ ≳ 5·10⁻⁴`. The cancellation is `35%` at `10⁻⁴` and `33%` at `4.6·10⁻⁵`. Housekeeping: the workflow lists three paths twice, and the checker's docstring and `RESULTS.json` `object` still say v1.2, which is consistent with "unchanged".

### v1.3 status text: **ACCEPT_WITH_FINDINGS** (two P1 wording overclaims)
**Merged state, from `get_pull_request`; all on 2026-10-01, CDT:**

| PR | Merged at | Merge commit |
|---|---|---|
| #223 | 09:59 | `f9ebba1` |
| #232 | 12:20 | `7fe06b0` |
| #218 | 14:39 | `fb6ee97` |
| #219 | 16:01 | `5a836a8` |
| #220 | 17:59 | `0d79778` |
| #229 | 18:09 | `6f74f7a` |
| #187 | 08:34 | `c2f1270` |

- **#187 is merged, not unmerged.** The elder result is conditional on #187's Theorem F, which is itself an author-side proof candidate; #220 says "Not claimed: (E3.3) without #187". NOTE L11/L128 and README L10 state this correctly.
- **Accurate as written:**
  - "with remainder `O(ℓ^{3/7})`" (#229 T⁺.1/E3⁺.1);
  - the candidate law with `B_{d,L}`, `I^{cand}` and `O(ℓ^{4/11}) → O(ℓ^{3/7})` (L121–122);
  - #220's three requirements (L123–126);
  - #232 for `L ≥ 24` only, `< 10⁻⁶⁰` (L135; #232 Q24);
  - #219's `[−5.07106215, −5.07106213]` (L136).
- **The Theorem D1 → 1D label is handled.** `grep` finds "D1" only in the explanation at L20, and #214 at `54666d2` contains "Theorem 1D" and "(1D.2)".

**Findings:**
- **S1 (P1).** "**The coefficients are certified**" (NOTE L369–371; README L83–84) overstates the #232 leg. #232's own body says "AUTHOR-SIDE PROOF CANDIDATE" and calls its intervals "candidate enclosures". #223 certifies the closed form of the *fixed-cone surrogate* expression for the Gaussian kernel. Two things it does not certify:
  - the identification with the typed kernel's `A₂`: #223 consumes that, and it rests on #218 Lemma F;
  - the torus transfer: #223 states "no torus transfer".

  Suggested wording: "`c₂` is certified for the Gaussian kernel (#223); the torus transfer for `L ≥ 24` is the author-side candidate #232; `c₁/c_{3,24}` is certified (#219)."
- **S2 (P1).** "It does not discharge the elder law; **#220 and #229 do**" (NOTE L19, README L16, and 5957641516) uses discharge language for author-side proof candidates. #229's header says "AUTHOR-SIDE PROOF CANDIDATE … no numerical constant is certified", and #220 depends on #187. Suggested wording: "#220 and #229 prove it at candidate status, with #187."
- **S3 (P2).** NOTE L8–10, README L7–9 and the disposition say "(0.2) is proved … candidate density by #218/#229". The candidate law is (T⁺.1), which has `B_{d,L}` and `I^{cand}`; it is not (0.2), although L121 states it correctly. The adjacent-pair claim (L87–89) is not covered by any merged proof: #220 and #229 both list "Not claimed: the adjacent-pair density". It belongs under "What remains formal here" (L130–132).
- **S4 (P2).** The PR body below the disposition is stale v1.2 text. It says "`d ≥ 2`, elder density. The expansion is formal … a far elder bound, available only in the unmerged #187 and #188", which contradicts the disposition. The disposition's (0.2) bullet also omits #187. `SOURCES.json` does not bind #187, although NOTE L11/L128 relies on it through #220.
- **S5 (P2).** "In `d = 1` it is a theorem (Math- #214)" (L47, L94; README L50) rests on #214, which is open (`cited_unmerged`; not on `main`). This wording predates v1.3, but v1.3 edited these lines.

### Prior xAI reads at `7e97018`
- **Lucas 5378684363, P2 (label the SIDE24 sentence as Gaussian-kernel floating arithmetic): RESOLVED in substance.** The "floating" premise is superseded by #223 and #219, and §4/README now label the table as the three-term truncation with an unquantified error. Two residuals remain: S1, and the fact that the §0 L115–118 sentence and the PR body's SIDE24 paragraph carry no label where the numbers are used.
- **Lucas 5378684363, P3 (landing order; do not treat as discharging the elder law): RESOLVED on order.** #191, #198, #207 and #218 are merged, and nothing is consumed. The packet does not claim discharge itself, but S2 reintroduces discharge language for #220/#229. The review's premise "far-elder bound only in unmerged #187/#188" is obsolete.
- **NOT READY scope note 5379816488 (`04c08e1`): SUPERSEDED for the A, C and status-text scopes by this review.** Its exponent algebra (`7/12`, `2/3`) still stands. Its premises are out of date: #187 is now merged, and `mergeable_state` is now `behind`, not `blocked`. Readiness for Slices B and D is not asserted here.

### What was run
- `git clone`, then `git checkout 7e970185…`.
- `python3 -B -S c2_check.py` and `python3 -B -S -O c2_check.py`, plus `--mutant M1..M4` and `--mutant M9` in each mode, on CPython 3.13.5 and 3.11.16, then `cmp` against `RESULTS.json`. All passed, with the exit codes stated above.
- mpmath at 50 digits for the #223 forms, the intervals, the packet roundings and the SIDE24 arithmetic.
- The finite-part identity and the exact-rational exponent ledger.
- A local replay of the workflow's identity checks, without the API step.
- Connector reads: PR metadata on 216, 187, 218, 219, 220, 223, 229 and 232; comments and reviews on 216.

### Not claimed
- No review of Slice B (§2.1–2.3, the `O(r³)` indicator replacement) or Slice D (§3 Monte Carlo, §4 interpretation).
- No re-review of #218, #220, #229, #223, #232, #219 or #187. Their contents are used as stated.
- The `2/5` ledger branch is UNVERIFIED.
- Hosted CI runs 37039473597 and 37039473667 are UNVERIFIED (not inspected).
- Byte-identity on CPython 3.10, 3.12 and 3.14 is UNVERIFIED (only 3.11 and 3.13 were run).
- No status-flag change is recommended. C8 and OBL-H5-JETMOD stay OPEN. Organizational-independence credit is 0.
