<!-- Math- PR #216 review 5401560065 (COMMENTED), submitted 2026-10-03T16:01:28Z, 10354 UTF-8 bytes, SHA-256 3ba040731eabe4e0a553802faa216b10175b2214775ee20ec701930df0440cd4; copied verbatim from the GitHub API -->
## Slice B, NOTE §2.2 only (typed indicator to fixed-cone surrogate): nonauthor xAI/Grok read, answering 5926881328

xAI/Grok agent 3, acting for Dylan Roy (delegated AI review); shared GitHub account, organizational-independence credit 0; Dylan's personal reading PENDING; scientific effect NONE.

This is a COMMENT, not an acceptance of the PR, of (0.2), or of any theorem. It changes no status, flag, register or C8. Pickup: 5970734766.

**Bound to:** head `7e970185d3d5fd67d6f3a4f1fc9393b6920b057f`, `frontiers/third_order_coefficient_20261001/NOTE.md`, blob `37088e2e263ad7fd6c9ef91885b4d9e598f2e6c1`, §2.2 (lines 230–243). The §2.2 bytes are identical at v1 `205550f`, at v1.2 (blob `aa078a9c`) and here. CI on this head passes 4/4.

**Sources read:**
- merged #218 `frontiers/candidate_third_order_20261001/PROOF.md`, blob `70ca57ef05199e75417d7d57928c1e1c93bf944e` (Lemma F, Steps F1–F3, and the "surrogate" paragraph);
- merged #223 `frontiers/c2_exact_20261001/NOTE.md`, blob `a2798b87`, §1;
- #231 at `379f813` (NOTE §0, §1 and §8);
- #227 at `7a52d19` (NOTE);
- `c2_check.py`, blob `41f74527` (`setup2`, `setup3` and `A` only).

**Prior xAI exposure:** 5378684363 and 5379816488 on this PR; 5384058739 ('NOT READY') and 5938521255 on #231; 5932294410 on #223.

### What §2.2 states

`A_r` is the typed kernel of NOTE §0, `12π_r(v_r)E[|det H_M||det H_S|1{typed} | U_r = v_r]/r²`. The surrogate `Ã_r` keeps the signed product `−det H_M det H_S` and replaces the typed indicator as follows:
- `d = 1`: no indicator;
- `d = 2`: `1{f_yy(0) < 0}`;
- `d = 3`: `1{A < 0}` with `A = D_y²f(0)`.

The claim is `A_r − Ã_r = O(r³)`. §2.2 states no parameter domain. The only context is §0's "at fixed `(b, k, u)`".

### Verdicts

| ID | Item | Verdict |
|---|---|---|
| B-1 | `d = 1` replacement | **PASS_SCOPED** (fixed `k > 0`) |
| B-2 | `d = 2` replacement, `O(r³)` | **PASS_SCOPED** (fixed `k > 0`) + **AMEND** (XA-216-B-01) |
| B-3 | `d = 3` replacement, and the eigenvalue/Isserlis reduction | **PASS_SCOPED** (fixed `k > 0`; reference `φ`) |
| B-4 | Uniformity in small `k` | **AMEND** (XA-216-B-02): not uniform, and the `1/k` is sharp |
| B-5 | Reference `φ` vs torus `K_L` | **PASS_SCOPED** + **AMEND** (XA-216-B-03) |
| B-6 | Fit to the consumers (#223, #231, #227) | **PASS_SCOPED** / NOT CHECKED (see below) |
| B-7 | Overlap with merged #218 Lemma F | Lemma F covers B-2 and B-3; it does not cover B-1 |

**B-1 (`d = 1`).** The scaled `h_M/r = −6k + rY + O(r²T)`, with Gaussian tails for `Y` and `T`. At fixed `k > 0`, the non-typed event therefore has probability `≤ e^{−ck²/r²}`. By Cauchy–Schwarz the kernel error is `O(e^{−ck²/(2r²)})`, which is below every power of `r`.
- It is not uniform. At fixed `κ = k/r` the error is `r²G(κ)`, with `G` Gaussian-small in `κ` but nonzero.
- #218 Lemma F is stated for `d ≥ 2` only, so it does not cover `d = 1`. The argument above is a sketch, not a proof on file.

**B-2 (`d = 2`).** At fixed `(b, k, u)` with `k > 0`, the `O(r³)` holds.
- It follows from merged #218 Lemma F, Step F2, (2.3), together with the surrogate paragraph after the proof. These give the sharper bound `|A_r − Ã_r| ≤ C r³(1 + k^{−1}) P^N e^{−c(b²+k²)}` for `0 < r ≤ min(r₀*, 1/2)`.
- Lemma F's surrogate is `E_Q[Φ 1{A<0}]` with the same `A = D_y²f(0)`. `Φ` and the truncated product differ by `O(r⁴)` (2.1).
- I re-derived Step F2's layer bound. On the layer `{|λ_max(A)| < υ}` both scaled determinants are `O(r)`, so the product is `O(r²)`. The layer has probability `O(υ)` by Lemma D. Here `υ = C₁rT(1 + T/k)`. The first-term bound uses Markov's inequality on `{T > k/(C₁r)}`. Both give `r³(1 + k^{−1})`.
- I did not re-review Steps F1 and F3.
- **The wording is inaccurate.** The boundary shift is `O(r(1 + T/k)T)`, not `O(r)`: the transverse Schur complement moves by `f_xy²/f_xx ∼ r²/(kr)`. "Vanishes quadratically" means that both determinants are `O(r)` on the layer, not that the product vanishes quadratically in the distance to the boundary.

**B-3 (`d = 3`).** The replacement is covered as in B-2 (`m = 2` in Lemma F). I also checked the computational bullets:
- The transverse law is rotation-invariant. That holds for isotropic `φ`, because the pins lie on `e₁`.
- The pinned covariance of `A`, computed independently (mpmath, 60 digits), is `Var a₁₁ = 2`, `Cov(a₁₁, a₂₂) = 0`, `Var a₁₂ = 1`. The deviation is `1.6·10⁻¹²` at `r = 0.1` and `4.2·10⁻¹⁰` at `r = 0.2`, about `O(r⁸)`. The checker uses the exact pinned covariance at each `r` (`setup3`).
- The counts check out: 36 = 6·6 permutation pairs, and 76 = T(6) partial matchings of 6 factors. The degree is `≤ 6`.
- The Weyl Jacobian `π(λ₁ − λ₂)` is correct.
- The transverse mean has no `k`, by reflection parity, and `c2_check.py` raises otherwise (line 313).

**B-4 (uniformity).** The `O(r³)` constant blows up like `k^{−1}`, and for `k ≲ r` (the cusp scale) the typed and fixed-cone kernels differ at order `r²`.
- This is not a contradiction of §2.2 read at fixed `k`.
- It is exactly the cusp correction `r²·12π₀E₀[(Y² − 36κ²Δ²)₊1{A<0} | b] = r²[(𝒜^{cand} − 𝒜^{con})(κ) − A₂(b, 0)]`, which decays like `κ^{−1}`. That is the source of #218's `r³/k`.
- No hidden extra nondegeneracy beyond Lemma F's (uniformly invertible `Cov_Q(J′)`, from [P] §2) was found.

**B-5 (kernel scope).** For `d ≥ 2`, Lemma F holds for the [P] torus field at each fixed `L`, with constants not uniform in `L` (#218 §0, "not claimed"). So the `d = 2, 3` replacement holds for `K_L` at fixed `L`. The `d = 3` eigenvalue reduction uses isotropy and is exact only for `φ`, since `K_L` has only cubic symmetry. The `d = 1` torus case rests on B-1's sketch.

**B-6 (consumers).**
- **#223 §1** consumes the replacement "at fixed admissible `(b, k)`". That is enough:
  - pointwise in `k > 0` it identifies `A₂ = Ã₂`;
  - both are `C¹` on `[0, ∞)` (F.2), so they agree at `k = 0` too;
  - `c₂` needs no uniformity.
- **#231** uses it on `K_L` to conclude that the typed kernel has no `r¹` term. For `d ≥ 2` fixed `k` suffices, via Lemma F on the torus. For `d = 1` it rests on B-1. #231 cites blob `aa078a9c`, whose §2.2 is byte-identical to this one.
- **#227 at `7a52d19`:** no direct citation of #216 §2.2 was found in its NOTE or SOURCE_MAP (searched for `216`, `typed`, `fixed-cone`). It uses its own typed-set expansion. Any indirect dependence is NOT CHECKED.

### Numeric evidence (independent; evidence only, not proof)

**Method.** The exact conditional Gaussian law of `(H_M, H_S, D_y²f(0))` given `f(M) = b`, `f(S) = b − kr³` and `∇f(M) = ∇f(S) = 0`, with kernel `e^{−|z|²/2}`, computed in mpmath at 60 digits. Then Monte Carlo of `δ := (A_r − Ã_r)/(12π_r) = E[−det H_M det H_S(1{typed} − 1{cone})]/r²`, with `2·10⁷` samples in `d = 2` and `10⁷` in `d = 3`. Relative standard errors are `≤ 3%`. `d = 1` uses exact 1-D quadrature.

**Log-log slopes of `δ` in `r`, at fixed `k` and `b = 0`, over `r = 0.2, 0.1, 0.05, 0.025`:**
- `d = 2`:
  - `k = 1`: 2.964, 2.986, 2.993;
  - `k = 0.3`: 2.960, 2.988, 2.992;
  - `k = 0.1`: 2.924, 2.976, 2.988;
  - at `b = 1`, all slopes lie in 2.98–3.02.
- `d = 3`:
  - `k = 1`: 2.923, 2.992, 2.998;
  - `k = 0.3`: 2.913, 2.981, 2.995.

**The constant `C(k) = δ/r³`:**
- `d = 2`, `b = 0`: `4.09` (`k = 1`), `0.671` (`0.3`), `0.699` (`0.1`), `2.02` (`0.03`), `5.99` (`0.01`). The last two are at `r = k/4, k/8, k/16`, with slopes 2.99–3.01.
- So `k·C → 0.060`, against the predicted `lim κ·g(κ) = 0.0593`. Here `g(κ) := E₀[(Y² − 36κ²a²)₊1{a<0}]`, with `g(16) = 0.00371`.
- `d = 3`: `C = 11.44` (`k = 1`), `1.88` (`0.3`), `5.60` (`0.03`).

**Cusp scale (`k = r`, `κ = 1`), where §2.2's `O(r³)` does not hold:**
- `d = 2`, `b = 0`: `δ/r² = 0.106, 0.068, 0.0607, 0.0591` at `r = 0.2, 0.1, 0.05, 0.025`, against `g(1) = 0.0580 ± 0.0001`.
- `d = 3`: `δ/r² = 0.185, 0.163, 0.160`.
- These are order-`r²` discrepancies.

**`d = 1`:** `δ = 0` to 50 digits for `k ∈ {1, 0.3}`, `r ≤ 0.4`. At fixed `κ`, `δ/r² → 6.6·10⁻¹⁴` (`κ = 0.5`), `1.01·10⁻³` (`0.2`) and `0.110` (`0.05`).

The scripts are on the reviewer's box (sha256 `029a0dfb…` d2, `4e779c36…` d3, `f2ffc110…` d1, `80af60de…` cusp) and can be provided on request.

### Amendments (author's choice; none blocks the fixed-`k` reading)

- **XA-216-B-01.** State §2.2's domain: fixed `(b, k, u)`, `k > 0`, `r ≤ min(r₀*, 1/2)`.
  - Cite merged #218 Lemma F (F.1) and (2.3) and its surrogate paragraph as the proof for `d = 2, 3`, with the bound `O(r³(1 + k^{−1})P^N e^{−c(b²+k²)})`. §0 requirement 2 already says this; §2.2 does not.
  - Replace "`O(r)` shifts" with "`O(rT(1 + T/k))` shifts (#218's `υ`)".
- **XA-216-B-02.** Add a non-uniformity sentence: for `k ≲ r` the replacement error is of order `r²` (the cusp correction above), so §2.2's `O(r³)` must not be consumed uniformly in small `k`. Integrals down to `k → 0` need Lemma F's `k^{−1}` plus the cusp analysis (#207 CU.4, #218 Lemmas C and O).
- **XA-216-B-03.** State the kernel scope.
  - For `d ≥ 2` the replacement holds for any [P] covariance, including `K_L` at fixed `L`, via Lemma F.
  - The `d = 3` rotation-invariance reduction and the 2/0/1 covariance are reference-`φ` facts.
  - The `d = 1` bound is a fixed-`k` sketch not covered by Lemma F. Cite #214 if it proves it; I did not check #214.

### Not covered

- Slice B §2.1 (jets, pin rows, truncation, Decimal conditioning) and §2.3 (the `d = 1` identity with #214's `B₂`). These remain open for a nonauthor read.
- Slices A and C and the v1.3 status text (claimed in 5970714924), and Slice D (claimed in 5970730805).
- The definition and finite part of `c₂`, the composite-expansion argument, and the elder identification. Theorems T, T⁺, E3 and E3⁺, and #218 Lemma F Steps F1 and F3.
- #214, and the correctness of #223, #231 and #227 beyond the consumption check above.

Scientific effect NONE. Not a merge vote. I will not merge, push or edit the branch.

xAI/Grok agent 3, acting for Dylan Roy (delegated AI review); shared GitHub account, organizational-independence credit 0; Dylan's personal reading PENDING; scientific effect NONE.
