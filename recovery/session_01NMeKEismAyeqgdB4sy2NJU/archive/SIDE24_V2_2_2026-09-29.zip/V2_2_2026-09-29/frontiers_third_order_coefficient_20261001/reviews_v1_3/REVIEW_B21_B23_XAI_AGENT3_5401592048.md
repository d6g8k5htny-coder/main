<!-- Math- PR #216 review 5401592048 (COMMENTED), submitted 2026-10-03T16:10:46Z, 8958 UTF-8 bytes, SHA-256 bdd48012849c1ca2d6568389cde4080aa59790cf2b20ce844ee3f8471a273070; copied verbatim from the GitHub API -->
## Slice B, NOTE §2.1 and §2.3: nonauthor xAI/Grok review, completing Slice B (answers 5926881328; pickup 5970734766, extended by 5970863484)

xAI/Grok agent 3, acting for Dylan Roy (delegated AI review); shared GitHub account, organizational-independence credit 0; Dylan's personal reading PENDING; scientific effect NONE

**Prior xAI exposure:**
- 5378684363 and 5379816488 on #216;
- 5384058739 ('NOT READY') and 5938521255 on #231;
- 5932294410 on #223;
- my own items on this PR: 5970734766, 5401560065 (§2.2) and 5970863484.

**What this is.** A COMMENT, not an APPROVE, and not a merge vote. It does not accept the PR or any theorem, and it changes no status or flag. Verdicts are scoped to the cited lines. Numbers marked *evidence* are exploration outside the repository; they are not certification.

**Binding.**
- Head `7e970185d3d5fd67d6f3a4f1fc9393b6920b057f`, unchanged since 5401560065.
- `frontiers/third_order_coefficient_20261001/NOTE.md`, blob `37088e2e263ad7fd6c9ef91885b4d9e598f2e6c1`: §2.1 is lines 222–228 and §2.3 is lines 245–252.
- `c2_check.py`, blob `41f745275db81f6332e791759db5858eec8c5365`.
- [R] = `LIFETIME_REMAINDER.md`, blob `247b3ecf`.
- #214 `PROOF.md` at `54666d2`, blob `1591ecee` (open PR).

### §2.1 Pinned Gaussian structure

**B-8, jets: PASS.**
- `Cov(∂^αf(0), ∂^βf(0)) = (−1)^{|β|}∂^{α+β}ρ(0)` is correct for stationary `f`.
- The checker's `rho_der` reproduces `(−1)^m(2m−1)!!` (Gaussian) and the factor `(1+4^m)/2` (mixture).
- Jet orders are `N = 12, 10, 8`.

**B-9, pin rows and Hessians: PASS.**
- The pin rows (`c2_check.py` 158–175) are [R] §2's rows exactly:
  - `(f(a)+f(c))/2`, `(f(c)−f(a))/r`, `(f_x(c)−f_x(a))/r`;
  - `(6/r²)[f_x(a)+f_x(c)−2(f(c)−f(a))/r]`;
  - transverse `(f_y(a)+f_y(c))/2` and `(f_y(c)−f_y(a))/r`.
- The target `v_r = (b−kr³/2, −kr², 0, 12k, 0…)` follows from `f(M) = b`, `f(S) = b−kr³` and zero gradients; I checked the row algebra.
- The rows and Hessians at `±(r/2)e₁` are Taylor series in `J`. The truncation is the only approximation.

**B-10, truncation: PASS_SCOPED + AMEND (XA-216-B-04).**
This is *evidence*: the checker's own `Kernel(d,N,r).A(b,k)` compared with an exact, untruncated surrogate kernel. The exact kernel uses closed-form kernel derivatives at the displaced points and mpmath at 60 digits. Test points were `(b,k) ∈ {(0,1), (1,0.3), (−1.5,2)}` and `r ∈ {0.003, 0.007, 0.011}`.
- `d = 1, N = 12`: max relative difference `6.5·10⁻¹⁵`. The worst point is in the far tail (`A ≈ 3·10⁻²¹`); the others are `≤ 1.5·10⁻¹⁵`.
- `d = 2, N = 10`: max `3.7·10⁻¹⁵`.
- For `d = 1, 2` these differences are at float resolution, so the claim holds to within the precision of the float output.
- **`d = 3, N = 8`: the claim fails as stated.** Comparing `N = 8` with `N = 10`:
  - at `r = 0.011`: `6.4·10⁻¹⁴`, `1.2·10⁻¹⁴` and `2.3·10⁻¹³` relative;
  - at `r = 0.007`: `6.2·10⁻¹⁵`, `1.1·10⁻¹⁵` and `2.2·10⁻¹⁴`.
  - The ratio of about 10.3 between the two `r` values is consistent with the nominal `r^{N−2}`.
- **Consequence for the result: immaterial.** `coefficients(3,'gauss',N,RS,40,80,32)` gives `c₂ = 0.16123405017410` at `N = 8` and `0.16123405016253` at `N = 10`, a shift of `1.2·10⁻¹¹`. In `d = 2`, `N = 10` and `N = 12` give an identical `c₂ = 0.2215244125233545`.
- *XA-216-B-04, the fix:* replace "below `10⁻¹⁵` relative at `r ≤ 0.011`" with a statement per dimension. Either raise `N` to 10 in `d = 3`, or write "`≲ 10⁻¹⁵` in `d = 1, 2`; `≲ 3·10⁻¹³` in `d = 3`, moving `c₂` by about `10⁻¹¹` (measured)". Also say that "`r^{N−2}` × Gaussian moment" gives the order, not a stated constant.

**B-11, conditioning: PASS.**
- The conditional variances are `O(r⁴)`. For example, `Var(f_xx(M) | pins) ≈ 0.17r⁴` at `r = 0.1`.
- They come from `O(1)` covariances cancelling, since `|det| = 12r^{−(d+3)}` in [R].
- The end-to-end agreement in B-10 shows that Decimal at 50 digits suffices.

### §2.3 The finite part in `d = 1`

**B-12, the `b`-integral: PASS + AMEND (XA-216-B-05).**
- With `Y = f₄/12`, `∫π₀E₀[f₄²]db = p₁₂p₃·σ₄²` holds. By parity independence, `E[f₄² | a₁ = 0, a₂ = 0, a₃ = α] = Var(a₄|a₂) = σ₄²`.
- *XA-216-B-05:*
  - (0.1) is at `k = 0`, so its `b`-integral is `−(σ₄²/12)p₁₂p₃(0)`.
  - The `k`-dependent `−(σ₄²/12)p₁₂p₃(12k)` is the cusp component of `∫A₂(b,k)db`, that is, the same expression evaluated at `v₀(b,k)`. Say so.
  - Cite #214 **§2(d)** (definition of `B₂^{(2)}`, line 235) instead of §2(e) (its closed form).

**B-13, finite part = `2B₂^{(2)}`: PASS (algebra).**
- With `α = 12k`: `(1/3)|S⁰|·(−σ₄²p₁₂/12)·12^{1/3}∫(p₃(α)−p₃(0))α^{−4/3}dα = −(σ₄²p₁₂/18)12^{1/3}∫… = 2B₂^{(2)}`, with `|S⁰| = 2` giving `ν = 2ν₊`.
- *Evidence:* by quadrature this piece is `0.1278025445920` against `2B₂^{(2)} = 0.1278025445923` (Gaussian), and `0.3417624077411` against `0.3417624077424` (mixture).

**B-14, fold part = `2B₂^{(1)}`: PASS_SCOPED + AMEND (XA-216-B-06).**
- The NOTE asserts this without derivation.
- *Evidence (strong, pointwise in `k`):* I took the exact kernel and Richardson extrapolation in `r` of `F_r(k) := ∫db A_r(b,k)` (mp, 60 digits), at `k ∈ {0.02, 0.1, 0.25, 0.5, 1}`:
  - `F₀ = 3α²p₁₂p₃(α)` to `≤ 1.3·10⁻²³` relative.
  - `F₂ = (3/4)α²p₁₂p₃(α)(u(α)+2c₂) − (σ₄²/12)p₁₂p₃(α)`, with #214 Lemma 1.3's `c₂, d₂, q₂`, to `≤ 2·10⁻¹⁷` relative for the Gaussian kernel and `≤ 2·10⁻¹⁶` for the mixture.
  - So the split into a fold piece and a cusp piece holds **pointwise**, not only in total.
  - Sample values: `F₂(0.1) = −0.0242954313558574` and `F₂(0.5) = 0.0685485585087909` (Gaussian).
  - The fold piece integrates to `0.1022420356738555`, equal to `2B₂^{(1)}` in all 16 digits (Gaussian); for the mixture, `0.2342803347268223`, again equal to `2B₂^{(1)}`.
- *XA-216-B-06:*
  - Write out the coordinate map (`t = r`, `τ = r/2`, `α = 12k`, `h = ℓ`, the `r²`-order of `∫db r^{−2}A_r` ↔ the `τ²`-order of `(12/t⁴)p_t m²`), or label the identity as checked numerically.
  - State that it consumes #214 Lemma 1.3, which is open and not reviewed here. "`d = 1` is a theorem" is conditional on #214; cf. S5 in 5401553740.

**B-15, T1/T2 totals: cited, not replayed (Slice C).**
- I recomputed the closed forms independently: `2B₂ = 0.230044580266175` (Gaussian) and `0.576042742469266` (mixture). The NOTE's `0.2300445803` and `0.5760427425` are correct roundings.
- The checker's `…5808` and `…7428` lie within `6·10⁻¹⁰` and `4·10⁻¹⁰`, as §2.4 says.

**B-16, `r¹` term (outside §2.3, see the overlap below).**
- *Evidence, exact surrogate:* `A_r − A_{−r}` scales as `r³`. From `r = 0.01` to `0.05` the ratio is 125.0 at `d = 1` `(1,0.3)`, and 125.1 and 125.0 at `d = 2` `(0,1)` and `(1,0.3)`.
- So there is no `r¹` term, but there **is** an odd `r³` term. This is consistent with the `(1, r², r³, r⁴)` fit.

**Falsifiers sought:**
- truncation exceeding the stated bound (found in `d = 3`; immaterial);
- the split failing pointwise, or a factor-2 orientation error (not found);
- non-Gaussian spectral moments, via the mixture (not found);
- the `k^{−4/3}` endpoint: the fold piece is `O(k²)` and the cusp subtraction vanishes to `O(k²)` (no issue).

### Overlap with merged #218
- **Lemma F** (`d = 2, 3`, typed indicator → cone) does not touch §2.1 or §2.3. §2.3 is `d = 1`; see B-7 in 5401560065.
- **#218's surrogate paragraph** (for `N ≥ 6`, the exact `r²`-coefficient of the truncated surrogate is `A₂`) covers §2.1's truncation qualitatively in `d ≥ 2`. B-10 quantifies it.
- **#218 Step F3** (evenness and smoothness of the pinned law) and T5 carry the absence of an `r¹` term in `d ≥ 2`. #231 Lemma E (open) does the same for the surrogate.
- **Scope note.** The expansion `Ã_r = A₀ + r²A₂ + O(r³)` and the absence of an `r¹` term sit in NOTE §0 and T5 (Slices A and C), not in §2.3. I did not re-review #218 F1 or F3; B-16 is evidence only.

### Combined Slice B summary (§2.1–§2.3)
- **§2.1** (this review): PASS on jets, rows and conditioning; truncation PASS_SCOPED + AMEND B-04 (`d = 3` bound misstated; `c₂` effect `1.2·10⁻¹¹`).
- **§2.2:** per 5401560065. B-1 and B-3 PASS_SCOPED; B-2 and B-5 PASS_SCOPED + AMEND; B-4 AMEND (not uniform in small `k`).
- **§2.3** (this review): PASS on the algebra; fold part PASS_SCOPED + AMEND B-05 and B-06. Numerically confirmed pointwise for two kernels; conditional on open #214.
- **Amendments:** XA-216-B-01 to B-06. None blocks the reported digits.

**Not covered:**
- Slices A, C and D;
- the proof of #214;
- a re-review of #218 F1 and F3;
- non-Gaussian kernels in `d = 2, 3`.

Scientific effect NONE.
