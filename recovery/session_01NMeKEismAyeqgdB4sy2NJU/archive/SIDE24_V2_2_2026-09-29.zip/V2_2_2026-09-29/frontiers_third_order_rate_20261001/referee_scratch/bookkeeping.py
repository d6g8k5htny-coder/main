"""Referee: exact checks of the bookkeeping inequalities of Lemma C+ (C.2 Case 3, Step C3), Lemma CE+ (B_lambda, B_kappa,
B_5, E4-E6) and Prop W+ (W3 chain), with r = s^2, kappa = t^2 exact squares; extreme kappa included."""
from fractions import Fraction as Fr
import random
rng = random.Random(3)
bad = {}
def chk(name, cond):
    if not cond: bad[name] = bad.get(name, 0) + 1
n = 0
for _ in range(20000):
    s = Fr(rng.randint(1, 400), 400)                      # r = s^2 in (0, 1]
    tmax = 1/s                                            # kappa r <= 1  <=>  t s <= 1
    t = tmax*Fr(rng.randint(1, 10**4), 10**4)
    if rng.random() < 0.2: t = tmax*Fr(1, rng.randint(10**3, 10**6))   # tiny kappa
    r, kap = s*s, t*t; k = kap*r; n += 1
    one = Fr(1)
    # (C.2) Case 3: w <= 36 kappa^2 r^2 = 36 k^2 <= 36 k ; (12 kappa r + 2 eta)^2 with eta ~ r: <= C (k + r^2)
    chk('C2case3: k^2 <= k', k*k <= k)
    chk('C2case3: (k + r)^2 <= 2(k + r^2) + 2k', (k + r)**2 <= 4*(k + r*r) + 2*k)
    # Step C2+: k + r^2 <= r(1 + kappa)
    chk('C2+: k + r^2 <= r(1+kappa)', k + r*r <= r*(1 + kap))
    # Step C3 / E5: r^2(1+kappa)^2 = (r+k)^2 <= 2 r(1 + kappa)  (needs r + k <= 2)
    chk('C3: r^2(1+kappa)^2 <= 2r(1+kappa)', r*r*(1 + kap)**2 <= 2*r*(1 + kap))
    # B_lambda: kappa^2 min(1,kappa) (r^3 + r^{3/2} + (r/kappa)^{3/2}) <= 3(r + kappa^2 r^{3/2})
    mn = min(one, kap)
    lhs = kap*kap*mn*(r**3 + s**3 + s**3/t**3)
    chk('B_lambda', lhs <= 3*(r + kap*kap*s**3))
    # B_kappa: kappa^2 min(1,kappa) min(1,(r/kappa)^3) <= r^3
    chk('B_kappa', kap*kap*mn*min(one, (r/kap)**3) <= r**3)
    # E4: kappa^2 r^2 = k^2 <= kappa r ; E6: k^2 <= kappa r
    chk('E4/E6', k*k <= kap*r)
    # CE+ => CE: kappa^2 r^{3/2} + kappa^3 r^2 <= 2 kappa^2 r ; r(1+kappa) <= r(1+kappa)^2
    chk('CE+ implies CE', kap*kap*s**3 + kap**3*r*r <= 2*kap*kap*r)
    # W+ (only for kappa <= 1): chain and (W+) => (W.1) for k <= r
    if kap <= 1:
        import math
        L = Fr(math.floor(1000*math.log(2/float(r))), 1000)       # rational lower proxy for log(2/r) >= 0
        a = kap**3 + kap*kap*r + kap*r*r + r**3*L
        b = (kap + r)**2*(kap + r*L)
        chk('W3 chain', a <= b <= (1 + L)*(kap + r)**3)
        chk('(k+r)^3 <= 4(k^3+r^3)', (kap + r)**3 <= 4*(kap**3 + r**3))
        chk('W+ => W.1 (const 2*(1+0.74))', b <= 2*(kap*kap + r*r)*(1 + Fr(74, 100)))
print('instances', n, 'failures', bad if bad else 'none')
