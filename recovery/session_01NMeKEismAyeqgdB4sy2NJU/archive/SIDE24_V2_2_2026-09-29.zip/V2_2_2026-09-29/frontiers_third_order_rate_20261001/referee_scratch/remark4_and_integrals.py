from fractions import Fraction as Fr
import sympy as sp
# Remark 4 numbers
c, c1, c2 = 0.0417759, -0.2118484, 0.1612340
print('c1/c =', c1/c, ' (packet: -5.0711)')
print('c2/c =', c2/c, ' (packet: 3.8595 / 3.859496)')
# with the more precise source values (#207 sec 8, #218 Remark 2)
C, C1, C2 = 0.0417759318, -0.21184835, 0.16123405
print('precise: c1/c =', C1/C, ' c2/c =', C2/C)
# exponents
print('relative remainder exponent 3/7+1/3 =', Fr(3,7)+Fr(1,3), '; #220: 4/11+1/3 =', Fr(4,11)+Fr(1,3))
print('l^{1/4}/l^{-1/3} ->', Fr(1,4)+Fr(1,3), ' l^{1/3}/l^{-1/3} ->', Fr(2,3))
# (W+.3) integral
r, rho = sp.symbols('r rho', positive=True)
I = sp.integrate(r**3*sp.log(2/r), (r, 0, rho))
print('int_0^rho r^3 log(2/r) dr =', sp.simplify(I), ' ; packet form - it =', sp.simplify(I - rho**4/4*(sp.log(2/rho)+sp.Rational(1,4))))
# cusp-error integrals of section 5
l = sp.symbols('ell', positive=True)
rf, rc = sp.symbols('rho_f rho_c', positive=True)
for name, integrand in [('r(1+kappa)', r*(1+l/r**4)), ('kappa^2 r^{3/2}', (l/r**4)**2*r**sp.Rational(3,2)), ('kappa^3 r^2', (l/r**4)**3*r**2)]:
    print(name, '->', sp.simplify(sp.integrate(integrand, (r, rf, rc))))
