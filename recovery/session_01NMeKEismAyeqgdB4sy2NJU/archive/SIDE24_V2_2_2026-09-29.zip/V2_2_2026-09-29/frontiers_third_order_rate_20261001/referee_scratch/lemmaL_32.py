"""Referee independent checks: Lemma L (exhaustive rational grid + identity with #218's min-form),
and the inclusion (3.2) at the matrix level with exact rationals (m = 1..4)."""
from fractions import Fraction as Fr
import random, itertools

def wp(c, y):
    v = c*c - y*y
    return v if v > 0 else Fr(0)

# ---- Lemma L on an exhaustive grid
grid = [Fr(i, 6) for i in range(-30, 31)]
cs = [Fr(i, 6) for i in range(0, 25)]
viol = eq = tot = 0
minform_mismatch = 0
for c in cs:
    for y in grid:
        for yp in grid:
            tot += 1
            lhs = abs(wp(c, y) - wp(c, yp))
            rhs = abs(y - yp)*(abs(y) + abs(yp))
            if lhs > rhs: viol += 1
            if lhs == rhs and lhs > 0: eq += 1
            # identity (c^2-y^2)_+ = c^2 - min(y^2, c^2): #218 Step C3's min inequality is the same statement
            if wp(c, y) != c*c - min(y*y, c*c): minform_mismatch += 1
print('Lemma L grid: instances', tot, 'violations', viol, 'equalities', eq, 'min-form identity mismatches', minform_mismatch)

# ---- sharpness: can the factor (|y|+|y'|) be replaced by t(|y|+|y'|), t<1? (equality when yy'>=0 inside window)
print('sharpness example c=1,y=1/2,y\'=1/3:', abs(wp(Fr(1),Fr(1,2))-wp(Fr(1),Fr(1,3))), '=', abs(Fr(1,2)-Fr(1,3))*(Fr(1,2)+Fr(1,3)))

# ---- (3.2) at the matrix level
def det(M):
    n = len(M)
    if n == 1: return M[0][0]
    return sum(((-1)**j)*M[0][j]*det([row[:j]+row[j+1:] for row in M[1:]]) for j in range(n))
def inv(M):
    n = len(M); A = [row[:] + [Fr(int(i == j)) for j in range(n)] for i, row in enumerate(M)]
    for i in range(n):
        p = next(k for k in range(i, n) if A[k][i] != 0); A[i], A[p] = A[p], A[i]
        piv = A[i][i]; A[i] = [x/piv for x in A[i]]
        for k in range(n):
            if k != i and A[k][i] != 0:
                f = A[k][i]; A[k] = [a - f*b for a, b in zip(A[k], A[i])]
    return [row[n:] for row in A]
def is_pd(M):   # Sylvester
    return all(det([row[:k] for row in M[:k]]) > 0 for k in range(1, len(M)+1))
rng = random.Random(7)
def rand_negdef(m):
    while True:
        Bm = [[Fr(rng.randint(-6, 6), rng.randint(1, 4)) for _ in range(m)] for _ in range(m)]
        S = [[sum(Bm[k][i]*Bm[k][j] for k in range(m)) for j in range(m)] for i in range(m)]  # B^T B >= 0
        eps = Fr(rng.randint(1, 30), rng.randint(1, 60))
        A = [[-(S[i][j] + (eps if i == j else 0)) for j in range(m)] for i in range(m)]
        if is_pd([[-x for x in row] for row in A]): return A
cnt = viol32 = violq = cnt_first = cnt_second = 0
for m in (1, 2, 3, 4):
    for _ in range(400 if m < 4 else 150):
        A = rand_negdef(m)
        g = [Fr(rng.randint(-8, 8), rng.randint(1, 4)) for _ in range(m)]
        g2 = sum(x*x for x in g)
        Ai = inv(A)
        q = sum(g[i]*Ai[i][j]*g[j] for i in range(m) for j in range(m))     # gamma^T A^{-1} gamma (<= 0)
        # check |q| <= |gamma|^2/lambda  <=>  lambda <= |gamma|^2/|q|  <=>  (-A) - (|g|^2/|q|) I is not PD
        if q != 0:
            t = g2/abs(q)
            if is_pd([[-A[i][j] - (t if i == j else 0) for j in range(m)] for i in range(m)]): violq += 1
        for _ in range(4):
            kap = Fr(rng.randint(1, 200), rng.randint(1, 20))
            phi = Fr(rng.choice((-1, 1)))*(Fr(1, 6) + Fr(rng.randint(0, 300), 900))   # 1/6 <= |phi| <= 1/2
            f4 = 3*q + 72*kap*phi
            cnt += 1
            first = abs(f4) >= 6*kap
            t = g2/(2*kap)
            # lambda <= t  <=>  (-A) - t I is NOT positive definite
            second = not is_pd([[-A[i][j] - (t if i == j else 0) for j in range(m)] for i in range(m)])
            cnt_first += first; cnt_second += (second and not first)
            if not (first or second): viol32 += 1
print('(3.2) matrix-level: instances', cnt, 'violations', viol32, '| only-first', cnt_first, 'only-second', cnt_second,
      '| |q|<=|g|^2/lam violations', violq)
# ---- B_4 window length: | |phi|-1/3 | <= delta, phi=(f4-3q)/(72 kappa) => f4 in two intervals of total length 2*2*72*kappa*delta
kap, eps = Fr(5, 3), Fr(1, 7)
delta = 2*eps/(3*kap)
print('B_4 total f4-length / eps* =', (2*(2*delta)*72*kap)/eps, '(packet/#220: 192)')
