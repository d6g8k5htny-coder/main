"""Referee exploration (floating point; not a proof): Proposition W+ mechanism in d = 2 for the Gaussian kernel
K(z) = exp(-|z|^2/2) on R^2 (the L -> infinity proxy of the [P] torus field).
Exact Gaussian regression on the pins f(M)=b, f(S)=b-k r^3, grad f(M)=grad f(S)=0 (mpmath, 90 digits), the six
Hessian entries mapped to the rescaled variables (a1, a2', c1, c2, e1, e2) whose conditional law is uniformly
nondegenerate (#211 Step 5), then Monte Carlo of
     G(r, k) := E_Q[W_r/r^2] / r^2 = E[|D_M D_S| 1{typed}],   D_i = det H_i / r^2.
W+ predicts G <= C (kappa + r)^2 (kappa + r log(2/r)); #198 (W.1) predicts G <= C (kappa^2 + r^2)."""
import mpmath as mp, numpy as np, sys
mp.mp.dps = 90
def He(n, x):
    if n == 0: return mp.mpf(1)
    h0, h1 = mp.mpf(1), x
    for j in range(1, n): h0, h1 = h1, x*h1 - j*h0
    return h1
def cov(p, al, q, be):
    z1, z2 = p[0]-q[0], p[1]-q[1]
    return (-1)**(al[0]+al[1]) * He(al[0]+be[0], z1)*He(al[1]+be[1], z2)*mp.e**(-(z1*z1+z2*z2)/2)
def law(r, b, k):
    r = mp.mpf(r); M = (-r/2, mp.mpf(0)); S = (r/2, mp.mpf(0))
    O = [(M, (0,0)), (M, (1,0)), (M, (0,1)), (S, (0,0)), (S, (1,0)), (S, (0,1))]
    H = [(M, (2,0)), (M, (1,1)), (M, (0,2)), (S, (2,0)), (S, (1,1)), (S, (0,2))]
    V = O + H
    Sig = mp.matrix(12, 12)
    for i, (p, a) in enumerate(V):
        for j, (q, bb) in enumerate(V): Sig[i, j] = cov(p, a, q, bb)
    SOO = Sig[0:6, 0:6]; SHO = Sig[6:12, 0:6]; SHH = Sig[6:12, 6:12]
    v = mp.matrix([b, 0, 0, b - k*r**3, 0, 0])
    Rg = SHO * mp.inverse(SOO)
    mu = Rg * v; C = SHH - Rg * SHO.T
    # map raw (xxM, xyM, yyM, xxS, xyS, yyS) -> (a1, a2', c1, c2, e1, e2); a2' has the affine shift -12k/r^2
    L = mp.matrix(6, 6)
    L[0,0] = L[0,3] = 1/(2*r**2); L[1,0] = -1/r**3; L[1,3] = 1/r**3
    L[2,1] = L[2,4] = 1/(2*r**2); L[3,1] = -1/r; L[3,4] = 1/r
    L[4,2] = L[4,5] = mp.mpf(1)/2; L[5,2] = -1/r; L[5,5] = 1/r
    m = L*mu; m[1] = m[1] - 12*k/r**2
    Ct = L*C*L.T
    return np.array([float(x) for x in m]), np.array([[float(Ct[i,j]) for j in range(6)] for i in range(6)])
def G(r, b, k, N, rng, batch=500000):
    m, Ct = law(r, b, k)
    ev = np.linalg.eigvalsh(Ct)
    Lc = np.linalg.cholesky(Ct)
    kap = k/r; tot = 0.0; tot2 = 0.0; typ = 0
    n = 0
    while n < N:
        z = rng.standard_normal((batch, 6)) @ Lc.T + m
        a1, a2, c1, c2, e1, e2 = z.T
        xxM = a1 - 6*kap - r*a2/2; xxS = a1 + 6*kap + r*a2/2
        yyM = e1 - r*e2/2; yyS = e1 + r*e2/2
        xyM = r*c1 - c2/2; xyS = r*c1 + c2/2
        DM = xxM*yyM - xyM**2; DS = xxS*yyS - xyS**2
        t = (xxM < 0) & (DM > 0) & (DS < 0)
        w = np.where(t, np.abs(DM*DS), 0.0)
        tot += w.sum(); tot2 += (w*w).sum(); typ += t.sum(); n += batch
    mean = tot/n; se = np.sqrt(max(tot2/n - mean**2, 0)/n)
    return mean, se, typ/n, ev.min(), ev.max()
if __name__ == '__main__':
    rng = np.random.default_rng(20261001)
    b = 1.0
    N = int(sys.argv[1]) if len(sys.argv) > 1 else 4000000
    print('d=2 Gaussian kernel, b = %.1f, N = %d per point' % (b, N))
    print('%-8s %-9s %-12s %-10s %-9s %-10s %-10s %-10s %-10s' % ('r', 'kappa', 'G', 'se', 'P(typed)', 'G/W+', 'G/W.1', 'eig_min', 'eig_max'))
    for kap_rule in ('k=0', 'kappa=r', 'kappa=0.1'):
        for r in (0.4, 0.2, 0.1, 0.05, 0.025, 0.0125):
            kap = 0.0 if kap_rule == 'k=0' else (r if kap_rule == 'kappa=r' else 0.1)
            k = kap*r
            g, se, pt, e0, e1 = G(r, b, k, N, rng)
            wplus = (kap + r)**2*(kap + r*np.log(2/r)); w1 = kap**2 + r**2
            print('%-8.4f %-9.4f %-12.4e %-10.2e %-9.5f %-10.4f %-10.4f %-10.3e %-10.3e' % (r, kap, g, se, pt, g/wplus, g/w1, e0, e1))
        print()
