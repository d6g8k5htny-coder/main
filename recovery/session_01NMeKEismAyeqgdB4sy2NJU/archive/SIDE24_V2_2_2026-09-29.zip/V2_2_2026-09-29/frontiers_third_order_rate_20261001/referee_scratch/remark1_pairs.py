"""Remark 1 test: the fold-end terms as functions of ef (rho_f = l^ef); others fixed at their best (>= 4/9).
T1 = rho_f^5/l (Lemma F layer, (K2) rejected fold mass, Lemma O/O' tail)  -- increasing in rho_f
T2 = l rho_f^-2 (finite-part truncation, linear cusp error r*kappa)         -- decreasing
T3 = l^2 rho_f^-11/2, T4 = l^3 rho_f^-9 (Lemma Q margin terms, elder only)  -- decreasing
Question: is 'the leading coefficients of BOTH matched pairs' needed to go below 3/7 in this ledger?"""
from fractions import Fraction as Fr
G = sorted({Fr(i, n) for n in range(2, 400) for i in range(1, n)})
efs = [g for g in G if Fr(1, 4) < g < Fr(1, 3)]
CAP = Fr(4, 9)                      # rho_c- and a-terms at their optimum
def best(fams):
    f = lambda e: min([CAP, 2*e] + [t(e) for t in fams])
    e = max(efs, key=f); return e, f(e)
T1 = lambda e: 5*e - 1; T2 = lambda e: 1 - 2*e; T3 = lambda e: 2 - Fr(11, 2)*e; T4 = lambda e: 3 - 9*e
print('candidate, all terms          :', best([T1, T2]))
print('elder, all terms              :', best([T1, T2, T3, T4]))
print('candidate, T1 pair removed    :', best([T2]))
print('candidate, T2 pair removed    :', best([T1]))
print('elder, T1 pair removed        :', best([T2, T3, T4]))
print('elder, T2 pair removed        :', best([T1, T3, T4]), ' <- margin terms T3,T4 keep 3/7')
print('elder, T3,T4 removed          :', best([T1, T2]))
