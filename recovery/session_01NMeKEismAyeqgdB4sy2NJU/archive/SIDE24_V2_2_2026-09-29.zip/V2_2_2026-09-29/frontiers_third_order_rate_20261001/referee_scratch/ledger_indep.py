"""Independent recomputation of the section-5 ledger (exponent of ell for each error term), written from #218 sec 4,
#220 sec 4 and the packet's Lemmas C+, CE+, W+ -- not from the packet's checker."""
from fractions import Fraction as Fr
def terms(ef, ec, ea):
    one = Fr(1)
    T = {}
    # fold region (#218 sec 4 / #220 sec 4): Lemma F layer int_0^{rho_f} (r + r^4/l) dr ; finite part l^{1/3}K0^{2/3}
    T['F rho_f^2'] = 2*ef
    T['F rho_f^5/l (layer)'] = 5*ef - 1
    T['F l rho_f^-2 (finite part)'] = 1 - 2*ef
    T['F^eld rho_f^5/l (K2 rejected fold)'] = 5*ef - 1
    # cusp region errors: int_{rho_f}^{rho_c} of r(1+kappa) [C+ / CE+], kappa^2 r^{3/2}, kappa^3 r^2 [CE+ only], kappa = l r^-4
    T['K r term -> rho_c^2'] = 2*ec
    T['K r kappa -> l rho_f^-2'] = 1 - 2*ef
    T['K^eld kappa^2 r^{3/2} -> l^2 rho_f^{-11/2}'] = 2 - Fr(11, 2)*ef
    T['K^eld kappa^3 r^2 -> l^3 rho_f^-9'] = 3 - 9*ef
    T['K lower end (Lemma O/O\') l^{1/4} s_f^5'] = Fr(1, 4) + 5*(ef - Fr(1, 4))
    T['K upper tail l^{1/4} s_c^-7'] = Fr(1, 4) - 7*(ec - Fr(1, 4))
    # J2..J5 (#218): J2 rho_c^3 (W.4), J3 l^2 rho_c^-7 + l rho_c^-2 (#207 (7.1)), J4 l^2 rho_c^-7, J5 l
    T['J2 rho_c^3'] = 3*ec; T['J3 l^2 rho_c^-7'] = 2 - 7*ec; T['J3 l rho_c^-2'] = 1 - 2*ec
    T['J4 l^2 rho_c^-7'] = 2 - 7*ec; T['J5 l'] = one
    # intermediate elder: [rho_c,a] by (W+.2): (kappa+r)^3 log -> l^3 rho_c^-11 log + a^4 log ; [a, r0*] by S': l^{5/3}a^-7 + l^{2/3}a^-2
    T['I l^3 rho_c^-11 log'] = 3 - 11*ec; T['I a^4 log'] = 4*ea
    T['I l^{5/3} a^-7'] = Fr(5, 3) - 7*ea; T['I l^{2/3} a^-2'] = Fr(2, 3) - 2*ea
    T['far (#187)'] = Fr(2, 3)
    return T
T = terms(Fr(2, 7), Fr(2, 9), Fr(1, 9))
mn = min(T.values())
print('least exponent:', mn)
for k, v in sorted(T.items(), key=lambda kv: kv[1]): print('  %-48s %s' % (k, v))
# hypotheses
ef, ec, ea = Fr(2, 7), Fr(2, 9), Fr(1, 9)
print('l^{1/3}<rho_f<l^{1/4}<rho_c<a:', Fr(1, 3) > ef > Fr(1, 4) > ec > ea > 0,
      '| k<=1 on [rho_f,inf): 1-3ef =', 1 - 3*ef, '| kappa<=1 on [rho_c,inf): 1-4ec =', 1 - 4*ec, '| kappa on [a,..]: 1-4ea =', 1 - 4*ea)
# Remark 1: at rho_f = l^{2/7}, kappa = l rho_f^-4 = rho_f^{-1/2}; check each per-unit-r error = rho_f^{1/2}
e = lambda ell_exp: ell_exp / ef   # convert ell-exponent to rho_f-exponent
kap = e(1) - 4
print('Remark 1: kappa = rho_f^%s ; r^4/l -> %s ; r kappa -> %s ; kappa^2 r^{3/2} -> %s ; kappa^3 r^2 -> %s' %
      (kap, 4 - e(1), 1 + kap, 2*kap + Fr(3, 2), 3*kap + 2))
# 3-D max-min over the split exponents within the ordering constraints
best = (None, None)
G = sorted({Fr(i, n) for n in range(2, 121) for i in range(1, n)})
cands_f = [g for g in G if Fr(1, 4) < g <= Fr(1, 3)]
cands_c = [g for g in G if Fr(1, 9) < g < Fr(1, 4)]
cands_a = [g for g in G if 0 < g < Fr(2, 9)]
bf = max(cands_f, key=lambda f: min(v for k, v in terms(f, Fr(2, 9), Fr(1, 9)).items()))
print('best rho_f exponent (rho_c, a fixed):', bf, '-> least', min(terms(bf, Fr(2, 9), Fr(1, 9)).values()))
# full max-min: rho_c and a only need min >= 3/7; record the set of (ec, ea) keeping least = 3/7 at ef=2/7
ok_c = [c for c in cands_c if min(v for k, v in terms(Fr(2, 7), c, Fr(1, 9)).items()) == Fr(3, 7)]
ok_a = [a for a in cands_a if min(v for k, v in terms(Fr(2, 7), Fr(2, 9), a).items()) == Fr(3, 7)]
print('rho_c exponents keeping 3/7: [%s, %s]' % (min(ok_c), max(ok_c)), '| a exponents keeping 3/7: [%s, %s]' % (min(ok_a), max(ok_a)))
# regressions
old = terms(Fr(3, 11), Fr(2, 9), Fr(2, 15))
old['K r kappa^2 -> l^2 rho_f^-6'] = 2 - 6*Fr(3, 11)
del old['K^eld kappa^2 r^{3/2} -> l^2 rho_f^{-11/2}'], old['K^eld kappa^3 r^2 -> l^3 rho_f^-9']
print('#218/#220 old ledger least (fold/cusp):', min(v for k, v in old.items() if not k.startswith('I')))
print('old rk^2 at new split: l^', 2 - 6*Fr(2, 7))
