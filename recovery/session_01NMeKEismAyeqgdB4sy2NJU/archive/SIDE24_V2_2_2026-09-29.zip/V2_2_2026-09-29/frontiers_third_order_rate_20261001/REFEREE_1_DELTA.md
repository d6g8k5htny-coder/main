# Delta check of the fixes to REFEREE_1: CL-THIRD-ORDER-RATE-20261001-v1

Same referee as `REFEREE_1.md`, 1 October 2026. This check covers the fixes only, not a fresh review. I compared:
- `PROOF_fixed.md` against `PROOF_draft.md`;
- `r37_check_fixed.py` against `r37_check_draft.py`;
- the new `README_fixed.md`.

The worktree files `PROOF.md`, `README.md`, `r37_check.py` and `RESULTS.json` in `wt-r37/frontiers/third_order_rate_20261001` are
byte-identical to the `_fixed` files, and to a fresh checker run.

## Verdict: **FURTHER FIXES: one required, one line, in the README**

- **PROOF and checker:** accepted. All two minor findings and twelve nits of `REFEREE_1.md` are correctly applied, and
  the diff introduces no new error.
- **README:** one claim overstates the result by a factor `log(2/r)` (R-1 below).

With R-1 fixed, no further referee pass is needed. Everything else below is optional.

## 1. Status of each finding

Line numbers are those of `PROOF_fixed.md`.

| Finding | Where it is fixed | Status |
|---|---|---|
| MINOR-1 (Remark 1; "not the bottleneck") | Remark 1, lines 365–380; end of §3, lines 226–229; R1 `remark1_maxmin`; §8 | **Fixed.** The text now matches the max–min: without `ρ_f⁵/ℓ`, both densities reach `4/9`; without only the linear pair, the candidate reaches `4/9` and the elder stays at `3/7`. R1 output is `{4/9, 4/9, 4/9, 3/7}`, identical to the referee's `remark1_pairs.py`. |
| MINOR-2 (parity, §2 against Remark 2) | lines 164–166; Remark 2, lines 386–388 | **Fixed.** Both places now say `O((1 + κ)k²)`, with `O(k²)` expected but not proved. Optional wording in O-1. |
| N1 | line 127 | Fixed. |
| N2 | lines 18–19 | Fixed. |
| N3 | lines 13–14, 129–130; line 160 ("which is (L.1)") | Fixed. "Analogue" no longer appears. |
| N4 | lines 143–146 | Fixed. Optional wording in O-3. |
| N5 | lines 227–229 | Fixed. Optional wording in O-3. |
| N6 | lines 391–397; §7 #211 row; Merged inputs | Fixed. See the note after this table. |
| N7 | lines 72–74 | Fixed. |
| N8 | lines 242–243, 254, 273 | Fixed. The only `C₁` left in §4 is the disambiguating "not Lemma Q's `C₁`". |
| N9 | Dependencies, Merged inputs, §7 rows for #191, #198, #220 | Fixed. |
| N10 | R3 matrix instances; §8 | Fixed. See the note after this table. |
| N11 | `RESULTS.json`, `M1`–`M8.json`; exploration docstring | Fixed, apart from one archived output (O-4). |
| N12 | line 273 (`(1 + j)` dropped); lines 292–294 (log remark) | Fixed. The quoted numbers match the referee's run: `G ≈ 0.030r³` for `r` from 0.4 to 0.0125. The cited scripts need archiving (O-4). |

**Note on N6.**
- Remark 3's quote is a verbatim prefix of #211, ending "near `0`, …". The original comma is kept, and the original
  continues "consistent with …".
- The mechanism is now attributed to #198 and Step W2.
- #211 is pinned. `git rev-parse 8e89fe8:frontiers/equal_height_mass_value_20261001/NOTE.md` returns `ed0d3fa8`.

**Note on N10.** R3 now has 900 matrix instances, `A = −O diag(μ)Oᵀ` with `O` a Cayley transform, for `m = 1, 2, 3`.
- The code is correct. It checks `q = γᵀA^{−1}γ` exactly, checks `A·A^{−1} = I` (which certifies that `O` is
  orthogonal), and uses `λ = min μ` exactly.
- Replaying the random stream, the 66 instances that need the second alternative split as 27 scalar and 39 matrix
  (`m = 1, 2, 3`: 13, 16, 10). So the matrix part exercises both alternatives.
- The committed file is named `r37_check.py`, as §8 says.

## 2. Checker and pins (rerun)

**Base run.**
- `r37_check_fixed.py` exits 0.
- Its output is byte-identical under `-O`, and identical to `RESULTS.json`, `RESULTS_O.json` and `R_3.10`–`R_3.14.json`.
- I reran it myself on CPython 3.10, 3.11, 3.12, 3.13 and 3.14, with and without `-O`: identical every time.

**Mutants.** Each exits 1, fails only its own control, and matches the shipped `M*.json`:

| Mutant | Fails |
|---|---|
| M1, M2, M6, M8 | R1 |
| M3 | R2 |
| M4 | R3 |
| M5 | R4 |
| M7 | R6 |

An unknown, empty or lower-case label exits 2.

**Pins, now checkable in the worktree's git history.** Every declared pin resolves correctly:

| Commit | File | Blob |
|---|---|---|
| `c2f1270` ("Merge #187 …") | `far_elder_rate_20260930/PROOF.md` | `07260114` |
| `8e89fe8` | #211 `NOTE.md` | `ed0d3fa8` |
| `782211f` | #207 | `f6df5a73` |
| `0cf048d` | #218 | `70ca57ef` |
| `e481d23` | #220 | `736a35de` |

This also settles two items `REFEREE_1` could not check: #187's merge commit and #211's head.

## 3. README check

The README is accurate except for one claim.
- The results and dependencies are correct, and the pins are as verified in §2.
- The cross-version reproducibility claim is confirmed.
- The mutant claim is confirmed.
- The review record is right: the verdict, two minor findings and twelve nits, and the referee's checks (93,025;
  5,400; 20,000; the `d = 2` Monte Carlo).

The README's claim that "the workflow checks every pin" is about CI, which was outside this check. The pins themselves
resolve correctly.

**R-1 (required), README lines 19–20.** The README says "…`O(r³log(2/r))` … This sharpens #198 (W.4) and proves the
order that #211 suggests heuristically." That overstates the result by a log factor. #211's heuristic order is `O(r³)`,
and the PROOF itself (Remark 3, lines 393–394) says (W⁺.2) "proves this order up to the factor `log(2/r)`". Fix: "…and
proves the order that #211 suggests heuristically, up to a factor `log(2/r)`."

## 4. Optional items (none blocks)

**O-1. Remark 2, lines 387–388 (my own wording, copied from REFEREE_1).** "A kink at moderate `f₄` needs `|f₄| ≳ κ`
or …" contradicts itself. Suggested: "since crossing the kink needs `|f₄ − 3γᵀA^{−1}γ| ≈ 72κ`, hence `|f₄| ≳ κ` or
`λ ≲ |γ|²/κ`, as in (3.2)". Also reflow line 388, which is 154 characters against at most 143 for any prose line of the
draft.

**O-2. Checker docstring.** The R1 paragraph of the docstring (lines 6–14) does not mention the new Remark 1 max–min.
§8 and the README do. Add one sentence.

**O-3. Wording.**
- Line 146: "both are absorbed by `k² ≤ k = κr`" also needs `η² ≤ Cr²T^N ≤ Cr·T^N` for the `η` parts.
- Line 229: "lets a typed pair reach" would be more exact as "lets a pair inside the typed window `|Y_r| < 6κ|Δ|`
  reach".
- README line 26 could echo PROOF lines 13–14: the inequality of Lemma L is #218 Step C3's, and only its use in Steps
  C2 and E3 is new.

**O-4. Archive housekeeping.**
- `exploration/parity_toy_broken.out` still has the old header "(parity broken: expect growth ~kappa)". The fixed
  script prints "(parity broken: D ~ k, bounded uniformly in kappa by Lemma L)". I reran it, and the numbers are
  identical, so regenerate the `.out`.
- PROOF lines 292–294 now cite the referee's `d = 2` exploration. Archive `referee_scratch/toy_Wplus_d2.py` and
  `toy_Wplus_d2.out` next to `REFEREE_1.md`. That run uses `b = 1` and the Gaussian kernel on `R²`.
- The stale `base.json` and `baseO.json` from the draft checker are still in the scratch folder. They are not in the
  worktree; delete them to avoid confusion.

## 5. Files

The scratch outputs of this check are in `referee_scratch/delta/`:
- the fresh run, its `-O` variant, and runs on 3.10 and 3.12–3.14;
- the mutant outputs;
- the rerun of the broken-parity exploration.
