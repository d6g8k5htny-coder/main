# Referee report: CL-THIRD-ORDER-RATE-20261001-v1 (`PROOF_draft.md`, checker `r37_check_draft.py`)

Clean-context, same-family referee (Anthropic Claude), 1 October 2026. I read the packet and all ten sources in
`referee_src/` in full. Source identity: the git blob hashes of the provided files match every pin the packet declares
(`f6df5a73` #207, `70ca57ef` #218, `736a35de` #220, `441152df` #191, `abfb98ae` #198, `247b3ecf` [R], `07260114` #187,
`28748b08` [C7-K], `5b6328ea` [Z]). #211 is `ed0d3fa8`; the packet does not pin it.

## Verdict: **ACCEPT WITH MINOR FIXES**

I found no major issue. The three new ingredients are correct:
- Lemma L, with Lemma C⁺ as a one-step change of #218.
- The refined bound (3.1)–(3.2) on `𝔅_4′`, with Lemma CE⁺.
- Proposition W⁺.

Every bound reused from #218 §4 and #220 §4 is valid at the new splits `ρ_f = ℓ^{2/7}`, `ρ_c = ℓ^{2/9}`, `a = ℓ^{1/9}`.
I recomputed the ledger independently. Its least exponent is `3/7`, attained exactly by the terms the packet marks, and
no term is missing. Proposition W⁺ is needed: with #198 (W.1) the intermediate separations stop at `2/5 < 3/7`.

There are two minor findings. Both concern the note's own explanatory claims (Remark 1; the parity statement of §2
against Remark 2), not the proofs. There are also twelve nits. Details follow, by the six points of the review mandate.

---

## 1. What was verified, point by point

### 1.1 Lemma L and Lemma C⁺ (§§1–2)

**Lemma L.** It is correct and sharp. It is literally the inequality #218 already uses in Step C3, because
`(c² − y²)₊ = c² − min(y², c²)` (nit N3).

**Step C1 / (C.2): no hidden `κ²`.**
- *Case 1, both indicators.* The bound is `24ηκ|Δ| + η²`, with `η = Cr(1 + k)T^{N₁}`. This is `≤ C(κr + r²)T^N`.
- *Case 1, exactly one indicator.* The bound is `2η(12κ|Δ| + 3η) ≤ C(κr + r²)T^N`.
- *Case 3.* The weight is `w_κ ≤ 36κ²r²T^{2m} = 36k²T^{2m}`, and the typed product is `(12κ|Δ| + 2η)² ≤ C(k² + r²)T^N`.
  Both are absorbed because `k² ≤ k = κr`, using `k ≤ 1`.

So #218's (C.2) is already `Cr(1 + κ)T^N`, as #218 states.

**Step C2⁺.**
- The bound `|Y − Y₀| ≤ 3k|tr(adj(A₀)B)| + Cr²T^N` is #218's.
- `|Y| + |Y₀| ≤ CT^N` is legitimate. `T` dominates `1 + k + ‖F_r‖_{C⁹} + ‖F₀‖_{C⁹} + r^{−2}‖F_r − F₀‖_{C⁴}`, so the bound
  holds for `f₄`, `f₄^{(0)}`, `γ`, `γ^{(0)}`, `B`, `A₀` and `|Δ| ≤ T^m`.
- Lemma L then gives `C(k + r²)T^{N′} = Cr(κ + r)T^{N′}`.

**Step C3.**
- The density term is `Cr²P²·(1 + κ)²P^N`. Since `(r + k)² ≤ 2(r + k)` when `r + k ≤ 3/2`, it is `≤ Cr(1 + κ)`.
- In the parity target shift, the integrand moves by `O(kP^N)`, with no `κ`.
- The density factor `1 + O(k²)` multiplies `E₀[min(Y², 36κ²Δ²)] ≤ E₀[Y²]`, again with no `κ`.

No other `κ²` arises in Steps C1–C3.

### 1.2 Lemma CE⁺ (§3)

**(Q3) on `𝔅_4′`.** By #220 Step E2, (Q3) holds if `κ ≥ 1280C₁𝒩r` and `λ² ≥ 1280C₁𝒩r|γ|²/κ`. Both are implied off
`𝔅_λ ∪ 𝔅_κ`, because `C₂ ≥ 1280C₁` and `λ₂` contains `C₂|γ|(𝒩r/κ)^{1/2}`. So `ε* ≤ κ/4` on `𝔅_4′`, and
`||φ_r| − 1/3| ≤ 1/6`.

**(3.2).** The inclusion is correct; I checked it at the matrix level (§3, check 4). The window `I₄` has total length
`192ε*` exactly.

**`𝒩_r`-layers.** The handling is correct for two reasons:
- the right side of (3.2) does not involve `𝒩_r`;
- `I₄` is monotone in `ε*`, so replacing `𝒩_r` by `2^{j+1}` on each layer only enlarges it.

**Order of conditioning.** It is legitimate:
- `σ(J‴) ⊂ σ(J″) ⊂ σ(J′)`;
- `{λ ≤ |γ|²/(2κ)}` is `J″`-measurable;
- `ε = |γ|²/(2κ)` is `J‴`-measurable. #220 itself applies (2.2) this way, with `λ₂(|γ|)`.

**(2.1) with the weight `(P + |J′|)^p`.** The weight contains `f₄`, and (2.1) still applies, because
`(P + |J″| + |f₄|)^p ≤ (P + |J″|)^p(1 + |f₄|)^p`.

**`𝔅_λ` recomputed.**
- The bound is `κ²min(1, κ)·E[λ₂³…] → κ²min(1, κ)(r³ + r^{3/2} + (r/κ)^{3/2})`.
- This is `≤ C(r + κ²r^{3/2})`, because `κ²r³ = k²r ≤ r` and `κ^{1/2}r^{3/2} = k^{1/2}r ≤ r`.

**`𝔅_κ` and `𝔅_5`.** The bounds `Cr³` and `Cκ³r²` are confirmed.

**Step E3⁺.** It is correct.

**Steps E4–E6.** They cost `k²`, `(r + k)²` and `k²`; each is `≤ Cr(1 + κ)`.

### 1.3 Proposition W⁺ (§4)

**Every fact holds on all of `(0, r₀*]`.**
- (F1) is stated by #220 for every `r ≤ r₀*`.
- (F3)/(2.1) and (F5)/(2.2) rest on #218 Step F1's uniform invertibility on `(0, r₀*]`.
- (F4) is #218 (1.2), valid for `r ≤ r₀*`. It holds at `k = 0` too, since `T` and (R2)–(R5) do not depend on the target.

**(F1) at `k = 0`.** I accept it: #191 Steps 1–3 are pathwise Taylor identities with no division by `k`, and #198
Lemma W states the `k = 0` member explicitly. The theorems never use `k = 0`, since `k > 0` on `[ρ_c, a]`; only (W⁺.3)
and Remark 3 do.

**The window and the four terms.**
- The `f₄`-window has length `144κ + 24η′/|Δ|`, exactly.
- The splitting inequality holds.
- The four terms of Step W3 are as stated.
- (4.2) is exactly the count `Cs + 2Cs⌈log₂(1/s)⌉ + Cs`.
- The chain to (W⁺.1) is correct.

**(W⁺.2) and (W⁺.3).**
- The identity `r^{d−1}Ψ₀ = r^{−2}A_r(b, 0, u)` is #191 §2 and #198's proof of (W.4).
- `∫₀^ρ r³log(2/r) dr = (ρ⁴/4)(log(2/ρ) + 1/4)` (sympy).

### 1.4 Assembly (§5): the reused bounds at the new splits

| Reused bound | Condition needed | Holds at the new splits because |
|---|---|---|
| Lemma F (#218) | `r ≤ min(r₀*, 1/2)` only | `ρ_f` is small for small `ℓ` |
| Finite part | `|A₂(k) − A₂(0)| ≤ Ck` from (F.2), valid for any `K₀` | here `K₀ = ℓ^{1/7} ≤ 1` |
| (K2) fold mass | `ρ_f ≤ ℓ^{1/4}` and `ρ_f ≤ r₂` | both hold |
| Lemma O/O′ | `s_f < 1` | `s_f = ℓ^{1/28}` |
| `J₂` by (W.4) | `ρ_c ≤ r₀*` | holds |
| `J₃` by #207 (7.1) | `k ≤ 1` on `[ρ_c, r₀]` | `k ≤ ℓ^{1/3}` there |
| `J₄`, `J₅` | none (split-free) | — |
| Lemmas C⁺/CE⁺ | `k ≤ 1` and `ρ_c ≤ r₂` | `k ≤ ℓ^{1/7}` |
| W⁺ on `[ρ_c, a]` | `κ ≤ 1`, `a < r₀*` | `κ ≤ ℓ^{1/9}` |
| S′ on `[a, r₀*]` | `κ ≤ 1` | `κ ≤ ℓ^{5/9}` |

**The ledger.** Recomputed from scratch, it gives a least exponent of `3/7`, attained exactly by four kinds of term:
- `ρ_f⁵/ℓ`, from three sources: Lemma F's layer, the (K2) fold mass, and Lemma O/O′'s tail;
- `ℓρ_f^{−2}`, from two sources: the finite part and the linear cusp error;
- `ℓ²ρ_f^{−11/2}` (elder only);
- `ℓ³ρ_f^{−9}` (elder only).

Every other term is `≥ 4/9`. The intermediate elder mass is `O(ℓ^{4/9}log(1/ℓ))`, and nothing is omitted.

The result is not sensitive to `ρ_c` or `a`: any `ρ_c`-exponent in `[3/14, 11/49]`, and any `a`-exponent in
`[3/28, 5/42]`, keeps `3/7`.

### 1.5 Remarks

- **Remark 1:** see MINOR-1.
- **Remark 2:** see MINOR-2. Its numbers match the shipped output: the largest `|D|/k²` for `k ≤ 1/40` is `4.329`.
- **Remark 3:** the quote is a verbatim prefix of #211 lines 160–162, in its §2. The attribution and pinning points
  are in N6.
- **Remark 4:**
  - from the listed rounded values, `c₁/c = −5.07107`; from #207's values, `−5.071062`;
  - `c₂/c = 3.859496` from #218's values (`3.859498` from the rounded ones);
  - the relative exponent is `16/21`, and #220's was `23/33`.
- **Remark 5:** every implication checks.

### 1.6 Checker

- `python3 -B -S r37_check_draft.py` exits 0, and its output is byte-identical under `-O`.
- Each mutant exits 1 and fails only its own control:

  | Mutant | Fails |
  |---|---|
  | M1, M2, M6, M8 | R1 |
  | M3 | R2 |
  | M4 | R3 |
  | M5 | R4 |
  | M7 | R6 |

- An unknown or empty label exits 2.

The controls test what §8 says they test, with two caveats, both in N10:
- R3 tests (3.2) only after assuming the matrix inequality;
- R1 can only certify the terms it lists. The referee's independent ledger closes that gap.

---

## 2. Findings

### MINOR-1. Remark 1 and line 219 misstate which terms block an improvement of `3/7`

- **Where:** lines 218–219 ("§5 shows they are not the bottleneck"); Remark 1, lines 354–358 ("Going below `3/7`
  needs the leading coefficients of both pairs"; "The nonlinear elder terms … are not the obstruction").
- **What is wrong.** At the fold end the four `3/7` terms form two groups:
  - one family increasing in `ρ_f`: `ρ_f⁵/ℓ` (Lemma F's `r³/k` layer, the (K2) fold mass, Lemma O/O′'s `κ^{−1}` tail);
  - three families decreasing in `ρ_f`: `ℓρ_f^{−2}`, `ℓ²ρ_f^{−11/2}` and `ℓ³ρ_f^{−9}`.

  An exact max–min over `ρ_f = ℓ^e`, with the other terms at their optimum `4/9`, gives
  (`referee_scratch/remark1_pairs.py`):

  | Removed from the ledger | Candidate | Elder |
  |---|---|---|
  | the `ρ_f⁵/ℓ` pair | `4/9` | `4/9` |
  | the linear `ℓρ_f^{−2}` pair | `4/9` | still `3/7` |
  | the nonlinear terms | `3/7` | `3/7` |

  When only the linear pair is removed, the elder density stays at `3/7` because `κ²r^{3/2}` and `κ³r²` then balance
  `ρ_f⁵/ℓ` at the same `ρ_f = ℓ^{2/7}`.

  So "needs … both pairs" is not what the ledger shows: one pair suffices, the `ρ_f⁵/ℓ` pair for both densities. And
  "not the obstruction / not the bottleneck" is misleading: the Lemma Q terms attain `3/7` exactly, and they are the
  elder obstruction once the linear pair is resolved. Only "improving them alone would not change the exponent" is
  true.
- **Fix.** Rewrite lines 218–219 and the last two bullets of Remark 1, for example:

  > In this ledger the exponent is the balance of the increasing family `ρ_f⁵/ℓ` against three decreasing ones.
  > Resolving the first matched pair (fold `r³/k` layer ↔ Lemma O/O′ `κ^{−1}` tail, and for the elder density the
  > (K2) fold mass) would move the split for both densities, subject to that expansion's own next-order remainder.
  > Resolving only the linear pair would help the candidate density but not the elder density, whose Lemma Q margin
  > terms `κ²r^{3/2}` and `κ³r²` then set `3/7`.

  The proofs are not affected.

### MINOR-2. The parity statement of §2 contradicts Remark 2 for the candidate kernel

- **Where:** lines 156–158 ("Parity would sharpen the contribution … from `O(k)` to `O(k²)` (Remark 2)") against
  Remark 2, lines 364–365 ("for the candidate kernel the kink costs `O(κk²)`").
- **What is wrong.** Line 157 attributes to Remark 2 a uniform `O(k²)`. Remark 2 claims only `O(κk²)` for the candidate
  kernel, which is not `O(k²)` uniformly, since `κ ≍ ρ_f^{−1/2} → ∞` at the fold end.

  The exploration is consistent with a uniform `O(k²)`: in `parity_toy.out` the candidate `|D|/k²` lies in
  `[1.72, 2.71]` for `k ≤ 1/40` across `κ ∈ {1/2, …, 32}`. That is plausible, because a kink at moderate `f₄` needs
  `|Δ| ≲ |γ|²/κ`, the mechanism of (3.2). Neither statement is proved.
- **Fix.** Make both places say the same thing, for example:

  > `O((1 + κ)k²)` by the bounded density of `f₄`; `O(k²)` is expected, since a kink at moderate `f₄` needs
  > `|f₄| ≳ κ` or `λ ≲ |γ|²/κ` as in (3.2), but it is not proved.

  Nothing uses it, so the ledger is unaffected.

### NITs

**N1 (line 124).** "off it both sides are `≥ 0 = 0`" is garbled. Suggested: "off `{A < 0}` both weights vanish, so the
left side is `0`."

**N2 (lines 18–19).** "Each alternative costs a factor `κ`" should say *saves*, for example: "each alternative saves a
factor `κ`, so the charge drops from `O(rκ²)` to `O(rκ)`."

**N3 (lines 12–15 and 152).** Lemma L is not an "analogue" of #218 Step C3's inequality; it is the same inequality, by
`(c² − y²)₊ = c² − min(y², c²)`. I confirmed the identity on 93,025 grid points. Say so in "What is new": the new step is
using the local constant in Step C2 and in Step E3, not the inequality itself.

**N4 (line 138).** Add one sentence on why Step C1 is already linear in `κ`. Its only `κ²` is Case 3's
`w_κ ≤ 36κ²r²T^{2m} = 36k²T^{2m}`, together with `(12κ|Δ| + 2η)² ≤ C(k² + r²)T^N`, and both are absorbed by `k² ≤ k`.
That is exactly where a reader will look for a hidden `κ²`.

**N5 (line 219).** The phrase "Lemma Q's margins (`𝔅_λ` and `𝔅_5`)" is inaccurate for `𝔅_5`.
- `𝔅_5 = {|φ_r| > 1}` is the domain half of (Q4), not a margin.
- Its `κ³r²` comes from the shift `τ = 3k tr(adj(A)B)` between `Y_r` and `Y′`.

Reword this together with MINOR-1.

**N6 (lines 368–373 and 403).** Three points on Remark 3:
- The parenthetical credits #211 with a mechanism it does not state.
  - #211 names the agreement of the two endpoint axial curvatures.
  - "The typed window forces `|Y| = O(r)`" is #198's remark after Lemma W.
  - "Its probability is `O(r/|Δ|)`" is this note's own step.
- The quote stops mid-sentence. The original continues ", consistent with the linear rise in `d = 3`; …". Mark the cut
  with "…".
- Pin #211's blob (`ed0d3fa8`) in §7, since a verbatim quote needs a fixed version.

**N7 (lines 70–71).** The `θ`-equivalence is now vacuous. #187 is merged and used in (E3⁺.1), so both sides hold for
every `θ ≤ 3/7`. Either state that its content is that (E3⁺.0) isolates the far part without #187, or drop it.

**N8 (lines 192 and 232).** `C₁` has two meanings:
- in §3 it is Lemma Q's constant, in `ε* = 80C₁𝒩_r r(1 + Γ)²`;
- in §4 it is (F1)'s remainder constant, in `η = C₁r𝒩_r^{N₁}`.

Rename one of them.

**N9 (lines 32–35 and 396).** Complete the consumption list, which is what rebinding uses:
- #191's role should name Lemma E Steps 1–3, used directly at lines 225–226 for (F1) at `k = 0`;
- #198's role should name Lemma W's `k = 0` clause;
- #220's role should name Lemma H, through Lemma S′'s proof.

**N10 (§8, lines 406 and 417).** Two points on the checker description:
- §8 calls the checker `r37_check.py`, but the shipped file is `r37_check_draft.py`.
- R3 checks (3.2) only after assuming `|γᵀA^{−1}γ| ≤ |γ|²/λ`, on scalar instances. Add matrix instances.
  `referee_scratch/lemmaL_32.py` runs 5,400 exact instances with `m = 1…4` and finds no violation.

**N11 (artifacts beside the draft).**
- `base.json` and `M1.json`–`M8.json` are stale. The current checker adds `"splitting_instances": 3000` to R4 (diff at
  line 59), so regenerate them before any `RESULTS.json` is committed.
- `exploration/parity_toy_broken.py` says "expect growth ~kappa", but its own output shows `D/k` uniform in `κ`, as
  Remark 2 correctly states. Fix that script's docstring and header.

**N12 (line 262, optional).** Two small points on Step W3:
- The factor `(1 + j)` is unnecessary, since `log₂(1/η_j)` decreases in `j`. It is harmless.
- The `log(2/r)` of (4.2) is probably an artifact of integrating `f₄` alone. In the referee's `d = 2` exploration (§3,
  check 10), `E_Q[W_r/r²]/r²` at `k = 0` is `≈ 0.030r³` with no visible log, and `P(typed) ≈ 0.12r`. This changes
  nothing in the ledger, since `4/9 > 3/7`. A one-line remark would do.

---

## 3. Independent checks and their outcomes

Scripts and outputs are in `referee_scratch/`.

1. **Source identity.**
   - What: `git hash-object` on all ten `referee_src` files.
   - Outcome: every blob the packet declares matches; #211 is `ed0d3fa8`, not pinned by the packet.
2. **Checker** (`base_run.json`, `base_runO.json`, `M1.json`–`M8.json`).
   - What: the base run, `-O`, all mutants, and unknown or empty labels.
   - Outcome: as in §1.6. The shipped JSONs are stale (N11).
3. **Lemma L** (`lemmaL_32.py`).
   - What: an exhaustive exact grid, with `c` from 0 to 4 and `y, y′` from −5 to 5, all in steps of 1/6.
   - Outcome: 93,025 instances, 0 violations, 10,400 equality cases. The identity `(c² − y²)₊ = c² − min(y², c²)` is
     exact on all of them.
4. **(3.2) at the matrix level** (`lemmaL_32.py`).
   - What: 5,400 exact instances with `m = 1…4`, random negative-definite rational `A` and random `γ`, and `f₄` chosen
     so that `|φ| ∈ [1/6, 1/2]`.
   - Outcome: 0 violations, and both alternatives occur (5,302 on the first, 98 only on the second).
   - Also: `|γᵀA^{−1}γ| ≤ |γ|²/λ_min(−A)`, tested by a Sylvester PD test, has 0 violations, and the length of `𝔅_4` is
     `192ε*` exactly.
5. **Independent ledger** (`ledger_indep.py`).
   - What: every term of #218 §4 and #220 §4 with the new lemmas, in exact arithmetic.
   - Outcome: the least exponent is `3/7`, attained by exactly seven entries of the four claimed kinds, and all others
     are `≥ 4/9`.
   - Also confirmed:
     - the split hypotheses;
     - the Remark 1 scalings: `κ = ρ_f^{−1/2}`, and all four per-unit errors equal `ρ_f^{1/2}`;
     - the optimal `ρ_f` exponent is `2/7`;
     - the old ledger's least exponent is `4/11`, and the old `rκ²` term at the new split gives `ℓ^{2/7}`;
     - the tolerance ranges for `ρ_c` and `a` quoted in §1.4.
6. **Remark 1 pair test** (`remark1_pairs.py`).
   - Outcome: the results stated in MINOR-1.
7. **Bookkeeping** (`bookkeeping.py`).
   - What: 20,000 exact instances with `r = s²` and `κ = t²`, including tiny `κ` and `κr → 1`, of every inequality used
     in C⁺, CE⁺ and W⁺: Case 3, Step C3, `𝔅_λ`, `𝔅_κ`, E4–E6, CE⁺ ⇒ CE, the W3 chain, and W⁺ ⇒ W.1.
   - Outcome: no failures.
8. **Remark 4 and integrals** (`remark4_and_integrals.py`, using sympy).
   - Outcome: the ratios and exponents of §1.5, and the three cusp-error integrals of §5, all confirmed.
9. **(4.2) numerically** (`check_42.out`).
   - What: the ratio `E[min(1, s/|Δ|)] / (s(4 + 2log₂(1/s)))`.
   - Outcome: the ratio is stable — about 0.26 for `m = 1`, `μ = 0`; 0.10–0.11 for `m = 1`, `μ = 1.5`; 0.17 for
     `m = 2`. For `m = 2`, `P(|det| < ε)/ε` is 0.50–0.55, confirming Lemma D's linear small-ball bound.
10. **Toy Gaussian field for W⁺** (`toy_Wplus_d2.py` and `.out`).
    - What:
      - `d = 2`, Gaussian kernel on `R²`;
      - the exact two-site regression, in mpmath at 90 digits;
      - the rescaled Hessian variables of #211 Step 5, whose conditional covariance has eigenvalues in `[0.032, 2.0]`
        for every `r`;
      - 2·10⁶ samples per point, at `b = 1`.

      The quantity measured is `G = E_Q[W_r/r²]/r²`.
    - Outcomes:

      | Regime | Behaviour of `G` | Compared with W⁺ and (W.1) |
      |---|---|---|
      | `k = 0` | `G/r³ = 0.028–0.031` for `r` from 0.4 to 0.0125 | (W.1)'s `r²` is not sharp, as W⁺ claims |
      | `κ = r` | `G/r³ → ≈ 645` | `G/W⁺ ∈ [20, 35]` |
      | `κ = 0.1` | `G → 0.556 ≈ 556κ³`, the cusp limit | `G/W⁺` rises to that bounded limit |

      No data point contradicts (W⁺.1).
11. **#211 quote.**
    - Outcome: a verbatim (whitespace-normalized) prefix of #211 lines 160–162, in its §2.
12. **Remark 2 exploration** (`exploration/`).
    - Outcome: the claims match the shipped outputs. Two points to note:
      - the broken-parity run has `D/k ∈ [−0.37, −0.14]`, uniform in `κ`;
      - that run's label is wrong (N11).

**Not checked.** These are outside the source set:
- #216 and #223 (for example, the claim that #223 gives `c₂` in closed form);
- #187's merge commit `c2f1270`;
- [P], [E1], [E2], [REC] and [182], which this packet consumes only through the provided sources.

## 4. Summary for the author

No change is needed to any theorem, lemma statement, proof or exponent. Before submission:
- apply MINOR-1, rewording Remark 1 and line 219;
- apply MINOR-2, reconciling line 157 with Remark 2;
- apply the nits, of which the substantive ones are N6 and N9 (attribution, pinning, consumption list) and N11 (stale
  outputs);
- regenerate the outputs.
