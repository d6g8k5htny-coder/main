"""Exploration (not a control): the parity mechanism of Lemmas C+ / CE+ in a d = 2 toy model (m = 1).
Even jets (A, f4), odd jets (gamma, B) independent of them; odd mean 12k*w.  Y' = (f4/12)A - gamma^2/4, h = 3kB.
D_cand(k) = E_k[w(A, Y'+h)] - E_k[w(A, Y')],   D_eld(k) = E_k[(w(A, Y'+h) - w(A, Y')) 1{|Y'| < 2 kappa |A|}],
w(A, Y) = (36 kappa^2 A^2 - Y^2)_+ 1{A < 0}.  Claim: |D| <= C(1 + kappa) k^2 (cand), C k^2 (eld); naive Lipschitz: kappa*k.
f4 is integrated in closed form; (gamma, B) by Gauss-Hermite; A by Gauss-Legendre on [-10, 0]."""
import numpy as np
from scipy.special import erf
SQ2 = np.sqrt(2.0)
Phi = lambda z: 0.5 * (1 + erf(z / SQ2))
phi = lambda z: np.exp(-0.5 * z * z) / np.sqrt(2 * np.pi)

def moments(a, b, mu, s):
    """int_a^b u^j N(u; mu, s^2) du for j = 0, 1, 2 (a <= b elementwise)."""
    za, zb = (a - mu) / s, (b - mu) / s
    m0 = Phi(zb) - Phi(za)
    i1 = phi(za) - phi(zb)                     # int z phi
    i2 = m0 + za * phi(za) - zb * phi(zb)      # int z^2 phi
    return m0, mu * m0 + s * i1, mu * mu * m0 + 2 * mu * s * i1 + s * s * i2

def G(mu, s, c):                               # E (c^2 - U^2)_+, U ~ N(mu, s^2)
    m0, m1, m2 = moments(-c, c, mu, s)
    return c * c * m0 - m2

def H_eld(mu, s, c, h):                        # E [((c^2-(U+h)^2)_+ - (c^2-U^2)) 1{|U| < c/3}]
    lo, hi = -c / 3, c / 3
    a1, b1 = np.maximum(lo, -c - h), np.minimum(hi, c - h)
    b1 = np.maximum(a1, b1)
    m0, m1, m2 = moments(a1, b1, mu, s)
    inner = -2 * h * m1 - h * h * m0           # |u+h| < c
    M0, M1, M2 = moments(lo, hi, mu, s)
    out = -(c * c * (M0 - m0) - (M2 - m2))    # |u+h| >= c: integrand -(c^2 - u^2)
    return inner + out

def run(kappa, k, wg=0.7, wb=-0.4, rho_o=0.5, muA=-0.3, mu4=0.4, rho4=0.6, s4=0.9, nA=600, nH=48):
    xA, wA = np.polynomial.legendre.leggauss(nA); A = -5 * (xA + 1); wA = 5 * wA * np.exp(-0.5 * (A - muA) ** 2) / np.sqrt(2 * np.pi)
    xh, wh = np.polynomial.hermite_e.hermegauss(nH); wh = wh / np.sqrt(2 * np.pi)
    g0, b0 = np.meshgrid(xh, xh, indexing='ij'); W2 = np.outer(wh, wh)
    gam = 12 * k * wg + g0
    B = 12 * k * wb + rho_o * g0 + np.sqrt(1 - rho_o ** 2) * b0
    Dc = De = 0.0
    for Ai, wi in zip(A, wA):
        c = 6 * kappa * abs(Ai); s = abs(Ai) * s4 / 12
        mu = (Ai / 12) * (mu4 + rho4 * Ai) - gam ** 2 / 4
        h = 3 * k * B
        Dc += wi * np.sum(W2 * (G(mu + h, s, c) - G(mu, s, c)))
        De += wi * np.sum(W2 * H_eld(mu, s, c, h))
    return Dc, De

if __name__ == '__main__':
    print('kappa      k        D_cand        D_cand/k^2    D_eld         D_eld/k^2     naive kappa*k')
    for kappa in (0.5, 2.0, 8.0, 32.0):
        for k in (0.2, 0.1, 0.05, 0.025, 0.0125):
            Dc, De = run(kappa, k)
            print(f'{kappa:6.2f} {k:8.4f} {Dc:+.6e} {Dc/k**2:+.5f} {De:+.6e} {De/k**2:+.5f} {kappa*k:.4f}')
