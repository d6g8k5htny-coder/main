"""Negative control for the exploration: break parity by giving B a mean 0.5*A + 0.3 (an even-jet dependence).
Then the first-order term survives: D(k) is of order k, not k^2. By Lemma L (|w(y) - w(y')| <= |y - y'|(|y| + |y'|))
D(k)/k stays bounded uniformly in kappa; the output confirms this (D/k in [-0.37, -0.14] for kappa in [1/2, 32])."""
import numpy as np
from parity_toy import G, H_eld
def run(kappa, k, nA=600, nH=48, muA=-0.3, mu4=0.4, rho4=0.6, s4=0.9):
    xA, wA = np.polynomial.legendre.leggauss(nA); A = -5 * (xA + 1); wA = 5 * wA * np.exp(-0.5 * (A - muA) ** 2) / np.sqrt(2 * np.pi)
    xh, wh = np.polynomial.hermite_e.hermegauss(nH); wh = wh / np.sqrt(2 * np.pi)
    g0, b0 = np.meshgrid(xh, xh, indexing='ij'); W2 = np.outer(wh, wh)
    Dc = De = 0.0
    for Ai, wi in zip(A, wA):
        c = 6 * kappa * abs(Ai); s = abs(Ai) * s4 / 12
        gam = g0; B = (0.5 * Ai + 0.3) + b0
        mu = (Ai / 12) * (mu4 + rho4 * Ai) - gam ** 2 / 4
        h = 3 * k * B
        Dc += wi * np.sum(W2 * (G(mu + h, s, c) - G(mu, s, c)))
        De += wi * np.sum(W2 * H_eld(mu, s, c, h))
    return Dc, De
print('kappa      k      D_cand/k     D_eld/k   (parity broken: D ~ k, bounded uniformly in kappa by Lemma L)')
for kappa in (0.5, 2.0, 8.0, 32.0):
    for k in (0.05, 0.0125):
        Dc, De = run(kappa, k)
        print(f'{kappa:6.2f} {k:8.4f} {Dc/k:+.5f} {De/k:+.5f}')
