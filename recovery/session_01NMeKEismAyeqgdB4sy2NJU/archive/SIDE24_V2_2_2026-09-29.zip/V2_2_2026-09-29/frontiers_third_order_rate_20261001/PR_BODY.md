**Author-side proof candidate (Anthropic Claude). Scientific effect NONE. Nonauthor review required. I will not merge.**

Head `5dbe15c`, PROOF blob `110ed33a`. That is a rebind of the opening `15cf419` / `4f6dbf25` after #220's status-only update; the mathematics is unchanged. This packet improves the remainders of Math- #218 (Theorem T) and #220 (Theorem E3), from `O(ℓ^{4/11})` to `O(ℓ^{3/7})`, in every `d ≥ 2`:

    ν_cand(ℓ) = c ℓ^{−1/3} + B_{d,L} + I^{cand} ℓ^{1/4} + c₂ ℓ^{1/3} + O(ℓ^{3/7})                 (T⁺.1)
    ν_eld(ℓ)  = c ℓ^{−1/3} + c₁ ℓ^{1/4} + c₂ ℓ^{1/3} + ν_eld^{far,r_0^*}(ℓ) + O(ℓ^{3/7})          (E3⁺.0)
    ν_eld(ℓ)  = c ℓ^{−1/3} + c₁ ℓ^{1/4} + c₂ ℓ^{1/3} + O(ℓ^{3/7})        (with #187, merged)       (E3⁺.1)
    ρ_rej(ℓ)  = B_{d,L} + (I^{cand} − c₁) ℓ^{1/4} + O(ℓ^{3/7})            (with #187, merged)       (R⁺.1)

The elder density from intermediate separations is now `O(ℓ^{4/9}log(1/ℓ))`; #220 had `O(ℓ^{2/5})`. For SIDE24, the relative remainder of the three-term law becomes `O(ℓ^{16/21})`, against `O(ℓ^{23/33})` before.

## What is new

**Lemma L.** `|(c² − y²)₊ − (c² − y′²)₊| ≤ |y − y′|(|y| + |y′|)`. The Lipschitz constant is free of `c = 6κ|det A|`.
- #218 Step C2 and #220 Step E3 used the global constant `12κ|det A|`. That is the source of `(1 + κ)²` in #218 (C.1), and #218's closing remark of §3 says so.
- The inequality itself is the one #218 Step C3 already uses. #218's remark proposed a parity argument; Lemma L makes it unnecessary.
- Result, **Lemma C⁺**: the candidate cusp kernel has error `Cr(1 + κ)`.

**A refined bound on the elder edge window `𝔅_4`.** The elder decision's edge `|φ| ≈ 1/3` needs `|f₄ − 3γᵀA^{−1}γ| ≍ κ`. So `|f₄| ≥ 6κ` or `λ ≤ |γ|²/(2κ)`, and each alternative saves a factor `κ`. This gives `O(rκ)` where #220 had `O(rκ²)`.
- Result, **Lemma CE⁺**: the elder cusp kernel has error `C(r(1 + κ) + κ²r^{3/2} + κ³r²)`.

**Proposition W⁺ (typed window).** `Y` is affine in `f₄` with slope `det A/12`, so the typed window `|Y| ≤ 6κ|det A| + O(r)` has conditional probability `O(κ + r/|det A|)`. Hence

    E_Q[W_r/r²] ≤ C r² (κ + r)² (κ + r log(2/r)) P^N        (k ≤ r).

This beats #198 (W.1) by the factor `κ + r log(2/r)`.
- At `k = 0`, the equal-height kernel satisfies `r^{d−1}Ψ_0 = O(r³log(2/r))` near the diagonal. This proves, up to the log, the order that #211 suggests heuristically, and sharpens #198 (W.4) to `O(ρ⁴log(2/ρ))`.

**Assembly.** The splits are `ρ_f = ℓ^{2/7}`, `ρ_c = ℓ^{2/9}` and `a = ℓ^{1/9}`. Four error terms are then exactly `ℓ^{3/7}`: `ρ_f⁵/ℓ`, `ℓρ_f^{−2}`, `ℓ²ρ_f^{−11/2}` and `ℓ³ρ_f^{−9}`. All others are `O(ℓ^{4/9}log(1/ℓ))`. PROOF §6 Remark 1 explains which matched pair blocks further progress; the formal next term is `ℓ^{1/2}`.

## Dependencies

**Consumed, unmerged.** The packet cannot be integrated before these, and must be rebound if any of them changes.

| PR | PROOF blob | Head | Note |
|---|---|---|---|
| #207 | `f6df5a73` | `b12ff46` | a guarded main-only refresh for its integrator; the blob is unchanged |
| #218 | `70ca57ef` | `0cf048d` | the head is Dylan's `main` merge; the blob is unchanged |
| #220 | `c8767dde` | `70dcf31` | a status-only update after its successor Slice C PASS_TECHNICAL; rebound from `736a35de` |

**Consumed, merged.**
- [R]; [P] with [E1], [E2] and [REC]; [Z]; [C7-K].
- #191 (`441152df`) and #198 (`abfb98ae`).
- #187 (`07260114`), merged on 1 October at `c2f1270`. It is used only for (E3⁺.1) and the second form of (R⁺.1).

**Cited.** #216, and #223 (`c₂`; merged on 1 October at `f9ebba1`); #211 (Remark 3); #188.

The workflow binds every pin. For each consumed pull request it also checks the current head, or the merge commit once merged. I replayed its logic locally: all sources bind.

## Controls

`r37_check.py` uses the standard library and exact rationals. `RESULTS.json` is byte-identical under `-O` and on CPython 3.10–3.14.

| Control | Checks |
|---|---|
| R1 | the ledger: least `3/7`, attained exactly by the stated terms; the others `≥ 4/9`; split hypotheses; optimality of the splits; regressions to `4/11` (#218 T1) and `2/5` (#220); Remark 1's max–min |
| R2 | Lemma L |
| R3 | the window inclusion (3.2), on scalar instances and on exact rational matrix instances, `m = 1, 2, 3` |
| R4 | the sign window, (4.1), the exact `f₄`-window length, the splitting inequality |
| R5, R6 | the bookkeeping of Proposition W⁺ and Lemmas C⁺, CE⁺ |

Mutants M1–M8 each fail only their own control, and an unknown label exits 2.

## Review record

**Nonauthor review.** OpenAI / Codex (delegated) returned **PASS_TECHNICAL / ACCEPT_SCOPED** for Slices A–C (§§1–5), conditional on the exact imported interfaces, at `15cf419` / `4f6dbf25` (review 5381412814). It found no blocking defect. The rebind to `5dbe15c` changes dependency identities only, and a bounded delta read has been requested (5934578107).

**Same-family referee.** A clean-context referee (Anthropic Claude) read the note against all ten sources at their declared blobs.
- Verdict: **ACCEPT WITH MINOR FIXES**, with no major finding.
- Two minor findings and twelve nits, all applied:
  - Remark 1 said both matched pairs block a further gain. An exact max–min shows the `ρ_f⁵/ℓ` family alone does for both densities, while for the elder density the Lemma Q terms take over once the linear pair is resolved.
  - The parity statements of §2 and Remark 2 are now consistent.
- Its delta check accepted the fixes after one README correction, which is applied.

**The referee's independent checks:**
- an exact ledger;
- Lemma L on 93,025 grid points;
- (3.2) on 5,400 exact matrix instances;
- 20,000 bookkeeping instances;
- a `d = 2` Gaussian-field Monte Carlo of Proposition W⁺: at `k = 0`, `E_Q[W_r/r²]/r² ≈ 0.03r³`, and the ratios to W⁺ stay bounded.

**Independence.** The referee is the same account as the author, so it carries zero organizational independence.

**Review slices** (PROOF §9):
- **A** §§1–2: Lemma L and Lemma C⁺;
- **B** §3: Lemma CE⁺, the refined `𝔅_4` bound (3.1)–(3.2) and Step E3⁺;
- **C** §§4–5: Proposition W⁺ and the assembly.

Nonauthor reads of any slice are welcome. Slice A is short.

## Not claimed

- sharpness of `3/7`;
- certified constants;
- uniformity in `d` or `L`;
- the adjacent-pair density.

🤖 Generated with [Claude Code](https://claude.com/claude-code)

https://claude.ai/code/session_01NMeKEismAyeqgdB4sy2NJU
