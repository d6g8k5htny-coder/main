import json, hashlib, subprocess, pathlib
root = pathlib.Path('frontiers/third_order_rate_20261001')
S = pathlib.Path('/tmp/claude-0/-home-claude/b41b316f-232c-5cf7-a0ee-80f0de603a6f/scratchpad/r37')
def blob(path, rev='origin/main'):
    data = subprocess.run(['git', 'show', f'{rev}:{path}'], capture_output=True, check=True).stdout
    framed = b'blob ' + str(len(data)).encode() + b'\0' + data
    return {'path': path, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'git_blob': hashlib.sha1(framed).hexdigest()}
consumed = []
for path, tag, use in (
    ('frontiers/three_fronts_20260924/LIFETIME_REMAINDER.md', 'R', '(R2)-(R5): pin densities (R5), coupling, moments'),
    ('imports/lifetime_parent_20260925/UNIFORM_MATRIX_CAP_AND_LIFETIME.md', 'P', 'section 2 finite-jet rank and section 15 parity factorization, through #218 and #220'),
    ('imports/lifetime_parent_20260925/ERRATUM_CONGRUENCE.md', 'E1', 'reading rule'),
    ('reviews/d1_section9_borel_repair_20260925/REPAIR.md', 'E2', 'section 9 replacement'),
    ('reviews/d1_chain_reconciliation_20260928/RECONCILIATION.md', 'REC', 'reading rule'),
    ('frontiers/c7_zero_gap_limit_20260929/PROOF.md', 'Z', '(Z2)-(Z3): the equal-height kernel Psi_0 and B_{d,L}'),
    ('frontiers/c7_total_bounded_20260929/PROOF.md', 'C7-K', '(K2): the rejected fold mass'),
    ('frontiers/remainder_vanishing_20260930/PROOF.md', '191', 'Math- #191 (merged 2026-10-01, merge commit 9556547): Lemma E Steps 1-3 (for (F1) at k = 0); section 2: r_0^* and the k = 0 identity r^(d-1) Psi_0(b, ru) = r^-2 A_r(b, 0, u)'),
    ('frontiers/remainder_rate_20260930/PROOF.md', '198', 'Math- #198 (merged 2026-10-01, merge commit 124c37d): section 3 (3.1), the sign window and (3.2); Lemma W with its k = 0 clause, (W.1); the proof of (W.4); Lemma F-prime'),
    ('frontiers/far_elder_rate_20260930/PROOF.md', '187', 'Math- #187 (merged 2026-10-01 13:34 UTC, merge commit c2f1270, with the blob #220 pins): Theorem F at the single separation rho = r_0^* (far elder density O(l^(2/3))), for (E3+.1) and the second form of (R+.1) only'),
):
    d = blob(path); d['tag'] = tag; d['use'] = use; consumed.append(d)
cu = []
for path, rev, tag, use in (
    ('frontiers/cusp_second_order_20261001/PROOF.md', '782211f494aeef1a24b70fe76423c66afe2ea9dc', '207', 'section 0 cusp objects; (0.2)/(CU.2), the coefficient c1; section 7 (through #218)'),
    ('frontiers/candidate_third_order_20261001/PROOF.md', '0cf048d18eb28a4ba37eba89c238a2910d4ca915', '218', 'Lemma D (1.1); (1.2); Lemma F (F.1)-(F.2); Lemma C and its proof (Steps C1-C3, (C.2)); Lemma O (O.1); (0.1), the coefficient c2; section 4: the decomposition F + K + J2 + ... + J5 and the bounds on F and J2-J5'),
    ('frontiers/elder_third_order_20261001/PROOF.md', 'e481d230cba1f6f29d89c76c8086ee512a61c22e', '220', 'section 0 (near/far identity, A^eld, c1); Lemma Q; section 2 (notation, facts (F1)-(F7), (2.1)-(2.2), Lemma G, Lemma CE and its proof, Steps E1-E6); Lemma O-prime; Lemma H (through Lemma S-prime); Lemma S-prime (S-prime.1); section 4: the decomposition F^eld + K^eld + I^eld - J4 and the bound on F^eld'),
):
    d = blob(path, rev); d.update(tag=tag, use=use, head=rev, pr='Math- #' + tag); cu.append(d)
cun = []
for path, rev, tag, use in (
    ('frontiers/third_order_coefficient_20261001/NOTE.md', '04c08e1534122f210be888742fcd7a568e45b097', '216', 'numerical values of c2 (Remark 4)'),
    ('frontiers/c2_exact_20261001/NOTE.md', 'b2247fd81712f131ad604d13125580bf1afe2f94', '223', 'c2 in closed form for the Gaussian kernel (Remark 4)'),
    ('frontiers/equal_height_mass_value_20261001/NOTE.md', '8e89fe886368ae048e125c26f3ac51aa9bec83f6', '211', 'the heuristic r^(d-1) Psi_0 = O(r^3) quoted in Remark 3 and its Monte Carlo of I(s)'),
    ('frontiers/far_elder_flat_ridge_20260930/PROOF.md', '85f0586a468c2b2f73af0e340d251e33a52caade', '188', 'an alternative far elder bound (cited only)'),
):
    d = blob(path, rev); d.update(tag=tag, use=use, head=rev, pr='Math- #' + tag); cun.append(d)
files = []
for name in ('PROOF.md', 'README.md', 'r37_check.py', 'RESULTS.json'):
    data = (root / name).read_bytes()
    files.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
ref = (S / 'referee_v1' / 'REFEREE_1.md').read_bytes()
ref_d = (S / 'referee_v1' / 'REFEREE_1_DELTA.md').read_bytes()
m = {
 'schema': 1,
 'scientific_effect': 'NONE',
 'object': 'CL-THIRD-ORDER-RATE-20261001-v1',
 'kind': 'author-side proof candidate: the candidate and elder lifetime densities to third order with remainder O(l^(3/7)) in every d >= 2 (Theorems T+ and E3+), improving the O(l^(4/11)) of Math- #218 and #220: nu_cand = c l^(-1/3) + B_{d,L} + I^cand l^(1/4) + c2 l^(1/3) + O(l^(3/7)); nu_eld = c l^(-1/3) + c1 l^(1/4) + c2 l^(1/3) + nu_eld^{far,r_0^*} + O(l^(3/7)), and with merged #187 + O(l^(3/7)); rejected density B_{d,L} + (I^cand - c1) l^(1/4) + O(l^(3/7)); new: Lemma L (a kappa-free local Lipschitz bound for (c^2 - y^2)_+), Lemma C+ (candidate cusp kernel, error r(1 + kappa)), Lemma CE+ (elder cusp kernel, error r(1 + kappa) + kappa^2 r^(3/2) + kappa^3 r^2, through a refined bound on the edge window B_4), Proposition W+ (typed-window bound E_Q[W_r/r^2] <= C r^2 (kappa + r)^2 (kappa + r log(2/r)) P^N for k <= r; at k = 0 the equal-height kernel is O(r^3 log(2/r)) near the diagonal); intermediate elder mass O(l^(4/9) log(1/l))',
 'author': 'Anthropic Claude',
 'session': 'https://claude.ai/code/session_01NMeKEismAyeqgdB4sy2NJU',
 'read_at': {'branch_base': subprocess.run(['git', 'rev-parse', 'origin/main'], capture_output=True, check=True).stdout.decode().strip()},
 'consumed': consumed,
 'consumed_unmerged': cu,
 'cited_only': [],
 'cited_unmerged': cun,
 'cited_external': [
    {'tag': 'Haynsworth', 'reference': 'E. V. Haynsworth, inertia additivity of the Schur complement (1968)', 'use': 'through #218 Lemma C, Step C1'},
    {'tag': 'Weyl', 'reference': 'Weyl integration formula on symmetric matrices', 'use': 'through #218 Lemma D'},
    {'tag': 'Anderson', 'reference': 'T. W. Anderson, Proc. Amer. Math. Soc. 6 (1955) 170-176', 'use': 'through #218 (1.2)'}],
 'mutants': ['M1', 'M2', 'M3', 'M4', 'M5', 'M6', 'M7', 'M8'],
 'replayed': ['r37_check.py'],
 'referee': {'kind': 'clean-context same-family referee (Anthropic Claude subagent), before submission, with a delta check of the fixes', 'verdict': 'ACCEPT WITH MINOR FIXES (no major finding; two minor findings and twelve nits, all applied); delta check: one required README correction (applied) and four optional items (applied)',
             'report': 'project archive V2_2/frontiers_third_order_rate_20261001/REFEREE_1.md', 'report_sha256': hashlib.sha256(ref).hexdigest(), 'report_bytes': len(ref),
             'delta_report': 'project archive V2_2/frontiers_third_order_rate_20261001/REFEREE_1_DELTA.md', 'delta_report_sha256': hashlib.sha256(ref_d).hexdigest(), 'delta_report_bytes': len(ref_d),
             'independent_checks': 'source blobs; an exact independent ledger (least 3/7, others >= 4/9) and a max-min over the splits; Lemma L on 93,025 exact grid points; (3.2) on 5,400 exact matrix instances m = 1..4; 20,000 exact bookkeeping instances; sympy for Remark 4 and the integrals; (4.2) numerically; a d = 2 Gaussian-field Monte Carlo of Proposition W+ under the exact two-site regression (k = 0: E_Q[W_r/r^2]/r^2 ~ 0.03 r^3; ratios to W+ bounded)',
             'independence': 'same provider and GitHub account as the author; zero organizational independence'},
 'delivered_under': 'explicit owner instructions of Dylan Roy in claude.ai session session_01NMeKEismAyeqgdB4sy2NJU, given after OWNER_STOP (2026-09-27): 2026-09-30 "Continue to Work on closing as many mathematical items as possible while working with and supporting the other models in the GitHub. Also advance the mathematics in every place that\'s justified based on what we currently know", followed by "Continue"; standing: "Any request or permissions are preapproved in advance by me Dylan Roy", pull requests only, never self-merge, no register/GRAPH/STATUS/lemma_closed/prize/premise edits, OWNER_STOP.md untouched. OWNER_STOP.md addresses Cursor agents and is untouched; nothing is merged by its author.',
 'files': files,
}
json.dump(m, open(root / 'SOURCES.json', 'w'), indent=1)
open(root / 'SOURCES.json', 'a').write('\n')
print('ok', len(consumed), len(cu), len(cun))
