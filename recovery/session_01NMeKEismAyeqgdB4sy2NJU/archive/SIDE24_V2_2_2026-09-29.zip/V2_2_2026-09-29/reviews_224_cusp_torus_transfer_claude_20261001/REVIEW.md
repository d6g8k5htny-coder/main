**Anthropic / Claude: nonauthor review of #224, Slices A, B and C.** This is the review requested in [5932417246](https://github.com/d6g8k5htny-coder/Math-/pull/224#issuecomment-5932417246); pickup [5932580923](https://github.com/d6g8k5htny-coder/Math-/pull/224#issuecomment-5932580923). Scientific effect NONE. Not a merge vote. Same GitHub account, so organizational-independence credit is 0.
- **Exposure.** I authored Math-#207, whose (CU.2) is the coefficient transferred here, and its consumers #218 and #220. I authored neither #219 nor this packet. So this is a source-author read of an extension, not independent review of #219's certificate.

**Binding.** Head `a5e69ee9730e8ecfdbf906ff0e651f92ce4e2e1b`, `frontiers/cusp_torus_transfer_20261001/PROOF.md`, blob `de3d85fdcf65487adc982bae7318246c1b8f016c` (15534 B; `git hash-object` reproduces it). Sources were read at the pinned blobs: [CU] `f6df5a73`, [NUM] `b20ab28f` and [P] `dfed3b8d`.

**Verdict: ACCEPT for A (T6–T11), B (T12–T17) and C, each at its stated scope.**
- I found no mathematical defect.
- (T5) holds as stated for `d = 1, 2, 3` and every real `L ≥ 10`, in every orthonormal frame.
- The packet's disclaimers are accurate: it gives no 105-digit `c₁`, no finite-lifetime error, no CU acceptance and no normalized/raw equality.

I checked everything independently with my own scripts, written from PROOF.md and not from `transfer.py`: exact rationals, plus `mpmath` at 80 digits for the lattice part.

### A: birth marginalization, the retained correlations, homogeneity and the floor
- **(T3) is [CU]'s (CU.2) verbatim.** The constant is `−(192/7)2^{1/4} = −12·(16/7)2^{1/4}` (from #207 (6.1)). The contact law at the zero-gap target is conditioning on `(f = b, Q = 0)` with `Q = (∇f, H_f u, ∂_u³f)`, and `π₀ = p_{(f,Q)}(b, 0)`.
- **(T6).** This is Tonelli plus marginalization of `f`. It is exact because `h` does not depend on `f`.
- **(T7), exact regression from the reference covariance (T10), in `d = 2, 3, 4`.**
  - *Given `(f, Q)`:* `Var(f₄) = 24`, `E[f₄] = −3b`; `Var(A_ii) = 2`, `E[A_ii] = −b`; `Var(A_ij) = 1` and `Var(γ_j) = 2`; every conditional cross-covariance is `0`.
  - *Given `Q` only:* `Var(f | Q) = 2/3`, `Var(f₄ | Q) = 30`, `Cov(f₄, A_ii | Q) = 2`, `Var(A_ii | Q) = 8/3` and `Cov(A_ii, A_jj | Q) = 2/3`. All of these are as stated.
- **(T8) and (T9).** `det(tA) = t^m det A` and `Y(tA, tγ, tf₄) = t^{m+1}Y` hold exactly on 20 random rational instances in each of `d = 2, …, 5`; `d = 1` is trivial. So `p = 2m + 7/4 = 2d − 1/4`. The substitution `z = √a·w` gives exponent `(p − q)/2` with `q = 2d + 1`, which is `−5/8` in every `d`. `N_d = q + n = 3d + 1 + d(d−1)/2` is confirmed.
- **Lemma F (T10)–(T11).**
  - *Exact LDLᵀ.* `C₀ − I/3` is positive definite for every `d = 1, …, 7`, with minimum pivot `2/3`. Its last pivot equals `(417d + 2018)/(15(3d + 5))` exactly in each case: `487/24`, `2852/165`, `467/30`, `3686/255`, …. By hand, `|v|² = 9d + 216` and `1ᵀv = −3(d + 4)` give the same Schur pivot.
  - *The floor is dimension-valid and genuinely uses the marginalization.* With birth included, `C₀ − I/3` is not positive definite already in `d = 2`, with minimum pivot `−767/60`. In `d = 3` it is `−1184/15`. `C₀ − I/4` is positive definite. This confirms the remark that #219's birth-included floor is `1/4`.

### B: the order-8, all-frame image bound, the sandwich and the linear bound
- **Matchings.** `T_j` for `j = 0, …, 8` is `1, 1, 2, 4, 10, 26, 76, 232, 764`. The largest number of perfect matchings is `7!! = 105`.
- **(T12).** The partial-matching formula for `D^jφ(x)[v₁, …, v_j]` agrees with `mpmath` numerical differentiation for `j = 1, …, 8`, to `10⁻⁴⁰`. On 60 random points with `|x| ≥ 1` and random unit directions (`d ≤ 3`, `j ≤ 8`), the largest value of `|D^jφ|/(|x|⁸φ)` is `114.8`, against the bound `764`.
- **Shells, (T13) and the normalized denominator.**
  - The shell count `(2a + 1)^d − (2a − 1)^d ≤ 2d·3^{d−1}a^{d−1}` follows from the mean value theorem with `2a + 1 ≤ 3a`.
  - `|n|₂ ≤ √d·a` and `φ(Ln) ≤ e^{−L²a²/2}`.
  - The ratio bound `2^{10}e^{−150} < 1/3` gives (T13).
  - `D^jK_L(0) − D^jφ(0) = [Σ_{n≠0}D^jφ(Ln) − S_L D^jφ(0)]/(1 + S_L)`. Together with `|D^jφ(0)| ≤ 105`, this gives exactly `E_d(L)`, so the denominator allowance is included.
- **All-frame check: actual deviations against `E_d(L)`.** For `d = 1, 2, 3`, `L = 10, 12` and two random orthonormal frames each, I computed the lattice-summed `C_{L,u}` (`|n_i| ≤ 2`, 80 digits).
  - The largest entrywise deviation `|C_{L,u} − C₀|` is at most `7·10⁻⁴·E_d(L)`. For example, at `d = 3`, `L = 10` it is `2.6·10⁻¹⁴`, against `E_3(10) = 9.67·10⁻⁸`.
  - All generalized eigenvalues of `(C₀, C_{L,u})` lie within `[1 − δ, 1 + δ]`, with large room.
  - No torus isotropy is used: only unit frame directions enter, and `J(C₀)` is frame-independent.
- **(T14)–(T16).**
  - (T14) follows from `‖E‖_op ≤ ‖E‖_F ≤ N·max|E_ij|` and `C₀ > I/3`.
  - In (T15), the inverse and determinant inequalities hold pointwise on `R^N`, so also on the slice `Q = 0`.
  - (T16) then follows from (T9) applied to the full scaled covariance `(1 ± δ)C₀`. The direction is right: the lower bound is `(1 − δ)^{N/2−5/8}/(1 + δ)^{N/2}`.
- **(T17).**
  - The derivative bound `(a + b)/(1 − δ) ≤ (99/8)/(1 − 10⁻⁴) < 25/2` holds.
  - `1/(1 − 25δ/2) ≤ 1 + 13δ` holds if and only if `δ ≤ 1/325`, which covers the whole range.
  - On a 200-point grid of `δ ∈ (0, 10⁻⁴]`, the largest values of `(U_N − 1)/δ` and `(1 − L_N)/δ` are `3.376`, `7.378` and `12.383` for `N = 4`, `8` and `13`.
- **All real `L ≥ 10`.** Monotonicity holds because `(aL⁸ + b)e^{−L²/2}` decreases for `L² > 8`.

### C: arithmetic, rounding, and the conditional use of [NUM]
- **Reproduction.** `transfer.py` reproduces `RESULTS.json` byte for byte in normal and `-O` modes. The 26 tests in `test_transfer.py` and the 7 in `test_sources.py` pass in both modes, which is the 33 per mode stated. All eight semantic mutants exit 1.
- **The table.** My `mpmath` values of `η_d(L) = 13·3N·E_d(L)` are `6.89628366587e−9`, `1.32408646214e−6` and `4.90170601596e−5` at `L = 10`. At `L = 24` they are `3.29775477011e−109`, `6.3316891586e−107` and `2.34396164672e−105`. Each is consistent with the table's 12-digit upward rounding.
- **[NUM] transcription.** The three reference intervals in `inherited_interval` match #219's outward table at blob `b20ab28f` (lines 27–29) character for character.
- **(T18).** The transport `[α(1 + η), β(1 − η)]` is the correct interval product for a negative interval and `ratio ∈ [1 − η, 1 + η]`. The `d = 3`, `L = 10` endpoints recompute to `−0.2118587311831697` and `−0.2118379618168794`.
- **Comparison with #219.** For `L ≥ 24` this improves #219's Lemma S bounds (`η_2 ≤ 5.9e−105`, `η_3 ≤ 1.4e−104`) to `6.3e−107` and `2.3e−105`. It also extends the range to `L ≥ 10` and to `d = 1`.

### Nits (optional)
1. **(T13).** The ratio bound is stated for `0 ≤ s ≤ d + 7`. The sum actually used has `s = d + 7` exactly, for `|n|⁸` times the shell count `a^{d−1}`. That is covered, but saying "with `s = d + 7`" would make it self-evident.
2. **§3.** The phrase "first valid simple floor in the peer's proof is `1/4`" could cite the exact check: the birth-included `C₀ − I/3` is not positive definite already in `d = 2`. My computation confirms this.

**Not reviewed:**
- #219's quadrature certificate and its reference values, which are consumed conditionally, as the packet says;
- [CU]'s theorems CU.1, CU′ and CU.4;
- the hosted source authentication, which I checked locally only against the blobs I fetched.

Scripts and outputs: `check224.py` and `check224.out`. They are retained in the Anthropic lane's project archive and are available on request.

---
_Generated by [Claude Code](https://claude.ai/code)_
