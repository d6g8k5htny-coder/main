"""Independent checks for Math-#224 (Anthropic/Claude nonauthor review). Written from PROOF.md alone, not from transfer.py.
Exact parts: Fractions. Lattice part: mpmath (80 digits)."""
from fractions import Fraction as F
from itertools import combinations
import random, math, json
import mpmath as mp

# ---------------------------------------------------------------- exact reference covariance (T10)
def dfact(n):  # (n-1)!! for even n (moments of N(0,1)): E[Z^n]
    r = 1
    for j in range(1, n, 2): r *= j
    return r
def cov0(a, b):
    s = [x + y for x, y in zip(a, b)]
    if any(x % 2 for x in s): return F(0)
    # (-1)^{|b|} d^{a+b} phi(0), with d^{2k} e^{-x^2/2}|_0 = (-1)^k (2k-1)!!
    sign = (-1) ** (sum(b) + sum(x // 2 for x in s))
    val = 1
    for x in s: val *= dfact(x)
    return F(sign * val)
def e(d, *ax):
    v = [0] * d
    for i in ax: v[i] += 1
    return tuple(v)
def labels(d, birth=False):
    Q = [e(d, i) for i in range(d)] + [e(d, 0, i) for i in range(d)] + [e(d, 0, 0, 0)]
    Z = [e(d, i, j) for i in range(1, d) for j in range(i, d)] + [e(d, 0, 0, i) for i in range(1, d)] + [e(d, 0, 0, 0, 0)]
    return ([e(d)] if birth else []) + Q, Z
def mat(rows, cols): return [[cov0(a, b) for b in cols] for a in rows]
def ldl_pivots(M):
    n = len(M); A = [list(r) for r in M]; D = []
    L = [[F(int(i == j)) for j in range(n)] for i in range(n)]
    for j in range(n):
        p = A[j][j] - sum(L[j][k] ** 2 * D[k] for k in range(j))
        D.append(p)
        for i in range(j + 1, n):
            L[i][j] = (A[i][j] - sum(L[i][k] * L[j][k] * D[k] for k in range(j))) / p
    return D
def inv(M):
    n = len(M); A = [list(r) + [F(int(i == j)) for j in range(n)] for i, r in enumerate(M)]
    for c in range(n):
        p = next(r for r in range(c, n) if A[r][c] != 0); A[c], A[p] = A[p], A[c]
        pv = A[c][c]; A[c] = [x / pv for x in A[c]]
        for r in range(n):
            if r != c and A[r][c] != 0:
                f = A[r][c]; A[r] = [x - f * y for x, y in zip(A[r], A[c])]
    return [r[n:] for r in A]
def mm(A, B): return [[sum(A[i][k] * B[k][j] for k in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]
def T(A): return [list(r) for r in zip(*A)]

out = {}
# A1: floor C0 > I/3 for d = 1..7; last pivot = (417d+2018)/(15(3d+5)); N_d
floor = {}
for d in range(1, 8):
    Q, Z = labels(d); X = Q + Z
    C0 = mat(X, X)
    piv = ldl_pivots([[C0[i][j] - (F(1, 3) if i == j else 0) for j in range(len(X))] for i in range(len(X))])
    N = len(X)
    floor[d] = {'N': N, 'N_formula': 3 * d + 1 + d * (d - 1) // 2, 'q': len(Q), 'min_pivot': str(min(piv)),
                'all_positive': all(p > 0 for p in piv), 'last_pivot': str(piv[-1]),
                'formula': str(F(417 * d + 2018, 15 * (3 * d + 5))), 'match': piv[-1] == F(417 * d + 2018, 15 * (3 * d + 5))}
    # also the sharpness of 1/3 as a uniform floor: smallest eigen-type pivot with floor 1/2 fails?
    piv_half = ldl_pivots([[C0[i][j] - (F(1, 2) if i == j else 0) for j in range(len(X))] for i in range(len(X))])
    floor[d]['floor_1/2_fails'] = not all(p > 0 for p in piv_half)
out['A1_floor'] = floor

# A2: conditional law given (f = b, Q = 0) and the birth mixture (T7), d = 2, 3, 4
cond = {}
for d in (2, 3, 4):
    Qb, Z = labels(d, birth=True)          # Qb = (f, Q)
    S11 = mat(Qb, Qb); S21 = mat(Z, Qb); S22 = mat(Z, Z)
    I11 = inv(S11)
    B = mm(S21, I11)                         # regression coefficients of Z on (f, Q)
    Sc = [[S22[i][j] - sum(B[i][k] * S21[j][k] for k in range(len(Qb))) for j in range(len(Z))] for i in range(len(Z))]
    names = [str(z) for z in Z]
    f4 = len(Z) - 1; A11 = 0; A22 = d - 1 if d >= 3 else None   # first two diagonal A entries (labels order: (1,1),(1,2),..)
    diagA = [i for i, z in enumerate(Z) if sum(z) == 2 and max(z) == 2]
    offA = [i for i, z in enumerate(Z) if sum(z) == 2 and max(z) == 1]
    gam = [i for i, z in enumerate(Z) if sum(z) == 3]
    c = {'Var(f4|f,Q)': str(Sc[f4][f4]), 'mean coeff f4 on f': str(B[f4][0]),
         'Var(A_ii|f,Q)': sorted({str(Sc[i][i]) for i in diagA}), 'mean coeff A_ii on f': sorted({str(B[i][0]) for i in diagA}),
         'Var(A_ij|f,Q)': sorted({str(Sc[i][i]) for i in offA}), 'Var(gamma|f,Q)': sorted({str(Sc[i][i]) for i in gam}),
         'max |offdiag cond cov|': str(max([abs(Sc[i][j]) for i in range(len(Z)) for j in range(len(Z)) if i != j] or [F(0)]))}
    # birth mixture: covariance of Z given Q only (f integrated out)
    Q, _ = labels(d)
    T11 = mat(Q, Q); T21 = mat(Z, Q); Bq = mm(T21, inv(T11))
    Sm = [[S22[i][j] - sum(Bq[i][k] * T21[j][k] for k in range(len(Q))) for j in range(len(Z))] for i in range(len(Z))]
    fQ = mat([e(d)], Q); varf = F(1) - sum(x * y for x, y in zip(mm(fQ, inv(T11))[0], fQ[0]))
    c.update({'Var(f|Q)': str(varf), 'Var(f4|Q)': str(Sm[f4][f4]), 'Cov(f4,A_ii|Q)': sorted({str(Sm[f4][i]) for i in diagA}),
              'Var(A_ii|Q)': sorted({str(Sm[i][i]) for i in diagA}),
              'Cov(A_ii,A_jj|Q)': sorted({str(Sm[i][j]) for i in diagA for j in diagA if i != j})})
    cond[d] = c
out['A2_conditioning'] = cond

# A3: homogeneity p = 2m + 7/4 and slice exponent (p - q)/2 = -5/8; exact degree check of Delta and Y on random data
def det(M):
    n = len(M)
    if n == 0: return F(1)
    A = [list(r) for r in M]; s = F(1)
    for c in range(n):
        p = next((r for r in range(c, n) if A[r][c] != 0), None)
        if p is None: return F(0)
        if p != c: A[c], A[p] = A[p], A[c]; s = -s
        s *= A[c][c]
        for r in range(c + 1, n):
            f = A[r][c] / A[c][c]; A[r] = [x - f * y for x, y in zip(A[r], A[c])]
    return s
def adj(M):
    n = len(M)
    if n == 0: return []
    if n == 1: return [[F(1)]]
    return [[(-1) ** (i + j) * det([r[:j] + r[j + 1:] for k, r in enumerate(M) if k != i]) for i in range(n)] for j in range(n)]
rng = random.Random(224)
hom = {}
for d in range(1, 6):
    m = d - 1; ok = True
    for _ in range(20):
        A = [[F(0)] * m for _ in range(m)]
        for i in range(m):
            for j in range(i, m):
                A[i][j] = A[j][i] = F(rng.randint(-9, 9), rng.randint(1, 5))
        g = [F(rng.randint(-9, 9), rng.randint(1, 5)) for _ in range(m)]
        f4 = F(rng.randint(-20, 20), 3); t = F(rng.randint(2, 9), rng.randint(1, 4))
        def Y(A, g, f4):
            Ad = adj(A); return f4 * det(A) / 12 - sum(g[i] * Ad[i][j] * g[j] for i in range(m) for j in range(m)) / 4
        tA = [[t * x for x in r] for r in A]
        ok &= det(tA) == t ** m * det(A) and Y(tA, [t * x for x in g], t * f4) == t ** (m + 1) * Y(A, g, f4)
    p = F(7, 4) * (m + 1) + F(m, 4)
    hom[d] = {'degrees_ok': ok, 'p': str(p), 'p_formula_2d-1/4': p == 2 * d - F(1, 4), 'q': 2 * d + 1,
              'slice_exponent': str((p - (2 * d + 1)) / 2)}
out['A3_homogeneity'] = hom

# B1: matching counts and the origin bound
Tj = [sum(math.factorial(j) // (2 ** a * math.factorial(a) * math.factorial(j - 2 * a)) for a in range(j // 2 + 1)) for j in range(9)]
out['B1_matchings'] = {'T_j': Tj, 'max_perfect_matchings_j<=8': max(dfact(j) if j % 2 == 0 else 0 for j in range(9))}

# B2: directional derivative formula D^j phi(x)[v...] = phi(x) * sum over partial matchings (-1)^{#pairs+#singles} prod(v.v) prod(x.v)
mp.mp.dps = 80
def partial_matchings(idx):
    if not idx: yield [], []; return
    first, rest = idx[0], idx[1:]
    for pm, sg in partial_matchings(rest):      # first as singleton
        yield pm, [first] + sg
    for k in range(len(rest)):                   # first paired with rest[k]
        others = rest[:k] + rest[k + 1:]
        for pm, sg in partial_matchings(others):
            yield [(first, rest[k])] + pm, sg
def dphi(x, vs):
    tot = mp.mpf(0)
    for pm, sg in partial_matchings(list(range(len(vs)))):
        term = mp.mpf((-1) ** (len(pm) + len(sg)))
        for i, k in pm: term *= mp.fsum(a * b for a, b in zip(vs[i], vs[k]))
        for i in sg: term *= mp.fsum(a * b for a, b in zip(x, vs[i]))
        tot += term
    return tot * mp.e ** (-mp.fsum(a * a for a in x) / 2)
# sanity vs numerical differentiation along a single direction (j = 1..8), d = 2
xs = [mp.mpf('0.7'), mp.mpf('-1.3')]; v = [mp.mpf(3) / 5, mp.mpf(4) / 5]
g1 = lambda s: mp.e ** (-((xs[0] + s * v[0]) ** 2 + (xs[1] + s * v[1]) ** 2) / 2)
deriv_ok = all(abs(mp.diff(g1, 0, j) - dphi(xs, [v] * j)) < mp.mpf(10) ** -40 for j in range(1, 9))
# (T12) on random points |x| >= 1 and random unit directions
worst = mp.mpf(0)
for _ in range(60):
    d = rng.choice((1, 2, 3)); j = rng.randint(0, 8)
    x = [mp.mpf(rng.uniform(-6, 6)) for _ in range(d)]
    if mp.sqrt(mp.fsum(a * a for a in x)) < 1: continue
    vs = []
    for _ in range(j):
        w = [mp.mpf(rng.gauss(0, 1)) for _ in range(d)]; nw = mp.sqrt(mp.fsum(a * a for a in w)); vs.append([a / nw for a in w])
    nx = mp.sqrt(mp.fsum(a * a for a in x))
    worst = max(worst, abs(dphi(x, vs)) / (nx ** 8 * mp.e ** (-nx * nx / 2)))
out['B2_derivatives'] = {'matching_formula_vs_mp.diff': bool(deriv_ok), 'max |D^j phi|/(|x|^8 phi) on 60 samples': mp.nstr(worst, 6), 'bound': 764}

# B3: actual lattice deviation C_{L,u} - C_0 in random frames vs E_d(L); generalized eigenvalues within [1-delta, 1+delta]
def frame(d, rng):
    # random orthonormal frame by Gram-Schmidt
    vs = []
    while len(vs) < d:
        w = [mp.mpf(rng.gauss(0, 1)) for _ in range(d)]
        for u in vs:
            c = mp.fsum(a * b for a, b in zip(w, u)); w = [a - c * b for a, b in zip(w, u)]
        nw = mp.sqrt(mp.fsum(a * a for a in w))
        if nw > mp.mpf('1e-3'): vs.append([a / nw for a in w])
    return vs
def cov_L(alpha, beta, R, L, d):
    # (-1)^{|beta|} D^{alpha+beta} K_L(0) along frame directions R
    dirs = []
    for i, k in enumerate(alpha): dirs += [R[i]] * k
    for i, k in enumerate(beta): dirs += [R[i]] * k
    num = mp.mpf(0); S = mp.mpf(0)
    rngn = range(-2, 3)
    import itertools
    for n in itertools.product(rngn, repeat=d):
        x = [L * c for c in n]
        num += dphi(x, dirs)
        if any(n): S += mp.e ** (-mp.fsum(a * a for a in x) / 2)
    return (-1) ** sum(beta) * num / (1 + S)
def E_d(d, L): return 3 * d * 3 ** (d - 1) * (764 * d ** 4 * mp.mpf(L) ** 8 + 105) * mp.e ** (-mp.mpf(L) ** 2 / 2)
lat = {}
for d in (1, 2, 3):
    Q, Z = labels(d); X = Q + Z; N = len(X)
    C0 = mp.matrix([[mp.mpf(cov0(a, b).numerator) / cov0(a, b).denominator for b in X] for a in X])
    for L in (10, 12):
        rows = []
        for trial in range(2):
            R = frame(d, rng)
            CL = mp.matrix(N, N)
            for i in range(N):
                for j in range(i, N):
                    CL[i, j] = CL[j, i] = cov_L(X[i], X[j], R, mp.mpf(L), d)
            dev = max(abs(CL[i, j] - C0[i, j]) for i in range(N) for j in range(N))
            Ed = E_d(d, L); delta = 3 * N * Ed
            # generalized eigenvalues of (C0, CL)
            Linv = mp.inverse(mp.cholesky(C0)); M = Linv * CL * Linv.T
            ev = mp.eigsy(M)[0]
            rows.append({'max_entry_dev': mp.nstr(dev, 5), 'E_d': mp.nstr(Ed, 5), 'dev/E_d': mp.nstr(dev / Ed, 5),
                         'gen_eig_range': [mp.nstr(min(ev) - 1, 5), mp.nstr(max(ev) - 1, 5)], 'delta': mp.nstr(delta, 5),
                         'within': bool(max(abs(x - 1) for x in ev) <= delta)})
        lat[f'd={d},L={L}'] = rows
out['B3_lattice'] = lat

# B4: (T17) on a fine grid and the table values eta_d(L) = 13 * 3 N E_d(L)
t17 = {}
for N in (4, 8, 13):
    a = mp.mpf(N) / 2 - mp.mpf(5) / 8; b = mp.mpf(N) / 2; worst = mp.mpf(0)
    for k in range(1, 201):
        dl = mp.mpf(k) / 200 * mp.mpf('1e-4')
        U = (1 + dl) ** a / (1 - dl) ** b; Lw = (1 - dl) ** a / (1 + dl) ** b
        worst = max(worst, (U - 1) / dl, (1 - Lw) / dl)
    t17[N] = mp.nstr(worst, 8)
out['B4_T17_max_slope'] = t17
tab = {}
for d in (1, 2, 3):
    N = 3 * d + 1 + d * (d - 1) // 2
    tab[d] = {str(L): mp.nstr(13 * 3 * N * E_d(d, L), 12) for L in (10, 24)}
out['B4_eta_table'] = tab
print(json.dumps(out, indent=1, default=str))
