<!-- main#229 comment 5974287061, created 2026-10-03T22:45:55Z (updated 2026-10-03T22:45:55Z), 18787 UTF-8 bytes, SHA-256 faf8691f08e654bbbef6b253668e3457e2f384846a54405fecfb3bcceabae696; copied verbatim from the GitHub API -->
## C94 cross-provider review: reviewer controls, exact executable and stdout

This is the standard-library script behind the [review 5974283483](https://github.com/d6g8k5htny-coder/main/issues/229#issuecomment-5974283483). I wrote it independently of the author's and the first reviewer's code. It checks finite algebra only. It does not prove C91–C93's Gaussian inputs, C82's Theorem LB, A1's W1 (whose algebra it re-checks; disclosed self-consumption) or QS/A2 geometry.

Dylan Roy — delegated AI review. Actual performer: Anthropic Claude (session `session_01NMeKEismAyeqgdB4sy2NJU`). Scientific effect: NONE.

**Extraction rule.**
- The file is the exact text between the ```` ```python ```` fence under the `###` heading and the next ```` ``` ```` line, plus one final newline.
- The expected stdout is the text in the following ```` ```text ```` fence, plus one final newline.
- The byte counts below include those newlines.

**Run.**
- `python3 -B -S c94_exact.py`: exit 0, with exactly the stdout shown. A run takes about 3 seconds.
- `-O` mode and plain `python3`: byte-identical output.
- `python3 c94_exact.py BOGUS`: exit 2.
- Each of the six mutant labels exits 1 (table below).

The output was produced with Python 3.11.15.

**Groups.**

| group | what it checks |
|---|---|
| Y0 | (C3): `G(X, ζ) = P(u, Z)` exactly; `a_S = γ²(ψ + c)`, `a_M = γ²(ψ − c)` |
| Y1 | (C6)–(C7): the radius event `λ < H(γ)/ρ²`, `288U⁴`, `24rU²`; §6: `Rbox` is the `ℓ¹` radius of the box's raw image, term by term |
| Y2 | (C8): W1 for `S` ⟺ `E`'s `R² ≤ q²`; W1 for `M` (`τ_M ≤ 4a`) in squared form; `6ψ/(ψ + c) = 144λ/a_S`; `m_S ≥ c_* a_S²`; `27/512 > 3/250` |
| Y3 | (C9)–(C10): the inverse primitives, the total `(3/2)ε + (4/3)r√ε` at `d = √ε`, the squared-Markov factor |
| Y4 | (C12)–(C13): `dλ = (γ²/24)dψ`, `w_λ dλ = (γ⁶/384)(ψ² − c²)dψ`, `γ⁶\|c\|³ = \|D\|³`, `γ⁶R² = J²` |
| Y5 | (C14): the decomposition of `{E0 ≥ η}` |
| Y6 | (C16)–(C18): the eight powers at `w = r^{−1/16}`, `d = r^{1/2}`, `p = 2`, minimum `1/2`; `ρ ≥ w/2` |
| Y7 | (C19): the witness and sampled neighbourhoods (typed, `ψ > 2c`, no extra critical point) |
| Y8 | §6: C90's repaired constants `K = 187969/31250`, `ω₀ = 74875/187969`, both interval bounds; Corollary 9(c)'s integral |

**Mutants.** Each was actually run; each exits 1.

| label | change | failing groups | failed checks |
|---|---|---|---:|
| `RBOX_48` | radius threshold `H = (25/48)(\|γ\| + 12)²` | Y1 | 540 |
| `INT_144` | edge integral `144U⁴` | Y1 | 39 |
| `CSTAR_125` | `c_* = 3/(125A_*²)` | Y2 | 3069 |
| `JAC_12` | `dλ = (γ²/12)dψ` | Y4 | 7986 |
| `LEDGER_P1` | moment order `p = 1` in (C17) | Y6 | 1 |
| `K_SIX` | repaired bound `K < 6` | Y8 | 1 |

### c94_exact.py

- **File:** 14980 bytes, SHA-256 `9091f5cf39e16753ac7a2f702d722eccb191ab2dadbc3f6c141cb06de877c188`.
- **Stdout:** 640 bytes, SHA-256 `8a7c77ac56c96423767bb379abdffa633242c0857f99bc80eea7e3849f7df424`.

```python
#!/usr/bin/env python3
"""C94 cross-provider review controls: exact rational checks, standard library only.

Target: C94-PLANAR-WEIGHTED-TRAP-WINDOW-RANDOM-MARGIN-20261003-v1, main issue 229, comment 5964517708
(15,407 bytes, SHA-256 0fe4fa20...af3c).
Reviewer: Anthropic Claude, session_01NMeKEismAyeqgdB4sy2NJU, for Dylan Roy (delegated AI review).
Written without the author's or the first reviewer's code. Disclosed self-consumption: (C8) uses the
reviewer's own QS addendum A1 (Lemma W1), and section 6 names the reviewer's A2 QS-E' as repaired by C90.

Usage: python3 c94_exact.py [MUTANT]   (exit 0 pass, 1 fail, 2 unknown label)
Mutants (each must exit 1):
  RBOX_48      radius threshold H(gamma) = (25/48)(|gamma| + 12)^2 in place of 25/96 (C6)
  INT_144      the edge integral 144 U^4 in place of 288 U^4 (C7)
  CSTAR_125    c_* = 3/(125 A_*^2) in place of 3/(250 A_*^2) (C8)
  JAC_12       d lambda = (gamma^2/12) d psi in place of gamma^2/24 (C12)
  LEDGER_P1    the moment order p = 1 in place of p = 2 (C17)
  K_SIX        the repaired Lemma 7(b) bound K < 6 in place of K < 6.05 (section 6, repair 1)
These checks test finite algebra only. They do not prove C91-C93's Gaussian inputs, C82's level-band
theorem LB, A1's W1 (whose algebra is re-checked here), or QS/A2 geometry.
"""
import math
import random
import sys
from fractions import Fraction as F

MUTANTS = ("RBOX_48", "INT_144", "CSTAR_125", "JAC_12", "LEDGER_P1", "K_SIX")
MUT = None
if len(sys.argv) > 1:
    MUT = sys.argv[1]
    if len(sys.argv) > 2 or MUT not in MUTANTS:
        print("unknown mutant label: %s" % " ".join(sys.argv[1:]))
        sys.exit(2)

RNG = random.Random(94_5964517708)
RESULTS, FAILS = [], []


class Group:
    def __init__(self, name):
        self.name, self.n, self.bad = name, 0, 0

    def check(self, ok, msg=""):
        self.n += 1
        if not ok:
            self.bad += 1
            if len(FAILS) < 12:
                FAILS.append("%s: %s" % (self.name, msg))

    def close(self):
        RESULTS.append((self.name, self.n - self.bad, self.n))


def rq(lo, hi, den=97):
    a, b = int(math.floor(F(lo) * den)), int(math.floor(F(hi) * den))
    return F(RNG.randint(a, b), den)


def rq_pos(lo, hi, den=97):
    while True:
        x = rq(lo, hi, den)
        if x > 0:
            return x


def Gcub(lam, gam, B1, C3, X, zeta):
    return (2 * X**3 - F(3, 2) * X - F(1, 2) + (gam / 2) * (X**2 - F(1, 4)) * zeta
            - (lam / 2) * zeta**2 + (B1 / 2) * X * zeta**2 + (C3 / 6) * zeta**3)


def Pcub(psi, c, R, u, Z):
    return 2 * u**3 - F(3, 2) * u - F(1, 2) - (psi + 2 * c * u) * Z**2 / 48 + R * Z**3 / 3456


# =====================================================================
# Y0  (C3): the raw-to-cubic map G(X, zeta) = P(u, Z), u = X + gamma zeta/12, Z = gamma zeta
# =====================================================================
g = Group("Y0 (C3) raw-to-cubic map")
for _ in range(3000):
    lam, gam, B1, C3 = rq(-3, 3), rq(-3, 3), rq(-3, 3), rq(-3, 3)
    if gam == 0:
        continue
    D, J = gam**2 - 12 * B1, 8 * gam**3 - 144 * B1 * gam + 576 * C3
    psi, c, R = 24 * lam / gam**2, D / gam**2, J / gam**3
    X, zeta = rq(-3, 3), rq(-3, 3)
    g.check(Gcub(lam, gam, B1, C3, X, zeta) == Pcub(psi, c, R, X + gam * zeta / 12, gam * zeta), "G(X, zeta) = P(u, Z)")
    g.check(24 * lam + D == gam**2 * (psi + c) and 24 * lam - D == gam**2 * (psi - c), "a_S = gamma^2 (psi + c), a_M = gamma^2 (psi - c)")
g.close()

# =====================================================================
# Y1  (C6)-(C7): the radius event and the two elementary integrals
# =====================================================================
g = Group("Y1 (C6)-(C7) radius tail")
Hc = F(25, 48) if MUT == "RBOX_48" else F(25, 96)
for _ in range(4000):
    gam, lam, rho = rq(-6, 6), rq_pos(0, 3), rq_pos(F(1, 10), 20)
    # Rbox > 3/2 + rho  <=>  (5/2)(|gam| + 12)/sqrt(24 lam) > rho  <=>  (25/4)(|gam| + 12)^2 > 24 lam rho^2
    lhs_event = F(25, 4) * (abs(gam) + 12)**2 > 24 * lam * rho**2
    g.check(lhs_event == (lam < Hc * (abs(gam) + 12)**2 / rho**2), "Rbox > 3/2 + rho iff lambda < H(gamma)/rho^2")
# section 6: Rbox bounds the raw image of the box [-5/4, 3/2] x [-30/sqrt(psi), 30/sqrt(psi)] under
# (u, Z) -> (X, zeta) = (u - Z/12, Z/gamma); take 24 lambda = s^2 so that sqrt(psi) = s/|gamma| is rational
for _ in range(3000):
    gam, s_ = rq(-6, 6), rq_pos(F(1, 20), 6)
    if gam == 0:
        continue
    sqpsi = s_ / abs(gam)
    rbox = F(3, 2) + F(5, 2) * (abs(gam) + 12) / s_
    worst = F(0)
    for u in (F(-5, 4), F(3, 2)):
        for Z in (30 / sqpsi, -30 / sqpsi):
            X, zeta = u - Z / 12, Z / gam
            worst = max(worst, abs(X) + abs(zeta))           # an upper bound for the Euclidean norm
    g.check(worst <= rbox, "the raw image of the trap box has radius <= Rbox")
    g.check(F(3, 2) + 30 / (12 * sqpsi) + 30 / s_ == rbox, "3/2 + (5/2)/sqrt(psi) + 30/sqrt(24 lambda) = Rbox exactly")
k288 = 144 if MUT == "INT_144" else 288
for U in [F(k, 13) for k in range(1, 40)]:
    # int_0^U dlam int_0^{48 lam} s(48 lam - s)/16 ds = int_0^U 1152 lam^3 dlam
    inner_coeff = (F(48)**3 / 2 - F(48)**3 / 3) / 16
    g.check(inner_coeff == 1152 and inner_coeff * U**4 / 4 == k288 * U**4, "(C7) 288 U^4")
    g.check(48 * U**2 / 2 == 24 * U**2, "(C7) 24 r U^2")
    rho = U + 1
    for H in (F(1), F(7, 3)):
        Ucap = min(U, H / rho**2)
        g.check(Ucap**4 <= H**4 / rho**8 and Ucap**2 <= H**2 / rho**4, "U^4 <= H^4/rho^8, U^2 <= H^2/rho^4")
g.close()

# =====================================================================
# Y2  (C8): A1 W1 on E and the deterministic tolerance floor v >= c_* a_S^2
# =====================================================================
g = Group("Y2 (C8) tolerance floor")
cst_den = 125 if MUT == "CSTAR_125" else 250
g.check(F(4, 27) * 27 == 4, "a^2 = 4/27 for a = 2/(3 sqrt 3)")
for _ in range(6000):
    psi = rq_pos(F(1, 10), 8)
    c = rq(-psi + F(1, 97), psi / 2)                 # E: |c| < psi and psi >= 2c
    if not (abs(c) < psi and psi >= 2 * c):
        continue
    q2 = 16 * (psi - 2 * c)**2 * (psi + c)
    R2 = q2 * rq(0, 2, 1000)                         # both sides of E's R^2 <= q^2
    # tau_i / a = 1 + 3|c|/(psi +- c) + |R|/(4 (psi +- c)^(3/2))
    # W1 (S): tau_S/a <= (2 psi - c + 3|c|)/(psi + c)  <=>  |R|/(4 (psi + c)^(3/2)) <= (psi - 2c)/(psi + c)
    #         (both sides >= 0; compare squares)        <=>  R^2 <= 16 (psi - 2c)^2 (psi + c)
    w1s = R2 / (16 * (psi + c)**3) <= (psi - 2 * c)**2 / (psi + c)**2
    g.check(w1s == (R2 <= q2), "W1 (S) holds exactly on E's R^2 <= 16 (psi - 2c)^2 (psi + c)")
    if R2 > q2:
        continue
    # W1 (M): tau_M/a <= 4 follows from 3|c|/(psi - c) + (psi - 2c) sqrt(psi + c)/(psi - c)^(3/2) <= 3
    rhs = 3 - 3 * abs(c) / (psi - c)
    g.check(rhs >= 0 and (psi - 2 * c)**2 * (psi + c) / (psi - c)**3 <= rhs**2, "W1 (M): tau_M <= 4a on E")
    # (C8): 2 psi - c + 3|c| <= 6 psi, and in raw jets 6 psi/(psi + c) = 144 lambda/a_S <= 3 A_*/a_S
    g.check(2 * psi - c + 3 * abs(c) <= 6 * psi, "2 psi - c + 3|c| <= 6 psi")
    gam = rq_pos(F(1, 10), 3)
    lam = psi * gam**2 / 24
    Lam = lam + rq(0, 2)
    As = 48 * Lam
    aS = gam**2 * (psi + c)
    g.check(6 * psi / (psi + c) == 144 * lam / aS and 144 * lam / aS <= 3 * As / aS, "6 psi/(psi + c) = 144 lambda/a_S <= 3 A_*/a_S")
    # m_S = 2/(125 tau_S^2) with tau_S <= 3 a A_*/a_S and a^2 = 4/27: m_S >= 3 a_S^2/(250 A_*^2)
    tauS_bound_sq = 9 * F(4, 27) * As**2 / aS**2
    cst = F(3, cst_den) / As**2
    g.check(2 / (125 * tauS_bound_sq) == cst * aS**2, "m_S >= c_* a_S^2 with c_* = 3/(250 A_*^2)")
    g.check(aS <= As and cst * aS**2 <= F(3, 250) < F(27, 512), "c_* a_S^2 <= 3/250 < 27/512 <= e_M")
g.check(1 / (8 * 16 * F(4, 27)) == F(27, 512), "tau_M <= 4a gives 1/(8 tau_M^2) >= 27/512")
g.close()

# =====================================================================
# Y3  (C9)-(C10): the split at a_S = d and the choice d = sqrt(eps)
# =====================================================================
g = Group("Y3 (C9)-(C10) local tolerance split")
for _ in range(4000):
    As = rq_pos(1, 50)
    r = rq_pos(F(1, 10000), F(1, 10), 10000)
    sq = rq_pos(F(1, 1000), 1, 1000)               # d = sqrt(eps), rational
    eps, d = sq * sq, sq
    if not d < As:
        continue
    away = (1 / d**2 - 1 / As**2) / 2 + r * (1 / d**3 - 1 / As**3) / 3   # int_d^A (s^-3 + r s^-4) ds
    g.check(0 < away <= 1 / (2 * d**2) + r / (3 * d**3), "(C10) int_d^A_* (s^-3 + r s^-4) ds <= d^-2/2 + r d^-3/3")
    total = d**2 + r * d + eps**2 * (1 / (2 * d**2) + r / (3 * d**3))
    g.check(total == F(3, 2) * eps + F(4, 3) * r * sq, "(C10) at d = sqrt(eps): (3/2) eps + (4/3) r sqrt(eps)")
    # squared Markov on a_S >= d: K0 N e >= c_* a_S^2/2  =>  1 <= (eps N / a_S^2)^2 with eps = 2 K0 e / c_*
    K0, N, e, cst = F(167, 192), rq_pos(1, 9), rq_pos(F(1, 1000), 1, 1000), rq_pos(F(1, 1000), 1, 1000)
    aS = rq_pos(F(1, 100), 5)
    eps2 = 2 * K0 * e / cst
    if K0 * N * e >= cst * aS**2 / 2:
        g.check((eps2 * N / aS**2)**2 >= 1, "squared Markov factor eps^2 N^2 a_S^-4 >= 1 on the bad event")
g.close()

# =====================================================================
# Y4  (C11)-(C13): the band Jacobian and the cancellation of the chart poles
# =====================================================================
g = Group("Y4 (C12)-(C13) band Jacobian")
jac = F(1, 12) if MUT == "JAC_12" else F(1, 24)
for _ in range(4000):
    gam, B1, C3 = rq(-4, 4), rq(-4, 4), rq(-4, 4)
    if gam == 0:
        continue
    D, J = gam**2 - 12 * B1, 8 * gam**3 - 144 * B1 * gam + 576 * C3
    c, R = D / gam**2, J / gam**3
    lam1, lam2 = rq(0, 3), rq(0, 3)
    psi1, psi2 = 24 * lam1 / gam**2, 24 * lam2 / gam**2
    if psi1 != psi2:
        g.check((lam2 - lam1) / (psi2 - psi1) == jac * gam**2, "(C12) d lambda = (gamma^2/24) d psi")
    psi = psi1
    aM, aS = gam**2 * (psi - c), gam**2 * (psi + c)
    g.check(aM * aS / 16 * jac * gam**2 == gam**6 * (psi**2 - c**2) / 384, "(C12) w_lambda d lambda = (gamma^6/384)(psi^2 - c^2) d psi")
    g.check(gam**6 * abs(c)**3 == abs(D)**3 and gam**6 * R**2 == J**2, "(C13) gamma^6 |c|^3 = |D|^3, gamma^6 R^2 = J^2")
g.close()

# =====================================================================
# Y5  (C14): the decomposition of {E0 >= eta}
# =====================================================================
g = Group("Y5 (C14) random tolerance decomposition")
for _ in range(6000):
    v, d, E0 = rq_pos(F(1, 100), 1), rq_pos(F(1, 100), F(1, 4)), rq(0, 2)
    mu = None if RNG.random() < 0.2 else -rq_pos(F(1, 1000), 2)       # mu < 0 on E; None is -infinity
    eta = v / 2 if mu is None else min(v, -mu) / 2
    if E0 >= eta:
        cover = E0 >= v / 2 or (mu is not None and -2 * d <= mu < 0) or E0 >= d
        g.check(cover, "{E0 >= eta} lies in {E0 >= v/2} u {-2d <= mu < 0} u {E0 >= d}")
g.close()

# =====================================================================
# Y6  (C16)-(C18): the exponent ledger at w = r^(-1/16), d = r^(1/2), p = 2
# =====================================================================
g = Group("Y6 (C16)-(C18) ledger")
bw, bd = F(1, 16), F(1, 2)
p = 1 if MUT == "LEDGER_P1" else 2
e_exp = 1 - 4 * bw                                                  # e = r w^4
terms = [8 * bw, 1 + 4 * bw, e_exp, 1 + e_exp / 2, bd, F(1), p * (e_exp - bd), 2 - 4 * bw]
g.check(terms[:6] + [terms[7]] == [F(1, 2), F(5, 4), F(3, 4), F(11, 8), F(1, 2), F(1), F(7, 4)], "the listed powers")
g.check(min(terms) == F(1, 2) and 3 + min(terms) == F(7, 2), "(C18) Q_r^W(E minus Good) <= C r^(7/2)")
for w in [F(k, 2) for k in range(6, 200)]:
    g.check(w - F(3, 2) >= w / 2, "rho = w - 3/2 >= w/2 for w >= 3")
g.check(1 - bw > 0 and e_exp > 0 and bd > 0, "2 r w -> 0, r w^4 -> 0, d -> 0")
g.close()

# =====================================================================
# Y7  (C19): the positive interior witness of E
# =====================================================================
g = Group("Y7 (C19) witness")
for Lam in [F(k, 7) for k in range(1, 60)]:
    lam, gam, B1 = Lam / 2, F(1), (1 + 6 * Lam) / 12
    C3 = -(8 * gam**3 - 144 * B1 * gam) / 576                       # J = 0
    D, J = gam**2 - 12 * B1, 8 * gam**3 - 144 * B1 * gam + 576 * C3
    psi, c, R = 24 * lam / gam**2, D / gam**2, J / gam**3
    g.check(psi == 12 * Lam and c == -6 * Lam and R == 0, "psi = 12 Lambda, c = -6 Lambda, R = 0")
    g.check(24 * lam - D > 0 and 24 * lam + D > 0 and psi > 2 * c and R**2 < 16 * (psi - 2 * c)**2 * (psi + c), "strict T, psi > 2c, R^2 < q^2")
    g.check(R**2 + 64 * c * (psi**2 - c**2) < 0, "discriminant factor < 0: no extra critical point")
    for _ in range(30):                                              # a small neighbourhood stays inside E
        dl, dg, db, dc = (rq(-Lam / 100, Lam / 100, 9700) for _ in range(4))
        l2, g2, b2, c2 = lam + dl, gam + dg / 10, B1 + db, C3 + dc
        D2, J2 = g2**2 - 12 * b2, 8 * g2**3 - 144 * b2 * g2 + 576 * c2
        p2, cc2, R2 = 24 * l2 / g2**2, D2 / g2**2, J2 / g2**3
        g.check(24 * l2 - D2 > 0 and 24 * l2 + D2 > 0 and p2 > 2 * cc2 and R2**2 + 64 * cc2 * (p2**2 - cc2**2) < 0,
                "a neighbourhood: typed, psi > 2c, no extra critical point")
g.close()

# =====================================================================
# Y8  section 6: C90's repairs to A2 (Lemma 7(b) constants, Corollary 9(c) integral)
# =====================================================================
g = Group("Y8 section 6 repaired constants")
a0, b0, k0 = F(599, 250), F(277, 250), F(256, 125)
K = b0 + k0 * a0
w0 = a0 / K
g.check(K == F(187969, 31250) and w0 == F(74875, 187969), "K = 187969/31250, omega0 = 74875/187969")
g.check(K < (F(6) if MUT == "K_SIX" else F(605, 100)), "K < 6.05")
g.check(1 - k0 * w0 > 0 and b0 / (1 - k0 * w0) == K, "b0/(1 - k0 omega0) = K at omega0, denominator positive")
for k in range(1, 400):
    om = w0 * F(k, 400)
    g.check(0 < 1 - k0 * om and b0 / (1 - k0 * om) <= K, "0 < omega <= omega0: b0/(1 - k0 omega) <= K")
    om2 = w0 * (1 + F(k, 40))
    g.check(a0 / om2 <= K, "omega >= omega0: a0/omega <= K")
for _ in range(2000):
    cc, x = rq(-3, 3), rq(0, 6)
    integral = (x**3 / 3 - cc**2 * x) - (abs(cc)**3 / 3 - cc**2 * abs(cc)) if x > abs(cc) else F(0)
    target = x**3 / 3 - cc**2 * x + 2 * abs(cc)**3 / 3 if x > abs(cc) else F(0)
    g.check(integral == target, "Corollary 9(c): int_|c|^x (psi^2 - c^2) d psi = x^3/3 - c^2 x + 2|c|^3/3")
g.close()

# ---------------------------------------------------------------------
total = sum(t for _, _, t in RESULTS)
passed = sum(p_ for _, p_, _ in RESULTS)
for name, p_, t in RESULTS:
    print("%-46s %6d/%-6d %s" % (name, p_, t, "PASS" if p_ == t else "FAIL"))
print("mutant: %s" % (MUT if MUT else "none"))
print("total checks: %d; failures: %d" % (total, total - passed))
for f_ in FAILS:
    print("  FAIL " + f_)
sys.exit(0 if passed == total else 1)
```

```text
Y0 (C3) raw-to-cubic map                         5980/5980   PASS
Y1 (C6)-(C7) radius tail                        10152/10152  PASS
Y2 (C8) tolerance floor                         21332/21332  PASS
Y3 (C9)-(C10) local tolerance split             10361/10361  PASS
Y4 (C12)-(C13) band Jacobian                    11984/11984  PASS
Y5 (C14) random tolerance decomposition          5337/5337   PASS
Y6 (C16)-(C18) ledger                             197/197    PASS
Y7 (C19) witness                                 1947/1947   PASS
Y8 section 6 repaired constants                  2801/2801   PASS
mutant: none
total checks: 70091; failures: 0
```

🤖 Generated with [Claude Code](https://claude.com/claude-code)


---
_Generated by [Claude Code](https://claude.ai/code)_
