<!-- Math- #244 comment 5957180884, 2026-10-02T16:55:46Z; copied verbatim from the GitHub API -->
PR244 Slice D — exact-source regression evidence for4167121714

Actual performers: OpenAI / Codex review_fractional_packet_reproducibility and disjoint test_dependency_presence_fix. Organizational-independence credit0; scientific effectNONE.

The original defect is reproduced, and the v1.1 repair passes the bounded tests. These execute unchanged dependency-gate Python extracted from the exact workflow, with real disposable Git trees and controlled read-only API replies. The independent review runner repeated the normal/optimized 30-case suite, the actual original/current comparison, and the single-guard negative control.

Results:
- 30/30 cases pass under normal and optimized Python; repeat runs are byte-identical per mode. Mode-labelled output differs only in the mode field.
- Exact v1 workflow59f52e89ba113240d6da255ec37edd04b0cecec0 accepts deleted and renamed merged-source fixtures through the historical API. Exact v1.1 workflowda14cfb6e93f7aeea3195a9fccd6fd720b17c8a8 rejects both before historical retrieval. Both accept the pinned tracked source and reject a changed tracked source.
- Merged changed/symlink/untracked/directory/executable-mode/worktree-drift cases reject. Open unchanged-source head advancement accepts, changed-source drift and closed-unmerged status reject. Already-merged consumed sources have no historical fallback.
- Removing only the new merged-presence guard makes the suite fail on merged_deleted_historical_still_available: the deleted source is wrongly accepted through the still-available historical API.

Limits: Python3.12.14 locally, versus the workflow's3.11.16; dependency-gate lines39–141 only. This is not a live Actions/API/permissions test, does not cover every GitHub symlink-API semantic, and does not prove automatic rerun freshness after a dependency changes. cited_unmerged intentionally remains historical-only. The numerical checker and final git-diff shell command are separate. No author-branch edits or merge occurred.

To reproduce, save the exact [v1.1 workflow](https://github.com/d6g8k5htny-coder/Math-/blob/446ea03d555968557136e9f7f569d6c56359bd76/.github/workflows/soft-closed-form.yml) as workflow.exact.yml and the exact [v1 workflow](https://github.com/d6g8k5htny-coder/Math-/blob/1781c0fd37469a0840f3c768d2b505ef6319133e/.github/workflows/soft-closed-form.yml) as workflow.v1.exact.yml beside the two scripts below. The harness refuses different workflow blobs.

Run:
```sh
python -B -S test_dependency_presence.py > results.normal.json
python -B -O -S test_dependency_presence.py > results.optimized.json
python -B -S compare_actual_v1.py > actual-v1-regression.normal.json
python -B -O -S compare_actual_v1.py > actual-v1-regression.optimized.json
python -B -S test_dependency_presence.py --remove-merged-presence-guard
# Last command must fail with exit1 at the deleted-merged-source fixture.
```

SHA256:
- test_dependency_presence.py: f1508b994bc48b19a74d6f2415fa3e578b021bcdfc96f20d462ef0a255f6b085
- compare_actual_v1.py: 800d7b168bc82f768db2c50abed7c68f46fed551b1d92036ba9488e126d91f10
- results.normal.json: db529277ab6d0657bbf37791be75c250a592973efd0c38ca93b5563efa3d00b7
- results.optimized.json: 1c57022a0dba018d8ca8780c56cd65f49367f0144f7515a2035f92c7ac868358
- actual-v1-regression.normal.json: c50f386c1efb0c2cdc2fd1bf7c9a30973b214cb96c820d4109e44d8e3d4d683e
- actual-v1-regression.optimized.json: 682abef35f35f130041a2440d95d2a6ac76b2c28b17057446edaecbce92bc361

<details><summary>test_dependency_presence.py (complete)</summary>

```python
#!/usr/bin/env python3
"""Bounded offline tests of the exact PR244 dependency gate, not its checker.

Runs unchanged workflow Python through its dependency loop (lines 39-141), with
real disposable Git commits/worktrees, a synthetic packet and synthetic dependency
bytes, and an allowlisted in-memory replacement for urllib.request.urlopen.
No network requests or repository-author-branch changes are made.
"""
import base64
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import urllib.error
import urllib.request

HERE = Path(__file__).resolve().parent
SOURCE = HERE / 'workflow.exact.yml'
EXPECTED_SOURCE_BLOB = 'da14cfb6e93f7aeea3195a9fccd6fd720b17c8a8'
REPO = 'fixture-owner/fixture-repo'
API = 'https://api.github.com/repos/' + REPO
DEP_PATH = 'frontiers/soft_rejected_pairs_20261002/PROOF.md'
HEAD = '1' * 40
ADVANCED_HEAD = '2' * 40
MERGE = '3' * 40
PINNED = b'fixture source: pinned version\n'
CHANGED = b'fixture source: changed version\n'


def blob_sha(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def entry_for(data=PINNED):
    return {'path': DEP_PATH, 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest(), 'git_blob': blob_sha(data),
            'head': HEAD, 'pr': 'Math- #242'}


def git(root, *args):
    return subprocess.run(['git', *args], cwd=root, check=True,
                          capture_output=True, text=True).stdout


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


def require(condition, detail):
    # The harness must retain its assertions when testing with Python -O.
    if not condition:
        raise AssertionError(detail)


source_data = SOURCE.read_bytes()
require(blob_sha(source_data) == EXPECTED_SOURCE_BLOB, 'wrong source version')
source_text = source_data.decode()
begin = source_text.index('          import base64, hashlib, json, os, pathlib, subprocess, sys, urllib.parse, urllib.request\n')
end = source_text.index("          script = str(root / 'closed_form_check.py')\n", begin)
prefix = ''.join(line[10:] for line in source_text[begin:end].splitlines(keepends=True))
require(prefix.endswith("'dependency_merged': merged}))\n"), 'unexpected extraction boundary')
mutation = '--remove-merged-presence-guard' in sys.argv
if mutation:
    guard = "        if merged and landed is None:\n            raise ValueError('dependency ' + entry['pr'] + ' has merged but its pinned source is absent from this '\n                             'tree: ' + entry['path'])\n"
    require(prefix.count(guard) == 1, 'negative-control guard not unique')
    prefix = prefix.replace(guard, '\n' * guard.count('\n'))
# Preserve original YAML line numbering for any raised exception.
original_start_line = source_text[:begin].count('\n') + 1
compiled = compile('\n' * (original_start_line - 1) + prefix, str(SOURCE), 'exec')

# Expected values are observed behavior contracts; tests marked "limitation"
# intentionally demonstrate stated boundaries rather than additional guarantees.
CASES = [
    dict(name='merged_pinned_tracked', state='merged', local='pinned', accept=True, calls=2),
    dict(name='merged_deleted_historical_still_available', state='merged', local='deleted', error='has merged but its pinned source is absent', calls=2),
    dict(name='merged_renamed_historical_still_available', state='merged', local='renamed', error='has merged but its pinned source is absent', calls=2),
    dict(name='merged_committed_changed', state='merged', local='changed', error='not the recorded regular-file blob', calls=2),
    dict(name='merged_worktree_changed', state='merged', local='worktree_changed', error='source differs from its pinned blob', calls=2),
    dict(name='merged_tracked_symlink', state='merged', local='symlink', error='not the recorded regular-file blob', calls=2),
    dict(name='merged_worktree_symlink', state='merged', local='worktree_symlink', error='checkout path is not a regular file', calls=2),
    dict(name='merged_untracked_lookalike', state='merged', local='untracked', error='has merged but its pinned source is absent', calls=2),
    dict(name='merged_directory_at_path', state='merged', local='directory', error='not the recorded regular-file blob', calls=2),
    dict(name='merged_executable_at_path', state='merged', local='executable', error='not the recorded regular-file blob', calls=2),
    dict(name='merged_worktree_deleted', state='merged', local='worktree_deleted', error='checkout path is not a regular file', calls=2),
    dict(name='merged_merge_commit_drift', state='merged', local='pinned', current_node='changed', error='is not the pinned blob', calls=2),
    dict(name='merged_api_unavailable_fails_closed', state='merged', local='pinned', api_error='pull', error='HTTP Error 503', calls=1),
    dict(name='open_absent_bound_historical', state='open', local='deleted', accept=True, calls=5),
    dict(name='open_advanced_head_same_blob', state='open_advanced', local='deleted', accept=True, calls=5),
    dict(name='open_advanced_head_changed_blob', state='open_advanced', local='deleted', current_node='changed', error='is not the pinned blob', calls=2),
    dict(name='open_pinned_tracked', state='open', local='pinned', accept=True, calls=2),
    dict(name='open_untracked_lookalike', state='open', local='untracked', error='path present in the checkout but not as a tracked blob', calls=2),
    dict(name='open_untracked_broken_symlink', state='open', local='untracked_broken_symlink', error='path present in the checkout but not as a tracked blob', calls=2),
    dict(name='open_tracked_symlink', state='open', local='symlink', error='not the recorded regular-file blob', calls=2),
    dict(name='open_committed_changed', state='open', local='changed', error='not the recorded regular-file blob', calls=2),
    dict(name='closed_unmerged', state='closed', local='deleted', error='closed without merge', calls=1),
    dict(name='open_historical_head_mismatch', state='open', local='deleted', historical='head_mismatch', error='recorded head does not resolve', calls=3),
    dict(name='open_historical_path_mismatch', state='open', local='deleted', historical='path_mismatch', error='does not map to the recorded blob', calls=4),
    dict(name='open_historical_symlink_node', state='open', local='deleted', historical='symlink', error='does not map to the recorded blob', calls=4),
    dict(name='open_historical_bytes_mismatch', state='open', local='deleted', historical='bytes_mismatch', error='source differs from its pinned blob', calls=5),
    dict(name='open_historical_encoding_invalid', state='open', local='deleted', historical='encoding_invalid', error='unexpected blob encoding', calls=5),
    dict(name='always_merged_consumed_pinned', state='merged', kind='consumed', local='pinned', accept=True, calls=0),
    dict(name='always_merged_consumed_absent', state='merged', kind='consumed', local='deleted', error='merged source drifted or absent', calls=0),
    dict(name='cited_unmerged_historical_only', state='closed', kind='cited_unmerged', local='deleted', accept=True, calls=3, limitation=True),
]


def run_case(case, require_no_merged_history=True):
    with tempfile.TemporaryDirectory(prefix=case['name'] + '-', dir=HERE / 'tmp') as temp:
        root = Path(temp)
        git(root, 'init', '-q')
        git(root, 'config', 'user.name', 'Offline Review Fixture')
        git(root, 'config', 'user.email', 'fixture@example.invalid')
        packet = root / 'frontiers/soft_closed_form_20261002'
        payload = b'offline packet placeholder\n'
        packet_entry = {'path': 'placeholder.txt', 'bytes': len(payload),
                        'sha256': hashlib.sha256(payload).hexdigest()}
        manifest = {'files': [packet_entry], 'consumed': [], 'cited_only': [],
                    'consumed_unmerged': [], 'cited_unmerged': []}
        manifest[case.get('kind', 'consumed_unmerged')].append(entry_for())
        write(packet / 'placeholder.txt', payload)
        write(packet / 'SOURCES.json', json.dumps(manifest).encode())
        path = root / DEP_PATH
        local = case['local']
        if local in ('pinned', 'worktree_changed', 'worktree_deleted', 'worktree_symlink', 'executable'):
            write(path, PINNED)
            if local == 'executable':
                path.chmod(0o755)
        elif local == 'changed':
            write(path, CHANGED)
        elif local == 'renamed':
            write(path.with_name('PROOF-renamed.md'), PINNED)
        elif local == 'symlink':
            write(path.with_name('source.md'), PINNED)
            path.symlink_to('source.md')
        elif local == 'directory':
            write(path / 'child.md', PINNED)
        git(root, 'add', '.')
        git(root, 'commit', '-qm', 'Bounded fixture')
        if local == 'untracked':
            write(path, PINNED)
        elif local == 'untracked_broken_symlink':
            path.parent.mkdir(parents=True, exist_ok=True)
            path.symlink_to('not-present.md')
        elif local == 'worktree_changed':
            write(path, CHANGED)
        elif local == 'worktree_deleted':
            path.unlink()
        elif local == 'worktree_symlink':
            path.unlink()
            write(path.with_name('worktree-source.md'), PINNED)
            path.symlink_to('worktree-source.md')

        state = case['state']
        current_ref = MERGE if state == 'merged' else (ADVANCED_HEAD if state == 'open_advanced' else HEAD)
        pr = {'merged': state == 'merged', 'state': 'closed' if state in ('closed', 'merged') else 'open',
              'merge_commit_sha': MERGE if state == 'merged' else None, 'head': {'sha': current_ref}}
        node = {'type': 'file', 'path': DEP_PATH, 'sha': blob_sha(PINNED), 'size': len(PINNED)}
        current_node = dict(node)
        if case.get('current_node') == 'changed':
            current_node.update(sha=blob_sha(CHANGED), size=len(CHANGED))
        historical_node = dict(node)
        historical_head = HEAD
        historical_bytes = PINNED
        historical_encoding = 'base64'
        historical = case.get('historical')
        if historical == 'head_mismatch':
            historical_head = '4' * 40
        elif historical == 'path_mismatch':
            historical_node['path'] = 'wrong-path.md'
        elif historical == 'symlink':
            historical_node['type'] = 'symlink'
        elif historical == 'bytes_mismatch':
            historical_bytes = CHANGED
        elif historical == 'encoding_invalid':
            historical_encoding = 'invalid'
        calls = []
        content_reads = 0

        def urlopen(request, timeout):
            nonlocal content_reads
            url = request.full_url
            require(request.get_method() == 'GET', 'non-read request')
            require(timeout == 60, 'unexpected timeout')
            require(request.headers['Authorization'] == 'Bearer inert-offline-fixture-token', 'unexpected authorization')
            require(url.startswith(API + '/'), 'unexpected endpoint root')
            route = url[len(API):]
            calls.append(route)
            if route == '/pulls/242':
                if case.get('api_error') == 'pull':
                    raise urllib.error.HTTPError(url, 503, 'fixture unavailable', None, None)
                result = pr
            elif route == '/commits/' + HEAD:
                result = {'sha': historical_head}
            elif route == '/contents/' + DEP_PATH + '?ref=' + current_ref and not content_reads and case.get('kind', 'consumed_unmerged') == 'consumed_unmerged':
                result = current_node
                content_reads += 1
            elif route == '/contents/' + DEP_PATH + '?ref=' + HEAD:
                result = historical_node
            elif route == '/git/blobs/' + blob_sha(PINNED):
                result = {'encoding': historical_encoding, 'content': base64.b64encode(historical_bytes).decode()}
            else:
                raise AssertionError('Unexpected network endpoint: ' + route)
            return io.StringIO(json.dumps(result))

        old_urlopen = urllib.request.urlopen
        old_cwd = Path.cwd()
        old_env = dict(os.environ)
        output = io.StringIO()
        error = None
        try:
            urllib.request.urlopen = urlopen
            os.chdir(root)
            os.environ['GH_REPOSITORY'] = REPO
            os.environ['GH_TOKEN'] = 'inert-offline-fixture-token'
            with contextlib.redirect_stdout(output):
                exec(compiled, {'__name__': '__main__'})
        except Exception as exc:
            error = type(exc).__name__ + ': ' + str(exc)
        finally:
            urllib.request.urlopen = old_urlopen
            os.chdir(old_cwd)
            os.environ.clear()
            os.environ.update(old_env)
        accepted = error is None
        require(accepted == case.get('accept', False), (case['name'], error, calls))
        if not accepted:
            require(case['error'] in error, (case['name'], error))
        require(len(calls) == case['calls'], (case['name'], calls))
        # Crucially, the history is still mocked as available in every merged case,
        # but neither the old head nor its blob is ever requested.
        if state == 'merged' and require_no_merged_history:
            require(not any(route.startswith(('/commits/', '/git/blobs/')) for route in calls), (case['name'], calls))
        return {'case': case['name'], 'accepted': accepted, 'error': error,
                'api_calls': calls, 'stdout': output.getvalue().splitlines(),
                'head_tree_entry': git(root, 'ls-tree', 'HEAD', '--', DEP_PATH).strip(),
                'working_tree_status': git(root, 'status', '--porcelain').splitlines(),
                'explicit_limit': case.get('limitation', False), 'assertions_passed': True}


def main():
    (HERE / 'tmp').mkdir(exist_ok=True)
    results = [run_case(case) for case in CASES]
    report = {'source_git_blob': blob_sha(source_data),
              'source_sha256': hashlib.sha256(source_data).hexdigest(),
              'extracted_prefix_sha256': hashlib.sha256(prefix.encode()).hexdigest(),
              'extracted_source_lines': [original_start_line, original_start_line + prefix.count('\n') - 1],
              'python': sys.version.split()[0], 'mode': 'optimized' if sys.flags.optimize else 'normal',
              'mutation': mutation,
              'git': subprocess.run(['git', '--version'], capture_output=True, text=True, check=True).stdout.strip(),
              'count': len(results), 'passed': len(results), 'cases': results}
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
```
</details>

<details><summary>compare_actual_v1.py (complete)</summary>

```python
#!/usr/bin/env python3
"""Run the same Git/API fixtures through actual original and corrected source."""
import hashlib
import json
from pathlib import Path
import sys

import test_dependency_presence as harness

HERE = Path(__file__).resolve().parent
OLD_SOURCE = HERE / 'workflow.v1.exact.yml'
old_bytes = OLD_SOURCE.read_bytes()
harness.require(harness.blob_sha(old_bytes) == '59f52e89ba113240d6da255ec37edd04b0cecec0', 'wrong original source')
text = old_bytes.decode()
begin = text.index('          import base64, hashlib, json, os, pathlib, subprocess, sys, urllib.parse, urllib.request\n')
end = text.index("          script = str(root / 'closed_form_check.py')\n", begin)
prefix = ''.join(line[10:] for line in text[begin:end].splitlines(keepends=True))
line = text[:begin].count('\n') + 1
old_code = compile('\n' * (line - 1) + prefix, str(OLD_SOURCE), 'exec')
new_code = harness.compiled
results = []
for name in ['merged_pinned_tracked', 'merged_deleted_historical_still_available',
             'merged_renamed_historical_still_available', 'merged_committed_changed']:
    base = next(c.copy() for c in harness.CASES if c['name'] == name)
    original = base.copy()
    if base['local'] in ('deleted', 'renamed'):
        original.update(accept=True, calls=5)
        del original['error']
    elif base['local'] == 'changed':
        original['calls'] = 0
    harness.compiled = old_code
    before = harness.run_case(original, require_no_merged_history=False)
    harness.compiled = new_code
    after = harness.run_case(base)
    if base['local'] in ('deleted', 'renamed'):
        harness.require(before['accepted'] and not after['accepted'], 'real regression not reproduced')
        harness.require(any(c.startswith('/git/blobs/') for c in before['api_calls']), 'v1 history not exercised')
        harness.require(not any(c.startswith('/git/blobs/') for c in after['api_calls']), 'corrected history reached')
    results.append({'case': name, 'original_v1': before, 'corrected_v1_1': after})
print(json.dumps({'original_source_blob': harness.blob_sha(old_bytes),
                  'original_source_sha256': hashlib.sha256(old_bytes).hexdigest(),
                  'original_source_lines': [line, line + prefix.count('\n') - 1],
                  'corrected_source_blob': harness.blob_sha(harness.source_data),
                  'mode': 'optimized' if sys.flags.optimize else 'normal',
                  'python': sys.version.split()[0], 'compared_cases': len(results),
                  'verified_regressions': 2, 'results': results}, indent=2, sort_keys=True))
```
</details>
