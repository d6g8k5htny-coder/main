<!-- Math- #244 review 5395107094, 2026-10-02T18:04:31Z at a6eb508; copied verbatim from the GitHub API -->
## PR244 v1.2 — original Slice D findings resolved

**PASS_TECHNICAL_SCOPED / ACCEPT for this affected delta.** OA-244-D-01, D-02 and D-03 are resolved at head `a6eb5085c8e82468e3c65befa56e2c9eb5886322`. No new D-scope finding.

Actual performer: OpenAI / Codex review_fractional_packet_reproducibility, returning to [review5394484567](https://github.com/d6g8k5htny-coder/Math-/pull/244#pullrequestreview-5394484567). Organizational-independence credit 0; Dylan personal reading PENDING; scientific effect NONE. This is a post-cut successor readback, not a replacement for the historical audit pin, a fresh whole-packet acceptance, or an integration vote.

### Exact identities

- Previous head `446ea03d555968557136e9f7f569d6c56359bd76`, PROOF `e0aff5ad5bb757eb759b64e5ba746e8491250391`
- Successor PROOF `c69f92b1076399fb9f8917bb273e15348b0a497e`, 58,898 bytes, SHA256 `dd9b436a58d5d58f706ca59ddcf3eb31519866ea9e0a854e168036a8c21e1eaf`
- Checker `4050199c769453feff5481fa626ffb68771e17e1`; RESULTS `d64fe8686a0db53f58db3a761611d0fb245e1f02`; SOURCES `830ff9d98939096ab9329b1a1cc5197b8cf24f76`

All four packet files matched the successor manifest's byte counts and SHA256 values.

### Findings and fresh execution

1. **D-01 resolved.** Checker output, RESULTS and manifest agree on `CL-SOFT-CLOSED-FORM-20261002-v1.2`. Comparing parsed old/new RESULTS found exactly the new object and `C3.Delta_curve` entry, with no other value changes.

2. **D-02 resolved.** The C5 row now describes the two actual rejection branches. A fresh reconstruction of all 400 seeded rational samples again found exactly the two original non-chain cases, `(t,chi0,psi)=(5/9,-35,167/360)` and `(5/8,-104/11,1023/2000)`. Both reject through `psi<2c'`; all 400 reject. The code's unchanged branch logic and the corrected prose agree.

3. **D-03 resolved.** The checker summary and §7 now identify floating-point branches C2, C4, C6, C7, C8 and C9. In particular the off-zero-set C4 samples and decimal C9 cases are no longer presented as exact rational checks.

Fresh `python -B -S` and `python -B -O -S` runs reproduced RESULTS byte-for-byte. All 18 M1–M9 mode-runs exited 1 and isolated their mapped control; both M99 runs exited 2. A local derivative with only `rho = cp / psi` changed to `rho = cp / psi + Fr(1,1000)` exited 1 with only C3 false in both modes. This confirms the added C3 branch is actually exercised; it is a finite diagnostic, not proof of the cited lemma.

Exact function-source comparison found only existing `control_C3` and `main` changed, with the new `delta_fibre` helper. All other controls are preserved. PROOF §§2, 4 and 5 are byte-identical to v1.1; §3 is identical after removing the inserted Remark A.1′. In particular this readback does not upgrade the unchanged numerical evidence to certified bounds or raw-archive reproduction.

### Rebinding and cited-lemma custody

The fetched #242 successor `ee56652e1b30f2bfbb476da269fab15eb24cecba` / proof `271412dbc96a29590f5f805258e15c9e335cb430` and cited #243 successor `3a188bef39f5eca6fbb7c0cc43be86a52140895c` / proof `6502cf7ba2edee47761e40308c15b7563b06d1f8` match their recorded bytes, SHA256 and Git blobs. The #242 consumed §§0–3 block is exactly unchanged: 43,505 bytes, SHA256 `7548a21d71929bed22629021b9d22e83ee1396644e270182a7bd17640371c73d`. The target tree retains the same regular-file #170/[CUB] source blobs.

I read the actual [full-Delta lemma5957328502](https://github.com/d6g8k5htny-coder/Math-/pull/244#issuecomment-5957328502), [interface note5957339141](https://github.com/d6g8k5htny-coder/Math-/pull/244#issuecomment-5957339141) and [separate review5957356693](https://github.com/d6g8k5htny-coder/Math-/pull/244#issuecomment-5957356693). Remark A.1′ faithfully transcribes their normalization, sign choice, maximin criterion, integral and separate c'=0 case. It preserves the two-saddle tie and the distinction between a death-level mark and a convention-independent unique partner. Attribution identifies it as a cited lemma using [CUB](C3)–(C4). Its existing author/reviewer lineage remains controlling: this is transcription/interface custody, **not another independent proof acceptance**.

### Workflow and boundary

The workflow is unchanged at blob `da14cfb6e93f7aeea3195a9fccd6fd720b17c8a8`; the prior source-presence fixture evidence remains attached to those exact bytes. All four successor head-associated checks report success. The [exact-controls log](https://github.com/d6g8k5htny-coder/Math-/actions/runs/37042262049/job/110954997327) records test merge `0efdc15` of a6eb508 into `2d8616e`, CPython 3.11.16, #242 bound at ee56652/271412db as open, and the cited #243 at 3a188be/6502cf7b. Local fresh runs used Python 3.12.14.

Claim5958217025 is complete and will be explicitly released. No source ref was changed during the author's announced pause; no readiness, merge or overall-integration claim is made. #242-first integration and a fresh current-state gate check remain required. The old D findings and all historical pins remain preserved.
