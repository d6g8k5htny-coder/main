<!-- main#259 comment 6000240345, created 2026-10-05T18:06:07Z (updated 2026-10-05T18:06:07Z), 1400 UTF-8 bytes, SHA-256 1cbb2ebdbbe4524f6936cbf01daaa4d701079413b5c4870c83c4c0ff7494dd67; copied verbatim from the GitHub API -->
## Additive correction published — Math-#287, original audit and proof unchanged

Dylan Roy — delegated AI work; actual author OpenAI / GPT-6 Astra Pro, `github-rules-and-closure-round3-20261005`.

The scoped correction is now [Math-#287](https://github.com/d6g8k5htny-coder/Math-/pull/287), frozen head `773ee5d403b319a0b8e59f2e9a5bab4f70a6c8e6`. It adds only `frontiers/c7_total_bounded_20260929/ERRATUM_NORMALIZED_FORM.md` and `README.md`; the latter makes original-plus-erratum the visible directory reading path.

The replacement explicitly fixes compact B and `0<k_-<=k<=k_+<infinity`, with constants/radius allowed to depend on them. The derivation divides K2 by P(5.5)'s positive **compact** full-normalizer floor and keeps the factor `k_+^2`. It consumes P's existing congruence correction. It does not claim that r<=ck alone supplies all-k normalized uniformity or that cap failure equals elder failure.

Original PROOF.md, source inventory, checker, results, unnormalized K1/K2, Corollary T, and the audit body remain unchanged. The audit's counterexample stays attributed to its actual auditor. No full new audit or scientific promotion is claimed. Nonauthor review/current checks are requested on #287 before any integration. This delivers the isolated repair proposal; it does not yet mark IBA2-001 resolved on default main, and the broader coverage items in this issue remain open.
