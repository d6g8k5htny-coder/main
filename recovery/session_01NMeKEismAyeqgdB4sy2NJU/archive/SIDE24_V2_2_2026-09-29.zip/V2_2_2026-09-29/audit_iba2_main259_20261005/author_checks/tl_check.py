# Exploration checks (sympy) for the main#259 IBA2-009 reply; not a repository control.
import sympy as sp
r, l, k0, a, y, A = sp.symbols('r ell k0 a y A', positive=True)
kap = l/r**4          # kappa = ell / r^4
k = l/r**3            # k = ell / r^3 = kappa * r
assert sp.simplify(k - kap*r) == 0
# 1. relative error k^a on a kernel of size 1/kappa: absolute k^a/kappa = ell^(a-1) r^(4-3a)
expr = sp.simplify(k**a/kap)
print("k^a/kappa =", expr)
assert sp.simplify(expr - l**(a-1)*r**(4-3*a)) == 0
# integrate over the overlap r in [(ell/k0)^(1/3), ell^(1/4)] for a != 5/3
F = l**(a-1)*r**(5-3*a)/(5-3*a)
up = sp.simplify(F.subs(r, l**sp.Rational(1,4)))
lo = sp.simplify(F.subs(r, (l/k0)**sp.Rational(1,3)))
print("upper end:", sp.simplify(sp.powsimp(up, force=True)), " lower end:", sp.simplify(sp.powsimp(lo, force=True)))
# exponents of ell at both ends
eu = sp.simplify((a-1) + (5-3*a)/4); el = sp.simplify((a-1) + (5-3*a)/3)
print("exponent upper:", eu, " lower:", el)
assert sp.simplify(eu - (a+1)/4) == 0 and sp.simplify(el - sp.Rational(2,3)) == 0
print("o(ell^(1/2)) iff (a+1)/4 > 1/2 iff a > 1; a=1 gives", eu.subs(a,1), "; a=2 gives min(3/4, 2/3) = 2/3")
# a = 5/3: log case
I53 = sp.integrate(l**sp.Rational(2,3)*r**(-1), (r, (l/k0)**sp.Rational(1,3), l**sp.Rational(1,4)))
print("a=5/3:", sp.simplify(sp.expand_log(I53, force=True)))
# 2. Astra's profile H = k^2 psi(k^3/r): k^3/r = kappa*k^2 and H = (1/kappa) * y psi(y) with y = k^3/r
assert sp.simplify(k**3/r - kap*k**2) == 0
assert sp.simplify(k**2 - (1/kap)*(k**3/r)) == 0
# layer r ~ ell^(3/10): k ~ ell^(1/10), kappa ~ ell^(-1/5), kappa*k = k^2/r ~ 1/k
rl = l**sp.Rational(3,10)
print("layer: k =", sp.simplify(k.subs(r, rl)), " kappa =", sp.simplify(kap.subs(r, rl)), " kappa*k =", sp.simplify((kap*k).subs(r, rl)))
# 3. formal: (F0/kappa)*(12/25)k^2 = (12/25) F0 r k = (12/25) F0 kappa r^2  (Sol's p = 1)
F0 = sp.symbols('F0', positive=True)
t = (F0/kap)*sp.Rational(12,25)*k**2
assert sp.simplify(t - sp.Rational(12,25)*F0*r*k) == 0 and sp.simplify(t - sp.Rational(12,25)*F0*kap*r**2) == 0
# 4. absolute error r^2 + k^2 relative to 1/kappa: kappa r^2 + kappa k^2 = r k + k^3/r
assert sp.simplify(kap*(r**2 + k**2) - (r*k + k**3/r)) == 0
# 5. Remark 1 balance at rho_f = ell^(3/10): int_0^rho r^4/ell dr = int_rho^oo ell^2 r^-6 dr = ell^(1/2)/5
rho = sp.symbols('rho', positive=True)
f1 = sp.integrate(r**4/l, (r, 0, rho)); f2 = sp.integrate(l**2*r**-6, (r, rho, sp.oo))
print("fold family:", f1, " error tail:", f2)
print("at rho = ell^(3/10):", sp.simplify(f1.subs(rho, rl)), sp.simplify(f2.subs(rho, rl)))
sol = sp.solve(sp.Eq(f1, f2), rho); print("balance rho:", sol)
# 6. K2 region k >= k0: int_0^{(ell/k0)^(1/3)} r^4/ell dr
print("K2 region:", sp.simplify(sp.integrate(r**4/l, (r, 0, (l/k0)**sp.Rational(1,3)))))
# 7. Sol's criterion with p = 1 up to kappa1 = k0^(4/3) ell^(-1/3): ell^(1/4) kappa1^(1/4) -> 0
kap1 = kap.subs(r, (l/k0)**sp.Rational(1,3))
print("kappa1 =", sp.simplify(kap1), "; ell^(1/4) kappa1^(p-3/4) at p=1:", sp.simplify(l**sp.Rational(1,4)*kap1**sp.Rational(1,4)))
# 8. a fold-side relative error r^al k^-be: absolute r^(1+al) k^(-1-be); overlap exponent at the cusp end (kappa = 1)
al, be = sp.symbols('alpha beta', real=True)
G = sp.integrate(r**(1+al)*(l/r**3)**(-1-be), r)
print("fold-side relative r^alpha k^-beta, antiderivative:", sp.simplify(G))
ex = sp.simplify((-1-be) + (5+al+3*be)/4)
print("exponent at r = ell^(1/4):", ex, " -> o(ell^(1/2)) iff alpha - beta > 1")
