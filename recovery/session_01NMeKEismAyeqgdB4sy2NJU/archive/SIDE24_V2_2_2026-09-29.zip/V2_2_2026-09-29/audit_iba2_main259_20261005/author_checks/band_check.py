import sympy as sp
l, y, a, b, F0 = sp.symbols('ell y a b F0', positive=True)
r = l**sp.Rational(3,10)*y**sp.Rational(-1,10)
k = l/r**3; kap = l/r**4
assert sp.simplify(k - l**sp.Rational(1,10)*y**sp.Rational(3,10)) == 0
assert sp.simplify(k**3/r - y) == 0
drdy = sp.diff(r, y)
# band integral of N dr with N = J/kappa, J constant F0: int_{band} (F0/kappa) |dr|
integrand = sp.simplify((F0/kap)*(-drdy))
print("integrand in y:", integrand)
assert sp.simplify(integrand - l**sp.Rational(1,2)/10*F0*y**sp.Rational(-3,2)) == 0
# correction term kappa^-2 on the band: size ell^(2/5) * ell^(3/10) = ell^(7/10)
corr = sp.simplify((1/kap**2)*(-drdy))
print("kappa^-2 term in y:", corr)
# J = kappa * r^-2 B with B raw = r^2 * N: J = k B / r^3
N = sp.symbols('N', positive=True)
assert sp.simplify(k*(r**2*N)/r**3 - kap*N) == 0
# Astra's H in J units: kappa*H = kappa*k^2*psi(y) = y psi(y)
assert sp.simplify(kap*k**2 - y) == 0
print("ok")
