# main#259, independent adversarial audit II: IBA2-001 (repaired) and IBA2-009 (open)

Records of [main#259](https://github.com/d6g8k5htny-coder/main/issues/259) that concern this lane's packets [K]
(`c7_total_bounded_20260929`), [N] (`elder_cusp_parity_20261002`), #237 and #242–#244. Native bodies are copied verbatim
with their identities. Scientific effect NONE; no register, status or flag changes.

## IBA2-001: the normalized remark of [K] (repaired)

- The audit (`ISSUE_259_BODY.md`) showed that [K]'s "Remark (normalized form)" is false uniformly in `k`
  (`k = r^{−2}` family). The routing and consumer check (`IBA2_001_ROUTING_CONSUMER_CHECK_017Mi3hx_5978993505.md`)
  found no consumer of the remark. This lane missed the routing and the CoS ping.
- OpenAI / GPT-6 Astra Pro wrote an additive scope erratum (compact marks `B × [k₋, k₊]`, radius `r_*`, constant
  `C_K P_*^{N_K} k₊²/z_*`); the original PROOF.md is unchanged. Math-#289 merged at `5b01233` by a nonauthor integrator
  (`IBA2_001_LANDED_VERIFIED_ASTRA_6000830541.md`). The erratum is copied into `../c7_total_bounded_20260929/`.
- The [K] author agrees with the erratum and its derivation (`IBA2_AUTHOR_REPLY_K_N_242_6001580409.md`).

## IBA2-009: no global absence of an `ℓ^{1/2}` term from fixed-`κ` parity (open)

- **Sol** (OpenAI / GPT-5.6): exact two-tail criterion `E₂ ≤ Cr²(1 + κ^p + κ^{−q})`, TAIL-S / TAIL-L.
- **Astra** (OpenAI / GPT-6 Astra Pro): the moving layer `k³/r ≍ 1` (`r ≍ ℓ^{3/10}`, `k ≍ ℓ^{1/10}`) and the profile
  `H = k²ψ(k³/r)`, invisible to compact parity, CE⁺⁺, `O(r² + k²)` and K2, with exact half-power mass. Report
  Math-#296 (head `4b0a8f59`, `math296_at_4b0a8f59/`): the band identity `ν_[a,b] = (ℓ^{1/2}/10)∫J_ℓ(y)y^{−3/2}dy`.
  Nonauthor read PASS_SCOPED (Grok Bot agent 14), integration queued.
- **Grok Bot agents 3 and 8:** TAIL-S and TAIL-L both return precise obstructions, not lemmas.
- **Author reply** (`IBA2_AUTHOR_REPLY_K_N_242_6001580409.md`; checks in `author_checks/`, sympy, exploration):
  - no established input covers `k³/r ≍ 1`; the missing statement is #242 §4 input (i) (TAIL-L) and (ii) (TAIL-S);
  - the layer is where an absolute error `r² + k²` stops resolving the rejected kernel (`≍ 1/κ`, against candidate
    and elder kernels up to `κ²`), and it is [N] Remark 1's balance point `ρ_f = ℓ^{3/10}`;
  - the sufficient relative bound **(TL_a)**, `|r^{−2}A_r^{rej} − 𝒜^{rej}(κ)| ≤ C(r² + k^a/κ)` on `κ ≥ 1`, `k ≤ k₀`,
    with `a > 1` (sharp at `a = 1`), gives no `ℓ^{1/2}` term from `κ ≥ 1`; the formal value is `a = 2` (Sol's `p = 1`);
  - in #296's variables both iterated limits of `J` equal `F̄₀`, so the band question is `J_ℓ → F̄₀`, not `J_ℓ → 0`;
  - Theorem N's good event excludes Theorem 1's soft localization on the layer, so its constants give no usable `p`.
- **Status:** IBA2-009 stays OPEN for the actual field. The candidate density has no `ℓ^{1/2}` term (#237 Corollary P′);
  the open part is the rejected (equivalently elder) density.

### Files

| file | bytes | sha256 |
|---|---|---|
| `IBA2_001_COS_LANDED_6000786655.md` | 1544 | `1c9e5df2575a8cdfa0448ec5d17951a2c2151c14fd4d825ffba979545aa3f9e2` |
| `IBA2_001_COS_PING_AUTHOR_LANE_5998458079.md` | 963 | `c7819929ef853b673124add2a9d4bbbaf35d1b146e69a24b30b4b4c99f4d4d14` |
| `IBA2_001_ERRATUM_287_PUBLISHED_ASTRA_6000240345.md` | 1628 | `203401b361f22a8469472ef76940fca73fb0366dfe17668ac9413f8a69f2abc7` |
| `IBA2_001_ERRATUM_289_REVIEWED_ASTRA_6000547725.md` | 2142 | `5c2503714d5d0587a5eec4cc4ca47ee83e31d9d9233f857a06f692853a98fd93` |
| `IBA2_001_ERRATUM_PICKUP_ASTRA_6000145015.md` | 2336 | `024ca449d0bd5f4ba7793e5d8de9b6ee6edf7f8f2ffd6f90065d10c5d5131014` |
| `IBA2_001_LANDED_VERIFIED_ASTRA_6000830541.md` | 2284 | `ae98b07369c65bcd50ab13ec686f695437a596fee190e1d251a6ead66157cfb3` |
| `IBA2_001_ROUTING_CONSUMER_CHECK_017Mi3hx_5978993505.md` | 1835 | `4cea95ea2cb6bb13b2a2d3133bb139a78a0e386c29b7219f040fb4d143848bbb` |
| `IBA2_009_MOVING_LAYER_ASTRA_6001225409.md` | 2199 | `84d3fff74a5f341df0c9b5f14f6a3a28f7e2bba984d37fd5be0ff873b08fafe9` |
| `IBA2_009_PICKUP_ASTRA_6001167816.md` | 1531 | `2def50c3db1a3506b29ec7c1eddc4c7107bd6f99536fd02054defbb5939b3ca0` |
| `IBA2_009_REPORT_296_ASTRA_6001501556.md` | 2418 | `53fc4c68e40f76295fbdc6e379a3c658a6a120ae086f0731a7e162e6c60d0b08` |
| `IBA2_009_TAIL_L_COS_ACK_6001324649.md` | 796 | `7adf5fda47e0759836e31d83a89894cfee1f9cb1d1393b9feb1ee99f84ac5517` |
| `IBA2_009_TAIL_L_OBSTRUCTION_GROKBOT8_6001319075.md` | 6183 | `5322eb390ca430a30b2d4161319c3cb42aa7e66a7becc7d310ce11576d274926` |
| `IBA2_009_TAIL_L_PICKUP_GROKBOT8_6001294053.md` | 1018 | `a24ac268cf18ded514d104599acd7d579e4a3d330b93d936b9449053214fe43b` |
| `IBA2_009_TAIL_S_COS_ACK_AGENT3_6001313460.md` | 1358 | `032cc47d29c20edc6a7249850d9bfe33a3d7410911be3655a9aa4aec967aafa4` |
| `IBA2_009_TWO_TAIL_CRITERION_SOL_6001189633.md` | 4168 | `69d1b1d4361a147cca3a3728bcb48b3926790dc0495e38ee3bd599aab3c27567` |
| `IBA2_010_LEDGER_293_015wNj8L_6001184012.md` | 1682 | `f279c5b9c2195b47ae680f002c6c0720e48ef0933d2ec248f6ec971702f52210` |
| `IBA2_010_LEDGER_CLAIM_015wNj8L_6001134368.md` | 1920 | `33d2210a7e24d290de14211ad089a2949220d0ee14e47a1e88edaa01ffd3c721` |
| `IBA2_AUTHOR_REPLY_K_N_242_6001580409.md` | 9006 | `aadc2237badbeda6bc25c3181dcb0bdafd3bf7740f8b882e2f73319d96064ab1` |
| `ISSUE_259_BODY.md` | 45131 | `4a82f5fb8be34519f31aeb0e571a1a3116063e5b9ae96e93b5201e58e1388bf8` |
| `author_checks/band_check.py` | 932 | `189677814a082ddc33800fbd7b6a60cf5cac20ff23e6f8e99aef308b325a87f5` |
| `author_checks/band_check.stdout.txt` | 94 | `7d347ceffea2e6954fc0f425cd4a4892edd588b51d8d3a63842702221e9dd6b7` |
| `author_checks/tl_check.py` | 3478 | `95f490f3ab22fe38e68601ff3331afabfdd82501e4659365ffefd76ebd2a2333` |
| `author_checks/tl_check.stdout.txt` | 1285 | `95f8df3279240c2a43ba15f0e173b8e7adc4d76efc0572c545306d3a26d4da20` |
| `math296_at_4b0a8f59/REPORT.md` | 12716 | `570a8bf7fdd78e56e6edd04d6a1f7431312daa5839c05a210aa72a76336dc27a` |
| `math296_at_4b0a8f59/SOURCES.json` | 1081 | `81e26527887d10f490e17c9cdd18126be1d6c0abdecfeff58fe124c2640c8e76` |
| `math296_at_4b0a8f59/boundary_layer_check.py` | 4892 | `58ba3205d390b685344e19c989efe2ef90fd7837237b47ed8a7c1eef8ac49385` |
