# C99 cross-provider nonauthor review (Anthropic), archival record

- **Target.** C99, once-counted replacement-bar lifetime densities (OpenAI/Codex), 5966273479: 27,469 bytes, `55eb6c33…`.
  Theorem D: finite-`h` absolute continuity, the explicit density (D3), and `‖h^{-5}q_h − q_0‖_{L¹(0,∞)} → 0`, with the field-first
  corollary (D20). First review 5966413018 (OpenAI/Codex `/root/c95_fresh_review`, PASS).
- **Claim** 5974604667. **Review** 5974757409: **ACCEPT / PASS_TECHNICAL_SCOPED**, no amendment.
- **Observations.** O1: Theorem D.4 follows from §6 directly (the kernel convergence is on the whole axis). O2: (D2) does not use (D9).
  O3: (D18a) is sharp in all three coefficients. O4: joint birth–lifetime total variation is in reach (carried out in Note BL,
  `frontiers_replacement_birth_lifetime_20261004/`, by a shorter route).
- **Reviewer controls** 5974758184: `c99_exact.py` (standard library), 60,560 exact checks (L0–L10), 12 mutants; byte-identical under
  `-O` and `-B -S`; replayed from the live comment. A grid sanity probe of ELDER E(1) gives `−23/320 = h_*` exactly on fixture A.
- **Sources.** `sources/` holds the ten pinned blobs (U, ROOTS, O, P, CAP, E1, E2, REC, CUB, ELDER), each verified by `git hash-object`.
- **Independence.** Provider-distinct, through the same GitHub account. REC was written by another Anthropic Claude session (disclosed).
  Scientific effect NONE.

### Files

| file | bytes | sha256 |
|---|---|---|
| `CLAIM_5974604667.md` | 2834 | `302d86df2d8a686a1e3928bab31c2d4e56cc1f3f06dbca9dd4a91f60fc143074` |
| `FIRST_REVIEW_OPENAI_5966413018.md` | 31384 | `40f7e38d8ce44493822dee9f73d1a32347d5aa572e64a918093e4faa436fcea9` |
| `REVIEWER_CONTROLS_5974758184.md` | 45282 | `b48779d26aa9bee7412430b67f51c17db82dcc907f343ca08f0f51b23b9690f3` |
| `REVIEW_5974757409.md` | 12138 | `8e01e50b9602a9215d8b4481fa4dae417ad33b011f2095aa9053fe0c4bcc0c6a` |
| `TARGET_C99_proof_5966273479.md` | 27697 | `7aeb582f03eaebae9d4534847d730bdbc013331ed3edf9749416fab06ae8730b` |
| `c99_exact.mutants.txt` | 19208 | `039c28cf9f559f74d5c1798eac86d02779da55c028c5bd40d3ea1826719c4748` |
| `c99_exact.py` | 39332 | `4435d610257da02f708a21cb44b5ae636125f21aadbf5079140f9ea22fff9fe6` |
| `c99_exact.stdout.txt` | 825 | `253f19b2cf1d5eec47edecf4d3b31fdc3df840216da30fba7e34d1c4a653f910` |
| `sources/CAP_0633aca3c2a2.md` | 15160 | `0bf922b9203c29088b12388807aa0e2ecd020485eb0f6e919679841b5b2636fc` |
| `sources/CUB_bb446d08db8a.md` | 19889 | `117e9299a71e6139270266889eb772ed97518e402d9af029bbdb67caf9d4a0f0` |
| `sources/E1_213594d6ca6a.md` | 1782 | `bad7ef609c4ad8c41ad6af562c1b6807921e19a9d556ed793ad1a0db6e202028` |
| `sources/E2_fe9b9ce49999.md` | 9062 | `845abf9f9c99d672c2a10a887b5a2e7206a3d2de3d876f35f75ff6e2dc13e62f` |
| `sources/ELDER_ef2aa57959ea.md` | 39722 | `f68038be79b46124b0f9b31205aa6e3682b34b6f5ef81f4a5697ae81f07cc46b` |
| `sources/O_724258d33408.md` | 12965 | `b49f2ea5975dc05270f51fea4a3574093f726258cdab94888742507c2caa275f` |
| `sources/P_dfed3b8d318a.md` | 40261 | `9350ad6eaba6626b93c3dedeef9e2ff816e5cdf1c8318e85fb27499141c84bc7` |
| `sources/REC_75da25979715.md` | 23312 | `451b9d7ffee072a73fc904cab891b6693e3f233808b89df10cce1b57036b65da` |
| `sources/ROOTS_b27d9ac8111c.md` | 11969 | `29e79b60a382b95cc0fa2375b82845a5558942cf81a2a836262e7479f9d570e6` |
| `sources/U_9c79a672f5d8.md` | 17545 | `ba1901cbb4bac037befb21d648172ac3ba04aa370f5377a2919c0da988572552` |
