<!-- main#229 comment 5974758184, created 2026-10-03T23:52:56Z (updated 2026-10-03T23:52:56Z), 45053 UTF-8 bytes, SHA-256 a5197d990bc0f58162d95778e2eeedd8f60ea97cea249e3ce3f5d79dc0bcc5e6; copied verbatim from the GitHub API -->
## C99 cross-provider review: reviewer controls, exact executable and stdout

This is the standard-library script behind the [review 5974757409](https://github.com/d6g8k5htny-coder/main/issues/229#issuecomment-5974757409). I wrote it before reading the author controls (5966423222) or the first review (5966413018) and its checker (5966413142), and independently of all three. It checks finite algebra, exact identities on fixtures and finite models only. It does not prove U, ROOTS, O, P, CAP, E1, E2, REC, CUB or ELDER, the Kac–Rice identities, the coupling bounds (G7)–(G9)/(S12), the tail (S9), or any measure-theoretic limit.

Dylan Roy — delegated AI review. Actual performer: Anthropic Claude (session `session_01NMeKEismAyeqgdB4sy2NJU`). Scientific effect: NONE.

**Extraction rule.**
- The file is the exact text between the ```` ```python ```` fence under the `###` heading and the next ```` ``` ```` line, plus one final newline.
- The expected stdout is the text in the following ```` ```text ```` fence, plus one final newline.
- The byte counts below include those newlines.

**Run.**
- `python3 -B -S c99_exact.py`: exit 0, with exactly the stdout shown. A run takes about 8 seconds.
- `-O` mode and plain `python3`: byte-identical output.
- `python3 c99_exact.py BOGUS`: exit 2.
- Each of the twelve mutant labels exits 1 (table below).

The output was produced with Python 3.11.15.

**Groups.**

| group | what it checks |
|---|---|
| L0 | P (3.1)–(3.3): `|det T_r| = 12r⁻⁵` and `v_r = (b − kr³/2, −kr², 0, 12k, 0, 0)` with a constant `k`-slope; the radial and rare-scale ledgers; `A_r(r²/Z_r) = 12π_r` (one `Z_r`); `A_0/z_0 = 12π_0` |
| L1 | (D5)–(D6): the regression coupling `F + Cov·Γ⁻¹(t − V(F))` on random rational 10-dimensional instances is exactly affine in `k`; its slope is `Cov·Γ⁻¹t₁`; `g = (f − b)/r³` interpolates exactly |
| L2 | (D4), (D14), ROOTS R1: `P_(k,kη) = kP_η`; `B_s`, `D_s` of degree 1; `Σ`, `Δ`, `H` of degree 3 (cones); typing invariance; `w(k,kη) = k⁴w(1,η)`; Jacobian `k⁴` and the `k⁸`; `H = H_poly/(1728k³)`; (C3); pin determinants `3k(B_s ∓ 2s)`; R1.3 and (C8) on 600 constructed extra critical points |
| L3 | ROOTS fixtures: all extra roots from (R1.2); heights and Hessians; exclusions nonzero; `Y_*`; `D = 2, 1` (fixture A, `t = 1, 8/5`) and `D = 2` with the below-window saddle (fixture B); rays (roots fixed, heights and gap ratios scaled by `k`); `S_0`'s gap ratio is exactly `k`; the inverse map and `T_0' = t³z_η` |
| L4 | (D6)–(D8) at 100 digits on a perturbed affine family: exact affinity; the envelope identity `d/dk g(Y_r(k)) = ∂_k g`; `T` increasing with `T' ≥ t³z_η/2`; deviation `O(ε)` |
| L5 | (D10)–(D11) on affine maps with step amplitudes: an explicit `O(1/i)` bound; injective pushforward is an isometry; the split; `C¹` is needed (sawtooth maps); weak convergence is not `L¹` convergence |
| L6 | (D18a) on random step functions, and an equality case for each of its three coefficients |
| L7 | (D19)–(D20) and O (O13)–(O14) on finite field ensembles: `L²η − m ≥ 0` with mass exactly `E[(N − 1)_+]`; the triangle bound |
| L8 | (D3): moments of `t⁴dt = τ^{2/3}/(3z^{5/3})dτ` with a `t`-dependent `D` read at `t_τ` (rational cube roots); the support and the `J` floor |
| L9 | (D17) in three norms; (D12)'s triangle; variation from a countable algebra of rational intervals |
| L10 | the diagonal step: `d_{b+c(f−b)}(M) − b = c(d_f(M) − b)` on random grids; ELDER E(1) sanity on fixture A (grid maximin `−23/320`); `k`-scaling of the grid maximin |

**Mutants.** Each was actually run; each exits 1.

| label | change | failing groups | failed checks |
|---|---|---|---:|
| `Z_TWICE` | the amplitude carries `(r²/Z_r)²` | L0 | 400 |
| `TARGET_K2` | the appended jet target scales as `k²η` | L1 | 192 |
| `W_DEG2` | `w(k,kη) = k²w(1,η)` | L2 | 1496 |
| `DROP_BELOW` | saddles below `−k` dropped from `D` | L3 | 1 |
| `INCLUDE_PARTNER` | `Y_*` not excluded from `D` | L3 | 2 |
| `NONAFFINE_K` | a remainder quadratic in `k` | L4 | 79 |
| `C0_ONLY` | `C⁰` convergence of `T_i` taken as enough | L5 | 4 |
| `WEAK_ONLY` | weak convergence taken as `L¹` | L5 | 3 |
| `COEF_J1` | coefficient 1 on `‖f − g‖_{L¹(J)}` | L6 | 4 |
| `HALF_EXCESS` | `E[N 1{N ≥ 2}]/2` in place of `E[(N − 1)_+]` | L7 | 1127 |
| `JAC_NO_THIRD` | `t⁴dt = τ^{2/3}/z^{5/3} dτ` | L8 | 6000 |
| `NEG_SCALE` | a negative rescaling in the diagonal step | L10 | 150 |

### c99_exact.py

- **File:** 39332 bytes, SHA-256 `4435d610257da02f708a21cb44b5ae636125f21aadbf5079140f9ea22fff9fe6`.
- **Stdout:** 825 bytes, SHA-256 `253f19b2cf1d5eec47edecf4d3b31fdc3df840216da30fba7e34d1c4a653f910`.

```python
#!/usr/bin/env python3
"""C99 cross-provider review controls: exact rational checks, standard library only.

Target: C99-WEIGHTED-LIFETIME-DENSITY-20261003-v1, main issue 229, comment 5966273479
(27,469 bytes, SHA-256 55eb6c33...295e).
Reviewer: Anthropic Claude, session_01NMeKEismAyeqgdB4sy2NJU, for Dylan Roy (delegated AI review).
Written without the author's controls (5966423222), the first reviewer's checker (5966413142) or any
other reviewer's code.

Usage: python3 c99_exact.py [MUTANT]   (exit 0 pass, 1 fail, 2 unknown label)
Mutants (each must exit 1):
  Z_TWICE        the amplitude carries (r^2/Z_r)^2: a second normalizer (D13)
  TARGET_K2      the appended jet target scales as k^2 eta, not k eta (D5)
  W_DEG2         w(k, k eta) = k^2 w(1, eta) in place of k^4 (D14)
  DROP_BELOW     candidate saddles below the pinned height -k are dropped from D (ROOTS R3, D9)
  INCLUDE_PARTNER  the actual partner Y_* is not excluded from D (D9)
  NONAFFINE_K    the k-family has a remainder quadratic in k, so (D6)'s exact difference quotient fails
  C0_ONLY        C^0 convergence of T_i is taken as enough for (D10)
  WEAK_ONLY      weak convergence of densities is taken as L1 convergence (section 8)
  COEF_J1        coefficient 1 on ||f-g||_{L1(J)} in (D18a)
  HALF_EXCESS    E[N 1{N>=2}]/2 in place of E[(N-1)_+] in (D19)
  JAC_NO_THIRD   t^4 dt = tau^(2/3)/z^(5/3) d tau, missing the factor 1/3 (D3)
  NEG_SCALE      a negative rescaling in the diagonal step of section 4
These checks test finite algebra, exact identities on fixtures and finite models only. They do not
prove U, ROOTS, O, P, CAP, E1, E2, REC, CUB or ELDER, the Kac-Rice identities, the coupling bounds
(G7)-(G9)/(S12), the tail (S9), or any measure-theoretic limit.
"""
import math
import random
import sys
from decimal import Decimal, getcontext
from fractions import Fraction as F

MUTANTS = ("Z_TWICE", "TARGET_K2", "W_DEG2", "DROP_BELOW", "INCLUDE_PARTNER", "NONAFFINE_K",
           "C0_ONLY", "WEAK_ONLY", "COEF_J1", "HALF_EXCESS", "JAC_NO_THIRD", "NEG_SCALE")
MUT = None
if len(sys.argv) > 1:
    MUT = sys.argv[1]
    if len(sys.argv) > 2 or MUT not in MUTANTS:
        print("unknown mutant label: %s" % " ".join(sys.argv[1:]))
        sys.exit(2)

RNG = random.Random(99_5966273479)
RESULTS, FAILS = [], []


class Group:
    def __init__(self, name):
        self.name, self.n, self.bad = name, 0, 0

    def check(self, ok, msg=""):
        self.n += 1
        if not ok:
            self.bad += 1
            if len(FAILS) < 12:
                FAILS.append("%s: %s" % (self.name, msg))

    def close(self):
        RESULTS.append((self.name, self.n - self.bad, self.n))


def rq(lo, hi, den=97):
    a, b = int(math.floor(F(lo) * den)), int(math.floor(F(hi) * den))
    return F(RNG.randint(a, b), den)


def rq_pos(lo, hi, den=97):
    while True:
        x = rq(lo, hi, den)
        if x > 0:
            return x


def det(m):
    """Exact determinant by fraction-preserving elimination."""
    m = [list(map(F, row)) for row in m]
    n, d = len(m), F(1)
    for c in range(n):
        p = next((r for r in range(c, n) if m[r][c] != 0), None)
        if p is None:
            return F(0)
        if p != c:
            m[c], m[p] = m[p], m[c]
            d = -d
        d *= m[c][c]
        for r in range(c + 1, n):
            f_ = m[r][c] / m[c][c]
            if f_:
                for j in range(c, n):
                    m[r][j] -= f_ * m[c][j]
    return d


def solve(a, b):
    """Exact solution of a x = b (a square, nonsingular)."""
    n = len(a)
    m = [list(map(F, a[i])) + [F(b[i])] for i in range(n)]
    for c in range(n):
        p = next(r for r in range(c, n) if m[r][c] != 0)
        m[c], m[p] = m[p], m[c]
        piv = m[c][c]
        m[c] = [x / piv for x in m[c]]
        for r in range(n):
            if r != c and m[r][c] != 0:
                f_ = m[r][c]
                m[r] = [x - f_ * y for x, y in zip(m[r], m[c])]
    return [m[i][n] for i in range(n)]


# ---------------------------------------------------------------------
# planar pinned cubic (U (3)/ROOTS R1/CUB (C1)) as a polynomial dict {(i, j): coeff} in X^i Z^j
# ---------------------------------------------------------------------
def cubic(k, s, a, be, q):
    return {(3, 0): 2 * k, (1, 0): -F(3, 2) * k, (0, 0): -k / 2, (0, 2): s / 2, (2, 1): a / 2,
            (0, 1): -a / 8, (1, 2): be / 2, (0, 3): q / 6}


def pev(p, x, z):
    return sum(c * x**i * z**j for (i, j), c in p.items())


def pdx(p):
    return {(i - 1, j): c * i for (i, j), c in p.items() if i > 0}


def pdz(p):
    return {(i, j - 1): c * j for (i, j), c in p.items() if j > 0}


def grad(p, x, z):
    return pev(pdx(p), x, z), pev(pdz(p), x, z)


def hess(p, x, z):
    px, pz = pdx(p), pdz(p)
    return pev(pdx(px), x, z), pev(pdz(px), x, z), pev(pdz(pz), x, z)


def hdet(p, x, z):
    a_, b_, c_ = hess(p, x, z)
    return a_ * c_ - b_ * b_


def shear(k, s, a, be, q):
    B = be - a**2 / (12 * k)
    D = (q - a * be / (4 * k) + a**3 / (72 * k**2)) / 2
    return B, D


def excl(k, s, a, be, q):
    B, D = shear(k, s, a, be, q)
    return {"Sigma": 12 * k * D**2 + (s - B)**2 * (B + 2 * s), "Delta": 12 * k * D**2 + B**3, "D": D,
            "H": 12 * k * D**2 + B**3 - 4 * B * s**2}


def w_typed(k, s, a, be, q):
    B, _ = shear(k, s, a, be, q)
    return 9 * k**2 * (4 * s**2 - B**2)


# =====================================================================
# L0  contact frame (P (3.1)-(3.3)), the radial and rare-scale ledgers, and one normalizer (D13)-(D14)
# =====================================================================
g = Group("L0 frame, ledgers, one normalizer")
for _ in range(400):
    r = rq_pos(F(1, 50), 2)
    rows = [[F(1, 2), 0, F(1, 2), 0, 0, 0],
            [-1 / r, 0, 1 / r, 0, 0, 0],
            [0, -1 / r, 0, 1 / r, 0, 0],
            [12 / r**3, 6 / r**2, -12 / r**3, 6 / r**2, 0, 0],
            [0, 0, 0, 0, F(1, 2), F(1, 2)],
            [0, 0, 0, 0, -1 / r, 1 / r]]
    g.check(abs(det(rows)) == 12 / r**5, "|det T_r| = 12 r^-(d+3), d = 2")
    b, k = rq(-3, 3), rq_pos(F(1, 4), 3)
    obs = [b, 0, b - k * r**3, 0, 0, 0]              # f(a), f_x(a), f(c), f_x(c), f_y(a), f_y(c)
    U = [sum(F(x) * y for x, y in zip(row, obs)) for row in rows]
    g.check(U == [b - k * r**3 / 2, -k * r**2, 0, 12 * k, 0, 0], "(3.3)/(D5): v_r = (b-kr^3/2,-kr^2,0,12k,0,0)")
    # (D5): v_r is affine in k with b fixed: v_r(k) = v_r(0) + k v_r'
    k2 = rq_pos(F(1, 4), 3)
    U2 = [b - k2 * r**3 / 2, -k2 * r**2, 0, 12 * k2, 0, 0]
    slope = [(x2 - x1) / (k2 - k) for x1, x2 in zip(U, U2)] if k2 != k else None
    if slope is not None:
        g.check(slope == [-r**3 / 2, -r**2, 0, 12, 0, 0], "v_r has the constant k-slope (-r^3/2,-r^2,0,12,0,0)")
for d_ in range(2, 7):
    g.check((d_ - 1) + 3 - (d_ + 3) + 2 == 1, "P (10.2): spatial + height + pin + determinant powers = 1")
# rare scale r^-3, jet Jacobian r, determinant r^4, normalizer Z_r ~ r^2: the prefactor r^2/Z_r is O(1)
g.check(-3 + 1 + 4 - 2 == 0, "U (9)/(D13): r^-3 * r * r^4 / Z_r has power 0")
for _ in range(400):
    t, h = rq_pos(F(1, 4), 3), rq_pos(F(1, 100), 1)
    r = t * h
    # r dr * r^3 (rare failure) with r = t h, dr = h dt, divided by h^5, equals t^4 dt
    g.check(h**-5 * (r * h) * r**3 == t**4, "(11)/(D13): h^-5 r dr r^3 = t^4 dt")
    pi_r, Z_r = rq_pos(F(1, 10), 5), rq_pos(F(1, 100), 3) * r**2
    A_r = 12 * pi_r * Z_r / r**2
    amp = A_r * (r**2 / Z_r) ** (2 if MUT == "Z_TWICE" else 1)
    lam = rq_pos(F(1, 3), 3)
    A_r2 = 12 * pi_r * (lam * Z_r) / r**2
    amp2 = A_r2 * (r**2 / (lam * Z_r)) ** (2 if MUT == "Z_TWICE" else 1)
    g.check(amp == 12 * pi_r and amp2 == amp, "A_r r^2/Z_r = 12 pi_r: exactly one Z_r cancels")
    z0 = rq_pos(F(1, 10), 3)
    g.check((12 * pi_r * z0) / z0 == 12 * pi_r, "A_0/z_0 = 12 pi_0")
g.close()

# =====================================================================
# L1  (D5)-(D6): the regression coupling is exactly affine in the target, hence in k
# =====================================================================
g = Group("L1 coupling affine in k (D5)-(D6)")
for inst in range(24):
    n = 10
    Mm = [[rq(-2, 2, 7) for _ in range(n)] for _ in range(n)]
    Gam = [[sum(Mm[i][l] * Mm[j][l] for l in range(n)) + (1 if i == j else 0) for j in range(n)] for i in range(n)]
    g.check(det(Gam) > 0, "Gamma_r positive definite (Gram plus identity)")
    nev = 6                                             # six field evaluations (values or derivatives)
    C = [[rq(-2, 2, 5) for _ in range(n)] for _ in range(nev)]
    Fv = [rq(-3, 3, 11) for _ in range(nev)]            # unconditioned F at the evaluations
    VF = [rq(-3, 3, 11) for _ in range(n)]              # V_r(F)
    b, r = rq(-2, 2), rq_pos(F(1, 20), 1)
    eta = [rq(-3, 3) for _ in range(4)]

    def target(k):
        jet_k = k * k if MUT == "TARGET_K2" else k
        return [b - k * r**3 / 2, -k * r**2, 0, 12 * k, 0, 0,
                r * jet_k * eta[0], jet_k * eta[1], jet_k * eta[2], jet_k * eta[3]]

    def coupled(k):
        x = solve(Gam, [ti - vi for ti, vi in zip(target(k), VF)])
        return [fv + sum(cr[j] * x[j] for j in range(n)) for fv, cr in zip(Fv, C)]

    ka, kb = F(1, 2), F(5, 2)
    fa, fb = coupled(ka), coupled(kb)
    slope = [(y - x) / (kb - ka) for x, y in zip(fa, fb)]
    t1 = [-r**3 / 2, -r**2, 0, 12, 0, 0, r * eta[0], eta[1], eta[2], eta[3]]
    xs = solve(Gam, t1)
    g.check(slope == [sum(cr[j] * xs[j] for j in range(n)) for cr in C] or MUT == "TARGET_K2",
            "the k-slope is Cov(F,V) Gamma^-1 t_1, independent of k")
    for _ in range(4):
        k = rq_pos(F(1, 2), F(5, 2))
        fk = coupled(k)
        interp = [((kb - k) * x + (k - ka) * y) / (kb - ka) for x, y in zip(fa, fb)]
        g.check(fk == interp, "f_r^(k eta) equals the affine interpolation of two targets (D6)")
        # normalized local values g = (f - b)/r^3 inherit exact affinity
        gk = [(v - b) / r**3 for v in fk]
        gi = [((kb - k) * (x - b) + (k - ka) * (y - b)) / ((kb - ka) * r**3) for x, y in zip(fa, fb)]
        g.check(gk == gi, "g_r^k is exactly affine: partial_k g = (g^kb - g^ka)/(kb - ka)")
g.close()

# =====================================================================
# L2  (D4), (D14) and ROOTS R1/R2: scaling, homogeneity of exclusions, w = k^4 w(1,eta), k^8, R1 identities
# =====================================================================
g = Group("L2 scaling, homogeneity, R1 identities")
for _ in range(1500):
    eta = [rq(-4, 4) for _ in range(4)]
    k = rq_pos(F(1, 5), 5)
    th = [k * e for e in eta]
    p1, pk = cubic(F(1), *eta), cubic(k, *th)
    x, z = rq(-3, 3), rq(-3, 3)
    g.check(pev(pk, x, z) == k * pev(p1, x, z), "P_(k,k eta) = k P_eta")
    gx1, gz1 = grad(p1, x, z)
    gxk, gzk = grad(pk, x, z)
    g.check((gxk, gzk) == (k * gx1, k * gz1), "critical points fixed along the ray")
    B1, D1 = shear(F(1), *eta)
    Bk, Dk = shear(k, *th)
    g.check(Bk == k * B1 and Dk == k * D1, "B_s, D_s homogeneous of degree 1")
    e1, ek = excl(F(1), *eta), excl(k, *th)
    for key in ("Sigma", "Delta", "H"):
        g.check(ek[key] == k**3 * e1[key], "%s homogeneous of degree 3 (a cone)" % key)
    g.check((th[0] < -abs(Bk) / 2) == (eta[0] < -abs(B1) / 2), "strict typing preserved on rays")
    wk, w1 = w_typed(k, *th), w_typed(F(1), *eta)
    g.check(wk == k ** (2 if MUT == "W_DEG2" else 4) * w1, "w(k, k eta) = k^4 w(1, eta)")
    jac = det([[1, 0, 0, 0, 0]] + [[eta[i]] + [k if j == i else 0 for j in range(4)] for i in range(4)])
    g.check(jac == k**4, "(k, eta) -> (k, k eta) has Jacobian k^4")
    g.check(jac * wk / w1 == k**8 if w1 != 0 else True, "the coordinate amplitude carries k^8")
    # ROOTS R1: H = H_poly/(1728 k^3), with U = 12 k beta - a^2, V = 72 k^2 q - 18 k a beta + a^3
    s, a, be, q = th
    Up, Vp = 12 * k * be - a**2, 72 * k**2 * q - 18 * k * a * be + a**3
    g.check(ek["H"] == (Vp**2 + Up**3 - 576 * k**2 * Up * s**2) / (1728 * k**3), "H = H_poly/(1728 k^3)")
    # CUB (C3): sheared form; pin Hessians and the typed weight
    u = x + a * z / (12 * k)
    g.check(pev(pk, x, z) == 2 * k * u**3 - 3 * k * u / 2 - k / 2 + s * z**2 / 2 + Bk * u * z**2 / 2 + Dk * z**3 / 3,
            "(C3) sheared cubic")
    dM, dS = hdet(pk, F(-1, 2), F(0)), hdet(pk, F(1, 2), F(0))
    g.check(dM == 3 * k * (Bk - 2 * s) and dS == 3 * k * (Bk + 2 * s), "pin determinants 3k(B -/+ 2s)")
    if s < -abs(Bk) / 2:
        g.check(dM > 0 and dS < 0 and dM * (-dS) == wk, "typed: M max, S saddle, w = |det H_M||det H_S|")
# R1.3 on exact extra critical points: build (u, Z, B, s) first, then D from the line and k from the conic
cnt = 0
while cnt < 600:
    u, Z, B, s = rq(-3, 3), rq(-3, 3), rq(-3, 3), rq(-3, 0)
    if Z == 0 or u * u == F(1, 4) or s == 0:
        continue
    k = -B * Z**2 / (12 * (u * u - F(1, 4)))
    if k <= 0:
        continue
    D = -(s + B * u) / Z
    a = rq(-2, 2)
    be = B + a**2 / (12 * k)
    q = 2 * D + a * be / (4 * k) - a**3 / (72 * k**2)
    p = cubic(k, s, a, be, q)
    X = u - a * Z / (12 * k)
    g.check(grad(p, X, Z) == (0, 0), "an extra critical point of R1.1")
    H = 12 * k * D**2 + B**3 - 4 * B * s**2
    g.check(H * Z**2 == 3 * k * (B + 4 * s * u)**2, "R1.3: H Z^2 = 3k(B_s + 4su)^2")
    g.check(hdet(p, X, Z) == -3 * k * (B + 4 * s * u), "(C8): det Hess P = -3k(B_s + 4su)")
    cnt += 1
g.close()


# =====================================================================
# L3  ROOTS fixtures: all-root enumeration, the reciprocal count D_(t,k), rays and the inverse map
# =====================================================================
def extra_roots(k, s, a, be, q):
    """Exact extra critical points when R1.2 has rational roots (fixtures); returns (X, Z) list."""
    B, D = shear(k, s, a, be, q)
    A2, A1, A0 = 12 * k * D**2 + B**3, 2 * B**2 * s, B * s**2 - 3 * k * D**2
    disc = A1 * A1 - 4 * A2 * A0
    num, den = disc.numerator, disc.denominator
    rn, rd = math.isqrt(num), math.isqrt(den)
    if rn * rn != num or rd * rd != den:
        return None
    sq = F(rn, rd)
    out = []
    for us in ((-A1 + sq) / (2 * A2), (-A1 - sq) / (2 * A2)):
        Z = -(s + B * us) / D
        out.append((us - a * Z / (12 * k), Z))
    return out


def count_D(p, k, roots, t, c0, C0, kl, kh, mode=None):
    """U (5): saddles Y != Y_*, P(Y) < 0, c0 <= t|Y-M0| <= C0, -P/|Y-M0|^3 in [kl, kh]."""
    M0 = (F(-1, 2), F(0))
    window = [y for y in roots if -k < pev(p, *y) < 0 and hdet(p, *y) < 0]
    ystar = max(window, key=lambda y: pev(p, *y)) if window else None
    cands = [(F(1, 2), F(0))] + list(roots)
    n = 0
    for y in cands:
        hy = pev(p, *y)
        if hdet(p, *y) >= 0 or hy >= 0:
            continue
        if y == ystar and mode != "INCLUDE_PARTNER":
            continue
        if mode == "DROP_BELOW" and hy <= -k and y != (F(1, 2), F(0)):
            continue
        rho2 = (y[0] - M0[0])**2 + (y[1] - M0[1])**2
        if not (c0**2 <= t**2 * rho2 <= C0**2):
            continue
        if not (kl**2 * rho2**3 <= hy**2 <= kh**2 * rho2**3):
            continue
        n += 1
    return n, ystar


g = Group("L3 fixtures, count D, rays, inverse")
mode = MUT if MUT in ("DROP_BELOW", "INCLUDE_PARTNER") else None
fixA = (F(1), F(-21, 10), F(0), F(-3), F(3, 5))
fixB = (F(1), F(-39, 16), F(0), F(-3), F(3, 2))
pA, pB = cubic(*fixA), cubic(*fixB)
rA, rB = extra_roots(*fixA), extra_roots(*fixB)
g.check(rA is not None and set(rA) == {(F(-5, 8), F(3, 4)), (F(-5, 6), F(-4, 3))}, "fixture A: all extra roots")
g.check(rB is not None and set(rB) == {(F(-5, 8), F(3, 4)), (F(-37, 24), F(-35, 12))}, "fixture B: all extra roots")
for (p, roots, vals, dets) in ((pA, rA, {(F(-5, 8), F(3, 4)): F(-23, 320), (F(-5, 6), F(-4, 3)): F(-13, 45)},
                                {(F(-5, 8), F(3, 4)): F(-27, 4), (F(-5, 6), F(-4, 3)): F(-12)}),
                               (pB, rB, {(F(-5, 8), F(3, 4)): F(-53, 512), (F(-37, 24), F(-35, 12)): F(-11125, 4608)},
                                {(F(-5, 8), F(3, 4)): F(-297, 32), (F(-37, 24), F(-35, 12)): F(-1155, 32)})):
    for y in roots:
        g.check(grad(p, *y) == (0, 0), "extra root is critical")
        g.check(pev(p, *y) == vals[y] and hdet(p, *y) == dets[y], "fixture heights and Hessian determinants")
    for pin in ((F(-1, 2), F(0)), (F(1, 2), F(0))):
        g.check(grad(p, *pin) == (0, 0), "pins are critical")
for fx in (fixA, fixB):
    e = excl(*fx)
    g.check(all(e[key] != 0 for key in ("Sigma", "Delta", "D", "H")), "fixture avoids Sigma, Delta, D_s = 0, H = 0")
    B, _ = shear(*fx)
    g.check(fx[1] < -abs(B) / 2, "fixture strictly typed")
g.check(hdet(pB, F(-1, 2), F(0)) == F(45, 8) and hdet(pB, F(1, 2), F(0)) == F(-189, 8), "fixture B pin determinants")
nA1, ysA = count_D(pA, F(1), rA, F(1), F(1, 2), F(2), F(1, 10), F(2), mode)
nA2, _ = count_D(pA, F(1), rA, F(8, 5), F(1, 2), F(2), F(1, 10), F(2), mode)
nB1, ysB = count_D(pB, F(1), rB, F(1), F(1, 2), F(4), F(1, 100), F(2), mode)
g.check(ysA == (F(-5, 8), F(3, 4)) and ysB == (F(-5, 8), F(3, 4)), "Y_* is Y1 in both fixtures")
g.check(nA1 == 2 and nA2 == 1, "fixture A: D = 2 at t = 1 and D = 1 at t = 8/5 (ROOTS R4)")
g.check(nB1 == 2, "fixture B: S0 and the below-window Y2 are both rejected candidates, D = 2")
zA = -pev(pA, *ysA)
g.check(zA == F(23, 320) and 0 < zA < 1, "z_eta = -P_eta(Y_*) in (0, 1)")
for _ in range(300):
    k = rq_pos(F(1, 5), 4)
    pk = cubic(k, *[k * c for c in fixA[1:]])
    for y in rA:
        g.check(grad(pk, *y) == (0, 0) and pev(pk, *y) == k * pev(pA, *y), "roots fixed, heights scaled on the ray")
    t = rq_pos(F(1, 2), 2)
    T0 = t**3 * k * zA
    g.check(T0 / (t**3 * zA) == k, "inverse map k_0 = tau/(t^3 z_eta)")
    k2 = k + rq_pos(F(1, 100), 1)
    g.check((t**3 * k2 * zA - T0) / (k2 - k) == t**3 * zA, "T_0' = t^3 z_eta > 0")
    # the pinned saddle S0 has gap ratio exactly k: the fixed-k slice k = k_+- is not null (ROOTS R2)
    g.check(-pev(pk, F(1, 2), F(0)) == k, "S0 (distance 1) has gap ratio exactly k for every theta")
    # gap ratios scale by k along the ray (squared form)
    for y in rA:
        rho2 = (y[0] + F(1, 2))**2 + y[1]**2
        g.check(pev(pk, *y)**2 / rho2**3 == k**2 * pev(pA, *y)**2 / rho2**3, "gap ratio scales by k")
    # D on the ray with the band scaled by k equals D at k = 1: membership is a function of ratio/k
    nk, _ = count_D(pk, k, rA, F(1), F(1, 2), F(2), k * F(1, 10), k * F(2))
    g.check(nk == 2, "D_(t,k)(k eta) with K scaled by k equals D_(t,1)(eta)")
g.close()

# =====================================================================
# L4  (D6)-(D8) on a perturbed affine family, at 100 significant digits (decimal)
# =====================================================================
g = Group("L4 envelope and lifetime map (decimal)")
getcontext().prec = 100
Dd = Decimal


def to_dec_poly(p):
    return {key: Dd(c.numerator) / Dd(c.denominator) for key, c in p.items()}


P1 = cubic(F(1), *fixA[1:])
Q0 = {(4, 0): F(1), (1, 3): F(1), (0, 4): F(-1, 2), (2, 1): F(1)}
Q1 = {(0, 4): F(1), (3, 1): F(-1), (1, 2): F(1), (0, 0): F(1, 3)}


def fam(k, eps, mutant):
    out = {}
    for key, c in P1.items():
        out[key] = out.get(key, 0) + k * c
    for key, c in Q0.items():
        out[key] = out.get(key, 0) + eps * c
    kk = k * k if mutant else k
    for key, c in Q1.items():
        out[key] = out.get(key, 0) + eps * kk * c
    return out


nonaff = MUT == "NONAFFINE_K"
for eps in (F(1, 1000), F(1, 10000)):
    ka, kb = F(1, 2), F(2)
    for _ in range(40):
        k = rq_pos(F(1, 2), 2)
        x, z = rq(-2, 2), rq(-2, 2)
        lhs = pev(fam(k, eps, nonaff), x, z)
        rhs = ((kb - k) * pev(fam(ka, eps, nonaff), x, z) + (k - ka) * pev(fam(kb, eps, nonaff), x, z)) / (kb - ka)
        g.check(lhs == rhs, "exact affinity in k: the difference quotient is partial_k g (D6)")


def newton(p, y0, steps=60):
    px, pz = to_dec_poly(pdx(p)), to_dec_poly(pdz(p))
    pxx, pxz, pzz = to_dec_poly(pdx(pdx(p))), to_dec_poly(pdz(pdx(p))), to_dec_poly(pdz(pdz(p)))
    x, z = y0
    for _ in range(steps):
        gx, gz = pev(px, x, z), pev(pz, x, z)
        a_, b_, c_ = pev(pxx, x, z), pev(pxz, x, z), pev(pzz, x, z)
        dd = a_ * c_ - b_ * b_
        x, z = x - (c_ * gx - b_ * gz) / dd, z - (-b_ * gx + a_ * gz) / dd
        if abs(gx) + abs(gz) < Dd(10) ** -95:
            break
    return x, z, abs(pev(px, x, z)) + abs(pev(pz, x, z))


Y1 = (Dd(-5) / 8, Dd(3) / 4)
zst = Dd(23) / 320
t = Dd(3) / 2
for eps in (F(1, 1000), F(1, 10000), F(1, 100000)):
    epsd = Dd(eps.numerator) / Dd(eps.denominator)
    prevT, devs = None, []
    for kq in (F(1, 2), F(3, 4), F(1), F(5, 4), F(3, 2), F(7, 4), F(2)):
        kd = Dd(kq.numerator) / Dd(kq.denominator)
        x, z, res = newton(fam(kq, eps, False), Y1)
        g.check(res < Dd(10) ** -80, "continued root Y_r(k) found (residual < 1e-80)")
        dlt = Dd(10) ** -25
        vals = []
        for sgn in (1, -1):
            kk = kd + sgn * dlt
            pk = {key: kk * (Dd(c.numerator) / Dd(c.denominator)) for key, c in P1.items()}
            for key, c in Q0.items():
                pk[key] = pk.get(key, 0) + epsd * Dd(c.numerator) / Dd(c.denominator)
            for key, c in Q1.items():
                pk[key] = pk.get(key, 0) + epsd * kk * Dd(c.numerator) / Dd(c.denominator)
            # Newton directly on the decimal polynomial at k +- delta, started from the root at k
            px = {(i - 1, j): c * i for (i, j), c in pk.items() if i > 0}
            pz = {(i, j - 1): c * j for (i, j), c in pk.items() if j > 0}
            pxx = {(i - 1, j): c * i for (i, j), c in px.items() if i > 0}
            pxz = {(i, j - 1): c * j for (i, j), c in px.items() if j > 0}
            pzz = {(i, j - 1): c * j for (i, j), c in pz.items() if j > 0}
            xx, zz = x, z
            for _ in range(40):
                gx, gz = pev(px, xx, zz), pev(pz, xx, zz)
                a_, b_, c_ = pev(pxx, xx, zz), pev(pxz, xx, zz), pev(pzz, xx, zz)
                dd = a_ * c_ - b_ * b_
                xx, zz = xx - (c_ * gx - b_ * gz) / dd, zz - (-b_ * gx + a_ * gz) / dd
            vals.append(pev(pk, xx, zz))
        dgdk = (vals[0] - vals[1]) / (2 * dlt)
        partial = pev(to_dec_poly(P1), x, z) + epsd * pev(to_dec_poly(Q1), x, z)
        g.check(abs(dgdk - partial) < Dd(10) ** -40, "(D7): d/dk g(Y_r(k)) = partial_k g at the root")
        devs.append(abs(partial + zst))
        Tk = -t**3 * pev(to_dec_poly(fam(kq, eps, False)), x, z)
        if prevT is not None:
            g.check(Tk > prevT, "(D8): T_h increasing in k")
        prevT = Tk
        g.check(-t**3 * partial >= t**3 * zst / 2, "(D8): T_h' >= t^3 z_eta / 2")
    g.check(max(devs) < 40 * epsd, "|partial_k g(Y_r) + z_eta| = O(eps)")
g.close()


# =====================================================================
# L5  (D10)-(D11): pushforwards of step densities by affine maps; isometry; C0 and weak counterexamples
# =====================================================================
def l1_steps(f1, f2):
    """f = (breaks, values): values[i] on [breaks[i], breaks[i+1]); zero outside."""
    pts = sorted(set(f1[0]) | set(f2[0]))

    def val(f, x):
        br, vs = f
        for i in range(len(vs)):
            if br[i] <= x < br[i + 1]:
                return vs[i]
        return F(0)

    tot = F(0)
    for i in range(len(pts) - 1):
        mid = (pts[i] + pts[i + 1]) / 2
        tot += abs(val(f1, mid) - val(f2, mid)) * (pts[i + 1] - pts[i])
    return tot


def push_affine(f, al, be):
    br, vs = f
    return ([al * x + be for x in br], [v / al for v in vs])


def sub_steps(f1, f2):
    pts = sorted(set(f1[0]) | set(f2[0]))

    def val(f, x):
        br, vs = f
        for i in range(len(vs)):
            if br[i] <= x < br[i + 1]:
                return vs[i]
        return F(0)

    return (pts, [val(f1, (pts[i] + pts[i + 1]) / 2) - val(f2, (pts[i] + pts[i + 1]) / 2) for i in range(len(pts) - 1)])


g = Group("L5 pushforward lemma (D10)-(D11)")
for _ in range(60):
    nb = RNG.randint(2, 6)
    inner = sorted(set(rq(1, 2, 64) for _ in range(nb)) - {F(1), F(2)})
    br = [F(1)] + inner + [F(2)]
    a0 = (br, [rq(0, 3, 16) for _ in range(len(br) - 1)])
    al0, be0 = rq_pos(F(1, 2), 3), rq(-1, 1)
    l1a = sum(abs(v) * (br[i + 1] - br[i]) for i, v in enumerate(a0[1]))
    jumps = [a0[1][0]] + [a0[1][i + 1] - a0[1][i] for i in range(len(a0[1]) - 1)] + [-a0[1][-1]]
    prev = None
    for i in (1, 2, 4, 8, 16, 64, 256):
        al, be = al0 + F(1, i), be0 + F((-1) ** i, 2 * i)
        dist = l1_steps(push_affine(a0, al, be), push_affine(a0, al0, be0))
        bound = sum(abs(J) * abs((al - al0) * x + (be - be0)) for J, x in zip(jumps, br)) / al + l1a * abs(al - al0) / al
        g.check(dist <= bound, "||T_i#a - T_0#a|| <= (1/alpha_i) sum |J_j||T_i(x_j)-T_0(x_j)| + ||a|| |alpha_i-alpha_0|/alpha_i")
        sJ = sum(abs(J) for J in jumps)
        g.check(bound <= (F(5, 2) * sJ + l1a) / (i * al0), "the bound is at most (5/2 sum|J| + ||a||)/(i alpha_0) -> 0")
    v = (br, [rq(0, 3, 16) for _ in range(len(br) - 1)])
    d_av = sub_steps(a0, v)
    l1_av = sum(abs(x) * (d_av[0][i + 1] - d_av[0][i]) for i, x in enumerate(d_av[1]))
    g.check(l1_steps(push_affine(a0, al0, be0), push_affine(v, al0, be0)) == l1_av,
            "injective pushforward is an isometry: ||T#(a - v)|| = ||a - v||_1 (contraction)")
    # (D11): T_i#a_i - T_0#a_0 = T_i#(a_i - a_0) + [T_i#a_0 - T_0#a_0], and the norm bound
    ai = (br, [x + rq(-F(1, 10), F(1, 10), 64) for x in a0[1]])
    al, be = al0 + F(1, 7), be0 - F(1, 9)
    lhs = l1_steps(push_affine(ai, al, be), push_affine(a0, al0, be0))
    d_i = sub_steps(ai, a0)
    l1_i = sum(abs(x) * (d_i[0][k_ + 1] - d_i[0][k_]) for k_, x in enumerate(d_i[1]))
    g.check(lhs <= l1_i + l1_steps(push_affine(a0, al, be), push_affine(a0, al0, be0)), "(D11) split bound")
# C0 is not enough: sawtooth maps with slopes 1/2, 3/2 on 2n pieces of [0,1] converge uniformly to the identity
for n in (1, 2, 5, 10, 50, 200):
    w = F(1, 2 * n)
    br, vals, x = [F(0)], [], F(0)
    for j in range(2 * n):
        sl = F(1, 2) if j % 2 == 0 else F(3, 2)
        x += sl * w
        br.append(x)
        vals.append(1 / sl)                         # density of the pushforward of Lebesgue on that piece
    g.check(br[-1] == 1, "sawtooth maps [0,1] onto [0,1]")
    supdev = max(abs(br[j] - j * w) for j in range(2 * n + 1))
    g.check(supdev <= F(1, 4 * n), "sup |T_n - id| <= 1/(4n) -> 0")
    dist = l1_steps((br, vals), ([F(0), F(1)], [F(1)]))
    g.check(dist <= F(1, n) if MUT == "C0_ONLY" else dist == F(1, 2), "variation distance stays 1/2: C1 is needed")
# weak convergence is not L1 convergence: densities alternating 0 and 2 on 2n pieces of [0,1]
for n in (1, 3, 10, 40):
    br = [F(j, 2 * n) for j in range(2 * n + 1)]
    vals = [F(0) if j % 2 == 0 else F(2) for j in range(2 * n)]
    m1 = sum(vals[j] * (br[j + 1] ** 2 - br[j] ** 2) / 2 for j in range(2 * n))
    g.check(abs(m1 - F(1, 2)) <= F(1, 2 * n), "first moments converge (weak convergence)")
    dist = l1_steps((br, vals), ([F(0), F(1)], [F(1)]))
    g.check(dist <= F(1, n) if MUT == "WEAK_ONLY" else dist == 1, "L1 distance stays 1")
g.close()

# =====================================================================
# L6  (D18a): the global L1 inequality, exactly, with equality cases for all three coefficients
# =====================================================================
g = Group("L6 global L1 inequality (D18a)")
cJ = 1 if MUT == "COEF_J1" else 2


def l1_on(f1, f2, lo, hi):
    pts = sorted(set([x for x in f1[0] + f2[0] if lo < x < hi] + [lo, hi]))

    def val(f, x):
        br, vs = f
        for i in range(len(vs)):
            if br[i] <= x < br[i + 1]:
                return vs[i]
        return F(0)

    return sum(abs(val(f1, (pts[i] + pts[i + 1]) / 2) - val(f2, (pts[i] + pts[i + 1]) / 2)) * (pts[i + 1] - pts[i])
               for i in range(len(pts) - 1))


def mass(f):
    br, vs = f
    return sum(v * (br[i + 1] - br[i]) for i, v in enumerate(vs))


def rhs18a(f, g_, lo, hi, top):
    return cJ * l1_on(f, g_, lo, hi) + abs(mass(f) - mass(g_)) + 2 * (l1_on(g_, ([F(0), top], [F(0)]), F(0), lo)
                                                                       + l1_on(g_, ([F(0), top], [F(0)]), hi, top))


for _ in range(800):
    top = F(10)
    pts = sorted(set([F(0), top] + [rq(0, 10, 8) for _ in range(5)]))
    f1 = (pts, [rq(0, 2, 8) for _ in range(len(pts) - 1)])
    f2 = (pts, [rq(0, 2, 8) for _ in range(len(pts) - 1)])
    lo, hi = rq_pos(F(1, 8), 4, 8), rq(5, 10, 8)
    g.check(l1_on(f1, f2, F(0), top) <= rhs18a(f1, f2, lo, hi, top), "(D18a)")
# equality instances: mass m on J^c moves (term 2||f-g||_J), mass appears (mass term), disjoint J^c masses (tail term)
J = (F(2), F(5))
top = F(10)
m = F(3, 2)
gA = ([F(0), F(2), F(5), F(10)], [F(0), F(1), F(0)])
fA = ([F(0), F(2), F(5), F(6), F(10)], [F(0), 1 - m / 3, m, F(0)])  # f moves mass m from J to J^c
eqA = l1_on(fA, gA, F(0), top)
g.check(eqA == 2 * m and eqA == rhs18a(fA, gA, *J, top), "equality: coefficient 2 on ||f-g||_J is sharp")
gB = ([F(0), F(10)], [F(0)])
fB = ([F(0), F(1), F(10)], [m, F(0)])
g.check(l1_on(fB, gB, F(0), top) == rhs18a(fB, gB, *J, top), "equality: the mass term is sharp")
gC = ([F(0), F(1), F(10)], [m, F(0)])
fC = ([F(0), F(6), F(7), F(10)], [F(0), m, F(0)])
g.check(l1_on(fC, gC, F(0), top) == rhs18a(fC, gC, *J, top) == 2 * m, "equality: coefficient 2 on the tail is sharp")
g.close()

# =====================================================================
# L7  (D19)-(D20) with O (O13)-(O14): occurrence excess on finite field ensembles
# =====================================================================
g = Group("L7 occurrence excess (D19)-(D20)")
for _ in range(1500):
    nf = RNG.randint(1, 6)
    probs = [rq_pos(F(1, 100), F(1, 6), 600) for _ in range(nf)]
    fields = []
    for pr in probs:
        Nw = RNG.choice([0, 1, 1, 1, 2, 3, 4, 5])
        fields.append((pr, [RNG.randint(1, 6) for _ in range(Nw)]))
    eta = {}
    mm = {}
    for pr, ls in fields:
        for l in ls:
            eta[l] = eta.get(l, 0) + pr
            mm[l] = mm.get(l, 0) + pr / len(ls)
    excess = sum(pr * max(len(ls) - 1, 0) for pr, ls in fields)
    diff = {l: eta.get(l, 0) - mm.get(l, 0) for l in set(eta) | set(mm)}
    g.check(all(v >= 0 for v in diff.values()), "0 <= m_h <= L^2 eta_h")
    tv = sum(abs(v) for v in diff.values())
    if MUT == "HALF_EXCESS":
        bound = sum(pr * len(ls) for pr, ls in fields if len(ls) >= 2) / 2
    else:
        bound = excess
    g.check(tv <= bound, "(D19): ||L^2 eta - m|| <= E[(N-1)_+]")
    g.check(tv == excess, "equality: the difference is a positive measure of mass E[(N-1)_+]")
    phi = {l: rq(-1, 1, 12) for l in range(1, 7)}
    for pr, ls in fields:
        S = sum(phi[l] for l in ls)
        corr = S / len(ls) if ls else F(0)
        g.check(abs(S - corr) <= max(abs(v) for v in phi.values()) * max(len(ls) - 1, 0), "(O14) pathwise")
    p = sum(pr for pr, ls in fields if ls)
    if p > 0:
        nu = {l: rq_pos(F(1, 50), 1, 50) for l in range(1, 7)}
        tot = sum(nu.values())
        nu = {l: v / tot for l, v in nu.items()}
        lhs = sum(abs(mm.get(l, 0) / p - nu[l]) for l in range(1, 7))
        rhs = excess / p + sum(abs(eta.get(l, 0) / p - nu[l]) for l in range(1, 7))
        g.check(lhs <= rhs, "(D20) triangle: ||m/p - nu|| <= E[(N-1)_+]/p + ||L^2 eta/p - nu||")
for nn in range(0, 60):
    g.check(0 <= max(nn - 1, 0) <= nn * (1 if nn >= 2 else 0), "(O13) first")
    g.check(nn - (1 if nn > 0 else 0) == max(nn - 1, 0), "(O13) second")
    g.check(2 * (1 if nn >= 2 else 0) <= nn * (1 if nn >= 2 else 0), "(O13) third")
g.close()

# =====================================================================
# L8  (D3): the change of variables tau = t^3 z, with perfect-cube z so that every quantity is rational
# =====================================================================
g = Group("L8 explicit density (D3)")
third = 1 if MUT == "JAC_NO_THIRD" else F(1, 3)
for _ in range(1500):
    c0 = rq_pos(F(1, 4), 1, 12)
    C0 = c0 + rq_pos(F(1, 12), 2, 12)
    kk = rq_pos(F(1, 2), 3, 12)
    while True:
        zc = rq_pos(F(1, 10), 1, 30)                  # z^(1/3)
        if zc**3 < kk:
            break
    z = zc**3
    # piecewise reciprocal count: D = D1 for t < tb, D2 for t >= tb, with a rational breakpoint
    tb = c0 + (C0 - c0) * rq_pos(F(1, 10), F(9, 10), 10)
    D1, D2 = RNG.choice([1, 2]), RNG.choice([1, 2])
    for nmom in range(0, 4):
        # t-side: integral of t^4 (t^3 z)^n / D(t) dt
        e = 3 * nmom + 5
        lhs = z**nmom * ((tb**e - c0**e) / D1 + (C0**e - tb**e) / D2) / e
        # tau-side: integral of tau^n tau^(2/3)/(3 z^(5/3)) / D(t_tau) over (c0^3 z, C0^3 z); antiderivative
        # tau^(n+5/3)/(n+5/3), where (t^3 z)^(n+5/3) = t^(3n+5) z^(n+5/3) and z^(1/3) = zc
        def anti(tt):
            return tt**e * zc**(3 * nmom + 5) / (F(3 * nmom + 5, 3))
        rhs = third / zc**5 * ((anti(tb) - anti(c0)) / D1 + (anti(C0) - anti(tb)) / D2)
        g.check(lhs == rhs, "moment %d: t^4 dt = tau^(2/3)/(3 z^(5/3)) d tau with D read at t_tau" % nmom)
    tt = c0 + (C0 - c0) * rq(0, 1, 50)
    tau = tt**3 * z
    g.check((tau**2 / (27 * z**5)) == (tt**2 / (3 * z))**3, "(tau^(2/3)/(3 z^(5/3)))^3 = (t^2/(3z))^3")
    g.check(c0**3 * z < tau or tt == c0, "support: tau > c0^3 z > 0")
    g.check(tau <= C0**3 * z < C0**3 * kk, "support inside (0, C0^3 k_+)")
    jm = rq_pos(F(1, 100), C0**3 * kk, 100)
    if jm <= tau < C0**3 * z:
        g.check(z > jm / C0**3, "on J every contributing z exceeds j_-/C0^3")
g.close()

# =====================================================================
# L9  (D17) tail inclusion, (D12) kernel triangle, and variation from a countable algebra
# =====================================================================
g = Group("L9 tail inclusion and kernel variation")
for _ in range(3000):
    kl = rq_pos(F(1, 10), 1)
    kh = kl + rq_pos(F(1, 10), 2)
    k = kl + (kh - kl) * rq(0, 1, 50)
    T = rq_pos(F(1, 10), 5)
    eta = [rq(-6, 6) for _ in range(4)]
    keta = [k * x for x in eta]
    l1n, l1k = sum(abs(x) for x in eta), sum(abs(x) for x in keta)
    lin, lik = max(abs(x) for x in eta), max(abs(x) for x in keta)
    l2n, l2k = sum(x * x for x in eta), sum(x * x for x in keta)      # squared Euclidean norms
    if l1n > T:
        g.check(l1k > kl * T, "l1: |eta| > T implies |k eta| > k_- T")
    if lin > T:
        g.check(lik > kl * T, "max norm: |eta| > T implies |k eta| > k_- T")
    if l2n > T * T:
        g.check(l2k > (kl * T) ** 2, "l2: |eta| > T implies |k eta| > k_- T")
for _ in range(400):
    nk = RNG.randint(1, 5)
    wts = [rq_pos(F(1, 10), 2) for _ in range(nk)]
    s1 = [{l: rq(0, 2, 20) for l in range(5)} for _ in range(nk)]
    s0 = [{l: rq(0, 2, 20) for l in range(5)} for _ in range(nk)]
    lhs = sum(abs(sum(w * (a[l] - b[l]) for w, a, b in zip(wts, s1, s0))) for l in range(5))
    rhs = sum(w * sum(abs(a[l] - b[l]) for l in range(5)) for w, a, b in zip(wts, s1, s0))
    g.check(lhs <= rhs, "(D12): ||int sigma_i - int sigma_0|| <= int ||sigma_i - sigma_0||")
    # a signed discrete measure: |nu|(R) is attained by a two-set partition {A, A^c} with A a finite union of
    # small rational intervals around the positive atoms
    atoms = sorted(set(rq(-5, 5, 8) for _ in range(6)))
    nu = {x: rq(-2, 2, 9) for x in atoms}
    tvn = sum(abs(v) for v in nu.values())
    A = [x for x in atoms if nu[x] > 0]
    dl = F(1, 32)
    inA = lambda y: any(x - dl < y <= x + dl for x in A)
    g.check(abs(sum(v for x, v in nu.items() if inA(x))) + abs(sum(v for x, v in nu.items() if not inA(x))) == tvn,
            "variation from the countable algebra of rational intervals")
g.close()


# =====================================================================
# L10  the diagonal step: positive rescaling preserves maximin; ELDER E(1) sanity on fixture A (grid)
# =====================================================================
def maximin(vals, nx, ny, M):
    """Largest level l such that M connects inside {f >= l} to a vertex above f(M) (4-neighbour grid)."""
    order = sorted(range(nx * ny), key=lambda i: -vals[i])
    parent = list(range(nx * ny))
    high = [vals[i] > vals[M] for i in range(nx * ny)]
    added = [False] * (nx * ny)

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    for i in order:
        added[i] = True
        x, y = divmod(i, ny)
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            xx, yy = x + dx, y + dy
            if 0 <= xx < nx and 0 <= yy < ny and added[xx * ny + yy]:
                a_, b_ = find(i), find(xx * ny + yy)
                if a_ != b_:
                    parent[a_] = b_
                    high[b_] = high[b_] or high[a_]
        if added[M] and high[find(M)]:
            return vals[i]
    return None


g = Group("L10 rescaling and maximin")
for _ in range(150):
    nx, ny = 7, 7
    vals = RNG.sample(range(-200, 200), nx * ny)
    vals = [F(v) for v in vals]
    locmax = [i for i in range(nx * ny)
              if all(vals[i] > vals[(i // ny + dx) * ny + (i % ny + dy)]
                     for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))
                     if 0 <= i // ny + dx < nx and 0 <= i % ny + dy < ny) and vals[i] < max(vals)]
    if not locmax:
        continue
    M = RNG.choice(locmax)
    d0 = maximin(vals, nx, ny, M)
    b = vals[M]
    c = -rq_pos(F(1, 10), 3) if MUT == "NEG_SCALE" else rq_pos(F(1, 10), 3)
    vt = [b + c * (v - b) for v in vals]
    d1 = maximin(vt, nx, ny, M)
    g.check(d0 is not None and d1 is not None and d1 - b == c * (d0 - b), "d_(b+c(f-b))(M) - b = c (d_f(M) - b)")
# ELDER E(1) on fixture A, sampled on the 1/40 grid of [-3,3]^2 (integer-scaled values, exact on the grid)
N = 40
nx = ny = 6 * N + 1
ivals = []
for i in range(nx):
    X = i - 3 * N
    for j in range(ny):
        Zj = j - 3 * N
        # 20 N^3 P(X/N, Z/N) for fixture A (k=1, a=0, beta=-3, s=-21/10, q=3/5) is an integer
        ivals.append(40 * X**3 - 30 * X * N * N - 10 * N**3 - 21 * Zj * Zj * N - 30 * X * Zj * Zj + 2 * Zj**3)
Mi = (-N // 2 + 3 * N) * ny + 3 * N
dgrid = maximin(ivals, nx, ny, Mi)
hgrid = F(dgrid, 20 * N**3)
g.check(abs(hgrid - F(-23, 320)) < F(1, 100), "grid maximin from M0 is within 0.01 of h_* = -23/320 (Theorem E(1))")
g.check(hgrid > -1 + F(1, 2), "the death is not through the pinned saddle (height -1)")
for kq in (F(1, 2), F(3, 2), F(7, 3)):
    dk = maximin([kq * v for v in ivals], nx, ny, Mi)
    g.check(dk == kq * dgrid, "maximin of k P is k times maximin of P on the same grid")
g.close()

# ---------------------------------------------------------------------
total = sum(t for _, _, t in RESULTS)
passed = sum(p for _, p, _ in RESULTS)
for name, p, t in RESULTS:
    print("%-44s %6d/%-6d %s" % (name, p, t, "PASS" if p == t else "FAIL"))
print("grid maximin on fixture A: %s = %.6f (h_* = -23/320 = -0.071875)" % (hgrid, float(hgrid)))
print("mutant: %s" % (MUT if MUT else "none"))
print("total checks: %d; failures: %d" % (total, total - passed))
for f_ in FAILS:
    print("  FAIL " + f_)
sys.exit(0 if passed == total else 1)
```

```text
L0 frame, ledgers, one normalizer              2406/2406   PASS
L1 coupling affine in k (D5)-(D6)               240/240    PASS
L2 scaling, homogeneity, R1 identities        21856/21856  PASS
L3 fixtures, count D, rays, inverse            2423/2423   PASS
L4 envelope and lifetime map (decimal)          164/164    PASS
L5 pushforward lemma (D10)-(D11)                986/986    PASS
L6 global L1 inequality (D18a)                  803/803    PASS
L7 occurrence excess (D19)-(D20)              11484/11484  PASS
L8 explicit density (D3)                      10602/10602  PASS
L9 tail inclusion and kernel variation         9441/9441   PASS
L10 rescaling and maximin                       155/155    PASS
grid maximin on fixture A: -23/320 = -0.071875 (h_* = -23/320 = -0.071875)
mutant: none
total checks: 60560; failures: 0
```

🤖 Generated with [Claude Code](https://claude.com/claude-code)


---
_Generated by [Claude Code](https://claude.ai/code)_
