<!-- Math- PR #387 body as served 2026-10-06T17:27:38Z (updated 2026-10-06T18:43:06Z), head e950f0eef3586d5a7aae64fd491adfa84ba82176, 6452 UTF-8 bytes, SHA-256 038eb96f30c7ee9df1bd6833f9633ad525b7c24c0c0bfba0519f30ffc80292e0; copied verbatim from the GitHub API -->
## Lifetime note TS packet: the note, its controls, three slice reads, the AMEND successor text and its readback (custody only)

**Scientific effect: NONE.** This is custody only. No proof byte changes, and no status, register, graph, `lemma_closed`, prize or premise surface is touched. Author: Anthropic Claude (session `session_01NMeKEismAyeqgdB4sy2NJU`), for Dylan Roy (delegated AI work). The author of the stored note is the same lane, so organizational-independence credit is 0 for every read listed. Claim per D5: [6021671402](https://github.com/d6g8k5htny-coder/main/issues/229#issuecomment-6021671402).

### Disposition

- **Head:** `e950f0eef3586d5a7aae64fd491adfa84ba82176` on `claude/ts-small-kappa-packet-20261006` (owner: this lane). It is one commit on `main` `665f744a`.
- **Completed review scopes.** The note's mathematical reads are stored here and are not re-opened. Each is by a Cursor cloud agent running xAI Grok 4.7, summoned under D2 of [6002718035](https://github.com/d6g8k5htny-coder/main/issues/229#issuecomment-6002718035):
  - Slice B (§2): **PASS**, `bc-fc3c840f…` ([6020812551](https://github.com/d6g8k5htny-coder/main/issues/229#issuecomment-6020812551));
  - Slice C (§§3–4): **PASS**, `bc-13c209f1…` ([6020820817](https://github.com/d6g8k5htny-coder/main/issues/229#issuecomment-6020820817));
  - Slices A–D (§1, §0, §§5–7): **AMEND**, `bc-2bf93428…` ([6020822268](https://github.com/d6g8k5htny-coder/main/issues/229#issuecomment-6020822268)). It found one false comparison in §1 Step 2; no constant, exponent or stated bound changes.
  - The author applied the AMEND exactly as successor text ([6021299833](https://github.com/d6g8k5htny-coder/main/issues/229#issuecomment-6021299833) §2). Its readback is **PASS**, `bc-8e7c19e7…` ([6021301151](https://github.com/d6g8k5htny-coder/main/issues/229#issuecomment-6021301151)). The read-complete note is [6021671402](https://github.com/d6g8k5htny-coder/main/issues/229#issuecomment-6021671402).
- **Engineering read of this delta: PASS** at the frozen head, by a Cursor cloud agent running xAI Grok 4.7, `bc-453d337f…` (pickup [6021767477](https://github.com/d6g8k5htny-coder/Math-/pull/387#issuecomment-6021767477), verdict [6021834784](https://github.com/d6g8k5htny-coder/Math-/pull/387#issuecomment-6021834784); its acknowledgement [6021755279](https://github.com/d6g8k5htny-coder/Math-/pull/387#issuecomment-6021755279) was edited to the same PASS). It checked all six items of the request [6021753290](https://github.com/d6g8k5htny-coder/Math-/pull/387#issuecomment-6021753290), with no finding.
- **Unresolved finding IDs:** none.
- **Validation (author replay, not a review):**
  - `replay.py` passes in both interpreter modes: `16 stored identities, 2 extractions, 1 checker stdouts, 10 mutants, 3 invalid invocations and 2 negative controls PASS`.
  - The protocol and raw-evidence suites pass in both modes, 13 + 13 tests.
  - The repository tests `test_proof_reachability`, `test_navigation_links` and `test_downstream_validation` pass.
  - The builder reproduces the packet byte for byte.
  - CI at `e950f0ee`: `math-downstream-gates`, `downstream-replay`, `formal / formal-evidence`, both `replay` modes and `exact-and-probe` all succeed.
- **Next action.** Integration by a non-author lane, under the expected-head guard (merge commit), with a fresh check run if the base has moved. The author does not merge and does not push while an integration pickup is open.

### What changes (all new files)

| Path | Content |
|---|---|
| `frontiers/ts_small_kappa_20261006/TS/` (16 files) | Every record of note TS, as an exact comment body (see the list below the table). Also `author_controls.py` (`ts_exact.py`, 20,043 B, `0337e78c…`) and `author_controls_stdout.json` (185 B, `f5d11868…`), extracted from the controls comment by its stated fence rule. |
| `SOURCES.json` | One object with its identities, the reads as recorded, the successor text to read the note with, the conditionality, `not_claimed` and `organizational_independence: 0`. It also gives the extraction rule, the related packets and the exclusions (routing, and the author-side referee reports). |
| `replay.py` | Math-#384's TL packet replay (`frontiers/tl_soft_layer_20261006/replay.py` at `6b4c70e9`), with this packet's docstring and paths. It carries 13 exact rejection fingerprints (`(exit, stdout SHA-256, stderr SHA-256, reason)`) for 10 mutants and 3 invalid invocations; all were computed under both modes and are identical. Its negative controls are a one-byte change to `TS/PROOF.md`, and S3's constant `C₄ = 131 → 130`, which must fail exactly at `S3_constants`. |
| `README.md` | The packet's statement, reads table, the amendment of record, paraphrase, limits and replay. |
| `tests/test_ts_small_kappa_replay_protocol.py`, `tests/test_ts_small_kappa_replay_evidence.py` | #384's two test files, with this packet's paths, inventory count (13) and negative-control fixture. |
| `.github/workflows/ts-small-kappa.yml` | #384's workflow, with this packet's paths and display name. |

The comment bodies stored in `TS/`:
- the claim 6019827162 and the main#259 pickup 6019832792;
- the frozen note 6020794123 (52,499 B, `add203d6…`) and the controls comment 6020799284 (24,674 B, `3bc78b5e…`);
- the read request and summonses 6020811116, 6020819748 and 6020820922, and the main#259 pointer 6020826510;
- the three verdicts, the successor text 6021299833, its readback 6021301151, and the read-complete note 6021671402.

### Notes for the reader

- **Checking the differences mechanically.** Compare `replay.py`, the two tests and the workflow against their TL counterparts at #384's head `6b4c70e9`. Apart from the contract table, only the paths, names, docstring lines and the negative-control block differ.
- **The successor text.** The stored note body is the frozen one. `SOURCES.json` (`read_with`) and the README say that it is to be read with the successor text, which changes three comparisons in §1 and no result.
- **No other packet is edited.** In particular, #229's and #220's bounds of record are untouched. Note TS's improvement is recorded only as a stored, read note. TS cites note TL by its comment, so this PR has no file dependency on #384.

🤖 Generated with [Claude Code](https://claude.com/claude-code)

https://claude.ai/code/session_01NMeKEismAyeqgdB4sy2NJU


---
_Generated by [Claude Code](https://claude.ai/code)_
