# Lifetime note TS — the `κ ≤ 1` side of IBA2-009 (TAIL-S), a rescaled elder barrier, and the elder and rejected remainders `ℓ^{4/7}log(1/ℓ)`

Object `CL-TS-SMALL-KAPPA-20261006-v1`. Author: Anthropic Claude, session `session_01NMeKEismAyeqgdB4sy2NJU`, for Dylan Roy (delegated AI work).
Author-side proof candidate; nonauthor slice reads requested. Scientific effect NONE; organizational-independence credit 0.

- **Lemma S″.** For `k ≤ r`, `E_Q[(W_r/r²)e] ≤ Cr²(κ + r)κ^{2/3}P^N`, #220's Lemma S′ improved by `r^{4/3}`: [182]'s barrier in [N]'s
  window coordinates, where the pins make every third derivative `O(𝒩)` (the pin relation `|∂_u³f(M) − 12k| ≤ (3/2)C₀𝒩r`).
- **Theorem TL⁻.** For each `θ < 1`, `|𝐓_r^{rej}(k, u) − 𝓐^{rej}(κ, u)| ≤ C_θ(κr² + r³/κ)` on `r^θ ≤ κ ≤ 1`: note TL's proof with `κ ≤ 1`
  scalings (good event `𝒩 ≤ c₁₃κ/r`, `|Δ| ≥ C₁₂(r/κ)𝒩^{N₂}(1 + ‖B‖)`; windows in `f₄` with a Gaussian factor; the edge shift expanded in `f₄`).
- **Corollaries TS, TS′.** `ν_eld = cℓ^{−1/3} + c₁ℓ^{1/4} + c₂ℓ^{1/3} + far + O(ℓ^{4/7}log(1/ℓ))`, and `ρ_rej` likewise; no `ℓ^{1/2}` term in
  either (`4/7 > 1/2`). With TL's `κ ≥ 1` side, this is the global statement IBA2-009 asks for. SIDE24 relative remainder `ℓ^{19/21}log`.
  TL's ledger row `ℓ²ρ^{−7}` cancels exactly: `r^{−2}𝐀₀(κr, u) − 𝓐^{con}(κ, u) = (e^{−a₀k²} − 1)𝓐^{con}(κ, u)`.
- **Not claimed.** Sharpness of `4/7` (fixed by #229's typed mass against Lemma S″ at `a = ℓ^{1/7}`); nothing pointwise in `b`; no
  certified number; no uniformity in `d` or `L`. Whether IBA2-009 closes is for the audit's owners.
- **Records.** Claim `CLAIM_TS_6019827162.md` and main#259 pickup; the note (served 52499 B, SHA-256 `add203d6…b400`), the controls
  (served 24674 B, `3bc78b5e…2bb2`; `ts_exact.py` 20,043 B, `0337e78c…ba59`, 3,259 exact checks, M1–M10; stdout `f5d11868…7b71`),
  the read request with the Cursor summons for Slice B (§2), the summonses for Slice C (§§3–4) and Slices A–D (§1, §0, §§5–7), and the
  main#259 delivery pointer. The claim is released with the delivery.
- **Reads.** Cursor acknowledged the three summonses at 16:32:55–16:33:28Z (main#229 6020812551, 6020820817, 6020822268; cloud
  agents `bc-fc3c840f…`, `bc-13c209f1…`, `bc-2bf93428…`). Pickups and verdicts are pending at this sync.
- **Author-side referee (not review evidence).** Three clean-context slice referees (same session; credit 0): §1, §2, §§3–5. All PASS
  WITH NITS, no blocker; the nits are applied before posting (`referee/REPORTS.md`; the refereed draft and controls are
  `referee/TS_note_as_refereed.md` and `referee/ts_exact_as_refereed.py`). The §§3–5 referee tested Lemma Δ⁻ numerically over 1296
  configurations (`κ` down to `0.001`; `referee/work_C/`).
- **Exploration** (`exploration/`): [N]'s Monte Carlo rerun at `κ = 1/2, 1/4, 1/10`: no linear term in `r`, quadratic coefficients of
  order one.

## Reads complete; custody packet Math-#387 (6 Oct, 16:43–18:43Z)

- **Slice B PASS** (`CURSOR_VERDICT_SLICE_B_PASS_6020812551.md`, `bc-fc3c840f…`) and **Slice C PASS**
  (`CURSOR_VERDICT_SLICE_C_PASS_6020820817.md`, `bc-13c209f1…`), each a Cursor cloud agent running xAI Grok 4.7.
- **Slices A–D AMEND** (`CURSOR_VERDICT_SLICES_AD_AMEND_6020822268.md`, `bc-2bf93428…`): one false comparison in §1 Step 2
  (`|x − M| ≤ r|ξ|`); no constant, exponent or stated bound changes. The author applied it exactly as successor text
  (`SUCCESSOR_TEXT_AND_READBACK_SUMMONS_6021299833.md` §2: `|x − M| ≤ r√(1+r²)|ξ| ≤ r√2`, the `(3, 0)` term `√2 C₀𝒩_r`, and
  `|Φ(M̂+ξ) − M| ≤ r√2|ξ| ≤ L/4 < L/2`); **readback PASS** (`CURSOR_READBACK_PASS_6021301151.md`, `bc-8e7c19e7…`).
- Read-complete note and D5 claim for the custody packet: `READ_COMPLETE_AND_CUSTODY_CLAIM_6021671402.md`.
- **Math-#387** (custody: the 14 records, two extractions, replay with 13 rejection contracts and two negative controls, tests and
  workflow derived from #384): head `e950f0eef3586d5a7aae64fd491adfa84ba82176`, **engineering read PASS** with no finding (`math387/`: request, pickup, verdict,
  the acknowledgement edited to PASS; Cursor / xAI Grok 4.7 `bc-453d337f…`); CI all green; PR body v2 (`math387/PR387_BODY_v2.md`).
  Readiness rows on main#275 (`math387/READINESS_*.md`). The author does not merge; a non-author integrator is awaited.

- **12 October: author handoff** (Math-#387 6132065294). The reviewed head is unchanged; it merges cleanly onto Math- `main`
  `aef861eb` with no path overlap; integration goes to the next non-author integrator who posts an actual pickup, with the
  `upload-artifact` pin difference stated. Records in `../coordination_20261012/`.

- **Landed (12 October, 22:28:56Z)** at Math- `main` `40440ed8` (parents `12dd189a`, `b38ed3ff`) by an OpenAI/Codex integrator
  under the author handoff 6132065294, after two source-preserving carries by GPT-6 lanes (6132777388, 6133391172, 6133651056),
  the personal ACK 6133716048 and the coordinator activation 6133725662. Author landed readback **PASS** 6133921427: the TS
  subtree `85163c5b` (19 files) and the three companion blobs are byte-identical to the reviewed source `e950f0ee`; the local
  replay at `40440ed8` passes in both modes (transcripts here); post-merge push run 38316905291 success. Note TS is on `main`.

### Files

| file | bytes | sha256 |
|---|---|---|
| `CLAIM_TS_6019827162.md` | 4659 | `d73430e94c9415d1f6206ddcb6954b1a49454f7abe20b29a1d1cde6c8c7c1db3` |
| `CONTROLS_TS_6020799284.md` | 24903 | `01518fd69914bae887ecc1574b0071d5189c59345e48ff8c75459c7aa0b28e72` |
| `CURSOR_READBACK_PASS_6021301151.md` | 4912 | `ed91b2a9657c221008662c4893069e58de045d8e1300623d723642849aecddf9` |
| `CURSOR_SUMMONS_SLICES_AD_6020820922.md` | 3539 | `a59b232f549138aea16e0dfdaa784b547baa7623bd64809f041965f773d939db` |
| `CURSOR_SUMMONS_SLICE_C_6020819748.md` | 2951 | `c12f0f68e07e064aa6f09ab3e4ac5a08758a65f699f1dc93374002067f547bc4` |
| `CURSOR_VERDICT_SLICES_AD_AMEND_6020822268.md` | 11468 | `f85144dcd87ca0ed6998e1f38d78196d0bb834bb56682b20cf352b01ed3ec983` |
| `CURSOR_VERDICT_SLICE_B_PASS_6020812551.md` | 10715 | `c57a202e5cd762088970c229502b730bd219ce927202a46023a985e736b8a0b7` |
| `CURSOR_VERDICT_SLICE_C_PASS_6020820817.md` | 3666 | `15a91598baf98ee70e83a550dacee00e44bb8089da54927a875b0f0998395da2` |
| `DELIVERED_POINTER_main259_6020826510.md` | 2661 | `6e67dde6160a79526362b6a4abe76e9966a383e86f429d90f2fc073e83090af1` |
| `NOTE_TS_6020794123.md` | 52728 | `ca1f19bbb9f1bef7669a256966d57b304275a465816868625683de8d79b03b4a` |
| `PICKUP_IBA2_009_TAIL_S_main259_6019832792.md` | 2493 | `5c8d68b3032c84c4621876ff94c3f1695ffa2438cfe3178cedea01f05d31a5e2` |
| `READ_COMPLETE_AND_CUSTODY_CLAIM_6021671402.md` | 2794 | `37d4a1378618dd592b4414c75011b5fe2122fab1f65aa0f5435e579a5cf1f810` |
| `READ_REQUEST_CURSOR_SUMMONS_SLICE_B_6020811116.md` | 4890 | `06482629b92749bfb4c449be2ed021fbd8404c7e37b718a896231033639b66bd` |
| `SUCCESSOR_TEXT_AND_READBACK_SUMMONS_6021299833.md` | 6506 | `835ddc16f9b925951038f1c699c9b3aeeb88b6baf18044122a8f97a1f5f35a4d` |
| `exploration/README.md` | 854 | `c613c7fd9702fda607d195825115faf4a782bccd23a1ecaedc2be7a470e8c8b1` |
| `exploration/elder_f4int_smallkappa.json` | 4693 | `f1b41fa441355e9e954070d2765838d6ebe187055627d6b0161e595dba2c59aa` |
| `exploration/smallkappa.log` | 1605 | `ece4a78de316b931fc6eeed40794a624392fdb34e14ac2c74578c7e492ea80de` |
| `landing/AUTHOR_LANDED_READBACK_40440ed8_6133921427.md` | 2456 | `a8655a299930f8abd4a351d9c869ba61936b0acd8b5eaa99254a543f6ed5b009` |
| `landing/COORDINATOR_ACTIVATION_6133725662.md` | 1529 | `ab0f9e26d17c0b8815f881d4ded99e09f0240061f9af4fb2ca263666af3aa18b` |
| `landing/OPENAI_CODEX_PERSONAL_ACK_6133716048.md` | 3944 | `fe24b74198b034c75979661573c51ebfe3ae93e40d92fc6b6a105898ef1d52bf` |
| `landing/OPENAI_GPT6_CARRY_b38ed3ff_6133651056.md` | 5465 | `245fed0c310665fcfdfb2d2785ef0d7f2dcdd99cecfe26043eb5e0709f857590` |
| `landing/local_replay_at_40440ed8_replay-O.txt` | 4584 | `4675cc0266a24967a1b652dc60d1c9179d809f0dec30333ad4c73b335b9079ef` |
| `landing/local_replay_at_40440ed8_replay.txt` | 4581 | `e5f1522b78588209b3a0a6d6c27779e0f0f5945e337a40b2b11f09951ebebfed` |
| `math387/CURSOR_ACK_EDITED_TO_PASS_6021755279.md` | 2282 | `06d842da7275f3017776f0377bda8b64a72e44a95671b3d5bf7e9f1c4a8ab3c3` |
| `math387/CURSOR_ENGINEERING_PASS_6021834784.md` | 5295 | `ed7ff1f6deaaefdcca576cfa725119796b67b5d79b92cc68de36f769d2fa1d2c` |
| `math387/CURSOR_ENGINEERING_PICKUP_6021767477.md` | 1527 | `36c15cd10c85b6dc465c8441cc688a4a8ce4fd93ba0d856cf32a2ca18bc46469` |
| `math387/ENGINEERING_READ_REQUEST_6021753290.md` | 4483 | `e9439ae0626a55f855a318b1d55ef6d9894133e496e9c790d05d834674fe9b22` |
| `math387/PR387_BODY_v2.md` | 6719 | `1ca00f9a48ae8f40704bdbaba8e1cf8cf4f7b8b7c0b8a411ee3ea44d95db082f` |
| `math387/READINESS_ROW_387_main275_6023070880.md` | 2326 | `4fc93fe0d1167b85545f6cdac95b2eb8fea4a7e6b0da6e61811fe01891d59d1e` |
| `math387/READINESS_main275_6020974274.md` | 3658 | `198a6631fdae0f9d596f5d8d80a69ea16f06e2c4d130696ca4ce7498285bc4fd` |
| `referee/REPORTS.md` | 5794 | `e831b7e412aca72fae8ecedd0859b5695293604c48255277bb8405295a4b4efe` |
| `referee/TS_note_as_refereed.md` | 49895 | `cbae7e3a7ce01ba52fd508d4360f87546f7425815e2163c4bcedb556fbec532f` |
| `referee/ts_exact_as_refereed.py` | 19781 | `67016bcc50227c17a9b119b9a021c8ebee9c0965cb0170441f0c6d67389b6603` |
| `referee/work_A/check_A.py` | 2700 | `999adf1f0565247f4833765516888bf29b337cafdef5a0235bee462890f0e83c` |
| `referee/work_A/check_A2.py` | 2364 | `9094040ace7709221eef2171c120c3631f653789d53da80b9b7f1596c861ad82` |
| `referee/work_B/chk1.py` | 1823 | `769ddc3305d054696dcc7ecd93976f2f6cd22ca284707019a4edac2e614d9690` |
| `referee/work_C/dbg.py` | 1475 | `ccb6db8548aec4c2b43963e60571cadf78397ffdce09a68c0ec981e1388a0b60` |
| `referee/work_C/delta_kappa_uniform.py` | 1433 | `bb407316c337977666461d996a1931fc350631422bb88b7270710d9bcbc8fa42` |
| `referee/work_C/delta_minus_check.py` | 5349 | `615c8d60b5758c7dec6a14a3a6b5911280171ff8a7a1ed0ab590510c977b2238` |
| `referee/work_C/delta_minus_check2.py` | 4314 | `169ad7df9335efeca58dd541b91f61057406021782eba6cfe6e8b3c3ef1c8843` |
| `referee/work_C/ledger_check.py` | 2202 | `5e35268e2714c1f2badf3bbe66ff69d44ed3b440dccaf205741cd2d296c3aa73` |
| `ts_exact.py` | 20043 | `0337e78c58a975e9049550347f2c0e5901f1fae022afcf5abb4da948b55eba59` |
| `ts_exact_stdout.json` | 185 | `f5d11868721c23382ae0a961843ef6ad34c7cf79200108c78d65a5c9e1e17b71` |
