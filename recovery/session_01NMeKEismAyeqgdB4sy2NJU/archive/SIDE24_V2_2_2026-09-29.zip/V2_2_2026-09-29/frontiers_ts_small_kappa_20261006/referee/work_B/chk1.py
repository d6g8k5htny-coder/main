import numpy as np
rng = np.random.default_rng(1)
worst = {}
def upd(k, v):
    worst[k] = max(worst.get(k, -np.inf), v)
for m in (1, 2, 3, 4):
    for _ in range(20000):
        X = rng.normal(size=(m, m)); A = -(X @ X.T) - rng.uniform(1e-4, 2) * np.eye(m) * rng.uniform(0, 1)
        ev = np.linalg.eigvalsh(A)
        if ev.max() >= 0: continue
        lam = -ev.max(); nA = np.abs(ev).max()
        g = rng.normal(size=m) * rng.uniform(0, 5)
        Y = rng.normal(size=(m, m)); B = (Y + Y.T) / 2
        eta = rng.normal(size=m); f5 = rng.normal()
        Ai = np.linalg.inv(A); D = np.linalg.det(A)
        q = g @ Ai @ g; Gt = np.linalg.norm(Ai @ g)
        Q1 = f5/120 - eta @ Ai @ g/12 + g @ Ai @ B @ Ai @ g/8
        nB = np.abs(np.linalg.eigvalsh(B)).max()
        # TL (1.1) for j = 0, 1/2, 1, 3/2, 2
        for j in (0, .5, 1, 1.5, 2):
            upd(f"(1.1) j={j}", D**2 * Gt**(2*j) / (lam**(2-j) * abs(q)**j * nA**(2*m-2)) if q != 0 or j == 0 else 0)
        # (2.2-) with the explicit constants from |Q1| <= |f5|/120 + |eta|Gt/12 + |B|Gt^2/8 (Cauchy-Schwarz factor 3)
        rhs1 = 3 * nA**(2*m-2) * (lam**2 * f5**2 / 120**2 + np.dot(eta, eta) * abs(q) * lam / 144 + nB**2 * q**2 / 64)
        upd("(2.2-) first", D**2 * Q1**2 / rhs1)
        rhs2 = nA**(2*m-2) * (lam**2 * abs(f5) / 120 + np.linalg.norm(eta) * abs(q)**.5 * lam**1.5 / 12 + nB * abs(q) * lam / 8)
        upd("(2.2-) second", D**2 * abs(Q1) / rhs2)
        # |Delta_B| = |tr(adj(A) B)| <= m |A|^{m-1} |B|
        J = D * Ai
        upd("Delta_B", abs(np.trace(J @ B)) / (m * nA**(m-1) * nB))
for k, v in worst.items():
    print(f"{k:16s} max ratio = {v:.6f}  (must be <= 1)")
# r^{1/2} log(2/r) on (0, 1/10]
r = np.linspace(1e-9, 0.1, 200001)
print("max r^{1/2}log(2/r) on (0,0.1] =", (np.sqrt(r) * np.log(2 / r)).max(), "(need <= 2)")
