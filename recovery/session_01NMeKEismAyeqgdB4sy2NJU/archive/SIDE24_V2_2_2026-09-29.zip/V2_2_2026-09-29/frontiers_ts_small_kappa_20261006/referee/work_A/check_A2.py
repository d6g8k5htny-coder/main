"""Pinned polynomial fields in d = 2: sup over |xi| <= 1 of the window third partials, as r -> 0."""
import random
import sympy as sp
import itertools

x, y = sp.symbols('x y', real=True)
X, Xi = sp.symbols('X Xi', real=True)


def pinned_field(r, k, b, free):
    # monomials x^i y^j, i + j <= 6; pinned unknowns: c00, c10, c20, c30, c01, c11
    cs = {}
    unknowns = sp.symbols('c00 c10 c20 c30 c01 c11')
    pinned_idx = [(0, 0), (1, 0), (2, 0), (3, 0), (0, 1), (1, 1)]
    f = 0
    for i in range(7):
        for j in range(7 - i):
            if (i, j) in pinned_idx:
                f += unknowns[pinned_idx.index((i, j))] * x**i * y**j
            else:
                f += free[(i, j)] * x**i * y**j
    M = {x: -r / 2, y: 0}
    S = {x: r / 2, y: 0}
    eqs = [f.subs(M) - b, f.subs(S) - (b - k * r**3),
           sp.diff(f, x).subs(M), sp.diff(f, x).subs(S),
           sp.diff(f, y).subs(M), sp.diff(f, y).subs(S)]
    sol = sp.solve(eqs, unknowns, dict=True)[0]
    return sp.expand(f.subs(sol))


random.seed(7)
free = {(i, j): sp.Rational(random.randint(-30, 30), 10) for i in range(7) for j in range(7 - i)}
b = sp.Rational(1, 3)
for kappa in (sp.Rational(1), sp.Rational(1, 10)):
    for r in (sp.Rational(1, 5), sp.Rational(1, 20), sp.Rational(1, 100), sp.Rational(1, 500)):
        k = kappa * r
        f = pinned_field(r, k, b, free)
        Fw = sp.expand((f.subs({x: r * X, y: r**2 * Xi}) - b) / r**4)
        # third partials on the unit disc around Mhat = (-1/2, 0), sampled on a polar grid
        thirds = [sp.lambdify((X, Xi), sp.diff(Fw, X, a, Xi, 3 - a)) for a in range(4)]
        mx = [0.0] * 4
        for ri in [i / 8 for i in range(9)]:
            for th in [2 * 3.14159265 * j / 24 for j in range(24)]:
                import math
                px, py = -0.5 + ri * math.cos(th), ri * math.sin(th)
                for a in range(4):
                    mx[a] = max(mx[a], abs(thirds[a](px, py)))
        d3M = float(sp.diff(f, x, 3).subs({x: -r / 2, y: 0}))
        print(f"kappa={float(kappa):5.2f} r={float(r):7.4f}  |d_u^3 f(M)-12k|/r={abs(d3M - 12 * float(k)) / float(r):7.3f}"
              f"  sup|(3,0)|={mx[3]:8.3f} sup|(2,1)|={mx[2]:7.3f} sup|(1,2)|={mx[1]:7.3f} sup|(0,3)|={mx[0]:7.3f}")
print("f4 coefficient term: d_u^4 f(0) =", float(24 * free[(4, 0)]), " (expect |d_u^3 f(M) - 12k|/r -> |f4|/2 as r -> 0)")
