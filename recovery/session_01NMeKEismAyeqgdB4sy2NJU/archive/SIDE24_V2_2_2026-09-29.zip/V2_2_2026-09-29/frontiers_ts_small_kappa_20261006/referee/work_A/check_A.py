"""Referee A independent checks for TS note section 1 (Lemma S'')."""
import sympy as sp
import random

t, r, k, b, s = sp.symbols('t r k b s', real=True)

# ---- (1.1) via Peano kernel ----
# g'''(0) - 12k = 12 (R4 - r R3'/2) / r^3, R4 = int_0^r (r-t)^3/6 g'''' dt, R3' = int_0^r (r-t)^2/2 g'''' dt
ker = (r - t)**3 / 6 - r * (r - t)**2 / 4
print("kernel factored:", sp.factor(ker))          # expect -(r-t)^2 (r+2t)/12 (sign-definite on [0,r])
mass = sp.integrate(sp.Abs(ker).subs(sp.Abs(ker), -ker), (t, 0, r))
print("int |kernel| =", sp.simplify(mass))           # expect r^4/24
print("sharp constant 12*mass/r^3 / r =", sp.simplify(12 * mass / r**4))   # expect 1/2  (note uses 3/2)
print("note's crude constant 12*(1/24 + 1/12) =", sp.Rational(12) * (sp.Rational(1, 24) + sp.Rational(1, 12)))

# exact identity on a generic pinned sextic profile
a2, a3, g4, g5, g6 = sp.symbols('a2 a3 g4 g5 g6')
g = b + a2 * t**2 + a3 * t**3 + g4 * t**4 + g5 * t**5 + g6 * t**6
sol = sp.solve([g.subs(t, r) - (b - k * r**3), sp.diff(g, t).subs(t, r)], [a2, a3], dict=True)[0]
gp = g.subs(sol)
lhs = sp.diff(gp, t, 3).subs(t, 0) - 12 * k
g4f = sp.diff(gp, t, 4)
rhs = -12 * sp.integrate(sp.expand((r - t)**2 * (r + 2 * t) / 12 * g4f), (t, 0, r)) / r**3
print("pinned sextic identity holds:", sp.simplify(lhs - rhs) == 0)

# ---- chain rule scaling and D^2 F(Mhat) = Lambda^{-1} H Lambda^{-1} in d = 3 (generic cubic-quartic f) ----
x1, x2, x3, X, X1, X2 = sp.symbols('x1 x2 x3 X Xi1 Xi2', real=True)
random.seed(1)
mons = [x1**i * x2**j * x3**l for i in range(5) for j in range(5) for l in range(5) if i + j + l <= 4]
f = sum(sp.Rational(random.randint(-9, 9), random.randint(1, 5)) * m for m in mons)
# frame u = e1, Theta = (e2, e3); window map
Phi = {x1: r * X, x2: r**2 * X1, x3: r**2 * X2}
Fw = (f.subs(Phi) - b) / r**4
vars_w = [X, X1, X2]
vars_x = [x1, x2, x3]
ok = True
import itertools
for orders in itertools.product(range(4), repeat=3):
    if sum(orders) not in (2, 3):
        continue
    a, b1, b2 = orders
    dw = Fw
    for v, o in zip(vars_w, orders):
        dw = sp.diff(dw, v, o)
    df = f
    for v, o in zip(vars_x, orders):
        df = sp.diff(df, v, o)
    pred = r**(a + 2 * (b1 + b2) - 4) * df.subs(Phi)
    ok &= sp.simplify(sp.expand(dw - pred)) == 0
print("chain-rule scaling r^{a+2|beta|-4} verified for all orders 2,3:", ok)
# D^2 at M-hat = (-1/2, 0, 0) vs Lambda^{-1} H_M Lambda^{-1}
Mh = {X: sp.Rational(-1, 2), X1: 0, X2: 0}
Mx = {x1: -r / 2, x2: 0, x3: 0}
H2w = sp.hessian(Fw, vars_w).subs(Mh)
HM = sp.hessian(f, vars_x).subs(Mx)
Lam_inv = sp.diag(1 / r, 1, 1)
print("D^2 F(Mhat) == Lambda^-1 H_M Lambda^-1:", sp.simplify(H2w - Lam_inv * HM * Lam_inv) == sp.zeros(3, 3))
