# Note TS — author-side clean-context referee pass (not review evidence)

Same provider and session as the author (Anthropic Claude, `session_01NMeKEismAyeqgdB4sy2NJU`): three clean-context
subagents, one per slice, each given the refereed draft `TS_note.md` (sha256 `cbae7e3a…532f`), `ts_exact.py` (sha256
`67016bcc…6603`) and the cited sources, and asked for a bounded report. The subagents could not write report files;
these reports are transcribed by the author from their hand-backs on 2026-10-06 (~16:25Z). Their scratch scripts are in
`work_A/`, `work_B/` and `work_C/`.

| Slice | Scope | Verdict |
|---|---|---|
| A | §1 (Lemma S″), its statement in §0, the Comparison paragraph | PASS WITH NITS (6 nits) |
| B | §2 (Lemma W⁻, (2.2⁻), 𝔊⁻, Lemma GE⁻, Proposition RW⁻) | PASS WITH NITS (6 nits) |
| C | §§3–5 (Lemma Δ⁻, Steps 1–6, (5.0), Corollary TS and its ledger, TS′) | PASS WITH NITS (6 nits) |

## Slice A

No mathematical error. Findings (all NIT):
1. `C₀`: for `j = 9` the gradient is a derivative of order 10; limit the gradient clause to `j ≤ 8`.
2. `N₂` in §1 Step 4 is undefined there and clashes with §2's `N₂ = max(N₁, m − 1)`; §1 needs `N₂ ≥ m` and `≥ N₁`.
   Define it (it is #220's exponent) or rename it.
3. (1.1)'s constant `3/2` is correct but not sharp; the Peano kernel of `R₄ − rR₃′/2` is `−(r − t)²(r + 2t)/12`, of one
   sign, so the sharp constant is `1/2` (attained for constant `g⁗`).
4. Step 2 uses `|x − M| ≤ 2r`, Step 3 the sharper `|Φ(M̂ + ξ) − M| ≤ r|ξ| ≤ r`; use one bound.
5. `E` is an ellipsoid, a closed ball only topologically; `∂E = Φ(M̂ + ∂B(0, δ))` uses `E ⊂ B̄(M, r)` and that the
   projection `R^d → X` is injective and open on `B(M, L/2)`.
6. The Comparison integral needs `a ≥ ℓ^{1/4}` (so that `κ ≤ 1` on `[a, r_0^*]`).

Checked and fine: (1.1) re-derived and the identity confirmed in sympy; the chain-rule scaling for orders 2 and 3
(`d = 3`); `D²𝔉(M̂) = H̃`; the third-derivative bounds; the barrier (Taylor, `δ`, the crossing argument, [182] (2), `e = 1`);
(1.3)'s case split and `C₆`; Step 4 as #220's proof with `ε″`; (S″.2); the ratio `r^{4/3}`; all ranges; the controls
(S1, S2, mutants M1, M2, M3, M10).

## Slice B

No mathematical error; every `κ ≥ 1` step of TL's Lemma GE and Proposition RW correctly adapted to `0 < κ ≤ 1`.
Findings (all NIT):
1. `η` denotes both the jet `∇_Θ∂_u³f(0)` (in `λ₄`, `t₁`, `Q₁`) and the slack `C_Rr𝒩^{N₁}` of (W1); rename the slack.
2. TL (1.1) is stated for `j = 0, 1, 2`; the note also uses `j = 1/2` and `j = 3/2` (true by interpolation; checked
   numerically).
3. Lemma W⁻ does not cover (W1)'s window (shifted centre, width `η/|Δ|`); the proof there uses only the bounded density,
   which suffices since those weights contain no `|q|`. Say so, and qualify the §0 sentence "every window …".
4. "`A` given `J‴`" is not literally TL's (B4); it is correct (a Schur complement with covariance `≥ c₀I`, as in #220
   (F5)/(2.2)); add a clause.
5. In (Q′1)'s second part the term `2r²·4 = 8r² ≤ r` is missing from the text (the controls' `57 = 6 + 44 + 1 + 6`).
6. Constants: `N` in (2.1⁻) depends on `(p, s)`; `1/10` in `r₄⁻` is redundant; in `𝔅_b` use the layer value of the slack in
   `min(1, κ + η/|Δ|)`, and for #229 (4.2)'s `s ≤ 1/2` use `min ≤ 1 ≤ 2η_j` for large `j`.

Checked and fine: Lemma W⁻ (density bound, `|μ₄|`, both `|q|` cases), the degree-2 claim, TL (2.2) for all `κ`; Lemma GE⁻
(a), (b) (all margins, (Q′1)–(Q′2), Lemma R₂), (c) (`ϑ` small, `ℰ ⊂ {23κ ≤ |z| ≤ 25κ}`), constants chosen without
circularity; no hidden `κ ≥ κ₀` hypothesis in [N]'s Lemmas Q′, Q″, R₂, Ω (the `κ₀`-dependences of [N] are only in
Theorem N's Steps N1–N2, not used); Proposition RW⁻'s reduction, (W1) everywhere, (W2), and each cost; conditioning order
and `𝒩`-layers; no bare `r²` term in (2.3⁻); the controls (3257 checks, mutants).

## Slice C

No blocker, no needed correction. Findings (all NIT):
1. Step 4: insert "by parity, `E_{r,0}[G_r] = E_{r,0}[G_{−r}]`" (TL's Step 4 says it).
2. "Collecting": Steps 3 and 5 each contribute `κ³r²`; the extra terms total `≤ 5κ³r²`; write `Cκ³r²`.
3. (Δ.1⁻): add "and the same for the lower branch" (two branches can exceed one branch's bound by about `1.2×`, within
   `0.87×` of twice it); merge the two equal monomials; optionally spell out the mirror `z ↦ −z`.
4. (5.0): TL's (B3) is stated for `0 ≤ k ≤ 1`; (5.0) holds for every `k` (`V_0` centred Gaussian). #237 (R.2) is stated
   for `r > 0`; at `r = 0` cite #218 Step C3 (even jets' law independent of `k`; `π_0 = p_even·p_odd`), which gives (5.0)
   pointwise in `b`.
5. The last "contributions" bullet: without (5.0) the least exponent is `4/7` exactly for `σ ∈ (1/5, 10/49]`, i.e. with
   Theorem TL⁻ at `θ ∈ [9/10, 1)`; S5 should check an interior point.
6. (optional) `a = ℓ^{1/7}(log(1/ℓ))^{−3/14}` gives `O(ℓ^{4/7}(log(1/ℓ))^{1/7})`.

Checked and fine: the controls (normal, `-O`, mutants, invalid invocations); Lemma Δ⁻ (edges, the second-difference
identity by hand and numerically with a Gaussian `p₄`, the three bounds, the kink, the cutoff, (Δ.1⁻)); numerics over 1296
configurations (`κ ∈ [0.01, 1]`) with ratios to the note's bounds `≤ 0.99` and `≤ 0.87`, scaled ratios bounded as
`κ → 0.001`; Steps 1–6 and `p = ⌈3/(1 − θ)⌉`; (5.0) exact, with sign; the cusp bounds; (5.1); `𝒦₁` at a general split;
`𝒦₂`; the cancellation with signs; `I^{eld}`; all ranges; the ledger (recomputed exactly); the split range; the
counterfactual exponents `4/9` and `6/13`; TS′.
