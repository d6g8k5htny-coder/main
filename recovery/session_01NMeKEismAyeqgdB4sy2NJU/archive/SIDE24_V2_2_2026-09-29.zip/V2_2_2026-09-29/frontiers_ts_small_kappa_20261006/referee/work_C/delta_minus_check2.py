"""Referee C: float64 check of Lemma Delta- with a Gaussian p4 (both branches, kink included)."""
import itertools
import math
import numpy as np
from scipy.integrate import quad

ce = 1 / 200
pos = lambda y: y if y > 0 else 0.0


def Q(f, pts):
    pts = sorted(set(pts))
    return sum(quad(f, pts[i], pts[i + 1], limit=200, epsabs=0, epsrel=1e-12)[0] for i in range(len(pts) - 1))


def run():
    w2 = w1 = wid = wr2 = wr1 = 0.0
    n = 0
    for kap, D2, Q1, q3, mu, sig, frac in itertools.product(
            [0.01, 0.05, 0.2, 1.0], [1.0, 0.3], [0.5, -2.0, 0.05], [0.0, 3.0, 20.0],
            [-3.0, 0.0, 2.0], [0.7, 1.5], [1.0, 0.5, 0.1]):
        r = frac * ce * kap / abs(Q1)
        beta = 12 * kap * D2 * Q1
        a = 36 * r * Q1
        p4 = lambda x: math.exp(-(x - mu) ** 2 / (2 * sig ** 2)) / (math.sqrt(2 * math.pi) * sig)
        dp4 = lambda x: -(x - mu) / sig ** 2 * p4(x)
        w0 = lambda x: D2 / 144 * (5184 * kap ** 2 - (x + q3) ** 2)
        dw0 = lambda x: -D2 / 72 * (x + q3)

        def g(s, x):
            z = x + q3
            return pos(w0(x) + s * beta) if abs(z) >= 24 * kap + 36 * s * Q1 else 0.0

        def S(s):
            zm = math.sqrt(5184 * kap ** 2 + 144 * s * beta / D2)
            thr = 24 * kap + 36 * s * Q1
            up = Q(lambda x: (w0(x) + s * beta) * p4(x), [thr - q3, 48 * kap - q3, zm - q3])
            lo = Q(lambda x: (w0(x) + s * beta) * p4(x), [-zm - q3, -48 * kap - q3, -thr - q3])
            return up + lo

        D2nd = S(r) + S(-r) - 2 * S(0.0)
        bound2 = 0.0
        for br in (1, -1):
            e0 = br * 24 * kap - q3
            grid = np.linspace(e0 - abs(a), e0 + abs(a), 401)
            supFp = max(abs(dw0(x) * p4(x) + w0(x) * dp4(x)) for x in grid)
            supe = max(p4(x) for x in grid)
            zk = br * 72 * kap - q3
            gk = np.linspace(zk - 12.1 * r * abs(Q1), zk + 12.1 * r * abs(Q1), 401)
            supk = max(p4(x) for x in gk)
            bound2 += a * a * supFp + 864 * kap * r * r * D2 * Q1 * Q1 * supe + 291 * kap * r * r * D2 * Q1 * Q1 * supk
        assert abs(D2nd) <= bound2 * (1 + 1e-6) + 1e-300, ("D2", kap, D2, Q1, q3, mu, sig, frac, D2nd, bound2)
        w2 = max(w2, abs(D2nd) / bound2)
        wr2 = max(wr2, abs(D2nd) / (r * r * kap * D2 * Q1 * Q1))
        # identity, upper branch
        e0 = 24 * kap - q3
        Zp = 48 * kap - q3
        F = lambda x: w0(x) * p4(x)
        Phi = lambda x: Q(F, [e0, e0 + x]) if x >= 0 else -Q(F, [e0 + x, e0])
        zmp = math.sqrt(5184 * kap ** 2 + 144 * r * abs(beta) / D2) - q3
        kink = Q(lambda x: (pos(w0(x) + r * beta) + pos(w0(x) - r * beta) - 2 * pos(w0(x))) * p4(x),
                 [Zp, 72 * kap - q3 - 13 * r * abs(Q1), 72 * kap - q3, 72 * kap - q3 + 13 * r * abs(Q1), zmp + 1])

        def Sup(s):
            zm = math.sqrt(5184 * kap ** 2 + 144 * s * beta / D2)
            return Q(lambda x: (w0(x) + s * beta) * p4(x), [24 * kap + 36 * s * Q1 - q3, 48 * kap - q3, zm - q3])
        lhs = Sup(r) + Sup(-r) - 2 * Sup(0.0)
        mid = r * beta * (Q(p4, [e0 + a, e0 - a]) * (1 if a < 0 else -1))   # int_{e0+a}^{e0-a} p4, signed
        rhs = -(Phi(a) + Phi(-a)) + mid + kink
        scale = abs(Phi(a) + Phi(-a)) + abs(mid) + abs(kink) + 1e-300
        wid = max(wid, abs(lhs - rhs) / scale)
        # (Delta.1-), both branches
        brk = [-73 * kap - q3, -24 * kap - q3 - abs(a), -24 * kap - q3 + abs(a), 24 * kap - q3 - abs(a),
               24 * kap - q3 + abs(a), 73 * kap - q3, -72 * kap - q3, 72 * kap - q3]
        D1 = Q(lambda x: abs(g(r, x) - g(-r, x)) * p4(x), brk)
        supw = max(p4(x) for x in np.linspace(-73 * kap - q3, 73 * kap - q3, 1601))
        b1 = 2 * (2664 * r * abs(Q1) * kap ** 2 * D2 + 1200 * r * kap ** 2 * D2 * abs(Q1)) * supw
        assert D1 <= b1 * (1 + 1e-6), ("D1", kap, D2, Q1, q3, mu, sig, frac, D1, b1)
        w1 = max(w1, D1 / b1)
        wr1 = max(wr1, D1 / (r * kap ** 2 * D2 * abs(Q1)))
        n += 1
    print("cases", n)
    print("max |2nd diff| / note's bound (both branches) :", w2)
    print("max |2nd diff| / (r^2 kappa D2 Q1^2)          :", wr2)
    print("max rel. error of the identity (upper branch) :", wid)
    print("max 1st diff / note's bound (both branches)   :", w1)
    print("max 1st diff / (r kappa^2 D2 |Q1|)            :", wr1)


run()
