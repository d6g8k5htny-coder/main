from fractions import Fraction as F
# rho = l^s, a = l^t ; each row = exponent of l (log rows flagged)
def rows(s, t, *, TLminus=True, Spp=True, cancel=True):
    R = {}
    R['U r^2: rho^3'] = 3*s
    R['U fold / TL1'] = F(2,3)
    R['A2 finite part l^2 rho^-5'] = 2-5*s
    if TLminus:
        R['TL- kr^2: l^{3/4}'] = F(3,4)
        R['TL- r^3/k: rho^8/l'] = 8*s-1
    else:
        R['O(r) cusp error: rho^2'] = 2*s
    R['elder cusp tail l^3 rho^-11'] = 3-11*s
    R['contact diff'] = (4-13*s) if cancel else (2-7*s)
    R['W+ kappa^3 on [rho,l^1/5]'] = 3-11*s
    R['W+ kappa^2 r log on [rho,l^1/5] (log)'] = 2-6*s
    R['W+ r^3 log on [l^1/5,a] (log)'] = 4*t
    if Spp:
        R["S'' r kappa^2/3"] = F(2,3)-F(2,3)*t
        R["S'' kappa^5/3"] = F(5,3)-F(17,3)*t
    else:
        R["S' l^2/3 a^-2"] = F(2,3)-2*t
        R["S' l^5/3 a^-7"] = F(5,3)-7*t
    return R
R = rows(F(3,14), F(1,7))
for k,v in sorted(R.items(), key=lambda kv: kv[1]): print("%-40s %s" % (k, v))
print("least:", min(R.values()), " > 1/2:", min(R.values()) > F(1,2))
# best over a grid of (s, t): s in (1/5, 1/4), t in (0, 1/5)
def best(**kw):
    bestv, arg = None, None
    for i in range(1, 400):
        s = F(1,5) + F(1,20)*F(i,400)        # (1/5, 1/4)
        for j in range(1, 400):
            t = F(1,5)*F(j,400)
            m = min(rows(s, t, **kw).values())
            if bestv is None or m > bestv: bestv, arg = m, (s, t)
    return bestv, arg
print("full (TL-, S'', (5.0))        :", best())
print("TL inputs + (5.0) only        :", best(TLminus=False, Spp=False))
print("S'' + (5.0), no TL-           :", best(TLminus=False))
print("TL- + S'', no (5.0)           :", best(cancel=False))
# admissible sigma range with a = l^{1/7}
ok = [F(1,5)+F(i,100000) for i in range(1,5000) if min(rows(F(1,5)+F(i,100000), F(1,7)).values()) >= F(4,7)]
print("admissible sigma: min", float(ok[0]), " max", ok[-1], float(ok[-1]), " 17/77 =", float(F(17,77)))
ok2 = [F(1,5)+F(i,100000) for i in range(1,5000) if min(rows(F(1,5)+F(i,100000), F(1,7), cancel=False).values()) >= F(4,7)]
print("no (5.0): admissible sigma max", ok2[-1], float(ok2[-1]), "; 10/49 =", float(F(10,49)), " theta there =", (1-4*F(10,49))/F(10,49))
