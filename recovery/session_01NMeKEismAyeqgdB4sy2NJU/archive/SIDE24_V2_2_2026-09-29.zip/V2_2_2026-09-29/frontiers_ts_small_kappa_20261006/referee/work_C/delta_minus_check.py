"""Referee C: numerical check of Lemma Delta- (edges in f4, the identity, the three bounds, (Delta.1-)) with a true
Gaussian p4, both branches, and the kink.  Conditioned on J'' with A < 0: z = f4 + 3|q|, w0 = (D2/144)(5184 k^2 - z^2),
beta = 12 k D2 Q1, G_s = (w0 + s beta)_+ 1{|z| >= 24k + 36 s Q1} (cutoff r|Q1| <= c_e k assumed)."""
import itertools
import mpmath as mp

mp.mp.dps = 40
ce = mp.mpf(1) / 200


def run():
    worst2 = 0
    worst1 = 0
    worst_id = 0
    worst_ratio2 = 0
    worst_ratio1 = 0
    n = 0
    for kap, D2, Q1, q3, mu, sig, frac in itertools.product(
            [mp.mpf('0.02'), mp.mpf('0.2'), mp.mpf(1)], [mp.mpf(1), mp.mpf('0.3')],
            [mp.mpf('0.5'), mp.mpf(-2), mp.mpf('0.05')], [mp.mpf(0), mp.mpf(3), mp.mpf(20)],
            [mp.mpf(-3), mp.mpf(0), mp.mpf(2)], [mp.mpf('0.7'), mp.mpf('1.5')],
            [mp.mpf(1), mp.mpf('0.5'), mp.mpf('0.1')]):
        r = frac * ce * kap / abs(Q1)
        beta = 12 * kap * D2 * Q1
        p4 = lambda x: mp.exp(-(x - mu) ** 2 / (2 * sig ** 2)) / (mp.sqrt(2 * mp.pi) * sig)
        dp4 = lambda x: -(x - mu) / sig ** 2 * p4(x)
        w0 = lambda x: D2 / 144 * (5184 * kap ** 2 - (x + q3) ** 2)
        dw0 = lambda x: -D2 / 72 * (x + q3)

        def G_int(s, branch):
            # integral over the branch of (w0 + s beta)_+ p4 df4
            thr = 24 * kap + 36 * s * Q1
            # positive part vanishes beyond |z| = sqrt(5184 k^2 + 144 s beta / D2)
            zmax2 = 5184 * kap ** 2 + 144 * s * beta / D2
            zmax = mp.sqrt(zmax2)
            if branch == 1:
                lo, hi = thr - q3, zmax - q3
            else:
                lo, hi = -zmax - q3, -thr - q3
            if hi <= lo:
                return mp.mpf(0)
            mid = [lo, (48 * kap - q3) if branch == 1 else (-48 * kap - q3), hi]
            mid = sorted(set([m for m in mid if lo <= m <= hi]))
            return mp.quad(lambda x: (w0(x) + s * beta) * p4(x), mid)

        S = {s: G_int(s, 1) + G_int(s, -1) for s in (r, -r, mp.mpf(0))}
        D2nd = S[r] + S[-r] - 2 * S[mp.mpf(0)]
        # bound of the note, upper + lower branch
        a = 36 * r * Q1
        total_bound = 0
        for branch in (1, -1):
            e0 = (24 * kap - q3) if branch == 1 else (-24 * kap - q3)
            # sup over |f4 - e0| <= |a| of |F'| with F = w0 p4
            grid = [e0 - abs(a) + 2 * abs(a) * j / 400 for j in range(401)]
            supFp = max(abs(dw0(x) * p4(x) + w0(x) * dp4(x)) for x in grid)
            supp_edge = max(p4(x) for x in grid)
            zk = 72 * kap if branch == 1 else -72 * kap
            gridk = [zk - q3 - mp.mpf('12.1') * r * abs(Q1) + mp.mpf('24.2') * r * abs(Q1) * j / 400 for j in range(401)]
            supp_kink = max(p4(x) for x in gridk)
            total_bound += a ** 2 * supFp + 864 * kap * r ** 2 * D2 * Q1 ** 2 * supp_edge \
                + 291 * kap * r ** 2 * D2 * Q1 ** 2 * supp_kink
        assert abs(D2nd) <= total_bound * (1 + mp.mpf('1e-20')), (kap, D2, Q1, q3, mu, sig, frac, D2nd, total_bound)
        worst2 = max(worst2, abs(D2nd) / total_bound)
        worst_ratio2 = max(worst_ratio2, abs(D2nd) / (r ** 2 * kap * D2 * Q1 ** 2))
        # the identity (upper branch), with the kink integral computed separately
        e0 = 24 * kap - q3
        Zp = 48 * kap - q3
        F = lambda x: w0(x) * p4(x)
        Phi = lambda x: mp.quad(F, [e0, e0 + x])
        pos = lambda y: y if y > 0 else mp.mpf(0)
        zmaxp = mp.sqrt(5184 * kap ** 2 + 144 * r * abs(beta) / D2) - q3
        kink = mp.quad(lambda x: (pos(w0(x) + r * beta) + pos(w0(x) - r * beta) - 2 * pos(w0(x))) * p4(x),
                       [Zp, 72 * kap - q3 - 13 * r * abs(Q1), 72 * kap - q3, 72 * kap - q3 + 13 * r * abs(Q1), zmaxp + 1])
        lhs = G_int(r, 1) + G_int(-r, 1) - 2 * G_int(mp.mpf(0), 1)
        rhs = -(Phi(a) + Phi(-a)) + r * beta * mp.quad(p4, [e0 + a, e0 - a]) + kink
        worst_id = max(worst_id, abs(lhs - rhs) / (abs(lhs) + mp.mpf('1e-30')))
        # (Delta.1-): int |G_r - G_{-r}| p4 <= [2664 r|Q1| k^2 D2 + 1200 r k^2 D2 |Q1|] sup p4
        def g(s, x):
            z = x + q3
            thr = 24 * kap + 36 * s * Q1
            return pos(w0(x) + s * beta) if abs(z) >= thr else mp.mpf(0)
        brk = sorted(set([-73 * kap - q3, -24 * kap - q3 - abs(a), -24 * kap - q3 + abs(a),
                          24 * kap - q3 - abs(a), 24 * kap - q3 + abs(a), 73 * kap - q3,
                          -72 * kap - q3, 72 * kap - q3]))
        D1 = mp.quad(lambda x: abs(g(r, x) - g(-r, x)) * p4(x), brk)
        gridw = [-73 * kap - q3 + 146 * kap * j / 800 for j in range(801)]
        supw = max(p4(x) for x in gridw)
        b1 = 2 * (2664 * r * abs(Q1) * kap ** 2 * D2 + 1200 * r * kap ** 2 * D2 * abs(Q1)) * supw  # two branches
        assert D1 <= b1 * (1 + mp.mpf('1e-20')), (kap, Q1, D1, b1)
        worst1 = max(worst1, D1 / b1)
        worst_ratio1 = max(worst_ratio1, D1 / (r * kap ** 2 * D2 * abs(Q1)))
        n += 1
    print("cases", n)
    print("max |2nd diff| / note's bound   :", mp.nstr(worst2, 6))
    print("max |2nd diff| / (r^2 k D2 Q1^2) :", mp.nstr(worst_ratio2, 6))
    print("max rel. error of the identity   :", mp.nstr(worst_id, 6))
    print("max 1st diff / note's bound      :", mp.nstr(worst1, 6))
    print("max 1st diff / (r k^2 D2 |Q1|)   :", mp.nstr(worst_ratio1, 6))


run()
