import itertools, math
from scipy.integrate import quad
ce = 1/200
pos = lambda y: y if y > 0 else 0.0
def Q(f, pts):
    pts = sorted(set(pts)); return sum(quad(f, pts[i], pts[i+1], limit=200, epsabs=0, epsrel=1e-11)[0] for i in range(len(pts)-1))
for kap in (1.0, 0.1, 0.01, 0.001):
    m2 = m1 = 0.0
    for D2, Q1, q3, mu, sig, frac in itertools.product([1.0], [0.5, -2.0], [0.0, 3.0], [-1.0, 0.0, 2.0], [0.7, 1.5], [1.0, 0.3]):
        r = frac*ce*kap/abs(Q1); beta = 12*kap*D2*Q1
        p4 = lambda x: math.exp(-(x-mu)**2/(2*sig**2))/(math.sqrt(2*math.pi)*sig)
        w0 = lambda x: D2/144*(5184*kap**2-(x+q3)**2)
        def S(s):
            zm = math.sqrt(5184*kap**2+144*s*beta/D2); thr = 24*kap+36*s*Q1
            return Q(lambda x: (w0(x)+s*beta)*p4(x), [thr-q3, 48*kap-q3, zm-q3]) + Q(lambda x: (w0(x)+s*beta)*p4(x), [-zm-q3, -48*kap-q3, -thr-q3])
        d2 = abs(S(r)+S(-r)-2*S(0.0))
        a = 36*r*Q1
        def g(s, x):
            z = x+q3; return pos(w0(x)+s*beta) if abs(z) >= 24*kap+36*s*Q1 else 0.0
        brk = [-73*kap-q3, -24*kap-q3-abs(a), -24*kap-q3+abs(a), 24*kap-q3-abs(a), 24*kap-q3+abs(a), 73*kap-q3, -72*kap-q3, 72*kap-q3]
        d1 = Q(lambda x: abs(g(r,x)-g(-r,x))*p4(x), brk)
        m2 = max(m2, d2/(r*r*kap*D2*Q1*Q1)); m1 = max(m1, d1/(r*kap**2*D2*abs(Q1)))
    print("kappa=%-6g  max |2nd diff|/(r^2 kappa D^2 Q1^2) = %10.3f   max 1st diff/(r kappa^2 D^2|Q1|) = %10.3f" % (kap, m2, m1))
