import itertools, mpmath as mp
mp.mp.dps = 40
ce = mp.mpf(1)/200
pos = lambda y: y if y > 0 else mp.mpf(0)
for kap, D2, Q1, q3, mu, sig, frac in itertools.product(
        [mp.mpf('0.02')], [mp.mpf(1), mp.mpf('0.3')],
        [mp.mpf('0.5')], [mp.mpf(0), mp.mpf(3), mp.mpf(20)],
        [mp.mpf(-3), mp.mpf(0), mp.mpf(2)], [mp.mpf('0.7'), mp.mpf('1.5')],
        [mp.mpf(1), mp.mpf('0.5'), mp.mpf('0.1')]):
    r = frac*ce*kap/abs(Q1); beta = 12*kap*D2*Q1; a = 36*r*Q1
    p4 = lambda x: mp.exp(-(x-mu)**2/(2*sig**2))/(mp.sqrt(2*mp.pi)*sig)
    w0 = lambda x: D2/144*(5184*kap**2-(x+q3)**2)
    def g(s, x):
        z = x+q3; thr = 24*kap+36*s*Q1
        return pos(w0(x)+s*beta) if abs(z) >= thr else mp.mpf(0)
    brk = sorted(set([-73*kap-q3, -24*kap-q3-abs(a), -24*kap-q3+abs(a), 24*kap-q3-abs(a), 24*kap-q3+abs(a), 73*kap-q3, -72*kap-q3, 72*kap-q3]))
    D1 = mp.quad(lambda x: abs(g(r,x)-g(-r,x))*p4(x), brk)
    # brute force Riemann sum on a fine grid as a cross-check
    N = 200000
    lo, hi = -73*kap-q3, 73*kap-q3
    h = (hi-lo)/N
    D1b = sum(abs(g(r, lo+(j+0.5)*h)-g(-r, lo+(j+0.5)*h))*p4(lo+(j+0.5)*h) for j in range(N))*h if False else None
    supw = max(p4(-73*kap-q3+146*kap*j/800) for j in range(801))
    b1 = (2664*r*abs(Q1)*kap**2*D2 + 1200*r*kap**2*D2*abs(Q1))*supw
    if D1 > b1:
        print("FAIL", [mp.nstr(v,4) for v in (kap,D2,Q1,q3,mu,sig,frac)], "D1", mp.nstr(D1,6), "b1", mp.nstr(b1,6), "brk", [mp.nstr(b,6) for b in brk])
        break
