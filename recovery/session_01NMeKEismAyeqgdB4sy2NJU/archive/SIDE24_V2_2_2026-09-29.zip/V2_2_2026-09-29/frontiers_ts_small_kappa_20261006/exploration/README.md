# Exploration for note TS (not part of the proof)

The rejected, elder and candidate kernels at small `κ`, `d = 2`, Gaussian kernel, `b = 0`, by [N]'s Monte Carlo
`frontiers_elder_cusp_parity_20261002/exploration/elder_f4int.py` (unchanged; sha256
`ecc584fe4fc93b4ea2a7eec80852ca3f50ca3bb8fdcba2d6a94b5ec6e6d5b223`), run on 6 Oct 2026 as

    python3 elder_f4int.py 20000 0.003,0.006,0.009,0.012,0.016,0.02 0:0.5,0:0.25,0:0.1 smallkappa 20261006 3

(numpy 2.4.4, scipy 1.17.1, mpmath 1.3.0; 20,000 samples, antithetic in the odd jets; cubic fits in `r`). Output:
`elder_f4int_smallkappa.json`, log `smallkappa.log`. Note TS Remark 3 quotes the rejected kernel's relative linear coefficients
(`+0.0007 ± 0.0173`, `+0.0043 ± 0.0033`, `+0.0045 ± 0.0024` at `κ = 1/2, 1/4, 1/10`) and the rejected fractions (`0.078`, `0.250`,
`0.467`, towards `14/27`).
