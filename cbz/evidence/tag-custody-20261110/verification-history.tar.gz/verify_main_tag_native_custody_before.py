"""Bounded one-off verification of two preserved Main tag source deltas."""
import hashlib,json,pathlib,sys,tarfile
p=pathlib.Path(sys.argv[1]);H=lambda b:hashlib.sha256(b).hexdigest()
def oid(kind,raw):return hashlib.sha1(kind.encode()+b' '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def entries(raw):
 out={};i=0
 while i<len(raw):
  space=raw.index(b' ',i);nul=raw.index(b'\0',space);mode=raw[i:space].decode();name=raw[space+1:nul].decode('utf-8');part=raw[nul+1:nul+21];assert len(part)==20 and name not in out;out[name]=(mode,part.hex());i=nul+21
 assert i==len(raw);return out
with tarfile.open(p,'r:gz') as t:
 members=t.getmembers();names=[m.name for m in members];assert len(names)==len(set(names)) and all(m.isfile() and 0<=m.size<=16*1024*1024 and not m.name.startswith('/') and all(x not in ('','.','..') for x in pathlib.PurePosixPath(m.name).parts) for m in members)
 def get(name):return t.extractfile(name).read()
 m=json.loads(get('MANIFEST.json'));assert m['schema']=='cbz.historical-main-tags-native-custody.v1' and len(m['tags'])==2 and len(m['files'])==11
 expected={'MANIFEST.json'}|{r['archive_name'] for r in m['files']}|{'git-objects/'+r['kind']+'/'+r['sha'] for r in m['native_objects']};assert set(names)==expected
 objs={}
 for r in m['native_objects']:
  raw=get('git-objects/'+r['kind']+'/'+r['sha']);assert len(raw)==r['bytes'] and H(raw)==r['sha256'] and oid(r['kind'],raw)==r['sha'];objs[(r['kind'],r['sha'])]=raw
 for r in m['tags']:
  if r['type']=='tag':assert objs[('tag',r['object'])].splitlines()[0]==('object '+r['target_commit']).encode()
  else:assert r['type']=='commit' and r['object']==r['target_commit']
 for commit,tree in m['commit_trees'].items():assert objs[('commit',commit)].splitlines()[0]==('tree '+tree).encode()
 for r in m['files']:
  raw=get(r['archive_name']);assert len(raw)==r['bytes'] and H(raw)==r['sha256'] and oid('blob',raw)==r['git_blob'];assert t.getmember(r['archive_name']).mode==(0o755 if r['mode']=='100755' else 0o644)
  parts=pathlib.PurePosixPath(r['path']).parts;tree=m['commit_trees'][r['commit']]
  for name in parts[:-1]:mode,tree=entries(objs[('tree',tree)])[name];assert mode in ('40000','040000')
  mode,sha=entries(objs[('tree',tree)])[parts[-1]];assert mode==r['mode'] and sha==r['git_blob']
print('PASS: 2 historical tags, 2 commits,',sum(r['kind']=='tree' for r in m['native_objects']),'native path trees and 11 exact file bindings; source preservation only')
