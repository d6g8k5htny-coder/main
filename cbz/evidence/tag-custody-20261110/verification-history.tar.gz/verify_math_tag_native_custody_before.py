"""Bounded one-off verification of the preserved Math tag source archive."""
import hashlib,json,pathlib,sys,tarfile
p=pathlib.Path(sys.argv[1]);H=lambda b:hashlib.sha256(b).hexdigest()
def oid(kind,raw):return hashlib.sha1(kind.encode()+b' '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def entries(raw):
 out={};i=0
 while i<len(raw):
  space=raw.index(b' ',i);nul=raw.index(b'\0',space);mode=raw[i:space].decode();name=raw[space+1:nul].decode('utf-8');part=raw[nul+1:nul+21];assert len(part)==20 and name not in out;out[name]=(mode,part.hex());i=nul+21
 assert i==len(raw);return out
with tarfile.open(p,'r:gz') as t:
 members=t.getmembers();names=[m.name for m in members];assert len(names)==len(set(names)) and all(m.isfile() and 0<=m.size<=16*1024*1024 and not m.name.startswith('/') and all(x not in ('','.','..') for x in pathlib.PurePosixPath(m.name).parts) for m in members)
 def get(name):return t.extractfile(name).read()
 m=json.loads(get('MANIFEST.json'));assert m['schema']=='cbz.historical-math-tags-native-custody.v2';assert len(m['files'])==52 and len(m['tag_objects'])==5 and len(m['tree_bindings'])==171
 expected={'MANIFEST.json'}|{'sources/'+r['path'] for r in m['files']}|{'tags/'+r['file'] for r in m['tag_objects']}|{'git-objects/'+r['kind']+'/'+r['sha'] for r in m['native_objects']};assert set(names)==expected
 objs={}
 for r in m['native_objects']:
  raw=get('git-objects/'+r['kind']+'/'+r['sha']);assert len(raw)==r['bytes'] and H(raw)==r['sha256'] and oid(r['kind'],raw)==r['sha'];objs[(r['kind'],r['sha'])]=raw
 for r in m['tag_objects']:
  raw=get('tags/'+r['file']);assert len(raw)==r['bytes'] and H(raw)==r['sha256'] and oid('tag',raw)==r['tag_object'] and raw.splitlines()[0]==('object '+r['target_commit']).encode()
 for commit,tree in m['commit_trees'].items():assert objs[('commit',commit)].splitlines()[0]==('tree '+tree).encode()
 files={r['path']:r for r in m['files']};assert len(files)==52
 for r in m['files']:
  raw=get('sources/'+r['path']);assert len(raw)==r['bytes'] and H(raw)==r['sha256'] and oid('blob',raw)==r['git_blob'];assert t.getmember('sources/'+r['path']).mode==(0o755 if r['mode']=='100755' else 0o644)
 for r in m['tree_bindings']:
  parts=pathlib.PurePosixPath(r['path']).parts;tree=m['commit_trees'][r['commit']]
  for name in parts[:-1]:mode,tree=entries(objs[('tree',tree)])[name];assert mode in ('40000','040000')
  mode,sha=entries(objs[('tree',tree)])[parts[-1]];assert mode==r['mode'] and sha==r['git_blob']==files[r['path']]['git_blob']
print('PASS: 5 annotated tag objects, 5 commits,',sum(r['kind']=='tree' for r in m['native_objects']),'native path trees, 52 files and 171 exact bindings; source preservation only')
