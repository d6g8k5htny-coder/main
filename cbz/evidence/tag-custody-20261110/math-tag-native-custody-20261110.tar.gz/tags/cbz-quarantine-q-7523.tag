object de872d97fa54eb11c0834b8f532543222900d165
type commit
tag cbz-quarantine-q-7523
tagger CBZ source preservation <cbz-baseline@users.noreply.github.com> 1793303796 +0000

Immutable CBZ snapshot Q-7523 at de872d97fa54eb11c0834b8f532543222900d165; original proofs, controls, source and full ancestry preserved. No mathematical or scientific promotion. See cbz/math-delivery-snapshots/plan.json and federation proof index for disposition.
