object fc5ecb67f4a9d6cfb1dec066499ca2daa1147b3b
type commit
tag cbz-quarantine-q-7525
tagger CBZ source preservation <cbz-baseline@users.noreply.github.com> 1793303800 +0000

Immutable CBZ snapshot Q-7525 at fc5ecb67f4a9d6cfb1dec066499ca2daa1147b3b; original proofs, controls, source and full ancestry preserved. No mathematical or scientific promotion. See cbz/math-delivery-snapshots/plan.json and federation proof index for disposition.
