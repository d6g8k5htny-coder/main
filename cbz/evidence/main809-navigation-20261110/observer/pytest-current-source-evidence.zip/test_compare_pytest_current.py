"""Adverse controls for the seven-blob receipt comparator."""
import base64
import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent
SOURCE = (ROOT / 'compare_pytest_current.py').read_text()
PRIOR = (ROOT / 'pytest-prior-source-comparison.json').read_bytes()
FETCHED = json.loads((ROOT / 'pytest-current-fetched.json').read_text())


def exercise(data, source=SOURCE, optimized=False):
    with tempfile.TemporaryDirectory(prefix='pytest-current-comparator-') as temp:
        root = Path(temp)
        (root / 'compare_pytest_current.py').write_text(source)
        (root / 'pytest-prior-source-comparison.json').write_bytes(PRIOR)
        command = [sys.executable, '-B', '-S'] + (['-O'] if optimized else []) + [str(root / 'compare_pytest_current.py')]
        return subprocess.run(command, input=json.dumps(data) + '\n', text=True, capture_output=True, timeout=30)


def altered():
    data = copy.deepcopy(FETCHED)
    raw = bytearray(base64.b64decode(''.join(data[0]['content'].split()), validate=True))
    raw[0] ^= 1
    data[0]['content'] = base64.b64encode(raw).decode()
    return data


class ComparatorControls(unittest.TestCase):
    def test_exact_inputs_pass(self):
        for optimized in (False, True):
            self.assertEqual(exercise(FETCHED, optimized=optimized).returncode, 0)

    def test_missing_source_refuses(self):
        for optimized in (False, True):
            self.assertNotEqual(exercise(FETCHED[:-1], optimized=optimized).returncode, 0)

    def test_duplicate_source_refuses(self):
        data = copy.deepcopy(FETCHED)
        data[-1] = data[0]
        for optimized in (False, True):
            self.assertNotEqual(exercise(data, optimized=optimized).returncode, 0)

    def test_changed_bytes_refuse(self):
        for optimized in (False, True):
            self.assertNotEqual(exercise(altered(), optimized=optimized).returncode, 0)

    def test_identity_guard_removal_reopens_changed_bytes(self):
        anchor = "if (len(raw) != expected['bytes'] or digest != expected['sha256'] or git != expected['git_blob']):"
        self.assertEqual(SOURCE.count(anchor), 1)
        mutant = SOURCE.replace(anchor, 'if False:', 1)
        for optimized in (False, True):
            result = exercise(altered(), source=mutant, optimized=optimized)
            self.assertEqual(result.returncode, 0, result.stderr)


if __name__ == '__main__':
    unittest.main(verbosity=2)
