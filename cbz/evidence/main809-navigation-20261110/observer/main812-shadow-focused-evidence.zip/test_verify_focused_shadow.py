"""Adverse and guard-removal checks for the bounded hosted-artifact reader."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import zipfile

ROOT = Path(__file__).resolve().parent
CODE = (ROOT / 'verify_focused_shadow.py').read_text()
with zipfile.ZipFile(ROOT / 'main812-shadow-focused-artifact-13756913624.zip') as z:
    MEMBERS = {name: z.read(name) for name in z.namelist()}


def exercise(changes=None, removed=(), source=CODE, optimized=False):
    with tempfile.TemporaryDirectory(prefix='main812-focused-verifier-') as temp:
        directory = Path(temp)
        path = directory / 'evidence.zip'
        changes = changes or {}
        with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
            for name, data in MEMBERS.items():
                if name not in removed:
                    z.writestr(name, changes.get(name, data))
        script = directory / 'verify.py'
        script.write_text(source)
        flags = ['-B', '-S'] + (['-O'] if optimized else [])
        return subprocess.run([sys.executable, *flags, str(script), str(path),
                               hashlib.sha256(path.read_bytes()).hexdigest()], capture_output=True, text=True, timeout=30)


def with_observation(obs):
    data = json.dumps(obs).encode()
    return {'observation.json': data}


def forged_result():
    name = 'normal-plain-no-prefix-candidate.stderr'
    data = MEMBERS[name].replace(b' ... ok\n', b' ... FAIL\n', 1)
    obs = json.loads(MEMBERS['observation.json'])
    obs['cases'][0]['stderr_sha256'] = hashlib.sha256(data).hexdigest()
    return {**with_observation(obs), name: data}


class FocusedReaderControls(unittest.TestCase):
    def test_original_is_accepted(self):
        for optimized in (False, True):
            self.assertEqual(exercise(optimized=optimized).returncode, 0)

    def test_missing_stream_is_rejected(self):
        for optimized in (False, True):
            self.assertNotEqual(exercise(removed=('normal-plain-no-prefix-candidate.stderr',), optimized=optimized).returncode, 0)

    def test_forged_result_is_rejected(self):
        for optimized in (False, True):
            self.assertNotEqual(exercise(forged_result(), optimized=optimized).returncode, 0)

    def test_duplicate_case_is_rejected(self):
        obs = json.loads(MEMBERS['observation.json'])
        obs['cases'][1] = obs['cases'][0]
        for optimized in (False, True):
            self.assertNotEqual(exercise(with_observation(obs), optimized=optimized).returncode, 0)

    def test_forged_source_is_rejected(self):
        obs = json.loads(MEMBERS['observation.json'])
        obs['source_git_blobs']['tools/periodic_pilot_custody.py'] = '0' * 40
        for optimized in (False, True):
            self.assertNotEqual(exercise(with_observation(obs), optimized=optimized).returncode, 0)

    def test_result_guard_removal_reopens_forgery(self):
        anchor = 'if result != wanted:'
        self.assertEqual(CODE.count(anchor), 1)
        mutant = CODE.replace(anchor, 'if False:', 1)
        for optimized in (False, True):
            result = exercise(forged_result(), source=mutant, optimized=optimized)
            self.assertEqual(result.returncode, 0, result.stderr)


if __name__ == '__main__':
    unittest.main(verbosity=2)
