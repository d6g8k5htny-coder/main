"""Inspect one hosted custody-shadow artifact; no full G5 claim."""
import hashlib
import json
from pathlib import Path
import re
import sys
import zipfile

CASES = tuple(mode + '-' + shadow + '-' + prefix + '-' + kind
              for mode in ('normal', 'optimized') for shadow in ('plain', 'shadow')
              for prefix in ('no-prefix', 'prefix') for kind in ('candidate', 'mutant'))
IDS = ('test_fault_child_does_not_write_bytecode_to_source_tree',
       'test_output_scandir_oserror_exits_74', 'test_upload_stage_mkdir_oserror_exits_74')
SOURCES = {'tests/test_periodic_pilot_custody.py': 'c4b449311b922f75c7977918cc92f604e8779ba8',
           'tests/test_periodic_pilot_custody_oserror.py': '868772303875e148f61d2981cbf840b2eff1ad78',
           'tools/periodic_pilot_custody.py': '024f860f6cec1e603a083bb2f09f32d7e32a2399'}


def verify(path, digest):
    raw = Path(path).read_bytes()
    if hashlib.sha256(raw).hexdigest() != digest:
        raise ValueError('archive digest mismatch')
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        expected = {'console.txt', 'observation.json'} | {case + '.' + ext for case in CASES for ext in ('stdout', 'stderr')}
        if len(names) != len(set(names)) or set(names) != expected or z.testzip() is not None:
            raise ValueError('archive member or CRC mismatch')
        obs, console = (json.loads(z.read(name)) for name in ('observation.json', 'console.txt'))
        if (not obs.get('python', '').startswith('3.11.') or console != {'python': obs['python'], 'cases': 16, 'qualified': 16}
                or obs.get('source_git_blobs') != SOURCES or obs.get('mutation') != 'remove only the child -B flag'):
            raise ValueError('observation context mismatch')
        rows = obs.get('cases')
        if not isinstance(rows, list) or [r.get('case') for r in rows] != list(CASES):
            raise ValueError('case population mismatch')
        for row in rows:
            case = row['case']
            mutated = case.endswith('-mutant')
            out, err = (z.read(case + '.' + ext) for ext in ('stdout', 'stderr'))
            if (out or row.get('stdout_sha256') != hashlib.sha256(out).hexdigest()
                    or row.get('stderr_sha256') != hashlib.sha256(err).hexdigest()
                    or row.get('returncode') != (1 if mutated else 0) or row.get('qualified') is not True):
                raise ValueError('stream digest or status mismatch')
            text = err.decode('utf-8')
            result = []
            for line in text.splitlines():
                match = re.fullmatch(r'(\w+) \(test_periodic_pilot_custody_oserror\.RawOSErrorExitTests\.\w+\) \.\.\. (ok|FAIL)', line)
                if match:
                    result.append(match.groups())
            wanted = [(name, 'FAIL' if mutated and i == 0 else 'ok') for i, name in enumerate(IDS)]
            if result != wanted:
                raise ValueError('test result mismatch')
            if (row.get('results') != [list(x) for x in wanted] or 'skipped' in text
                    or not re.search(r'(?m)^Ran 3 tests in [0-9.]+s$', text)
                    or not text.rstrip().endswith('FAILED (failures=1)' if mutated else 'OK')):
                raise ValueError('summary mismatch')
            if mutated and ('in test_fault_child_does_not_write_bytecode_to_source_tree' not in text
                            or "self.assertEqual(list(tools.rglob('*.pyc')), [])" not in text
                            or 'periodic_pilot_custody.cpython-311.pyc' not in text):
                raise ValueError('mutant failure trace mismatch')
    return {'artifact_sha256': digest, 'python': obs['python'], 'cases': len(CASES),
            'scope': 'one hosted custody import-shadow observation; not full G5 or a general mutation grader'}


if __name__ == '__main__':
    if len(sys.argv) != 3:
        raise SystemExit('usage: verify_focused_shadow.py ZIP SHA256')
    print(json.dumps(verify(sys.argv[1], sys.argv[2]), indent=2))
