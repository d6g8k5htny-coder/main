"""Exercise a candidate child -B flag only in temporary source copies."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'repro-source'
TEST = 'tests/test_periodic_pilot_custody_oserror.py'
EXPECTED = '1013b0dad8fc213d786921cf8d9221698937815b'
raw = (SOURCE / TEST).read_bytes()
blob = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
if blob != EXPECTED:
    raise ValueError('native test source mismatch')
anchor = b"subprocess.run([sys.executable, '-c', FAULT, mode, str(REPO)]"
replacement = b"subprocess.run([sys.executable, '-B', '-c', FAULT, mode, str(REPO)]"
if raw.count(anchor) != 1:
    raise ValueError('expected child invocation is not unique')
modified = raw.replace(anchor, replacement, 1)
results = []
for optimized in (False, True):
    with tempfile.TemporaryDirectory(prefix='main809-custody-child-b-') as temp:
        checkout = Path(temp) / 'source'
        shutil.copytree(SOURCE, checkout)
        (checkout / TEST).write_bytes(modified)
        env = dict(os.environ)
        env.pop('PYTHONDONTWRITEBYTECODE', None)
        cmd = [sys.executable, '-B', '-S'] + (['-O'] if optimized else []) + [
            '-m', 'unittest', 'discover', '-s', 'tests', '-p',
            'test_periodic_pilot_custody_oserror.py', '-v']
        p = subprocess.run(cmd, cwd=checkout, env=env, capture_output=True, timeout=120)
        paths = sorted(x.relative_to(checkout).as_posix() for x in checkout.rglob('*.pyc'))
        label = 'optimized' if optimized else 'normal'
        (ROOT / ('repro-child-b-' + label + '.stdout')).write_bytes(p.stdout)
        (ROOT / ('repro-child-b-' + label + '.stderr')).write_bytes(p.stderr)
        if p.returncode != 0 or b'Ran 2 tests' not in p.stderr or not p.stderr.rstrip().endswith(b'OK') or paths:
            raise ValueError('candidate child -B did not pass without bytecode: ' + label)
        results.append({'parent_mode': label, 'exit': p.returncode, 'tests': 2,
                        'pyc_paths': paths, 'stdout_sha256': hashlib.sha256(p.stdout).hexdigest(),
                        'stderr_sha256': hashlib.sha256(p.stderr).hexdigest()})
out = {'python': sys.version, 'native_test_blob': blob,
       'candidate_test_sha256': hashlib.sha256(modified).hexdigest(),
       'change': 'insert -B before -c in the child Python invocation',
       'environment': 'PYTHONDONTWRITEBYTECODE absent', 'cases': results,
       'scope': 'isolated candidate in temporary copies; not integrated or full discovery qualification'}
(ROOT / 'repro-child-b-results.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps(out, indent=2))
