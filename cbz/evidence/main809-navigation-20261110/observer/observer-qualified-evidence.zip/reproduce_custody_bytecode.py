"""Observe the native custody OSError tests in temporary source copies only."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'repro-source'
EXPECTED = {
    'tests/test_periodic_pilot_custody.py': 'c4b449311b922f75c7977918cc92f604e8779ba8',
    'tests/test_periodic_pilot_custody_oserror.py': '1013b0dad8fc213d786921cf8d9221698937815b',
    'tools/periodic_pilot_custody.py': '024f860f6cec1e603a083bb2f09f32d7e32a2399',
}
for name, expected in EXPECTED.items():
    data = (SOURCE / name).read_bytes()
    got = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    if got != expected:
        raise ValueError('native source mismatch: ' + name)

results = []
for optimized in (False, True):
    for prevent_bytecode in (False, True):
        with tempfile.TemporaryDirectory(prefix='main809-custody-repro-') as temp:
            checkout = Path(temp) / 'source'
            shutil.copytree(SOURCE, checkout)
            env = dict(os.environ)
            env.pop('PYTHONDONTWRITEBYTECODE', None)
            if prevent_bytecode:
                env['PYTHONDONTWRITEBYTECODE'] = '1'
            cmd = [sys.executable, '-B', '-S'] + (['-O'] if optimized else []) + [
                '-m', 'unittest', 'discover', '-s', 'tests', '-p',
                'test_periodic_pilot_custody_oserror.py', '-v']
            p = subprocess.run(cmd, cwd=checkout, env=env, capture_output=True, timeout=120)
            paths = sorted(x.relative_to(checkout).as_posix() for x in checkout.rglob('*.pyc'))
            label = ('optimized' if optimized else 'normal') + ('-env1' if prevent_bytecode else '-envunset')
            (ROOT / ('repro-custody-' + label + '.stdout')).write_bytes(p.stdout)
            (ROOT / ('repro-custody-' + label + '.stderr')).write_bytes(p.stderr)
            if p.returncode != 0 or b'Ran 2 tests' not in p.stderr or not p.stderr.rstrip().endswith(b'OK'):
                raise ValueError('native test execution failed: ' + label)
            expected = [] if prevent_bytecode else [
                'tools/__pycache__/periodic_pilot_custody.' + sys.implementation.cache_tag + '.pyc']
            if paths != expected:
                raise ValueError('unexpected bytecode population: ' + label + ' ' + repr(paths))
            results.append({'case': label, 'exit': p.returncode, 'tests': 2, 'pyc_paths': paths,
                            'stdout_sha256': hashlib.sha256(p.stdout).hexdigest(),
                            'stderr_sha256': hashlib.sha256(p.stderr).hexdigest()})

out = {'python': sys.version, 'cache_tag': sys.implementation.cache_tag,
       'native_source_blobs': EXPECTED, 'cases': results,
       'scope': 'isolated copies of three native source blobs; CPython 3.12 local; not the original hosted run, full discovery, G5 or scientific evidence'}
(ROOT / 'repro-custody-results.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps(out, indent=2))
