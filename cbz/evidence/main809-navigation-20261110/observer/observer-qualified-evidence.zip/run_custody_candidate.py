"""Run the candidate custody tests in fresh temporary copies in both modes."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

root = Path(__file__).resolve().parent
source = root / 'candidate-source'
label = sys.argv[1]
results = []
for optimized in (False, True):
    with tempfile.TemporaryDirectory(prefix='main809-custody-candidate-') as directory:
        checkout = Path(directory) / 'source'
        shutil.copytree(source, checkout)
        env = dict(os.environ)
        env.pop('PYTHONDONTWRITEBYTECODE', None)
        command = [sys.executable, '-B', '-S'] + (['-O'] if optimized else []) + [
            '-m', 'unittest', 'discover', '-s', 'tests', '-p',
            'test_periodic_pilot_custody_oserror.py', '-v']
        run = subprocess.run(command, cwd=checkout, env=env, capture_output=True, timeout=120)
        mode = 'optimized' if optimized else 'normal'
        (root / ('candidate-' + label + '-' + mode + '.stdout')).write_bytes(run.stdout)
        (root / ('candidate-' + label + '-' + mode + '.stderr')).write_bytes(run.stderr)
        errors = run.stderr.decode('utf-8')
        if label == 'red':
            valid = (run.returncode != 0 and 'Ran 3 tests' in errors and 'FAILED (failures=1)' in errors
                     and 'test_fault_child_does_not_write_bytecode_to_source_tree' in errors
                     and errors.count(' ... ok') == 2)
        else:
            valid = (run.returncode == 0 and 'Ran 3 tests' in errors and errors.rstrip().endswith('OK')
                     and errors.count(' ... ok') == 3 and 'skipped' not in errors)
        if not valid:
            raise ValueError('unexpected candidate outcome: ' + label + '/' + mode + '\n' + errors)
        results.append({'mode': mode, 'exit': run.returncode, 'tests': 3,
                        'stderr_sha256': hashlib.sha256(run.stderr).hexdigest()})
output = {'label': label, 'python': sys.version, 'results': results,
          'test_sha256': hashlib.sha256((source / 'tests/test_periodic_pilot_custody_oserror.py').read_bytes()).hexdigest(),
          'scope': 'temporary source copies; focused tests only; not integrated or federation G5'}
(root / ('candidate-' + label + '-results.json')).write_text(json.dumps(output, indent=2) + '\n')
print(json.dumps(output, indent=2))
