"""Read the original Main #812 v2 old-base navigation artifact with explicit skip limits."""
import hashlib
import json
from pathlib import Path
import re
import sys
import zipfile

METHODS = (
    'test_all_actual_parent_fixture_and_subtest_non_successes_cannot_qualify',
    'test_fresh_pattern_dependent_load_tests_disagreement_refuses_before_body',
    'test_interrupted_incomplete_nonzero_and_damaged_journals_cannot_qualify',
    'test_native_pattern_censuses_select_actual_membership_not_id_prefix',
    'test_omitted_duplicate_extra_zero_and_import_failed_inventories_refuse',
    'test_original_zip_member_bytes_and_inert_api_bindings_are_both_checked',
    'test_pilot_success_can_never_produce_main_discovery_qualification',
    'test_real_unchanged_reader_accepts_only_labelled_test_archive_then_exact_join_membership',
    'test_safe_original_cases_preserve_fixture_lifecycle_and_unsafe_suites_refuse',
    'test_source_runtime_closed_records_stale_context_and_missing_producers_refuse',
)
EXPECTED_LINES = [name + ' (test_unittest_full_qualification.MainUnittestQualificationContract.' + name + ') ... ok' for name in METHODS]
NEW_TEST = 'test_fault_child_does_not_write_bytecode_to_source_tree (test_periodic_pilot_custody_oserror.RawOSErrorExitTests.test_fault_child_does_not_write_bytecode_to_source_tree) ... ok'


def verify(path, digest):
    data = Path(path).read_bytes()
    if hashlib.sha256(data).hexdigest() != digest:
        raise ValueError('artifact digest mismatch')
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        expected = {'commit.txt', 'history-reader.log', 'graph525-optimized.log', 'landing.txt',
                    'navigation.json', 'python.txt', 'tests-normal.log'}
        if len(names) != len(set(names)) or set(names) != expected or z.testzip() is not None:
            raise ValueError('artifact member or CRC mismatch')
        if (z.read('commit.txt').decode().strip() != 'd314fe2f756155c21bc432eb8a28e4989a47c632'
                or z.read('python.txt').decode().strip() != 'Python 3.11.18'):
            raise ValueError('tested context mismatch')
        text = z.read('tests-normal.log').decode('utf-8')
        lines = text.splitlines()
        target_lines = [line for line in lines if '(test_unittest_full_qualification.MainUnittestQualificationContract.' in line]
        if target_lines != EXPECTED_LINES:
            raise ValueError('selected qualification tests differ')
        summaries = [i for i, line in enumerate(lines) if re.fullmatch(r'Ran 2785 tests in [0-9.]+s', line)]
        if (lines.count(NEW_TEST) != 1 or sum(' ... skipped ' in line for line in lines) != 23
                or len(summaries) != 1 or lines[summaries[0] + 1:summaries[0] + 3] != ['', 'OK (skipped=23)']):
            raise ValueError('full navigation summary differs')
        nav = json.loads(z.read('navigation.json'))
        if nav.get('problems') != []:
            raise ValueError('navigation reported problems')
    return {'artifact_sha256': digest, 'tested_merge': 'd314fe2f756155c21bc432eb8a28e4989a47c632',
            'python': '3.11.18', 'normal_tests': 2785, 'skips': 23, 'selected_qualification_tests': 10,
            'scope': 'recorded summary in original normal navigation artifact, with buffered output after it; skips mean not full G5; no optimized full discovery or science claim'}


if __name__ == '__main__':
    if len(sys.argv) != 3:
        raise SystemExit('usage: verify_v1_navigation.py ZIP SHA256')
    print(json.dumps(verify(sys.argv[1], sys.argv[2]), indent=2))
