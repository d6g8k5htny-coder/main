"""Check candidate and flag-removal mutation under an inherited cache prefix."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

root = Path(__file__).resolve().parent
source = root / 'candidate-shadow-fixed'
test_path = 'tests/test_periodic_pilot_custody_oserror.py'
candidate = (source / test_path).read_bytes()
anchor = b"subprocess.run([sys.executable, '-B', '-c', FAULT, mode, str(REPO)]"
replacement = b"subprocess.run([sys.executable, '-c', FAULT, mode, str(REPO)]"
if candidate.count(anchor) != 1 or b"os.environ.pop('PYTHONPYCACHEPREFIX', None)" not in candidate:
    raise ValueError('candidate or cache-prefix control mismatch')
mutant = candidate.replace(anchor, replacement, 1)
records = []
for optimized in (False, True):
    for mutated in (False, True):
        with tempfile.TemporaryDirectory(prefix='main812-cache-prefix-fixed-') as temp:
            checkout = Path(temp) / 'source'
            shutil.copytree(source, checkout)
            if mutated:
                (checkout / test_path).write_bytes(mutant)
            env = dict(os.environ)
            env.pop('PYTHONDONTWRITEBYTECODE', None)
            env.pop('PYTHONPATH', None)
            env['PYTHONPYCACHEPREFIX'] = str(Path(temp) / 'external-pycache')
            command = [sys.executable, '-B', '-S'] + (['-O'] if optimized else []) + [
                '-m', 'unittest', 'discover', '-s', 'tests', '-p',
                'test_periodic_pilot_custody_oserror.py', '-v']
            run = subprocess.run(command, cwd=checkout, env=env, capture_output=True, timeout=120)
            stderr = run.stderr.decode('utf-8')
            name = ('optimized' if optimized else 'normal') + ('-mutant' if mutated else '-candidate')
            (root / ('prefix-shadow-fixed-' + str(sys.version_info.minor) + '-' + name + '.stderr')).write_bytes(run.stderr)
            suffix = 'FAILED (failures=1)' if mutated else 'OK'
            if (run.returncode != (1 if mutated else 0) or 'Ran 3 tests' not in stderr
                    or not stderr.rstrip().endswith(suffix) or 'skipped' in stderr
                    or ('test_fault_child_does_not_write_bytecode_to_source_tree' not in stderr)):
                raise ValueError('unexpected result for ' + name + '\n' + stderr)
            records.append({'case': name, 'exit': run.returncode,
                            'stderr_sha256': hashlib.sha256(run.stderr).hexdigest()})
result = {'python': sys.version, 'candidate_sha256': hashlib.sha256(candidate).hexdigest(),
          'mutation': 'remove child -B', 'environment': 'inherited PYTHONPYCACHEPREFIX',
          'cases': records, 'scope': 'local isolated controls; not full regression or hosted qualification'}
(root / ('prefix-shadow-fixed-' + str(sys.version_info.minor) + '-results.json')).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
