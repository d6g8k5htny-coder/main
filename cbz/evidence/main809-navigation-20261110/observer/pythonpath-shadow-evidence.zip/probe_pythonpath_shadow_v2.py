"""Exercise the actual focused custody regression under an inherited tools package."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile

root = Path(__file__).resolve().parent
source = root / sys.argv[1]
results = []
for optimized in (False, True):
    for mutant in (False, True):
        with tempfile.TemporaryDirectory(prefix='main812-shadow-') as directory:
            base = Path(directory)
            checkout = base / 'checkout'
            shutil.copytree(source, checkout)
            external = base / 'external'
            package = external / 'tools'
            package.mkdir(parents=True)
            (package / '__init__.py').write_text('')
            shutil.copyfile(source / 'tools/periodic_pilot_custody.py', package / 'periodic_pilot_custody.py')
            test = checkout / 'tests/test_periodic_pilot_custody_oserror.py'
            original = test.read_text()
            needle = "[sys.executable, '-B', '-c', FAULT, mode, str(REPO)]"
            if original.count(needle) != 1:
                raise ValueError('unexpected original source')
            if mutant:
                test.write_text(original.replace(needle, "[sys.executable, '-c', FAULT, mode, str(REPO)]"))
            env = dict(os.environ)
            env.pop('PYTHONDONTWRITEBYTECODE', None)
            env.pop('PYTHONPYCACHEPREFIX', None)
            env['PYTHONPATH'] = str(external)
            cmd = [sys.executable, '-B', '-S'] + (['-O'] if optimized else []) + [
                '-m', 'unittest', 'discover', '-s', 'tests', '-p',
                'test_periodic_pilot_custody_oserror.py', '-v']
            p = subprocess.run(cmd, cwd=checkout, env=env, capture_output=True, timeout=120)
            mode = 'optimized' if optimized else 'normal'
            label = sys.argv[1] + '-' + str(sys.version_info.minor) + '-' + mode + ('-mutant' if mutant else '-candidate')
            (root / ('pythonpath-shadow-' + label + '.stdout')).write_bytes(p.stdout)
            (root / ('pythonpath-shadow-' + label + '.stderr')).write_bytes(p.stderr)
            caches = sorted(str(x.relative_to(external)) for x in external.rglob('*.pyc'))
            results.append({'mode': mode, 'mutant_removes_child_B': mutant,
                            'exit': p.returncode, 'external_bytecode': caches,
                            'stderr_sha256': hashlib.sha256(p.stderr).hexdigest()})
output = {'python': sys.version, 'test_source_sha256': hashlib.sha256((source / 'tests/test_periodic_pilot_custody_oserror.py').read_bytes()).hexdigest(),
          'scope': 'temporary source copies and inherited PYTHONPATH; original assertions retained',
          'results': results}
(root / ('pythonpath-shadow-' + sys.argv[1] + '-' + str(sys.version_info.minor) + '-results.json')).write_text(
    json.dumps(output, indent=2) + '\n')
print(json.dumps(output, indent=2))
