"""External observer: retain actual admitted populations/events without changing source."""
import hashlib,json,pathlib,sys,unittest
root=pathlib.Path.cwd();sys.path.insert(0,str(root))
from tests import test_formal_compiled_inventory as inventory
from tests import test_formal_source_custody as custody
out=pathlib.Path(sys.argv[1]); records=[]
kill=inventory.require_policy_mutation_kill; baseline=inventory.require_policy_control
labels=['ignore_noise','allow_forbidden','allow_extra_constant','allow_missing_module','allow_duplicate_constant','allow_extra_theorem','allow_bad_count','ignore_blob_bytes','ignore_modes','accept_changed_head','ignore_manifest_arguments','ignore_loaded_sources','omit_untracked_inputs','allow_git_replacements','omit_initial_binding','omit_final_binding']
def observation(result,ids):
 return {'selected_ids':ids,'testsRun':result.testsRun,'failures':[case.id() for case,_ in result.failures],'errors':[case.id() for case,_ in result.errors],'skips':result.skipped,'expectedFailures':len(result.expectedFailures),'unexpectedSuccesses':len(result.unexpectedSuccesses),'records':[{k:v for k,v in record.items() if k!='test'} for record in result.records],'events':[{'parent_id':e['test'].id(),'failure_id':e['failure_test'].id(),'phase':e['phase'],'kind':e['kind']} for e in result.events],'transcript':result.stream.stream.getvalue()}
def observe_kill(result,ids,expected):
 kill(result,ids,expected)
 records.append(dict(label=labels[sum(r['kind']=='mutant' for r in records)],kind='mutant',expected_failures=sorted(expected),admitted=True,**observation(result,ids)))
def observe_baseline(result,ids):
 baseline(result,ids)
 records.append(dict(label='compiled-baseline' if not records else 'custody-baseline',kind='baseline',admitted=True,**observation(result,ids)))
inventory.require_policy_mutation_kill=observe_kill;inventory.require_policy_control=observe_baseline
try:
 suite=unittest.TestSuite([inventory.AuditorMutationTests('test_policy_mutants_are_killed'),custody.CustodySourceMutationTests('test_nine_declared_source_mutants_have_reason_bound_kills')])
 result=unittest.TextTestRunner(verbosity=2).run(suite)
finally:
 inventory.require_policy_mutation_kill=kill;inventory.require_policy_control=baseline
out.write_text(json.dumps({'python':sys.version,'optimized':sys.flags.optimize,'sources':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [pathlib.Path('tests/test_formal_compiled_inventory.py'),pathlib.Path('tests/test_formal_source_custody.py'),pathlib.Path('formal/manifest.json')]},'observations':records},indent=2)+'\n')
if not result.wasSuccessful() or len(records)!=18: sys.exit(1)
