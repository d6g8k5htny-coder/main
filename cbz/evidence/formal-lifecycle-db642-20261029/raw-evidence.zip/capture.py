import json, pathlib, subprocess, sys, time
out=pathlib.Path(__file__).with_name('raw')
label=sys.argv[1]
args=sys.argv[2:]
p=subprocess.run(args,cwd='/workspace/scratch/db6428847655/cbz/worktrees/main-lifecycle',text=True,capture_output=True)
(out/(label+'.stdout')).write_text(p.stdout)
(out/(label+'.stderr')).write_text(p.stderr)
(out/(label+'.json')).write_text(json.dumps({'argv':args,'cwd':str(pathlib.Path.cwd()),'returncode':p.returncode,'interpreter':sys.version,'timestamp':time.time()},indent=2)+'\n')
print(label, 'returncode=',p.returncode)
print(p.stdout)
print(p.stderr)
sys.exit(p.returncode)
