import ast,hashlib,json,os,pathlib,stat,subprocess
root=pathlib.Path.cwd();out=pathlib.Path(__file__).parent
base=json.loads((out/'base-test-contracts.json').read_text());summary={}
for path,contract in base.items():
 tree=ast.parse(pathlib.Path(path).read_text());methods={};definitions=[]
 for cls in tree.body:
  if isinstance(cls,ast.ClassDef):
   for method in cls.body:
    if isinstance(method,(ast.FunctionDef,ast.AsyncFunctionDef)) and method.name.startswith('test_'):
     key=cls.name+'.'+method.name;methods[key]=ast.dump(method,include_attributes=False)
     for node in ast.walk(method):
      if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ('mutations','expected_failures') for t in node.targets):
       definitions.append({'method':key,'target':[t.id for t in node.targets if isinstance(t,ast.Name)],'ast':ast.dump(node.value,include_attributes=False)})
 missing=sorted(set(contract['test_methods'])-set(methods))
 if missing or definitions!=contract['mutation_definitions']:raise AssertionError((path,missing))
 summary[path]={'prior_methods':len(contract['test_methods']),'current_methods':len(methods),'missing_methods':missing,'mutation_definitions_identical':True,'sha256':hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()}
allowed=set(base)|{'formal/manifest.json'}
changed=subprocess.check_output(['git','diff','--name-only','7b165770'],text=True).splitlines()
if not set(changed)<=allowed:raise AssertionError(changed)
old=json.loads(subprocess.check_output(['git','show','7b165770:formal/manifest.json'],text=True));new=json.loads(pathlib.Path('formal/manifest.json').read_text())
for path in base:
 if new['files'][path]!=summary[path]['sha256']:raise AssertionError('unbound test source')
 old['files'][path]=new['files'][path]
if old!=new:raise AssertionError('protected manifest policy changed')
base_tree=json.loads((out/'base-tree.json').read_text());checked=[];different=[]
for item in base_tree['entries']:
 if item['path'] in allowed:continue
 path=pathlib.Path(item['path'])
 if item['type']!='blob':raise AssertionError(item)
 raw=os.readlink(path).encode() if path.is_symlink() else path.read_bytes()
 digest=hashlib.sha1(('blob %d\0'%len(raw)).encode()+raw).hexdigest()
 mode='120000' if path.is_symlink() else ('100755' if path.stat().st_mode&stat.S_IXUSR else '100644')
 if digest!=item['sha'] or mode!=item['mode']:different.append(item['path'])
 checked.append(item['path'])
if different:raise AssertionError(different)
summary['protected']={'checked_blobs_and_modes':len(checked),'different':different,'changed_tracked_paths':changed,'only_manifest_hash_fields_changed':sorted(base),'base':base_tree['commit']}
(out/'preservation-final.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
