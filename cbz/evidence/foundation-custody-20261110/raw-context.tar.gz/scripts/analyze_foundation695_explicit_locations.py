"""Resolve explicitly named paths from nine historic location forms, not claims."""
import hashlib,json,os,subprocess
from pathlib import Path
root=Path('/workspace/scratch/7abea556a9be'); catalog=json.loads((root/'recovered-foundation-695/catalog.json').read_bytes()); rows={r['id']:r for r in catalog['quarantines']};env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_TERMINAL_PROMPT='0',GIT_OPTIONAL_LOCKS='0',GIT_LITERAL_PATHSPECS='1')
base={'main':root/'cbz-main-g1-origin','trial':root/'federation-vector-post-integration-20261109/trial'};current={'main':'eed4e646565bf670d87b5ec41b9ae18f8a20d35a','trial':'3738c859d519d2dbf1e388fe48fe0ae60c9487a3'}
def lookup(repo,commit,path):
 p=subprocess.run(['git','-C',str(base[repo]),'ls-tree','-z','--full-tree',commit,'--',path],env=env,capture_output=True,check=True);out=[x for x in p.stdout.split(b'\0') if x]
 if not out:return None
 assert len(out)==1;meta,name=out[0].split(b'\t',1);mode,kind,obj=meta.split(b' ');assert name.decode()==path
 return {'mode':mode.decode(),'kind':kind.decode(),'object':obj.decode()}
def cmp(repo,commit,path):
 a,b=lookup(repo,commit,path),lookup(repo,current[repo],path);return {'repository':repo,'source_commit':commit,'path':path,'source_entry':a,'current_commit':current[repo],'current_entry':b,'comparison':'SOURCE_MISSING' if a is None else 'CURRENT_MISSING' if b is None else 'IDENTICAL' if a==b else 'CHANGED'}
out=[]
configs=[('Q-8336','3ab12c6542c88554ad0d42e0e19aff2461dc3c0d','experiments/universality/quartic_cusp_field',['PROOF.md','REVIEW.md'],'cbz-quarantine-q-8336','05d7516c4ddc303732ca69e4ea251b90ab6ace71'),('Q-8340','f02758555b4bce4554e34e8913947f69578d0816','experiments/universality/two_parameter_cusp_population',['PROOF.md','REVIEW.md'],'cbz-quarantine-q-8340','9632605e623b7c517dc0cddd099c6687376f4036'),('Q-8429','16764aab8ce7b74327276ac4be619f2d3e4ed4af','experiments/universality/fold_isolation_diagonal',[], 'cbz-quarantine-q-8429','b552f251228ef158ef3d5313becccfde22b9d4ec')]
for ident,commit,path,files,tag,tag_obj in configs:
 loc=rows[ident]['location'];assert commit in loc and path in loc and tag in loc
 resolved=[cmp('main',commit,path+'/'+f) for f in files] if files else [cmp('main',commit,path)]
 unresolved=['README row path not specified in historical location'] if files else []
 out.append({'id':ident,'input':loc,'tag':tag,'tag_object':tag_obj,'peeled_commit':commit,'resolved_paths':resolved,'unresolved':unresolved,'current_admission':'UNASSESSED'})
for ident in ('Q-9001','Q-9002','Q-9003','Q-9004','Q-9005','Q-9006'):
 loc=rows[ident]['location'];repo,commit=loc['repository'],loc['commit']; names=loc.get('paths') or [loc['path'],loc['schema']]
 resolved=[cmp(repo,commit,p.rstrip('/')) for p in names];unresolved=[]
 if 'records' in loc:unresolved.append('record glob and live state not compared: '+loc['records'])
 out.append({'id':ident,'input':loc,'resolved_paths':resolved,'unresolved':unresolved,'current_admission':'UNASSESSED'})
assert len(out)==9
p=root/'recovered-foundation-695/explicit-locations-20261110.json';report={'scope':'Exact tree entries for explicitly named historical locations and observed annotated tag targets; no claim, live state, scientific review or quarantine admission is established.','rows':out,'cbz_green':False};p.write_text(json.dumps(report,indent=2)+'\n')
for row in out:print(row['id'],[(x['path'],x['comparison']) for x in row['resolved_paths']], 'unresolved',len(row['unresolved']))
print('sha256',hashlib.sha256(p.read_bytes()).hexdigest())
