import hashlib,json,os,subprocess
from pathlib import Path
root=Path('/workspace/scratch/7abea556a9be');base=root/'recovered-foundation-695';m=json.loads((base/'archive-sources-manifest.json').read_bytes());tags=json.loads((base/'archive-tag-observation.json').read_bytes());env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_TERMINAL_PROMPT='0',GIT_OPTIONAL_LOCKS='0',GIT_LITERAL_PATHSPECS='1')
assert len(tags['tags'])==len(m['archives'])==3;total=0;all_paths=set();unique=set()
for row in m['archives']:
 tag=next(x for x in tags['tags'] if x['tag']==row['tag']);assert tag['ref_object']==row['tag_object'] and tag['peeled_object']['sha']==row['commit'] and tag['peeled_object']['type']=='commit'
 p=subprocess.run(['git','-C',str(root/'cbz-main-g1-origin'),'ls-tree','-r','-z','--full-tree',row['commit'],'--',row['source_path']],env=env,capture_output=True,check=True)
 native={}
 for line in p.stdout.split(b'\0'):
  if line:
   meta,name=line.split(b'\t',1);mode,kind,blob=meta.decode().split();native[name.decode()]=(mode,kind,blob)
 assert len(native)==len(row['files'])
 for f in row['files']:
  assert native[f['path']]==(f['mode'],'blob',f['blob']);path=base/'archive-sources'/row['id']/f['path'];assert path.is_file() and not path.is_symlink();raw=path.read_bytes();assert len(raw)==f['bytes'] and hashlib.sha256(raw).hexdigest()==f['sha256'] and hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==f['blob'];all_paths.add(path);unique.add(f['blob']);total+=len(raw)
found={p for p in (base/'archive-sources').rglob('*') if p.is_file()};assert found==all_paths and len(found)==87 and len(unique)==72 and total==m['total_file_bytes']==697375
print('PASS 3 annotated tag targets, 87 exact source files, 72 Git blobs, 697375 file bytes; SHA-1 Git identities and SHA-256 content hashes match')
