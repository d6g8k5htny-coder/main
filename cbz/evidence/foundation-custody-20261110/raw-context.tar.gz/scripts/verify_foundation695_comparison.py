"""Independently compare each exact path using direct Git tree lookups."""
import collections,concurrent.futures,hashlib,json,os,re,subprocess
from pathlib import Path
root=Path('/workspace/scratch/7abea556a9be');p=root/'recovered-foundation-695/catalog-comparison-20261110.json';x=json.loads(p.read_bytes());raw=(root/'recovered-foundation-695/catalog.json').read_bytes();assert hashlib.sha256(raw).hexdigest()==x['catalog_sha256']
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_TERMINAL_PROMPT='0',GIT_OPTIONAL_LOCKS='0',GIT_LITERAL_PATHSPECS='1')
paths={'main':root/'cbz-main-g1-origin','Math-':root/'math-branch-ancestry-20261109.git'};curr={'main':root/'cbz-main-g1-origin','Math-':root/'federation-vector-post-integration-20261109/Math-'}
expected={}
for row in x['rows']:
 for b in row['bindings']:
  if 'repository' not in b:continue
  repo,path=b['repository'],b['path']
  for tag in ('source','current'):
   key=(repo,b[tag+'_commit'],path); entry=b[tag+'_tree_entry'];assert key not in expected or expected[key]==entry;expected[key]=entry
def lookup(item):
 (repo,commit,path),want=item; p=curr[repo] if commit==x['current_source_cuts'][repo] else paths[repo]
 r=subprocess.run(['git','-C',str(p),'ls-tree','-z','--full-tree',commit,'--',path],env=env,capture_output=True,check=True);parts=[q for q in r.stdout.split(b'\0') if q]
 if not parts:actual=None
 else:
  assert len(parts)==1;meta,name=parts[0].split(b'\t',1);mode,kind,obj=meta.split(b' ');assert name.decode('utf-8','surrogateescape')==path;actual={'mode':mode.decode(),'kind':kind.decode(),'object':obj.decode()}
 if actual!=want:raise ValueError((repo,commit,path,want,actual))
 return 1
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool: count=sum(pool.map(lookup,expected.items()))
assert count==334
states=collections.Counter(b['comparison'] for r in x['rows'] for b in r['bindings']);assert states==collections.Counter({'IDENTICAL_MODE_KIND_OBJECT':354,'CHANGED_MODE_KIND_OR_OBJECT':5,'UNASSESSED_LOCATION_SYNTAX':3,'UNASSESSED_STRUCTURED_LOCATION':6})
assert len(x['rows'])==184 and sum(r['source_status'] is None for r in x['rows'])==6 and all(not r['missing_required_fields'] and r['owner']=='none' and r['maintenance']=='zero' and r['current_admission']=='UNASSESSED' for r in x['rows'])
print('PASS 334 distinct direct Git tree lookups reproduce all 359 parsed location comparisons; nine other location forms unassessed; 184 field-presence checks do not certify current mathematical admission')
