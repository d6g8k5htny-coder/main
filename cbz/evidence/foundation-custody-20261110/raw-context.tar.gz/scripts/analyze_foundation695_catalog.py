"""Non-admitting Git-tree comparison of historical #695 catalog locations."""
import collections,hashlib,json,os,re,subprocess
from pathlib import Path
root=Path('/workspace/scratch/7abea556a9be'); raw=(root/'recovered-foundation-695/catalog.json').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='6fb095df59726f6ee13b265dd88440e1a5f0c7ca7a5025643fd1bbe9acab3ec7'
catalog=json.loads(raw); rows=catalog['quarantines']; assert len(rows)==184 and len({x['id'] for x in rows})==184
fields=('id','title','location','layer_a_status','exact_boundary','blocking_reason','attempted','resumption_cost','isolation','owner','maintenance')
current={'main':'c32e6f27d318e25708939105285366a7a0daf971','Math-':'9bdfc54b76173b57912503bfcf901a5f9d43b09c'}
repo_paths={'main':root/'cbz-main-g1-origin','Math-':root/'math-branch-ancestry-20261109.git'}
current_paths={'main':root/'cbz-main-g1-origin','Math-':root/'federation-vector-post-integration-20261109/Math-'}
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_TERMINAL_PROMPT='0',GIT_OPTIONAL_LOCKS='0'); cache={}
def tree(repo,commit):
 key=(repo,commit)
 if key not in cache:
  path=current_paths[repo] if commit==current[repo] else repo_paths[repo]
  p=subprocess.run(['git','-C',str(path),'ls-tree','-r','-t','-z','--full-tree',commit],env=env,capture_output=True,check=True)
  d={}
  for line in p.stdout.split(b'\0'):
   if not line:continue
   meta,name=line.split(b'\t',1);mode,kind,obj=meta.split(b' ');name=name.decode('utf-8','surrogateescape')
   assert name not in d;d[name]={'mode':mode.decode(),'kind':kind.decode(),'object':obj.decode()}
  cache[key]=d
 return cache[key]
items=[]; pattern=re.compile(r'^d6g8k5htny-coder/([^@]+)@([0-9a-f]{40}):([^#]+)(?:#.*)?$')
for r in rows:
 missing=[k for k in fields if k not in r or r[k] in (None,'',[],{})]
 locations=r['location'] if isinstance(r['location'],list) else [r['location']];bindings=[]
 for loc in locations:
  if not isinstance(loc,str):bindings.append({'input':loc,'comparison':'UNASSESSED_STRUCTURED_LOCATION'});continue
  m=pattern.fullmatch(loc)
  if not m or m.group(1) not in current:bindings.append({'input':loc,'comparison':'UNASSESSED_LOCATION_SYNTAX'});continue
  repo,commit,path=m.groups(); old=tree(repo,commit).get(path); new=tree(repo,current[repo]).get(path)
  if old is None:state='OLD_PATH_NOT_A_TRACKED_ENTRY'
  elif new is None:state='NO_CURRENT_ENTRY_AT_SAME_PATH'
  elif old==new:state='IDENTICAL_MODE_KIND_OBJECT'
  else:state='CHANGED_MODE_KIND_OR_OBJECT'
  bindings.append({'input':loc,'repository':repo,'source_commit':commit,'path':path,'source_tree_entry':old,'current_commit':current[repo],'current_tree_entry':new,'comparison':state})
 items.append({'id':r['id'],'title':r['title'],'source_status':r.get('status'),'proposal_status':r.get('proposal_status'),'missing_required_fields':missing,'owner':r.get('owner'),'maintenance':r.get('maintenance'),'bindings':bindings,'current_admission':'UNASSESSED'})
counts=collections.Counter(b['comparison'] for row in items for b in row['bindings'])
out={'schema':'cbz.historical-quarantine-catalog-comparison.v1','catalog_git_commit':'82d9e480a51b946b3e74525ccf32139129d37d28','catalog_git_blob':'892466e68f90a584e214f60c86c7c493d4f9c42e','catalog_sha256':hashlib.sha256(raw).hexdigest(),'source_cuts':catalog['source_cuts'],'current_source_cuts':current,'scope':'Historical unmerged proposal; Git tree entry comparisons only. Does not validate semantic anchors, proof statements, isolation, mathematical blocking reasons, kernel outcomes, reviews or current quarantine admission. Unparsed and missing locations are explicit; directories compare by tree object.','counts':dict(counts),'rows':items,'cbz_green':False}
p=root/'recovered-foundation-695/catalog-comparison-20261110.json';p.write_text(json.dumps(out,indent=2,ensure_ascii=True)+'\n')
print('rows',len(items),'missing required fields',sum(bool(x['missing_required_fields']) for x in items),'source-status absent',sum(x['source_status'] is None for x in items),'bindings',dict(counts),'trees',len(cache),'output_sha256',hashlib.sha256(p.read_bytes()).hexdigest())
