"""Compare leaves under changed historical directory bindings, without dispositions."""
import collections,hashlib,json,os,subprocess
from pathlib import Path
root=Path('/workspace/scratch/7abea556a9be');report=json.loads((root/'recovered-foundation-695/catalog-comparison-20261110.json').read_text());env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_TERMINAL_PROMPT='0',GIT_OPTIONAL_LOCKS='0')
def entries(repo,commit,path):
 p=subprocess.run(['git','-C',str(repo),'ls-tree','-r','-z','--full-tree',commit,'--',path],env=env,capture_output=True,check=True);out={}
 for line in p.stdout.split(b'\0'):
  if line:
   m,n=line.split(b'\t',1);mode,kind,sha=m.split(b' ');out[n.decode('utf-8','surrogateescape')]={'mode':mode.decode(),'kind':kind.decode(),'object':sha.decode()}
 return out
changes=[]
for row in report['rows']:
 for b in row['bindings']:
  if b['comparison']!='CHANGED_MODE_KIND_OR_OBJECT' or b['source_tree_entry']['kind']!='tree':continue
  old=entries(root/'math-branch-ancestry-20261109.git',b['source_commit'],b['path']);new=entries(root/'federation-vector-post-integration-20261109/Math-',b['current_commit'],b['path']);diff=[]
  for name in sorted(set(old)|set(new)):
   a,c=old.get(name),new.get(name)
   if a!=c:diff.append({'path':name,'status':'ADDED' if a is None else 'REMOVED' if c is None else 'CHANGED','source':a,'current':c})
  changes.append({'id':row['id'],'path':b['path'],'source_commit':b['source_commit'],'current_commit':b['current_commit'],'old_leaves':len(old),'current_leaves':len(new),'differences':diff})
out={'scope':'Git leaf identities under three historically recorded directory bindings; no theorem, semantic or quarantine disposition inferred.','directories':changes,'cbz_green':False};p=root/'recovered-foundation-695/directory-deltas-20261110.json';p.write_text(json.dumps(out,indent=2)+'\n')
for x in changes:print(x['id'],x['path'],'source/current',x['old_leaves'],x['current_leaves'],'diff',dict(collections.Counter(d['status'] for d in x['differences'])))
print('output sha256',hashlib.sha256(p.read_bytes()).hexdigest())
