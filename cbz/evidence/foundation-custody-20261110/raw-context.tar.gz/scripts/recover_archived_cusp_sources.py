"""Recover exact Git blob bytes for three historic unmerged archive subtrees."""
import hashlib,json,os,subprocess
from pathlib import Path,PurePosixPath
root=Path('/workspace/scratch/7abea556a9be');repo=root/'cbz-main-g1-origin';out=root/'recovered-foundation-695';env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_TERMINAL_PROMPT='0',GIT_OPTIONAL_LOCKS='0')
cases=[('Q-8336','3ab12c6542c88554ad0d42e0e19aff2461dc3c0d','experiments/universality/quartic_cusp_field','cbz-quarantine-q-8336','05d7516c4ddc303732ca69e4ea251b90ab6ace71'),('Q-8340','f02758555b4bce4554e34e8913947f69578d0816','experiments/universality/two_parameter_cusp_population','cbz-quarantine-q-8340','9632605e623b7c517dc0cddd099c6687376f4036'),('Q-8429','16764aab8ce7b74327276ac4be619f2d3e4ed4af','experiments/universality/fold_isolation_diagonal','cbz-quarantine-q-8429','b552f251228ef158ef3d5313becccfde22b9d4ec')]
rows=[];all_shas=set()
for ident,commit,path,tag,tag_obj in cases:
 r=subprocess.run(['git','-C',str(repo),'ls-tree','-r','-z','--full-tree',commit,'--',path],env=env,capture_output=True,check=True);items=[]
 for line in r.stdout.split(b'\0'):
  if not line:continue
  meta,name=line.split(b'\t',1);mode,kind,sha=meta.decode().split();name=name.decode('utf-8');assert mode=='100644' and kind=='blob' and PurePosixPath(name).is_relative_to(path) and '..' not in PurePosixPath(name).parts
  items.append({'path':name,'mode':mode,'blob':sha});all_shas.add(sha)
 assert len(items)=={'Q-8336':2,'Q-8340':2,'Q-8429':83}[ident]
 rows.append({'id':ident,'commit':commit,'source_path':path,'tag':tag,'tag_object':tag_obj,'files':items})
check=subprocess.run(['git','-C',str(repo),'cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)'],env=env,input=('\n'.join(sorted(all_shas))+'\n').encode(),capture_output=True,check=True)
missing=[line.split()[0] for line in check.stdout.decode().splitlines() if line.endswith(' missing')]
if missing:
 r=subprocess.run(['git','-C',str(repo),'-c','core.hooksPath=/dev/null','fetch','--no-tags','--no-write-fetch-head','--no-recurse-submodules','origin',*missing],env=env,capture_output=True,timeout=180)
 (out/'archive-blob-fetch.stdout').write_bytes(r.stdout);(out/'archive-blob-fetch.stderr').write_bytes(r.stderr);(out/'archive-blob-fetch.exit').write_text(str(r.returncode)+'\n')
 if r.returncode:raise RuntimeError('exact blob fetch failed')
cache={};total=0
for row in rows:
 for item in row['files']:
  sha=item['blob']
  if sha not in cache:
   raw=subprocess.run(['git','-C',str(repo),'cat-file','blob',sha],env=env,capture_output=True,check=True).stdout
   assert len(raw)<64*1024*1024 and hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==sha
   cache[sha]=raw
  raw=cache[sha];total+=len(raw);assert total<256*1024*1024
  target=out/'archive-sources'/row['id']/item['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);item.update(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
report={'scope':'Exact bytes of explicitly named subtrees at archived PR heads. This preserves source and recorded reviews without endorsing or updating their mathematics; the two nonspecific README rows remain unresolved.','archives':rows,'unique_blobs':len(all_shas),'initially_missing_blobs':len(missing),'total_file_bytes':total,'cbz_green':False}
p=out/'archive-sources-manifest.json';p.write_text(json.dumps(report,indent=2)+'\n');print('archives',len(rows),'files',sum(len(x['files']) for x in rows),'unique_blobs',len(all_shas),'fetched',len(missing),'bytes',total,'manifest_sha256',hashlib.sha256(p.read_bytes()).hexdigest())
