#!/usr/bin/env python3
"""Scope-aware local retrieval reference. It never writes to Drive or proves premises.

python reuse_tools.py lookup 'pin Jacobian'
python reuse_tools.py check OP01 --scope scope.json --source-dir refreshed_sources
python reuse_tools.py self-test --source-dir refreshed_sources

Save exact connector text in KEY.txt, including its original Unicode/newlines.
KEY is each source's key in OPERATIONS.json. Native frozen bodies use their stated
normalization. Source refresh and current disposition checks remain the caller's job.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import tempfile

HERE=Path(__file__).resolve().parent

def load_catalog(path=HERE/'OPERATIONS.json'):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def tokens(text):
    return set(re.findall(r'[\w]+',text.casefold()))

def lookup(catalog,query):
    words=tokens(query)
    ranked=[]
    for op in catalog['operations']:
        score=len(words & tokens(op['operation_id']+' '+op['title']+' '+op['intent']))
        if score:
            ranked.append((score,op))
    return [dict(operation_id=o['operation_id'],title=o['title'],reuse_state=o['reuse_state'],requires=o['requires'],utility=o['utility']) for _,o in sorted(ranked,key=lambda p:(-p[0],p[1]['operation_id']))]

def source_digest(source,raw):
    if 'frozen_body_reproduced_sha256' not in source:
        return hashlib.sha256(raw).hexdigest(),source['extraction_sha256']
    text=raw.decode('utf-8-sig').replace('\r\n','\n').replace('\r','\n')
    markers=re.findall(r'^BEGIN_[A-Z0-9_]+$',text,re.M)
    if len(markers)!=1:
        raise ValueError('Expected one frozen body marker')
    begin=markers[0]; end=begin.replace('BEGIN_','END_',1)
    if text.count('\n'+end)!=1:
        raise ValueError('Expected one end marker')
    body=text.split('\n'+begin+'\n',1)[1].split('\n'+end,1)[0].rstrip('\n')+'\n'
    return hashlib.sha256(body.encode()).hexdigest(),source['frozen_body_reproduced_sha256']

def check(catalog,operation_id,scope,source_dir=None):
    op=next((o for o in catalog['operations'] if o['operation_id']==operation_id),None)
    if op is None:
        return {'decision':'UNKNOWN_OPERATION','operation_id':operation_id}
    mismatch={k:{'required':v,'supplied':scope.get(k)} for k,v in op['requires'].items() if scope.get(k)!=v}
    result=dict(operation_id=operation_id,reuse_state=op['reuse_state'],utility=op['utility'],novelty=op['novelty'],action=op['action'],exclusions=op['exclusions'])
    if mismatch:
        return dict(result,decision='SCOPE_MISMATCH',mismatch=mismatch)
    if source_dir is None:
        return dict(result,decision='SOURCE_REFRESH_REQUIRED',source_keys=op['source_keys'])
    bindings={s['key']:s for s in catalog['sources']}
    checked=[]
    for key in op['source_keys']:
        source=bindings[key]; path=Path(source_dir)/(key+'.txt')
        try:
            actual,expected=source_digest(source,path.read_bytes())
        except (OSError,UnicodeError,ValueError,IndexError) as error:
            return dict(result,decision='SOURCE_REFRESH_REQUIRED',source_key=key,detail=str(error))
        if actual!=expected:
            return dict(result,decision='SOURCE_MISMATCH',source_key=key,expected=expected,actual=actual)
        checked.append({'key':key,'id':source['id'],'sha256':actual})
    decision={'CONDITIONAL_RULE':'SCOPE_MATCH_CONDITIONAL','CANDIDATE':'REVIEW_REQUIRED','NEGATIVE_RULE':'REJECT_CLAIM','REVIEW_ONLY':'REVIEW_REQUIRED','BLOCKED_AS_PROOF':'REJECT_CLAIM'}[op['reuse_state']]
    return dict(result,decision=decision,checked_sources=checked,note='Declared scope matched local refreshed bytes. This is not proof of premises, current acceptance, or enforcement on other agents.')

def self_test(catalog,source_dir):
    """Exposed development controls, not held-out performance trials."""
    results=[]
    def record(name,got,wanted):
        results.append({'test':name,'pass':got==wanted,'observed':got,'expected':wanted})
    ops={o['operation_id']:o for o in catalog['operations']}
    for oid,expected in [('OP01','SCOPE_MATCH_CONDITIONAL'),('OP06','SCOPE_MATCH_CONDITIONAL'),('OP08','REVIEW_REQUIRED'),('OP05','REJECT_CLAIM'),('OP14','REVIEW_REQUIRED'),('OP15','REJECT_CLAIM')]:
        record('declared scope '+oid,check(catalog,oid,ops[oid]['requires'],source_dir)['decision'],expected)
    record('intent retrieves Jacobian',lookup(catalog,'pin Jacobian')[0]['operation_id'],'OP01')
    record('intent retrieves cone',lookup(catalog,'cone integral')[0]['operation_id'],'OP08')
    record('absent source cannot clear use',check(catalog,'OP01',ops['OP01']['requires'])['decision'],'SOURCE_REFRESH_REQUIRED')
    record('unknown object',check(catalog,'OP999',{},source_dir)['decision'],'UNKNOWN_OPERATION')
    for oid,key,bad in [('OP01','dimension','3'),('OP01','frame','different_order'),('OP01','measure','selected_Palm'),('OP03','kappa','variable_in_r'),('OP06','remainder','eta_deleted'),('OP07','moments','only_fourth_moment'),('OP07','target','stretched_exponential'),('OP08','gaussian_mean','nonzero'),('OP08','matrix_size','3'),('OP12','r','all_small_r'),('OP12','coverage','whole_annulus'),('OP14','dimension','2')]:
        scope=dict(ops[oid]['requires']);scope[key]=bad
        record('reject '+oid+' '+key,check(catalog,oid,scope,source_dir)['decision'],'SCOPE_MISMATCH')
    scope=dict(ops['OP01']['requires']);scope.pop('frame')
    record('missing frame cannot be guessed',check(catalog,'OP01',scope,source_dir)['decision'],'SCOPE_MISMATCH')
    # A source change must actually change the guarded decision, not just its label.
    with tempfile.TemporaryDirectory() as d:
        (Path(d)/'rn5.txt').write_text('changed source bytes')
        record('source mutation',check(catalog,'OP04',ops['OP04']['requires'],d)['decision'],'SOURCE_MISMATCH')
    record('utility not manufactured',all(o['utility']=='UNMEASURED' for o in ops.values()),True)
    record('no fake formalization',all(o['machine_formalization']=='NOT_ESTABLISHED' for o in ops.values()),True)
    return dict(kind='exposed_development_controls',passed=sum(r['pass'] for r in results),total=len(results),heldout_utility_measured=False,results=results)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--catalog',default=str(HERE/'OPERATIONS.json'))
    sub=parser.add_subparsers(dest='cmd',required=True)
    q=sub.add_parser('lookup');q.add_argument('query')
    c=sub.add_parser('check');c.add_argument('operation_id');c.add_argument('--scope',required=True);c.add_argument('--source-dir')
    t=sub.add_parser('self-test');t.add_argument('--source-dir',required=True)
    args=parser.parse_args();catalog=load_catalog(args.catalog)
    if args.cmd=='lookup':result=lookup(catalog,args.query)
    elif args.cmd=='check':result=check(catalog,args.operation_id,json.loads(Path(args.scope).read_text()),args.source_dir)
    else:result=self_test(catalog,args.source_dir)
    print(json.dumps(result,indent=2,ensure_ascii=False))
    if args.cmd=='self-test' and result['passed']!=result['total']:
        raise SystemExit(1)

if __name__=='__main__':main()
