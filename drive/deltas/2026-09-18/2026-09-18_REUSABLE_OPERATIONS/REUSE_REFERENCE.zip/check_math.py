"""Narrow exact checks for this audit; not a theorem prover or field certificate."""
import json
from pathlib import Path
import sympy as s

r,k,l,lam,h,x=s.symbols('r k l lambda h x',positive=True)
half=s.Rational(1,2)
T=s.Matrix([[half,half,0,0,0,0],[-r**-3,r**-3,-1/(2*r**2),0,-1/(2*r**2),0],[0,0,half,0,half,0],[0,0,-1/r,0,1/r,0],[0,0,0,half,0,half],[0,0,0,-1/r,0,1/r]])
tests=[]
def test(name,value):
    tests.append({'test':name,'pass':bool(value)})
test('EC014 exact determinant',s.simplify(T.det()+r**-5)==0)
mut=T.copy();mut[1,:]=mut[1,:]/r
test('extra denominator changes determinant',s.simplify(mut.det()+r**-6)==0)
test('fold power identity',s.simplify(r**3/s.Integer(6)*r**-5*r**2)==s.Rational(1,6))
inv=(6*l/k)**s.Rational(1,3)
test('cubic measure pushforward',s.simplify(inv*s.diff(inv,l)-6**s.Rational(2,3)/(3*k**s.Rational(2,3))*l**-s.Rational(1,3))==0)
test('Holder exponent sum',s.Rational(1,4)*2+s.Rational(1,2)==1)
test('wrong moment exact counterexample',s.Rational(1,4)>s.sqrt(s.Rational(1,4)**4))
z,n,e,t=s.symbols('Z N e t')
test('normalizer correction identity',s.factor((n+e)/(z+t)-n/z-(e-(n/z)*t)/(z+t))==0)
test('odd signed moment is not absolute',(-1)**3+1**3==0 and abs(-1)**3+abs(1)**3==2)
a=s.sqrt(h/(lam+h))
cap=2*s.integrate(((lam+h)*x*x-h)**2,(x,a,1))
target=s.Rational(2,15)*(3*lam**2-4*lam*h+8*h*h-8*h**s.Rational(5,2)/s.sqrt(lam+h))
test('cone cap integration',s.simplify(cap-target)==0)
H=s.Matrix([[0,0,half],[0,-1,0],[half,0,0]])
G=s.Matrix([[s.Rational(8,3),0,s.Rational(2,3)],[0,1,0],[s.Rational(2,3),0,s.Rational(8,3)]])
test('cone planar eigenvalues',(G*H).eigenvals()=={s.Rational(5,3):1,s.Integer(-1):2})
value=half*(3*s.Rational(5,3)**2-4*s.Rational(5,3)+8-8/s.sqrt(s.Rational(8,3)))
test('cone planar constant',s.simplify(value-(s.Rational(29,6)-s.sqrt(6)))==0)
test('square-root cusp slope',s.limit(s.sqrt(s.exp(r*r)-1)/r,r,0,dir='+')==1)
output={'kind':'narrow_symbolic_checks','passed':sum(t['pass'] for t in tests),'total':len(tests),'machine_formal_proof':False,'results':tests}
(Path(__file__).parent/'MATH_CHECKS.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(output,indent=2))
if output['passed']!=output['total']:raise SystemExit(1)
