from pathlib import Path
import hashlib,json
HERE=Path(__file__).resolve().parent
p=HERE/'LS-DATA-013-v1.0_q0_law_specific_verify_v1_2_1.py'
s=p.read_text()
if hashlib.sha256(p.read_bytes()).hexdigest()!='5202c5fa33b1f08d502220943443573cc8c8e3a31682e6f3079443647fe0f6b9':raise RuntimeError('source drift')
needle='def verify(machine: dict[str, Any]) -> dict[str, Any]:\n'
if s.count(needle)!=1:raise RuntimeError('verify target mismatch')
guard=(HERE/'shape_guard.txt').read_text()
preflight='''    malformed = shape_errors(machine)
    if malformed:
        return {"verifier_release": VERIFIER_RELEASE,
                "machine_schema": MACHINE_SCHEMA, "valid": False,
                "errors": malformed, "root_reports": {}}
'''
s=s.replace(needle,guard+needle+preflight)
old_tests='    predecessor_tests = predecessor_negative_tests(machine)\n    cl_tests = cl_adversarial_tests(machine)'
new_tests='''    # Regression generators require a structurally valid baseline. Invalid
    # input must reach the rejection-report writer without entering them.
    predecessor_tests = predecessor_negative_tests(machine) if report["valid"] else []
    cl_tests = cl_adversarial_tests(machine) if report["valid"] else []'''
if s.count(old_tests)!=1:raise RuntimeError('CLI battery target mismatch')
s=s.replace(old_tests,new_tests)
s=s.replace('VERIFIER_RELEASE = "q0-law-specific-verifier/1.2.1"','VERIFIER_RELEASE = "q0-law-specific-verifier/1.2.2-candidate"')
candidate=HERE/'q0_shape_safe_v1_2_2_candidate.py'
candidate.write_text(s)
print(json.dumps(dict(source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),candidate_sha256=hashlib.sha256(candidate.read_bytes()).hexdigest())))
