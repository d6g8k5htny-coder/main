from pathlib import Path
import json,copy,hashlib,subprocess,sys
from replay import load,need,mutations,SOURCE,HERE

candidate=HERE/'q0_shape_safe_v1_2_2_candidate.py'
new=load(candidate,'q_new_candidate');old=load(SOURCE,'q_prior_candidate')
base=old.load(HERE/'machine.json')
tests=new.predecessor_negative_tests(base)+new.cl_adversarial_tests(base)
need(len(tests)==21 and all(t['passed'] for t in tests),'original 21 regression tests')
a=new.verify(base);b=old.verify(base)
a.pop('verifier_release');b.pop('verifier_release')
need(a==b,'valid predecessor semantics changed')
cases=mutations(base)
more=[('claims_not_object',dict(base,claims=None)),('migration_not_object',dict(base,migration_map=[])),
      ('roots_not_list',dict(base,proposed_roots='Q_TYPED_MS_RATE')),('objects_not_object',dict(base,objects=None)),
      ('top_level_not_object',[])]
cases+=more
for name,m in cases:
    r=new.verify(m)
    need(not r['valid'] and r['errors'] and r['root_reports']=={},'shape guard failed '+name)

# Test the actual CLI on a known crash and the prior duplicate-key attack.
cli=[]
for name in ('route_not_object','LS-MUT-013-duplicate-key-machine'):
    report=HERE/(name+'_candidate_rejection.json')
    report.write_text('{"valid":true,"stale_marker":true}\n')
    p=subprocess.run([sys.executable,str(candidate),str(HERE/(name+'.json')),str(report)],capture_output=True,text=True)
    r=json.loads(report.read_text())
    need(p.returncode!=0 and not r['valid'] and r['root_reports']=={} and 'stale_marker' not in r,'CLI must replace stale success report with explicit rejection')
    cli.append(dict(input=name,returncode=p.returncode,errors=r['errors']))

out=dict(status='PASS',original_regressions=21,additional_shape_probes=len(cases),actual_cli_rejections=cli,
         valid_predecessor_report_unchanged_except_release=True,provider_independence=0,
         canonical_installation=False,source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
         candidate_sha256=hashlib.sha256(candidate.read_bytes()).hexdigest(),
         test_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         scope='specified JSON shape failures return explicit invalid reports; no general adversarial-completeness claim')
(HERE/'CANDIDATE_VALIDATION.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
