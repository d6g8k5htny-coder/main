"""Same-provider exact q0 successor replay and malformed-shape probes."""
from pathlib import Path
import importlib.util,copy,hashlib,json,subprocess,sys
HERE=Path(__file__).resolve().parent
SOURCE=HERE/'LS-DATA-013-v1.0_q0_law_specific_verify_v1_2_1.py'

def need(p,s):
    if not p:raise RuntimeError(s)

def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    return mod

def mutations(base):
    target='Q_TYPED_MS_RATE'
    cases=[]
    def add(name,change):
        m=copy.deepcopy(base);change(m);cases.append((name,m))
    add('route_not_object',lambda m:m['claims'][target].update(dependency_routes=['bad']))
    add('claim_not_object',lambda m:m['claims'].update({target:[]}))
    add('unhashable_status',lambda m:m['claims'][target].update(status=[]))
    add('unhashable_root',lambda m:m.update(proposed_roots=[{}]))
    add('base_dependency_not_string',lambda m:m['claims'][target].update(dependency_ids=[{}]))
    add('route_dependency_not_list',lambda m:m['claims'][target].update(dependency_routes=[dict(route_id='BAD',dependencies=3)]))
    add('route_id_not_string',lambda m:m['claims'][target].update(dependency_routes=[dict(route_id=[],dependencies=['MORSE_SMALE_R0'])]))
    add('statement_not_string',lambda m:m['claims'][target].update(statement=[]))
    return cases

def main():
    successor=load(SOURCE,'q_old_successor')
    predecessor=load(HERE/'predecessor.py','q_predecessor')
    base=successor.load(HERE/'machine.json')
    old_report=predecessor.verify(base);report=successor.verify(base)
    need(old_report['root_reports']==report['root_reports'],'predecessor valid-input root mismatch')
    tests=successor.predecessor_negative_tests(base)+successor.cl_adversarial_tests(base)
    need(len(tests)==21 and all(t['passed'] for t in tests),'original 21 tests')
    p=subprocess.run([sys.executable,str(SOURCE),str(HERE/'machine.json'),str(HERE/'REPLAY_GENERATED_REPORT.json')],capture_output=True,text=True)
    (HERE/'REPLAY_STDOUT.txt').write_text(p.stdout);(HERE/'REPLAY_STDERR.txt').write_text(p.stderr)
    need(p.returncode==0,'successor CLI baseline failed')
    actual=json.loads((HERE/'REPLAY_GENERATED_REPORT.json').read_text())
    expected=json.loads((HERE/'LS-DATA-013-v1.0_q0_law_specific_verify_v1_2_1_report.json').read_text())
    for r in (actual,expected):
        r.pop('execution',None);r['predecessor_machine'].pop('path',None)
    need(actual==expected,'semantic report drift')
    attack=HERE/'LS-MUT-013-duplicate-key-machine.json'
    p2=subprocess.run([sys.executable,str(SOURCE),str(attack),str(HERE/'DUPLICATE_REJECTION.json')],capture_output=True,text=True)
    rejected=json.loads((HERE/'DUPLICATE_REJECTION.json').read_text())
    need(p2.returncode!=0 and not rejected['valid'] and rejected['root_reports']=={},'duplicate key CLI must reject')
    shapes=[]
    for name,m in mutations(base):
        try:
            r=successor.verify(m)
            shapes.append(dict(name=name,status='CLEAN_REJECT' if not r['valid'] else 'INCORRECT_ACCEPT',errors=r['errors']))
        except Exception as ex:
            shapes.append(dict(name=name,status='UNHANDLED_EXCEPTION',exception=type(ex).__name__,message=str(ex)))
        (HERE/(name+'.json')).write_text(json.dumps(m,sort_keys=True,indent=2)+'\n')
    out=dict(status='REPLAY_PASS_WITH_NEW_MALFORMED_SHAPE_DEFECT',original_tests=21,root_reports_equal=True,
             semantic_report_equal=True,duplicate_key_rejected=True,shape_probes=shapes,
             independence_credit=0,installation_performed=False,
             source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),replay_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    (HERE/'REPLAY_AUDIT.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()
