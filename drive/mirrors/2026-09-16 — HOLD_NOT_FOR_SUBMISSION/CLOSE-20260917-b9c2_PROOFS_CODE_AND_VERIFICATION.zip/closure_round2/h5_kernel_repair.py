"""Create a new H5 kernel candidate from exact frozen source; never overwrite it."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'intake/h5/source/K3_SIDE24_LB/UPPER2D/H5_closure/h5_kernel.py'
raw=SRC.read_bytes()
if hashlib.sha256(raw).hexdigest()!='b2e6014c2fd6eb9e72b2104cc828a764e280f76b8396a02edd37654b6ad83ad7':
    raise RuntimeError('Frozen H5 source drift')
s=raw.decode()
s=s.replace('tot = sum((wj*(kj**q) for kj, wj in zip(self.ks, self.ws)), iv.mpf(0))',
            'tot = sum((wj*(abs(kj)**q) for kj, wj in zip(self.ks, self.ws)), iv.mpf(0))')
s=s.replace('"""Certified upper bound on sup_s |K1^{(q)}(s)| = (1/Z) sum w k^q."""',
            '"""Upper bound on sup_s |K1^{(q)}(s)| via absolute spectral moments."""')
old='        return val + iv.mpf([-self.tail(n), self.tail(n)])'
new='''        # Infinite denominator Z=Z_J+t_0 is also uncertain. If val=N_J/Z_J,
        # K-val=(e_n-val*t_0)/(Z_J+t_0), so the normalized error is at most
        # tail(n)+|val|*tail(0). Keep the original truncation and add its
        # missing normalization correction with outward interval arithmetic.
        error = self.tail(n) + abs(val).b*self.tail(0)
        return val + iv.mpf([-error.b, error.b])'''
if s.count(old)!=1: raise RuntimeError('Kernel return target mismatch')
s=s.replace(old,new)
dst=ROOT/'closure_round2/h5_repaired/h5_kernel.py'
dst.parent.mkdir(exist_ok=True)
dst.write_text(s)
receipt=dict(source_sha256=hashlib.sha256(raw).hexdigest(),candidate_sha256=hashlib.sha256(dst.read_bytes()).hexdigest(),
             changes=['absolute odd spectral moments','infinite normalizer tail correction'],frozen_source_modified=False)
(dst.parent/'PATCH_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
