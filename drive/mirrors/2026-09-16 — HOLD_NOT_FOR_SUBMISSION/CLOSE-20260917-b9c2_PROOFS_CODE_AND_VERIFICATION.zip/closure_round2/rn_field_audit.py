"""Author-side cross-representation and source-integration audit, not a second provider."""
from pathlib import Path
from flint import arb,arb_mat,ctx
from math import comb
import hashlib,json,sys
import rn_field as F
from rn_field import need,eye,frob

def spectral(n,s):
    h=arb.pi()/12
    ks=[j*h for j in range(117)]
    ws=[(-k*k/2).exp() for k in ks]
    def tail(n):
        ratio=(-235*h*h/2).exp()*(arb(118)/117)**n
        need(ratio<1,'spectral ratio')
        return 2*(-(117*h)**2/2).exp()*(117*h)**n/(1-ratio)
    z=1+2*sum(ws[1:],arb(0))
    z=F.add_radius(z,tail(0))
    if n%2==0:
        v=int(n==0)+2*(-1)**(n//2)*sum((w*k**n*(k*s).cos() for w,k in zip(ws[1:],ks[1:])),arb(0))
    else:
        v=2*(-1)**((n+1)//2)*sum((w*k**n*(k*s).sin() for w,k in zip(ws[1:],ks[1:])),arb(0))
    return F.add_radius(v,tail(n))/z

def product(X,Y):
    return [sum((comb(n,j)*X[j]*Y[n-j] for j in range(n+1)),arb_mat(X[0].nrows(),Y[0].ncols())) for n in range(len(X))]

def inverse(X):
    R=[X[0].inv()]
    for n in range(1,len(X)):
        R.append(-R[0]*sum((comb(n,j)*X[j]*R[n-j] for j in range(1,n+1)),arb_mat(X[0].nrows(),X[0].ncols())))
    return R

def actual_jets(field,x,y,ux,uy):
    mixed=field.cell_mixed(field.x_stencils(x,0),y,0)
    Bs,Fs,zs=[],[],[]
    for n in range(5):
        def block(start,rows):
            return arb_mat([[sum((comb(n,dx)*arb(ux)**dx*arb(uy)**(n-dx)*mixed[i,dx+g[0],n-dx+g[1]] for dx in range(n+1)),arb(0)) for g in F.JETS] for i in range(start,start+rows)])
        Bs.append(block(0,6));Fs.append(block(6,6));zs.append(-block(12,1).transpose())
    zs[0][0,0]+=F.HEIGHT-F.R**3/12
    BB=product([b.transpose() for b in Bs],Bs)
    Ds=[field.YY-BB[0]]+[-d for d in BB[1:]]
    FJ=product(Fs,inverse(Ds))
    return product(FJ,[f.transpose() for f in Fs]),product(FJ,zs)

def point_logQ(A,m):
    need(frob(A)<1,'point domain')
    return -(eye(6)-A*A).det().log()/2+(m.transpose()*(eye(6)+A).inv()*m)[0,0]

checks=0
F.source_contract()
for s in ['0','1/40','-1/20','12/117','5','-7','12','17']:
    images=F.kernel_all(arb(s),18)
    for n in range(19):
        need(images[n].overlaps(spectral(n,arb(s))),f'kernel representations disagree n={n} s={s}')
        checks+=1

field=F.Field()
cert=json.loads((F.OUT/'RN_FIELD_CERTIFICATE.json').read_text())
need(cert['script_sha256']==hashlib.sha256(Path(F.__file__).read_bytes()).hexdigest(),'certificate/script mismatch')
a=[arb(s) for s in cert['uniform_norms']['A']]
m=[arb(s) for s in cert['uniform_norms']['m']]
point_reports=[]
for x,y,ux,uy in [('5','0','1','0'),('24/5','8/5','3/5','4/5'),('-5','0','0','1'),('0','5','1','0'),('12','0','1','0'),('9','12','3/5','4/5')]:
    Aj,mj=actual_jets(field,x,y,ux,uy)
    for n in range(5):
        need(frob(Aj[n])<a[n].upper() and frob(mj[n])<m[n].upper(),'actual point jets outside cover norm bound')
        checks+=2
    L=point_logQ(Aj[0],mj[0])
    # Separate completion-of-the-square formula in the full covariance.
    S=eye(6)-Aj[0];Si=S.inv();H=Si-eye(6)*arb('1/2');c=Si*mj[0]
    other=-3*arb(2).log()-S.det().log()-H.det().log()/2+(c.transpose()*H.inv()*c)[0,0]-(mj[0].transpose()*Si*mj[0])[0,0]
    need(L.overlaps(other),'two Gaussian integral formulas disagree');checks+=1
    point_reports.append(dict(y=[x,y],direction=[ux,uy],logQ=L.str(40)))

# Source integration: numerical diagnostic at the source's two actual paths.
sys.path.insert(0,str(F.ROOT/'output/rn_math'))
import source_point_integration as S
from mpmath import mp
engine,transcript=S.load_engine()
source_checks=[]
ratio_checks=[]
for x,y,ux,uy in [('5','0','1','0'),('4.8','1.6','0.6','0.8')]:
    Aj,mj=actual_jets(field,x,y,ux,uy)
    val=point_logQ(Aj[0],mj[0])
    ref=S.original_logq(engine,(mp.mpf(x),mp.mpf(y)))
    err=abs(mp.mpf(val.mid().str(105,radius=False))-ref)
    need(err<mp.mpf('1e-75'),'source model scalar mismatch')
    source_checks.append(dict(y=[x,y],absolute_error=mp.nstr(err,12)));checks+=1
    def ratios(t):
        fs=engine.station_fast_full((mp.mpf(x)+t*mp.mpf(ux),mp.mpf(y)+t*mp.mpf(uy)))
        rp=fs['pgrad']*(2*mp.pi*engine.E.A2)
        mass=engine.E._Phi((engine.kit.b-fs['mu_t'])/fs['s_t'])-engine.E._Phi((engine.kit.s-fs['mu_t'])/fs['s_t'])
        rw=mass/(engine.E._Phi(engine.kit.b)-engine.E._Phi(engine.kit.s))
        return rp,rw
    for index,name in enumerate(('Rpg','Rwm')):
        refs=[mp.diff(lambda t:ratios(t)[index],mp.mpf(0),n) for n in range(5)]
        bounds=[arb(v) for v in cert['density_ratios'][name+'_raw_directional_derivative_absolute_bounds']]
        for n,ref in enumerate(refs):
            need(abs(ref)<mp.mpf(bounds[n].upper().str(70,radius=False)),'source ratio derivative exceeds certified bound')
            checks+=1
        lower=arb(cert['density_ratios'][name+'_lower'])
        need(refs[0]>mp.mpf(lower.lower().str(70,radius=False)),'source ratio below lower bound');checks+=1
        ratio_checks.append(dict(y=[x,y],ratio=name,raw_derivatives=[mp.nstr(v,20) for v in refs]))

# The exact quarter-grid has no stochastic coverage step.
need(cert['accepted_cells']==sum(F.cell_intersects(i,j,4) for i in range(-68,68) for j in range(-68,68)),'cover cardinality');checks+=1
need(F.kernel_all(0,0)[0].contains(1),'kernel unit variance');checks+=1
for n in range(1,18,2):need(F.kernel_all(0,n)[n].contains(0),'kernel odd parity');checks+=1

out=dict(status='PASS',checks=checks,provider_independence=0,
         methods=['image versus spectral kernel with both infinite tails','actual point matrix jets versus spatial uniform bounds',
                  'two exact Gaussian integral formulas','two archived source model point integrations','exact integer grid count and parity'],
         point_reports=point_reports,source_point_diagnostics=source_checks,
         source_density_ratio_diagnostics=ratio_checks,
         certificate_sha256=hashlib.sha256((F.OUT/'RN_FIELD_CERTIFICATE.json').read_bytes()).hexdigest(),
         audit_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(F.OUT/'RN_FIELD_AUDIT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
