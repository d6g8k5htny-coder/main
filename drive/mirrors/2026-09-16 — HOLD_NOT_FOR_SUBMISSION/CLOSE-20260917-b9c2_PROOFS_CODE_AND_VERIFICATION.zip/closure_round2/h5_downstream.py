"""Replay the archived dominant-box consumer using the additive kernel candidate.
This is a scoped replay, not a certificate of the whole legacy box pipeline.
"""
from pathlib import Path
from mpmath import mp,iv,mpf
import sys,json,hashlib,time,importlib.util
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'output/h5/deps'),str(ROOT/'intake/h5/source/K3_SIDE24_LB/UPPER2D/H2_foundations'),str(ROOT/'closure_round2/h5_repaired')]
import h5_kernel as hk

def loadold():
    spec=importlib.util.spec_from_file_location('h5_old',ROOT/'intake/h5/source/K3_SIDE24_LB/UPPER2D/H5_closure/h5_kernel.py')
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    return m

def need(p,s):
    if not p:raise RuntimeError(s)

def image(n,s):
    def C(n):
        a,b=1,1
        if not n:return a
        for k in range(1,n):a,b=b,b+k*a
        return b
    def tail(n,R):
        rho=((72+R)/(48+R))**n*iv.exp(-((72-R)**2-(48-R)**2)/2)
        need(rho.b<1,'tail ratio')
        return 2*C(n)*(48+R)**n*iv.exp(-(48-R)**2/2)/(1-rho)
    R=iv.mpf('0.2');need(abs(s).b<R.a,'image domain')
    z=1+2*iv.exp(-iv.mpf(288));tz=tail(0,iv.mpf(0))
    z=iv.mpf([z.a,(z+tz).b])
    total=iv.mpf(0)
    for k in (-1,0,1):
        x=s+24*k;h0,h1=iv.mpf(1),x
        if n==0:h=h0
        elif n==1:h=h1
        else:
            for j in range(1,n):h0,h1=h1,x*h1-j*h0
            h=h1
        total+=(-1)**n*h*iv.exp(-x*x/2)
    t=tail(n,R)
    return (total+iv.mpf([-t.b,t.b]))/z

def witness():
    old=loadold()
    mp.dps=iv.dps=340
    old.LAT=old.Lattice();hk.LAT=hk.Lattice()
    # First omitted spectral image j=117 has phase pi, making denominator
    # omission visible independently of the already known odd-moment bug.
    s=iv.mpf(12)/117
    truth=image(0,s);legacy=old.LAT.k1(0,s);fixed=hk.LAT.k1(0,s)
    need(truth.b<legacy.a, 'normalizer witness did not refute legacy enclosure')
    need(fixed.a<=truth.a and truth.b<=fixed.b,'repaired normalizer misses truth')
    norm=dict(s='12/117',truth_minus_old_lower=mp.nstr(mpf(truth.b)-mpf(legacy.a),40),
              correction_upper=mp.nstr(mpf((abs(legacy).b*old.LAT.tail(0)).b),40),refuted=True,repaired_contains=True)
    witnesses=[]
    for precision in (40,100):
        # Match the driver pattern: construct the spectral lattice at the
        # foundations' 100-digit import precision, then set working precision.
        mp.dps=iv.dps=100
        old.LAT=old.Lattice();hk.LAT=hk.Lattice()
        mp.dps=iv.dps=precision
        r=mpf(1)/20
        yc=(-r/2+mpf('0.040')*mp.cos(mpf(165)*mp.pi/180),mpf('0.040')*mp.sin(mpf(165)*mp.pi/180))
        eta=mpf('0.0015')
        old._set_eta(eta,eta,td=6);hk._set_eta(eta,eta,td=6)
        ko=old.KernelSeries(r,yc);kf=hk.KernelSeries(r,yc)
        for n in (0,2,4):
            o=ko.tm_factor(n,'dxM',0);f=kf.tm_factor(n,'dxM',0)
            d=iv.mpf(old.ETA1)
            op=sum((o.c[old._MIDX[j,0]]*d**j for j in range(old.TD+1)),iv.mpf(0))
            fp=sum((f.c[hk._MIDX[j,0]]*d**j for j in range(hk.TD+1)),iv.mpf(0))
            truth=image(n,iv.mpf(ko.args['dxM'])+d)
            ob=op+iv.mpf([-o.R.b,o.R.b]);fb=fp+iv.mpf([-f.R.b,f.R.b])
            need(truth.b<ob.a or truth.a>ob.b,'TD6 witness not disjoint')
            need(fb.a<=truth.a and truth.b<=fb.b,'TD6 repair misses truth')
            witnesses.append(dict(kernel_order=n,taylor_degree=6,working_digits=precision,legacy_remainder=mp.nstr(mpf(o.R.b),35),
                                  repaired_remainder=mp.nstr(mpf(f.R.b),35),endpoint_error=mp.nstr(mpf(abs(truth-op).a),35),
                                  legacy_refuted=True,repaired_contains=True))
    out=dict(status='PASS',normalization_witness=norm,actual_CoarseBox_setup_witnesses=witnesses,
             candidate_sha256=hashlib.sha256(Path(hk.__file__).read_bytes()).hexdigest(),
             parent_H5_certificates_revalidated=False)
    (ROOT/'closure_round2/H5_DOWNSTREAM_WITNESSES.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

def replay():
    start=time.monotonic();mp.dps=iv.dps=40;hk.LAT=hk.Lattice()
    r=mpf('0.05');fr=hk.PinFrame(r)
    yc=(-r/2+mpf('0.040')*mp.cos(mpf(165)*mp.pi/180),mpf('0.040')*mp.sin(mpf(165)*mp.pi/180))
    cb=hk.CoarseBox(fr,yc,mpf('0.0015'),mpf('0.0015'))
    hi=hk.coarse_fine_hi(cb,mpf('4.0387231691e-3'),8)
    need(mpf('1e-6')<mpf(hi)<mpf('1e-4'),'archived dominant-box window no longer satisfied')
    result=dict(status='PASS_ARCHIVED_WINDOW',dominant_box_hi=mp.nstr(mpf(hi),35),
                elapsed_seconds=round(time.monotonic()-start,3),candidate_sha256=hashlib.sha256(Path(hk.__file__).read_bytes()).hexdigest(),
                scope='actual CoarseBox + coarse_fine_hi, archived r=.05 dominant box, K=8',
                caveat='other legacy arithmetic and complete cover not revalidated',parent_H5_certificates_revalidated=False)
    (ROOT/'closure_round2/H5_DOMINANT_BOX_REPLAY.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    if '--replay' in sys.argv:replay()
    else:witness()
