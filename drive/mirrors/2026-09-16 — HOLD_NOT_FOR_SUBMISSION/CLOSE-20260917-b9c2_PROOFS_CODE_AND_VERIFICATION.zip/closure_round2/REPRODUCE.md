# Reproducing CLOSE-20260917-b9c2

Extract the bundle without flattening its directory tree. Use Python 3.12 with python-flint 0.9.0 and mpmath 1.3.0. The H2 dependency uses SymPy; the archived source adapter uses NumPy. Versions are recorded in the verification receipt.

From the extracted root:

```sh
python3 closure_round2/rn_field.py --cover
python3 closure_round2/rn_field_audit.py
python3 -O closure_round2/rn_field_audit.py
python3 closure_round2/h5_kernel_repair.py
python3 closure_round2/h5_downstream.py
python3 closure_round2/h5_downstream.py --replay
python3 closure_round2/q_replay/replay.py
python3 closure_round2/q_replay/build_candidate.py
python3 closure_round2/q_replay/test_candidate.py
python3 -O closure_round2/q_replay/test_candidate.py
```

The scripts write their reports next to the scripts, replacing generated report copies in the extracted bundle. Original source carriers remain in separate input paths. Kernel and field code check the source hashes they consume. H5's inherited `is 0` idiom may produce SyntaxWarnings; those warnings do not change the recorded result.

The field certificate covers the complete fixed-r annulus and conditioning window; it is not a random test. The source-point adapter is explicitly diagnostic. The q candidate is a noncanonical successor and is not installed anywhere by these commands. The bundle does not include private download URLs, authentication material or Python caches.

For a byte-integrity check, compare every payload file to PAYLOAD_MANIFEST.json before running, since reruns update generated logs and elapsed-time fields.
