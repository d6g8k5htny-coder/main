import sys, time
sys.path.insert(0, '/mnt/agents/output/K3_SIDE24_LB/UPPER2D/H5_closure')
import h5_run
from mpmath import mpf, mp, iv, pi
mp.dps = 40
iv.dps = 40
import h5_kernel as hk

r = mpf('0.05')
hk.LAT.self_test()
ctx = h5_run.Ctx(r, 0, 1, 'sring')
ctx.rec = open('/mnt/agents/output/K3_SIDE24_LB/UPPER2D/H5_closure/h5_results_r0.05_sring.jsonl', 'a')
ctx.log = open('/mnt/agents/output/K3_SIDE24_LB/UPPER2D/H5_closure/sring_detail.log', 'a')
ctx.frame = hk.PinFrame(r)
ctx.Z_lo = mpf('4.0387231691e-3')
ctx.Z_hi = mpf('1.3970321600e-2')
asx = r/2
HALF = int(sys.argv[1])
# H5-AXIS v3: ring probes just outside the enlarged S-disk (d_S in
# [0.065, 0.10]), six off-cone directions
SITES = ((30, '0.065'), (60, '0.065'), (90, '0.065'), (120, '0.065'), (150, '0.065'), (90, '0.085'))
for thS, dS in SITES[3*HALF:3*HALF+3]:
    thm = mpf(thS)*pi/180
    yc = (asx + mpf(dS)*mp.cos(pi - thm), mpf(dS)*mp.sin(pi - thm))
    t0 = time.time()
    try:
        cb = ctx.coarse(yc, mpf('0.00025'), mpf('0.00025'))
        hi = mpf(hk.coarse_fine_hi(cb, ctx.Z_lo, 8))
        rho_hi = hi/(4*mpf('0.00025')**2)
        print('sring probe thS=%d dS=%s: rho_hi=%.4e (%.0fs)' % (thS, dS, rho_hi, time.time()-t0), flush=True)
        ctx.jrec(dict(part='sringprobe', thS=thS, dS=dS, rho_hi=str(rho_hi)))
    except SystemExit as e:
        print('sring probe thS=%d dS=%s FAILED: %s' % (thS, dS, str(e)[:60]), flush=True)
print('sring half %d done' % HALF, flush=True)
