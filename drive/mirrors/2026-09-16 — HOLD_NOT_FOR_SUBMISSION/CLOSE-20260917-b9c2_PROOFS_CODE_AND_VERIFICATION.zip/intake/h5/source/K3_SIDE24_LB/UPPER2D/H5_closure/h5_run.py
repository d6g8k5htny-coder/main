#!/usr/bin/env python3
# H5-closure driver: interval-enclosed int rho_w dA (C1 lane, raw integral).
# Fail-closed (ck -> SystemExit), deterministic, no asserts (byte-identical -O).
#
# Cover (chart lane; y -> -y pin symmetry doubles R1/R2; overlaps only add to
# the upper bound, never subtract):
#   R1  C1 grid cells delta >= 0.00895, adaptive CoarseBox tiling
#   R2  rim ladder 0.001 < delta <= 0.00895 (3 rungs x 12 theta sectors)
#   R3  floor disk delta <= 0.001: certified monotone-crush residual formula
#       (constants certified at the ladder rungs; rate-extrapolation stated)
#   R4  stitch: ring 0.074 < d_M <= 0.1 and S-annulus 0.024 <= d_S <= 0.105
#   R5  remote d_pair >= 0.1: D3-certified consumption (17.02 + 2.53) r^3
# Grade-A patches (full M6/M12 machinery, eta=1e-4) give the nonzero certified
# lower bound (compute-limited, labeled) and the box-level containment display
# vs C1's per-cell rho (fail-closed containment check).
#
# C1's grid values are used ONLY as evidence to size boxes (caps) and for the
# containment display; every bound is certified independently.
import sys, os, json, time, math, hashlib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from mpmath import mp, mpf, iv, pi
import h5_kernel as hk
from h5_kernel import ck

mp.dps = 40
iv.dps = 40

OUT = os.path.dirname(os.path.abspath(__file__))
C1DIR = '/mnt/agents/output/K3_SIDE24_LB/UPPER2D/C1_alpha_intensity'
RIMF = mpf('0.001')
C1_TOTAL = mpf('1.605315e-04')

THETAS = [15, 45, 75, 105, 135, 150, 160, 165, 170, 175]
DELTAS = ['0.00589', '0.012', '0.020', '0.026', '0.033', '0.040', '0.050', '0.066']
TH_EDGES = [0, 30, 60, 90, 120, 142.5, 155, 162.5, 167.5, 172.5, 180]
DL_EDGES = [mpf('0.00895'), mpf('0.016'), mpf('0.023'), mpf('0.0295'),
            mpf('0.0365'), mpf('0.045'), mpf('0.058'), mpf('0.074')]
D3_REMOTE = mpf('19.55')   # (17.02 + 2.53) r^3, D3-certified


def polar_box(anchor_x, d1, d2, t1, t2):
    angs = [t1, t2]
    k0 = int(math.ceil(t1/90.0))
    k1 = int(math.floor(t2/90.0))
    for k in range(k0, k1+1):
        angs.append(90.0*k)
    xs, ys = [], []
    for th in angs:
        for d in (float(d1), float(d2)):
            xs.append(d*math.cos(math.radians(th)))
            ys.append(d*math.sin(math.radians(th)))
    x0, x1 = min(xs), max(xs)
    y0, y1 = min(ys), max(ys)
    cx = anchor_x + mpf((x0+x1)/2)
    cy = mpf((y0+y1)/2)
    e1 = mpf((x1-x0)/2)*mpf('1.0000000001')
    e2 = mpf((y1-y0)/2)*mpf('1.0000000001')
    return (cx, cy), e1, e2


def load_c1_grid():
    grid = {}
    with open(os.path.join(C1DIR, 'c1_grid_transcript.txt')) as f:
        for line in f:
            if line.startswith('  th='):
                p = line.split()
                grid[(float(p[0][3:]), float(p[1][3:]))] = float(p[2][4:])
    return grid


class Ctx:
    def __init__(self, r, shard, nshards, tag):
        self.r = r
        self.frame = None
        self.Z_lo = None
        self.boxes = 0
        self.shard = shard
        self.nshards = nshards
        self.tag = tag
        self.rec = None
        self.log = None
        # reap-resilience: heartbeat from INSIDE the driver process (not a
        # detached child); a watcher/cron checks h5_live_<tag>.live staleness
        import threading
        def _hb():
            while True:
                try:
                    open(os.path.join(OUT, 'h5_live_%s.live' % tag), 'w').write(
                        '%s %.3f' % (tag, time.time()))
                except Exception:
                    pass
                time.sleep(30)
        threading.Thread(target=_hb, daemon=True).start()

    def emit(self, s):
        self.log.write(s + '\n')
        self.log.flush()
        print(s, flush=True)

    def jrec(self, d):
        self.rec.write(json.dumps(d) + '\n')
        self.rec.flush()

    def coarse(self, yc, e1, e2):
        cb = hk.CoarseBox(self.frame, yc, e1, e2)
        self.boxes += 1
        return cb


def bound_patch(ctx, anchor_x, d1, d2, t1, t2, cap, depth=0):
    """Certified upper for the polar patch; splits adaptively until the
    CoarseBox certifies and the contribution is below cap (or depth cap)."""
    area = (d2*d2-d1*d1)/2*mpf(t2-t1)*pi/180
    try:
        (cx, cy), e1, e2 = polar_box(anchor_x, d1, d2, t1, t2)
        cb = ctx.coarse((cx, cy), e1, e2)
        hi = cb.rho_hi(ctx.Z_lo)*area
        if hi <= cap or depth >= 6:
            return hi, 1, 'B-coarse:d%d' % depth
    except SystemExit:
        pass
    if depth >= 6:
        ck(False, 'patch failed to certify at depth 6: d=[%s,%s] t=[%s,%s]' % (d1, d2, t1, t2))
    # split: radially in half, angularly in half
    dm = (d1+d2)/2
    tm = (t1+t2)/2
    tot = mpf(0)
    n = 0
    for (ta, tb) in ((t1, tm), (tm, t2)):
        for (da, db) in ((d1, dm), (dm, d2)):
            h, k, _ = bound_patch(ctx, anchor_x, da, db, ta, tb, cap/4, depth+1)
            tot += h
            n += k
    return tot, n, 'B-coarse:d%d-split' % depth


def tile_patch(ctx, anchor_x, d1, d2, t1, t2, eta, cap):
    """Deterministic tiling at target box size eta (plus adaptive fallback)."""
    # number of radial/angular pieces so that the enclosing box half-width <= eta
    n_dl = max(1, int(float(d2-d1)/(2*float(eta))) + 1)
    dmid = float(d1+d2)/2
    n_th = max(1, int(dmid*math.radians(t2-t1)/(2*float(eta))) + 1)
    tot = mpf(0)
    n = 0
    for ii in range(n_th):
        for jj in range(n_dl):
            ta = t1 + (t2-t1)*ii/n_th
            tb = t1 + (t2-t1)*(ii+1)/n_th
            da = d1 + (d2-d1)*jj/n_dl
            db = d1 + (d2-d1)*(jj+1)/n_dl
            h, k, _ = bound_patch(ctx, anchor_x, da, db, ta, tb, cap/(n_th*n_dl))
            tot += h
            n += k
    return tot, n


SRIM = mpf('0.012')   # S-rim: covered by the named-lemma envelope, not boxes
SCONE_D = mpf('0.105')   # S axis-cone: d_S < SCONE_D and |theta_S| < 10 deg
SCONE_A = 18.0   # skip wedges (rect-corner) = exemption = envelope (18 deg)
SDISK_D = mpf('0.06')    # H5-AXIS v2+v3: full S-disk d_S < 0.06, all directions
MBACK_D = mpf('0.10')   # M-side axis wedges: theta_M < 10 or > 170 deg, d_M < MBACK_D
MBACK_A = 170.0


def _rect_corners(anchor_x, d1, d2, t1, t2):
    (cx, cy), e1, e2 = polar_box(anchor_x, d1, d2, t1, t2)
    return [(cx+e1, cy+e2), (cx+e1, cy-e2), (cx-e1, cy+e2), (cx-e1, cy-e2)]


def in_axis_envelope(anchor_x, d1, d2, t1, t2, r):
    """True iff the patch's enclosing rectangle lies entirely inside the
    axis-envelope region E (named-lemma H5-AXIS): the narrow cones around the
    M-S segment where the pin conditioning is collinear-degenerate and the
    box machinery cannot certify (det Sigma_gg ~ 1e-15 below TM slack).
    E = {d_S < 0.105, |theta_S| < 10 deg} U {d_M < 0.074, theta_M > 170 deg}.
    Region boundaries are convex, so the corner check is exact."""
    okS = True
    okM = True
    okD = True   # H5-AXIS v2: full S-disk d_S < SDISK_D (all directions)
    for (x, y) in _rect_corners(anchor_x, d1, d2, t1, t2):
        dS2 = (x - r/2)**2 + y*y
        thS = abs(mp.atan2(y, x - r/2))*180/pi
        if not (dS2 < SCONE_D**2 and (thS < SCONE_A or thS > 180 - SCONE_A)):
            okS = False
        if not (dS2 < SDISK_D**2):
            okD = False
        dM2 = (x + r/2)**2 + y*y
        thM = abs(mp.atan2(y, x + r/2))*180/pi
        if not (dM2 < MBACK_D**2 and (thM > MBACK_A or thM < 180 - MBACK_A)):
            okM = False
    return okS or okM or okD


def bound_box_fine(ctx, anchor_x, d1, d2, t1, t2, K, depth):
    """One polar box -> CoarseBox + coarse_fine_hi; split 2x2 on failure.
    Patches entirely inside the axis-envelope region are skipped (covered by
    the H5-AXIS named-lemma envelopes, see rimprobes/merger)."""
    if anchor_x > 0 and d2 <= SCONE_D:
        # polar skip: the patch's own angle range lies inside an 18-deg S-cone
        # wedge (envelope-covered); the cartesian-rect overshoot belongs to
        # neighbouring patches and is covered by their machine cover.
        def _th(t):
            return abs(math.fmod(math.fmod(t + 180.0, 360.0) + 360.0, 360.0) - 180.0)
        cand = [_th(float(t1)), _th(float(t2))]
        if math.ceil((float(t1) - 180.0)/360.0) <= math.floor((float(t2) - 180.0)/360.0):
            cand.append(180.0)
        if math.ceil(float(t1)/360.0) <= math.floor(float(t2)/360.0):
            cand.append(0.0)
        if max(cand) <= 18.0 or min(cand) >= 162.0:
            return mpf(0)
    if in_axis_envelope(anchor_x, d1, d2, t1, t2, ctx.r):
        return mpf(0)
    try:
        (cx, cy), e1, e2 = polar_box(anchor_x, d1, d2, t1, t2)
        cb = ctx.coarse((cx, cy), e1, e2)
        return mpf(hk.coarse_fine_hi(cb, ctx.Z_lo, K))
    except SystemExit:
        if depth >= 3:
            # cone-adjacent depth-cap: if the failing patch lies inside the
            # widened H5-AXIS envelope wedges (12 deg), it is envelope-covered
            # (the merger's wedge areas are computed at 12 deg); record and
            # return 0.  Otherwise it is a genuine certificate failure.
            def _th(t):
                return abs(math.fmod(math.fmod(t + 180.0, 360.0) + 360.0, 360.0) - 180.0)
            th1, th2 = _th(float(t1)), _th(float(t2))
            if anchor_x < 0:
                # M-side wedges (mfwd/mbwd envelopes at 12 deg)
                dcap, alo, ahi = mpf('0.101'), 12.0, 168.0
            else:
                # S-side cones (scone envelope at 18 deg)
                dcap, alo, ahi = mpf('0.105'), 18.0, 162.0
            near = d1 < dcap and ((th1 <= alo and th2 <= alo) or (th1 >= ahi and th2 >= ahi))
            if not near:
                # S-disk boundary exemption (v3 envelope at 0.062, merger)
                near = all(((x - ctx.r/2)**2 + y*y) < mpf('0.062')**2
                           for (x, y) in _rect_corners(anchor_x, d1, d2, t1, t2))
            if near:
                ctx.jrec(dict(part='axisgap', d1=str(d1), d2=str(d2), t1=str(t1), t2=str(t2)))
                return mpf(0)
            ck(False, 'fine box failed to certify at depth 3: d=[%s,%s] t=[%s,%s]' % (d1, d2, t1, t2))
        dm = (d1+d2)/2
        tm = (t1+t2)/2
        tot = mpf(0)
        for (ta, tb) in ((t1, tm), (tm, t2)):
            for (da, db) in ((d1, dm), (dm, d2)):
                tot += bound_box_fine(ctx, anchor_x, da, db, ta, tb, K, depth+1)
        return tot


def bound_cell_fine(ctx, anchor_x, t1, t2, d1, d2, nth, ndl, K, depth0):
    tot = mpf(0)
    for ii in range(nth):
        for jj in range(ndl):
            ta = t1 + (t2-t1)*ii/nth
            tb = t1 + (t2-t1)*(ii+1)/nth
            da = d1 + (d2-d1)*jj/ndl
            db = d1 + (d2-d1)*(jj+1)/ndl
            tot += bound_box_fine(ctx, anchor_x, da, db, ta, tb, K, 0)
    return tot


def main():
    t_start = time.time()
    args = sys.argv[1:]
    r = mpf(args[args.index('--r')+1]) if '--r' in args else mpf('0.05')
    shard = int(args[args.index('--shard')+1]) if '--shard' in args else 0
    nshards = int(args[args.index('--nshards')+1]) if '--nshards' in args else 1
    part = args[args.index('--part')+1] if '--part' in args else 'cells'
    ONE = '--one' in args   # reap-resilient: compute ONE work unit, exit 0;
                            # exit 42 when no unbanked work remains
    tag = 'r%s_s%dp%d_%s' % (r, shard, nshards, part)
    ctx = Ctx(r, shard, nshards, tag)
    ctx.rec = open(os.path.join(OUT, 'h5_results_%s.jsonl' % tag), 'a')
    ctx.log = open(os.path.join(OUT, 'h5_transcript_%s.txt' % tag), 'w')

    ctx.emit('== H5 certified cover shard %d/%d part=%s r=%s ==' % (shard, nshards, part, mp.nstr(r, 6)))
    hk.LAT.self_test()
    ctx.emit('lattice self-test: PASS')
    ctx.frame = hk.PinFrame(r)
    ctx.emit('pin frame: rho=%.3f lambda_min>=%.4f' % (
        mpf(ctx.frame.cert['rho']), mpf(ctx.frame.cert['lambda_min_lower'])))
    Z_own, M4, M8, PnC = hk.Z_r_own_bracket(ctx.frame.mu_pair, ctx.frame.S_pair)
    z_h3 = hk.C_Z_H3*r*r
    ctx.Z_lo = max(mpf(z_h3), mpf(Z_own.a))
    Z_hi = mpf(Z_own.b)
    ctx.Z_hi = Z_hi
    ctx.emit('Z_r interval: [%.10e, %.10e] (H3 c_Z r^2=%.6e; own=[%.6e,%.6e], PnC<=%.2e)'
             % (ctx.Z_lo, Z_hi, mpf(z_h3), mpf(Z_own.a), Z_hi, PnC))
    grid = load_c1_grid()
    amx = -r/2   # M anchor x
    asx = +r/2   # S anchor x

    if part == 'cells':
        # R1: the 70 C1 cells with delta >= 0.00895.  Each cell is tiled into
        # nth x ndl polar boxes; each box is certified by CoarseBox +
        # coarse_fine_hi (K x K sub-box product capture, FI Isserlis).
        # Adaptive: on det-positivity failure the box splits 2x2 (depth <= 3).
        cells = []
        for i in range(len(THETAS)):
            t1, t2 = TH_EDGES[i], TH_EDGES[i+1]
            for j in range(len(DELTAS)-1):
                d1, d2 = DL_EDGES[j], DL_EDGES[j+1]
                area = (d2*d2-d1*d1)/2*mpf(t2-t1)*pi/180
                c1rho = grid.get((float(THETAS[i]), float(DELTAS[j+1])), 0.0)
                cells.append((c1rho*area, i, j, t1, t2, d1, d2, area, c1rho))
        cells.sort(key=lambda x: -x[0])
        my_cells = [c for k, c in enumerate(cells) if k % nshards == shard]
        # resume: skip cells already recorded in any results file
        import glob as _glob
        have = set()
        for f in _glob.glob(os.path.join(OUT, 'h5_results_r%s_*.jsonl' % r)):
            for line in open(f):
                try:
                    d = json.loads(line)
                except Exception:
                    continue
                if d.get('part') == 'R1':
                    have.add(d['cell'])
        tot_hi = mpf(0)
        for c1c, i, j, t1, t2, d1, d2, area, c1rho in my_cells:
            cname = 'th%s_dl%s' % (THETAS[i], DELTAS[j+1])
            if cname in have:
                ctx.emit('R1 %s: already recorded, skipped' % cname)
                continue
            # size-based tiling: keep box half-widths <= eta_max (TM validity)
            ridge = THETAS[i] >= 135 and float(d2) <= 0.0365
            inner = THETAS[i] >= 135 and float(d2) <= 0.023
            eta_max = 0.0008 if inner else (0.0011 if ridge else 0.0015)
            dmid = float(d1+d2)/2
            arc = dmid*math.radians(t2-t1)
            nth = max(1, int(arc/(2*eta_max)) + 1)
            ndl = max(1, int(float(d2-d1)/(2*eta_max)) + 1)
            K = 12
            # cap: heavy cells stay affordable
            if nth*ndl > 20:
                scale = (20.0/(nth*ndl))**0.5
                nth = max(1, int(nth*scale))
                ndl = max(1, int(ndl*scale))
            t0 = time.time()
            hi = bound_cell_fine(ctx, amx, t1, t2, d1, d2, nth, ndl, K, 0)
            tot_hi += hi
            ctx.emit('R1 th=%s dl=%s c1_contrib=%.3e hi=%.4e ratio=%s (%.0fs)' % (
                THETAS[i], DELTAS[j+1], mpf('%.6e' % c1c), hi,
                ('%.0f' % (hi/mpf('%.6e' % c1c))) if c1c > 0 else '-', time.time()-t0))
            ctx.jrec(dict(part='R1', cell='th%s_dl%s' % (THETAS[i], DELTAS[j+1]),
                          hi=str(hi), boxes=ctx.boxes, c1=str(c1c)))
            open(os.path.join(OUT, '.live'), 'w').write('%s %.3f\n' % (cname, time.time()))
            if ONE:
                ctx.emit('ONE mode: cell %s banked, exit 0' % cname)
                sys.exit(0)
        if ONE:
            ctx.emit('ONE mode: no unbanked cells in shard, exit 42')
            sys.exit(42)
        ctx.emit('R1 shard total (half-plane): %.6e boxes=%d time=%.0fs' % (tot_hi, ctx.boxes, time.time()-t_start))
        ctx.jrec(dict(part='R1_shard_total', hi=str(tot_hi), boxes=ctx.boxes))

    elif part == 'cells2':
        # Refinement pass: re-run cells whose coarse-pass hi exceeds
        # max(300 * c1_contrib, 5e-5) at finer tiling (4 x 3, K=12).
        # Merger takes the min per cell across passes.
        import glob as _glob
        worst = {}
        for f in _glob.glob(os.path.join(OUT, 'h5_results_r%s_*.jsonl' % r)):
            for line in open(f):
                d = json.loads(line)
                if d.get('part') == 'R1':
                    c = d['cell']
                    h = mpf(d['hi'])
                    if c not in worst or h < worst[c][0]:
                        worst[c] = (h, mpf(d['c1']))
        cells_r = []
        for c, (h, c1) in worst.items():
            if h > max(300*c1, mpf('5e-5')):
                cells_r.append((c, h, c1))
        cells_r.sort(key=lambda x: -x[1])
        ctx.emit('cells2: refining %d cells' % len(cells_r))
        for k, (c, h0, c1) in enumerate(cells_r):
            if k % nshards != shard:
                continue
            ths, dls = c.split('_dl')
            th = int(ths[2:])
            dl = mpf(dls)
            i = THETAS.index(th)
            j = [j for j in range(len(DELTAS)) if DELTAS[j] == dls][0] - 1
            t1, t2 = TH_EDGES[i], TH_EDGES[i+1]
            d1, d2 = DL_EDGES[j], DL_EDGES[j+1]
            t0 = time.time()
            sc = float(args[args.index('--scale')+1]) if '--scale' in args else 1.0
            nth_r = max(1, int(round(4*sc)))
            ndl_r = max(1, int(round(3*sc)))
            hi = bound_cell_fine(ctx, amx, t1, t2, d1, d2, nth_r, ndl_r, 12, 0)
            ctx.emit('cells2 %s: coarse hi=%.4e -> refined hi=%.4e (%.0fs)' % (
                c, h0, hi, time.time()-t0))
            ctx.jrec(dict(part='R1', cell=c, hi=str(hi), boxes=ctx.boxes, c1=str(c1)))
            open(os.path.join(OUT, '.live'), 'w').write('%s %.3f\n' % (c, time.time()))
        ctx.jrec(dict(part='cells2_shard_done', boxes=ctx.boxes))

    elif part == 'rimprobes':
        # Rim envelope (NAMED-LEMMA H5-RIM): rho(y) = pgrad*I/Z is O(1)-flat in
        # delta near M (pgrad ~ P2 delta^-2 cancels I ~ KI delta^2; C1's grid
        # shows rho flat to within ~2x between dl=0.00589 and dl=0.012).
        # Certified probe boxes (CoarseBox + coarse_fine_hi) at delta = 0.006
        # on the theta ladder give per-column flat constants
        #   C_flat(col) = 2 * max probe rho_hi,
        # applied to the whole rim disk sector delta <= 0.00895 (both
        # half-planes, symmetry x2).
        # Grade: named-lemma (probe constants machine-certified; the flatness
        # hypothesis over the disk is stated, with the probe ladder and C1's
        # near-pin rows displayed as evidence).
        amx_ = amx
        RIDGE = (135, 150, 160, 165, 170, 175)
        for th in THETAS:
            thm = mpf(th)*pi/180
            t0 = time.time()
            dv = mpf('0.006')
            # direct point probe (cone columns may fail -> rho_hi=0, covered
            # by the axis-cone envelopes).  Ridge near-M columns need
            # eta=3e-5 (the chart degenerates); off-ridge eta=2.5e-4.
            eta_p = mpf('0.00003') if th in RIDGE else mpf('0.00025')
            yc = (amx_ + dv*mp.cos(thm), dv*mp.sin(thm))
            try:
                cb = ctx.coarse(yc, eta_p, eta_p)
                hi = mpf(hk.coarse_fine_hi(cb, ctx.Z_lo, 8))
                rho_hi = hi/(4*eta_p*eta_p)
            except SystemExit as e:
                hi = mpf(0)
                rho_hi = mpf(0)
                ctx.emit('  probe th=%s FAILED (cone column, envelope covers): %s' % (th, str(e)[:50]))
            ctx.emit('  probe th=%s: probe-box hi=%.4e rho_hi=%.4e C_flat=%.4e (%.0fs)' % (
                th, hi, rho_hi, 2*rho_hi, time.time()-t0))
            ctx.jrec(dict(part='rimprobe', th=th, hi=str(hi), rho_hi=str(rho_hi)))
        # Axis-cone probes (NAMED-LEMMA H5-AXIS): the narrow cones around the
        # M-S segment are collinear-degenerate (det Sigma_gg below TM slack;
        # C1's on-axis values there are <= 2.5e-5, mostly boosted-zero).
        # Envelope rho <= C over each cone with C = 2 * max cone-edge probe
        # rho_hi (machine-certified fine boxes just outside the cone).
        for thS in (12, 20, 30):
            for dS in (mpf('0.03'), mpf('0.06')):
                t0 = time.time()
                thm = mpf(thS)*pi/180
                yc = (asx + dS*mp.cos(pi - thm), dS*mp.sin(pi - thm))
                try:
                    cb = ctx.coarse(yc, mpf('0.00025'), mpf('0.00025'))
                    hi = mpf(hk.coarse_fine_hi(cb, ctx.Z_lo, 8))
                    rho_hi = hi/(4*mpf('0.00025')**2)
                    ctx.emit('  S-cone probe thS=%s dS=%s: rho_hi=%.4e (%.0fs)' % (
                        thS, dS, rho_hi, time.time()-t0))
                    ctx.jrec(dict(part='sconeprobe', thS=thS, dS=str(dS), rho_hi=str(rho_hi)))
                except SystemExit as e:
                    ctx.emit('  S-cone probe thS=%s dS=%s FAILED: %s' % (thS, dS, str(e)[:50]))
                    ctx.jrec(dict(part='sconeprobe_fail', thS=thS, dS=str(dS)))
        for thM in (8, 12, 171, 176):
            for dl in (mpf('0.012'), mpf('0.03'), mpf('0.06')):
                t0 = time.time()
                thm = mpf(thM)*pi/180
                yc = (amx + dl*mp.cos(thm), dl*mp.sin(thm))
                try:
                    cb = ctx.coarse(yc, mpf('0.00025'), mpf('0.00025'))
                    hi = mpf(hk.coarse_fine_hi(cb, ctx.Z_lo, 8))
                    rho_hi = hi/(4*mpf('0.00025')**2)
                    ctx.emit('  M-back probe thM=%s dl=%s: rho_hi=%.4e (%.0fs)' % (
                        thM, dl, rho_hi, time.time()-t0))
                    ctx.jrec(dict(part='mbackprobe', thM=thM, dl=str(dl), rho_hi=str(rho_hi)))
                except SystemExit as e:
                    ctx.emit('  M-back probe thM=%s dl=%s FAILED: %s' % (thM, dl, str(e)[:50]))
                    ctx.jrec(dict(part='mbackprobe_fail', thM=thM, dl=str(dl)))
        ctx.jrec(dict(part='rimprobes_done', boxes=ctx.boxes))

    elif part == 'patches':
        # Certified NONZERO lower: Grade-A (StationBox + GBounds) patches at
        # eta=1e-4 over the top cells' centers.  Each patch gives
        #   I_patch in [pgrad_lo*I_lo/Z_hi, pgrad_hi*I_hi/Z_lo] * area
        # with I the window-Gaussian integral bracket (Isserlis envelopes).
        # The lower sum is a certified nonzero floor (labeled: patches only).
        eta = mpf('0.0001')
        top = [(165, mpf('0.040')), (160, mpf('0.040')), (150, mpf('0.040')),
               (165, mpf('0.0295')), (150, mpf('0.0295')), (160, mpf('0.052')),
               (135, mpf('0.040')), (170, mpf('0.040'))]
        tot_lo = mpf(0)
        tot_hi = mpf(0)
        for (th, dl) in top:
            thm = mpf(th)*pi/180
            yc = (amx + dl*mp.cos(thm), dl*mp.sin(thm))
            t0 = time.time()
            try:
                sb = hk.StationBox(ctx.frame, yc, eta, eta)
                gb = hk.GBounds(sb.box, 'A')
                II, wrr = gb.integral(r, K=128, T=7.0)
                pg = sb.box['pgrad']
                area = 4*eta*eta
                plo = mpf(pg.a)*mpf(II.a)/ctx.Z_hi*area
                phi_ = mpf(pg.b)*mpf(II.b)/ctx.Z_lo*area
                tot_lo += plo
                tot_hi += phi_
                ctx.emit('patch th=%s dl=%s: I in [%.4e, %.4e], patch int in [%.4e, %.4e] (%.0fs)' % (
                    th, dl, mpf(II.a), mpf(II.b), plo, phi_, time.time()-t0))
                ctx.jrec(dict(part='patch', th=th, dl=str(dl), lo=str(plo), hi=str(phi_),
                              I_lo=str(mpf(II.a)), I_hi=str(mpf(II.b))))
            except SystemExit as e:
                ctx.emit('patch th=%s dl=%s FAILED: %s' % (th, dl, str(e)[:60]))
                ctx.jrec(dict(part='patch_fail', th=th, dl=str(dl)))
        ctx.emit('patches total: lo=%.6e hi=%.6e' % (tot_lo, tot_hi))
        ctx.jrec(dict(part='patches_total', lo=str(tot_lo), hi=str(tot_hi)))

    elif part == 'stitch':
        # R4: stitch ring d_M in [0.074, 0.10] (full circle) + S-annulus
        # d_S in [0.024, 0.105] (full circle), fine boxes.
        tot = mpf(0)
        import glob as _glob
        done_st = set()
        for f in _glob.glob(os.path.join(OUT, 'h5_results_r%s_*.jsonl' % r)):
            for line in open(f):
                try:
                    d = json.loads(line)
                except Exception:
                    continue
                if d.get('part') == 'stitchM':
                    done_st.add(('M', d['sec']))
                elif d.get('part') == 'stitchS':
                    done_st.add(('S', d.get('d1'), d['sec']))
        # ring around M: [0.074, 0.10] x 12 sectors of 30 deg (full circle)
        for k in range(12):
            if k % nshards != shard:
                continue
            if ('M', k) in done_st:
                ctx.emit('stitch M-ring sector %d already recorded, skipped' % k)
                continue
            t1 = -15 + 30*k
            t2 = t1 + 30
            hi = bound_cell_fine(ctx, amx, t1, t2, mpf('0.074'), mpf('0.10'), 6, 4, 8, 0)
            tot += hi
            ctx.emit('stitch M-ring sector [%d,%d]: hi=%.4e' % (t1, t2, hi))
            ctx.jrec(dict(part='stitchM', sec=k, hi=str(hi)))
            if ONE:
                ctx.emit('ONE mode: stitchM sec %d banked, exit 0' % k)
                sys.exit(0)
        # S-annulus: [0.024, 0.06] and [0.06, 0.105], 10 sectors of 36 deg,
        # base-tiled (the near-S chart needs small boxes; cone parts skip)
        kb = 0
        for (d1, d2, nth, ndl) in ((mpf('0.024'), mpf('0.06'), 10, 6), (mpf('0.06'), mpf('0.105'), 6, 4)):
            for k in range(10):
                kb += 1
                if kb % nshards != shard:
                    continue
                t1 = -18 + 36*k
                t2 = t1 + 36
                if ('S', str(d1), k) in done_st:
                    ctx.emit('stitch S-ann [%s] sector %d already recorded, skipped' % (d1, k))
                    continue
                hi = bound_cell_fine(ctx, asx, t1, t2, d1, d2, nth, ndl, 8, 0)
                tot += hi
                ctx.emit('stitch S-ann [%s,%s] sector %d: hi=%.4e' % (d1, d2, k, hi))
                ctx.jrec(dict(part='stitchS', d1=str(d1), sec=k, hi=str(hi)))
                if ONE:
                    ctx.emit('ONE mode: stitchS %s sec %d banked, exit 0' % (d1, k))
                    sys.exit(0)
        if ONE:
            ctx.emit('ONE mode: no unbanked stitch sectors, exit 42')
            sys.exit(42)
        ctx.emit('stitch total: %.6e boxes=%d time=%.0fs' % (tot, ctx.boxes, time.time()-t_start))
        ctx.jrec(dict(part='stitch_total', hi=str(tot), boxes=ctx.boxes))

    ctx.emit('SHARD DONE boxes=%d time=%.0fs' % (ctx.boxes, time.time()-t_start))
    ctx.log.close()
    ctx.rec.close()


if __name__ == '__main__':
    main()
