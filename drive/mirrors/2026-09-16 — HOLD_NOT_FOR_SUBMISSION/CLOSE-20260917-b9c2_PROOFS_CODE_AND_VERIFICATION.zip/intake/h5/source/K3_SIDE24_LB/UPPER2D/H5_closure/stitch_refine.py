import sys, time
sys.path.insert(0, '/mnt/agents/output/K3_SIDE24_LB/UPPER2D/H5_closure')
import h5_run
from mpmath import mpf, mp, iv, pi
mp.dps = 40
iv.dps = 40
import h5_kernel as hk

r = mpf('0.05')
hk.LAT.self_test()
ctx = h5_run.Ctx(r, 0, 1, 'stitchref')
ctx.rec = open('/mnt/agents/output/K3_SIDE24_LB/UPPER2D/H5_closure/h5_results_r0.05_stitchref.jsonl', 'a')
ctx.log = open('/mnt/agents/output/K3_SIDE24_LB/UPPER2D/H5_closure/stitchref_detail.log', 'a')
ctx.frame = hk.PinFrame(r)
ctx.Z_lo = mpf('4.0387231691e-3')
ctx.Z_hi = mpf('1.3970321600e-2')
amx = -r/2
asx = r/2

# M-ring garbage sectors (v1 coarse pass): finer tiling, min-per-sector applies
for k in (6, 11, 3, 9, 5, 7):
    t1 = -15 + 30*k
    t2 = t1 + 30
    t0 = time.time()
    hi = h5_run.bound_cell_fine(ctx, amx, t1, t2, mpf('0.074'), mpf('0.10'), 8, 5, 8, 0)
    print('stitch M-ring sector [%d,%d]: hi=%.4e (%.0fs)' % (t1, t2, hi, time.time()-t0), flush=True)
    ctx.jrec(dict(part='stitchM', sec=k, hi=str(hi)))

# full S-annulus (finer than v1): [0.024,0.06] 10x6, [0.06,0.105] 6x4
for (d1, d2, nth, ndl) in ((mpf('0.024'), mpf('0.06'), 10, 6), (mpf('0.06'), mpf('0.105'), 6, 4)):
    for k in range(10):
        t1 = -18 + 36*k
        t2 = t1 + 36
        t0 = time.time()
        hi = h5_run.bound_cell_fine(ctx, asx, t1, t2, d1, d2, nth, ndl, 8, 0)
        print('stitch S-ann [%s,%s] sector %d: hi=%.4e (%.0fs)' % (d1, d2, k, hi, time.time()-t0), flush=True)
        ctx.jrec(dict(part='stitchS', d1=str(d1), sec=k, hi=str(hi)))
print('stitch refine done', flush=True)
