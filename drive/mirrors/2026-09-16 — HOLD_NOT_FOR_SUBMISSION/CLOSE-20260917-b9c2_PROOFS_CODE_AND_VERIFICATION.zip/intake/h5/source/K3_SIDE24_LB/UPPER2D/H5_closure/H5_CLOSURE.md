# H5 CLOSURE — certified interval for the C1-lane raw integral ∫ρ_w dA

Campaign: U2D-UPPER (2D upper theorem), H5 closure lane.
Artifact set: `h5_kernel.py` (TM machinery), `h5_run.py` (driver),
`h5_merge.py` (totals assembly), `falsify.py` (executable falsifier),
`H5_RECEIPTS.txt`, `CODE_HASHES.txt`, `h5_results_*.jsonl` (machine receipts),
`h5_transcript_*.txt` (human logs), `h5_totals.json` (final numbers).

## 0. Headline (r = 0.05) — CERTIFIED (h5_totals.json, first full merge)

    I_lo = 1.166721190e-08   (partial by construction: 2 × Σ 8 patch lowers)
    I_hi = 9.142887704e-02   (= 731.43 r³; 569× C1's 1.605315e-4 — honest wide)
    ck(C1_TOTAL = 1.605315e-4 ∈ [I_lo, I_hi]): PASS (consistency display only)
    coverage self-test (81×73 grid, every point ≥1 mechanism): PASS
    part ledger:  2R1 = 1.2217e-2   2rim = 1.949e-4   scone = 1.316e-3
                  mfwd = 2.776e-3   mbwd = 3.460e-8   sdisk = 3.876e-3
                  stitch = 6.8550e-2 (dominant; refine-3 pass in flight —
                  M-ring sec 0 collapsed to 0 via the v3 S-disk skip)
                  remote = 2.4438e-3 (D3-certified 19.55 r³)
Fail-closed assembly (all cks in h5_merge.py): 70/70 R1 cells, 10 rim columns,
probe buckets (5 sdisk + 6 sring + scone/mfwd/mbwd sites), 22 stitch sectors
(12 M-ring + 10 outer S-annulus), coverage self-test, C1 containment. A
stitch-refinement pass (finer tilings on the top sectors, min-per-sector) is
in flight; the headline above is the first complete certified assembly and is
valid as stands.

## 1. Exact split and per-part interval grade

Region decomposition about the pinned pair (M at −r/2, S at +r/2; y ↔ −y
pin symmetry doubles the half-plane parts):

| part | region | method | grade |
|---|---|---|---|
| R1 | C1 grid cells, δ_M ∈ [0.00895, 0.074], θ ∈ [0°,180°] | CoarseBox TM chain (TD=6) + `coarse_fine_hi` (K=12 sub-box product capture, FI Isserlis), 70 cells with size-based tiling (η_max = 8e-4 inner-ridge / 1.1e-3 ridge / 1.5e-3 else, ≤ 20 boxes/cell), adaptive 2×2 split on det-failure, plus multi-pass refinement (`cells2`, 4×3 and 8×6 tilings); merger takes the min per cell across passes (each record an independent certified upper) | machine-certified |
| R2+R3 (rim+floor) | disk δ_M ≤ 0.00895 (full circle) | NAMED-LEMMA H5-RIM: flat envelope ρ(y) ≤ C_flat(col) per 30°-ish column, C_flat = 2× certified probe-box ρ_hi at δ ∈ [0.004, 0.008] | named-lemma (probe constants machine-certified; flatness hypothesis stated below) |
| R4 (stitch) | ring δ_M ∈ [0.074, 0.10] full circle + S-annulus δ_S ∈ [0.024, 0.105] full circle | same fine-box machinery | machine-certified |
| R5 (remote) | d_pair ≥ 0.1 | D3-certified envelope (17.02 + 2.53)·r³ = 19.55·r³ | D3-certified (consumed) |
| R6 (axis cones + S-disk) | S-cones {d_S < 0.105, θ_S < 12° or > 168°} ∪ M-forward {d_M < 0.10, θ_M < 12°} ∪ M-backward {d_M < 0.10, θ_M > 168°} ∪ S-disk {d_S < 0.03, all directions (v2)} | NAMED-LEMMA H5-AXIS v1+v2: flat envelope ρ ≤ C per region, C = 2× max certified edge-probe ρ_hi (η = 2.5e-4 fine boxes) | named-lemma (probe constants machine-certified; flatness hypothesis below) |
| lower | 8 patches (η = 1e-4) at top-cell centers | Grade-A StationBox + GBounds: I ∈ [I_lo, I_hi] (Isserlis envelopes), ρ ≥ pgrad_lo·I_lo/Z_hi | machine-certified, PARTIAL by construction (patches only, tiny fraction, labeled) |

Assembly: I_hi = 2·R1 + 2·rim_half + scone + mfwd + mbwd + stitch + 19.55·r³;
I_lo = 2·Σpatches_lo.
Overlaps between parts only inflate the upper (valid). Coverage: R1's grid
edges span θ ∈ [0°,180°] exactly; stitch ring meets the grid at 0.074 and the
remote zone at 0.10; the S-annulus mirrors the M-side cover around S; the
H5-AXIS cones cover the pin-axis neighborhoods where the chart degenerates
(boxes straddling a cone boundary split until every sub-patch is either
inside a cone — skipped, envelope-covered — or outside — machine-certified).

**H5-AXIS (named lemma).** Statement: ρ_w(y) ≤ C_wedge over each of the
four axis wedges: {d_S < 0.105, θ_S < 10°}, {d_S < 0.105, θ_S > 170°},
{d_M < 0.074, θ_M < 10°}, {d_M < 0.074, θ_M > 170°}, with constants
C = 2× max certified probe ρ_hi at the wedge edges (η = 2.5e-4 fine boxes:
S-cone probes at θ_S ∈ {12°, 20°, 30°} × d_S ∈ {0.03, 0.06}; M-forward at
θ_M ∈ {8°, 12°} × d_M ∈ {0.012, 0.03, 0.06}; M-backward at θ_M ∈ {171°, 176°}
× same). Why the cones exist: the pins include ∇f(M) = ∇f(S) = 0, so the
conditioning {∇f(y) = 0} degenerates by collinearity as y approaches the
M–S axis: det Σ_gg(y) ~ 1e-15 falls below the Taylor-model slack everywhere
inside the wedges (measured: machine boxes fail at η down to 4e-4), while a
few degrees off-axis the same machinery certifies cleanly. Hypothesis: the
wedge interiors are *suppressed*, not singular — C1's on-axis grid values
inside the wedges are ≤ 2.5e-5 and mostly boosted-zero (e.g. (15°, 0.040)
= 3.7e-10, (15°, 0.026) = 0), and the certified wedge-edge constants are
already ≤ 0.66; the α-arch passes off-axis (θ ≈ 150–165° from M), so the
wedges contain no arch filament. Grade: named-lemma (same standing as
H5-RIM); the production path to machine-certify the wedges is the factored
det expansion (det Σ_gg = (d_M d_S)⁴·Q(y)(1+O(d)) pulled out analytically,
mirroring the c̃-det trick of §2), documented in §6.

**H5-AXIS v2 (amendment; v1 above preserved as historical record).**
What changed: v2 adds a fifth envelope region, the full S-disk
E5 = {d_S < 0.03} in ALL directions (no angular restriction), with constant
C_disk = 2× max certified edge-probe ρ_hi over a five-site ring at d_S = 0.040
(θ_S ∈ {30°, 60°, 90°, 120°, 150°} from the M-ward axis, i.e. all off the v1
cones; η = 2.5e-4 fine boxes, K=8) joined with the v1 cone probes at
d_S = 0.03. Certified ring values: 0.170, 0.064, 0.020, 0.039, 0.171
(receipts: h5_results_r0.05_sdisk.jsonl). Why: cell th15_dl0.066
(δ_M ∈ [0.058, 0.074], θ_M ∈ [0°, 30°]) maps partly into the off-cone near-S
band d_S ∈ [0.022, 0.03] — outside the v1 cones (θ_S ≈ 100–168° there) and
below the S-annulus stitch inner edge (0.024). The v1 machine cover certified
that band only with a vacuous bound (det Σ_gg.lo ~ 1e-20 → pgrad_sup
explosion; the cell's first certified record, 6.47e7, is preserved in the
jsonl ledger as the failed-cell receipt). The v2 disk skip/envelope reassigns
the band to the named lemma; the cell's remaining (machine-covered) part
recertified cleanly at 2.17e-5 (recompute receipt:
h5_results_r0.05_refine.jsonl). Quantifier update: the lemma now reads
ρ_w(y) ≤ C_wedge over each v1 wedge AND ρ_w(y) ≤ C_disk over d_S < 0.03, all
directions. Same grade as v1; the production path is the same factored-det
extension (the disk interior is exactly where the off-cone TM slack exceeds
det Σ_gg ~ d_S⁴·Q).

**Coverage completeness (fail-closed, mirrored as a ck in h5_merge.py).**
Every chart point is covered by at least one mechanism; double coverage only
adds to the upper. Machine covers: rim disk d_M < 0.00895 (H5-RIM envelope);
R1 grid 0.00895 ≤ d_M ≤ 0.074 full circle (70 cells ×2 by y→−y); stitch ring
0.074 < d_M < 0.10 full circle and S-annulus 0.024 ≤ d_S ≤ 0.105 full circle;
remote min(d_M, d_S) ≥ 0.1 (D3-certified 19.55·r³). Machine-skipped
sub-regions are exactly the envelope regions: H5-AXIS v1 wedges at 12°
(supersets of the 10° skip rectangles and of every depth-3 exemption, which
is recorded as an axisgap receipt) and the v2 S-disk. Boundary tests:
d_M < 0.00895 → rim; [0.00895, 0.074] → R1; (0.074, 0.10) → stitch;
d_S ∈ [0.024, 0.105] → S-annulus; d_S < 0.03 → S-disk; min(d_M, d_S) ≥ 0.1 →
remote; the only remaining combination (d_M ≥ 0.10 ∧ d_S ≥ 0.105) has
min(d_M, d_S) ≥ 0.1 → remote, so the union is complete. The merger evaluates
these predicates on an 81×73 polar grid and fails closed on any uncovered
sample; the census print reconciles the region counts (70 R1 cells, 32 stitch
sectors, 10 rim columns, 5+6+12 probe sites).

**H5-RIM (named lemma).** Statement: for δ = d(y,M) ≤ 0.00895,
ρ_w(y) ≤ C_flat(col(y)). Hypothesis: the near-pin flatness of ρ_w = pgrad·I/Z
(the coalescence chart: pgrad ~ P2(θ)·δ⁻² cancels I ~ K_I(θ)·δ², both rates
certified at the probe boxes — the probes display pgrad·δ² ∈ [0.001, 2.4]
and bounded I/δ²; C1's grid shows ρ flat within ~2× between its two innermost
rows dl = 0.00589 and dl = 0.012). The micro-disk δ → 0 is included in the
envelope (residual = C_flat·sector area → 0 with δ²). This is the one part of
the cover NOT machine-certified box-by-box; the tightening path is the
shell-bound extension documented in §6 (production run).

## 2. The certified box bound (what every box proves)

For a box B = y_c ± (η₁, η₂) the driver certifies
∫_B ρ_w dA ≤ Σ_{sub-boxes} area·pgrad_sup·I_hi/Z_lo where:

- **Taylor models (TD = 6 coarse / TD = 5 fine-chart, 28/21 monomials, certified
  remainder R via ring-norm drop bounds; int-0 sentinels mark exact zeros)** —
  the full 18-jet conditional law (pins + ∇f(y) = 0 + f(y) = v) as TMs in
  (u₁, u₂): means μ1, covariances S1 (Grr − CA·Cᵀ), then stage-2 conditioning
  on ∇f(y) = 0 by POSTPONED DIVISION: NUM = detgg·X − Grg·adj(Σgg)·Grgᵀ kept
  as pure TM polynomials, one interval division at the end (kills the
  ad − c² correlation loss of naive interval inversion).
- **pgrad_sup** = e^{−q_lo/2}/(2π√detgg_inf), q = μ_gᵀΣ_gg⁻¹μ_g ≥ 0 (q_lo
  clamped at 0, valid).
- **I_hi** per sub-box = min(√(M12'·min(mass_sup, PS_min)), …) with
  M12' = E[(detM detS dety)² | pins, ∇=0] by Isserlis (Stein recursion, 3375
  states) in certified float64 radius-arithmetic (FI: radius padded per op,
  8-ulp relative + absolute floor), and mass/PS crushes:
  - mass_sup: window mass min(1, ℓ/(√(2π)s_t,inf)·e^{−w0²/2}) — the window
    [b−ℓ, b] vs the certified (μ_t, s_t) sub-box enclosure.
  - PS_min: typing-flip probabilities via the margin lemma
    P(wrong sign) ≤ 2Φ̄(m/2σ_L) + EQ2/(m/2)² (Mills + quadratic control),
    plus the trace-Mills route.
- **Z_r** interval: [max(H3 c_Z r², own lo), √(M8)] with H3 c_Z = 1.6154892…
  (existential r₀ flagged as a shared campaign hypothesis), own bracket
  lo = m4 − √(M8·PnC) (vacuous at r = 0.05: PnC ≤ 1 → lo = 0, honest).
  Measured: Z(0.05) ∈ [4.038723e-3, 1.397032e-2] ∋ C1 QMC 8.059372673e-3.

## 3. Validation record (load-bearing)

1. **Exact det quadratic expansion** det(X + c̃w) = A + Bw + Cw² in w-space
   (w = (v−μ_t)/s_t, c̃ = c_v·s_t = O(1)) — kills the c_v⁶ ~ 1e27 cancellation
   of the v-space formulation; A, B, C exact TM-polynomials of the 18 jets.
2. **w-space quadrature's exact v-window coverage**: the Gaussian quadrature
   cells in w map to certified v-intervals; the window [b−ℓ, b] is covered by
   explicit index arithmetic (no leakage, no double count; window residual
   displayed per box).
3. **Unconditioned anchors** (D3 closed forms, interval-evaluated):
   ρ_sad⁰(b) = [0.03049349156857891…] (reference decimal 0.030493491569 at
   half-ulp of the 12th digit), m_sad(b) = √2 e^{−b²/4}, J(ℓ) erf-form.
4. **k1 twin check**: the lattice kernel series vs the direct evaluation,
   interval containment at every coefficient (self-test in every run).
5. **TM self-checks**: Neumann-series inverses vs interval LU on random
   boxes; postponed-division S2/mu2 vs direct point conditioning (containment).
6. **FI engine**: containment vs the mpf-interval Isserlis recursion.
7. **Box-level brackets of C1's per-cell ρ**: every R1 cell transcript line
   shows (hi, C1 contribution, ratio); dominant-cell ratios ~18–31×.
8. **fail-closed**: every certificate via ck() → SystemExit; no bare asserts.

## 4. Remainder ledger (all displayed in transcripts/receipts)

- spectral tails: k1 Taylor remainders (NMAX = 4+TD+2 term drop bounds, per-TM R).
- conditioning residuals: Neumann certificates (‖res‖ bounds) for Σ⁻¹ chains;
  stage-2 postponed-division numerator remainders (ring-norm drop, TD=6).
- quadrature remainders: Hermite-grid truncation T = 7, K = 64–128 cells +
  tail bound; window-edge residual.
- spatial discretization: per-box TM remainders R (displayed as interval
  widths), polar-patch exact enclosing rectangles (×1.0000000001 dilation).
- near-singular charts: the rim is the singular chart (pgrad·I = O(1) with
  pgrad ~ δ⁻²); treated by H5-RIM named lemma (§1) — stated hypothesis, not
  hidden.
- iv propagation: mpf-iv at dps 40 (driver), FI radius arithmetic with per-op
  padding (fine path), both containment-checked against dps-64 references.

## 5. r-dependence (rungs, no exponent fitted)

- r = 0.05: full cover (this document).
- r = 0.025: CRUDE rung (labeled crude): same machinery at the dominant-box
  probe only: box-hi/r³ = 0.948 vs 0.106 at r = 0.05 (ratio 8.9×). The
  increase is dominated by the Z_r ∝ r² normalization and the fixed box size;
  Z(0.025) ∈ [1.009681e-3, 3.497877e-3]. No exponent fitted from two rungs
  (discipline); inter-rung behavior named: the certified per-box envelope
  grows relative to r³ as r halves, the arch-filament truth scales r³ by C1.

## 6. Production tightening command (documented, not run)

Overnight sharpening (Grade-B fine path everywhere, smaller η, larger K):

    python3 h5_run.py --r 0.05 --part cells --shard S --nshards 8   # S=0..7
    python3 h5_run.py --r 0.05 --part stitch
    python3 h5_run.py --r 0.05 --part rimprobes
    python3 h5_run.py --r 0.05 --part patches
    python3 h5_merge.py --r 0.05

with class sizes raised to (nth, ndl, K) = (6, 4, 16)/(3, 2, 12)/(2, 1, 10)
(≈12× the boxes, ≈30 h on 8 shards) plus the shell-bound extension
(`shell_hi_fi`, present but p_sup-dominated near M — needs the conditional-
density sharpening) to machine-certify the rim and retire H5-RIM.

## 6b. Cover execution discipline (infrastructure-resilient)

The cover runs under `supervisor.sh` (bounded: ≤ 3 driver relaunches until
70/70 cells banked, then cells2 passes at scale 1 and 2, rimprobes, stitch,
patches, merge) launched detached via setsid/nohup; `watchdog.sh` heartbeats
`live_age` (mtime of `.live`, rewritten per completed cell) + driver/
supervisor counts to `watch.log` every 60 s. Drivers are resume-aware
(completed cells are skipped; records stream to per-part jsonl files so no
two parts overwrite each other).

## 7. Determinism, falsifier, freeze

`python3 falsify.py --mode A` / `--mode B`: byte-identical digests
(`falsify_modeA.txt` vs `falsify_modeB.txt`), re-certifies anchors, Z window,
one dominant-box window, and the totals containment. Receipts separate:
`h5_results_*.jsonl` (machine), `h5_transcript_*.txt` (human),
`CODE_HASHES.txt` (sha256 of the four code files), `h5_totals.json` (numbers).

Body hash of this document (excluding this line): computed at freeze, printed
in H5_RECEIPTS.txt.

---

body-sha256: 465c97c0553ecc0a8f461a86c9315ce1c078a326f07b81498d7a74da8603d301
