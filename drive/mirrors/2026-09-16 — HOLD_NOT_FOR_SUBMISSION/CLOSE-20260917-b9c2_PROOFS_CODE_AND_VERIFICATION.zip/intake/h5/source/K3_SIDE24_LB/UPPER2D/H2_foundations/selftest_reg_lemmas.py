#!/usr/bin/env python3
"""
selftest_reg_lemmas.py -- fail-closed self-test for reg_lemmas.py, certifying
obligations OBL-B1-REG-G1, G4, G5 on the exact periodized field.

  R1  G4 rank-3 witness: cond cov of V5(x;M) given the six pins has exactly
      2 structurally-zero directions and 3 active at all 17 B2b probe points;
      active-block certified floor >= 6.1e-3 on the distance>=1 grid
      (certified min 6.16e-3 at (1,0.5); B2b float64 witness 6.2e-3);
  R2  G4 rank drop at S too (pair with the pinned saddle value);
  R3  G4 near-pin rate: lambda_min of the active block ~ C(r,u) d^6 with
      C > 0 certified by interval enclosures (NOT ~d^8: B2b's 2.4e-22 at
      d=0.002 is below the float64 eigvalsh noise floor ~1e-16 and is
      uncertifiable; certified value 7.3e-20, local exponents -> 6);
      mechanism: Var(f_xxx | pins) ~ 6 r^2 (certified), the other third-jet
      directions O(1);
  R4  G4/G5(c): Cov(H(M) | pins) PD, lambda_min ~ 1.04e-6 at r=0.05,
      scaling ~ r^4 (certified at r = 0.1, 0.05, 0.025);
  R5  G4 isolation algebra (sympy): the exclusion-zone inequalities;
  R6  G1: Upair diagonal rate ~ delta^6 (B2b's 4.2e-8 at delta=0.1
      reproduced: certified enclosure at 4.1561e-8) and separated-pair floor
      > 1e-6 on B2b's pair grid;
  R7  G5: 11-jet floors certified (7.5706e-11 enclosure at (1,0.5); B2b
      7.6e-11), the corpus's ten-jet endpoint floor ~ 0.12655 (citation
      scope anchor), and the general scheme applied to (a) (grad f(x),H(x))
      + pins at a near-pin point, (b) pair map + pins at a distinct pair,
      (c) a 14-jet three-point configuration -- all certified PD with
      explicit floors, no uniform floor over configurations (rates
      catalogued in R3/R4/R6).

Usage: python selftest_reg_lemmas.py
Deterministic; byte-identical under python and python -O; ck() fail-closed.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import sympy as sp
from mpmath import mp, mpf, iv

import cov_exact as ce
import pin_transform as pt
import reg_lemmas as rg


def ck(cond, msg="check"):
    if not cond:
        print("CHECK FAILED:", msg)
        raise SystemExit(1)
    print("[ok]", msg)


def nstr(x, n=6):
    return mp.nstr(x, n)


def eig_enclosure(A_iv):
    """Certified enclosure [lb, ub] of lambda_min of a symmetric interval
    matrix: lb from the Neumann inverse certificate; ub from the mpf
    eigensolver plus a Weyl residual computed in interval arithmetic plus the
    entry widths."""
    cert = rg.gram_eigfloor_certificate(A_iv)
    n = len(A_iv)
    mid = mp.matrix(n, n)
    for i in range(n):
        for j in range(n):
            mid[i, j] = rg._mid(A_iv[i][j])
    lam = sorted(mp.eigsy(mid)[0])[0]
    # eigenvector residual for the smallest eigenpair (interval A)
    ev, vec = mp.eigsy(mid)
    order = sorted(range(n), key=lambda i: ev[i])
    v = [vec[j, order[0]] for j in range(n)]
    res = mpf(0)
    for i in range(n):
        s = iv.mpf(0)
        for k in range(n):
            s = s + A_iv[i][k] * iv.mpf(v[k])
        res = max(res, max(abs(mpf(s.a)), abs(mpf(s.b))))
    width = max(mpf(A_iv[i][j].b) - mpf(A_iv[i][j].a) for i in range(n) for j in range(n))
    ub = lam + res + n * width
    return cert['lambda_min_lower'], ub, lam


print("selftest_reg_lemmas.py -- H2 Lemma-R regularity certificates (G1/G4/G5)")
print("config:", sorted((k, v) for k, v in ce.get_config().items()))

R05 = mpf('0.05')
_, Mp, Sp = rg.six_pins(R05)
pin_inv_05 = rg.pin_inverse(R05, 'iv')

# ------------------------------------------------------------------ R1
print("-- R1 G4: pinned-pair conditional covariance has rank exactly 3")
SEP = [(1.0, 0.5), (3.0, -2.0), (6.0, 0.1), (12.0, 12.0), (-6.0, 4.0),
       (0.0, 8.0), (-3.0, -5.0), (8.0, -8.0)]
NEAR = [(Mp[0] + d, Mp[1] + mpf('0.3') * d) for d in
        (mpf('0.002'), mpf('0.005'), mpf('0.01'), mpf('0.05'), mpf('0.2'))] + \
       [(Sp[0] + d, Sp[1] - mpf('0.3') * d) for d in
        (mpf('0.002'), mpf('0.01'), mpf('0.05'), mpf('0.2'))]
def dpin(x):
    return min(mp.sqrt((x[0] - Mp[0])**2 + x[1]**2), mp.sqrt((x[0] - Sp[0])**2 + x[1]**2))
floor_sep = mpf('1e9')
for xp in SEP + NEAR:
    x = (mpf(xp[0]), mpf(xp[1]))
    ev, _ = rg.cond_eigs(rg.V5_map(x, Mp), R05, 'iv', pin_inv_05)
    d = dpin(x)
    # certified rank-3 statement at every point: exactly two structural zero
    # directions (the a.s.-constant grad f(M) coords, analytic) AND the active
    # 3x3 block certified PD by an interval eigenfloor.
    C, _ = rg.cond_cov(rg.rank3_active(x, Mp), R05, pin_inv_05, 'iv')
    lb, ub, _ = eig_enclosure(C)
    ck(lb > 0, "R1 active block certified PD at x=(%s,%s), d=%s: %s <= lambda_min <= %s"
       % (xp[0], xp[1], nstr(d, 3), nstr(lb, 4), nstr(ub, 4)))
    if d >= mpf('0.2'):
        # hard threshold check (B2b's): 2 zeros, 3 active with margins >= 1e7
        zc = sum(1 for e in ev if abs(e) < mpf('1e-15'))
        ac = sum(1 for e in ev if e > mpf('1e-15'))
        ck(zc == 2 and ac == 3,
           "R1 rank exactly 3 (hard threshold) at x=(%s,%s), d=%s: zeros=%s active=%s (smallest active %s)"
           % (xp[0], xp[1], nstr(d, 3), zc, ac, nstr(ev[2], 3)))
    else:
        print("   R1 near-pin x=(%s,%s), d=%s: two structural zeros ~1e-95; third active eigenvalue %s "
              "< 1e-15 threshold (two-zone regime -- see R3)" % (xp[0], xp[1], nstr(d, 3), nstr(ev[2], 3)))
    if d >= 1:
        floor_sep = min(floor_sep, lb)
ck(floor_sep > mpf('6.1e-3'),
   "R1 certified active floor on the distance>=1 grid: %s > 6.1e-3 (B2b float64 witness 6.2e-3)"
   % nstr(floor_sep, 6))
ck(abs(floor_sep - mpf('0.00616467')) < mpf('2e-6'),
   "R1 FALSIFIER anchor: floor = 6.16467e-3 +/- 2e-6 (recompute to falsify)")

# ------------------------------------------------------------------ R2
print("-- R2 G4: same rank drop at the saddle pin S")
x = (mpf(3), mpf(-2))
ev, _ = rg.cond_eigs(rg.V5_map(x, Sp), R05, 'iv', pin_inv_05)
zc = sum(1 for e in ev if abs(e) < mpf('1e-15'))
ac = sum(1 for e in ev if e > mpf('1e-15'))
ck(zc == 2 and ac == 3, "R2 rank exactly 3 for pairs involving S (smallest active %s)" % nstr(ev[2], 3))

# ------------------------------------------------------------------ R3
print("-- R3 G4: near-pin rate lambda_min ~ C d^6, C > 0 (d^8 witness corrected)")
ds = [mpf('0.2'), mpf('0.05'), mpf('0.01'), mpf('0.002'), mpf('0.0005')]
for dirv, tag in (((mpf(1), mpf('0.3')), "u=(1,0.3)"), ((mpf('0.2'), mpf(-1)), "u=(0.2,-1)")):
    un = mp.sqrt(dirv[0]**2 + dirv[1]**2)
    u = (dirv[0] / un, dirv[1] / un)
    lams = []
    for d in ds:
        x = (Mp[0] + d * u[0], Mp[1] + d * u[1])
        C, _ = rg.cond_cov(rg.rank3_active(x, Mp), R05, pin_inv_05, 'iv')
        lb, ub, lam = eig_enclosure(C)
        ck(lb > 0, "R3 active block certified PD at d=%s %s: %s <= lambda_min <= %s"
           % (nstr(d, 3), tag, nstr(lb, 4), nstr(ub, 4)))
        lams.append((d, lb, ub, lam))
    exps = [mp.log(lams[i][3] / lams[i + 1][3]) / mp.log(lams[i][0] / lams[i + 1][0])
            for i in range(len(ds) - 1)]
    ck(all(mpf('5.5') < e < mpf('6.5') for e in exps[-2:]),
       "R3 asymptotic local exponents -> 6 %s: full sequence %s (crossover at d>0.01; NOT ~8)"
       % (tag, [nstr(e, 4) for e in exps]))
    c6 = [lams[i][3] / ds[i]**6 for i in range(len(ds))]
    ck(mpf('0.5') < c6[-1] / c6[-2] < 2 and c6[-1] > 0,
       "R3 asymptotic constant C = lambda/d^6 stabilizes %s: sequence %s (last two within a factor 2; C > 0 certified)"
       % (tag, [nstr(c, 3) for c in c6]))
    if tag == "u=(1,0.3)":
        lam002 = lams[3][3]
        ck(mpf('5e-20') < lam002 < mpf('2e-19'),
           "R3 FALSIFIER anchor: lambda_min(d=0.002) = %s in [5e-20, 2e-19]" % nstr(lam002, 6))
        ck(lam002 > 100 * mpf('2.4e-22'),
           "R3 certified value exceeds B2b's float64 number 2.4e-22 by >100x: "
           "that number sits below the float64 eigvalsh noise floor (~1e-16 for an O(1)-norm "
           "matrix) and was uncertifiable; the certified rate is d^6")
# mechanism: the pin leak suppresses the along-axis third jet ~ 6 r^2
print("   mechanism: conditional third-jet covariance at M")
vxxx = []
for rr in (mpf('0.1'), mpf('0.05'), mpf('0.025')):
    pinv = rg.pin_inverse(rr, 'iv') if rr != R05 else pin_inv_05
    _, Mr, _ = rg.six_pins(rr)
    CT, _ = rg.cond_cov(rg.third_jet(Mr), rr, pinv, 'iv')
    lb, ub, _ = eig_enclosure(CT)
    ck(lb > 0, "R3 third jets at M | pins certified PD at r=%s (floor %s)" % (nstr(rr, 4), nstr(lb, 4)))
    vxxx.append((rr, rg._mid(CT[0][0])))
rates = [vxxx[i][1] / vxxx[i][0]**2 for i in range(3)]
ck(all(mpf('4') < q < mpf('9') for q in rates),
   "R3 Var(f_xxx | pins) ~ 6 r^2 certified: %s (planar value 15 is NEVER the conditioned one)"
   % [nstr(q, 4) for q in rates])

# ------------------------------------------------------------------ R4
print("-- R4 G4/G5(c): Hessian law at the pin is PD, lambda_min ~ r^4")
hm = []
for rr in (mpf('0.1'), mpf('0.05'), mpf('0.025')):
    pinv = rg.pin_inverse(rr, 'iv') if rr != R05 else pin_inv_05
    _, Mr, _ = rg.six_pins(rr)
    CH, _ = rg.cond_cov(rg.H_jet(Mr), rr, pinv, 'iv')
    lb, ub, lam = eig_enclosure(CH)
    ck(lb > 0, "R4 H(M)|pins certified PD at r=%s: %s <= lambda_min <= %s"
       % (nstr(rr, 4), nstr(lb, 5), nstr(ub, 5)))
    hm.append((rr, lam))
ck(abs(hm[1][1] - mpf('1.0411e-6')) < mpf('3e-8'),
   "R4 FALSIFIER anchor: lambda_min(H(M)|pins) at r=0.05 = %s (B2b ~1.0e-6)" % nstr(hm[1][1], 6))
rates = [mp.log(hm[i][1] / hm[i + 1][1]) / mp.log(hm[i][0] / hm[i + 1][0]) for i in range(2)]
ck(all(mpf('3.5') < e < mpf('4.5') for e in rates),
   "R4 lambda_min(H(M)|pins) ~ r^4: local exponents %s" % [nstr(e, 4) for e in rates])

# ------------------------------------------------------------------ R5
print("-- R5 G4: near-pin isolation algebra (sympy)")
t, lam, K3 = sp.symbols('t lambda K3', positive=True)
g_bound = -lam * t**2 / 2 + K3 * t**3 / 6
ck(sp.factor(g_bound) == t**2 * (K3 * t - 3 * lam) / 6,
   "R5 f(M+tu) - b <= -lambda t^2/2 + K3 t^3/6 = (t^2/6)(K3 t - 3 lambda) < 0 for 0 < t < 3 lambda/K3")
ck(sp.simplify(g_bound.subs(t, 2 * lam / K3)) == -2 * lam**3 / (3 * K3**2) and
   sp.simplify(g_bound.subs(t, 4 * lam / K3)) == 8 * lam**3 / (3 * K3**2),
   "R5 value-exclusion zone radius 3 lambda / K3 (sign checked at 2 lambda/K3 and 4 lambda/K3)")
gp_bound = lam * t - K3 * t**2 / 2
ck(sp.simplify(gp_bound - t * (2 * lam - K3 * t) / 2) == 0 and
   sp.simplify(gp_bound.subs(t, lam / K3)) == lam**2 / (2 * K3),
   "R5 |grad f(M+tu)| >= lambda t - K3 t^2/2 = (t/2)(2 lambda - K3 t) > 0 for 0 < t < 2 lambda/K3 "
   "(no other critical points in the zone)")
print("   assembly (README): H(M)|pins nondegenerate (R4) => lambda > 0 a.s. under the weighted law;")
print("   ||f||_{C^3} finite a.s.; truncation events + Q_r-null => P_r(B3 tie class) = 0")

# ------------------------------------------------------------------ R6
print("-- R6 G1: near-diagonal pair-map degeneracy and separated floor")
base = (mpf(3), mpf(-2))
th = mpf('0.7'); u = (mp.cos(th), mp.sin(th))
lm = {}
for dlt in (mpf('1e-3'), mpf('0.1'), mpf('0.5'), mpf('2'), mpf('6')):
    y = (base[0] + dlt * u[0], base[1] + dlt * u[1])
    C, _ = rg.cond_cov(rg.Upair_map(base, y), R05, pin_inv_05, 'iv')
    lb, ub, lam = eig_enclosure(C)
    ck(lb > 0, "R6 Upair certified PD at delta=%s: %s <= lambda_min <= %s"
       % (nstr(dlt, 3), nstr(lb, 4), nstr(ub, 4)))
    lm[dlt] = lam
ck(abs(lm[mpf('0.1')] - mpf('4.1561e-8')) < mpf('5e-10'),
   "R6 FALSIFIER anchor: lambda_min(delta=0.1) = %s (B2b float64 witness 4.2e-8)" % nstr(lm[mpf('0.1')], 6))
ck(lm[mpf('1e-3')] < mpf('1e-16'),
   "R6 lambda_min(1e-3) = %s genuinely ~ 0: no uniform density bound extends to the diagonal"
   % nstr(lm[mpf('1e-3')], 4))
exp6 = mp.log(lm[mpf('0.1')] / lm[mpf('1e-3')]) / mp.log(100)
ck(mpf('5.5') < exp6 < mpf('6.5'), "R6 diagonal degeneracy rate ~ delta^6 (exponent %s)" % nstr(exp6, 4))
ck(lm[mpf('2')] > mpf('1e-2') and lm[mpf('6')] > mpf('0.5'),
   "R6 separated pair map strongly PD (delta=2: %s, delta=6: %s)"
   % (nstr(lm[mpf('2')], 4), nstr(lm[mpf('6')], 4)))
pair_grid = [(1.0, 0.5), (3.0, -2.0), (-4.0, 1.0), (0.0, 8.0), (12.0, 12.0),
             (Mp[0] + 0.4, Mp[1] + 0.1), (Sp[0] + 0.3, Sp[1] - 0.2)]
floor_pair = mpf('1e9')
for xp in pair_grid:
    x = (mpf(xp[0]), mpf(xp[1]))
    for yp in [(x[0] + 0.5, x[1] + 0.2), (x[0] + 2.0, x[1] - 1.0),
               ((x[0] + 6.0) % 24, (x[1] + 3.0) % 24)]:
        y = (mpf(yp[0]), mpf(yp[1]))
        C, _ = rg.cond_cov(rg.Upair_map(x, y), R05, pin_inv_05, 'iv')
        lb, ub, _ = eig_enclosure(C)
        floor_pair = min(floor_pair, lb)
ck(floor_pair > mpf('1e-6'),
   "R6 certified separated-pair floor on B2b's pair grid: %s > 1e-6" % nstr(floor_pair, 5))
print("   bootstrap (README): coincidence at separation delta forces |det H(x)| <= (K2 K3/2) delta;")
print("   expected critical count with |det H| <= eta under Q_r <= 576 eta / (2 pi * floor) -> 0")

# ------------------------------------------------------------------ R7
print("-- R7 G5: full-rank certificates (11-jet and general configurations)")
fl11 = mpf('1e9')
for xp in [(1.0, 0.5), (3.0, -2.0), (12.0, 12.0)]:
    x = (mpf(xp[0]), mpf(xp[1]))
    G11 = rg.gram(rg.J5_jet(x) + rg.six_pins(R05)[0], 'iv')
    lb, ub, lam = eig_enclosure(G11)
    ck(lb > 0, "R7 11-jet (J5(x) + 6 pins) certified PD at x=%s: %s <= lambda_min <= %s"
       % (xp, nstr(lb, 4), nstr(ub, 4)))
    fl11 = min(fl11, lb)
    if xp == (1.0, 0.5):
        ck(abs(lam - mpf('7.5706e-11')) < mpf('3e-13'),
           "R7 FALSIFIER anchor: 11-jet lambda_min at (1,0.5) = %s (B2b 7.6e-11)" % nstr(lam, 6))
ck(fl11 > mpf('1e-12'), "R7 11-jet certified floor over the three probes: %s > 1e-12" % nstr(fl11, 4))
# citation scope anchor: the corpus's ten-jet endpoint floor
G10 = rg.gram(rg.ten_jet((mpf(0), mpf(0))), 'iv')
lb, ub, lam = eig_enclosure(G10)
ck(lb > mpf('0.08') and mpf('0.126') < lam < mpf('0.127'),
   "R7 citation scope anchor: endpoint ten-jet lambda_min = %s, certified floor %s "
   "(the cited argument proves ONE single-endpoint eigenfloor only; G5 generalizes)" % (nstr(lam, 8), nstr(lb, 6)))
# (a) (grad f(x), H(x)) + pins at a near-pin point d=0.16 from M
x = (Mp[0] + mpf('0.16'), Mp[1] + mpf('0.05'))
Ga = rg.gram(rg.J5_jet(x) + rg.six_pins(R05)[0], 'iv')
lb, ub, lam = eig_enclosure(Ga)
ck(lb > 0, "R7 (a) (grad f(x),H(x)) + pins at d=0.16 from M certified PD: floor %s (no uniform floor -- "
           "near-pin ~ d^6 scale)" % nstr(lb, 4))
# (b) pair map + pins at a distinct pair
x = (mpf(3), mpf(-2)); y = (mpf('3.5'), mpf('-1.8'))
Gb = rg.gram(rg.Upair_map(x, y) + rg.six_pins(R05)[0], 'iv')
lb, ub, lam = eig_enclosure(Gb)
ck(lb > 0, "R7 (b) pair map + pins at a distinct pair certified PD: floor %s" % nstr(lb, 4))
# (c) arbitrary 14-jet three-point configuration
cfg = (rg.J5_jet((mpf('1.7'), mpf('2.9'))) + rg.J5_jet((mpf('-4.2'), mpf('1.1')))
       + rg.third_jet((mpf('0.9'), mpf('-5.7'))))
Gc = rg.gram(cfg, 'iv')
lb, ub, lam = eig_enclosure(Gc)
ck(lb > 0, "R7 (c) arbitrary 14-jet three-point configuration certified PD: floor %s "
           "(general lemma: linear independence of derivative evaluations at distinct points)"
           % nstr(lb, 4))

print("")
print("SELFTEST_REG_LEMMAS: PASS (G1/G4/G5 certified on the exact field; fail-closed)")
