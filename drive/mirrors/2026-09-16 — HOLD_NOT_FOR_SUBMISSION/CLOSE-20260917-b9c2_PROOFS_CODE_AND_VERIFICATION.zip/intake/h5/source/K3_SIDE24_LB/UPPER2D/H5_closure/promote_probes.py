#!/usr/bin/env python3
# promote_probes.py — rung sdisk/sring edge probes (H5-AXIS v2/v3 constants
# per rung) using the generated r-scaled driver module's machinery.
# Usage: python3 promote_probes.py --r 0.025 --half 0
import sys, os, time, importlib.util
D = '/mnt/agents/output/K3_SIDE24_LB/UPPER2D/H5_closure'
args = sys.argv[1:]
r_str = args[args.index('--r') + 1]
HALF = int(args[args.index('--half') + 1]) if '--half' in args else 0
s = float(r_str)/0.05
tag = r_str.replace('.', 'p')
mod_path = os.path.join(D, 'h5_run_r%s.py' % tag)
if not os.path.exists(mod_path):
    print('rung module missing (run promote_run.py once first): %s' % mod_path)
    raise SystemExit(1)
sys.path.insert(0, D)
spec = importlib.util.spec_from_file_location('h5_run_rung', mod_path)
h5_run = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h5_run)
from mpmath import mpf, mp, iv, pi
import h5_kernel as hk
r = mpf(r_str)
hk.LAT.self_test()
ctx = h5_run.Ctx(r, HALF, 2, 'r%s_s%dp2_probes' % (r_str, HALF))
ctx.rec = open(os.path.join(D, 'h5_results_r%s_s%dp2_probes.jsonl' % (r_str, HALF)), 'a')
ctx.log = open(os.path.join(D, 'h5_transcript_r%s_s%dp2_probes.txt' % (r_str, HALF)), 'a')
ctx.frame = hk.PinFrame(r)
Z_own, M4, M8, PnC = hk.Z_r_own_bracket(ctx.frame.mu_pair, ctx.frame.S_pair)
ctx.Z_lo = max(mpf(hk.C_Z_H3)*r*r, mpf(Z_own.a))
ctx.Z_hi = mpf(Z_own.b)
asx = r/2
ETA = mpf('0.00025')*mpf(s)
# sdisk: ring at d_S = 0.040*s, five off-cone directions (v2)
SDISK = [(30, 0.040), (60, 0.040), (90, 0.040), (120, 0.040), (150, 0.040)]
# sring: d_S in [0.065, 0.085]*s (v3)
SRING = [(30, 0.065), (60, 0.065), (90, 0.065), (120, 0.065), (150, 0.065), (90, 0.085)]
work = [('sdisk', th, d) for (th, d) in SDISK] + [('sring', th, d) for (th, d) in SRING]
for (kind, thS, dS) in work[HALF::2]:
    thm = mpf(thS)*pi/180
    yc = (asx + mpf(dS)*mpf(s)*mp.cos(pi - thm), mpf(dS)*mpf(s)*mp.sin(pi - thm))
    t0 = time.time()
    try:
        cb = ctx.coarse(yc, ETA, ETA)
        hi = mpf(hk.coarse_fine_hi(cb, ctx.Z_lo, 8))
        rho_hi = hi/(4*ETA**2)
        print('%s probe thS=%d dS=%s: rho_hi=%.4e (%.0fs)' % (kind, thS, dS, rho_hi, time.time()-t0), flush=True)
        ctx.jrec(dict(part=kind + 'probe', thS=thS, dS='%.8e' % (dS*s), rho_hi=str(rho_hi)))
    except SystemExit as e:
        print('%s probe thS=%d dS=%s FAILED: %s' % (kind, thS, dS, str(e)[:60]), flush=True)
        ctx.jrec(dict(part=kind + 'probe_fail', thS=thS, dS='%.8e' % (dS*s)))
print('probes half %d done (r=%s)' % (HALF, r_str), flush=True)
