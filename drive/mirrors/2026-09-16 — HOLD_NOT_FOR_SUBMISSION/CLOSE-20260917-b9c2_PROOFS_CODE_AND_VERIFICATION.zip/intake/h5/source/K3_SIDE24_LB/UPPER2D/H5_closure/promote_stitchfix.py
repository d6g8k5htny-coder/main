#!/usr/bin/env python3
# promote_stitchfix.py — one-work-unit stitch refiner at a rung: re-certifies
# ONE stitch sector with a finer tiling; min-per-sector in the merger picks
# the tightest (the coarse poison record stays banked, superseded).
# Usage: python3 promote_stitchfix.py --r 0.025 --kind M --sec 6 --nth 8 --ndl 5
import sys, os, time, importlib.util
D = '/mnt/agents/output/K3_SIDE24_LB/UPPER2D/H5_closure'
args = sys.argv[1:]
r_str = args[args.index('--r') + 1]
KIND = args[args.index('--kind') + 1]
SEC = int(args[args.index('--sec') + 1])
NTH = int(args[args.index('--nth') + 1]) if '--nth' in args else 8
NDL = int(args[args.index('--ndl') + 1]) if '--ndl' in args else 5
s = float(r_str)/0.05
tag = r_str.replace('.', 'p')
mod_path = os.path.join(D, 'h5_run_r%s.py' % tag)
if not os.path.exists(mod_path):
    print('rung module missing: %s' % mod_path)
    raise SystemExit(1)
sys.path.insert(0, D)
spec = importlib.util.spec_from_file_location('h5_run_rung', mod_path)
h5_run = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h5_run)
from mpmath import mpf, mp, iv, pi
mp.dps = 40; iv.dps = 40
import h5_kernel as hk
r = mpf(r_str)
hk.LAT.self_test()
ctx = h5_run.Ctx(r, 0, 1, 'r%s_stitchfix' % r_str)
ctx.rec = open(os.path.join(D, 'h5_results_r%s_stitchfix.jsonl' % r_str), 'a')
ctx.log = open(os.path.join(D, 'h5_transcript_r%s_stitchfix.txt' % r_str), 'a')
ctx.frame = hk.PinFrame(r)
Z_own, M4, M8, PnC = hk.Z_r_own_bracket(ctx.frame.mu_pair, ctx.frame.S_pair)
ctx.Z_lo = max(mpf(hk.C_Z_H3)*r*r, mpf(Z_own.a))
ctx.Z_hi = mpf(Z_own.b)
t0 = time.time()
if KIND == 'M':
    t1 = -15 + 30*SEC; t2 = t1 + 30
    d1 = mpf('0.074')*mpf(s); d2 = mpf('0.10')*mpf(s)
    hi = h5_run.bound_cell_fine(ctx, -r/2, t1, t2, d1, d2, NTH, NDL, 8, 0)
    print('stitchfix M sec %d [%d,%d] tiling %dx%d: hi=%.6e (%.0fs)' % (SEC, t1, t2, NTH, NDL, hi, time.time()-t0), flush=True)
    ctx.jrec(dict(part='stitchM', sec=SEC, hi=str(hi)))
else:
    t1 = -18 + 36*SEC; t2 = t1 + 36
    d1 = mpf('0.06')*mpf(s); d2 = mpf('0.105')*mpf(s)
    hi = h5_run.bound_cell_fine(ctx, r/2, t1, t2, d1, d2, NTH, NDL, 8, 0)
    print('stitchfix S-outer sec %d [%d,%d] tiling %dx%d: hi=%.6e (%.0fs)' % (SEC, t1, t2, NTH, NDL, hi, time.time()-t0), flush=True)
    ctx.jrec(dict(part='stitchS', d1=str(d1), sec=SEC, hi=str(hi)))
