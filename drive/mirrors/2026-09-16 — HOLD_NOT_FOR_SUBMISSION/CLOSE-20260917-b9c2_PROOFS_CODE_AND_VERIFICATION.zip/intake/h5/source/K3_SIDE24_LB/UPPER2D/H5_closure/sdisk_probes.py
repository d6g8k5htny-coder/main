import sys, time
sys.path.insert(0, '/mnt/agents/output/K3_SIDE24_LB/UPPER2D/H5_closure')
import h5_run
from mpmath import mpf, mp, iv, pi
mp.dps = 40
iv.dps = 40
import h5_kernel as hk

r = mpf('0.05')
hk.LAT.self_test()
ctx = h5_run.Ctx(r, 0, 1, 'refine')
ctx.rec = open('/mnt/agents/output/K3_SIDE24_LB/UPPER2D/H5_closure/h5_results_r0.05_sdisk.jsonl', 'a')
ctx.log = open('/mnt/agents/output/K3_SIDE24_LB/UPPER2D/H5_closure/sdisk_detail.log', 'a')
ctx.frame = hk.PinFrame(r)
ctx.Z_lo = mpf('4.0387231691e-3')
ctx.Z_hi = mpf('1.3970321600e-2')
asx = r/2
# H5-AXIS v2: S-disk edge probes, ring d_S in [0.032, 0.048], five directions
# off the axis cones (cone directions are probed by the v1 scone probes).
for thS in (30, 60, 90, 120, 150):
    thm = mpf(thS)*pi/180
    yc = (asx + mpf('0.040')*mp.cos(pi - thm), mpf('0.040')*mp.sin(pi - thm))
    t0 = time.time()
    try:
        cb = ctx.coarse(yc, mpf('0.00025'), mpf('0.00025'))
        hi = mpf(hk.coarse_fine_hi(cb, ctx.Z_lo, 8))
        rho_hi = hi/(4*mpf('0.00025')**2)
        print('sdisk probe thS=%d: rho_hi=%.4e (%.0fs)' % (thS, rho_hi, time.time()-t0), flush=True)
        ctx.jrec(dict(part='sdiskprobe', thS=thS, rho_hi=str(rho_hi)))
    except SystemExit as e:
        print('sdisk probe thS=%d FAILED: %s' % (thS, str(e)[:60]), flush=True)
        ctx.jrec(dict(part='sdiskprobe_fail', thS=thS))
print('sdisk probes done', flush=True)
