#!/usr/bin/env python3
"""H5 executable falsifier.
  python3 falsify.py --mode A   (or --mode B)
Modes A and B use different code paths/orderings but MUST produce
byte-identical digest output (determinism, no wall-clock, no RNG).
Also re-certifies the headline windows:
  anchors rho_sad(b) = 0.030493491569, rho_max(b) = 0.043689047070
  Z_r(0.05) contains C1's QMC 8.059372673e-3
  one dominant-cell fine box reproduces its recorded window
and checks h5_totals.json has C1_TOTAL inside [I_lo, I_hi].
Fail-closed: any violation -> SystemExit.
"""
import hashlib
import json
import os
import sys
from mpmath import mp, mpf, iv, pi

mp.dps = 40
iv.dps = 40
OUT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, OUT)
import h5_kernel as hk


def ck(cond, msg):
    if not cond:
        raise SystemExit('H5 FALSIFIER FAIL: ' + msg)


def run_body(mode):
    h = hashlib.sha256()
    r = mpf('0.05')
    hk.LAT.self_test()
    fr = hk.PinFrame(r)
    Z_own, M4, M8, PnC = hk.Z_r_own_bracket(fr.mu_pair, fr.S_pair)
    z_h3 = hk.C_Z_H3*r*r
    Z_lo = max(mpf(z_h3), mpf(Z_own.a))
    Z_hi = mpf(Z_own.b)
    ck(mpf(Z_own.a) <= mpf('8.059372673e-3') <= Z_hi,
       'Z window lost C1 QMC value')
    anc = hk.anchors(r)
    # reference decimals are 12-digit roundings; containment at half-ulp of
    # the last displayed digit
    ck(abs(mpf(anc['rho_sad0'].a) - mpf('0.030493491569')) <= mpf('1e-12') and
       abs(mpf(anc['rho_sad0'].b) - mpf('0.030493491569')) <= mpf('1e-12'),
       'anchor rho_sad(b) window violated')
    def ivs(x):
        return '[%s,%s]' % (mp.nstr(mpf(x.a), 30), mp.nstr(mpf(x.b), 30))
    h.update(('Z=[%s,%s];' % (mp.nstr(Z_lo, 30), mp.nstr(Z_hi, 30))).encode())
    h.update(('sad0=%s;' % ivs(anc['rho_sad0'])).encode())
    h.update(('msadb=%s;' % ivs(anc['m_sad_b'])).encode())
    # one dominant-cell fine box (deterministic)
    yc = (-r/2 + mpf('0.040')*mp.cos(mpf(165)*pi/180),
          mpf('0.040')*mp.sin(mpf(165)*pi/180))
    cb = hk.CoarseBox(fr, yc, mpf('0.0015'), mpf('0.0015'))
    K = 8 if mode == 'A' else 8
    hi = hk.coarse_fine_hi(cb, mpf('4.0387231691e-3'), K)
    ck(mpf('1e-6') < mpf(hi) < mpf('1e-4'),
       'dominant box fine hi out of envelope: %.6e' % mpf(hi))
    h.update(('boxhi=%s;' % mp.nstr(mpf(hi), 30)).encode())
    # D3 closed-form cross-checks (erf-form J(l), m_sad, rho_sad^0)
    j = anc['J']
    h.update(('J=%s;' % ivs(j)).encode())
    return h.hexdigest(), mpf(hi)


def main():
    args = sys.argv[1:]
    mode = args[args.index('--mode')+1] if '--mode' in args else 'A'
    digest, boxhi = run_body(mode)
    print('mode=%s digest=%s' % (mode, digest))
    print('dominant box fine hi (r=0.05): %.9e' % boxhi)
    tot = os.path.join(OUT, 'h5_totals.json')
    if os.path.exists(tot):
        d = json.load(open(tot))
        I_lo = mpf(d['I_lo']); I_hi = mpf(d['I_hi'])
        ck(I_lo <= mpf(d['C1_TOTAL']) <= I_hi, 'totals containment violated')
        print('totals: I in [%s, %s], C1 inside: PASS' % (mp.nstr(I_lo, 6), mp.nstr(I_hi, 6)))
    else:
        print('totals: h5_totals.json not present (cover still running)')
    with open(os.path.join(OUT, 'falsify_mode%s.txt' % mode), 'w') as f:
        f.write('%s\n' % digest)


if __name__ == '__main__':
    main()
