import sys, time
sys.path.insert(0, '/mnt/agents/output/K3_SIDE24_LB/UPPER2D/H5_closure')
import h5_run
from mpmath import mpf, mp, iv
mp.dps = 40
iv.dps = 40
import h5_kernel as hk

r = mpf('0.05')
hk.LAT.self_test()
ctx = h5_run.Ctx(r, 0, 1, 'testcell')
ctx.frame = hk.PinFrame(r)
ctx.Z_lo = mpf('4.0387231691e-3')
ctx.Z_hi = mpf('1.3970321600e-2')
t0 = time.time()
hi = h5_run.bound_cell_fine(ctx, -r/2, 0.0, 30.0, mpf('0.0365'), mpf('0.045'), 7, 2, 12, 0)
print('th15_dl0.040 cell: hi=%.4e (%.0fs, %d boxes)' % (hi, time.time()-t0, ctx.boxes))
