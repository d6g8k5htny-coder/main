import sys, time, json
sys.path.insert(0, '/mnt/agents/output/K3_SIDE24_LB/UPPER2D/H5_closure')
import h5_run
from mpmath import mpf, mp, iv
mp.dps = 40
iv.dps = 40
import h5_kernel as hk

r = mpf('0.05')
hk.LAT.self_test()
ctx = h5_run.Ctx(r, 0, 1, 'refine')
ctx.rec = open('/mnt/agents/output/K3_SIDE24_LB/UPPER2D/H5_closure/h5_results_r0.05_refine.jsonl', 'a')
ctx.log = open('/mnt/agents/output/K3_SIDE24_LB/UPPER2D/H5_closure/recompute_detail.log', 'a')
ctx.frame = hk.PinFrame(r)
ctx.Z_lo = mpf('4.0387231691e-3')
ctx.Z_hi = mpf('1.3970321600e-2')
t0 = time.time()
# th15_dl0.066: delta in [0.058, 0.074], theta in [0, 30]; fine tiling
hi = h5_run.bound_cell_fine(ctx, -r/2, 0.0, 30.0, mpf('0.058'), mpf('0.074'), 10, 6, 12, 0)
c1 = mpf('4.519908852753140520726169190686520526596e-14')
ctx.jrec(dict(part='R1', cell='th15_dl0.066', hi=str(hi), boxes=ctx.boxes, c1=str(c1)))
print('recomputed th15_dl0.066: hi=%.6e (%d boxes, %.0fs)' % (hi, ctx.boxes, time.time()-t0))
