import sys, time, json, os
sys.path.insert(0, '/mnt/agents/output/K3_SIDE24_LB/UPPER2D/H5_closure')
import h5_run
from mpmath import mpf, mp, iv, pi
mp.dps = 40
iv.dps = 40
import h5_kernel as hk

r = mpf('0.05')
hk.LAT.self_test()
ctx = h5_run.Ctx(r, 0, 1, 'stitchref3')
RECF = '/mnt/agents/output/K3_SIDE24_LB/UPPER2D/H5_closure/h5_results_r0.05_stitchref3.jsonl'
ctx.rec = open(RECF, 'a')
ctx.log = open('/mnt/agents/output/K3_SIDE24_LB/UPPER2D/H5_closure/stitchref3_detail.log', 'a')
ctx.frame = hk.PinFrame(r)
ctx.Z_lo = mpf('4.0387231691e-3')
ctx.Z_hi = mpf('1.3970321600e-2')
amx = -r/2
asx = r/2
HALF = int(sys.argv[1])

done = set()
if os.path.exists(RECF):
    for l in open(RECF):
        try:
            d = json.loads(l)
        except Exception:
            continue
        if d.get('part') in ('stitchM', 'stitchS'):
            done.add((d['part'], d.get('d1'), d['sec']))

# top stitch sectors, finer tiling; min-per-sector across passes applies
MSECS = ((0, 12, 8), (2, 10, 8), (10, 10, 8))
SSECS = ((1, 10, 8), (9, 10, 8), (4, 10, 8), (6, 10, 8))
work = []
for (k, nth, ndl) in MSECS:
    work.append(('M', k, nth, ndl))
for (k, nth, ndl) in SSECS:
    work.append(('S', k, nth, ndl))
my = work[HALF::2]
for (kind, k, nth, ndl) in my:
    if kind == 'M':
        key = ('stitchM', None, k)
        t1 = -15 + 30*k
        t2 = t1 + 30
        anchor, d1, d2 = amx, mpf('0.074'), mpf('0.10')
    else:
        key = ('stitchS', '0.06', k)
        t1 = -18 + 36*k
        t2 = t1 + 36
        anchor, d1, d2 = asx, mpf('0.06'), mpf('0.105')
    if key in done:
        print('skip %s sec %s (banked)' % (kind, k), flush=True)
        continue
    t0 = time.time()
    hi = h5_run.bound_cell_fine(ctx, anchor, t1, t2, d1, d2, nth, ndl, 10, 0)
    print('refine3 %s sec %d: hi=%.4e (%.0fs)' % (kind, k, hi, time.time()-t0), flush=True)
    if kind == 'M':
        ctx.jrec(dict(part='stitchM', sec=k, hi=str(hi)))
    else:
        ctx.jrec(dict(part='stitchS', d1=str(d1), sec=k, hi=str(hi)))
print('refine3 half %d done' % HALF, flush=True)
