#!/usr/bin/env python3
"""
selftest_pin_transform.py -- fail-closed self-test for pin_transform.py
(H2 LIBRARY 2).

  P1  symbolic determinants of every change of basis: det V = -1 (ROW-MAJOR
      convention: V[i][j] = evaluation_i(basis_j)), det D_r = r^9,
      det R_r = r^4, and the chain (r^9)^{-1} * (-1) * r^4 = -r^{-5};
  P2  T_r = D_r^{-1} V^{-1} R_r equals the LPW candidate's displayed T_r
      exactly (symbolic in r);
  P3  det T_r = -r^{-5} symbolically;
  P4  u_r = T_r (b,0,0,b-r^3/6,0,0)^T = (b-r^3/12, -r^2/4, 0,0,0, 1/3)^T
      symbolically (r, b symbols);
  P5  typed pair-Palm basis: det B_r = r^{-5}, C_r = T_r B_r^{-1} has
      det -1, and T_r = C_r B_r;
  P6  Hermite exactness: T_r P6(p) = c for a general symbolic cubic
      p = sum_j c_j basis_j (the trapezoidal correction is pinned by THIS
      test, since det B_r is unchanged without it);
  P7  convention test: the COLUMN-major V has the same determinant -1 but
      does NOT satisfy the formula (explicit negative control);
  P8  numeric T_r == symbolic T_r at rational rungs (mpf and iv);
  P9  numeric u_r at rungs {0.5, 0.25, 0.1, 0.025, 1e-5} (mpf and iv);
  P10 U_0 limit: Gamma_U(r) = T_r Gamma_P T_r^T (cov_exact pin covariance)
      converges to the endpoint ten-jet covariance block built from exact
      torus moments, envelope |.|_max <= 200 r^2 at r = 1e-3, 1e-4 with
      quadratic ratio; det Gamma_U > 0 and eigenfloor evidence > 0.12;
  P11 certified inverse: normalized frame certified at r = 1e-5 (residual
      < 1e-50, kappa_cert*eps <= 1e-8); RAW frame at r = 1e-5 REFUSED by the
      guard (mutation-sensitive); unguarded inspection certificate itself
      condemns the raw frame (kappa_cert*consumer_eps > CERT_TOL);
  P12 mutations (subprocess, normal AND -O): transpose_T, cubic_sign,
      drop_trapezoid, raw_inverse_unsafe each rejected with nonzero exit.

Usage: python selftest_pin_transform.py [MUTATION=<name>]
Deterministic; byte-identical transcript under python and python -O;
no bare asserts; ck() fail-closed (SystemExit).
"""
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import sympy as sp
from mpmath import mp, mpf, iv

import cov_exact as ce
import pin_transform as pt


def ck(cond, msg="check"):
    if not cond:
        print("CHECK FAILED:", msg)
        raise SystemExit(1)
    print("[ok]", msg)


def nstr(x, n=6):
    return mp.nstr(x, n)


MUT = None
for a in sys.argv[1:]:
    if a.startswith("MUTATION="):
        MUT = a.split("=", 1)[1]
if MUT is not None and MUT not in pt.MUTATIONS:
    print("CHECK FAILED: unknown mutation", MUT)
    raise SystemExit(1)

r, b = sp.symbols('r b')
print("selftest_pin_transform.py -- H2 LIBRARY 2 self-test")
if MUT:
    print("MUTATION ACTIVE:", MUT)

# ------------------------------------------------------------------ P1
print("-- P1 change-of-basis determinants (symbolic)")
V = pt.matrix_V('row-major')
ck(V.det() == -1, "P1 det V = -1 exactly (row-major convention)")
ck(sp.factor(pt.matrix_D(r).det()) == r**9, "P1 det D_r = r^9")
ck(sp.factor(pt.matrix_R(r).det()) == r**4, "P1 det R_r = r^4")
chain = sp.simplify((r**9) ** -1 * (-1) * r**4 + r**-5)
ck(chain == 0, "P1 chain det(D^{-1}) det(V^{-1}) det(R) = r^{-9}*(-1)*r^4 = -r^{-5}")

# ------------------------------------------------------------------ P2
print("-- P2 derived T_r == displayed T_r (mutation-sensitive)")
T = pt.matrix_T(r, MUT)
ck(sp.simplify(T - pt.displayed_T(r)) == sp.zeros(6),
   "P2 T_r = D_r^{-1} V^{-1} R_r equals the candidate's displayed T_r exactly")

# ------------------------------------------------------------------ P3
print("-- P3 det T_r = -r^{-5} (mutation-sensitive for cubic_sign)")
ck(sp.simplify(T.det() + r**-5) == 0, "P3 det T_r = -r^{-5} symbolically")

# ------------------------------------------------------------------ P4
print("-- P4 u_r identity (mutation-sensitive)")
u = pt.u_symbolic(r, b, MUT)
expect = sp.Matrix([b - r**3/12, -r**2/4, 0, 0, 0, sp.Rational(1, 3)])
ck(sp.simplify(u - expect) == sp.zeros(6, 1),
   "P4 u_r = (b-r^3/12, -r^2/4, 0, 0, 0, 1/3)^T symbolically")

# ------------------------------------------------------------------ P5
print("-- P5 typed pair-Palm basis factorization")
Bm = pt.matrix_B(r)
ck(sp.factor(Bm.det()) == r**-5, "P5 det B_r = r^{-5} (typed pair-Palm basis)")
Cm = pt.matrix_C(r)
ck(sp.factor(Cm.det()) == -1, "P5 det C_r = -1 (corrected basis -> Hermite-normalized)")
ck(sp.simplify(Cm * Bm - pt.matrix_T(r)) == sp.zeros(6), "P5 T_r = C_r B_r exactly")

# ------------------------------------------------------------------ P6
print("-- P6 Hermite exactness (coefficient recovery through the cubic span)")
cs = sp.symbols('c0:6')
p = sum(cs[j] * pt.BASIS[j] for j in range(6))
P6p = sp.Matrix(pt._evals_of(p, -r/2) + pt._evals_of(p, r/2))
rec = sp.simplify(pt.matrix_T(r, MUT) * P6p)
ck(rec == sp.Matrix(cs),
   "P6 T_r P6(p) = c exactly for every p in span(1,x,y,x^2,xy,x^3) "
   "(pins the trapezoidal correction term)")

# ------------------------------------------------------------------ P7
print("-- P7 row-major vs column-major convention (explicit negative control)")
Vcm = pt.matrix_V('column-major')
ck(Vcm == V.T and Vcm.det() == -1,
   "P7 column-major V is the transpose and has the SAME det -1 (det cannot pin the convention)")
Tcm = sp.simplify(pt.matrix_D(r) ** -1 * Vcm ** -1 * pt.matrix_R(r))
ck(sp.simplify(Tcm - pt.displayed_T(r)) != sp.zeros(6),
   "P7 column-major V does NOT satisfy T_r = D_r^{-1} V^{-1} R_r "
   "(the formula holds with the ROW-major V only -- convention is load-bearing)")

# ------------------------------------------------------------------ P8
print("-- P8 numeric T_r == symbolic T_r at rational rungs")
RUNGS = [mpf('0.5'), mpf('0.25'), mpf('0.1'), mpf('0.025'), mpf('1e-5')]
Ts = pt.matrix_T(r)
for rn in RUNGS:
    rq = sp.Rational(str(rn))
    Texact = [[mpf(int(c.p)) / int(c.q) for c in row] for row in
              (Ts.subs(r, rq).tolist())]
    for mode in ('mpf', 'iv'):
        Tn = pt.matrix_T_num(rn, mode, MUT)
        if MUT is None:
            mx = mpf(0)
            nbad = 0
            for i in range(6):
                for j in range(6):
                    v = Tn[i][j]
                    if mode == 'mpf':
                        mx = max(mx, abs(v - Texact[i][j]))
                    else:
                        if not (v.a <= Texact[i][j] <= v.b):
                            nbad += 1
                        mx = max(mx, abs((mpf(v.a) + mpf(v.b)) / 2 - Texact[i][j]),
                                 mpf(v.b) - mpf(v.a))
            ck(nbad == 0, "P8 iv entries all enclose the exact symbolic values at r=%s (%d violations)"
               % (nstr(rn, 4), nbad))
            ck(mx < mpf('1e-80'),
               "P8 numeric==symbolic T at r=%s (%s), max dev/width %s" % (nstr(rn, 4), mode, nstr(mx, 3)))
        else:
            print("   (mutation run: P8 numeric check performed with mutated T at r=%s, %s)"
                  % (nstr(rn, 4), mode))

# ------------------------------------------------------------------ P9
print("-- P9 numeric u_r at rungs")
for rn in RUNGS:
    p6 = [mpf(6) / 5, 0, 0, mpf(6) / 5 - rn**3 / 6, 0, 0]
    ue = [mpf(6) / 5 - rn**3 / 12, -rn**2 / 4, 0, 0, 0, mpf(1) / 3]
    um = pt.apply_T(p6, rn, 'mpf', MUT)
    dm = max(abs(a - c) for a, c in zip(um, ue))
    ui = pt.apply_T(p6, rn, 'iv', MUT)
    # ue is computed by a different (mpf) rounding path than the iv expression;
    # require agreement within half-width plus rounding slack.
    def _ok(a, c):
        lo, hi = mpf(a.a), mpf(a.b)
        return lo - mpf('1e-95') <= c <= hi + mpf('1e-95')
    cont = all(_ok(a, c) for a, c in zip(ui, ue))
    wid = max(mpf(a.b) - mpf(a.a) for a in ui)
    if MUT is None:
        ck(dm < mpf('1e-70'), "P9 u_r numeric at r=%s (mpf, max dev %s)" % (nstr(rn, 4), nstr(dm, 3)))
        ck(cont and wid < mpf('1e-70'),
           "P9 u_r numeric at r=%s (iv encloses, max width %s)" % (nstr(rn, 4), nstr(wid, 3)))
    else:
        print("   (mutation run: P9 at r=%s: mpf max dev %s)" % (nstr(rn, 4), nstr(dm, 3)))

# ------------------------------------------------------------------ P10
print("-- P10 U_0 limit and endpoint covariance (cov_exact integration)")
JET6 = [(0, 0), (1, 0), (0, 1), (2, 0), (1, 1), (3, 0)]
CSCALE = [mpf(1), 1, 1, mpf(1) / 2, 1, mpf(1) / 6]
G0 = [[CSCALE[i] * CSCALE[j] * ce.cov(JET6[i], JET6[j], 0, 0) for j in range(6)]
      for i in range(6)]
devs = []
for rn in (mpf('1e-3'), mpf('1e-4')):
    G = pt.pin_covariance(rn)
    GU = pt.transform_cov(G, rn, 'mpf', MUT)
    mx = max(abs(GU[i][j] - G0[i][j]) for i in range(6) for j in range(6))
    devs.append(mx)
    if MUT is None:
        ck(mx <= 200 * rn**2, "P10 |Gamma_U(r)-Gamma_0|_max = %s <= 200 r^2 at r=%s"
           % (nstr(mx, 3), nstr(rn, 3)))
if MUT is None:
    ratio = devs[0] / devs[1]
    ck(25 <= ratio <= 400, "P10 quadratic convergence ratio %s in [25,400]" % nstr(ratio, 4))
    print("   endpoint deviations:", [nstr(d, 3) for d in devs])
for rn in RUNGS:
    G = pt.pin_covariance(rn)
    GU = pt.transform_cov(G, rn, 'mpf', MUT)
    M = mp.matrix(6, 6)
    for i in range(6):
        for j in range(6):
            M[i, j] = GU[i][j]
    ev = mp.eigsy(M)[0]
    if MUT is None:
        ck(min(ev) > 0, "P10 Gamma_U positive definite at r=%s (lambda_min evidence %s)"
           % (nstr(rn, 4), nstr(min(ev), 6)))
        if rn == mpf('1e-5'):
            ck(min(ev) > mpf('0.12'),
               "P10 eigenfloor evidence lambda_min(Gamma_U(1e-5)) = %s > 0.12 "
               "(consistent with the certified uniform floor 0.123809288439 on [0,1e-5]; "
               "the certificate of record is W6's)" % nstr(min(ev), 12))
    else:
        print("   (mutation run: P10 eigsy at r=%s: min %s)" % (nstr(rn, 4), nstr(min(ev), 6)))

# ------------------------------------------------------------------ P11
print("-- P11 certified inverses (normalized vs raw frame)")
r_small = mpf('1e-5')
G = pt.pin_covariance(r_small, mode='iv')
Ginv, cert = pt.certified_inverse(G, r_small, 'normalized', mutation=None)
ck(cert['kappa_eps'] <= pt.CERT_TOL,
   "P11 normalized frame certified at r=1e-5: kappa_cert*eps = %s <= 1e-8 (kappa = %s, lambda_min >= %s)"
   % (nstr(cert['kappa_eps'], 3), nstr(cert['kappa_cert'], 4), nstr(cert['lambda_min_lower'], 6)))
def _prod_resid(Gg, Gi):
    res = mpf(0)
    for i in range(6):
        for j in range(6):
            s = iv.mpf(0)
            for k in range(6):
                s = s + Gg[i][k] * Gi[k][j]
            mid = (mpf(s.a) + mpf(s.b)) / 2
            res = max(res, abs(mid - (1 if i == j else 0)), mpf(s.b) - mpf(s.a))
    return res

def _frob_mid(Gg):
    def mid(x):
        if hasattr(x, 'a'):
            return (mpf(x.a) + mpf(x.b)) / 2
        return mpf(x)
    return mp.sqrt(sum(mid(x) ** 2 for row in Gg for x in row))

# The certified raw inverse is huge (entries ~ r^{-6}); its certified entry
# error is the Neumann bound err mapped back through T (entries up to 2/r^3).
# The honest check: the observed product residual is covered by the
# certificate's own prediction 10 * ||G||_F * 6 * max|T|^2 * err.
for rn, ctag in ((r_small, "1e-5"), (mpf('0.025'), "0.025")):
    Gg = pt.pin_covariance(rn, mode='iv')
    Gi, cf = pt.certified_inverse(Gg, rn, 'normalized', mutation=None)
    res = _prod_resid(Gg, Gi)
    Tn = pt.matrix_T_num(rn, 'mpf')
    tmax = max(abs(Tn[i][j]) for i in range(6) for j in range(6))
    bound = 10 * _frob_mid(Gg) * 6 * tmax**2 * cf['err_F']
    ck(res <= bound,
       "P11 G*Ginv residual %s covered by the certificate prediction %s at r=%s "
       "(raw-inverse entries ~ r^{-6}; entry error is the Neumann bound mapped through T)"
       % (nstr(res, 3), nstr(bound, 3), ctag))
# raw frame: the guard must REFUSE at r = 1e-5 (mutation-sensitive)
try:
    pt.certified_inverse(G, r_small, 'raw', mutation=MUT)
    ck(False, "P11 raw-frame inverse at r=1e-5 was NOT refused by the guard "
              "(nearly singular raw covariance treated as safe without normalization)")
except pt.CertificationError:
    print("[ok] P11 raw-frame guarded inverse refused at r=1e-5 (CertificationError)")
# the unguarded inspection certificate itself condemns the raw frame
_, cert_raw = pt.certified_inverse(G, r_small, 'raw', guard=False, mutation=MUT)
ck(cert_raw['kappa_eps'] > pt.CERT_TOL,
   "P11 certificate condemns the raw frame at r=1e-5: kappa_cert*eps = %s > 1e-8 (kappa = %s)"
   % (nstr(cert_raw['kappa_eps'], 3), nstr(cert_raw['kappa_cert'], 3)))
# at a moderate rung the raw frame IS safe at float64 consumer precision: the
# guard adapts quantitatively rather than blanket-banning (kappa ~ r^{-6.1}:
# measured 1.66e32 at r=1e-5, so the raw frame crosses CERT_TOL near r ~ 0.1)
G50 = pt.pin_covariance(mpf('0.5'), mode='iv')
_, cert50 = pt.certified_inverse(G50, mpf('0.5'), 'raw', mutation=MUT)
ck(cert50['kappa_eps'] <= pt.CERT_TOL,
   "P11 raw frame certified at r=0.5 (kappa*eps = %s): the guard is quantitative, not a blanket ban"
   % nstr(cert50['kappa_eps'], 3))
G25 = pt.pin_covariance(mpf('0.025'), mode='iv')
try:
    pt.certified_inverse(G25, mpf('0.025'), 'raw', mutation=MUT)
    ck(False, "P11 raw-frame inverse at r=0.025 was NOT refused (kappa*eps ~ 7e-5 > 1e-8)")
except pt.CertificationError:
    print("[ok] P11 raw-frame guarded inverse refused at r=0.025 as well (kappa*eps ~ 7e-5)")

# ------------------------------------------------------------------ P12
print("-- P12 mutation rejection (subprocess, normal AND -O)")
if MUT is None:
    for mut in pt.MUTATIONS:
        for opt in (False, True):
            cmd = [sys.executable] + (["-O"] if opt else []) + [
                os.path.join(HERE, "selftest_pin_transform.py"), "MUTATION=" + mut]
            p = subprocess.run(cmd, capture_output=True, text=True)
            ck(p.returncode != 0, "P12 mutation %s rejected under %s (rc=%d)"
               % (mut, "-O" if opt else "normal", p.returncode))
            ck("CHECK FAILED" in p.stdout, "P12 mutation %s produced a fail line under %s"
               % (mut, "-O" if opt else "normal"))
else:
    print("   (mutation run in progress: MUTATION=%s; subprocess section skipped)" % MUT)

print("")
if MUT is None:
    print("SELFTEST_PIN_TRANSFORM: PASS (all checks P1-P12 fail-closed; both-mode byte-identical design)")
else:
    print("MUTATION %s REACHED THE END WITHOUT REJECTION (must never print)" % MUT)
    raise SystemExit(1)
