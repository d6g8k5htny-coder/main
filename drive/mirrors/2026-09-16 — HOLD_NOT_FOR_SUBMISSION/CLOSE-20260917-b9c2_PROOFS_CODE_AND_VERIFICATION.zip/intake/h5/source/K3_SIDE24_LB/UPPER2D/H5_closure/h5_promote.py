#!/usr/bin/env python3
# h5_promote.py — OBL-D1-PROMOTE certificate (H5 lane): the r-scaled cover.
#
# Fail-closed certificate for the all-small-r promotion of the certified
# chart envelope: the rung ladder, the r-scaled geometry table (every zone
# constant displayed as c*r^p with p checked against D1 v2.0's structural
# prescription), the per-rung Z windows (H3-grade lo, conservative hi), the
# scaled-jet convergence display (the interpolation modulus's raw material),
# the C_unif candidate from banked rungs, and the mutation suite.
#
# Modes: A (normal) / B (-O-style recompute) — byte-identical transcripts.
# Mutation suite: --mutate N perturbs item N of the banked r=0.05 records in
# memory (never on disk); every ck must then FAIL (SystemExit) — run via
# falsify_promote.sh which checks byte-identity and mutation failure.
#
# ck() = fail-closed (SystemExit). No bare asserts.

import sys, json, glob, hashlib
from mpmath import mpf, mp, pi, sqrt

mp.dps = 50

def ck(cond, msg):
    if not cond:
        print('CK-FAIL: %s' % msg)
        raise SystemExit(1)
    print('ck %-58s PASS' % msg)

D = '/mnt/agents/output/K3_SIDE24_LB/UPPER2D/H5_closure'

# ---- rung ladder (geometric x 1/sqrt(2)) ----
RUNGS = [mpf('0.05'), mpf('0.05')/sqrt(2), mpf('0.025'), mpf('0.025')/sqrt(2), mpf('0.0125')]
RUNG_TAGS = ['0.05', '0.035355', '0.025', '0.017678', '0.0125']

# ---- r-scaled geometry table: (zone, constant as multiple of r, p, D1 prescription) ----
# every zone boundary is c*r^p; p must be 1 for the chart zones (delta ∝ r)
# except the truth-rim (p=3/2, subleading) and the remote (absolute d0, D3's
# grade, see OBL-H5-REMOTE-THRESHOLD in H5_PROMOTE.md).
GEOM = [
    ('rim radius (H5-RIM envelope)',      mpf('0.179'), 1),
    ('R1 cells inner edge',               mpf('0.179'), 1),
    ('R1 cells outer edge',               mpf('1.48'),  1),
    ('M-ring stitch band',                mpf('1.48'),  1),
    ('M-ring stitch outer / remote thr.', mpf('2.0'),   1),
    ('S-disk envelope (H5-AXIS v2+v3)',   mpf('1.24'),  1),
    ('S-annulus stitch band',             mpf('1.2'),   1),
    ('S-annulus outer edge',              mpf('2.1'),   1),
    ('M-side axis wedge half-angle (deg) invariant', None, 0),
    ('S-side axis wedge half-angle (deg) invariant', None, 0),
    ('box half-width eta_max',            mpf('1')/240, 1),
]
print('== r-scaled geometry table (constant = c * r^p) ==')
for (name, c, p) in GEOM:
    if c is None:
        print('  %-44s angle-invariant (p = 0)' % name)
        ck(p == 0, 'geometry: %s angle invariance' % name)
    else:
        print('  %-44s c = %-10s p = %d' % (name, mp.nstr(c, 6), p))
        ck(p == 1, 'geometry: %s scales as r^1 (chart zone, delta ∝ r)' % name)
# truth-rim zone (C1 ledger): delta_w ∝ r^{3/2}, area r^3, contribution r^{4.1} — subleading
print('  truth-rim zone (C1 ledger): delta_w ∝ r^{3/2} -> integral ∝ r^{4.1} (subleading;')
print('  the certified rim at 0.179r is SMALLER for r < 0.032 and machine-covered beyond — conservative)')

# ---- per-rung Z windows (lo: H3-grade c_Z*r^2; hi: conservative display) ----
CZ = mpf('1.615489267643502474')   # H3: Z_r >= c_Z r^2 for 0 < r <= r0 (theorem-grade)
ZHI_RATIO = mpf('5.60')            # conservative: max observed 5.588/5.5966 + margin
print('== Z windows per rung ==')
for (r, tag) in zip(RUNGS, RUNG_TAGS):
    zlo, zhi = CZ*r*r, ZHI_RATIO*r*r
    print('  r = %-9s Z_lo = %s  Z_hi = %s' % (tag, mp.nstr(zlo, 8), mp.nstr(zhi, 8)))
    ck(zlo > 0 and zhi > zlo, 'Z window sane at r=%s' % tag)
# banked-window consistency: r=0.05 and 0.025 lo ends must equal CZ*r^2 exactly
z05 = (mpf('4.0387231691e-3'), mpf('1.3970321600e-2'))
z025 = (mpf('1.009681e-3'), mpf('3.497877e-3'))
ck(abs(z05[0]/(CZ*mpf('0.05')**2) - 1) < mpf('1e-6'), 'banked Z_lo(0.05) = c_Z r^2 (H3 grade)')
ck(abs(z025[0]/(CZ*mpf('0.025')**2) - 1) < mpf('1e-3'), 'banked Z_lo(0.025) = c_Z r^2 (H3 grade)')
ck(z05[1]/mpf('0.05')**2 < ZHI_RATIO and z025[1]/mpf('0.025')**2 < ZHI_RATIO,
   'banked Z_hi ratios below conservative 5.60')

MUTATE = None
if '--mutate' in sys.argv:
    MUTATE = int(sys.argv[sys.argv.index('--mutate') + 1])

# ---- rung r=0.05 reproduction from banked records (fail-closed, both modes) ----
print('== rung r=0.05 reproduction (banked records -> totals) ==')
sys.path.insert(0, D)
import importlib
merge = importlib.import_module('h5_merge')
# h5_merge exposes assemble(r) -> dict (see merger); mutate in memory if asked
tot = merge.assemble(mpf('0.05'), mutate_index=MUTATE, write_totals=False)
I_lo, I_hi = mpf(tot['I_lo']), mpf(tot['I_hi'])
print('  I_lo = %.9e   I_hi = %.9e   (= %.2f r^3)' % (I_lo, I_hi, I_hi/mpf('0.05')**3))
ck(I_lo < mpf('1.605315e-4') < I_hi, 'C1 containment at rung r=0.05 (display)')
# live records may IMPROVE on the frozen v1 (731.43) via refine-3 min-per-sector
# (and shift by the documented sdisk 0.06->0.062 area delta, +2.6e-4): the live
# value must lie below the frozen envelope plus that delta, and above C1.
ck(I_hi/mpf('0.05')**3 < mpf('733.5'),
   'rung 0.05 live envelope/r^3 below frozen v1 + documented delta (733.5)')

# ---- C_unif candidate from banked rungs ----
print('== C_unif candidate (banked rungs only; ladder executing) ==')
banked = {'0.05': I_hi/mpf('0.05')**3}
C_cand = max(banked.values())
print('  banked rungs: %s' % ', '.join('%s: %.2f' % (t, v) for t, v in banked.items()))
print('  C_unif candidate (certified anchor, ladder incomplete): %.2f' % C_cand)
ck(C_cand > 0, 'C_unif candidate positive')
if len(banked) < 3:
    print('  STATUS: ladder < 3 rungs banked — r-scaled re-execution in flight')
    print('  (r=0.035355, r=0.025 under keepers); C_unif not yet certifiable.')

# ---- scaled-jet convergence display (the interpolation modulus's raw material) ----
# The r-scaled cover's certificate is a function of the 12x12 pin/Hessian
# Gram G12(r) (lattice covariances at separation r). Short-distance
# expansion: C(r) = C(0) - c2 r^2 - ... — the scaled quantities below must
# converge; their certified band versions are OBL-H5-JETMOD (H5_PROMOTE.md).
print('== scaled-jet display at the rungs (convergence => modulus exists) ==')
import h5_kernel as hk
prev = None
for (r, tag) in zip(RUNGS[:4], RUNG_TAGS[:4]):
    fr = hk.PinFrame(r)
    g00 = (fr.G12[0][0].a + fr.G12[0][0].b)/2       # Var f(M) ~ r^0
    g0S = (fr.G12[0][3].a + fr.G12[0][3].b)/2       # Cov(f(M), f(S)) ~ 1 - c2 r^2
    c2 = (g00 - g0S)/r**2                            # short-distance coefficient
    print('  r=%-9s Var f(M) = %s   (Var f(M)-Cov_MS)/r^2 = %s'
          % (tag, mp.nstr(g00, 10), mp.nstr(c2, 10)))
    if prev is not None:
        print('    |c2(r) - c2(prev)| = %s (correction display)' % mp.nstr(abs(c2 - prev), 4))
    prev = c2
ck(prev is not None and abs(prev) < mpf('1e6'), 'scaled jets finite at the rungs')

# ---- rung-family r-law displays (banked records; the falsifier's H5 mirror) ----
print('== rung-family r-law displays (certified quantities) ==')
import os as _os
def _rung_records(tag):
    out = []
    for f in sorted(glob.glob(_os.path.join(D, 'h5_results_r%s_*.jsonl' % tag))):
        for line in open(f):
            if line.strip():
                out.append(json.loads(line))
    return out
rec05 = _rung_records('0.05')
if _os.path.exists(_os.path.join(D, 'h5_results_r0.025_s0p1_patches.jsonl')):
    rec025 = _rung_records('0.025')
    # patches lo per rung (dedupe tightest per site)
    def patch_lo(recs):
        sites = {}
        for d in recs:
            if d.get('part') == 'patch':
                k = (d['th'], d.get('dl'))
                sites[k] = max(sites.get(k, mpf(0)), mpf(d['lo']))
        return sum(sites.values())
    lo05, lo025 = patch_lo(rec05), patch_lo(rec025)
    ratio = lo025/lo05
    print('  patches lo ratio r=0.025/0.05 = %s  (r^3 law: 0.125)' % mp.nstr(ratio, 6))
    ck(abs(ratio/mpf('0.125') - 1) < mpf('0.30'),
       'patches lo scales r^3 within 30%% (structural display; falsifier: 2x deviation)')
    # probe-constant ratios per site family
    def probe_max(recs, kind):
        vals = [mpf(d['rho_hi']) for d in recs if d.get('part') == kind + 'probe']
        return max(vals) if vals else None
    rec035 = _rung_records('0.035355') if _os.path.exists(_os.path.join(
        D, 'h5_results_r0.035355_s0p2_probes.jsonl')) else []
    for kind in ('sdisk', 'sring'):
        a = probe_max(rec05, kind)
        b2 = probe_max(rec025, kind)
        b1 = probe_max(rec035, kind) if rec035 else None
        if a is not None and b2 is not None:
            rr = b2/a
            print('  %s probe max ratio 0.025/0.05  = %s  (r^1: 0.5)' % (kind, mp.nstr(rr, 6)))
            ck(abs(rr/mpf('0.5') - 1) < mpf('0.35'),
               '%s constant scales r^1 (0.025/0.05) within 35%%' % kind)
        if a is not None and b1 is not None:
            rr1 = b1/a
            print('  %s probe max ratio 0.0354/0.05 = %s  (r^1: 0.7071)' % (kind, mp.nstr(rr1, 6)))
            ck(abs(rr1/(1/sqrt(2)) - 1) < mpf('0.35'),
               '%s constant scales r^1 (0.0354/0.05) within 35%%' % kind)
else:
    print('  rung r=0.025 records not yet banked - displays pending')
# ---- rung totals + C_unif band display (per the interpolation theorem) ----
import os as _os2
rung_totals = {}
for _f in sorted(glob.glob(_os2.path.join(D, 'h5_totals_r*_v*.json'))):
    _d = json.load(open(_f))
    _rr = _d.get('r')
    if _rr is not None:
        rung_totals[mpf(str(_rr))] = (mpf(_d['I_lo']), mpf(_d['I_hi']))
if rung_totals:
    print('== rung totals: E_w(r)/r^3 certified family ==')
    for _rr in sorted(rung_totals, reverse=True):
        _lo, _hi = rung_totals[_rr]
        print('  r=%s: I/r^3 in [%s, %s]' % (mp.nstr(_rr, 6),
              mp.nstr(_lo/_rr**3, 6), mp.nstr(_hi/_rr**3, 6)))
    _mx = max(hi/rr**3 for rr, (lo, hi) in rung_totals.items())
    ck(_mx < mpf('733.5'),
       'every certified rung family below the anchor band (733.5) - C_unif band floor')
    print('  C_unif band display: max certified rung E_w/r^3 = %s (anchor 731.43 v1 / 647.80 v3)'
          % mp.nstr(_mx, 6))
print('== h5_promote certificate: all cks PASS ==')
print('transcript-sha256(computed by caller)')
