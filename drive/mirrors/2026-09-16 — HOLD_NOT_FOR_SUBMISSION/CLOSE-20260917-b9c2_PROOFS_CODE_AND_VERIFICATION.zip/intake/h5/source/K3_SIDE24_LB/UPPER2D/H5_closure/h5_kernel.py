# H5 closure — theorem-grade interval evaluation of the raw alpha-lane integral
#   I_raw(r) = \int_{chart region} rho_w(y) dy,   rho_w = (pgrad/Z_r) * I(y),
#   I(y) = \int_{b-ell}^{b} phi(v; mu_t, s_t^2) g(v) dv,
#   g(v) = E[ |det H_M| 1{max} |det H_S| 1{sad} |det H_y| 1{sad} | pins, grad f(y)=0, f(y)=v ].
#
# Everything on the certified path is interval arithmetic (mpmath iv) with
# certified spectral tails (H2's cov_exact for derivative orders <= 8 and a
# cross-checked twin k1_high for orders 9..18), Neumann-certified pin
# conditioning (H2's pin_transform), Taylor-model (TM) propagation of the
# 18-jet conditioning over spatial boxes, Isserlis (Wick) moment polynomials
# in Delta = v - mu_t, margin/Mills chamber-exclusion bounds, and composite
# interval quadrature over the retained v-window with doubling tail bands.
#
# Fail-closed discipline: every certificate is enforced by ck() which raises
# SystemExit; no bare asserts are used for control flow anywhere.
#
# Frozen inputs (hash-pinned):
#   C1_ALPHA_INTENSITY.md      body ca2c02b8...
#   LEAD_INTENSITY_DERIVATION.md body 729644f3...
#   cov_exact.py               f08c1c5f...
#   pin_transform.py           c6988ac7...

import os, sys, hashlib
from mpmath import mp, mpf, iv, pi

_H2 = '/mnt/agents/output/K3_SIDE24_LB/UPPER2D/H2_foundations'
if _H2 not in sys.path:
    sys.path.insert(0, _H2)
import cov_exact as ce
import pin_transform as pt

B = mpf('1.2')          # pin level
DER = {'f': (0, 0), 'fx': (1, 0), 'fy': (0, 1), 'fxx': (2, 0), 'fxy': (1, 1), 'fyy': (0, 2)}
JETS_MS = ('f', 'fx', 'fy')
JETS_H = ('fxx', 'fxy', 'fyy')


def ck(cond, msg):
    """Fail-closed certificate check (deliberately not a bare assert)."""
    if not cond:
        raise SystemExit('H5_CERTIFICATE_FAILURE: %s' % msg)
    return True


# ---------------------------------------------------------------- lattice / kernel
class Lattice:
    """Spectral lattice sums with certified tails, any derivative order.

    For orders <= 8 this is byte-for-byte ce.e_sum/ce.k1 (H2, hash-pinned);
    for orders 9..18 it is a twin implementation with the same geometric tail
    argument, cross-checked against ce.k1 at orders <= 8 in self_test().
    """
    def __init__(self):
        self.h = iv.pi/12
        self.J = int(mp.ceil(mpf(30)/mpf(pi/12))) + 1
        h = self.h
        self.ks = [j*h for j in range(-self.J, self.J+1)]
        self.ws = [iv.exp(-k*k/2) for k in self.ks]
        self.Z1 = sum(self.ws, iv.mpf(0))
        self._tail_cache = {}
        self._lam_cache = {}

    def tail(self, n):
        if n in self._tail_cache:
            return self._tail_cache[n]
        J0 = self.J + 1
        k0 = J0*self.h
        rho = iv.exp(-(2*J0+1)*self.h*self.h/2)*(1 + 1/iv.mpf(J0))**n
        ck(rho.b < 1, 'lattice tail contraction rho<1 failed for n=%d' % n)
        t0 = iv.exp(-k0*k0/2)*k0**n
        tau = 2*t0/(1-rho)/self.Z1.a
        self._tail_cache[n] = tau
        return tau

    def lambda_q(self, q):
        """Certified upper bound on sup_s |K1^{(q)}(s)| = (1/Z) sum w k^q."""
        if q in self._lam_cache:
            return self._lam_cache[q]
        tot = sum((wj*(kj**q) for kj, wj in zip(self.ks, self.ws)), iv.mpf(0))
        lam = tot/self.Z1.a + self.tail(q)
        self._lam_cache[q] = lam
        return lam

    def k1(self, n, s):
        """K1^{(n)}(s), interval-enclosed, any 0 <= n <= 18."""
        ck(0 <= n <= 18, 'k1 order %d out of certified range' % n)
        sv = iv.mpf(s)
        if n % 2 == 0:
            tot = sum((wj*(kj**n)*iv.cos(kj*sv) for kj, wj in zip(self.ks, self.ws)), iv.mpf(0))
            val = tot/self.Z1
            if n % 4 == 2:
                val = -val
        else:
            tot = sum((wj*(kj**n)*iv.sin(kj*sv) for kj, wj in zip(self.ks, self.ws)), iv.mpf(0))
            val = tot/self.Z1
            if (n+1) % 4 == 2:
                val = -val
        return val + iv.mpf([-self.tail(n), self.tail(n)])

    def self_test(self):
        """Cross-check the twin against hash-pinned ce.k1 at orders <= 8."""
        for n in range(9):
            for s in (mpf(0), mpf('0.013'), mpf('-0.331'), mpf('2.7'), mpf('12.5')):
                a = ce.k1(n, s, 'spectral', 'iv')
                b = self.k1(n, s)
                lo = max(mpf(a.a), mpf(b.a)); hi = min(mpf(a.b), mpf(b.b))
                ck(lo <= hi, 'k1 twin disagreement vs cov_exact at n=%d s=%s' % (n, mp.nstr(s, 4)))
                ck(float(mpf(b.b) - mpf(b.a)) < 1e-30, 'k1 twin width too large at n=%d' % n)
        return True


LAT = Lattice()

# ---------------------------------------------------------------- Taylor models
# A Taylor model is P(u1,u2) + R: a bivariate polynomial of total degree <= TD
# with interval coefficients, plus a certified remainder |rho(u)| <= R for all
# |u_i| <= ETAi.  ETA1, ETA2 are set per spatial box before the chain runs.
# Coefficients are iv.mpf; the Python float 0 denotes an exactly-zero coeff.
TD = 5
ETA1 = iv.mpf(0)
ETA2 = iv.mpf(0)


def _build_mon():
    global _MON, _MIDX, NMON, _MTAB, _DROP
    _MON = [(a, b) for d in range(TD+1) for a in range(d, -1, -1) for b in [d - a]]
    _MIDX = {m: k for k, m in enumerate(_MON)}
    NMON = len(_MON)
    _MTAB = [[] for _ in range(NMON)]
    _DROP = []
    for _i in range(NMON):
        for _j in range(NMON):
            m = (_MON[_i][0]+_MON[_j][0], _MON[_i][1]+_MON[_j][1])
            if m[0]+m[1] <= TD:
                _MTAB[_MIDX[m]].append((_i, _j))
            else:
                _DROP.append((_i, _j))


def _set_TD(td):
    global TD
    if td != TD:
        TD = td
        _build_mon()


_build_mon()
_ETA_POW = None


def _set_eta(e1, e2, td=None):
    global ETA1, ETA2, _ETA_POW
    if td is not None:
        _set_TD(td)
    ETA1 = iv.mpf(mpf(e1)); ETA2 = iv.mpf(mpf(e2))
    _ETA_POW = [[ETA1**m for m in range(TD+1)], [ETA2**m for m in range(TD+1)]]


def _pw(eta, m):
    if m == 0:
        return iv.mpf(1)
    e = eta**m
    if m % 2 == 0:
        return iv.mpf([0, e.b])
    return iv.mpf([-e.b, e.b])


_ZEROIV = iv.mpf(0)


class TM:
    __slots__ = ('c', 'R')

    def __init__(self, c=None, R=None):
        self.c = c if c is not None else [0]*NMON
        self.R = R if R is not None else _ZEROIV

    @staticmethod
    def const(x):
        t = TM()
        t.c[0] = iv.mpf(x)
        return t

    @staticmethod
    def addmany(items):
        acc = [0]*NMON
        R = _ZEROIV
        for t in items:
            for i, a in enumerate(t.c):
                if a is not 0:
                    acc[i] = a if acc[i] is 0 else acc[i] + a
            R = R + t.R
        return TM(acc, R)

    def __add__(self, o):
        o = _astm(o)
        out = [0]*NMON
        for i in range(NMON):
            a, b = self.c[i], o.c[i]
            if a is 0:
                out[i] = b
            elif b is 0:
                out[i] = a
            else:
                out[i] = a + b
        return TM(out, self.R + o.R)

    __radd__ = __add__

    def __neg__(self):
        return TM([-a if a is not 0 else 0 for a in self.c], self.R)

    def __sub__(self, o):
        return self.__add__(_astm(o).__neg__())

    def __rsub__(self, o):
        return _astm(o).__sub__(self)

    def scale(self, s):
        s = iv.mpf(s)
        return TM([a*s if a is not 0 else 0 for a in self.c], self.R*abs(s))

    def bound(self):
        tot = _ZEROIV
        for k in range(NMON):
            a = self.c[k]
            if a is not 0:
                m1, m2 = _MON[k]
                tot = tot + abs(a)*_ETA_POW[0][m1]*_ETA_POW[1][m2]
        return tot.b

    def eval_box(self):
        """Nested-Horner box enclosure: inner Horner in u2 per u1-degree, then
        outer Horner in u1, over u_i in [-ETAi, ETAi], plus the remainder."""
        u1 = iv.mpf([-ETA1.b, ETA1.b]); u2 = iv.mpf([-ETA2.b, ETA2.b])
        outer = _ZEROIV
        for d1 in range(TD, -1, -1):
            inner = _ZEROIV
            for d2 in range(TD - d1, -1, -1):
                a = self.c[_MIDX[(d1, d2)]]
                inner = inner*u2 + (0 if a is 0 else a)
            outer = outer*u1 + inner
        return outer + iv.mpf([-self.R.b, self.R.b])

    def der(self, axis):
        """Exact derivative of the POLYNOMIAL part (remainder not differentiated;
        it enters eval_mv once, undifferentiated)."""
        out = [0]*NMON
        for k in range(NMON):
            a = self.c[k]
            if a is 0:
                continue
            m1, m2 = _MON[k]
            if axis == 0 and m1 > 0:
                out[_MIDX[(m1-1, m2)]] = a*m1
            elif axis == 1 and m2 > 0:
                out[_MIDX[(m1, m2-1)]] = a*m2
        return TM(out, _ZEROIV)

    def eval_mv(self):
        """Mean-value box enclosure of the polynomial part + remainder once:
        F(box) subseteq P(0) + sum_i (d_i P)(box)*[-ETAi, ETAi] + [-R, R]."""
        c0 = self.c[0]
        ck(c0 is not 0, 'eval_mv needs a nonzero constant term')
        tot = iv.mpf(c0)
        for axis, eta in ((0, ETA1), (1, ETA2)):
            dbox = self.der(axis).eval_box_noR()
            tot = tot + dbox*iv.mpf([-eta.b, eta.b])
        return tot + iv.mpf([-self.R.b, self.R.b])

    def eval_box_noR(self):
        u1 = iv.mpf([-ETA1.b, ETA1.b]); u2 = iv.mpf([-ETA2.b, ETA2.b])
        outer = _ZEROIV
        for d1 in range(TD, -1, -1):
            inner = _ZEROIV
            for d2 in range(TD - d1, -1, -1):
                a = self.c[_MIDX[(d1, d2)]]
                inner = inner*u2 + (0 if a is 0 else a)
            outer = outer*u1 + inner
        return outer

    def eval_iv(self, u1, u2):
        """Nested-Horner evaluation of the polynomial part over arbitrary
        intervals u1, u2 (no remainder)."""
        outer = _ZEROIV
        for d1 in range(TD, -1, -1):
            inner = _ZEROIV
            for d2 in range(TD - d1, -1, -1):
                a = self.c[_MIDX[(d1, d2)]]
                inner = inner*u2 + (0 if a is 0 else a)
            outer = outer*u1 + inner
        return outer

    def eval_box_sub(self, K1, K2=None):
        """Box enclosure via sub-box evaluation: partition [-ETA1,ETA1]x
        [-ETA2,ETA2] into K1 x K2 sub-boxes, Horner-evaluate on each, take the
        union, and add the (global, valid everywhere) remainder once.  Much
        sharper than one-shot Horner/mean-value when coefficients cancel."""
        if K2 is None:
            K2 = K1
        lo = None
        hi = None
        for a in range(K1):
            u1 = iv.mpf([-ETA1 + 2*ETA1*a/K1, -ETA1 + 2*ETA1*(a+1)/K1])
            for b in range(K2):
                u2 = iv.mpf([-ETA2 + 2*ETA2*b/K2, -ETA2 + 2*ETA2*(b+1)/K2])
                v = self.eval_iv(u1, u2)
                if lo is None or mpf(v.a) < lo:
                    lo = mpf(v.a)
                if hi is None or mpf(v.b) > hi:
                    hi = mpf(v.b)
        return iv.mpf([lo, hi]) + iv.mpf([-self.R.b, self.R.b])

    def __mul__(self, o):
        o = _astm(o)
        A, Bv = self.c, o.c
        out = [0]*NMON
        for t in range(NMON):
            acc = 0
            for i, j in _MTAB[t]:
                a = A[i]; b = Bv[j]
                if a is not 0 and b is not 0:
                    acc = a*b if acc is 0 else acc + a*b
            out[t] = acc
        # dropped-degree bound via ring norms (eta_max weighting)
        emax = ETA1 if ETA1.b >= ETA2.b else ETA2
        NA = [mpf(0)]*(TD+1); NB = [mpf(0)]*(TD+1)
        em = mpf(emax.b)
        for k in range(NMON):
            a = A[k]; b = Bv[k]
            d = _MON[k][0]+_MON[k][1]
            if a is not 0:
                NA[d] = NA[d] + mpf(abs(a).b)*em**d
            if b is not 0:
                NB[d] = NB[d] + mpf(abs(b).b)*em**d
        dropf = mpf(0)
        for di in range(TD+1):
            for dj in range(TD+1-di, TD+1):
                dropf = dropf + NA[di]*NB[dj]
        drop = iv.mpf(dropf*mpf('1.0000000001'))
        B1 = iv.mpf(sum(NA)*mpf('1.0000000001')); B2 = iv.mpf(sum(NB)*mpf('1.0000000001'))
        R = drop + B1*o.R + B2*self.R + self.R*o.R
        return TM(out, R)

    __rmul__ = __mul__

    def div(self, o):
        o = _astm(o)
        g0 = o.eval_box()
        ck(g0.a > 0 or g0.b < 0, 'TM division by model containing 0 on box')
        S = tm_inv(o)
        return self * S

    def __truediv__(self, o):
        return self.div(o)


def _astm(o):
    if isinstance(o, TM):
        return o
    return TM.const(o)


def tm_inv(G):
    """1/G as a TM: geometric series in x = 1 - G/g0 truncated at TD with a
    certified tail |x|^{TD+1}/((1-xb) g0)."""
    g0 = G.c[0]
    ck(g0 is not 0 and (g0.a > 0 or g0.b < 0), 'tm_inv: constant term straddles 0')
    x = G.scale(1/g0) - TM.const(1)          # zero constant term
    xb_iv = x.eval_box()
    xb = mpf(abs(xb_iv).b)
    ck(xb < 0.5, 'tm_inv: |1-G/g0| not < 1/2 on box')
    S = TM.const(1)
    xk = TM.const(1)
    for _k in range(1, TD+1):
        xk = xk*x
        S = S + xk.scale(-1 if _k % 2 else 1)
    tail = xb**(TD+1)/((1 - xb))
    return TM([a/g0 if a is not 0 else 0 for a in S.c],
              (S.R + tail)/abs(g0))


_BINOM_HALF = [mpf(1)]
for _k in range(1, 40):
    _BINOM_HALF.append(_BINOM_HALF[-1]*(mpf('0.5') - (_k-1))/_k)


def tm_sqrt(G):
    """sqrt(G) as a TM: binomial series in x = G/g0 - 1 truncated at TD with a
    Lagrange tail |C(1/2,TD+1)| xb^{TD+1} (1-xb)^{1/2-TD-1}."""
    g0 = G.c[0]
    ck(g0 is not 0 and g0.a > 0, 'tm_sqrt: nonpositive constant term')
    s0 = iv.sqrt(g0)
    x = G.scale(1/g0) - TM.const(1)
    xb_iv = x.eval_box()
    xb = mpf(abs(xb_iv).b)
    ck(xb < 0.5, 'tm_sqrt: |G/g0-1| not < 1/2 on box')
    S = TM.const(1)
    xk = TM.const(1)
    for _k in range(1, TD+1):
        xk = xk*x
        S = S + xk.scale(_BINOM_HALF[_k])
    tail = abs(_BINOM_HALF[TD+1])*(xb**(TD+1))*((1-xb)**(mpf('0.5') - TD - 1))
    return TM([a*s0 if a is not 0 else 0 for a in S.c], (S.R + tail)*s0)


def tm_exp(G):
    """exp of a TM: exp(c0)*series in the centered part + Lagrange defect."""
    c0 = G.c[0]
    P = TM([0] + G.c[1:], G.R)     # zero constant term, same remainder
    out = TM.const(1)
    Pk = TM.const(1)
    fk = mpf(1)
    for k in range(1, TD+1):
        Pk = Pk*P
        fk = fk*k
        out = out + Pk.scale(1/fk)
    pbound = P.eval_box()
    pb = abs(pbound).b
    defect = iv.exp(pb)*((pb**(TD+1))/FAC[TD+1] + P.R)
    ec0 = iv.exp(c0)
    return TM([ec0*a if a is not 0 else 0 for a in out.c], ec0.b*(out.R + defect))

# ---------------------------------------------------------------- station law
# Jet ordering (C1's, hash-pinned layout):
#   0..2   : f, fx, fy at M        3..5  : f, fx, fy at S
#   6..8   : f, fx, fy at y        9..11 : fxx, fxy, fyy at M
#   12..14 : fxx, fxy, fyy at S    15..17: fxx, fxy, fyy at y
# Pins: jets 0..5 (values/gradients at M, S).  Conditioning is done in the
# normalized frame U = T_r P6 (T_r exact rational in r; H2 pin_transform):
#   A = T_r G6 T_r^T  (point-exact, well conditioned, Neumann-certified),
#   C(y) = Cov(X(y), U)  (12x6, TM over the spatial box),
#   Grr  = Cov(X)        (12x12; y-self and MS blocks point-exact by
#                         stationarity, y-vs-MS cross block TM).

def _sign_beta(jb):
    """(-1)^{|jb|}: ce.cov convention Cov(d^ja f(x), d^jb f(y)) = (-1)^|jb| K^{(ja+jb)}(x-y)."""
    return -1 if (sum(DER[jb]) % 2) else 1


def _pts(r, y=None):
    rM = (-r/2, mpf(0)); rS = (r/2, mpf(0))
    P = [(rM, k) for k in JETS_MS] + [(rS, k) for k in JETS_MS]
    if y is not None:
        P += [(y, k) for k in JETS_MS]
    P += [(rM, k) for k in JETS_H] + [(rS, k) for k in JETS_H]
    if y is not None:
        P += [(y, k) for k in JETS_H]
    return P


def _kprod(lat_cache, n1, n2, t1, t2):
    return lat_cache[(n1, t1)]*lat_cache[(n2, t2)]


class PinFrame:
    """Per-rung certified pin frame: T, A, A^{-1} (Neumann), pin values u,
    and the y-independent M/S blocks (pair law, MS conditional moments)."""

    def __init__(self, r):
        self.r = mpf(r)
        self.T = pt.matrix_T_num(self.r, mode='iv')
        # 12x12 Gram of (pins at M,S) + (H_M, H_S) via a kernel cache
        cache = {}
        for t in (mpf(0), self.r, -self.r):
            for n in range(9):
                cache[(n, t)] = LAT.k1(n, t)
        P = _pts(self.r)
        G12 = [[None]*12 for _ in range(12)]
        for i in range(12):
            (xi, yi), ai = P[i]
            for j in range(i, 12):
                (xj, yj), aj = P[j]
                t = xi - xj
                n1 = DER[ai][0] + DER[aj][0]; n2 = DER[ai][1] + DER[aj][1]
                v = _sign_beta(aj)*_kprod(cache, n1, n2, t, mpf(0))
                G12[i][j] = v; G12[j][i] = v
        self.G12 = G12
        G6 = [row[:6] for row in G12[:6]]
        self.G6 = G6
        # A = T G6 T^T (interval)
        A = [[sum((self.T[i][k]*G6[k][l]*self.T[j][l]
                   for k in range(6) for l in range(6)), iv.mpf(0))
              for j in range(6)] for i in range(6)]
        self.A = A
        Ainv, cert = pt.certified_inverse(A, self.r, frame='raw')
        self.Ainv = Ainv
        self.cert = cert
        ck(mpf(cert['rho']) < mpf('0.5'), 'pin Neumann contraction rho<1/2')
        # exactness certificate: T exact rational (symbolic recompute)
        Ts = pt.matrix_T(self.r)
        for i in range(6):
            for j in range(6):
                tv = Ts[i, j]
                civ = self.T[i][j]
                ck(civ.a <= mpf(tv) <= civ.b, 'T entry interval does not pin the exact rational')
        # pin values in U frame
        pv = [iv.mpf(B), iv.mpf(0), iv.mpf(0), iv.mpf(B - self.r**3/6), iv.mpf(0), iv.mpf(0)]
        self.upin = [sum((self.T[i][j]*pv[j] for j in range(6)), iv.mpf(0)) for i in range(6)]
        self.lam_min_A = cert['lambda_min_lower']
        # y-independent MS blocks: C_MS = Cov(H_MS, U) = G12[6:, :6] T^T
        C_MS = [[sum((G12[6+i][k]*self.T[j][k] for k in range(6)), iv.mpf(0))
                 for j in range(6)] for i in range(6)]
        self.C_MS = C_MS
        CA_MS = [[sum((C_MS[i][k]*self.Ainv[k][j] for k in range(6)), iv.mpf(0))
                  for j in range(6)] for i in range(6)]
        self.mu_pair = [sum((CA_MS[i][k]*self.upin[k] for k in range(6)), iv.mpf(0))
                        for i in range(6)]
        self.S_pair = [[G12[6+i][6+j] - sum((CA_MS[i][k]*C_MS[j][k] for k in range(6)), iv.mpf(0))
                        for j in range(6)] for i in range(6)]

# ---------------------------------------------------------------- TM builders
FAC = [mpf(1)]
for _k in range(1, 40):
    FAC.append(FAC[-1]*_k)


class KernelSeries:
    """Per-box cache of certified 1D kernel Taylor coefficients."""

    def __init__(self, r, yc):
        r = mpf(r)
        self.args = {'dxM': mpf(yc[0]) + r/2, 'dxS': mpf(yc[0]) - r/2,
                     'dyv': mpf(yc[1]), 'zero': mpf(0)}
        self.NMAX = 4 + TD + 2   # highest kernel order needed
        self.coef = {}           # (n, arg) -> iv value of K1^{(n)}(t)
        for nm, t in self.args.items():
            for n in range(self.NMAX + 1):
                self.coef[(n, nm)] = LAT.k1(n, t)

    def tm_factor(self, n, arg, axis):
        """TM of K1^{(n)}(t + u_axis)."""
        eta = ETA1 if axis == 0 else ETA2
        t = TM()
        for m in range(TD + 1):
            t.c[_MIDX[(m, 0)] if axis == 0 else _MIDX[(0, m)]] = \
                self.coef[(n + m, arg)]/FAC[m]
        t.R = LAT.lambda_q(n + TD + 1)*(eta**(TD+1))/FAC[TD+1]
        return t


def jet_sig(jet):
    return DER[jet]


def cross_tm(ks, ja, pb, arg1, arg2, sgn):
    """TM of sgn * K1^{(a)}(arg1 + u1) K1^{(b)}(arg2 + u2)."""
    a1, a2 = jet_sig(ja); b1, b2 = jet_sig(pb)
    return (ks.tm_factor(a1 + b1, arg1, 0)*ks.tm_factor(a2 + b2, arg2, 1)).scale(sgn)


class StationBox:
    """Theorem-grade station law over a spatial box y = yc + [-ETA1,ETA1]x[-ETA2,ETA2].

    All outputs are Taylor models; box enclosures via eval_box().
    """

    def __init__(self, frame, yc, eta1, eta2):
        _set_eta(eta1, eta2, td=5)
        self.frame = frame
        self.yc = (mpf(yc[0]), mpf(yc[1]))
        r = frame.r
        ks = KernelSeries(r, self.yc)
        self.ks = ks

        def kcov(ja, jb, a1, a2):
            n1 = DER[ja][0] + DER[jb][0]; n2 = DER[ja][1] + DER[jb][1]
            return _sign_beta(jb)*ks.coef[(n1, a1)]*ks.coef[(n2, a2)]

        # ---- C(y) = Cov(X, U) (X-frame rows: 0..2 Y3, 3..8 MS-Hess, 9..11 Hy)
        C = [[None]*6 for _ in range(12)]
        for i in range(12):
            ja = xjet(i)
            for j in range(6):
                if 3 <= i <= 8:
                    C[i][j] = TM.const(frame.C_MS[i-3][j])
                    continue
                items = []
                for k in range(6):
                    Tjk = frame.T[j][k]
                    if Tjk == 0:
                        continue
                    pk = JETS_MS[k] if k < 3 else JETS_MS[k-3]
                    arg1 = 'dxM' if k < 3 else 'dxS'
                    items.append(cross_tm(ks, ja, pk, arg1, 'dyv', _sign_beta(pk)).scale(Tjk))
                C[i][j] = TM.addmany(items)
        self.C = C

        # ---- Grr as TM matrix (12x12 symmetric)
        yjets = (0, 1, 2, 9, 10, 11)
        msjets = (3, 4, 5, 6, 7, 8)
        Grr = [[None]*12 for _ in range(12)]
        for i in range(12):
            for j in range(i, 12):
                if i in msjets and j in msjets:
                    Grr[i][j] = TM.const(frame.G12[i+3][j+3])
                elif i in yjets and j in yjets:
                    Grr[i][j] = TM.const(kcov(xjet(i), xjet(j), 'zero', 'zero'))
                # y-jet x MS-Hessian cross block: true TMs below
                Grr[j][i] = Grr[i][j]
        for i in yjets:
            ja = xjet(i)
            for j in msjets:
                fj = 6 + j
                jb = jb_of(j)
                arg1 = 'dxM' if fj <= 11 else 'dxS'
                t = cross_tm(ks, ja, jb, arg1, 'dyv', _sign_beta(jb))
                Grr[i][j] = t; Grr[j][i] = t
        self.Grr = Grr

        # ---- conditioning chain (TM)
        # CA = C Ainv (12x6)
        CA = [[sum((C[i][k]*_tmscalar(frame.Ainv[k][j]) for k in range(6)), TM())
               for j in range(6)] for i in range(12)]
        # mu1 = C Ainv upin  (12-vector)
        mu1 = [sum((CA[i][k]*_tmscalar(frame.upin[k]) for k in range(6)), TM())
               for i in range(12)]
        # S1 = Grr - CA C^T  (symmetric)
        S1 = [[None]*12 for _ in range(12)]
        for i in range(12):
            for j in range(i, 12):
                acc = Grr[i][j]
                for k in range(6):
                    acc = acc - CA[i][k]*C[j][k]
                S1[i][j] = acc; S1[j][i] = acc
        self.S1 = S1
        self.mu1 = mu1

        # ---- stage 2: condition on grad f(y) = 0
        Sgg = [[S1[1+i][1+j] for j in range(2)] for i in range(2)]
        detgg = Sgg[0][0]*Sgg[1][1] - Sgg[0][1]*Sgg[0][1]
        self.detgg = detgg
        dinv = tm_inv(detgg)
        Sgginv = [[Sgg[1][1]*dinv, (-Sgg[0][1])*dinv], [(-Sgg[0][1])*dinv, Sgg[0][0]*dinv]]
        mu_g = [mu1[1], mu1[2]]
        # q = mu_g^T Sgginv mu_g
        q = TM()
        for a in range(2):
            for b in range(2):
                q = q + mu_g[a]*Sgginv[a][b]*mu_g[b]
        pgrad = tm_inv(tm_sqrt(detgg)).scale(1/(2*pi))*tm_exp(q.scale(mpf('-0.5')))
        self.pgrad = pgrad

        irest = [0] + list(range(3, 12))
        Grg = [[S1[irest[i]][1+j] for j in range(2)] for i in range(10)]
        # S2 = S1[irest,irest] - Grg Sgginv Grg^T ; mu2 = mu1[irest] - Grg Sgginv mu_g
        S2 = [[None]*10 for _ in range(10)]
        for i in range(10):
            for j in range(i, 10):
                acc = S1[irest[i]][irest[j]]
                for a in range(2):
                    for b in range(2):
                        acc = acc - Grg[i][a]*Sgginv[a][b]*Grg[j][b]
                S2[i][j] = acc; S2[j][i] = acc
        mu2 = [None]*10
        for i in range(10):
            acc = mu1[irest[i]]
            for a in range(2):
                for b in range(2):
                    acc = acc - Grg[i][a]*Sgginv[a][b]*mu_g[b]
            mu2[i] = acc
        self.S2 = S2; self.mu2 = mu2

        s_t2 = S2[0][0]
        self.s_t2 = s_t2
        self.mu_t = mu2[0]
        # w-space loadings first (well-conditioned TMs): c_tilde = Cov/s_t
        s_t_tm = tm_sqrt(s_t2)
        s_t_inv = tm_inv(s_t_tm)
        self.c_tilde = [S2[0][1+k]*s_t_inv for k in range(9)]
        self.c_v = [self.c_tilde[k]*s_t_inv for k in range(9)]
        self.mu_H = [mu2[1+k] for k in range(9)]
        # SH = S2_H - c_tilde c_tilde^T (same as S2_H - s_t^2 c_v c_v^T but
        # with well-conditioned TM factors)
        SH = [[None]*9 for _ in range(9)]
        for i in range(9):
            for j in range(i, 9):
                SH[i][j] = S2[1+i][1+j] - self.c_tilde[i]*self.c_tilde[j]
                SH[j][i] = SH[i][j]
        self.SH = SH

        # ---- certified pointwise-positivity checks on the box
        s_t2_box = s_t2.eval_box()
        ck(s_t2_box.a > 0, 's_t^2 not certified positive over box')
        dgg = detgg.eval_box()
        ck(dgg.a > 0, 'det Sigma_gg not certified positive over box')

        # ---- box enclosures (interval inputs for the moment machinery)
        # diagonal entries of SH are variances: clipping their enclosures at 0
        # below is a valid tightening (the true value is >= 0).
        SH_box = [[SH[i][j].eval_mv() for j in range(9)] for i in range(9)]
        for i in range(9):
            v = SH_box[i][i]
            SH_box[i][i] = iv.mpf([max(mpf(0), mpf(v.a)), v.b])
        s_t_box = iv.sqrt(s_t2_box)
        self.box = dict(
            pgrad=pgrad.eval_mv(),
            mu_t=self.mu_t.eval_mv(),
            s_t2=s_t2_box,
            s_t=s_t_box,
            c_v=[c.eval_mv() for c in self.c_v],
            c_tilde=[c.eval_mv() for c in self.c_tilde],
            mu_H=[m.eval_mv() for m in self.mu_H],
            SH=SH_box,
            # TM-level objects for correlation-preserving margin bounds
            mu_H_tm=self.mu_H, c_v_tm=self.c_v, SH_tm=SH,
            c_tilde_tm=self.c_tilde,
            mu_t_tm=self.mu_t, s_t2_tm=s_t2, s_t_tm=s_t_tm,
        )


def jb_of(j):
    """MS-Hessian jet name for X-frame index j in {3..8}."""
    return JETS_H[(j - 3) % 3]


_YJ = ('f', 'fx', 'fy')


def xjet(i):
    """Jet name for X-frame index i in {0..11}."""
    if i < 3:
        return _YJ[i]
    if i < 9:
        return JETS_H[(i - 3) % 3]
    return JETS_H[i - 9]


def _tmscalar(x):
    return TM.const(x)

# ---------------------------------------------------------------- Isserlis moments
# Moment polynomials in Delta = v - mu_t for X ~ N(mu_H + c_v Delta, SH),
# computed by the Stein recursion  E[X_i P] = mu_i E[P] + sum_j S_ij E[dP/dX_j]
# with memoization over exponent multisets.  Interval coefficients throughout.

def _padd(a, b):
    n = max(len(a), len(b))
    z = iv.mpf(0)
    out = [z]*n
    for i, x in enumerate(a):
        out[i] = out[i] + x
    for i, x in enumerate(b):
        out[i] = out[i] + x
    return out


def _pscale(a, s):
    return [s*x for x in a]


def _pmul_aff(a, m0, m1):
    z = iv.mpf(0)
    out = [z]*(len(a)+1)
    for i, x in enumerate(a):
        out[i] = out[i] + m0*x
        out[i+1] = out[i+1] + m1*x
    return out


def moment_engine(mu0, cv, S):
    n = len(mu0)
    cache = {}

    def M(e):
        if all(x == 0 for x in e):
            return [iv.mpf(1)]
        got = cache.get(e)
        if got is not None:
            return got
        i = next(k for k in range(n) if e[k] > 0)
        ei = list(e); ei[i] -= 1; ei = tuple(ei)
        out = _pmul_aff(M(ei), mu0[i], cv[i])
        for j in range(n):
            if j != i and e[j] > 0:
                ej = list(ei); ej[j] -= 1
                out = _padd(out, _pscale(M(tuple(ej)), S[i][j]*e[j]))
            elif j == i and e[i] > 1:
                ej = list(ei); ej[j] -= 1
                out = _padd(out, _pscale(M(tuple(ej)), S[i][i]*(e[i]-1)))
        cache[e] = out
        return out
    return M


def _det_monos(b):
    return [(1, ((b, 1), (b+2, 1))), (-1, ((b+1, 2),))]


def _mono_product(lists):
    out = [(1, ())]
    for ml in lists:
        new = []
        for c0, e0 in out:
            for c, e in ml:
                new.append((c0*c, tuple(sorted(e0 + e))))
        out = new
    return out


def _exp_tuple(e, n):
    ex = [0]*n
    for k, v in e:
        ex[k] += v
    return tuple(ex)


def moment_poly(M, monos, n):
    out = [iv.mpf(0)]
    for c, e in monos:
        out = _padd(out, _pscale(M(_exp_tuple(e, n)), iv.mpf(int(c))))
    return out


def peval_iv(p, x):
    out = iv.mpf(0)
    for c in reversed(p):
        out = out*x + c
    return out


# ---------------------------------------------------------------- det expansion
# det(X_b + c_b D) = A_b + B_b D + C_b D^2 exactly (det is quadratic):
#   A = det X_b,  B = grad det(X_b).c_b,  C = q_det(c_b).
# All v-moment polynomials are built from Isserlis moments of the CENTER-law
# Gaussian X0 ~ N(mu_H, SH); c_v enters only as exact scalar powers.

def _abc_lists(b, c_b):
    c0, c1, c2 = c_b
    A = [(iv.mpf(1), ((b, 1), (b+2, 1))), (iv.mpf(-1), ((b+1, 2),))]
    B = [(c0, ((b+2, 1),)), (-2*c1, ((b+1, 1),)), (c2, ((b, 1),))]
    C = [(c0*c2 - c1*c1, ())]
    return [A, B, C]


def _mul_monos(P, Q):
    out = []
    for c0, e0 in P:
        for c, e in Q:
            out.append((c0*c, tuple(sorted(e0 + e))))
    return out


def _mono_pow(ml, k):
    out = [(iv.mpf(1), ())]
    for _ in range(k):
        out = _mul_monos(out, ml)
    return out


def moment_poly_abc(M0, blocks, pw=1, n=9):
    """Poly in Delta of E[ prod_b det_b(D)^pw ] under the center law.
    blocks: list of abc_lists (one per distinct block).  Slots within a block
    are identical, so choices are grouped by (nA, nB, nC) counts with the
    multinomial factor pw!/(nA! nB! nC!)."""
    nslots = pw*len(blocks)
    degmax = 2*nslots
    coeffs = [iv.mpf(0)]*(degmax+1)
    import itertools as _it
    ranges = []
    for _ in blocks:
        ranges.append([(na, nb, pw-na-nb) for na in range(pw+1) for nb in range(pw+1-na)])
    for combo in _it.product(*ranges):
        eD = sum(nb + 2*nc for (na, nb, nc) in combo)
        fac = 1
        ml = [(iv.mpf(1), ())]
        for bi, (na, nb, nc) in enumerate(combo):
            fac *= int(mp.factorial(pw)/(mp.factorial(na)*mp.factorial(nb)*mp.factorial(nc)))
            A, B_, C = blocks[bi]
            for part, kk in ((A, na), (B_, nb), (C, nc)):
                if kk:
                    ml = _mul_monos(ml, _mono_pow(part, kk))
        acc = coeffs[eD]
        fiv = iv.mpf(fac)
        for c, e in ml:
            acc = acc + fiv*c*M0(_exp_tuple(e, n))
        coeffs[eD] = acc
    return coeffs


# legacy monomial sets retained for the pair-law moments
MONOS6 = [(c, tuple(sorted(e))) for c, e in
          _mono_product([_det_monos(0), _det_monos(3), _det_monos(6)])]
MONOS12 = [(c, tuple(sorted(e))) for c, e in _mono_product([
    _mono_product([_det_monos(0), _det_monos(0)]),
    _mono_product([_det_monos(3), _det_monos(3)]),
    _mono_product([_det_monos(6), _det_monos(6)])])]


def det_power_monos(b, pw):
    m = _mono_product([_det_monos(b)]*pw)
    return [(c, tuple(sorted(e))) for c, e in m]


# ---------------------------------------------------------------- margins
# For block b with mean mu(Δ) = m0 + c Δ and covariance Sb (3x3), write
#   det(X_b) - det(mu) = g(Δ)·W + W' Q W,  W ~ N(0, Sb),
#   g(Δ) = (mu2, -2 mu1, mu0) (affine in Δ),  Q = [[0,0,1/2],[0,-1,0],[1/2,0,0]].
# P( det has the wrong sign | Delta ) <= 2 Phi_bar(m/(2 sL)) + EQ2/(m/2)^2
#   with m = needed sign margin, sL^2 = g' Sb g, EQ2 = E[(W'QW)^2], via
#   {|dev| >= m} subset {|gW| >= m/2} u {|W'QW| >= m/2}, Mills ratio for the
#   Gaussian part (Phi_bar(a) <= phi(a)/a, a>0) and Markov-2 for the quadratic.

QM = ((iv.mpf(0), iv.mpf(0), iv.mpf('0.5')),
      (iv.mpf(0), iv.mpf(-1), iv.mpf(0)),
      (iv.mpf('0.5'), iv.mpf(0), iv.mpf(0)))


def block_margin_data(mu_b, c_b, Sb):
    """Interval polys in Delta: det(mu) [deg2], sL2 [deg2]; consts EQ, EQ2."""
    z = iv.mpf(0)
    m0, m1, m2 = mu_b
    c0, c1, c2 = c_b
    detp = [m0*m2 - m1*m1,
            m0*c2 + m2*c0 - 2*m1*c1,
            c0*c2 - c1*c1]
    g0 = [m2, c2]; g1 = [-2*m1, -2*c1]; g2 = [m0, c0]
    gs = [g0, g1, g2]
    sL2 = [z, z, z]
    for i in range(3):
        for j in range(3):
            Sij = Sb[i][j]
            gi, gj = gs[i], gs[j]
            sL2[0] = sL2[0] + Sij*gi[0]*gj[0]
            sL2[1] = sL2[1] + Sij*(gi[0]*gj[1] + gi[1]*gj[0])
            sL2[2] = sL2[2] + Sij*gi[1]*gj[1]
    QS = [[sum((QM[i][k]*Sb[k][j] for k in range(3)), z) for j in range(3)] for i in range(3)]
    EQ = QS[0][0] + QS[1][1] + QS[2][2]
    tr2 = z
    for i in range(3):
        for j in range(3):
            tr2 = tr2 + QS[i][j]*QS[j][i]
    EQ2 = 2*tr2 + EQ*EQ
    return dict(detp=detp, sL2=sL2, EQ=EQ, EQ2=EQ2)


# TM-coefficient analogues: margins as polys in Delta whose coefficients are
# TMs over the spatial box, so correlations survive to the box enclosure.
def block_margin_data_tm(mu_b, c_b, Sb):
    z = TM()
    m0, m1, m2 = mu_b
    c0, c1, c2 = c_b
    detp = [m0*m2 - m1*m1, m0*c2 + m2*c0 - (m1*c1).scale(2), c0*c2 - c1*c1]
    gs = [[m2, c2], [m1.scale(-2), c1.scale(-2)], [m0, c0]]
    sL2 = [z, z, z]
    for i in range(3):
        for j in range(3):
            Sij = Sb[i][j]
            gi, gj = gs[i], gs[j]
            sL2 = [sL2[0] + Sij*gi[0]*gj[0],
                   sL2[1] + Sij*(gi[0]*gj[1] + gi[1]*gj[0]),
                   sL2[2] + Sij*gi[1]*gj[1]]
    QS = [[TM.addmany([Sb[k][j].scale(QM[i][k])
                       for k in range(3)]) for j in range(3)] for i in range(3)]
    EQ = QS[0][0] + QS[1][1] + QS[2][2]
    tr2 = TM()
    for i in range(3):
        for j in range(3):
            tr2 = tr2 + QS[i][j]*QS[j][i]
    EQ2 = tr2.scale(2) + EQ*EQ
    return dict(detp=detp, sL2=sL2, EQ=EQ.eval_mv(), EQ2=EQ2.eval_mv())


def peval_tm(p, D):
    """Horner evaluation of a TM-coefficient poly at an interval D -> TM."""
    out = TM()
    for c in reversed(p):
        out = out.scale(D) + c
    return out


def _mills_hi(a_lo):
    """Upper bound on Phi_bar(a) for a >= a_lo > 0 (Mills): phi(a_lo)/a_lo."""
    ck(a_lo > 0, 'Mills bound needs a positive lower endpoint')
    return iv.exp(-a_lo*a_lo/2)/(iv.sqrt(2*pi)*a_lo)


def P_wrong_block(margin_int, sL2_int, EQ2):
    """Certified upper bound on P(wrong det sign) given margin m in margin_int."""
    m_lo = margin_int.a
    if not m_lo > 0:
        return iv.mpf(1)
    sL2_hi = sL2_int.b
    EQ2_hi = EQ2.b if hasattr(EQ2, 'b') else mpf(EQ2)
    p2 = EQ2_hi/(m_lo/2)**2
    if sL2_hi > 0:
        a_lo = m_lo/(2*iv.sqrt(iv.mpf(sL2_hi)))
        if a_lo.a > 0:
            p1 = 2*_mills_hi(a_lo.a)
        else:
            p1 = iv.mpf(1)
    else:
        p1 = iv.mpf(0)
    out = p1 + p2
    return iv.mpf([0, min(mpf(1), mpf(out.b))])


def P_trM_hi(trM_int, s_tr2_int):
    """Upper bound on P(trM >= 0): Phi_bar(-trM/s_tr); 1 when not certifiable."""
    if not (s_tr2_int.a > 0):
        return iv.mpf(1)
    t_lo = trM_int.a
    if not t_lo < 0:
        return iv.mpf(1)
    a_lo = -t_lo/iv.sqrt(s_tr2_int.b)
    if not a_lo > 0:
        return iv.mpf(1)
    return iv.mpf([0, _mills_hi(a_lo).b])


# ---------------------------------------------------------------- w-window quadrature
def w_cells(wlo_mid, whi_mid, wlo_cert, whi_cert, K=256, T=7.0):
    """Deterministic w-grid (w = (v-mu_t)/s_t): central K cells uniform over
    [-T, T] intersected with the (mid) window, plus doubling bands; outer edges
    extended to the certified window bounds wlo_cert <= wlo(y), whi_cert >=
    whi(y) for every y in the box.  Placement is non-rigorous; coverage is."""
    edges = set()
    edges.add(wlo_mid); edges.add(whi_mid)
    lo = max(wlo_mid, -T); hi = min(whi_mid, T)
    if hi > lo:
        for k in range(K+1):
            edges.add(lo + (hi-lo)*k/K)
    tb = -T
    while tb > wlo_mid:
        edges.add(max(wlo_mid, 2*tb))
        tb = 2*tb
    tb = T
    while tb < whi_mid:
        edges.add(min(whi_mid, 2*tb))
        tb = 2*tb
    ts = sorted(edges)
    ts[0] = wlo_cert   # certified outer extension (exact mpf)
    ts[-1] = whi_cert
    cells = []
    for i in range(len(ts)-1):
        a, bnd = mpf(ts[i]), mpf(ts[i+1])
        if bnd > a:
            cells.append((a, bnd))
    return cells

# ---------------------------------------------------------------- g-bounds and I-integral
def _sq_iv(x):
    """Tight interval square."""
    if x.a >= 0:
        return iv.mpf([x.a*x.a, x.b*x.b])
    if x.b <= 0:
        return iv.mpf([x.b*x.b, x.a*x.a])
    m = max(-x.a, x.b)
    return iv.mpf([0, m*m])


def _pos_iv(x):
    return iv.mpf([max(mpf(0), mpf(x.a)), max(mpf(0), mpf(x.b))])


class GBounds:
    """Per-box g(v) bound machinery: moment polys + margins, then v-quadrature."""

    def __init__(self, box, grade='A'):
        self.box = box
        self.grade = grade
        muH = box['mu_H']; SH = box['SH']
        # TM-level margin data per block (correlation-preserving); margins are
        # polys in w with c_tilde coefficients.
        muH_tm = box['mu_H_tm']; ct_tm = box['c_tilde_tm']; SH_tm = box['SH_tm']
        self.marg = []
        for b in range(3):
            mu_b = muH_tm[3*b:3*b+3]; c_b = ct_tm[3*b:3*b+3]
            Sb = [row[3*b:3*b+3] for row in SH_tm[3*b:3*b+3]]
            self.marg.append(block_margin_data_tm(mu_b, c_b, Sb))
        # trM data (TM level); margins are probability UPPER bounds, so a
        # non-certified-positive s_tr^2 degrades to P_trM = 1 (never fails).
        self.trM_p = [muH_tm[0] + muH_tm[2], ct_tm[0] + ct_tm[2]]
        self.s_tr2_tm = SH_tm[0][0] + SH_tm[2][2] + SH_tm[0][2].scale(2)
        self.s_tr2 = self.s_tr2_tm.eval_mv()
        # moment polys in w = (v-mu_t)/s_t via the exact det quadratic
        # expansion: Isserlis moments of the center law; loadings c_tilde
        # (= c_v s_t, O(1)) factored out as scalar powers.
        ct = box['c_tilde']
        z3 = [iv.mpf(0)]*3
        abcs = [_abc_lists(3*b, ct[3*b:3*b+3]) for b in range(3)]
        if grade == 'A':
            eng0 = moment_engine(muH, [iv.mpf(0)]*9, SH)

            def M0(e):
                return eng0(e)[0]
            self.M6p = moment_poly_abc(M0, abcs, 1, 9)
            self.M12p = moment_poly_abc(M0, abcs, 2, 9)
        # per-block E[det_b^6] polys (both grades) for the Hoelder cap
        self.E6 = []
        for b in range(3):
            mu_b = muH[3*b:3*b+3]
            Sb = [row[3*b:3*b+3] for row in SH[3*b:3*b+3]]
            eng_b = moment_engine(mu_b, z3, Sb)
            self.E6.append(moment_poly_abc(lambda e: eng_b(e)[0],
                                           [_abc_lists(0, ct[3*b:3*b+3])], 6, 3))

    def cell_bounds(self, W):
        """Return (g_lo, g_hi) valid for all (y, w) with w = (v-mu_t)/s_t in W."""
        box = self.box
        D = W                     # margin/moment polys are in w directly
        # margins at D (TM-coefficient polys -> TM at D -> box enclosure)
        P = []        # violation probs P(det sign != needed)
        PF = []       # flip probs P(det sign == needed) = deviation-flip bounds
        for b, need in enumerate((+1, -1, -1)):
            md = self.marg[b]
            detI = peval_tm(md['detp'], D).eval_mv()
            margin = detI if need > 0 else -detI
            sL2 = peval_tm(md['sL2'], D).eval_mv()
            P.append(P_wrong_block(margin, sL2, md['EQ2']))
            PF.append(P_wrong_block(-margin, sL2, md['EQ2']))
        trMI = peval_tm(self.trM_p, D).eval_mv()
        Ptr = P_trM_hi(trMI, self.s_tr2)                    # P(trM >= 0)
        # P(trM < 0): nonzero only when the mean trace is solidly positive
        if self.s_tr2.a > 0 and trMI.a > 0:
            a_lo = trMI.a/iv.sqrt(self.s_tr2.b)
            Ptr_sat = min(mpf(1), mpf(_mills_hi(a_lo).b))
        else:
            Ptr_sat = mpf(1)
        # satisfaction probs (for the Cauchy-Schwarz crush g^2 <= M12 P(C),
        # P(C) <= min_b P(block b satisfies its condition))
        PS = [min(mpf(1), min(mpf(PF[0].b), Ptr_sat)),
              min(mpf(1), mpf(PF[1].b)),
              min(mpf(1), mpf(PF[2].b))]
        PS_min_hi = min(PS)
        PnC_hi = min(mpf(1), mpf((P[0] + P[1] + P[2] + Ptr).b))
        # Hoelder cap: prod_b (E det_b^6)^{1/6}  (upper ends only; polys in w)
        hold_hi = mpf(1)
        for b in range(3):
            e6 = _pos_iv(peval_iv(self.E6[b], W))
            hold_hi = hold_hi*(mpf(e6.b)**(mpf(1)/6))
        if self.grade == 'A':
            M6 = peval_iv(self.M6p, W)
            M12 = _pos_iv(peval_iv(self.M12p, W))
            sq12 = mpf(iv.sqrt(iv.mpf(M12.b)).b)
            crush = mpf(iv.sqrt(iv.mpf(PS_min_hi)).b)
            g_hi = min(sq12, sq12*crush, mpf(hold_hi))
            m6abs_lo = mpf(0)
            if M6.a > 0:
                m6abs_lo = mpf(M6.a)
            elif M6.b < 0:
                m6abs_lo = -mpf(M6.b)
            g_lo = max(mpf(0), m6abs_lo - mpf(iv.sqrt(iv.mpf(M12.b)*PnC_hi).b))
            return mpf(g_lo), g_hi
        else:
            g_hi = mpf(hold_hi)*min(mpf(1), mpf(iv.sqrt(iv.mpf(PS_min_hi)).b))
            return mpf(0), g_hi

    def integral(self, r, K=256, T=7.0):
        """Interval [I_lo, I_hi] of I(y) = ∫_{b-ell}^b phi(v) g(v) dv over the
        box, in w = (v - mu_t)/s_t coordinates: I = ∫_window phi_01(w) g(w) dw.
        Upper over the outer window, lower over the guaranteed inner window."""
        box = self.box
        mu_t = box['mu_t']; s_t = box['s_t']
        ck(s_t.a > 0, 's_t not positive in integral')
        r = mpf(r); ell = r**3/6
        wlo = (iv.mpf(B) - iv.mpf(ell) - mu_t)/s_t   # interval over the box
        whi = (iv.mpf(B) - mu_t)/s_t
        wlo_mid = float(mpf(wlo.a) + mpf(wlo.b))/2
        whi_mid = float(mpf(whi.a) + mpf(whi.b))/2
        cells = w_cells(wlo_mid, whi_mid, wlo.a, whi.b, K=K, T=T)
        # inner (guaranteed) window
        in_a, in_b = mpf(wlo.b), mpf(whi.a)
        inv_sq2pi = iv.mpf(1/iv.sqrt(iv.mpf(2*pi)))
        I_lo = mpf(0); I_hi = mpf(0)
        mass = iv.mpf(0)
        for wa, wb in cells:
            width = wb - wa
            if width <= 0:
                continue
            W = iv.mpf([wa, wb])
            q = _sq_iv(W)/2
            phi = iv.exp(-q)*inv_sq2pi
            g_lo, g_hi = self.cell_bounds(W)
            I_hi += mpf(width)*mpf(phi.b)*g_hi
            if wa >= in_a and wb <= in_b:
                I_lo += mpf(width)*mpf(phi.a)*g_lo
            mass = mass + phi*iv.mpf(width)
        self.mass_interval = mass
        self.n_cells = len(cells)
        self.window = (wlo, whi)
        return iv.mpf([I_lo, I_hi]), (wlo, whi)


# ---------------------------------------------------------------- pair law / Z_r
def pair_law(frame):
    """Law of (H_M, H_S) given the six pins: N(mu6, S6), interval (point-exact)."""
    r = frame.r
    P = _pts(r)   # 12 jets: pins 0..5, H_M 6..8, H_S 9..11
    n = 12
    G = [[None]*n for _ in range(n)]
    for i in range(n):
        (xi, yi), ai = P[i]
        for j in range(i, n):
            (xj, yj), aj = P[j]
            v = ce.cov(DER[ai], DER[aj], xi - xj, yi - yj, 'spectral', 'iv')
            G[i][j] = v; G[j][i] = v
    # condition on pins via the normalized frame
    C = [[sum((G[6+i][k]*frame.T[j][k] for k in range(6)), iv.mpf(0))
          for j in range(6)] for i in range(6)]
    CA = [[sum((C[i][k]*frame.Ainv[k][j] for k in range(6)), iv.mpf(0))
           for j in range(6)] for i in range(6)]
    mu6 = [sum((CA[i][k]*frame.upin[k] for k in range(6)), iv.mpf(0)) for i in range(6)]
    S6 = [[None]*6 for _ in range(6)]
    for i in range(6):
        for j in range(i, 6):
            acc = G[6+i][6+j]
            for k in range(6):
                acc = acc - CA[i][k]*C[j][k]
            S6[i][j] = acc; S6[j][i] = acc
    return mu6, S6


def Z_r_own_bracket(mu6, S6):
    """H5's own certified bracket on Z_r (margin route), plus moment displays."""
    eng = moment_engine(mu6, [iv.mpf(0)]*6, S6)
    m4 = _mono_product([_det_monos(0), _det_monos(3)])
    M4 = moment_poly(eng, [(c, tuple(sorted(e))) for c, e in m4], 6)[0]
    m8 = _mono_product([_mono_product([_det_monos(0), _det_monos(0)]),
                        _mono_product([_det_monos(3), _det_monos(3)])])
    M8 = moment_poly(eng, [(c, tuple(sorted(e))) for c, e in m8], 6)[0]
    # margins on the pair chamber
    P = iv.mpf(0)
    for b, need in ((0, +1), (1, -1)):
        mu_b = mu6[3*b:3*b+3]
        Sb = [row[3*b:3*b+3] for row in S6[3*b:3*b+3]]
        md = block_margin_data(mu_b, [iv.mpf(0)]*3, Sb)
        detI = peval_iv(md['detp'], iv.mpf(0))
        margin = detI if need > 0 else -detI
        sL2 = peval_iv(md['sL2'], iv.mpf(0))
        P = P + P_wrong_block(margin, sL2, md['EQ2'])
    trM = mu6[0] + mu6[2]
    s_tr2 = S6[0][0] + S6[2][2] + 2*S6[0][2]
    P = P + P_trM_hi(iv.mpf([trM.a, trM.b]), s_tr2)
    PnC = min(mpf(1), mpf(P.b))
    M4a = mpf(M4.a); M4b = mpf(M4.b)
    m4abs = M4a if M4a > 0 else (-M4b if M4b < 0 else mpf(0))
    M8sup = mpf(_pos_iv(M8).b)
    z_lo = max(mpf(0), m4abs - mpf(iv.sqrt(M8sup*PnC).b))
    z_hi = mpf(iv.sqrt(M8sup).b)
    return iv.mpf([z_lo, z_hi]), M4, M8, PnC


# H3's certified normalizer lower bound (consumed per D1 polarity audit P6;
# validity r <= r_0 existential in H3 -- flagged as a shared campaign hypothesis)
C0_H3_LO = mpf('3.230978535287004948096246569018163150764858010558710998470')
C_Z_H3 = C0_H3_LO/2

# ---------------------------------------------------------------- anchors (certified erf)
def erf_iv(x, nterms=30):
    """Certified interval erf(x) for |x| <= 2 via the power series with a
    verified geometric tail bound."""
    xv = iv.mpf(x)
    ck(abs(xv.b) <= 2 and abs(xv.a) <= 2, 'erf_iv domain |x|<=2')
    x2 = xv*xv
    term = xv
    tot = term
    for k in range(1, nterms):
        term = -term*x2*(2*k-1)/(k*(2*k+1))
        tot = tot + term
    # tail: |term_{k+1}/term_k| = x^2 (2k+1)/((k+1)(2k+3)) <= x^2/(k+1)
    q = abs(x2).b/(nterms+1)
    ck(q < 0.5, 'erf tail contraction')
    tail = abs(term).b*q/(1-q)
    return 2/iv.sqrt(pi)*(tot + iv.mpf([-tail, tail]))


def anchors(r):
    """D3's closed forms and C1's unconditioned anchors, interval-evaluated."""
    r = mpf(r)
    ell = r**3/6
    a2 = ce.moment_a(1, 'spectral', 'iv')
    a4 = ce.moment_a(2, 'spectral', 'iv')
    bv = iv.mpf(B)
    m_sad_b = iv.sqrt(2)*iv.exp(-bv*bv/4)                       # D3 m_sad(b)
    phi_b = iv.exp(-bv*bv/2)/iv.sqrt(2*pi)
    rho_sad0 = phi_b*m_sad_b/(a2*2*pi)                          # D3 rho_sad^0(b)
    # J(ell) = sqrt(2)/(2 pi)^{3/2} * sqrt(pi/3) [erf(sqrt3 b/2) - erf(sqrt3(b-ell)/2)]
    sq3 = iv.sqrt(3)
    J = iv.sqrt(2)/(2*pi)**mpf('1.5')*iv.sqrt(pi/3)*(
        erf_iv(sq3*bv/2) - erf_iv(sq3*(bv - iv.mpf(ell))/2))
    # unconditioned single-Hessian moments via the H5 Isserlis engine
    s2 = a4 - a2*a2
    mu0 = [-a2*bv, iv.mpf(0), -a2*bv]
    Su = [[iv.mpf(0)]*3 for _ in range(3)]
    Su[0][0] = s2; Su[1][1] = a2*a2; Su[2][2] = s2
    eng = moment_engine(mu0, [iv.mpf(0)]*3, Su)
    Edet2 = moment_poly(eng, det_power_monos(0, 2), 3)[0]
    Edet = moment_poly(eng, [(c, tuple(sorted(e))) for c, e in _det_monos(0)], 3)[0]
    # Hoelder/margin bracket on m_sad(b) = E|det|1{sad}
    Pw = P_wrong_block(-(mu0[0]*mu0[2] - mu0[1]**2), iv.mpf(0),
                       block_margin_data(mu0, [iv.mpf(0)]*3, Su)['EQ2'])
    m_hi = mpf(iv.sqrt(_pos_iv(Edet2).b).b)
    _s = iv.sqrt(_pos_iv(Edet2).b*min(mpf(1), mpf(Pw.b)))
    m_lo = max(mpf(0), mpf(abs(Edet).a) - mpf(_s.b))
    return dict(ell=ell, a2=a2, a4=a4, m_sad_b=m_sad_b, rho_sad0=rho_sad0, J=J,
                Edet2=Edet2, Edet=Edet, m_sad_bracket=(m_lo, m_hi))


# ---------------------------------------------------------------- box rho bounds
def box_rho(sb, r, Z_int, grade='A', K=256, T=7.0):
    """Interval bounds on rho_w(y) over the box, given Z_r interval Z_int."""
    gb = GBounds(sb.box, grade)
    I_int, trange = gb.integral(r, K=K, T=T)
    pg = sb.box['pgrad']
    ck(Z_int.a > 0, 'Z_r lower bound must be positive')
    rho_lo = mpf(pg.a)*mpf(I_int.a)/mpf(Z_int.b)
    rho_hi = mpf(pg.b)*mpf(I_int.b)/mpf(Z_int.a)
    return dict(rho=(rho_lo, rho_hi), I=(mpf(I_int.a), mpf(I_int.b)),
                mass=gb.mass_interval, trange=trange, n_cells=gb.n_cells,
                pgrad=pg)

# ---------------------------------------------------------------- coarse boxes
class CoarseBox:
    """Certified crude rho upper bound over a spatial box, without any TM
    inverse: S1 = Grr - C Ainv C^T is polynomial TM arithmetic (valid at any
    eta); the stage-2 conditioning is then done in plain interval arithmetic
    (2x2 inverse with certified-positive det).  Wide but valid.

    rho(y) <= pgrad_sup * I_hi / Z_lo   for all y in the box, with
      pgrad_sup = exp(-q_inf/2) / (2 pi sqrt(detgg_inf)),
      I_hi      = sqrt(M12'_sup * min(mass_sup, PS_min_sup)),
    where M12' = E[h^2 | pins, grad f(y)=0] (v-marginal), mass_sup bounds
    P(f(y) in window | pins, grad=0), and PS_min is the typing-crush bound.
    """

    def __init__(self, frame, yc, eta1, eta2):
        _set_eta(eta1, eta2, td=6)
        r = frame.r
        self._r = r
        self.eta1 = eta1
        self.eta2 = eta2
        ks = KernelSeries(r, yc)
        self.yc = yc

        def kcov(ja, jb, a1, a2):
            n1 = DER[ja][0] + DER[jb][0]; n2 = DER[ja][1] + DER[jb][1]
            return _sign_beta(jb)*ks.coef[(n1, a1)]*ks.coef[(n2, a2)]

        # C rows (TMs) and Grr (TMs) as in StationBox
        C = [[None]*6 for _ in range(12)]
        for i in range(12):
            ja = xjet(i)
            for j in range(6):
                if 3 <= i <= 8:
                    C[i][j] = TM.const(frame.C_MS[i-3][j])
                    continue
                items = []
                for k in range(6):
                    Tjk = frame.T[j][k]
                    if Tjk == 0:
                        continue
                    pk = JETS_MS[k] if k < 3 else JETS_MS[k-3]
                    arg1 = 'dxM' if k < 3 else 'dxS'
                    items.append(cross_tm(ks, ja, pk, arg1, 'dyv', _sign_beta(pk)).scale(Tjk))
                C[i][j] = TM.addmany(items)
        yjets = (0, 1, 2, 9, 10, 11)
        msjets = (3, 4, 5, 6, 7, 8)
        Grr = [[None]*12 for _ in range(12)]
        for i in range(12):
            for j in range(i, 12):
                if i in msjets and j in msjets:
                    Grr[i][j] = TM.const(frame.G12[i+3][j+3])
                elif i in yjets and j in yjets:
                    Grr[i][j] = TM.const(kcov(xjet(i), xjet(j), 'zero', 'zero'))
                Grr[j][i] = Grr[i][j]
        for i in yjets:
            ja = xjet(i)
            for j in msjets:
                fj = 6 + j
                jb = jb_of(j)
                arg1 = 'dxM' if fj <= 11 else 'dxS'
                t = cross_tm(ks, ja, jb, arg1, 'dyv', _sign_beta(jb))
                Grr[i][j] = t; Grr[j][i] = t
        CA = [[TM.addmany([C[i][k]*_tmscalar(frame.Ainv[k][j]) for k in range(6)])
               for j in range(6)] for i in range(12)]
        S1 = [[None]*12 for _ in range(12)]
        for i in range(12):
            for j in range(i, 12):
                S1[i][j] = TM.addmany([Grr[i][j]] + [-CA[i][k]*C[j][k] for k in range(6)])
                S1[j][i] = S1[i][j]
        mu1 = [TM.addmany([CA[i][k]*_tmscalar(frame.upin[k]) for k in range(6)])
               for i in range(12)]
        # stage-2 conditioning with the division POSTPONED: for the 2x2 block
        # Sigma_gg = [[a,c],[c,d]], adj = [[d,-c],[-c,a]], det = ad-c^2:
        #   S2 = S1 - Grg adj Grg^T / det   <=>   S2 = NUM/det
        # with NUM = det*S1 - Grg adj Grg^T  a pure TM-polynomial (sharp);
        # the box enclosure is one interval division at the end.
        K1 = max(1, min(24, int(mpf(eta1)/mpf('0.00012')) + 1))
        K2 = max(1, min(24, int(mpf(eta2)/mpf('0.00012')) + 1))
        a_t = S1[1][1]; d_t = S1[2][2]; c_t = S1[1][2]
        detgg_t = a_t*d_t - c_t*c_t
        detgg = detgg_t.eval_box_sub(K1, K2)
        self.detgg_t = detgg_t
        self.detgg = detgg
        ck(detgg.a > 0, 'coarse: det Sigma_gg not certified positive')
        mug_t = [mu1[1], mu1[2]]
        qnum_t = TM.addmany([mug_t[0]*d_t*mug_t[0], -(mug_t[0]*c_t*mug_t[1]),
                             -(mug_t[1]*c_t*mug_t[0]), mug_t[1]*a_t*mug_t[1]])
        qnum = qnum_t.eval_box_sub(K1, K2)
        qq = qnum/detgg
        q_lo = max(mpf(0), mpf(qq.a))
        self.pgrad_sup = mpf(iv.exp(-q_lo/2).b)/mpf((iv.mpf(2*pi)*iv.sqrt(detgg.a)).b)
        self.pgrad_inf = mpf(iv.exp(-qq.b/2).a)/mpf((iv.mpf(2*pi)*iv.sqrt(detgg.b)).b)
        irest = [0] + list(range(3, 12))
        Grg_t = [[S1[irest[i]][1+j] for j in range(2)] for i in range(10)]
        # numerator TMs for S2 and mu2 (stored for fine_hi sub-box evaluation)
        self.S2NUM = [[None]*10 for _ in range(10)]
        S2 = [[None]*10 for _ in range(10)]
        for i in range(10):
            for j in range(i, 10):
                Qf = TM.addmany([Grg_t[i][0]*d_t*Grg_t[j][0],
                                 -(Grg_t[i][0]*c_t*Grg_t[j][1]),
                                 -(Grg_t[i][1]*c_t*Grg_t[j][0]),
                                 Grg_t[i][1]*a_t*Grg_t[j][1]])
                NUM = detgg_t*S1[irest[i]][irest[j]] - Qf
                self.S2NUM[i][j] = NUM
                self.S2NUM[j][i] = NUM
                S2[i][j] = NUM.eval_box_sub(K1, K2)/detgg
                S2[j][i] = S2[i][j]
        self.mu2NUM = [None]*10
        mu2 = [None]*10
        for i in range(10):
            Qf = TM.addmany([Grg_t[i][0]*d_t*mug_t[0], -(Grg_t[i][0]*c_t*mug_t[1]),
                             -(Grg_t[i][1]*c_t*mug_t[0]), Grg_t[i][1]*a_t*mug_t[1]])
            NUM = detgg_t*mu1[irest[i]] - Qf
            self.mu2NUM[i] = NUM
            mu2[i] = NUM.eval_box_sub(K1, K2)/detgg
        self.detgg_t = detgg_t
        self.qnum_t = qnum_t
        self.etaK = (K1, K2)
        self.s_t2 = S2[0][0]
        self.mu_t = mu2[0]
        self.mu_H = [mu2[1+k] for k in range(9)]
        self.SH = [[S2[1+i][1+j] for j in range(9)] for i in range(9)]
        # v-marginal second moment M12' = E[h^2 | pins, grad=0] (interval inputs)
        eng = moment_engine(self.mu_H, [iv.mpf(0)]*9, self.SH)
        self.M12v = _pos_iv(moment_poly(eng, MONOS12, 9)[0])
        # mass bound: P(f in [b-ell, b] | pins, grad=0) <= min(1, ell/(sqrt(2pi) s_t))
        ell = r**3/6
        if self.s_t2.a > 0:
            m_by_sd = iv.mpf(ell)/(iv.sqrt(iv.mpf(2*pi)*self.s_t2))
            self.mass_sup = min(mpf(1), mpf(m_by_sd.b))
        else:
            self.mass_sup = mpf(1)
        # typing crush at the v-marginal law (Delta = 0 margins)
        PS = []
        for b, need in enumerate((+1, -1, -1)):
            mu_b = self.mu_H[3*b:3*b+3]
            Sb = [row[3*b:3*b+3] for row in self.SH[3*b:3*b+3]]
            md = block_margin_data(mu_b, [iv.mpf(0)]*3, Sb)
            detI = peval_iv(md['detp'], iv.mpf(0))
            margin = detI if need > 0 else -detI
            sL2 = peval_iv(md['sL2'], iv.mpf(0))
            PS.append(P_wrong_block(-margin, sL2, md['EQ2']).b)   # P(satisfaction) <= flip bound
        trM = self.mu_H[0] + self.mu_H[2]
        s_tr2 = self.SH[0][0] + self.SH[2][2] + 2*self.SH[0][2]
        if s_tr2.a > 0 and trM.a > 0:
            alo = trM.a/iv.sqrt(s_tr2.b)
            ps_tr = min(mpf(1), mpf(_mills_hi(alo).b)) if alo > 0 else mpf(1)
        else:
            ps_tr = mpf(1)
        PS[0] = min(PS[0], ps_tr)
        self.PS_min_sup = min(mpf(1), min(PS))
        self.I_hi = mpf(iv.sqrt(self.M12v).b)*mpf(iv.sqrt(iv.mpf(min(self.mass_sup, self.PS_min_sup))).b)
        self.rho_hi_noZ = self.pgrad_sup*self.I_hi

    def rho_hi(self, Z_lo):
        ck(Z_lo > 0, 'coarse rho needs positive Z lower bound')
        return self.rho_hi_noZ/mpf(Z_lo)

# ------------------------------------------------ float64 radius-form intervals
# Certified interval arithmetic: value in [c - r, c + r]; each operation pads
# the radius by EPS*|result| for float64 rounding (EPS = 8 ulp) plus a tiny
# absolute floor.  Deterministic, IEEE double, no directed rounding needed.
import math as _math

FI_EPS = 8.0*2.0**-53
FI_FLOOR = 1e-300


class FI:
    __slots__ = ('c', 'r')

    def __init__(self, c, r=0.0):
        self.c = float(c)
        self.r = float(r) + FI_FLOOR

    @staticmethod
    def from_iv(x):
        a = float(mpf(x.a)); b = float(mpf(x.b))
        return FI((a+b)/2, (b-a)/2)

    def __add__(self, o):
        c = self.c + o.c
        return FI(c, self.r + o.r + FI_EPS*abs(c))

    def __sub__(self, o):
        c = self.c - o.c
        return FI(c, self.r + o.r + FI_EPS*abs(c))

    def __mul__(self, o):
        c = self.c*o.c
        return FI(c, abs(self.c)*o.r + abs(o.c)*self.r + self.r*o.r + FI_EPS*abs(c))

    def scale(self, s):
        s = float(s)
        return FI(self.c*s, self.r*abs(s) + FI_EPS*abs(self.c*s))

    def lo(self):
        return self.c - self.r

    def hi(self):
        return self.c + self.r

    def sqrt_hi(self):
        ck(self.c - self.r >= 0, 'FI sqrt of straddling interval')
        return _math.sqrt(self.c + self.r)


def moment_engine_fi(mu, S):
    """Stein-recursion Isserlis engine over FI arithmetic (centered Gaussian).
    mu: list of FI (constant means), S: 9x9 (or n x n) list of FI."""
    n = len(mu)
    cache = {}

    def M(e):
        if e in cache:
            return cache[e]
        s = sum(e)
        if s == 0:
            cache[e] = FI(1.0)
            return cache[e]
        i = next(k for k in range(n) if e[k] > 0)
        ei = list(e); ei[i] -= 1
        ei = tuple(ei)
        acc = mu[i]*M(ei)
        for j in range(n):
            if ei[j] > 0:
                ej = list(ei); ej[j] -= 1
                acc = acc + S[i][j].scale(ei[j])*M(tuple(ej))
        cache[e] = acc
        return acc

    return M


def M12v_fi(mu_H, SH):
    """E[(detM detS dety)^2] under N(mu_H, SH) via FI Isserlis (v-marginal)."""
    eng = moment_engine_fi(mu_H, SH)
    tot = FI(0.0)
    for c, e in MONOS12:
        tot = tot + eng(_exp_tuple(e, 9)).scale(c)
    return tot


def shell_terms_fi(mu_H, SH, e2, e4):
    """Placeholder for the near-M shell route (see CoarseBox shell flag)."""
    return None


def fi_div(a, b):
    ck(b.c - b.r > 0, 'FI division by straddling interval')
    lo = min(a.lo()/b.lo(), a.lo()/b.hi(), a.hi()/b.lo(), a.hi()/b.hi())
    hi = max(a.lo()/b.lo(), a.lo()/b.hi(), a.hi()/b.lo(), a.hi()/b.hi())
    return FI((lo+hi)/2, (hi-lo)/2 + FI_EPS*abs(lo))


def mills_fi_hi(a):
    """Certified upper on standard-normal upper tail for a >= 0 (Mills)."""
    if a <= 0:
        return 1.0
    return min(1.0, _math.exp(-a*a/2)/_math.sqrt(2*_math.pi)/a*(1.0 + 1e-15) + 1e-300)


def margins_fi(mu_b, Sb, need):
    """Certified upper on P(block satisfaction) at the fixed law (FI).
    need=+1: P(det >= 0) <= P(wrong sign of -det) route; need=-1: P(det <= 0).
    Returns P(satisfaction) upper bound."""
    m0, m1, m2 = mu_b
    detm = m0*m2 - m1*m1
    g0, g1, g2 = m2, m1.scale(-2.0), m0
    sL2 = FI(0.0)
    for i in range(3):
        for j in range(3):
            sL2 = sL2 + (g0 if i == 0 else (g1 if i == 1 else g2))*Sb[i][j]*(g0 if j == 0 else (g1 if j == 1 else g2))
    trQS = Sb[0][2] - Sb[1][1]
    QS = [[Sb[2][k].scale(0.5) for k in range(3)],
          [Sb[1][k].scale(-1.0) for k in range(3)],
          [Sb[0][k].scale(0.5) for k in range(3)]]
    QSQtr = FI(0.0)
    for i in range(3):
        for j in range(3):
            QSQtr = QSQtr + QS[i][j]*QS[j][i]
    EQ2 = QSQtr.scale(2.0) + trQS*trQS
    margin = detm if need > 0 else detm.scale(-1.0)
    mlo = margin.lo()
    if mlo <= 0:
        return 1.0
    sLhi = _math.sqrt(sL2.hi()) if sL2.hi() > 0 else 0.0
    if sLhi <= 0:
        p_dev = 0.0
    else:
        p_dev = 2* mills_fi_hi(mlo/(2*sLhi))
    p_q = EQ2.hi()/(mlo/2)**2
    return min(1.0, p_dev + p_q)


def coarse_fine_hi(cb, Z_lo, K):
    """Sub-box fine evaluation of a CoarseBox: partition the box into K x K
    sub-boxes; per sub-box compute certified pgrad_sup, I_hi (FI Isserlis on
    the postponed-division conditional law, window-mass crush, typing crush),
    and sum area_sub * rho_hi_sub.  Captures the pgrad x I correlation that
    the box-global bound loses."""
    _set_TD(6)
    detgg_t = cb.detgg_t
    qnum_t = cb.qnum_t
    tot = 0.0
    r = cb._r
    eta1, eta2 = cb.eta1, cb.eta2
    B_ = mpf('1.2')
    ell = r**3/6
    area_sub = 4*float(mpf(eta1))*float(mpf(eta2))/K**2
    M12g = float(mpf(cb.M12v.b))
    n_cells = 0
    for ai in range(K):
        u1 = iv.mpf([-eta1 + 2*eta1*ai/K, -eta1 + 2*eta1*(ai+1)/K])
        for bi in range(K):
            u2 = iv.mpf([-eta2 + 2*eta2*bi/K, -eta2 + 2*eta2*(bi+1)/K])
            det = FI.from_iv(detgg_t.eval_iv(u1, u2))
            det.r += float(mpf(detgg_t.R.b))
            ck(det.lo() > 0, 'fine: detgg not positive on sub-box')
            qn = FI.from_iv(qnum_t.eval_iv(u1, u2))
            qn.r += float(mpf(qnum_t.R.b))
            qq = fi_div(qn, det)
            q_lo = max(0.0, qq.lo())
            pg_sup = _math.exp(-q_lo/2)/(2*_math.pi*_math.sqrt(det.lo()))*(1+1e-14)
            mu2 = [None]*10
            SH = [[None]*10 for _ in range(10)]
            for i in range(10):
                NUM = cb.mu2NUM[i]
                v = FI.from_iv(NUM.eval_iv(u1, u2))
                v.r += float(mpf(NUM.R.b))
                mu2[i] = fi_div(v, det)
            for i in range(10):
                for j in range(i, 10):
                    NUM = cb.S2NUM[i][j]
                    v = FI.from_iv(NUM.eval_iv(u1, u2))
                    v.r += float(mpf(NUM.R.b))
                    SH[i][j] = fi_div(v, det)
                    SH[j][i] = SH[i][j]
            s_t2 = SH[0][0]
            mu_t = mu2[0]
            mu_H = [mu2[1+k] for k in range(9)]
            SHH = [[SH[1+i][1+j] for j in range(9)] for i in range(9)]
            # mass bound (window crush)
            if s_t2.lo() > 0:
                s_t_hi = _math.sqrt(s_t2.hi())
                t_lo = fi_div(FI(float(B_ - ell)) - mu_t, FI(s_t_hi))
                t_hi = fi_div(FI(float(B_)) - mu_t, FI(s_t_hi))
                tlo, thi = t_lo.lo(), t_hi.hi()
                if tlo > 0:
                    w0 = tlo
                elif thi < 0:
                    w0 = -thi
                else:
                    w0 = 0.0
                mass = min(1.0, float(mpf(ell))/ (_math.sqrt(2*_math.pi)*max(_math.sqrt(s_t2.lo()), 1e-300))
                           * _math.exp(-w0*w0/2)*1.000001 + FI_FLOOR)
            else:
                mass = 1.0
            # typing crush
            PS = 1.0
            for b in range(3):
                need = +1 if b == 0 else -1
                mub = mu_H[3*b:3*b+3]
                Sbb = [row[3*b:3*b+3] for row in SHH[3*b:3*b+3]]
                PS = min(PS, margins_fi(mub, Sbb, need))
            trM = mu_H[0] + mu_H[2]
            str2 = SHH[0][0] + SHH[2][2] + SHH[0][2].scale(2.0)
            if trM.lo() > 0 and str2.hi() > 0:
                PS = min(PS, mills_fi_hi(trM.lo()/_math.sqrt(str2.hi())))
            crush = min(mass, PS)
            if crush < 1e-40:
                I_hi = _math.sqrt(M12g*crush)
            else:
                M12 = M12v_fi(mu_H, SHH)
                I_hi = _math.sqrt(max(M12.hi(), 0.0)*crush)
            tot += area_sub*pg_sup*I_hi
            n_cells += 1
    return tot/float(Z_lo)




# ------------------------------------------------------- near-pin shell bound
def _det_monos_block(b):
    """Monomials of det H_block as (coef, ((idx,p),...)) over the 9 Hessian
    indices (blocks of 3: X_3b, X_3b+1, X_3b+2)."""
    return [(1.0, ((3*b, 1), (3*b+2, 1))), (-1.0, ((3*b+1, 2),))]


def _mono_prod_f(ma, mb):
    out = {}
    for ca, ea in ma:
        for cb_, eb in mb:
            d = dict(ea)
            for i, p in eb:
                d[i] = d.get(i, 0) + p
            key = tuple(sorted(d.items()))
            out[key] = out.get(key, 0.0) + ca*cb_
    return [(c, e) for e, c in out.items()]


def shell_hi_fi(mu_H, SHH):
    """Certified upper on g = E[|detM detS dety| 1{detM>0} 1{dety<0}] near M
    (and the S-symmetric version), via the shell {0 < detM < -Delta},
    Delta = dety - detM:
      g <= (p_sup/2) E[Delta^2 |detS| |dety|]
         <= (p_sup/4) (E[Delta^2 detS^2] + E[Delta^2 dety^2])
    with p_sup = 1/sqrt(2 pi s2_cond), s2_cond = Var(L_A | L_Delta) the
    conditional variance of the LINEAR parts (the density bound is exact:
    p_{A|Delta}(x) <= sup p_{L_A|L_Delta} by the mixture argument)."""
    eng = moment_engine_fi(mu_H, SHH)

    def lin_det(b):
        m0, m1, m2 = mu_H[3*b], mu_H[3*b+1], mu_H[3*b+2]
        return (m2, m1.scale(-2.0), m0)   # grad det at the mean

    def s2_lin(g1, b1, g2, b2):
        acc = FI(0.0)
        for i in range(3):
            for j in range(3):
                acc = acc + g1[i]*SHH[3*b1+i][3*b2+j]*g2[j]
        return acc

    M0 = _det_monos_block(0)
    M1 = _det_monos_block(1)
    M2 = _det_monos_block(2)
    M00 = _mono_prod_f(M0, M0)
    M11 = _mono_prod_f(M1, M1)
    M22 = _mono_prod_f(M2, M2)

    def Em(ma, mb):
        tot = FI(0.0)
        for c, e in _mono_prod_f(ma, mb):
            tot = tot + eng(_exp_tuple(e, 9)).scale(c)
        return tot

    # shell between M (max-typed) and y (saddle): {0 < detM < -Delta},
    # Delta = dety - detM.  g <= (p_sup/4)(E[Delta^2 detS^2] + E[Delta^2 dety^2]).
    gA = lin_det(0)
    gy = lin_det(2)
    sA = s2_lin(gA, 0, gA, 0)
    sy = s2_lin(gy, 2, gy, 2)
    sAy = s2_lin(gA, 0, gy, 2)
    sD = sA + sy - sAy.scale(2.0)
    cAD = sAy - sA
    if sD.lo() <= 0 or sA.lo() <= 0:
        return 1e300
    s2c = sA - cAD*cAD*fi_div(FI(1.0), sD)
    if s2c.lo() <= 0:
        return 1e300
    p_sup = 1.0/_math.sqrt(2*_math.pi*s2c.lo())
    M22_ = M22
    E_dS = Em(M22_, M11) + Em(M00, M11) - Em(_mono_prod_f(M2, M0), M11).scale(2.0)
    E_dy = Em(M22_, M22) + Em(M00, M22) - Em(_mono_prod_f(M2, M0), M22).scale(2.0)
    Esum = E_dS + E_dy
    g = Esum.scale(p_sup/4.0)
    return max(g.hi(), 0.0)
