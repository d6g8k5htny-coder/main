#!/usr/bin/env python3
"""
make_receipts.py -- regenerate the H2 foundations receipts and MANIFEST.

Fail-closed: refuses to write receipts unless both self-test transcripts exist,
end in their PASS markers, and are byte-identical across python / python -O.
Deterministic: no wall clock; sorted keys; fixed formatting.
"""
import hashlib
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def ck(cond, msg="check"):
    if not cond:
        print("CHECK FAILED:", msg)
        raise SystemExit(1)
    print("[ok]", msg)


def sha256(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def versions():
    import mpmath, sympy
    return {"python": sys.version.split()[0], "mpmath": mpmath.__version__,
            "sympy": sympy.__version__}


def receipt(lib, selftest, tx_n, tx_o, pass_marker, summary):
    pn, po = os.path.join(HERE, tx_n), os.path.join(HERE, tx_o)
    ck(os.path.exists(pn) and os.path.exists(po), "%s transcripts exist" % lib)
    tn = open(pn).read()
    to = open(po).read()
    ck(pass_marker in tn, "%s normal transcript carries %s" % (lib, pass_marker))
    ck(tn == to, "%s transcripts byte-identical (normal vs -O)" % lib)
    rec = {
        "library": lib,
        "selftest": selftest,
        "pass_marker": pass_marker,
        "environment": versions(),
        "sha256": {
            lib: sha256(os.path.join(HERE, lib)),
            selftest: sha256(os.path.join(HERE, selftest)),
            tx_n: sha256(pn),
            tx_o: sha256(po),
        },
        "transcript_lines": len(tn.splitlines()),
        "summary": summary,
        "status": "PASS",
    }
    out = os.path.join(HERE, "RECEIPT_%s.json" % lib.split(".")[0])
    with open(out, "w") as f:
        json.dump(rec, f, indent=2, sort_keys=True)
        f.write("\n")
    print("[ok] wrote", os.path.basename(out))
    return out


r1 = receipt(
    "cov_exact.py", "selftest_cov_exact.py",
    "selftest_cov_exact_normal.txt", "selftest_cov_exact_O.txt",
    "SELFTEST_COV_EXACT: PASS",
    {
        "certified_tails": "spectral < 1e-60 (n=0..8, KMAX=30); image < 1e-60 (|s|<=12, JMAX=3); moment Poisson < 1e-700",
        "adversarial_cross_impl": "10080 comparisons, separations +/-{0,0.006,0.0375,0.58,1.45,1.62}, total order <= 4, max dev 2.0e-100 < 1e-50",
        "odd_order_regression": "raw 2D phase-shifted-cosine route, both signs, near-zero, largest radius 1.62: max dev 5.0e-101 < 1e-45",
        "endpoint": "24 odd-total-order pairs exactly 0 at r=0; even entries = exact torus moment products",
        "hermite_cancellation": "Var cubic coordinate -> a_6/144, correction -a_8 r^2/2880 confirmed at r=1e-3 and 1e-5",
        "moments": "1-a_2 = 9.65254179896e-123 (identity, 150 dps); |a_4-3|, |a_6-15|, |a_8-105| strictly in (0, 1e-100)",
        "interval_path": "iv enclosures contain mpf values; 1D widths < 1e-55; covariance widths < 1e-50; tails carried",
        "mutations_rejected_both_modes": ["sine_drop", "planar_moments"],
    })

r2 = receipt(
    "pin_transform.py", "selftest_pin_transform.py",
    "selftest_pin_transform_normal.txt", "selftest_pin_transform_O.txt",
    "SELFTEST_PIN_TRANSFORM: PASS",
    {
        "symbolic_verifications": [
            "det V = -1 (row-major), det D_r = r^9, det R_r = r^4, chain = -r^{-5}",
            "T_r = D_r^{-1} V^{-1} R_r == displayed T_r exactly (sympy)",
            "det T_r = -r^{-5}; u_r = (b-r^3/12, -r^2/4, 0,0,0, 1/3)",
            "det B_r = r^{-5}, det C_r = -1, T_r = C_r B_r",
            "Hermite exactness T_r P6(p) = c through the cubic span",
            "column-major V: same det -1, formula FAILS (convention load-bearing)",
        ],
        "numeric": "T_r numeric==symbolic at 5 rungs (mpf+iv); u_r at 5 rungs; Gamma_U -> Gamma_0 with ratio 100.0 (quadratic)",
        "certified_inverse": "normalized frame kappa_cert=20.11, kappa*eps=2.01e-15 <= 1e-8 at r=1e-5; raw frame refused at r=1e-5 and r=0.025 (kappa*eps = 1.66e16 / 6.8e-5), certified at r=0.5",
        "mutations_rejected_both_modes": ["transpose_T", "cubic_sign", "drop_trapezoid", "raw_inverse_unsafe"],
    })

r3 = receipt(
    "reg_lemmas.py", "selftest_reg_lemmas.py",
    "selftest_reg_lemmas_normal.txt", "selftest_reg_lemmas_O.txt",
    "SELFTEST_REG_LEMMAS: PASS",
    {
        "OBL-B1-REG-G4": "pinned-pair Bulinskaya at rank 3: rank exactly 3 certified at 17 probe points; certified active floor 6.16287e-3 > 6.1e-3 on the d>=1 grid (midpoint 6.16467e-3; B2b 6.2e-3); near-pin rate certified lambda_min ~ C d^6 with C > 0 (B2b's ~d^8 / 2.4e-22 was below the float64 noise floor; certified lambda_min(d=0.002) = 5.62305e-20 lower bound, midpoint 7.31e-20); Var(f_xxx|pins) ~ 6 r^2 (5.967/5.992/5.998); H(M)|pins PD lambda_min ~ r^4 (1.04115e-6 at r=0.05; exponents 3.998/3.999); isolation zone radii 3 lambda/K3 (values) and 2 lambda/K3 (critical points) sympy-verified",
        "OBL-B1-REG-G1": "Morse bootstrap for the near-diagonal regime: Upair lambda_min ~ delta^6 (exponent 5.999 certified); 4.15612e-8 at delta=0.1 (B2b 4.2e-8); 4.167e-20 at 1e-3; separated-pair floor 9.9912e-6 > 1e-6; bootstrap inequality |det H(x)| <= (K2 K3/2) delta and expected count <= 576 eta/(2 pi floor) -> 0",
        "OBL-B1-REG-G5": "general full-rank lemma (linear independence of derivative evaluations at distinct torus points; README proof) + certified per-configuration floors: 11-jet 7.57065e-11 (B2b 7.6e-11); near-pin 11-jet 1.314e-12; pair+pins 3.244e-10; 14-jet 0.3776; ten-jet endpoint anchor 0.12655345 (floor 0.0817) marking the citation's exact scope",
    })

# MANIFEST over every file in the directory (excluding itself), sorted
names = sorted(fn for fn in os.listdir(HERE)
               if os.path.isfile(os.path.join(HERE, fn)) and fn != "MANIFEST.sha256")
with open(os.path.join(HERE, "MANIFEST.sha256"), "w") as fh:
    for fn in names:
        fh.write("%s  %s\n" % (sha256(os.path.join(HERE, fn)), fn))
print("[ok] wrote MANIFEST.sha256 (%d files)" % len(names))
print("RECEIPTS_AND_MANIFEST: PASS")
