# H2 foundations — shared libraries for the 2D upper-theorem campaign

Work-order items 176–197 (Stage A, dispatch H2). Owner: H2 foundations agent.
Date: 2026-09-13. Environment: python 3.12.12, mpmath 1.3.0, sympy 1.14.0
(matches REVIEW_LPW/ENVIRONMENT_LOCK.json).

Two SHARED libraries that every upper-theorem agent consumes:

| file | role |
|---|---|
| `cov_exact.py` | LIBRARY 1: exact-periodic covariance library (importable) |
| `pin_transform.py` | LIBRARY 2: canonical exact-pin transformation library (importable) |
| `selftest_cov_exact.py` | fail-closed self-test C1–C12 for library 1 |
| `selftest_pin_transform.py` | fail-closed self-test P1–P12 for library 2 |
| `selftest_*_{normal,O}.txt` | transcripts, byte-identical across `python` / `python -O` |
| `RECEIPT_cov_exact.json`, `RECEIPT_pin_transform.json` | receipts (separate) |
| `make_receipts.py` | deterministic receipt/manifest regenerator (fail-closed) |
| `reg_lemmas.py` | Lemma-R regularity certificates (G1/G4/G5 addendum; importable) |
| `selftest_reg_lemmas.py` | fail-closed self-test R1–R7 for the addendum |
| `MANIFEST.sha256` | sha256 of every file in this directory (incl. this README) |

## LIBRARY 1 — `cov_exact.py` usage contract

The law: exact normalized periodized side-24 2D Bargmann–Fock field, spectral
lattice (π/12)ℤ², masses e^{−|k|²/2}, Z-normalized:
`K(x,y) = Z^{-2} Σ_k w(k) e^{ik·(x−y)} = K1(x1−y1) K1(x2−y2)`,
`Z = Σ_{j∈(π/12)ℤ} e^{−j²/2}`, `K1(0) = 1` exactly.

Importing sets `mp.dps = iv.dps = 100` (≥ 60 house floor; `configure(dps=…)`
refuses < 60 and re-certifies the tails fail-closed).

Entry points (all validate inputs and raise `CovInputError`; no bare asserts):

- `cov(alpha, beta, dx, dy, impl='spectral', mode='mpf')` —
  `Cov(∂^α f(x), ∂^β f(y)) = (−1)^{|β|} K1^{(α1+β1)}(dx) K1^{(α2+β2)}(dy)`,
  multi-indices as int pairs, separation `(dx, dy) = x − y`, total order ≤ 8
  (certified ceiling). Cosine AND sine contributions are automatic via the
  derived parity decomposition: even order n → (−1)^{n/2}·E_n (cosine sum),
  odd n → (−1)^{(n+1)/2}·S_n (sine sum). **Odd-order sine terms are never
  dropped** (RB_R2 rung-table errata of record).
- `k1(n, s, impl, mode)`, `k1_spectral`, `k1_image`, `e_sum`, `s_sum`,
  `hermite_he`. `impl='image'` is the second implementation (wrapped-kernel
  image sums with exact Hermite derivatives, NO spectral sums), 24-periodic
  wrap certified by interval containment.
- `mode='mpf'` fast path; `mode='iv'` interval path (`iv.mpf`) **carrying the
  certified truncation tails** — theorem constants must be consumed from the
  iv path or from mpf values plus the exposed tail functions.
- Certified tails (computed in-program, interval-verified):
  `spectral_tail_1d(n)` < 1e-60 for n = 0..8 at KMAX = 30;
  `image_tail_1d(n, smax)` < 1e-60 for n = 0..8, |s| ≤ 12 at JMAX = 3;
  `moment_poisson_tail(m)` < 1e-700.
- Moments: `moment_a(m)` (exact finite-torus a_{2m} = (1/Z)Σ w k^{2m},
  THE theorem entry point), `moment_a_poisson(m)` (independent real-space
  identity), `one_minus_a2_poisson()` (exact identity
  `1 − a₂ = 576 Σn²e^{−288n²}/Σe^{−288n²}`), `planar_moment(m)` —
  **labeled diagnostic only**; the finite-torus moments are never planar
  (0 < |a_{2m} − (2m−1)!!| < 1e-100, tested strictly; e.g.
  1 − a₂ = 9.65254179896e-123 > 0).

## LIBRARY 2 — `pin_transform.py` usage contract

- Raw pins `P6_r = (f(M), f_x(M), f_y(M), f(S), f_x(S), f_y(S))`,
  `M = (−r/2, 0)`, `S = (r/2, 0)` (order pinned in `P6_ORDER`).
- Corrected typed pair-Palm basis `V_r = B_r P6_r` (`matrix_B`), with the
  trapezoidal correction `−(r/2)(∂₁f(S)+∂₁f(M))` in the cubic coordinate.
- Hermite-normalized `U_r = T_r P6_r`, `T_r = D_r^{−1} V^{−1} R_r`
  (`matrix_T`), with **row-major V** (`V[i][j] = evaluation_i(basis_j)`;
  det V = −1; the column-major transpose has the same det but does NOT
  satisfy the formula — tested as an explicit negative control).
- Symbolically verified (sympy exact): `T_r == displayed T_r`,
  `det T_r = −r^{−5}`, `det D_r = r^9`, `det R_r = r^4`, `det B_r = r^{−5}`,
  `det C_r = −1`, `T_r = C_r B_r`,
  `u_r = T_r(b,0,0,b−r³/6,0,0)ᵀ = (b−r³/12, −r²/4, 0,0,0, 1/3)ᵀ`,
  and Hermite exactness `T_r P6(p) = c` through the cubic span.
- Numeric paths: `matrix_T_num(r, mode)`, `apply_T(p6, r, mode)`,
  `transform_cov(G, r, mode)`, `pin_covariance(r, impl, mode)` (cov_exact),
  mpf and iv.
- `certified_inverse(G, r, frame='normalized', consumer_eps=1e-16)`:
  interval Neumann-series certificate (ρ = ‖I − AB‖_F < 1/2),
  κ_cert = ‖A‖_F(‖B‖_F + err); **refuses** (`CertificationError`) unless
  κ_cert·consumer_eps ≤ 1e-8. Normalized frame at r = 1e-5: κ = 20.11,
  κ·ε = 2.0e-15 — certified. Raw frame at r = 1e-5: κ·ε = 1.66e16 —
  refused; at r = 0.025: κ·ε = 6.8e-5 — refused; at r = 0.5: κ·ε = 1.0e-12 —
  certified. Never treat the nearly singular raw covariance inverse as
  numerically safe without normalization (κ ∼ r^{−6.1}).

## Mutations (each rejected fail-closed, both modes)

Library 1 (`MUTATION=` on `selftest_cov_exact.py`): `sine_drop` (the RB_R2
defect; caught at C4 with O(1) deviations), `planar_moments` (caught at C9).
Library 2 (`MUTATION=` on `selftest_pin_transform.py`): `transpose_T`,
`cubic_sign`, `drop_trapezoid` (all caught at P2 vs the displayed T_r),
`raw_inverse_unsafe` (caught at P11: the guard bypass is detected and the
certificate arithmetic itself condemns the raw frame).

## Reproduction

```
python3 selftest_cov_exact.py > selftest_cov_exact_normal.txt 2>&1
python3 -O selftest_cov_exact.py > selftest_cov_exact_O.txt 2>&1
python3 selftest_pin_transform.py > selftest_pin_transform_normal.txt 2>&1
python3 -O selftest_pin_transform.py > selftest_pin_transform_O.txt 2>&1
python3 make_receipts.py
```

Each self-test exits 0 with its PASS marker; transcripts are byte-identical
across modes (sha256 below). All code deterministic, no wall clock.

## sha256 of record (code + transcripts)

```
f08c1c5f653f2ffd2e85d39e1112f80d15db04d15f932e5ee42db2ca3553e783  cov_exact.py
c6988ac7fcfa32dcc03c1374e13fb4c26af1c12c25cb824a315e6dce8991fd41  pin_transform.py
e1b331dec6e0f82e6a084a30d9df9d8f402f42057861e6875504b04ea4a32068  selftest_cov_exact.py
90e88ff8f5248332219902caf6ea4df5bb5b89ffa72b95b519fd4472860403a6  selftest_pin_transform.py
cb6c0f2fb4350f2e5707ebf730b4ab74f7c5d733208a74649bc3cb7aab6ac27e  make_receipts.py
9c7838d1d4a9b181afb6e7ae94f46c588894232835236abba49abb69af35d30d  selftest_cov_exact_normal.txt
9c7838d1d4a9b181afb6e7ae94f46c588894232835236abba49abb69af35d30d  selftest_cov_exact_O.txt
7eeb845e063579444103097f5f8a9b7f5cecedafcfd68c3f4355e0a981c3acc2  selftest_pin_transform_normal.txt
7eeb845e063579444103097f5f8a9b7f5cecedafcfd68c3f4355e0a981c3acc2  selftest_pin_transform_O.txt
e7005a5af73d80bc1e129ac17ed19ae3d5df5d6667b076efa311f24247043450  reg_lemmas.py
27505d0196e39a0c47989c443f402aa2ad23bdf235771ea1bbdee1030efad65b  selftest_reg_lemmas.py
9d852eebddecc2ee5054ef87b61cb7149ab28cfe7dd7bf501f14c038771a2e18  selftest_reg_lemmas_normal.txt
9d852eebddecc2ee5054ef87b61cb7149ab28cfe7dd7bf501f14c038771a2e18  selftest_reg_lemmas_O.txt
```

(README.md, the two receipts, and every file above are hashed in
`MANIFEST.sha256`, the authoritative hash list.)

---

# Addendum — Lemma-R regularity obligations (from adversary B2b's
# NO-BREAK-WITH-CONCERNS verdict on B1's taxonomy), 2026-09-13

New files: `reg_lemmas.py`, `selftest_reg_lemmas.py`,
`selftest_reg_lemmas_{normal,O}.txt` (byte-identical), `RECEIPT_reg_lemmas.json`.
All numbers interval-certified on the exact periodized field (iv path, tails
carried). Each obligation closes with its exact falsifiers: recomputation
disagreeing beyond the stated window kills the certificate.

## OBL-B1-REG-G4 — pinned-pair Bulinskaya at rank 3 + near-pin isolation (CLOSED)

The 5-dim pair map V5(x;M) = (∇f(x), ∇f(M), f(x)−f(M)) has no density under
Q_r for pairs involving a pin: ∇f(M), f(M) are a.s.-constant, conditional
covariance rank exactly 3 (two structural zeros; certified at 17 points).
The missed class is Crit ∩ f⁻¹(b)\{M} and Crit ∩ f⁻¹(s)\{S} — the B3 tie
class. Derivation (certified pieces in selftest R1–R5):

1. **Rank-3 Bulinskaya away from pins.** For the rank-3 active map
   x ↦ (∇f(x), f(x) − b): Σ₃(x) = Cov(· | six pins) is PD at every free x
   (G5 algebraic lemma below) — hence on every compact K ⊂ T²\{M,S} a
   positive floor Λ(K) > 0 exists (continuity + compactness + pointwise PD),
   the density at (0, b) is ≤ (2π)^{−3/2} Λ(K)^{−3/2}, and Bulinskaya gives
   Q_r(∃x ∈ K: ∇f(x) = 0, f(x) = b) = 0. Certified floor on B2b's
   deterministic d ≥ 1 grid: **λ_min ≥ 6.16287e-3** (midpoint 6.16467e-3;
   B2b's float64 witness 6.2e-3).
2. **Near-pin rate (corrected).** λ_min(Σ₃(M + d·u)) ~ C(r,u) d⁶, C > 0,
   certified by interval enclosures at d = 0.2 … 5e-4 in two directions
   (asymptotic local exponents 6.04–6.27 → 6; C = λ/d⁶ stabilizes within a
   factor 2). The mechanism, certified: conditioning on the six pins leaks
   the along-axis third jet, Var(f_xxx | pins) ~ 6 r² (5.967/5.992/5.998 over
   r = 0.1/0.05/0.025), the other third-jet directions O(1); the residual
   direction f(x) − b − ½uᵀ∇f(x) = −(7/12)T(u) + O(d⁴) gives the d⁶.
   **B2b's "2.4e-22 at d ≈ 0.002, ~d⁸" is a float64 artifact**: an
   O(1)-norm matrix's eigvalsh noise floor is ~1e-16; the certified 100-dps
   value is λ_min(0.002) ∈ [5.62305e-20, 1.17e-19] — >100× their number, at
   the d⁶ rate. The d⁶ decay is *stronger* than d⁸; the isolation conclusion
   is unchanged.
3. **Near-pin isolation (sympy-verified algebra).** On
   A_{λ,K₃} = {−H(M) ⪰ λI, ‖f‖_{C³} ≤ K₃}, writing g(t) = f(M + t u) − b:
   g(t) ≤ −λt²/2 + K₃t³/6 = (t²/6)(K₃t − 3λ) < 0 for 0 < t < 3λ/K₃, and
   |∇f(M + tu)| ≥ λt − K₃t²/2 = (t/2)(2λ − K₃t) > 0 for 0 < t < 2λ/K₃ — a
   deterministic zone around M with no b-level points and no critical points
   at all (same at S, sign-flipped). H(M) | pins is nondegenerate Gaussian:
   certified PD with λ_min ~ r⁴ (1.04115e-6 at r = 0.05; exponents
   3.998/3.999) — so λ > 0 a.s. under Q_r, and under the weighted law
   P_r ≺≺ Q_r on {W_r > 0} (open cone {H(M) ≺ 0} has a density).
   ‖f‖_{C³} < ∞ a.s. (analytic field on a compact torus). Union over
   A_{1/n,n}: Q_r(tie class) = 0 ⇒ P_r(tie class) = 0.

## OBL-B1-REG-G1 — near-diagonal Morse bootstrap (CLOSED)

The pair map covers only compacta away from the diagonal: Upair(x,y) =
(∇f(x), ∇f(y), f(x)−f(y)) given the pins has λ_min(δ) ~ c δ⁶ — certified
exponent 5.999 (δ = 0.1 → 1e-3): genuinely ~0 at 1e-3 (4.167e-20). B2b's
4.2e-8 at δ = 0.1 reproduced with enclosure: **4.15612e-8**. Separated-pair
floor certified on B2b's pair grid: **9.9912e-6 > 1e-6**.

Bootstrap derivation: a coincidence (∇f(x) = ∇f(y) = 0, f(x) = f(y)) at
separation δ, on {‖f‖_{C²} ≤ K₂, ‖f‖_{C³} ≤ K₃}, forces, with
v = (y−x)/δ and Taylor–Lagrange,
  |H(x) v| ≤ (K₃/2) δ,  |vᵀ H(x) v| ≤ (K₃/3) δ
  ⇒ σ_min(H(x)) ≤ (K₃/2) δ ⇒ |det H(x)| ≤ (K₂ K₃/2) δ.
Kac–Rice under Q_r: the expected number of critical points with
|det H| ≤ η is
  N(η) = ∫ p_{∇f(x)|pins}(0) E[|det H| 1{|det H| ≤ η} | ∇f = 0, pins] dx
       ≤ 576 · η / (2π · floor)
(trivial bound |det H| 1{·} ≤ η — no Hessian density needed; the gradient
density bound uses the G4 floor away from pins, and the isolation zone
excludes critical points near pins on the truncation events). With
η = (K₂K₃/2) d₀ the probability of any coincidence pair at separation ≤ d₀
on the truncation event is ≤ const·d₀ → 0; union over truncation levels ⇒
the accumulating-coincidence class is Q_r-null, hence P_r-null. Off-diagonal
pairs are covered by the separated-pair Bulinskaya (floor above; every
distinct pair is algebraically full-rank by G5).

## OBL-B1-REG-G5 — general full-rank lemma (CLOSED, exact scope stated)

**Lemma.** Let x₁,…,x_m ∈ T² = R²/24Z² be distinct and {α_j} finite
multi-index sets. The Gaussian vector (∂^{α_j} f(x_j)) under the periodized
law — and jointly with the six pins whenever r > 0 (M ≠ S) — has a
positive-definite covariance.
**Proof.** The covariance is the Gram of g_{j,α}(k) = (ik)^α e^{ik·x_j} in
L²(μ), μ = Σ_{k∈(π/12)Z²} e^{−|k|²/2} δ_k (full support on the lattice).
If Σ c_{j,α} g_{j,α} = 0 a.e.(μ), then for all n ∈ Z²:
Σ_j q_j(n) e^{i(π/12)n·x_j} = 0 with q_j(n) = Σ_α c_{j,α}(i(π/12)n)^α.
The characters n ↦ e^{i(π/12)n·x} are distinct iff x is distinct mod 24
(equality ∀n ⟺ x − x' ∈ 24Z²). Exponential–polynomial sequences on Z² with
distinct frequencies are linearly independent (restrict to a lattice ray
n = t·v: distinct frequencies have incomparable growth; equal frequencies
leave polynomial independence), so each q_j ≡ 0, and the monomials n^α are
independent, so all c_{j,α} = 0. A Gram of linearly independent vectors is
PD. ∎

**Exact scope (the generalization the citation lacks):** full rank is
pointwise-in-configuration. NO uniform floor exists over configurations;
the certified degeneracy rates are the catalogue: pin-adjacent structures
(H(M)|pins ~ r⁴, third jet along-axis ~ 6r², raw pin block ~ r⁶-scale),
diagonal ~ δ⁶, near-pin ~ d⁶. Per-configuration floors are certified
on demand by `reg_lemmas.gram_eigfloor_certificate` (interval Neumann
inverse bound, fail-closed). The corpus's cited ten-jet result is exactly
one instance: endpoint λ_min = 0.12655345 (certified floor 0.0817) —
a single-endpoint eigenfloor only.

Certified instances (r = 0.05): 11-jet (J5(x) + 6 pins) floor over B2b's
three probes **7.571e-11 > 1e-12**, at (1,0.5) λ_min = **7.57065e-11**
(B2b 7.6e-11); (∇f(x),H(x)) + pins at d = 0.16 from M: floor 1.314e-12;
pair map + pins at a distinct pair: 3.244e-10; arbitrary 14-jet
three-point configuration: 0.3776.

## Exact falsifiers (recompute to kill)

| anchor | certified value (window) |
|---|---|
| G4 grid floor (d ≥ 1, r = 0.05) | 6.16467e-3 ± 2e-6 (certified lower bound 6.16287e-3) |
| G4 near-pin λ_min(d = 0.002), u = (1,0.3)-ray | ∈ [5e-20, 2e-19], NOT 2.4e-22 (float64 noise) |
| G4 near-pin asymptotic exponent | ∈ (5.5, 6.5), → 6 |
| G4 Var(f_xxx \| pins)/r² | ∈ (4, 9) at r = 0.1/0.05/0.025 (5.967/5.992/5.998) |
| G4 λ_min(H(M) \| pins), r = 0.05 | 1.04115e-6 ± 3e-8; rate r⁴ (3.998, 3.999) |
| G1 λ_min(Upair, δ = 0.1) | 4.15612e-8 ± 5e-10; rate δ⁶ (5.999) |
| G1 separated-pair grid floor | 9.9912e-6 > 1e-6 |
| G5 11-jet λ_min at (1,0.5), r = 0.05 | 7.57065e-11 ± 3e-13 |
| G5 ten-jet endpoint anchor | 0.12655345 ∈ [0.126, 0.127], certified floor > 0.08 |

Run: `python3 selftest_reg_lemmas.py` (PASS marker
`SELFTEST_REG_LEMMAS: PASS`), same under `python3 -O`; transcripts
byte-identical. Isolation algebra is sympy-verified in R5.
