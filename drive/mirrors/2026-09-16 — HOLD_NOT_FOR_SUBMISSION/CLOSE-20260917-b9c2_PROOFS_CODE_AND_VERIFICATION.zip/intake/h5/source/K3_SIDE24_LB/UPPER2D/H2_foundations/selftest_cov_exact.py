#!/usr/bin/env python3
"""
selftest_cov_exact.py -- fail-closed self-test for cov_exact.py (H2 LIBRARY 1).

Covers, in order:
  C1  configuration guards and in-program certified tails (< 1e-60 at the
      default cutoff, spectral n = 0..8; image tails at |s| <= 12 and at the
      adversarial radius 1.62);
  C2  kernel normalization K1(0) = 1 exactly and endpoint parity;
  C3  separation parity K1^{(n)}(-s) = (-1)^n K1^{(n)}(s), both
      implementations, positive AND negative separations;
  C4  DENSE ADVERSARIAL cross-implementation comparison: separations
      +/- {0, 0.006, 0.0375, 0.58, 1.45, 1.62} (grid), all derivative pairs
      (alpha, beta) with total order <= 4; agreement < 1e-50;
  C5  odd-total-order regression at NONZERO separation against a third,
      independent route (the raw 2D lattice definition with the phase-shifted
      cosine of the total order; no parity branch selection): positive and
      negative separations, near-zero separations, and the largest consumed
      radius 1.62 -- the RB_R2 sine-omission defect class;
  C6  endpoint r = 0 separately: every odd-total-order entry exactly zero,
      even entries reproduce the exact finite-torus moment products;
  C7  near-zero 1/r-frame cancellation: the cubic Hermite coordinate variance
      Var([f(S)-f(M)-(r/2)(f_x(S)+f_x(M))]/r^3) -> a_6/144 with correction
      -a_8 r^2/2880, at r = 1e-3 and r = 1e-5 (a sine-drop breaks this at the
      2 a_2/r^4 level);
  C8  finite-difference sign-convention check (independent of both closed
      forms): central differences of K1^{(n)} reproduce K1^{(n+1)};
  C9  finite-torus moments at 150 dps: the exact identity
      1 - a_2 = 576 sum n^2 e^{-288 n^2} / sum e^{-288 n^2}, Poisson
      identities for a_4, a_6, and STRICT positivity of every planar
      deviation (never silently planar; planar values labeled diagnostics);
  C10 iv-path enclosures: the interval path encloses the mpf path and carries
      the certified tails (width control);
  C11 fail-closed API: invalid inputs raise CovInputError;
  C12 mutations (subprocess, normal AND -O modes): MUTATION=sine_drop (the
      RB_R2 defect) and MUTATION=planar_moments must each be rejected with
      nonzero exit.

Usage: python selftest_cov_exact.py            (full suite)
       python selftest_cov_exact.py MUTATION=<name>   (must exit nonzero)
Deterministic; no wall clock; byte-identical transcript under python and
python -O; no bare asserts; ck() fail-closed (SystemExit).
"""
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import cov_exact as ce
from mpmath import mp, mpf, iv


def ck(cond, msg="check"):
    if not cond:
        print("CHECK FAILED:", msg)
        raise SystemExit(1)
    print("[ok]", msg)


def nstr(x, n=6):
    return mp.nstr(x, n)


MUT = None
for a in sys.argv[1:]:
    if a.startswith("MUTATION="):
        MUT = a.split("=", 1)[1]

print("selftest_cov_exact.py -- H2 LIBRARY 1 self-test")
print("config:", sorted((k, v) for k, v in ce.get_config().items()))
ck(ce.get_config()['dps'] >= 60, "mpmath dps >= 60 (house floor)")

# mutation injection (must be rejected by the suite below)
if MUT == "sine_drop":
    ce._CFG['sine_drop'] = True
    print("MUTATION ACTIVE: sine_drop (odd-order sine sums zeroed; the RB_R2 defect)")
if MUT == "planar_moments":
    ce.moment_a = lambda m, impl='spectral', mode='mpf': ce.planar_moment(m)  # noqa
    print("MUTATION ACTIVE: planar_moments (planar double factorials substituted)")

# ---------------------------------------------------------------- C1
print("-- C1 configuration guards and certified tails")
try:
    ce.configure(dps=30)
    ck(False, "configure(dps=30) must be refused")
except ce.CovInputError:
    print("[ok] configure(dps<60) refused (fail-closed)")
for n in range(0, 9):
    t = ce.spectral_tail_1d(n)
    ck(t < mpf('1e-60'), "C1 spectral truncation tail < 1e-60 at n=%d (certified %s)"
       % (n, nstr(t, 3)))
ti12 = max(ce.image_tail_1d(n, 12) for n in range(9))
ck(ti12 < mpf('1e-60'), "C1 image tail < 1e-60 on the full post-wrap domain |s|<=12, n<=8 (certified %s)" % nstr(ti12, 3))
ti162 = max(ce.image_tail_1d(n, mpf('1.62')) for n in range(9))
ck(ti162 < mpf('1e-60'), "C1 image tail < 1e-60 at the adversarial radius |s|<=1.62, n<=8 (certified %s)" % nstr(ti162, 3))
tm = max(ce.moment_poisson_tail(m) for m in range(5))
ck(tm < mpf('1e-700'), "C1 moment Poisson tail < 1e-700 for m<=4 (certified %s)" % nstr(tm, 3))

# ---------------------------------------------------------------- C2
print("-- C2 kernel normalization and endpoint parity")
ck(ce.k1_spectral(0, 0) == 1, "C2 K1(0) = 1 exactly (spectral)")
ck(abs(ce.k1_image(0, 0) - 1) < mpf('1e-80'), "C2 K1(0) = 1 (image, %s)" % nstr(abs(ce.k1_image(0, 0) - 1), 3))
for n in (1, 3, 5, 7):
    ck(ce.k1_spectral(n, 0) == 0, "C2 K1^(%d)(0) = 0 exactly (spectral odd branch)" % n)
    ck(abs(ce.k1_image(n, 0)) < mpf('1e-200'), "C2 K1^(%d)(0) = 0 (image, %s)" % (n, nstr(abs(ce.k1_image(n, 0)), 3)))

# ---------------------------------------------------------------- C3
print("-- C3 separation parity, both implementations")
SEPS_ABS = [mpf('0'), mpf('0.006'), mpf('0.0375'), mpf('0.58'), mpf('1.45'), mpf('1.62')]
SEPS = sorted([s for a in SEPS_ABS for s in (+a, -a)])
pmx = mpf(0)
for impl in ('spectral', 'image'):
    for n in range(0, 9):
        for s in SEPS:
            if s == 0:
                continue
            d = abs(ce.k1(n, s, impl) - ((-1) ** n) * ce.k1(n, -s, impl))
            pmx = max(pmx, d)
ck(pmx < mpf('1e-80'), "C3 K1^{(n)}(-s) = (-1)^n K1^{(n)}(s), both impls, n<=8 (max dev %s)" % nstr(pmx, 3))

# ---------------------------------------------------------------- C4
print("-- C4 dense adversarial cross-implementation comparison")
ALPHAS = [(a1, a2) for a1 in range(5) for a2 in range(5) if a1 + a2 <= 4]
PAIRS = [(al, be) for al in ALPHAS for be in ALPHAS
         if al[0] + be[0] + al[1] + be[1] <= 4]
print("   derivative pairs with |alpha+beta| <= 4:", len(PAIRS),
      "; separation grid:", len(SEPS), "x", len(SEPS))
# cache of 1D values (test-harness mirror of ce.cov's formula; ce.cov itself is
# exercised on the full first column below and by the direct route in C5)
cache = {}
def k1c(impl, n, si):
    key = (impl, n, si)
    if key not in cache:
        cache[key] = ce.k1(n, SEPS[si], impl)
    return cache[key]
def covc(impl, al, be, i, j):
    v = k1c(impl, al[0] + be[0], i) * k1c(impl, al[1] + be[1], j)
    return -v if (be[0] + be[1]) % 2 else v
mx4 = mpf(0); ncmp = 0; arg = None
for i in range(len(SEPS)):
    for j in range(len(SEPS)):
        for al, be in PAIRS:
            a = covc('spectral', al, be, i, j)
            b = covc('image', al, be, i, j)
            d = abs(a - b)
            ncmp += 1
            if d > mx4:
                mx4 = d; arg = (al, be, SEPS[i], SEPS[j])
ck(mx4 < mpf('1e-50'),
   "C4 spectral-vs-image agreement < 1e-50 on %d comparisons (max %s at alpha=%s beta=%s d=(%s,%s))"
   % (ncmp, nstr(mx4, 3), arg[0], arg[1], nstr(arg[2], 4), nstr(arg[3], 4)))
# exercise the public ce.cov API on the same set's corners (uncached)
mx4b = mpf(0)
for i in range(len(SEPS)):
    for al, be in PAIRS:
        for j in (0, len(SEPS) - 1):
            d = abs(ce.cov(al, be, SEPS[i], SEPS[j], 'spectral')
                    - ce.cov(al, be, SEPS[i], SEPS[j], 'image'))
            mx4b = max(mx4b, d)
ck(mx4b < mpf('1e-50'), "C4b public cov() API agreement < 1e-50 (max %s)" % nstr(mx4b, 3))

# ---------------------------------------------------------------- C5
print("-- C5 odd-order nonzero-separation regression: independent raw 2D route")
h, J, ks, ws, Z1 = ce.lattice()
Z2 = Z1 * Z1
def cov2d_direct(alpha, beta, dx, dy):
    """Raw defining sum: (1/Z^2) sum_{k1,k2} w1 w2 (-1)^|beta| k1^{n1} k2^{n2}
    cos(k1 dx + k2 dy + N pi/2), N = |alpha+beta|.  No parity branch
    selection anywhere: Re(i^N e^{i theta}) = cos(theta + N pi/2)."""
    n1 = alpha[0] + beta[0]; n2 = alpha[1] + beta[1]
    N = n1 + n2
    tot = mpf(0)
    for k1, w1 in zip(ks, ws):
        p1 = w1 * (k1 ** n1)
        ph1 = k1 * dx + N * mp.pi / 2
        row = mpf(0)
        for k2, w2 in zip(ks, ws):
            row += w2 * (k2 ** n2) * mp.cos(ph1 + k2 * dy)
        tot += p1 * row
    v = tot / Z2
    return -v if (beta[0] + beta[1]) % 2 else v

CASES5 = [
    # (alpha, beta, dx, dy) -- odd total orders at NONZERO separation dominate
    ((1, 0), (0, 0), mpf('0.0375'), mpf('0.58')),
    ((0, 0), (1, 0), mpf('-0.0375'), mpf('-0.58')),
    ((2, 0), (1, 0), mpf('0.006'), mpf('1.45')),
    ((0, 1), (2, 0), mpf('-1.62'), mpf('1.62')),     # N=3, largest radius, neg dx
    ((1, 0), (0, 0), mpf('-1.62'), mpf('-1.62')),    # N=1, largest radius, both neg
    ((1, 1), (1, 1), mpf('-0.006'), mpf('0.0375')),  # N=4 even control, near zero
    ((3, 0), (0, 1), mpf('1.62'), mpf('-1.62')),     # N=4, largest radius
    ((1, 0), (0, 1), mpf('0.58'), mpf('-1.45')),     # N=2 control
    ((2, 1), (1, 0), mpf('0.006'), mpf('-0.006')),   # N=4, near-zero both axes
    ((0, 1), (1, 1), mpf('-0.58'), mpf('0.006')),    # N=3 mixed
]
mx5 = mpf(0)
for al, be, dx, dy in CASES5:
    N = al[0] + al[1] + be[0] + be[1]
    ref = cov2d_direct(al, be, dx, dy)
    for impl in ('spectral', 'image'):
        v = ce.cov(al, be, dx, dy, impl)
        d = abs(v - ref)
        mx5 = max(mx5, d)
        ck(d < mpf('1e-45'),
           "C5 N=%d%s alpha=%s beta=%s d=(%s,%s): %s vs raw-2D (dev %s)"
           % (N, " ODD" if N % 2 else " even", al, be, nstr(dx, 4), nstr(dy, 4),
              impl, nstr(d, 3)))
print("   C5 max deviation over all cases/impls:", nstr(mx5, 3))

# ---------------------------------------------------------------- C6
print("-- C6 endpoint r = 0 (separate from nonzero-r)")
a = {m: ce.moment_a(m) for m in range(5)}
odds = [(al, be) for al, be in PAIRS if (al[0] + al[1] + be[0] + be[1]) % 2 == 1]
for al, be in odds:
    vs = ce.cov(al, be, 0, 0, 'spectral')
    ck(vs == 0, "C6 odd-total-order entry alpha=%s beta=%s exactly 0 at r=0 (spectral)" % (al, be))
    vi = ce.cov(al, be, 0, 0, 'image')
    ck(abs(vi) < mpf('1e-190'), "C6 odd-total-order entry alpha=%s beta=%s = 0 at r=0 (image %s)"
       % (al, be, nstr(abs(vi), 3)))
print("   checked %d odd-total-order pairs at the endpoint" % len(odds))
# even entries reproduce exact moment products
def endpoint_value(al, be):
    n1 = al[0] + be[0]; n2 = al[1] + be[1]
    if n1 % 2 or n2 % 2:
        return mpf(0)
    v = ((-1) ** (n1 // 2)) * a[n1 // 2] * ((-1) ** (n2 // 2)) * a[n2 // 2]
    return -v if (be[0] + be[1]) % 2 else v
mx6 = mpf(0)
for al, be in PAIRS:
    if (al[0] + al[1] + be[0] + be[1]) % 2 == 0:
        mx6 = max(mx6, abs(ce.cov(al, be, 0, 0) - endpoint_value(al, be)))
ck(mx6 < mpf('1e-80'), "C6 even endpoint entries = exact torus moment products (max dev %s)" % nstr(mx6, 3))
# spot identities: Var(f_x) = a2, Var(f_xx) = a4, Cov(f_xx, f_yy) = a2^2
ck(abs(ce.cov((1, 0), (1, 0), 0, 0) - a[1]) < mpf('1e-80'), "C6 Var(f_x) = a_2")
ck(abs(ce.cov((2, 0), (2, 0), 0, 0) - a[4 // 2]) < mpf('1e-80'), "C6 Var(f_xx) = a_4")
ck(abs(ce.cov((2, 0), (0, 2), 0, 0) - a[1] ** 2) < mpf('1e-80'), "C6 Cov(f_xx,f_yy) = a_2^2")

# ---------------------------------------------------------------- C7
print("-- C7 near-zero 1/r-frame cancellation (cubic Hermite coordinate)")
def var_cubic(rr, impl='spectral'):
    """Var(W)/r^6 with W = f(S)-f(M)-(r/2)(f_x(S)+f_x(M)), M=(-r/2,0), S=(r/2,0).
    Exact expansion: a_6 r^6/144 - a_8 r^8/2880 + O(r^10); the r^2 and r^4
    terms cancel identically, which requires the odd (sine) cross terms."""
    def c(al, be, dx):
        return ce.cov(al, be, dx, 0, impl)
    k0 = c((0, 0), (0, 0), rr)
    k1v = c((0, 0), (1, 0), rr)   # Cov(f(S), f_x(M)) = -K1'(r)  [sine branch]
    k2v = c((1, 0), (1, 0), rr)   # Cov(f_x(S), f_x(M)) = -K1''(r)
    var_ff = 2 * (1 - k0)
    cov_ab = 2 * k1v               # Cov(f(S)-f(M), f_x(S)+f_x(M)) = 2*k1v
    var_gg = 2 * a[1] + 2 * k2v
    return (var_ff - rr * cov_ab + (rr * rr / 4) * var_gg) / rr ** 6
target = a[3] / 144
for rr, tol in ((mpf('1e-3'), mpf('1e-6')), (mpf('1e-5'), mpf('1e-10'))):
    for impl in ('spectral', 'image'):
        v = var_cubic(rr, impl)
        ck(abs(v - target) < tol,
           "C7 Var cubic-Hermite at r=%s (%s) = %s vs a_6/144 = %s (dev %s < %s)"
           % (nstr(rr, 3), impl, nstr(v, 12), nstr(target, 12), nstr(abs(v - target), 3), nstr(tol, 1)))
# correction sign and size: target - v ~ a_8 r^2 / 2880
v3 = var_cubic(mpf('1e-3'))
corr = target - v3
pred = a[4] * mpf('1e-6') / 2880
ck(abs(corr / pred - 1) < mpf('0.01'),
   "C7 correction = -a_8 r^2/2880 confirmed at r=1e-3 (measured %s, predicted %s)"
   % (nstr(corr, 6), nstr(pred, 6)))

# ---------------------------------------------------------------- C8
print("-- C8 finite-difference sign-convention check (independent route)")
hh = mpf('1e-18')
mx8 = mpf(0)
for impl in ('spectral', 'image'):
    for n in range(0, 4):
        for s in (mpf('0.0375'), mpf('-0.58'), mpf('1.45'), mpf('-1.62'), mpf('0.006')):
            fd = (ce.k1(n, s + hh, impl) - ce.k1(n, s - hh, impl)) / (2 * hh)
            d = abs(fd - ce.k1(n + 1, s, impl))
            scale = 1 + abs(ce.k1(n + 1, s, impl))
            mx8 = max(mx8, d / scale)
ck(mx8 < mpf('1e-25'),
   "C8 central differences reproduce K1^{(n+1)} (max rel dev %s); sine-branch signs confirmed independently" % nstr(mx8, 3))

# ---------------------------------------------------------------- C9
print("-- C9 finite-torus moments at 150 dps (exact identities; never planar)")
ce.configure(dps=150)
a2s = ce.moment_a(1); a4s = ce.moment_a(2); a6s = ce.moment_a(3); a8s = ce.moment_a(4)
dev_a2 = 1 - a2s
dev_id = ce.one_minus_a2_poisson()
ck(abs(dev_a2 - dev_id) < mpf('1e-130'),
   "C9 identity 1-a_2 = 576 sum n^2 e^{-288n^2}/sum e^{-288n^2} (spectral %s, real-space %s, dev %s)"
   % (nstr(dev_a2, 12), nstr(dev_id, 12), nstr(abs(dev_a2 - dev_id), 3)))
ck(mpf(0) < dev_a2 < mpf('1e-100'),
   "C9 0 < 1 - a_2 < 1e-100 STRICTLY (finite torus is never planar; value %s)" % nstr(dev_a2, 8))
for m, aval, planar in ((2, a4s, 3), (3, a6s, 15), (4, a8s, 105)):
    ap = ce.moment_a_poisson(m)
    ck(abs(aval - ap) < mpf('1e-130'),
       "C9 a_%d spectral == Poisson real-space identity (dev %s)" % (2 * m, nstr(abs(aval - ap), 3)))
    dev = aval - ce.planar_moment(m)
    ck(dev != 0 and abs(dev) < mpf('1e-100'),
       "C9 0 < |a_%d - (planar %d)| < 1e-100 STRICTLY (deviation %s; nonzero: the torus is never planar; planar value is a labeled diagnostic only)"
       % (2 * m, planar, nstr(dev, 8)))
ck(abs(float(dev_a2) - 9.65254179896e-123) < 1e-135,
   "C9 1 - a_2 = 9.65254179896e-123 (ledger value of record, F3)")
ce.configure(dps=100)

# ---------------------------------------------------------------- C10
print("-- C10 interval path enclosures (iv carries the certified tails)")
mx10 = mpf(0)
for n in range(0, 9):
    for s in SEPS:
        for impl in ('spectral', 'image'):
            vv = ce.k1(n, s, impl, 'mpf')
            encl = ce.k1(n, s, impl, 'iv')
            ck(vv in encl, "C10 iv enclosure contains mpf value: impl=%s n=%d s=%s" % (impl, n, nstr(s, 4)))
            w = encl.b - encl.a
            mx10 = max(mx10, w)
ck(mx10 < mpf('1e-55'), "C10 all 1D iv widths < 1e-55 (max %s; tails dominate at ~1e-190)" % nstr(mx10, 3))
for al, be, dx, dy in CASES5[:6]:
    vv = ce.cov(al, be, dx, dy, 'spectral', 'mpf')
    encl = ce.cov(al, be, dx, dy, 'spectral', 'iv')
    ck(vv in encl, "C10 covariance iv enclosure contains mpf value: alpha=%s beta=%s d=(%s,%s)"
       % (al, be, nstr(dx, 4), nstr(dy, 4)))
    ck(encl.b - encl.a < mpf('1e-50'), "C10 covariance iv width < 1e-50")
a2i = ce.moment_a(1, 'spectral', 'iv')
ck(a2s in a2i and (a2i.b - a2i.a) < mpf('1e-55'), "C10 a_2 iv enclosure tight and contains the mpf value")

# ---------------------------------------------------------------- C11
print("-- C11 fail-closed API")
BAD_CALLS = [
    lambda: ce.k1(9, 0),
    lambda: ce.k1(-1, 0),
    lambda: ce.cov((5, 0), (4, 0), 0, 0),          # total order 9 > ceiling 8
    lambda: ce.cov((1,), (0, 0), 0, 0),
    lambda: ce.cov((1, 0), (0, 0), 0, 0, impl='bogus'),
    lambda: ce.k1_spectral(1, 0, mode='bogus'),
    lambda: ce.image_tail_1d(0, 13),
    lambda: ce.moment_a(5),
    lambda: ce.configure(kmax=0),
]
for i, call in enumerate(BAD_CALLS):
    try:
        call()
        ck(False, "C11 bad call #%d was NOT refused" % i)
    except (ce.CovInputError, ce.CertificationError) as e:
        print("[ok] C11 bad call #%d refused: %s" % (i, type(e).__name__))
# sanity: total order 8 is the certified ceiling and IS allowed
ck(abs(ce.cov((3, 0), (3, 0), mpf('0.5'), mpf('-0.25')) - ce.cov((3, 0), (3, 0), mpf('0.5'), mpf('-0.25'), 'image')) < mpf('1e-50'),
   "C11 total order 6 allowed and cross-impl consistent; ceiling is 8")

# ---------------------------------------------------------------- C12
print("-- C12 mutation rejection (subprocess, normal AND -O)")
if MUT is None:
    for mut in ("sine_drop", "planar_moments"):
        for opt in (False, True):
            cmd = [sys.executable] + (["-O"] if opt else []) + [
                os.path.join(HERE, "selftest_cov_exact.py"), "MUTATION=" + mut]
            p = subprocess.run(cmd, capture_output=True, text=True)
            ck(p.returncode != 0, "C12 mutation %s rejected under %s (rc=%d)"
               % (mut, "-O" if opt else "normal", p.returncode))
            ck("CHECK FAILED" in p.stdout, "C12 mutation %s produced a fail line under %s"
               % (mut, "-O" if opt else "normal"))
else:
    print("   (mutation run in progress: MUTATION=%s; subprocess section skipped)" % MUT)

print("")
if MUT is None:
    print("SELFTEST_COV_EXACT: PASS (all checks C1-C12 fail-closed; both-mode byte-identical design)")
else:
    print("MUTATION %s REACHED THE END WITHOUT REJECTION (must never print)" % MUT)
    raise SystemExit(1)
