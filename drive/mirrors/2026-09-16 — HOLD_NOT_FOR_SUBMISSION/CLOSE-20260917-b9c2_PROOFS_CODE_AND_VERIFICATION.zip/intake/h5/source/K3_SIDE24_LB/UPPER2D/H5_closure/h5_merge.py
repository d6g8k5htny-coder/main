#!/usr/bin/env python3
"""H5 totals assembly: reads all h5_results_*.jsonl shards, assembles the
certified upper/lower on the C1-lane raw integral I = int rho_w dA.

I_hi = 2*R1_half (C1-grid cells, delta>=0.00895, machine-certified)
     + 2*rim_half (NAMED-LEMMA H5-RIM flat envelope over delta<=0.00895)
     + stitch (R4 ring/annulus, machine-certified, full circle)
     + D3_REMOTE*r^3 (R5 remote, D3-certified)
I_lo = 2*sum(patches_lo) (Grade-A patches over top cells; labeled partial)

Fail-closed: ck(C1_TOTAL in [I_lo, I_hi]).
"""
import glob
import json
import os
import sys
from mpmath import mp, mpf, pi

mp.dps = 40
OUT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, OUT)
import h5_kernel as hk


def ck(cond, msg):
    if not cond:
        raise SystemExit('H5 MERGE FAIL-CLOSED: ' + msg)


def assemble(r=mpf('0.05'), mutate_index=None, write_totals=True, bremote=None):
    # B_remote: the D3 remote bracket constant (consumed per rung). Default
    # 19.55 = the frozen v1 consumption (D1 v2.0 dependency); new work passes
    # the D3 lane's kappa-inclusive amendment value when it lands (R3).
    s = r/mpf('0.05')   # rung scale: every geometric constant of the r=0.05 cover scales by s
    recs = []
    for f in sorted(glob.glob(os.path.join(OUT, 'h5_results_r%s_*.jsonl' % r))):
        for line in open(f):
            line = line.strip()
            if line:
                recs.append(json.loads(line))
    ck(recs, 'no result records found')
    if mutate_index is not None:
        # mutation-suite hook (in-memory only): delete ALL records of one
        # selector class — the corresponding completeness ck must then fail.
        # 0: one R1 cell, 1: one rim column, 2: one stitch sector,
        # 3: one scone probe site, 4: one sdisk probe site, 5: one sring site
        cells = sorted({d.get('cell') for d in recs if d.get('part') == 'R1'})
        sel = mutate_index % 6
        if sel == 0:
            tgt = cells[(mutate_index//6) % len(cells)]
            recs = [d for d in recs if not (d.get('part') == 'R1' and d.get('cell') == tgt)]
        elif sel == 1:
            ths = sorted({d['th'] for d in recs if d.get('part') == 'rimprobe'})
            tgt = ths[(mutate_index//6) % len(ths)]
            recs = [d for d in recs if not (d.get('part') == 'rimprobe' and d.get('th') == tgt)]
        elif sel == 2:
            secs = sorted({(d['part'], d.get('d1'), d['sec']) for d in recs
                           if d.get('part') in ('stitchM', 'stitchS')})
            tgt = secs[(mutate_index//6) % len(secs)]
            recs = [d for d in recs if not (d.get('part') == tgt[0] and d.get('d1') == tgt[1]
                                            and d.get('sec') == tgt[2])]
        elif sel == 3:
            sts = sorted({(d['thS'], d['dS']) for d in recs if d.get('part') == 'sconeprobe'})
            tgt = sts[(mutate_index//6) % len(sts)]
            recs = [d for d in recs if not (d.get('part') == 'sconeprobe'
                                            and (d['thS'], d['dS']) == tgt)]
        elif sel == 4:
            sts = sorted({d['thS'] for d in recs if d.get('part') == 'sdiskprobe'})
            tgt = sts[(mutate_index//6) % len(sts)]
            recs = [d for d in recs if not (d.get('part') == 'sdiskprobe' and d.get('thS') == tgt)]
        else:
            sts = sorted({(d['thS'], d['dS']) for d in recs if d.get('part') == 'sringprobe'})
            tgt = sts[(mutate_index//6) % len(sts)]
            recs = [d for d in recs if not (d.get('part') == 'sringprobe'
                                            and (d['thS'], d['dS']) == tgt)]

    R1 = mpf(0)
    r1_best = {}
    rim_cols = {}
    probe_sites = {}
    stitch_best = {}
    stitch_recs = 0
    patch_sites = {}
    for d in recs:
        p = d.get('part')
        if p == 'R1':
            # multiple passes (coarse + refinement): take the min per cell
            # (each record is an independent certified upper for the cell)
            c = d['cell']
            h = mpf(d['hi'])
            if c not in r1_best or h < r1_best[c]:
                r1_best[c] = h
        elif p == 'rimprobe':
            rim_cols[d['th']] = mpf(d['rho_hi'])
        elif p == 'sconeprobe':
            # dedupe by probe site (files append across reruns; last wins),
            # then the wedge constant is the max over sites
            probe_sites[('scone', d['thS'], d['dS'])] = mpf(d['rho_hi'])
        elif p == 'sdiskprobe':
            probe_sites[('sdisk', d['thS'])] = mpf(d['rho_hi'])
        elif p == 'sringprobe':
            probe_sites[('sring', d['thS'], d['dS'])] = mpf(d['rho_hi'])
        elif p == 'mbackprobe':
            key = 'mfwd' if int(d['thM']) < 90 else 'mbwd'
            probe_sites[(key, d['thM'], d['dl'])] = mpf(d['rho_hi'])
        elif p in ('stitchM', 'stitchS'):
            # v3: the inner S-annulus band [0.024,0.06] is superseded by the
            # enlarged S-disk envelope (d_S<0.06) - excluded from the sum
            if p == 'stitchS' and d.get('d1') is not None and mpf(d['d1']) < mpf('1.2')*r:
                continue
            # multiple passes: min per sector (each record an independent
            # certified upper for the sector)
            skey = (p, d.get('d1'), d['sec'])
            h = mpf(d['hi'])
            if skey not in stitch_best or h < stitch_best[skey]:
                stitch_best[skey] = h
            stitch_recs += 1
        elif p == 'patch':
            # dedupe by site (files append across reruns): each record is an
            # independent certified [lo, hi] for the site - tightest wins
            skey = (d['th'], d.get('dl'))
            if skey not in patch_sites:
                patch_sites[skey] = [mpf(d['lo']), mpf(d['hi'])]
            else:
                patch_sites[skey][0] = max(patch_sites[skey][0], mpf(d['lo']))
                patch_sites[skey][1] = min(patch_sites[skey][1], mpf(d['hi']))

    patches_lo = sum(v[0] for v in patch_sites.values())
    patches_hi = sum(v[1] for v in patch_sites.values())
    ck(len(patch_sites) == 8, 'patch sites incomplete: %d/8' % len(patch_sites))
    R1 = sum(r1_best.values())
    r1_cells = len(r1_best)
    ck(r1_cells == 70, 'R1 incomplete: %d/70 cells' % r1_cells)
    ck(len(rim_cols) == 10, 'rim probes incomplete: %d/10 columns' % len(rim_cols))
    srim_cols = {}
    for k3, v in probe_sites.items():
        srim_cols[k3[0]] = max(srim_cols.get(k3[0], mpf(0)), v)
    ck('scone' in srim_cols, 'S-cone probes missing')
    ck('mfwd' in srim_cols, 'M-forward probes missing')
    ck('mbwd' in srim_cols, 'M-backward probes missing')
    ck(sum(1 for k3 in probe_sites if k3[0] == 'scone') == 6,
       'S-cone probe sites incomplete: %d/6' % sum(1 for k3 in probe_sites if k3[0] == 'scone'))
    ck(sum(1 for k3 in probe_sites if k3[0] in ('mfwd', 'mbwd')) == 12,
       'M-cone probe sites incomplete: %d/12' % sum(1 for k3 in probe_sites if k3[0] in ('mfwd', 'mbwd')))
    stitch = sum(stitch_best.values())
    ck(stitch > 0, 'stitch missing')
    ck(len(stitch_best) == 22, 'stitch incomplete: %d/22 sectors (12 M-ring + 10 outer S-ann)' % len(stitch_best))

    # rim envelope: C_flat(col) = 2*rho_hi over the full rim disk sector
    RIM_D = mpf('0.00895')*s
    sec_area = pi*RIM_D**2*mpf(15)/360
    rim_half = sum(2*v*sec_area for v in rim_cols.values())

    # H5-AXIS envelopes (named lemma), split wedges:
    #   S-cone |theta_S|<18 deg and theta_S>162 deg, d_S<0.105 (72 deg total)
    #   M-forward theta_M<12 deg, d_M<0.10 full depth incl stitch ring (24 deg)
    #   M-backward theta_M>168 deg, d_M<0.10 full depth incl stitch ring (24 deg)
    #   S-disk (v2 amendment): d_S<0.03 full circle; constant = 2*max over the
    #   v2 ring probes (d_S~0.04, five off-cone directions) and the v1 cone
    #   probes at d_S=0.03
    scone_C = 2*srim_cols['scone']
    scone = scone_C*pi*(mpf('0.105')*s)**2*mpf(72)/360
    mfwd_C = 2*srim_cols['mfwd']
    mfwd = mfwd_C*pi*(mpf('0.10')*s)**2*mpf(24)/360
    mbwd_C = 2*srim_cols['mbwd']
    mbwd = mbwd_C*pi*(mpf('0.10')*s)**2*mpf(24)/360
    mback = mfwd + mbwd
    ck('sdisk' in srim_cols, 'S-disk (v2) probes missing')
    ck(sum(1 for k3 in probe_sites if k3[0] == 'sdisk') == 5,
       'S-disk (v2) probes incomplete: %d/5' % sum(1 for k3 in probe_sites if k3[0] == 'sdisk'))
    ck(sum(1 for k3 in probe_sites if k3[0] == 'sring') == 6,
       'S-ring (v3) probes incomplete: %d/6' % sum(1 for k3 in probe_sites if k3[0] == 'sring'))
    sdisk_C = 2*max([v for k3, v in probe_sites.items() if k3[0] in ('sdisk', 'sring')] +
                    [v for k3, v in probe_sites.items() if k3[0] == 'scone'])
    sdisk = sdisk_C*pi*(mpf('0.062')*s)**2
    for t in rim_cols:
        if t not in (15, 175):
            ck(rim_cols[t] > 0, 'rim column %s probe failed (not a cone column)' % t)

    # Coverage completeness self-test (fail-closed): every chart point is
    # covered by at least one mechanism.  Machine covers: rim disk
    # (d_M < 0.00895), R1 grid (0.00895 <= d_M <= 0.074, full circle via the
    # y -> -y symmetry), stitch (0.074 < d_M < 0.10 and 0.024 <= d_S <= 0.105),
    # remote (min(d_M, d_S) >= 0.1, D3-certified).  Machine-skipped sub-regions
    # are exactly the named-lemma envelope regions (H5-RIM; H5-AXIS v1 wedges
    # at 12 deg supersets of the 10 deg skip rects and of all depth-3
    # exemptions; H5-AXIS v2 S-disk d_S < 0.03).  Double coverage only ADDS.
    RIM_Dc = mpf('0.00895')*s
    census = dict(rim=0, r1=0, stitch=0, remote=0, env=0, multi=0)
    for i in range(81):
        dM = mpf('0.16')*s*i/80
        for j in range(73):
            thM = mpf(180)*j/72
            x = -r/2 + dM*mp.cos(thM*pi/180)
            y = dM*mp.sin(thM*pi/180)
            dS = mp.sqrt((x - r/2)**2 + y*y)
            thS = abs(mp.atan2(y, x - r/2))*180/pi
            hits = 0
            if dM < RIM_Dc:
                census['rim'] += 1; hits += 1
            if RIM_Dc <= dM <= mpf('0.074')*s:
                census['r1'] += 1; hits += 1
            if (mpf('0.074')*s < dM < mpf('0.10')*s) or (mpf('0.06')*s <= dS <= mpf('0.105')*s):
                census['stitch'] += 1; hits += 1
            if min(dM, dS) >= mpf('0.1')*s:
                census['remote'] += 1; hits += 1
            if ((dS < mpf('0.105')*s and (thS < 18 or thS > 162)) or
                    (dM < mpf('0.10')*s and (thM < 12 or thM > 168)) or dS < mpf('0.062')*s):
                census['env'] += 1; hits += 1
            ck(hits >= 1, 'UNCOVERED point: d_M=%s th_M=%s d_S=%s th_S=%s' % (dM, thM, dS, thS))
            if hits > 1:
                census['multi'] += 1
    print('coverage census (81x73 chart grid): %s' % census)

    D3_REMOTE = mpf('19.55') if bremote is None else mpf(bremote)
    remote = D3_REMOTE*r**3

    I_hi = 2*R1 + 2*rim_half + scone + mback + sdisk + stitch + remote
    I_lo = 2*patches_lo

    C1_TOTAL = mpf('1.605315e-04')*s**3   # C1 recomputed per rung: exact r^3 ledger
    ck(I_lo <= C1_TOTAL <= I_hi,
       'C1 total %.9e not in [%.9e, %.9e]' % (C1_TOTAL, I_lo, I_hi))

    parts = dict(
        r=str(r),
        R1_half=str(R1),
        rim_half=str(rim_half),
        rim_Cflat={str(k): str(2*v) for k, v in rim_cols.items()},
        scone=str(scone),
        scone_Cflat=str(scone_C),
        mfwd=str(mfwd),
        mfwd_Cflat=str(mfwd_C),
        sdisk=str(sdisk),
        sdisk_Cflat=str(sdisk_C),
        mbwd=str(mbwd),
        mbwd_Cflat=str(mbwd_C),
        stitch=str(stitch),
        remote=str(remote),
        patches_lo_half=str(patches_lo),
        patches_hi_half=str(patches_hi),
        I_lo=str(I_lo),
        I_hi=str(I_hi),
        I_hi_over_r3=str(I_hi/r**3),
        C1_TOTAL=str(C1_TOTAL),
        ratio_hi=str(I_hi/C1_TOTAL),
        ratio_lo=str(I_lo/C1_TOTAL),
    )
    # versioned totals writes (Stage-E discipline): h5_totals.json is the v1
    # CONSUMED artifact and is never overwritten; every merge writes a new
    # h5_totals_v{N}[_tag].json, fail-closed if the target exists
    if str(r) != '0.05':
        base = os.path.join(OUT, 'h5_totals_r%s_v%%d%%s.json' % r)
    else:
        base = os.path.join(OUT, 'h5_totals_v%d%s.json')
    if write_totals:
        n, suffix = 2, ''
        while os.path.exists(base % (n, suffix)):
            n += 1
        target = base % (n, suffix)
        ck(not os.path.exists(target), 'totals target must not exist: %s' % target)
        with open(target, 'x') as f:
            json.dump(parts, f, indent=2, sort_keys=True)
        print('totals written (new version, nothing overwritten): %s' % target)
    parts['_mpf'] = dict(I_lo=I_lo, I_hi=I_hi)
    return parts


def main(r=mpf('0.05')):
    parts = assemble(r)
    I_lo, I_hi = parts['_mpf']['I_lo'], parts['_mpf']['I_hi']
    C1_TOTAL = mpf(parts['C1_TOTAL'])
    print('=== H5 totals (r=%s) ===' % mp.nstr(r, 4))
    for k in sorted(parts):
        if k.startswith('_') or k in ('I_lo', 'I_hi', 'C1_TOTAL', 'ratio_hi',
                                      'ratio_lo', 'I_hi_over_r3'):
            continue
        print('  %-24s %s' % (k, parts[k]))
    print('I_lo = 2*patches_lo:       %.9e' % I_lo)
    print('I_hi = 2R1+2rim+sc+mb+st+rem: %.9e' % I_hi)
    print('C1_TOTAL:                  %.9e  INSIDE [lo,hi]: PASS' % C1_TOTAL)
    print('I_hi/C1: %.1fx   I_hi/r^3 = %.4f' % (I_hi/C1_TOTAL, I_hi/r**3))


if __name__ == '__main__':
    args = sys.argv[1:]
    rr = mpf(args[args.index('--r')+1]) if '--r' in args else mpf('0.05')
    main(rr)
