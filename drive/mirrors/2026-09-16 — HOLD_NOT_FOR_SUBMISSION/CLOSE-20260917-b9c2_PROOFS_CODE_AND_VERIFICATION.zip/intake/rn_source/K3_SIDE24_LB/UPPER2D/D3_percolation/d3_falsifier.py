#!/usr/bin/env python3
# d3_falsifier.py -- executable falsifier for the D3 percolation lane
# (OBL-B1-PERC): the remote preemption class A.rem.
#
# What this script does (fail-closed, ck() -> SystemExit(1); no bare asserts;
# deterministic; normal and -O modes byte-identical):
#
#   F0  freeze-before-consume: hash-pin import of B1's frozen falsifier
#       (b1_falsifier.py, sha256 pinned against B1_taxonomy/FREEZE.txt) as the
#       discrete-model engine; the D3 cover lemma's discrete mirror is built
#       on top of it.
#
#   F1  DISCRETE COVER MIRROR of the D3 split lemma (D3_PERCOLATION.md sec. 1):
#       on Reg/TYP,  A.rem = A \ A.loc  implies the union
#           E1: M's death saddle S' lies OUTSIDE the chart box, or
#           E2: S' inside, but the killing elder maximum M2 lies OUTSIDE, or
#           E3: S', M2 inside, but M and M2 are not connected INSIDE the box
#               at level > key(S)  (chart hole).
#       The mirror uses B2d's chart-box instrument verbatim: box radius
#       R = max(2, min(8, cheb(M,S)+1)) around M; loc := BFS from M over
#       {key > key(S)} inside the box reaches a vertex with key > key(M).
#       For every A.rem pair in the ensembles the script KILLS unless
#       E1 v E2 v E3 holds, and verifies the raw-count domination
#       (case E1 => the out-of-box window-saddle count is >= 1, etc.).
#       The killer-aware persistence variant is cross-checked against
#       B1F.persistence (identical die_partner on every field).
#       Non-vacuity: carved synthetics T-D3-REM (E1) and T-D3-RELDER (E2)
#       must realize as A.rem of the intended case; the ensembles must
#       contain >= 50 A.rem pairs.
#
#   F2  ENGINE RE-RUN: python3 d3_perc.py must exit 0 with stdout
#       byte-identical to the frozen transcript t_normal.txt; t_opt.txt must
#       be byte-identical to t_normal.txt (both-mode determinism); the
#       headline numbers are re-windowed from the fresh output:
#         I_uncond/r^3(0.05) in [2.92, 2.93];  crude spine total in [19, 23];
#   F3  AMENDMENT RE-RUN (R3 repair, HISTORICAL): d3_amend.py byte-identical
#       to the frozen ta_normal.txt; the v1-era window (kept for the
#       historical artifact; SUPERSEDED as a gate by F5);
#   F4  MUTATION SUITE (v1, historical): gate self-test, transcript tamper,
#       hash-pin mutation;
#   F5  AMENDMENT v2 RE-RUN (R2/V1): d3_amend_v2.py byte-identical to the
#       frozen ta2_normal.txt; the OPERATIVE discriminating gate
#       [21.27, 22.5] on the floor-consistent certified bracket: accepts
#       21.9279; rejects the kappa=0 reading (19.5465), the v1
#       QMC-denominator bracket (21.2153), and the mixed-denominator form
#       (21.2658) -- any denominator above the certified R2 floor fails
#       (edge 21.27, not the prescribed 21.24: the mixed form 21.2658 sits
#       above 21.24, so 21.27 is the minimal edge rejecting it);
#   F6  v2 MUTATION SUITE: gate self-test on sub-floor readings, transcript
#       tamper through the v2 parse path, QMC-denominator injection at the
#       floor pin, R2-artifact hash-pin mutation -> all must fire
#       fail-closed;
#   F7  PERC-DECAY RE-RUN (Theorem (2) validity premise): d3_perc_decay.py
#       byte-identical to the frozen pd_normal.txt; register completeness
#       (the three far-lane classes, certified bound + PD-CONN + precise
#       region each), all five PD6 mutations fired, count bound and
#       corridor bottleneck displays within their windows.
#         typed-y total in [4.5, 6.0];  rel kap_cross(5, axis) in [0.4, 0.9];
#         g/(Z_r m_sad)(5, transverse) in [0.95, 1.08].
#
# House conventions: mpmath dps=100; numpy RandomState MT19937; fixed seeds.

import hashlib
import importlib.util
import math
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
B1DIR = os.path.abspath(os.path.join(HERE, '..', 'B1_taxonomy'))
B1F_PATH = os.path.join(B1DIR, 'b1_falsifier.py')
B1F_SHA256 = '818df7985412071259345455c9ff6b68cad0c0fa9d636009cf8849b550154185'
T_NORMAL = os.path.join(HERE, 't_normal.txt')
T_OPT = os.path.join(HERE, 't_opt.txt')


def ck(cond, msg):
    if not cond:
        print("D3-FALSIFIER FIRED:", msg)
        raise SystemExit(1)


def _sha256(path):
    with open(path, 'rb') as fh:
        return hashlib.sha256(fh.read()).hexdigest()


ck(os.path.exists(B1F_PATH), "missing b1_falsifier.py")
ck(_sha256(B1F_PATH) == B1F_SHA256,
   "b1_falsifier.py hash drift (freeze-before-consume violated)")

_spec = importlib.util.spec_from_file_location("b1f_frozen", B1F_PATH)
B1F = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(B1F)

N = B1F.N
V = B1F.V
RING = B1F.RING
LINES = []


def emit(s):
    print(s)
    LINES.append(s)


# ---------------------------------------------------------------------------
# killer-aware persistence (independent extension of B1F.persistence; the
# die_partner outputs are cross-checked equal on every field we touch)
# ---------------------------------------------------------------------------
def persistence_killer(f):
    """Returns (die_partner, die_level, killer_birth): when max mv's root is
    absorbed by the eldest root at saddle v, killer_birth[mv] is the birth
    vertex (elder maximum) of the absorbing component."""
    order = sorted(range(V), key=lambda v: f.key(v), reverse=True)
    parent = list(range(V))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    active = [False] * V
    birth_vertex = [None] * V
    die_partner = {}
    die_level = {}
    killer_birth = {}
    for v in order:
        active[v] = True
        roots = sorted({find(u) for u in RING[v] if active[u]})
        if not roots:
            parent[v] = v
            birth_vertex[v] = v
            continue
        eldest = max(roots, key=lambda r: f.key(birth_vertex[r]))
        for r in roots:
            if r != eldest:
                mv = birth_vertex[r]
                die_partner[mv] = v
                die_level[mv] = f.key(v)
                killer_birth[mv] = birth_vertex[eldest]
                parent[r] = eldest
        parent[v] = eldest
    return die_partner, die_level, killer_birth


def in_box(v, Mv, R):
    return B1F.cheb(v, Mv) <= R


def box_witness(f, Mv, tkey, R, target=None):
    """BFS from Mv over {key > tkey} inside the box; if target is None: True
    iff a vertex with key > key(Mv) is reached (B2d's loc instrument); else:
    True iff target is reached (the E3 in-box connection test)."""
    mk = f.key(Mv)
    seen = {Mv}
    stack = [Mv]
    found = False
    while stack:
        x = stack.pop()
        for u in RING[x]:
            if u in seen or f.key(u) <= tkey or not in_box(u, Mv, R):
                continue
            seen.add(u)
            if target is None:
                if f.key(u) > mk:
                    found = True
            elif u == target:
                return True
            stack.append(u)
    return found


def is_window_saddle(f, w, Sv, Mv):
    """Raw window saddle: PL saddle (>=2 upper-link clusters), not Sv, with
    key(Sv) < key(w) < key(Mv) -- the discrete mirror of N_w."""
    if w == Sv or not (f.key(Sv) < f.key(w) < f.key(Mv)):
        return False
    if B1F.is_local_max(f, w):
        return False
    return len(B1F.upper_link_clusters(f, w)) >= 2


def audit_cover(f, Mv, Sv, die_partner, die_level, killer_birth, comp, maxkey,
                stats, tag):
    """The cover-lemma mirror for one pair. Returns 'A.rem-caseX' / 'A.loc' /
    'notA'. Kills on any uncovered A.rem."""
    if not f.gt(Mv, Sv):
        return 'notA'
    C = comp[Mv]
    ck(C >= 0, "%s: M not above S level" % tag)
    A = maxkey[C] > f.key(Mv)
    if not A:
        return 'notA'
    DM = die_partner.get(Mv)
    ck(DM is not None and die_level[Mv] > f.key(Sv),
       "%s: A true but M does not die strictly above S (T1 mirror broken)" % tag)
    if DM == Sv:
        return 'notA'   # success pair (D(M)==S): not in the failure class
    R = max(2, min(8, B1F.cheb(Mv, Sv) + 1))
    tkey = f.key(Sv)
    loc = box_witness(f, Mv, tkey, R)
    if loc:
        return 'A.loc'
    # A.rem: the cover lemma's three cases
    Sprim = DM
    M2 = killer_birth[Mv]
    ck(f.key(M2) > f.key(Mv), "%s: killer not elder (elder rule broken)" % tag)
    ck(is_window_saddle(f, Sprim, Sv, Mv),
       "%s: death saddle %d is not a raw window saddle (count mirror broken)"
       % (tag, Sprim))
    case1 = not in_box(Sprim, Mv, R)
    case2 = (not case1) and (not in_box(M2, Mv, R))
    case3 = (not case1) and (not case2) and \
        (not box_witness(f, Mv, tkey, R, target=M2))
    ck(case1 or case2 or case3,
       "%s pair (%d,%d): A.rem COVERED BY NO CASE (E1,E2,E3 all false):"
       " S'=%d in-box, M2=%d in-box, in-box connection exists"
       % (tag, Mv, Sv, Sprim, M2))
    # raw-count domination mirror: A.rem => a raw window saddle exists either
    # outside the box (E1) or inside (E2/E3)
    if case1:
        stats['E1'] += 1
        ck(not in_box(Sprim, Mv, R), "case tagging inconsistent")
    elif case2:
        stats['E2'] += 1
    else:
        stats['E3'] += 1
    stats['rem'] += 1
    return 'A.rem'


# ---------------------------------------------------------------------------
# carved synthetics (non-vacuity witnesses)
# ---------------------------------------------------------------------------
def synth_d3():
    out = []

    # T-D3-REM (E1: remote death saddle). Pair: M=(20,20)=10, S=(20,22)=6.
    # M's lineage rides a monotone ridge out and dies at the far dip (16,20).
    f = B1F.base_field("T-D3-REM")
    B1F.carve(f, 20, 20, 10.0)      # Mv
    B1F.carve(f, 20, 22, 6.0)       # Sv (two upper clusters: (20,21),(19,22))
    B1F.carve(f, 20, 21, 7.0)
    B1F.carve(f, 19, 22, 6.5)
    B1F.carve(f, 19, 20, 9.5)       # ridge leaving M, monotone down to the dip
    B1F.carve(f, 18, 20, 9.45)
    B1F.carve(f, 17, 20, 9.42)
    B1F.carve(f, 16, 20, 9.4)       # S' : the remote death saddle (dist 4 > R=3)
    B1F.carve(f, 15, 20, 9.45)      # monotone up to the elder maximum
    B1F.carve(f, 14, 20, 9.5)
    B1F.carve(f, 13, 20, 9.55)
    B1F.carve(f, 12, 20, 9.6)
    B1F.carve(f, 11, 20, 9.65)
    B1F.carve(f, 10, 20, 11.5)      # M2 elder
    out.append((f, 20 * N + 20, 20 * N + 22, 'E1'))

    # T-D3-RELDER (E2: local death saddle, remote elder). Same pair; the
    # death saddle (18,20) sits inside the box, the elder at distance 10.
    f = B1F.base_field("T-D3-RELDER")
    B1F.carve(f, 20, 20, 10.0)
    B1F.carve(f, 20, 22, 6.0)
    B1F.carve(f, 20, 21, 7.0)
    B1F.carve(f, 19, 22, 6.5)
    B1F.carve(f, 19, 20, 9.5)
    B1F.carve(f, 18, 20, 9.4)       # S' in-box (dist 2 <= R=3)
    B1F.carve(f, 17, 20, 9.45)
    B1F.carve(f, 16, 20, 9.5)
    B1F.carve(f, 15, 20, 9.55)
    B1F.carve(f, 14, 20, 9.6)
    B1F.carve(f, 13, 20, 9.65)
    B1F.carve(f, 12, 20, 9.7)
    B1F.carve(f, 11, 20, 9.75)
    B1F.carve(f, 10, 20, 11.5)      # M2 elder, remote
    out.append((f, 20 * N + 20, 20 * N + 22, 'E2'))
    return out


def run_field(f, tag, stats, all_pairs, seen_pairs):
    dp1, dl1 = B1F.persistence(f)
    dp, dl, kb = persistence_killer(f)
    ck(dp == dp1, "%s: killer-variant persistence disagrees with B1F" % tag)
    maxima = [v for v in range(V) if B1F.is_local_max(f, v)]
    saddles = [v for v in range(V) if not B1F.is_local_max(f, v)
               and len(B1F.upper_link_clusters(f, v)) >= 2]
    npairs = 0
    for Sv in sorted(saddles):
        comp, maxkey = B1F.components_above(f, Sv)
        for Mv in sorted(maxima):
            if not all_pairs and B1F.cheb(Mv, Sv) > 4:
                continue
            res = audit_cover(f, Mv, Sv, dp, dl, kb, comp, maxkey, stats, tag)
            seen_pairs.add((f.tag, Mv, Sv, res))
            if res != 'notA':
                stats['A'] += 1
            if res == 'A.loc':
                stats['loc'] += 1
            npairs += 1
    return npairs


def f1_cover_mirror():
    stats = {'E1': 0, 'E2': 0, 'E3': 0, 'rem': 0, 'A': 0, 'loc': 0}
    seen = set()

    # carved non-vacuity witnesses
    for f, Mv, Sv, expect in synth_d3():
        ck(B1F.is_local_max(f, Mv), "%s: carved M not a local max" % f.tag)
        ck(len(B1F.upper_link_clusters(f, Sv)) >= 2,
           "%s: carved S not a PL saddle" % f.tag)
        stats2 = {'E1': 0, 'E2': 0, 'E3': 0, 'rem': 0, 'A': 0, 'loc': 0}
        dp, dl, kb = persistence_killer(f)
        dp1, dl1 = B1F.persistence(f)
        ck(dp == dp1, "%s: persistence cross-check failed" % f.tag)
        comp, maxkey = B1F.components_above(f, Sv)
        res = audit_cover(f, Mv, Sv, dp, dl, kb, comp, maxkey, stats2, f.tag)
        ck(res == 'A.rem', "%s: expected A.rem, got %s" % (f.tag, res))
        ck(stats2[expect] == 1, "%s: expected case %s, stats=%s"
           % (f.tag, expect, stats2))
        emit("synthetic %s -> A.rem case %s (as carved)" % (f.tag, expect))

    # ensemble: 40 seeds close pairs (B1's audit geometry) + 6 seeds all pairs
    total_pairs = 0
    for seed in range(40):
        f = B1F.fourier_field(1000 + seed, "ens-%d" % seed, ridge=(seed % 3 == 0))
        total_pairs += run_field(f, "ens-%d" % seed, stats, False, seen)
    for seed in range(6):
        f = B1F.fourier_field(7000 + seed, "wrap-%d" % seed, ridge=(seed % 2 == 0))
        total_pairs += run_field(f, "wrap-%d" % seed, stats, True, seen)
    emit("ensemble pairs audited: %d; A-failures: %d (A.loc %d, A.rem %d);"
         " A.rem case split: E1(remote S')=%d E2(remote elder)=%d E3(hole)=%d"
         % (total_pairs, stats['A'], stats['loc'], stats['rem'],
            stats['E1'], stats['E2'], stats['E3']))
    ck(total_pairs > 0, "vacuous ensemble")
    ck(stats['rem'] >= 50, "too few A.rem pairs: falsifier is weak")
    ck(stats['E1'] + stats['E2'] + stats['E3'] == stats['rem'],
       "case accounting mismatch")


# ---------------------------------------------------------------------------
# F2: engine re-run and headline windows
# ---------------------------------------------------------------------------
def f2_engine_rerun():
    ck(os.path.exists(T_NORMAL), "missing frozen transcript t_normal.txt")
    ck(os.path.exists(T_OPT), "missing frozen transcript t_opt.txt")
    with open(T_NORMAL, 'rb') as fh:
        frozen = fh.read()
    with open(T_OPT, 'rb') as fh:
        frozen_opt = fh.read()
    ck(frozen == frozen_opt, "frozen t_normal/t_opt differ (mode asymmetry)")
    proc = subprocess.run([sys.executable, 'd3_perc.py'], cwd=HERE,
                          capture_output=True)
    ck(proc.returncode == 0, "d3_perc.py exit %d:\n%s"
       % (proc.returncode, proc.stderr.decode('utf-8', 'replace')[-2000:]))
    out = proc.stdout
    ck(out == frozen,
       "d3_perc.py output drifted from frozen transcript (sha256 %s vs %s)"
       % (hashlib.sha256(out).hexdigest()[:16],
          hashlib.sha256(frozen).hexdigest()[:16]))
    txt = out.decode('utf-8')
    ck('D3-PERC PASS digest=' in txt, "engine PASS line missing")
    # headline windows parsed from the fresh output
    m = re.search(r'0\.05\s+2\.08333e-5\s+\S+\s+\S+\s+(\d+\.\d+)', txt)
    ck(m and 2.92 < float(m.group(1)) < 2.93, "I_uncond/r^3 window breach")
    m = re.search(r'ASSEMBLY \(spine\):.*?= (\d+\.\d+) r\^3', txt)
    ck(m and 19.0 < float(m.group(1)) < 23.0, "spine total window breach")
    m = re.search(r'ASSEMBLY \(typed-y evidence envelope\): <= (\d+\.\d+) r\^3', txt)
    ck(m and 4.5 < float(m.group(1)) < 6.0, "typed-y total window breach")
    m = re.search(r'^\s*5\s+0\s+\S+\s+\S+\s+\S+\s+\S+\s+\S+\s+\S+\s+([\d.]+)\(cert\)',
                  txt, re.M)
    ck(m and 0.4 < float(m.group(1)) < 0.9, "rel kap_cross(5,axis) window breach")
    m = re.search(r'^\s*5\s+90\s+.*?([\d.]+) \+-[\d.]+\s+[\d.]+\+-[\d.]+$', txt, re.M)
    ck(m and 0.95 < float(m.group(1)) < 1.08, "g-RN(5,transverse) window breach")
    emit("engine re-run: exit 0, byte-identical to frozen transcript;"
         " headline windows all green")


# ---------------------------------------------------------------------------
# F3: amendment engine re-run + the DISCRIMINATING bracket gate (R3 repair):
# the certified B_remote must land in the kappa-inclusive window, and the
# gate must reject the kappa=0 sum 19.5465 (= 17.0182 + 2.52826 flat).
# ---------------------------------------------------------------------------
TA_NORMAL = os.path.join(HERE, 'ta_normal.txt')
TA_OPT = os.path.join(HERE, 'ta_opt.txt')

BRACKET_KAPPA0 = 17.0182 + 2.52826          # 19.54646: the kappa=0 reading
BRACKET_LO = BRACKET_KAPPA0 + 1.0           # 20.54646: discrimination edge
BRACKET_HI = 22.5


def bracket_gate(val):
    """The discriminating window: accepts only the kappa-inclusive certified
    bracket. Rejects the kappa=0 sum (19.5465), the superseded THM display's
    remote part (19.616), and any kappa_far < ~0.40 reading."""
    return BRACKET_LO <= val <= BRACKET_HI


def parse_bracket(txt):
    m = re.search(r'CERTIFIED BRACKET: B_remote <= ([\d.]+) \(round UP', txt)
    ck(m, "certified bracket line missing from amendment output")
    return float(m.group(1))


def f3_amendment_rerun():
    ck(os.path.exists(TA_NORMAL), "missing frozen transcript ta_normal.txt")
    ck(os.path.exists(TA_OPT), "missing frozen transcript ta_opt.txt")
    with open(TA_NORMAL, 'rb') as fh:
        frozen = fh.read()
    with open(TA_OPT, 'rb') as fh:
        frozen_opt = fh.read()
    ck(frozen == frozen_opt, "frozen ta_normal/ta_opt differ (mode asymmetry)")
    proc = subprocess.run([sys.executable, 'd3_amend.py'], cwd=HERE,
                          capture_output=True)
    ck(proc.returncode == 0, "d3_amend.py exit %d:\n%s"
       % (proc.returncode, proc.stderr.decode('utf-8', 'replace')[-2000:]))
    out = proc.stdout
    ck(out == frozen,
       "d3_amend.py output drifted from frozen transcript (sha256 %s vs %s)"
       % (hashlib.sha256(out).hexdigest()[:16],
          hashlib.sha256(frozen).hexdigest()[:16]))
    txt = out.decode('utf-8')
    ck('D3-AMEND PASS digest=' in txt, "amendment PASS line missing")
    bval = parse_bracket(txt)
    ck(bracket_gate(bval),
       "bracket %s fails the discriminating gate [%s, %s]"
       % (bval, BRACKET_LO, BRACKET_HI))
    m = re.search(r'kappa_far\^\(a\) \(assembled, axis-worst\)\s+= ([\d.]+)', txt)
    ck(m and 0.60 < float(m.group(1)) < 0.70,
       "assembled kappa_far window breach")
    m = re.search(r'kappa_pair \(chi2 route, certified\)\s+= ([\d.e-]+)', txt)
    ck(m and float(m.group(1)) < 0.01, "kappa_pair window breach")
    emit("amendment re-run: exit 0, byte-identical; certified bracket %s"
         " inside the discriminating gate [%s, %s] (kappa=0 sum %s rejected"
         " by construction)" % (bval, BRACKET_LO, BRACKET_HI, BRACKET_KAPPA0))


# ---------------------------------------------------------------------------
# F4: mutation suite -- the gate and the freeze-before-consume pins must
# fire on adversarial inputs.
# ---------------------------------------------------------------------------
def f4_mutation_suite():
    # MUT-1 gate self-test: the kappa=0 readings and range violators must be
    # rejected; the certified value must be accepted.
    rejects = [BRACKET_KAPPA0, 19.5465, 19.616, 20.0, 20.5, 22.5001, 25.0,
               17.0182 + 2.52826 * 1.3]          # kappa_far = 0.3 mutation
    for v in rejects:
        ck(not bracket_gate(v),
           "MUT-1 fail: gate accepted the mutated bracket %s" % v)
    accepts = [20.55, 21.2153, 22.5,
               17.0183 + 2.52826 * 1.66]          # the certified reading
    for v in accepts:
        ck(bracket_gate(v),
           "MUT-1 fail: gate rejected the certified bracket %s" % v)
    emit("MUT-1 gate self-test: %d mutated readings rejected, %d certified"
         " readings accepted" % (len(rejects), len(accepts)))

    # MUT-2 transcript tamper through the parse path: a transcript carrying
    # the kappa=0 sum as the bracket must fail the gate.
    with open(TA_NORMAL, 'rb') as fh:
        tampered = fh.read().decode('utf-8')
    tampered2 = re.sub(r'(CERTIFIED BRACKET: B_remote <= )[\d.]+',
                       r'\g<1>19.5465', tampered)
    ck(tampered2 != tampered, "MUT-2 setup: tamper regex did not bite")
    ck(not bracket_gate(parse_bracket(tampered2)),
       "MUT-2 fail: gate accepted a tampered (kappa=0) transcript")
    tampered3 = re.sub(r'(CERTIFIED BRACKET: B_remote <= )[\d.]+',
                       r'\g<1>23.99', tampered)
    ck(not bracket_gate(parse_bracket(tampered3)),
       "MUT-2 fail: gate accepted an inflated bracket")
    emit("MUT-2 transcript tamper: kappa=0 and inflated tampered transcripts"
         " both rejected")

    # MUT-3 freeze-before-consume tamper: a one-hex mutation of the engine's
    # hash pin for d3_perc.py must SystemExit before any computation.
    with open(os.path.join(HERE, 'd3_amend.py'), 'r') as fh:
        src = fh.read()
    i = src.find("'d3_perc.py': '")
    ck(i > 0, "MUT-3 setup: pin not found")
    j = src.find("'", i + 15)
    pin = src[i + 15:j]
    mut = src[:i + 15] + ('0' if pin[0] != '0' else '1') + src[i + 16:]
    mutpath = os.path.join(HERE, '_mut_amend.py')
    with open(mutpath, 'w') as fh:
        fh.write(mut)
    try:
        proc = subprocess.run([sys.executable, '_mut_amend.py'], cwd=HERE,
                              capture_output=True)
        ck(proc.returncode != 0,
           "MUT-3 fail: tampered hash pin did not fire")
        ck(b'hash pin mismatch' in proc.stdout,
           "MUT-3 fail: unexpected failure mode: %s"
           % proc.stdout.decode('utf-8', 'replace')[-300:])
    finally:
        os.unlink(mutpath)
    emit("MUT-3 freeze-before-consume: one-hex pin mutation -> SystemExit"
         " with the hash-pin failure")


# ---------------------------------------------------------------------------
# F5: v2 amendment engine re-run + the OPERATIVE discriminating gate (R2/V1):
# the certified floor-consistent bracket must land in [21.24, 22.5]; the gate
# rejects the kappa=0 reading (19.5465), the v1 QMC-denominator bracket
# (21.2153), and the mixed-denominator form (21.2658).
# ---------------------------------------------------------------------------
TA2_NORMAL = os.path.join(HERE, 'ta2_normal.txt')
TA2_OPT = os.path.join(HERE, 'ta2_opt.txt')

V2_KAPPA0 = 17.0182 + 2.52826                    # 19.54646
V1_BRACKET = 21.2153                             # kappas at the QMC probe
V2_MIXED = 17.0183 + 2.5282637 * 1.68            # 21.2658: floor kappas,
                                                 # probe-denominator I_ann
V2_BRACKET = 21.9279                             # floor-consistent certified
# GATE_LO note: the R2-round prescription said [21.24, 22.5], but the mixed
# form 21.2658 > 21.24, so that edge cannot reject it; 21.27 is the minimal
# edge satisfying ALL four required discriminations (reject 19.5465,
# 21.2153, 21.2658; accept 21.9279).
GATE_LO = 21.27
GATE_HI = 22.5


def gate_v2(val):
    return GATE_LO <= val <= GATE_HI


def f5_amendment_v2_rerun():
    ck(os.path.exists(TA2_NORMAL), "missing frozen transcript ta2_normal.txt")
    ck(os.path.exists(TA2_OPT), "missing frozen transcript ta2_opt.txt")
    with open(TA2_NORMAL, 'rb') as fh:
        frozen = fh.read()
    with open(TA2_OPT, 'rb') as fh:
        frozen_opt = fh.read()
    ck(frozen == frozen_opt, "frozen ta2_normal/ta2_opt differ (mode asymmetry)")
    proc = subprocess.run([sys.executable, 'd3_amend_v2.py'], cwd=HERE,
                          capture_output=True)
    ck(proc.returncode == 0, "d3_amend_v2.py exit %d:\n%s"
       % (proc.returncode, proc.stderr.decode('utf-8', 'replace')[-2000:]))
    out = proc.stdout
    ck(out == frozen,
       "d3_amend_v2.py output drifted from frozen transcript (sha256 %s vs %s)"
       % (hashlib.sha256(out).hexdigest()[:16],
          hashlib.sha256(frozen).hexdigest()[:16]))
    txt = out.decode('utf-8')
    ck('D3-AMEND-V2 PASS digest=' in txt, "v2 PASS line missing")
    m = re.search(r'CERTIFIED BRACKET \(floor-consistent\): B_remote <= ([\d.]+)',
                  txt)
    ck(m, "v2 certified bracket line missing")
    bval = float(m.group(1))
    ck(gate_v2(bval),
       "v2 bracket %s outside the operative gate [%s, %s]"
       % (bval, GATE_LO, GATE_HI))
    m = re.search(r'\[R2 floor, certified\].*?kappa_far = ([\d.]+)', txt)
    ck(m and 0.65 < float(m.group(1)) < 0.70,
       "floor kappa_far window breach")
    m = re.search(r'Num_ann/Z_probe/r\^3 = ([\d.]+)', txt)
    ck(m and abs(float(m.group(1)) - 17.0182368) < 0.001,
       "Num_ann consistency window breach")
    emit("v2 re-run: exit 0, byte-identical; certified floor-consistent"
         " bracket %s inside the operative gate [%s, %s]; the kappa=0"
         " reading %s, the QMC-denominator bracket %s, and the mixed"
         " denominator form %s are all below the gate edge"
         % (bval, GATE_LO, GATE_HI, V2_KAPPA0, V1_BRACKET, V2_MIXED))


# ---------------------------------------------------------------------------
# F6: v2 mutation suite -- the operative gate and the floor pin must fire on
# adversarial denominators (any denominator above the certified floor fails
# closed).
# ---------------------------------------------------------------------------
def f6_mutation_suite_v2():
    # MUT-V2-1 gate self-test: sub-floor-denominator brackets rejected, the
    # certified bracket accepted.
    rejects = [V2_KAPPA0, V1_BRACKET, V2_MIXED, 19.616, 20.9, 21.0,
               21.2399, 22.5001, 25.0]
    for v in rejects:
        ck(not gate_v2(v), "MUT-V2-1 fail: gate accepted %s" % v)
    accepts = [V2_BRACKET, 21.27, 21.92788306, 22.5]
    for v in accepts:
        ck(gate_v2(v), "MUT-V2-1 fail: gate rejected the certified %s" % v)
    emit("MUT-V2-1 gate self-test: %d sub-floor/out-of-range readings"
         " rejected (incl. kappa=0 %s, QMC-denominator %s, mixed %s),"
         " %d certified readings accepted"
         % (len(rejects), V2_KAPPA0, V1_BRACKET, V2_MIXED, len(accepts)))

    # MUT-V2-2 transcript tamper through the v2 parse path.
    with open(TA2_NORMAL, 'rb') as fh:
        tampered = fh.read().decode('utf-8')
    for bad in ['21.2153', '21.2658', '19.5465', '23.99']:
        t2 = re.sub(r'(CERTIFIED BRACKET \(floor-consistent\): B_remote <= )'
                    r'[\d.]+', r'\g<1>' + bad, tampered)
        ck(t2 != tampered, "MUT-V2-2 setup: tamper regex did not bite")
        m = re.search(r'CERTIFIED BRACKET \(floor-consistent\): B_remote <= '
                      r'([\d.]+)', t2)
        ck(m and not gate_v2(float(m.group(1))),
           "MUT-V2-2 fail: gate accepted tampered bracket %s" % bad)
    emit("MUT-V2-2 transcript tamper: QMC-denominator, mixed, kappa=0, and"
         " inflated tampered transcripts all rejected")

    # MUT-V2-3 QMC-denominator injection at the floor pin: mutating the
    # engine's pinned floor literal to the QMC probe value must fire the
    # fail-closed floor-drift ck BEFORE any computation.
    with open(os.path.join(HERE, 'd3_amend_v2.py'), 'r') as fh:
        src = fh.read()
    pin = "mpf('7.7592917375327855e-3')"
    ck(pin in src, "MUT-V2-3 setup: floor literal not found")
    mut = src.replace(pin, "mpf('8.061180539e-3')")   # QMC probe injection
    mutpath = os.path.join(HERE, '_mut_amend_v2.py')
    with open(mutpath, 'w') as fh:
        fh.write(mut)
    try:
        proc = subprocess.run([sys.executable, '_mut_amend_v2.py'], cwd=HERE,
                              capture_output=True)
        ck(proc.returncode != 0,
           "MUT-V2-3 fail: QMC-denominator injection did not fire")
        ck(b'R2 floor drifted' in proc.stdout,
           "MUT-V2-3 fail: unexpected failure mode: %s"
           % proc.stdout.decode('utf-8', 'replace')[-300:])
    finally:
        os.unlink(mutpath)
    emit("MUT-V2-3 QMC-denominator injection: mutated floor literal ->"
         " SystemExit with the R2 floor-drift failure")

    # MUT-V2-4 hash-pin tamper on the R2 artifact pin.
    m_pin = re.search(r"(H3_RUNG_FLOOR\.md':\s*\n\s*')([0-9a-f]{64})(')",
                      src)
    ck(m_pin, "MUT-V2-4 setup: artifact pin not found")
    h0 = m_pin.group(2)
    mut = (src[:m_pin.start(2)] + ('0' if h0[0] != '0' else '1')
           + src[m_pin.start(2) + 1:])
    mutpath = os.path.join(HERE, '_mut_amend_v2.py')
    with open(mutpath, 'w') as fh:
        fh.write(mut)
    try:
        proc = subprocess.run([sys.executable, '_mut_amend_v2.py'], cwd=HERE,
                              capture_output=True)
        ck(proc.returncode != 0,
           "MUT-V2-4 fail: artifact hash-pin mutation did not fire")
        ck(b'hash pin mismatch' in proc.stdout,
           "MUT-V2-4 fail: unexpected failure mode: %s"
           % proc.stdout.decode('utf-8', 'replace')[-300:])
    finally:
        os.unlink(mutpath)
    emit("MUT-V2-4 freeze-before-consume: one-hex R2-artifact pin mutation"
         " -> SystemExit with the hash-pin failure")


# ---------------------------------------------------------------------------
# F7: PERC-DECAY engine re-run (Theorem (2) validity-premise lane): byte
# identity vs the frozen transcripts; the register must carry exactly the
# three far-lane classes, each with a certified bound, a named missing
# input, and a precise uncontrolled region; the count bounds within their
# windows.
# ---------------------------------------------------------------------------
PD_NORMAL = os.path.join(HERE, 'pd_normal.txt')
PD_OPT = os.path.join(HERE, 'pd_opt.txt')


def f7_perc_decay_rerun():
    ck(os.path.exists(PD_NORMAL), "missing frozen transcript pd_normal.txt")
    ck(os.path.exists(PD_OPT), "missing frozen transcript pd_opt.txt")
    with open(PD_NORMAL, 'rb') as fh:
        frozen = fh.read()
    with open(PD_OPT, 'rb') as fh:
        frozen_opt = fh.read()
    ck(frozen == frozen_opt, "frozen pd_normal/pd_opt differ (mode asymmetry)")
    proc = subprocess.run([sys.executable, 'd3_perc_decay.py'], cwd=HERE,
                          capture_output=True)
    ck(proc.returncode == 0, "d3_perc_decay.py exit %d:\n%s"
       % (proc.returncode, proc.stderr.decode('utf-8', 'replace')[-2000:]))
    out = proc.stdout
    ck(out == frozen,
       "d3_perc_decay.py output drifted from frozen transcript (sha256 %s vs %s)"
       % (hashlib.sha256(out).hexdigest()[:16],
          hashlib.sha256(frozen).hexdigest()[:16]))
    txt = out.decode('utf-8')
    ck('D3-PERC-DECAY PASS digest=' in txt, "PERC-DECAY PASS line missing")
    for cls in ('B1.dir-far', 'B2-far', 'B4.rem'):
        ck('[%s] certified:' % cls in txt, "register entry missing: %s" % cls)
    ck(txt.count('missing: PD-CONN') == 3,
       "register missing-input entries drifted")
    for i in (1, 2, 3, 4, 5):
        ck('MUT-PD-%d ' % i in txt, "mutation MUT-PD-%d line missing" % i)
    ck(txt.count('mutation -> SystemExit with the expected failure') >= 5,
       "not all five PD6 mutations fired in the re-run")
    m = re.search(r'E_\{P_r\}\[N_w\(d >= 0\.2\)\] <= Num/Z_lo = ([\d.]+) r\^3',
                  txt)
    ck(m and 17.0 < float(m.group(1)) < 23.0,
       "far-lane count bound window breach")
    m = re.search(r'bottleneck z-score ([\d.]+)', txt)
    ck(m and 0.4 < float(m.group(1)) < 1.2,
       "corridor bottleneck display drifted: the Theta(1) verdict display")
    emit("PERC-DECAY re-run: exit 0, byte-identical; register carries the"
         " three far-lane classes each with a certified bound + PD-CONN + a"
         " precise region; all five mutations fired; count bound %s r^3 and"
         " the corridor bottleneck z = %s within their windows"
         % (m and re.search(r'E_\{P_r\}\[N_w\(d >= 0\.2\)\] <= Num/Z_lo = '
                          r'([\d.]+) r\^3', txt).group(1),
            re.search(r'bottleneck z-score ([\d.]+)', txt).group(1)))


def main():
    f1_cover_mirror()
    f2_engine_rerun()
    f3_amendment_rerun()
    f4_mutation_suite()
    f5_amendment_v2_rerun()
    f6_mutation_suite_v2()
    f7_perc_decay_rerun()
    body = "\n".join(LINES) + "\n"
    digest = hashlib.sha256(body.encode('utf-8')).hexdigest()
    print("D3-FALSIFIER PASS digest=%s" % digest)
    raise SystemExit(0)


if __name__ == "__main__":
    main()
