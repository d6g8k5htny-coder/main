"""Exact jet formulas and rational norm enclosures for whitened Gaussian chi-square.

Raw derivatives, NOT Taylor coefficients, throughout. Dimension d is arbitrary.
Numerical functions lazily require mpmath. Rational enclosure functions use only
the Python standard library and never convert an enclosure through binary float.
The field-dependent inputs must themselves be proved enclosures on the domain.
Author-side reconstruction, 2026-09-17; no RN-UNIF closure assertion.
"""
from dataclasses import dataclass
from fractions import Fraction as Q
from math import comb, factorial, isqrt


def rational(x):
    if isinstance(x, float):
        raise TypeError("Use exact integers/Fractions or decimal strings, not float")
    return Q(x)


@dataclass(frozen=True)
class Interval:
    """Closed rational interval; operations are exact outward enclosures."""
    lo: Q
    hi: Q

    def __init__(self, lo, hi=None):
        lo = rational(lo)
        hi = lo if hi is None else rational(hi)
        if lo > hi:
            raise ValueError("Reversed interval")
        object.__setattr__(self, "lo", lo)
        object.__setattr__(self, "hi", hi)

    def __add__(self, other):
        other = as_interval(other)
        return Interval(self.lo + other.lo, self.hi + other.hi)

    __radd__ = __add__

    def __neg__(self):
        return Interval(-self.hi, -self.lo)

    def __sub__(self, other):
        return self + (-as_interval(other))

    def __rsub__(self, other):
        return as_interval(other) + (-self)

    def __mul__(self, other):
        other = as_interval(other)
        p = [self.lo * other.lo, self.lo * other.hi,
             self.hi * other.lo, self.hi * other.hi]
        return Interval(min(p), max(p))

    __rmul__ = __mul__

    def reciprocal(self):
        if self.lo <= 0 <= self.hi:
            raise ValueError("Interval denominator contains zero")
        return Interval(1 / self.hi, 1 / self.lo)

    def __truediv__(self, other):
        return self * as_interval(other).reciprocal()

    def __rtruediv__(self, other):
        return as_interval(other) * self.reciprocal()

    def abs_upper(self):
        return max(abs(self.lo), abs(self.hi))


def as_interval(x):
    return x if isinstance(x, Interval) else Interval(x)


def imatrix(rows):
    rows = [[as_interval(x) for x in row] for row in rows]
    if not rows or not rows[0] or any(len(row) != len(rows[0]) for row in rows):
        raise ValueError("Expected a nonempty rectangular matrix")
    return rows


def izeros(n, m):
    return [[Interval(0) for _ in range(m)] for _ in range(n)]


def itranspose(A):
    return [list(x) for x in zip(*A)]


def iadd(A, B):
    if len(A) != len(B) or len(A[0]) != len(B[0]):
        raise ValueError("Matrix shapes differ")
    return [[a + b for a, b in zip(ar, br)] for ar, br in zip(A, B)]


def iscale(c, A):
    return [[c * a for a in row] for row in A]


def imul(A, B):
    if len(A[0]) != len(B):
        raise ValueError("Matrix product shape mismatch")
    return [[sum((A[i][k] * B[k][j] for k in range(len(B))), Interval(0))
             for j in range(len(B[0]))] for i in range(len(A))]


def ispd(A):
    """Sufficient interval LDL test. Symmetric exact matrix is a precondition.

    Enclosure arrays must be symmetric; this does not certify that an unknown
    matrix selected independently from those intervals is itself symmetric.
    """
    n = len(A)
    if len(A[0]) != n or any(A[i][j] != A[j][i] for i in range(n) for j in range(n)):
        raise ValueError("Symmetric square interval array required")
    L = izeros(n, n)
    D = []
    for i in range(n):
        pivot = A[i][i] - sum((L[i][k] * L[i][k] * D[k] for k in range(i)), Interval(0))
        if pivot.lo <= 0:
            raise ValueError("Positive definiteness not certified by interval LDL")
        D.append(pivot)
        L[i][i] = Interval(1)
        for j in range(i + 1, n):
            L[j][i] = (A[j][i] - sum((L[j][k] * L[i][k] * D[k]
                                    for k in range(i)), Interval(0))) / pivot
    return True


def iinverse(A):
    """Enclose every inverse in an interval matrix box via Gauss-Jordan.

    Fails if no pivot excluding zero is available. Such failure is inconclusive.
    Positive definiteness, when needed, must be checked separately with ispd.
    """
    n = len(A)
    if len(A[0]) != n:
        raise ValueError("Inverse requires square matrix")
    T = [row[:] + [Interval(int(i == j)) for j in range(n)] for i, row in enumerate(A)]
    for k in range(n):
        candidates = [i for i in range(k, n) if not (T[i][k].lo <= 0 <= T[i][k].hi)]
        if not candidates:
            raise ValueError("Interval elimination cannot certify a nonzero pivot")
        i = candidates[0]
        T[k], T[i] = T[i], T[k]
        pivot = T[k][k]
        T[k] = [x / pivot for x in T[k]]
        # These identities hold pointwise; impose them to reduce dependency.
        T[k][k] = Interval(1)
        for i in range(n):
            if i != k:
                multiplier = T[i][k]
                T[i] = [x - multiplier * y for x, y in zip(T[i], T[k])]
                T[i][k] = Interval(0)
    return [row[n:] for row in T]


def iproduct_jets(X, Y):
    if len(X) != len(Y):
        raise ValueError("Jet orders differ")
    result = []
    for n in range(len(X)):
        z = izeros(len(X[0]), len(Y[0][0]))
        for j in range(n + 1):
            z = iadd(z, iscale(comb(n, j), imul(X[j], Y[n-j])))
        result.append(z)
    return result


def iinverse_jets(X, require_spd=True):
    if require_spd:
        ispd(X[0])
    R = [iinverse(X[0])]
    for n in range(1, len(X)):
        z = izeros(len(X[0]), len(X[0]))
        for j in range(1, n + 1):
            z = iadd(z, iscale(comb(n, j), imul(X[j], R[n-j])))
        R.append(iscale(-1, imul(R[0], z)))
    return R


def conditional_interval_jets(F, D, z):
    """Actual Schur jets A=F D^-1 F^T, m=F D^-1 z, with D SPD.

    F/D/z are interval enclosures of raw derivatives through the same order.
    z is a column vector. Enforces covariance smallness later via norm_envelope.
    """
    if len(F) != len(D) or len(F) != len(z):
        raise ValueError("Jet orders differ")
    J = iinverse_jets(D)
    FJ = iproduct_jets(F, J)
    A = iproduct_jets(FJ, [itranspose(x) for x in F])
    m = iproduct_jets(FJ, z)
    return A, m


def whiten_interval_jets(S, mu, W, reference_mean):
    """Whiten actual covariance/mean jets using y-independent exact W.

    W and reference_mean may be enclosures. The caller must establish the
    identity W S_reference W^T=I for the same exact W being enclosed.
    """
    if len(S) != len(mu):
        raise ValueError("Jet orders differ")
    WT = itranspose(W)
    A, m = [], []
    dim = len(W)
    for j in range(len(S)):
        Aj = iscale(-1, imul(imul(W, S[j]), WT))
        if j == 0:
            Aj = iadd(Aj, [[Interval(int(i == k)) for k in range(dim)] for i in range(dim)])
        muj = mu[j] if j else iadd(mu[0], iscale(-1, reference_mean))
        A.append(Aj)
        m.append(imul(W, muj))
    return A, m


def sqrt_upper(x, bits=80):
    x = rational(x)
    if x < 0:
        raise ValueError("Negative square-root argument")
    scale = 1 << bits
    n = isqrt((x.numerator * scale * scale) // x.denominator)
    if n * n * x.denominator < x.numerator * scale * scale:
        n += 1
    return Q(n, scale)


def spectral_norm_upper(A):
    """min(Frobenius, sqrt(max-row-absolute-sum * max-column-sum))."""
    B = [[as_interval(x).abs_upper() for x in row] for row in A]
    frob2 = sum(x*x for row in B for x in row)
    rowcol = max(map(sum, B)) * max(map(sum, zip(*B)))
    return sqrt_upper(min(frob2, rowcol))


def exp_upper(x):
    """Rational exp upper bound: exp(x)<=(1-x/N)^(-N), N>=32*x."""
    x = rational(x)
    if x < 0:
        raise ValueError("This upper bound expects x>=0")
    if x == 0:
        return Q(1)
    n = max(1, (32*x.numerator + x.denominator-1)//x.denominator)
    if n > 100000:
        raise ValueError("Envelope too large for this rational implementation")
    return (Q(n)/(n-x))**n


def norm_envelope(a, c, dimension, chi2_floor=None):
    """Certified rational bounds through order four from true input jet bounds.

    a[j]>=sup ||A^(j)||_2 and c[j]>=sup ||m^(j)||_2 on ONE common
    domain/direction family. Symmetric A and a[0]<1 are assumptions.
    chi2_floor, if supplied, is a certified strictly positive lower bound
    for exp(logq)-1 on that same domain. No floor is inferred from samples.
    """
    a, c = list(map(rational, a)), list(map(rational, c))
    if len(a) != 5 or len(c) != 5 or dimension < 1:
        raise ValueError("Need orders 0..4 and positive dimension")
    if any(x < 0 for x in a+c) or a[0] >= 1:
        raise ValueError("Nonnegative norm bounds with a0<1 required")
    # U=A^2 retains covariance cancellation at A=0.
    u = [sum(Q(comb(n,j))*a[j]*a[n-j] for j in range(n+1)) for n in range(5)]
    h, b = [1/(1-a[0]*a[0])], [1/(1-a[0])]
    for n in range(1, 5):
        h.append(h[0]*sum(Q(comb(n,j))*u[j]*h[n-j] for j in range(1,n+1)))
        b.append(b[0]*sum(Q(comb(n,j))*a[j]*b[n-j] for j in range(1,n+1)))
    ell = [Q(dimension)*a[0]**2/(2*(1-a[0]**2)) + c[0]**2/(1-a[0])]
    for n in range(1,5):
        det = Q(dimension,2)*sum(Q(comb(n-1,j))*h[j]*u[n-j] for j in range(n))
        mean = sum(Q(factorial(n),factorial(i)*factorial(j)*factorial(n-i-j))*
                   c[i]*b[j]*c[n-i-j] for i in range(n+1) for j in range(n-i+1))
        ell.append(det+mean)
    e = exp_upper(ell[0])
    X = [e-1, e*ell[1], e*(ell[2]+ell[1]**2),
         e*(ell[3]+3*ell[1]*ell[2]+ell[1]**3),
         e*(ell[4]+4*ell[1]*ell[3]+3*ell[2]**2+6*ell[1]**2*ell[2]+ell[1]**4)]
    result = dict(A_norm=a, m_norm=c, logq=ell, chi2=X,
                  covariance_domain="conditional on true symmetric input jets", lemma_closed=False)
    if chi2_floor is not None:
        floor = rational(chi2_floor)
        if floor <= 0:
            raise ValueError("sqrt composition requires a strictly positive chi2 floor")
        # 1/sqrt(floor) <= sqrt_upper(1/floor), with rational arithmetic.
        t = sqrt_upper(1/floor)
        result['sqrt_chi2'] = [sqrt_upper(X[0]),
            X[1]*t/2,
            X[2]*t/2 + X[1]**2*t/(4*floor),
            X[3]*t/2 + 3*X[1]*X[2]*t/(4*floor)+3*X[1]**3*t/(8*floor**2),
            X[4]*t/2+(X[1]*X[3]+Q(3,4)*X[2]**2)*t/floor+
            Q(9,4)*X[1]**2*X[2]*t/floor**2+Q(15,16)*X[1]**4*t/floor**3]
    return result


def interval_envelope(A, m, chi2_floor=None):
    if len(A) != 5 or len(m) != 5:
        raise ValueError("Need interval jets through order four")
    return norm_envelope([spectral_norm_upper(x) for x in A],
                         [spectral_norm_upper(x) for x in m], len(A[0]), chi2_floor)


def product_jets(X, Y):
    """Ordered matrix product of numerical raw jets (mpmath matrices)."""
    if len(X) != len(Y):
        raise ValueError("Jet orders differ")
    return [sum((comb(n,j)*X[j]*Y[n-j] for j in range(n+1)), X[0]*Y[0]*0)
            for n in range(len(X))]


def inverse_jets(X):
    R = [X[0]**-1]
    for n in range(1,len(X)):
        R.append(-R[0]*sum((comb(n,j)*X[j]*R[n-j] for j in range(1,n+1)), X[0]*0))
    return R


def conditional_jets(F, D, z):
    J = inverse_jets(D)
    FJ = product_jets(F,J)
    return product_jets(FJ,[x.T for x in F]), product_jets(FJ,z)


def logq_jets(A, m):
    """Point numerical evaluation of exact identities; NOT interval certification."""
    from mpmath import mp
    if len(A) != len(m) or not A:
        raise ValueError("Matching nonempty jet lists required")
    nmax, d = len(A)-1, A[0].rows
    if any(x.rows != d or x.cols != d for x in A) or any(x.rows != d or x.cols != 1 for x in m):
        raise ValueError("Jet dimensions mismatch")
    # Do not infer positive definiteness from det alone.
    if min(mp.eigsy(mp.eye(d)-A[0], eigvals_only=True)) <= 0 or min(mp.eigsy(mp.eye(d)+A[0], eigvals_only=True)) <= 0:
        raise ValueError("Finite chi-square requires -I<A<I")
    B = inverse_jets([mp.eye(d)+A[0]]+list(A[1:]))
    C = inverse_jets([mp.eye(d)-A[0]]+[-x for x in A[1:]])
    tr = lambda M: mp.fsum(M[i,i] for i in range(d))
    ell = [-mp.log(mp.det(mp.eye(d)-A[0]*A[0]))/2+(m[0].T*B[0]*m[0])[0]]
    for n in range(1,nmax+1):
        det = -mp.fsum(comb(n-1,j)*tr((B[j]-C[j])*A[n-j]) for j in range(n))/2
        mean = mp.fsum((factorial(n)//(factorial(i)*factorial(j)*factorial(n-i-j)))*
                       (m[i].T*B[j]*m[n-i-j])[0]
                       for i in range(n+1) for j in range(n-i+1))
        ell.append(det+mean)
    return ell


def chi2_jets(logq):
    """Complete exponential Bell polynomial, any supplied order."""
    from mpmath import mp
    e = [mp.exp(logq[0])]
    for n in range(1,len(logq)):
        e.append(mp.fsum(comb(n-1,j)*logq[j+1]*e[n-1-j] for j in range(n)))
    return [mp.expm1(logq[0])]+e[1:]


def sqrt_jets(X):
    """Raw jet of sqrt(X) from the exact identity g^2=X; X0 must be >0."""
    from mpmath import mp
    if X[0] <= 0:
        raise ValueError("Positive point value is required; uniform bounds need a floor")
    g = [mp.sqrt(X[0])]
    for n in range(1,len(X)):
        g.append((X[n]-mp.fsum(comb(n,j)*g[j]*g[n-j] for j in range(1,n)))/(2*g[0]))
    return g
