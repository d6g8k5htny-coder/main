"""Point-only SIDE24 source adapter for whitened raw jets through order four.

This computes derivatives of the source engine's finite-image kernel. It does
NOT certify its infinite periodization tail, arithmetic error, any cell, or any
uniform domain. The shared immutable engine is imported without modification.
"""
from pathlib import Path
from math import comb
import contextlib
import hashlib
import io
import json
import os
import sys
from mpmath import mp
from rnu_white import product_jets, conditional_jets, logq_jets, chi2_jets

BASE=Path(__file__).resolve().parents[2]
ENG=BASE/'intake/rn_source/K3_SIDE24_LB/UPPER2D/D3_percolation'
PIN='85d7725fab42eeb0e823226f44d17f142a5c57e5d89084b2b6edffe4a8f0c930'


def load_engine():
    if hashlib.sha256((ENG/'d3_rn_unif.py').read_bytes()).hexdigest()!=PIN:
        raise RuntimeError('Source engine byte mismatch')
    sys.path.insert(0,str(ENG))
    sys.path.insert(0,str(ENG.parent/'H2_foundations'))
    previous=Path.cwd()
    captured=io.StringIO()
    try:
        os.chdir(ENG)
        with contextlib.redirect_stdout(captured):
            import d3_rn_unif as R
    finally:
        os.chdir(previous)
    return R, captured.getvalue()


def structural_jets(R,y,u,order=4):
    W=mp.matrix([[R.V0[j,k]/mp.sqrt(R.LAM0[k]) for j in range(6)] for k in range(6)])
    Y=[]
    V=[]
    for n in range(order+1):
        Yn=mp.zeros(3,6)
        Vn=mp.zeros(6,3)
        for k in range(n+1):
            coeff=comb(n,k)*u[0]**k*u[1]**(n-k)
            for i,(_,di) in enumerate(R.YJET):
                ai=R._GI[di]
                aug=(ai[0]+k,ai[1]+n-k)
                for j,(pj,dj) in enumerate(R.CSET6):
                    p=R.PTS[pj]
                    Yn[i,j]+=coeff*R.kdcov(aug,R._GI[dj],y[0]-p[0],y[1]-p[1])
            for i,(pi,di) in enumerate(R.TSET9[:6]):
                p=R.PTS[pi]
                for j,(_,dj) in enumerate(R.YJET):
                    bj=R._GI[dj]
                    aug=(bj[0]+k,bj[1]+n-k)
                    Vn[i,j]+=coeff*R.kdcov(R._GI[di],aug,p[0]-y[0],p[1]-y[1])
        Y.append(Yn)
        V.append(Vn)
    YY=mp.matrix([[R.kdcov(R._GI[di],R._GI[dj],0,0)
                   for _,dj in R.YJET] for _,di in R.YJET])
    F=[W*(V[n]-R.X6*R.G6inv*Y[n].T) for n in range(order+1)]
    YGY=product_jets([x*R.G6inv for x in Y],[x.T for x in Y])
    D=[YY-YGY[0]]+[-x for x in YGY[1:]]
    z=[-x*R._W6 for x in Y]
    z[0][0]+=R.kit.b-R.kit.ell/2
    A,m=conditional_jets(F,D,z)
    return A,m


def original_logq(R,y):
    fs=R.station_fast_full(y)
    v=R.kit.b-R.kit.ell/2
    muv=fs['mean_v'](v)
    mu9p=mp.matrix([muv[i] for i in range(6)])
    mu6=R.kit.Hmean
    Sp=R.E.submat(fs['cov9'],range(6),range(6))
    S6=R.kit.Hcov
    S9i=Sp**-1
    S6i=S6**-1
    M=S9i-S6i/2
    c=S9i*mu9p-S6i*mu6/2
    kk=(mu9p.T*S9i*mu9p)[0]-(mu6.T*S6i*mu6)[0]/2
    return -3*mp.log(2)+mp.log(mp.det(S6))/2-mp.log(mp.det(Sp))-mp.log(mp.det(M))/2+(c.T*(M**-1)*c)[0]-kk


def main():
    R,transcript=load_engine()
    result=[]
    for ys,us in [(('5','0'),('1','0')),(('4.8','1.6'),('0.6','0.8'))]:
        y=tuple(map(mp.mpf,ys))
        u=tuple(map(mp.mpf,us))
        A,m=structural_jets(R,y,u)
        L=logq_jets(A,m)
        X=chi2_jets(L)
        direct=lambda t:original_logq(R,(y[0]+t*u[0],y[1]+t*u[1]))
        refs=[mp.diff(direct,mp.mpf(0),k) for k in range(5)]
        errors=[abs(L[k]-refs[k])/max(1,abs(refs[k])) for k in range(5)]
        if max(errors)>mp.mpf('1e-60'):
            raise AssertionError('Source comparison failed: '+str(errors))
        result.append(dict(y=ys,direction=us,logq_jets=[mp.nstr(x,30) for x in L],
                           chi2_jets=[mp.nstr(x,30) for x in X],
                           scaled_errors=[mp.nstr(x,10) for x in errors],status='PASS'))
    report=dict(status='PASS',scope='two point paths, orders0..4; finite-image engine only',
                field_uniformity_certified=False,infinite_tail_certified=False,lemma_closed=False,
                source_engine_sha256=PIN,source_import_stdout_sha256=hashlib.sha256(transcript.encode()).hexdigest(),
                comparisons=result,checks=10,
                module_sha256=hashlib.sha256(Path(__file__).with_name('rnu_white.py').read_bytes()).hexdigest(),
                adapter_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    Path(__file__).with_name('SOURCE_POINT_REPORT.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    main()
