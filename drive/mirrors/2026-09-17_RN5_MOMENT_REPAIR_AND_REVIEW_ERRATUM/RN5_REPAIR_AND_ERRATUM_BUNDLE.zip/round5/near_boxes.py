"""RN5 conditional Gaussian Taylor boxes. Local certificates, not an annulus cover."""
from near_moments import *
from rn_field import add_radius, eye, frob, absolute_moments
from math import factorial

class TaylorBoxes(NearField):
    def __init__(self,order=6):
        super().__init__();self.order=order
        self.multi=[(i,j) for n in range(order+1) for i in range(n+1) for j in [n-i]]
        self.jets=[(i,j) for n in range(order+3) for i in range(n+1) for j in [n-i]]
        self.lookup={a:6+i for i,a in enumerate(self.jets)}
        self.zero=kernel_all(arb(0),2*(order+3))
        self.uncond=absolute_moments(2*(order+3))
        G6=sub(self.G,range(6),range(6));self.Gi=G6.inv()
        self.X=sub(self.G,range(6,12),range(6))
        self.pv=arb_mat([[HEIGHT],[0],[0],[HEIGHT-ELL],[0],[0]])
        self.mean_energy=(self.pv.transpose()*self.Gi*self.pv)[0,0].sqrt()

    def point_jets(self,x,y):
        xx=[kernel_all(x-p,self.order+4) for p,a in RAW]
        yy=kernel_all(y,self.order+4)
        raw=arb_mat([[(-1)**sum(a)*xx[i][a[0]+b[0]]*yy[a[1]+b[1]] for b in self.jets] for i,(p,a) in enumerate(RAW)])
        PC=sub(raw,range(6),range(len(self.jets)))
        PH=sub(raw,range(6,12),range(len(self.jets)))
        lc=arb_mat([[(-1)**sum(b)*self.zero[a[0]+b[0]]*self.zero[a[1]+b[1]] for b in self.jets] for a in self.jets])
        lc-=PC.transpose()*self.Gi*PC
        cross=PH-self.X*self.Gi*PC
        n=6+len(self.jets);C=arb_mat(n,n);m=arb_mat(n,1)
        lm=PC.transpose()*self.Gi*self.pv
        for i in range(n):
            m[i,0]=self.Hmean[i,0] if i<6 else lm[i-6,0]
            for j in range(n):
                C[i,j]=self.S0[i,j] if i<6 and j<6 else (cross[i,j-6] if i<6 else (cross[j,i-6] if j<6 else lc[i-6,j-6]))
        return C,m

    def box(self,x,y,h):
        x,y,h=map(arb,(x,y,h));need(h>0,'positive box halfwidth')
        C,m=self.point_jets(x,y)
        yi=[self.lookup[a] for a in JETS];hi=list(range(6))+[self.lookup[a] for a in HJETS]
        D=sub(C,yi,yi);HY=sub(C,hi,yi);HC=sub(C,hi,hi)
        Ty=chol(D).inv();A=HY*D.inv();CC=HC-A*HY.transpose()
        # Holder uses only three marginal Hessian moments. Separate whitening
        # avoids requiring independence or conditioning of their joint 9D law.
        LH=arb_mat(9,9)
        for off in (0,3,6):
            ll=chol(sub(CC,range(off,off+3),range(off,off+3)))
            for i in range(3):
                for j in range(3):LH[off+i,off+j]=ll[i,j]
        WH=LH.inv()
        # Each diagonal 3D block of Z has identity covariance at the center;
        # the three Hessian blocks may remain mutually correlated.
        T=arb_mat(12,12)
        for i in range(3):
            for j in range(3):T[i,j]=Ty[i,j]
        WA=-(WH*A)
        for i in range(9):
            for j in range(3):T[i+3,j]=WA[i,j]
            for j in range(9):T[i+3,j+3]=WH[i,j]
        polys={};means={}
        for a in self.multi:
            P=arb_mat(12,C.nrows());fac=factorial(a[0])*factorial(a[1])
            for i,b in enumerate(JETS):P[i,self.lookup[(a[0]+b[0],a[1]+b[1])]]=arb(1)/fac
            if a==(0,0):
                for i in range(6):P[i+3,i]=1
            for i,b in enumerate(HJETS):P[i+9,self.lookup[(a[0]+b[0],a[1]+b[1])]]=arb(1)/fac
            polys[a]=T*P;means[a]=polys[a]*m
        covs={}
        # Sum common monomials before interval substitution.
        for a,Pa in polys.items():
            PC=Pa*C
            for b,Pb in polys.items():
                c=(a[0]+b[0],a[1]+b[1])
                term=PC*Pb.transpose()
                if c in covs:covs[c]+=term
                else:covs[c]=term
        for off in (0,3,6,9):
            need((sub(covs[0,0],range(off,off+3),range(off,off+3))-eye(3)).contains(arb_mat(3,3)),'anchor marginal identity enclosure')
        need(sub(covs[0,0],range(3,12),range(3)).contains(arb_mat(9,3)),'anchor regression residual')
        cv=covs[0,0];mn=means[0,0]
        for i in range(12):
            mn[i,0]=add_radius(mn[i,0],sum((v[i,0].abs_upper()*h**sum(a) for a,v in means.items() if a!=(0,0)),arb(0)))
            for j in range(12):
                cv[i,j]=add_radius(cv[i,j],sum((v[i,j].abs_upper()*h**sum(a) for a,v in covs.items() if a!=(0,0)),arb(0)))
        # L2 Taylor remainder: conditional centered variance <= unconditional.
        rem=[]
        for b in JETS+HJETS:
            val=arb(0)
            for i in range(self.order+2):
                j=self.order+1-i
                sd=(self.uncond[2*(b[0]+i)]*self.uncond[2*(b[1]+j)]).sqrt()
                val+=h**(self.order+1)*sd/(factorial(i)*factorial(j))
            rem.append(val.upper())
        rawrem=rem[:3]+[arb(0)]*6+rem[3:]
        zrem=[sum((T[i,j].abs_upper()*rawrem[j] for j in range(12)),arb(0)).upper() for i in range(12)]
        psd=[cv[i,i].upper().sqrt() for i in range(12)]
        for i in range(12):
            mn[i,0]=add_radius(mn[i,0],self.mean_energy*zrem[i])
            for j in range(12):cv[i,j]=add_radius(cv[i,j],psd[i]*zrem[j]+psd[j]*zrem[i]+zrem[i]*zrem[j])
        G=sub(cv,range(3),range(3));B=sub(cv,range(3,12),range(3));V=sub(cv,range(3,12),range(3,12))
        lg=chol(G);Gi=G.inv();CS=V-B*Gi*B.transpose()
        h_pivots=[]
        for off in (0,3,6):
            ll=chol(sub(CS,range(off,off+3),range(off,off+3)))
            h_pivots.extend(ll[i,i].lower()**2 for i in range(3))
        my=sub(mn,range(3),(0,));mh=sub(mn,range(3,12),(0,))
        w0=arb_mat([[MID],[0],[0]]);w1=arb_mat([[1],[0],[0]])
        mm=LH*(mh+B*Gi*(Ty*w0-my))+A*w0
        slope=LH*B*Gi*Ty*w1+A*w1
        mu=[arb_poly([mm[i,0],slope[i,0]]) for i in range(9)]
        HC=LH*CS*LH.transpose()
        highs={}
        for name,off,k in [('M4',0,4),('S4',3,4),('Y2',6,2)]:
            p=det_moment(mu[off:off+3],sub(HC,range(off,off+3),range(off,off+3)),k)
            highs[name]=poly_upper(p,ELL/2);need(highs[name]>0,'positive moment cap')
        detcap=(highs['M4']*highs['S4']).sqrt().sqrt()*highs['Y2'].sqrt()
        # Height integral <= ell * supremum of full three-jet Gaussian density.
        ww=arb_mat([[MID+arb(0,(ELL/2).upper())],[0],[0]])
        dz=Ty*ww-my;q=(dz.transpose()*Gi*dz)[0,0]
        qlo=max(arb(0),q.lower())
        density=Ty.det().abs_upper()*(-qlo/2).exp()/((2*arb.pi())**arb('1.5')*G.det().sqrt())
        bound=(ELL*density*detcap/ZLO).upper()
        center=self.station(x,y)['corrected_spine'].upper()
        return dict(x=x.str(30),y=y.str(30),halfwidth=h.str(20),spine_upper_over_r3=(bound/R**3).str(30),
            bound_to_center=(bound/center).str(25),min_whitened_Y_pivot=min(lg[i,i].lower()**2 for i in range(3)).str(25),
            min_whitened_H_pivot=min(h_pivots).str(25),
            largest_L2_remainder=max(zrem).str(25),q_lower=qlo.str(25),status='PASS_LOCAL_BOX')

def main():
    f=TaylorBoxes();rows=[];start=time.monotonic()
    for deg,rad,h in [(0,'1','0.005'),(45,'1','0.005'),(90,'1','0.005'),(135,'1','0.005'),(180,'1','0.005'),
                      (45,'0.1','0.0001'),(90,'0.1','0.0001'),(0,'0.1','0.000001'),(45,'0.5','0.002'),(45,'3','0.01')]:
        t=arb(deg)*arb.pi()/180
        attempts=[];hh=arb(h)
        for refinement in range(9):
            try:
                row=f.box(arb(rad)*t.cos(),arb(rad)*t.sin(),hh)
                break
            except RuntimeError as e:
                attempts.append({'halfwidth':hh.str(20),'reason':str(e)})
                row={'status':'UNRESOLVED_BOX','reason':str(e),'radius':rad,'angle':deg,'halfwidth':hh.str(20)}
                hh/=10
        row['rejected_larger_boxes']=attempts
        row['requested_halfwidth_exact_decimal']=h
        row['halfwidth_divisor_power_of_ten']=len(attempts) if row['status']=='PASS_LOCAL_BOX' else len(attempts)-1
        row.update(radius=rad,angle_degrees=deg);rows.append(row);print(json.dumps(row),flush=True)
    result={'status':'LOCAL_BOX_CERTIFICATES_ONLY','spatial_cover':False,'precision_bits':ctx.prec,'taylor_order':f.order,
        'rows':rows,'elapsed_seconds':time.monotonic()-start,'source_contract':f.contract,
        'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'near_moments_sha256':hashlib.sha256((ROOT/'round5/near_moments.py').read_bytes()).hexdigest()}
    (ROOT/'round5/output/NEAR_TAYLOR_BOX_CERTIFICATE.json').write_text(json.dumps(result,indent=2)+'\n')

if __name__=='__main__':main()
