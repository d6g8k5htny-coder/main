"""RN5: exact point-law and whole-mark cap repair, not a spatial cover."""
from pathlib import Path
import sys, hashlib, json, math, time, re
from functools import lru_cache
from fractions import Fraction

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'closure_round2'))
from rn_field import arb,arb_mat,ctx,Field,need,chol,kernel_all,JETS,HJETS,R,HEIGHT,RAW
from flint import arb_poly

BASE=ROOT/'closure_round2/rn_field.py'
need(hashlib.sha256(BASE.read_bytes()).hexdigest()=='d9167ae821684f716fdbae11cd39eb13818422f50b6566f677d62c292e4a93c8','kernel identity')
SOURCE=ROOT/'intake/rn_source/K3_SIDE24_LB/UPPER2D/D3_percolation/d3_perc.py'
need(hashlib.sha256(SOURCE.read_bytes()).hexdigest()=='5bc092412943e1c2185a8cf86cee23ae9cd9a2aad9bd9ef0b02807e9ff58dfa4','affected source identity')
ZLO_EXACT=Fraction('0.0077592917375327855')
ZLO=arb(ZLO_EXACT.numerator)/ZLO_EXACT.denominator
ELL=R**3/6
MID=HEIGHT-ELL/2
LOCAL=JETS+HJETS

def sub(A,rr,cc):
    return arb_mat([[A[i,j] for j in cc] for i in rr])

def det_moment(mu,S,k):
    """Polynomial in t=v-MID; all coefficients are Arb enclosures."""
    @lru_cache(None)
    def moment(alpha):
        if sum(alpha)==0:return arb_poly([1])
        i=next(i for i,n in enumerate(alpha) if n)
        beta=list(alpha);beta[i]-=1
        value=mu[i]*moment(tuple(beta))
        for j in range(3):
            if beta[j]:
                gamma=beta[:];gamma[j]-=1
                value+=beta[j]*S[i,j]*moment(tuple(gamma))
        return value
    return sum(((-1)**j*math.comb(k,j)*moment((k-j,k-j,2*j)) for j in range(k+1)),arb_poly([0]))

def poly_upper(p,h):
    return (p[0].upper()+sum((p[j].abs_upper()*h**j for j in range(1,len(p))),arb(0))).upper()

class NearField(Field):
    def __init__(self):
        super().__init__()
        from rn_field import source_contract
        self.contract=source_contract()
        floor_text=(ROOT/'intake/rn_source/K3_SIDE24_LB/UPPER2D/H3_closure/H3_RUNG_FLOOR.md').read_text()
        floor_match=re.search(r'Z_\{0\.05\} ∈ \[\s*([\d.e+-]+)\s*,',floor_text)
        need(floor_match is not None and Fraction(floor_match.group(1))==ZLO_EXACT,'exact imported H3 floor')
        self.Lh=chol(self.S0)
        kk=kernel_all(arb(0),4)
        self.local_cov=arb_mat([[(-1)**sum(b)*kk[a[0]+b[0]]*kk[a[1]+b[1]] for b in LOCAL] for a in LOCAL])

    def mixed(self,x,y):
        xx=[kernel_all(arb(x)-p,4) for p,a in RAW]
        yy=kernel_all(arb(y),4)
        raw=arb_mat([[(-1)**sum(a)*xx[i][a[0]+b[0]]*yy[a[1]+b[1]] for b in LOCAL] for i,(p,a) in enumerate(RAW)])
        return self.forms*raw

    def station(self,x,y):
        mix=self.mixed(x,y)
        B=sub(mix,range(6),range(3));T=sub(mix,range(6),range(3,6))
        F=sub(mix,range(6,12),range(3));J=sub(mix,range(6,12),range(3,6))
        muy=sub(mix,[12],range(3)).transpose()
        muh=sub(mix,[12],range(3,6)).transpose()
        D=self.YY-B.transpose()*B
        Ld=chol(D);Di=D.inv()
        CY=sub(self.local_cov,range(3,6),range(3))-T.transpose()*B
        HC=arb_mat(9,9);HY=arb_mat(9,3);HM=arb_mat(9,1)
        cross=self.Lh*J
        bottom=sub(self.local_cov,range(3,6),range(3,6))-T.transpose()*T
        topY=self.Lh*F
        for i in range(9):
            HM[i,0]=self.Hmean[i,0] if i<6 else muh[i-6,0]
            for j in range(3):HY[i,j]=topY[i,j] if i<6 else CY[i-6,j]
        for i in range(6):
            for j in range(6):HC[i,j]=self.S0[i,j]
            for j in range(3):HC[i,j+6]=HC[j+6,i]=cross[i,j]
        for i in range(3):
            for j in range(3):HC[i+6,j+6]=bottom[i,j]
        A=HY*Di
        cov=HC-A*HY.transpose()
        L9=chol(cov)
        center=HM+A*(arb_mat([[MID],[0],[0]])-muy)
        mu=[arb_poly([center[i,0],A[i,0]]) for i in range(9)]
        moments={}
        for label,offset,orders in [('M',0,(4,)),('S',3,(4,)),('Y',6,(2,4))]:
            for k in orders:moments[label+str(k)]=det_moment(mu[offset:offset+3],sub(cov,range(offset,offset+3),range(offset,offset+3)),k)
        G=sub(D,(1,2),(1,2));Gi=G.inv();mg=sub(muy,(1,2),(0,));cg=sub(D,(0,),(1,2))
        chol(G)
        mt=muy[0,0]-(cg*Gi*mg)[0,0]
        st2=D[0,0]-(cg*Gi*cg.transpose())[0,0]
        need(st2>0,'positive height conditional variance')
        st=st2.sqrt()
        pgrad=(-(mg.transpose()*Gi*mg)[0,0]/2).exp()/(2*arb.pi()*G.det().sqrt())
        aa=(HEIGHT-ELL-mt)/(arb(2).sqrt()*st);bb=(HEIGHT-mt)/(arb(2).sqrt()*st)
        if aa>0:wm=(aa.erfc()-bb.erfc())/2
        elif bb<0:wm=((-bb).erfc()-(-aa).erfc())/2
        else:wm=(bb.erf()-aa.erf())/2
        need(wm.upper()>=0,'window mass enclosure')
        highs={k:poly_upper(p,ELL/2) for k,p in moments.items()}
        need(all(v>0 for v in highs.values()),'positive even moment caps')
        pair=(highs['M4']*highs['S4']).sqrt().sqrt()
        corrected=pair*highs['Y2'].sqrt()
        wrong=pair*highs['Y4'].sqrt()
        midpoint_ratio=(moments['Y2'][0]/moments['Y4'][0]).sqrt()
        return dict(x=arb(x),y=arb(y),moments=moments,highs=highs,cov=cov,mu=mu,D=D,
          density_mass=pgrad*wm,corrected_cap=corrected,wrong_cap=wrong,
          corrected_spine=pgrad*wm.upper()*corrected/ZLO,wrong_spine=pgrad*wm.upper()*wrong/ZLO,
          midpoint_second_over_fourth_sqrt=midpoint_ratio,
          min_D_pivot=min(Ld[i,i].lower()**2 for i in range(3)),
          min_H_pivot=min(L9[i,i].lower()**2 for i in range(9)))

def rational_counterexample():
    # Independent full-dimensional Gaussian symmetric Hessians, diagonal
    # means (-1,-1), (1,-1), (1,-1/4), each entry variance 10^-6.
    def exact(mu,k):
        var=Fraction(1,10**6)
        @lru_cache(None)
        def M(a):
            if sum(a)==0:return Fraction(1)
            i=next(i for i,x in enumerate(a) if x)
            b=list(a);b[i]-=1
            v=mu[i]*M(tuple(b))
            if b[i]:
                cc=b[:];cc[i]-=1
                v+=b[i]*var*M(tuple(cc))
            return v
        return sum(((-1)**j*math.comb(k,j)*M((k-j,k-j,2*j)) for j in range(k+1)),Fraction(0))
    dm4=exact((-1,-1,0),4);ds4=exact((1,-1,0),4);dy4=exact((1,Fraction(-1,4),0),4)
    # All nine entry deviations <=1/100: union-Chebyshev probability >=91/100.
    # On that event types are M=max,S=saddle,Y=saddle and determinants have
    # magnitudes >=98/100,9801/10000,2376/10000.
    lower=Fraction(91,100)*Fraction(98,100)*Fraction(9801,10000)*Fraction(2376,10000)
    wrong4=dm4*ds4*dy4**2
    need(lower**4>wrong4,'typed positive-definite Gaussian counterexample')
    need(wrong4<Fraction(63,1000)**4 and lower>Fraction(207,1000),'rational counterexample separation')
    return dict(typed_expectation_lower=str(lower),typed_expectation_lower_decimal=float(lower),
      wrong_envelope_fourth_power=str(wrong4),wrong_envelope_approx_decimal=float(wrong4)**.25,
      wrong_envelope_strict_rational_upper='63/1000',
      fourth_power_margin=str(lower**4-wrong4),variance='1/1000000',event_probability_lower='91/100',status='PASS')

def run_grid():
    f=NearField();rows=[]
    radii=['0.1','0.15','0.2','0.3','0.4','0.5','0.75','1','1.5','2','3','4','5']
    angles=[0,45,90,135,180]
    start=time.monotonic()
    for deg in angles:
        th=arb(deg)*arb.pi()/180
        for rad in radii:
            rr=arb(rad);x=rr*th.cos();y=rr*th.sin();d=f.station(x,y)
            row={'radius':rad,'angle_degrees':deg,'corrected_spine_over_r3':(d['corrected_spine']/R**3).str(30),
              'old_moment_power_spine_over_r3':(d['wrong_spine']/R**3).str(30),
              'Y2_at_mid':d['moments']['Y2'][0].str(30),'Y4_at_mid':d['moments']['Y4'][0].str(30),
              'sqrt_Y2_over_Y4_at_mid':d['midpoint_second_over_fourth_sqrt'].str(30),
              'min_D_cholesky_pivot':d['min_D_pivot'].str(30),'min_H_cholesky_pivot':d['min_H_pivot'].str(30)}
            rows.append(row)
            print(json.dumps({'station':len(rows),**row}),flush=True)
    result={'status':'PASS_SCOPED_POINT_LAWS_AND_WHOLE_MARK_CAPS','spatial_cover':False,
      'scope':'65 exact SIDE24 nine-pin laws; r=1/20,b=6/5; complete mark interval at each station',
      'precision_bits':ctx.prec,'counterexample':rational_counterexample(),'source_contract':f.contract,
      'corrected_inequality':'(E dM^4 E dS^4)^(1/4) * (E dy^2)^(1/2)',
      'source_bad_inequality':'(E dM^4 E dS^4)^(1/4) * (E dy^4)^(1/2)',
      'rows':rows,'elapsed_seconds':time.monotonic()-start,'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (ROOT/'round5/output/NEAR_MOMENT_REPAIR_CERTIFICATE.json').write_text(json.dumps(result,indent=2)+'\n')
    print('COMPLETE',len(rows),time.monotonic()-start)
    return result

if __name__=='__main__':run_grid()
