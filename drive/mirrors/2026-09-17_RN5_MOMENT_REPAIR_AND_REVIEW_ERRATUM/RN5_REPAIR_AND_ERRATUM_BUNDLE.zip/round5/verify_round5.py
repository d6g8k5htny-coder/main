"""Scientific consistency checks. Sampling validates implementation, not coverage."""
from near_moments import *
import re

checks=[]
def check(ok,label):
    need(ok,label);checks.append(label)

def identity_and_erratum():
    raw=(ROOT/'round5/intake/lm004.txt').read_bytes()
    text=raw.decode('utf-8-sig').replace('\r\n','\n').replace('\r','\n')
    aa=list(re.finditer(r'^BEGIN_FROZEN_LEMMA_BODY\s*$',text,re.M))
    bb=list(re.finditer(r'^END_FROZEN_LEMMA_BODY\s*$',text,re.M))
    check(len(aa)==len(bb)==1,'unique frozen-body markers')
    body=text[aa[0].end():bb[0].start()].strip('\n')+'\n'
    data=body.encode()
    check(len(data)==10416 and hashlib.sha256(data).hexdigest()=='d43179f3abfd7e93f988725f3b89a5826cc71e0fa04840f65c7f93f3359d0f87','LM004 exact body identity')
    section=body.split('2. C1 NORM AND EXACT FIELD',1)[1].split('3. THEOREM',1)[0]
    check(section.count('sup_{x in D} ||DE(x)||_op')==1,'one derivative supremum in actual norm section')
    check(section.count('sup_{x in D} ||E(x)||_2')==1,'one field supremum in actual norm section')
    eta=Fraction(1,8192);k=Fraction(1,16)
    check(eta**2*(1+k*k)<Fraction(1,8000)**2,'axis loss exact squared comparison')
    check(eta**2*(1+k)**2*(1+k*k)<Fraction(1,7000)**2,'face loss exact squared comparison')
    check(Fraction(63,128)-Fraction(3,64)-eta>Fraction(44,100),'sink contraction rational margin')
    check(-3+Fraction(1,4)==Fraction(-11,4),'central drift rational coefficient')
    old=(ROOT/'round5/intake/oldreview.txt').read_bytes()
    check(hashlib.sha256(old).hexdigest()=='c0571b7affc23c0d44e3479cb7ebafafbcfd49001a43097d43f00553f1d75f81','superseded report exact identity')
    return {'body_sha256':hashlib.sha256(data).hexdigest(),'body_bytes':len(data),
            'export_sha256':hashlib.sha256(raw).hexdigest(),'export_bytes':len(raw),'derivative_terms_in_norm':1}

def direct_nine_pin(f,x,y):
    coords=RAW+[((x,y),a) for a in LOCAL]
    # Independent assembly from all 18 raw derivative coordinates.
    def point(p):return p if isinstance(p,tuple) else (p,arb(0))
    cov=arb_mat(18,18)
    for i,(p,a) in enumerate(coords):
        px,py=point(p)
        for j,(q,b) in enumerate(coords):
            qx,qy=point(q)
            cov[i,j]=(-1)**sum(b)*kernel_all(px-qx,a[0]+b[0])[a[0]+b[0]]*kernel_all(py-qy,a[1]+b[1])[a[1]+b[1]]
    ci=list(range(6))+list(range(12,15));hi=list(range(6,12))+list(range(15,18))
    G=sub(cov,ci,ci);X=sub(cov,hi,ci);HH=sub(cov,hi,hi);chol(G)
    pc=arb_mat([[HEIGHT],[0],[0],[HEIGHT-ELL],[0],[0],[MID],[0],[0]])
    mm=X*G.inv()*pc;ss=HH-X*G.inv()*X.transpose()
    st=f.station(x,y)
    check(all(ss[i,j].overlaps(st['cov'][i,j]) for i in range(9) for j in range(9)),'direct-nine-pin covariance agrees '+x.str(8)+','+y.str(8))
    check(all(mm[i,0].overlaps(st['mu'][i][0]) for i in range(9)),'direct-nine-pin mean agrees '+x.str(8)+','+y.str(8))

def main():
    ident=identity_and_erratum();cx=rational_counterexample()
    check(cx['status']=='PASS','exact typed Gaussian counterexample')
    f=NearField()
    for deg,rad in [(45,'0.1'),(45,'1'),(180,'5')]:
        th=arb(deg)*arb.pi()/180;direct_nine_pin(f,arb(rad)*th.cos(),arb(rad)*th.sin())
    cert=json.loads((ROOT/'round5/output/NEAR_TAYLOR_BOX_CERTIFICATE.json').read_text())
    n=0
    for row in cert['rows']:
        check(row['status']=='PASS_LOCAL_BOX','local box pass '+str(row['angle_degrees'])+'/'+row['radius'])
        th=arb(row['angle_degrees'])*arb.pi()/180;d=arb(row['radius'])
        h=arb(row['requested_halfwidth_exact_decimal'])/10**row['halfwidth_divisor_power_of_ten']
        bound=arb(row['spine_upper_over_r3'])
        for sx,sy in [(-1,-1),(-1,1),(1,-1),(1,1)]:
            p=f.station(d*th.cos()+sx*h,d*th.sin()+sy*h)['corrected_spine']/R**3
            check(p.upper()<bound.lower(),'corner consistency '+str(n));n+=1
    points=json.loads((ROOT/'round5/output/NEAR_MOMENT_REPAIR_CERTIFICATE.json').read_text())['rows']
    rs=[arb(x) for x in ['0.1','0.15','0.2','0.3','0.4','0.5','0.75','1','1.5','2','3','4','5']]
    diagnostic={}
    for key in ['corrected_spine_over_r3','old_moment_power_spine_over_r3']:
        cols=[]
        for j,d in enumerate(rs):
            vals=[arb(points[13*i+j][key]) for i in range(5)]
            cols.append(sum(((vals[i]+vals[i+1])*arb.pi()/8 for i in range(4)),arb(0))*2*d)
        diagnostic[key]=sum(((cols[j]+cols[j+1])*(rs[j+1]-rs[j])/2 for j in range(12)),arb(0)).str(25)
    out={'status':'PASS','checks':len(checks),'labels':checks,'LM004_identity':ident,
         'exact_counterexample':cx,'corner_checks':n,'direct_raw_laws_checked':3,
         'D4_net_trapezoid_DIAGNOSTIC_NOT_AN_INTEGRAL_BOUND':diagnostic,
         'scope':'Consistency checks; no coverage inferred from samples; no external independence',
         'python_optimization':sys.flags.optimize,'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (ROOT/'round5/output/VERIFICATION.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()
