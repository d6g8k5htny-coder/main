"""Gaussian sqrt-chi-square modulus; theorem-backed scalar ball bounds.

The scalar bound is rigorous conditional on its supplied uniform bounds.
The numpy matrix evaluator is diagnostic floating point, NOT a certificate.
No function certifies RN-UNIF or a field domain by itself.
"""
from flint import arb


def uniform_speed_bound(n, a, mean_norm, covariance_derivative_frobenius,
                        mean_derivative_norm):
    """Enclose an L2 likelihood-ratio speed bound.

    Uniform hypotheses on a path: ||I-S||_2 <= a < 1, ||m|| <= mean_norm,
    ||S'||_F <= covariance_derivative_frobenius, ||m'|| <= mean_derivative_norm.
    Use exact integers or decimal/rational strings, or certified arb inputs.
    The returned ball encloses the upper-bound expression; its upper endpoint
    is an upper bound for the speed, NOT every element of the returned ball.
    """
    if not isinstance(n, int) or isinstance(n, bool) or n < 1:
        raise ValueError('n must be a positive integer')
    vals = [arb(x) for x in (a, mean_norm, covariance_derivative_frobenius,
                             mean_derivative_norm)]
    if any(not x.is_finite() or not x >= 0 for x in vals):
        raise ValueError('all bounds must be certainly finite and nonnegative')
    a, M, D, V = vals
    if not a < 1:
        raise ValueError('a must be certainly below 1')
    h = 1 - a
    delta = 1 - a*a
    logQ = -arb(n)/2 * delta.log() + M*M/h
    score_mean = arb(n).sqrt()*a*D/(2*delta) + D*M*M/(2*h*h) + V*M/h
    score_variance = D*D/(2*delta*delta) + (D*M/h + V)**2/delta
    return (logQ/2).exp() * (score_mean**2 + score_variance).sqrt()


def gaussian_l2_speed_squared(S, m, Sdot, mdot):
    """Diagnostic exact-formula evaluation in numpy double precision."""
    import numpy as np
    S = np.asarray(S, dtype=float)
    D = np.asarray(Sdot, dtype=float)
    m = np.asarray(m, dtype=float)
    v = np.asarray(mdot, dtype=float)
    n = len(m)
    if S.shape != (n,n) or D.shape != (n,n) or v.shape != (n,):
        raise ValueError('incompatible dimensions')
    if not all(np.all(np.isfinite(x)) for x in (S,D,m,v)):
        raise ValueError('nonfinite input')
    if not np.allclose(S,S.T,atol=1e-13,rtol=1e-13) or not np.allclose(D,D.T,atol=1e-13,rtol=1e-13):
        raise ValueError('symmetric covariance and derivative required')
    ev = np.linalg.eigvalsh(S)
    if ev[0] <= 0 or ev[-1] >= 2:
        raise ValueError('finite chi-square requires 0 < S < 2I')
    I = np.eye(n)
    K = np.linalg.inv(S)
    H = np.linalg.inv(2*I-S)
    A = I-S
    T = np.linalg.inv(I-A@A)
    logQ = -0.5*np.linalg.slogdet(I-A@A)[1] + m@H@m
    score_mean = -0.5*np.trace(D@T@A) + 0.5*m@H@D@H@m + v@H@m
    u = D@H@m + v
    score_variance = 0.5*np.trace(D@T@D@T) + u@T@u
    return float(np.exp(logQ)*(score_mean**2+score_variance))
