from pathlib import Path
import json,hashlib,shutil,zipfile,sys,importlib.metadata

ROOT=Path(__file__).resolve().parents[1];HERE=ROOT/'round5';REL=HERE/'release';PAY=REL/'payload'
REL.mkdir(exist_ok=True);PAY.mkdir(exist_ok=True)
def ident(p):
    b=Path(p).read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
archive='1vSI-evINWskhXVyiZ0slt-rLT74sPpXH'
base='intake/rn_source/K3_SIDE24_LB/UPPER2D/D3_percolation/'
spec=[
 ('Q-RN5-MOMENT-001',archive,base+'d3_perc.py','envelope_v; window_cap_env and consumers relying on the claimed polarity-safe upper bound. Other functions are outside this finding.'),
 ('Q-RN5-MOMENT-002',archive,base+'d3_amend_v2.py','v3_annulus_numerator and assembled near/remote numerical upper-bound claims that consume E.window_cap_env. H3 denominator repair and unaffected far components retained.'),
 ('Q-RN5-MOMENT-003',archive,base+'D3_REMOTE_AMENDMENT_v2.md','I_ann=17.6804 r^3 and B_remote=21.9279 r^3 as upper-bound certification claims, plus conclusions depending on those values. Historical evidence is retained.'),
 ('Q-RN5-MOMENT-004','1aCa-QG9CSrNUB9SUFKISifghSf-41fRy','round5/intake/cl.txt','Section 3 claim that the near integrand with sqrt(E dy^4) is certified, and the derived near/remote forecasts. Far progress and declared partial coverage are retained.'),
 ('Q-RN5-LM004-A1','1CHErajW7G2y8y7Mr0bKYMy2lJbA2HIAt','round5/intake/oldreview.txt','A1 statement that the C1 derivative supremum is duplicated, and the proposed cleanup. Prior technical reconciliation is retained with the erratum.')]
holds=[]
for key,drive,path,scope in spec:
    p=ROOT/path
    row={'key':key,'class':'DEFECTIVE_SCOPE','drive_id':drive,'local_evidence':path,
      'archive_member':path.removeprefix('intake/rn_source/') if drive==archive else None,
      'affected_scope':scope,**ident(p),'action':'LOGICAL_QUARANTINE; original content bytes retained',
      'restoration_test':'Replaced moment inequality; exact successor identities; complete corrected spatial cover and budget replay; scoped technical review before certification.',
      'original_parent':'Archive member; carrier retained' if drive==archive else ('1FmKnSQRpHc6EYCUEIl07FQDECUZsiEqG' if key=='Q-RN5-MOMENT-004' else '1wPVf5p6Tz_4jy4NgRzrKJgUjEqM7MD3f'),
      'destination':'LOGICAL_QUARANTINE; carrier stays in place'}
    if key=='Q-RN5-LM004-A1':
        row.update(action='Move old report, rename as superseded; bytes retained',destination='1cKcmxCj9jcFFCUBgUqpifDiOfJJyh17f',
          original_name='AUTO-RV-LM004-20260917165201_TECHNICAL_RECONCILIATION.md',
          new_name='SUPERSEDED_A1_ERRATUM_AUTO-RV-LM004-20260917165201.md',
          restoration_test='Metadata move is reversible using original parent/name; historical report must always be read with LM004_REVIEW_ERRATUM_v1.1. False A1 finding is not restored as authority.')
    holds.append(row)
(HERE/'SCOPED_HOLDS.json').write_text(json.dumps({'version':'RN5-v1.0','date':'2026-09-17','archive_sha256':'a2136bc033f349382f9896896347da7a6dabde3334103276ad04db9205aa2b5b','holds':holds},indent=2)+'\n')
req='python-flint=='+importlib.metadata.version('python-flint')+'\n'
(HERE/'requirements.txt').write_text(req)
(HERE/'README.md').write_text('''# RN5 portable repair and review evidence

Start with round5/RN5_NEAR_MOMENT_REPAIR.md and round5/LM004_REVIEW_ERRATUM_v1.1.md.
SCOPED_HOLDS.json describes five scoped exclusions and the old report's reversible move.
These are author-side candidates, with zero organizational-independence credit.
Full near-annulus coverage, all-small-r extension, and independent acceptance remain open.

## Replay

Use Python 3.12 and the python-flint version pinned in round5/requirements.txt.
From this archive's root:

    python3 -O round5/near_moments.py
    python3 -O round5/near_boxes.py
    python3 -O round5/verify_round5.py

Expected: 65 point-law / whole-mark certificates, 10 accepted local boxes, 66 verification checks.
The original result files are in round5/output. Replay rewrites these local generated files;
elapsed time and run metadata may change. The archive itself remains the immutable baseline.
Source files are hash-pinned and copied at the paths expected by the verifier.
The complete payload inventory is DELIVERY_MANIFEST.json; it deliberately excludes itself.

## Review packet

R1. Reconstruct Holder (4,4,2) and the exact typed Gaussian counterexample.
R2. Reproduce source hashes, normalization, jet orders, six pins, marks, and H3 input scope.
R3. Audit image and spectral tail bounds in the imported rn_field.py dependency.
R4. Reconstruct conditional covariance, polynomial Wick moments, and the whole-mark cap.
R5. Verify the conditional L2 Taylor remainder and covariance remainder inequalities.
R6. Verify separate marginal whitening; no independence of Hessian blocks is assumed.
R7. Re-run positive-definiteness checks, all local boxes and the independent raw-law checks.
R8. Preserve the local-box limitation; require an actual complete cover before an integral bound.
R9. Reproduce LM004 frozen-body extraction and withdraw only the false duplicate-term claim.
R10. Disclose actual provider, authorship/coauthorship and exposure; do not claim blind review.

Current next task: construct a complete corrected near-region cover; optimize near-axis cells;
reassemble the remote budget only after all pending cells have valid bounds. Locate the exact
CL v5 archive/code before attempting executable crosswalk or accepting later CL coverage.
''')
files=['round5/RN5_NEAR_MOMENT_REPAIR.md','round5/LM004_REVIEW_ERRATUM_v1.1.md','round5/SCOPED_HOLDS.json',
 'round5/requirements.txt','round5/near_moments.py','round5/near_boxes.py','round5/verify_round5.py',
 'closure_round2/rn_field.py','output/rn_modulus/sqrt_chi2_modulus.py',
 'intake/rn_source/K3_SIDE24_LB/UPPER2D/H2_foundations/cov_exact.py',
 'intake/rn_source/K3_SIDE24_LB/UPPER2D/H3_closure/H3_RUNG_FLOOR.md',base+'d3_rn_unif.py',
 'round5/intake/lm004.txt','round5/intake/oldreview.txt','round5/intake/rn.txt','round5/intake/cl.txt']
files+= [base+x for x in ['d3_perc.py','d3_amend_v2.py','D3_REMOTE_AMENDMENT_v2.md']]
files+= [str(p.relative_to(ROOT)) for p in sorted((HERE/'output').iterdir()) if p.is_file()]
old_readme=PAY/'round5/README.md'
if old_readme.exists():old_readme.unlink()
for path in files:
    dst=PAY/path;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/path,dst)
shutil.copyfile(HERE/'README.md',PAY/'README.md');files.append('README.md')
payload=[{'path':p,**ident(PAY/p)} for p in sorted(files)]
manifest={'version':'RN5-v1.0','session':'ROUND5-20260917-b9c2','provider':'OpenAI','date':'2026-09-17',
 'claims':['CLAIM-ROUND5-RN5-ALIGN-NEAR','CLAIM-ROUND5-LM004-REVIEW-ERRATUM'],
 'scope':'Corrected moment inequality, 65 point laws and complete mark caps, ten local spatial boxes, source-bound review erratum. No full near-region integral certificate.',
 'organizational_independence_credit':0,'python':sys.version,'requirements':req.strip(),
 'payload_count':len(payload),'payloads':payload,'self_hash_rule':'Manifest excludes itself; detached custody binds manifest and ZIP bytes.'}
(REL/'DELIVERY_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
shutil.copyfile(REL/'DELIVERY_MANIFEST.json',PAY/'DELIVERY_MANIFEST.json')
zip_path=REL/'RN5_REPAIR_AND_ERRATUM_BUNDLE.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(PAY.rglob('*')):
        if not p.is_file():continue
        zi=zipfile.ZipInfo(str(p.relative_to(PAY)),(2026,9,17,17,0,0));zi.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(zi,p.read_bytes())
release=[HERE/'RN5_NEAR_MOMENT_REPAIR.md',HERE/'LM004_REVIEW_ERRATUM_v1.1.md',HERE/'SCOPED_HOLDS.json',REL/'DELIVERY_MANIFEST.json',zip_path]
(REL/'UPLOAD_PLAN.json').write_text(json.dumps([{'path':str(p),'name':p.name,**ident(p)} for p in release],indent=2)+'\n')
print(json.dumps({'payloads':len(payload),'release':[{ 'name':p.name,**ident(p)} for p in release]},indent=2))
