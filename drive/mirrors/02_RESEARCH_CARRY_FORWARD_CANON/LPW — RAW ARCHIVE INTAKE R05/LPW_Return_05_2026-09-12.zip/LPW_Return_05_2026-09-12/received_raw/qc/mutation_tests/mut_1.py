#!/usr/bin/env python3
"""QC-RETURN03 independent numeric verification (verification-only reviewer program).

Independent reproduction of the computable components of the author-side
quantitative candidate 03_EXPLICIT_CONSTANTS_CANDIDATE.md (r_* = 10^-28,
c_* = 10^-1235), on the exact periodized side-24 Bargmann-Fock field:
  spectral lattice (pi/12) Z^2, masses exp(-|k|^2/2), |k| <= 30 truncation
  with a certified tail bound, Z-normalized, mpmath at 100 dps (>= 60 dps
  required).  Written from the public derivation documents only; does NOT
  import or reuse the author's companion checker.

Conventions (from the reviewed candidate and endpoint supplement):
  K_24(z) = k(z1) k(z2),  k(t) = sum_n p_n cos(alpha n t),  p_n = w_n/Z,
  w_n = exp(-(alpha n)^2/2), alpha = pi/12.
  E[d^B f(z) d^G f(w)] = (-1)^|G| k^(B1+G1)(z1-w1) k^(B2+G2)(z2-w2).
  M_r = (-r/2, 0), S_r = (r/2, 0),
  P6_r = (f(M), f_x(M), f_y(M), f(S), f_x(S), f_y(S)),
  U_r = T_r P6_r with the displayed T_r,
  J = (f_yy, f_xxy/2, f_xyy/2, f_yyy/6)(0), V_r = (U_r, J),
  u_r = (b - r^3/12, -r^2/4, 0, 0, 0, 1/3), b = 6/5.

Fail-closed: every acceptance gate is ck() -> SystemExit.  No bare asserts.
Output: deterministic JSON on stdout (byte-identical under python and
python -O).
"""
from __future__ import annotations
import json
import sys
from fractions import Fraction as Q
import mpmath as mp

DPS = 100
mp.mp.dps = DPS

CHECKS = []
def ck(name, ok):
    if not bool(ok):
        raise SystemExit('FAIL:' + name)
    CHECKS.append({'check': name, 'status': 'PASS'})

def S(x):
    return mp.nstr(mp.mpf(x), 25)

# ---------------------------------------------------------------------------
# Spectral lattice with certified tail
# ---------------------------------------------------------------------------
alpha = mp.pi / 12
KCUT = mp.mpf(30)                      # |k| = alpha |n| <= 30
N0 = int(mp.floor(KCUT / alpha))       # largest n with alpha n <= 30
ck('cut_consistency', alpha * N0 <= KCUT < alpha * (N0 + 1) and N0 == 114)

w = {n: mp.exp(-(alpha * n) ** 2 / 2) for n in range(-N0, N0 + 1)}
Ztr = sum(w.values())

# Certified tail bound for sum_{|n| >= N0+1} w_n (alpha n)^m, any m <= 8.
# For n >= N0+1, alpha n > 30 > 1, so (alpha n)^m <= (alpha n)^8 (m <= 8),
# and the terms decay geometrically with ratio <= rho.
n1 = N0 + 1
F1 = mp.exp(-(alpha * n1) ** 2 / 2) * (alpha * n1) ** 8
rho = mp.exp(-alpha ** 2 * (2 * n1 + 1) / 2) * (mp.mpf(n1 + 1) / n1) ** 8
rho = rho * (1 + mp.mpf('1e-90'))     # widen against mpmath rounding
ck('tail_ratio_below_half', rho < mp.mpf('0.5'))
TAIL = 2 * F1 / (1 - rho) * (1 + mp.mpf('1e-80'))
ck('tail_certified_below_1e_120', TAIL < mp.mpf('1e-120'))
ck('tail_certified_below_1e_60', TAIL < mp.mpf('1e-60'))
# Every truncated quantity below carries certified error <= TAIL/Ztr + Z-tail
# effects < 1e-100; all acceptance margins in this program exceed 1e-3.
CERT_ERR = mp.mpf('1e-100')

_kcache = {}
def k1(m, t):
    """m-th derivative of the 1D covariance factor k at t (truncated, certified)."""
    key = (m, mp.mpf(t))
    v = _kcache.get(key)
    if v is not None:
        return v
    mm, tt = key
    tot = mp.mpf(0)
    if mm % 2 == 0:
        sgn = (-1) ** (mm // 2)
        for n in range(-N0, N0 + 1):
            x = alpha * n
            tot += w[n] * (x ** mm) * mp.cos(x * tt)
        v = sgn * tot / Ztr
    else:
        sgn = (-1) ** ((mm + 1) // 2)
        for n in range(-N0, N0 + 1):
            x = alpha * n
            tot += w[n] * (x ** mm) * mp.sin(x * tt)
        v = sgn * tot / Ztr
    _kcache[key] = v
    return v

def cov_eval(beta, gamma, dz):
    """E[d^beta f(z) d^gamma f(w)] with z - w = dz."""
    sgn = (-1) ** (sum(gamma))
    return sgn * k1(beta[0] + gamma[0], dz[0]) * k1(beta[1] + gamma[1], dz[1])

def linstat_variance(terms):
    """Variance of sum c_i d^{beta_i} f(z_i); terms = (c, (z1,z2), (b1,b2))."""
    tot = mp.mpf(0)
    for (ca, za, ba) in terms:
        for (cb, zb, bb) in terms:
            tot += ca * cb * cov_eval(ba, bb, (za[0] - zb[0], za[1] - zb[1]))
    ck('linstat_variance_nonnegative', tot > -CERT_ERR)
    return max(tot, mp.mpf(0))

# Exact rational scalars
BB = Q(6, 5)
DELTA = Q(1, 1024)
def M(x):
    return mp.mpf(x.numerator) / x.denominator

RUNGS = [Q(1, 4), Q(1, 10), Q(1, 20), Q(1, 40), Q(1, 100)]

# Displayed T_r rows (columns follow P6_r), as exact rationals in r.
def T_rows(r):
    return [
        [Q(1, 2), r / 8, Q(0), Q(1, 2), -r / 8, Q(0)],
        [-Q(3, 2) / r, -Q(1, 4), Q(0), Q(3, 2) / r, -Q(1, 4), Q(0)],
        [Q(0), Q(0), Q(1, 2), Q(0), Q(0), Q(1, 2)],
        [Q(0), -Q(1, 2) / r, Q(0), Q(0), Q(1, 2) / r, Q(0)],
        [Q(0), Q(0), -1 / r, Q(0), Q(0), 1 / r],
        [2 / r ** 3, 1 / r ** 2, Q(0), -2 / r ** 3, 1 / r ** 2, Q(0)],
    ]

U0_JETS = [((0, 0), (0, 0)), ((0, 0), (1, 0)), ((0, 0), (0, 1)),
           ((0, 0), (2, 0)), ((0, 0), (1, 1)), ((0, 0), (3, 0))]
U0_SCALE = [Q(1), Q(1), Q(1), Q(1, 2), Q(1), Q(1, 6)]
J_JETS = [((0, 0), (0, 2)), ((0, 0), (2, 1)), ((0, 0), (1, 2)), ((0, 0), (0, 3))]
J_SCALE = [Q(1), Q(1, 2), Q(1, 2), Q(1, 6)]

def P6_jets(r):
    rm = M(r)
    Mpt = (-rm / 2, mp.mpf(0))
    Spt = (rm / 2, mp.mpf(0))
    return [(Mpt, (0, 0)), (Mpt, (1, 0)), (Mpt, (0, 1)),
            (Spt, (0, 0)), (Spt, (1, 0)), (Spt, (0, 1))]

def u_vec(r):
    return [M(BB - r ** 3 / 12), M(-r ** 2 / 4), mp.mpf(0), mp.mpf(0),
            mp.mpf(0), M(Q(1, 3))]

def U_row_terms(r, i):
    """Linear-statistic terms of (U_r)_i as (coef, point, jet)."""
    rows = T_rows(r)
    jets = P6_jets(r)
    return [(M(rows[i][j]), jets[j][0], jets[j][1]) for j in range(6)
            if rows[i][j] != 0]

def J_terms(j):
    pt, jet = J_JETS[j]
    return [(M(J_SCALE[j]), pt, jet)]

def cov_block(stats_a, stats_b):
    """Covariance matrix between two lists of linear statistics."""
    out = []
    for ta in stats_a:
        row = []
        for tb in stats_b:
            tot = mp.mpf(0)
            for (ca, za, ba) in ta:
                for (cb, zb, bb) in tb:
                    tot += ca * cb * cov_eval(ba, bb,
                                              (za[0] - zb[0], za[1] - zb[1]))
            row.append(tot)
        out.append(row)
    return out

def V_stats(r):
    return [U_row_terms(r, i) for i in range(6)] + [J_terms(j) for j in range(4)]

# ---------------------------------------------------------------------------
# Matrix helpers (symmetric spectra with certification)
# ---------------------------------------------------------------------------
def eigs(Mmat, name):
    """Eigenvalues of a symmetric matrix, with residual/orthonormality checks.
    Returns (sorted eigenvalue list, certified radius tol): every true
    eigenvalue lies within tol of some returned value."""
    n = len(Mmat)
    A = mp.matrix(Mmat)
    E, V = mp.eigsy(A)
    maxres = mp.mpf(0)
    for i in range(n):
        vi = mp.matrix([V[j, i] for j in range(n)])
        ri = A * vi - E[i] * vi
        res = mp.sqrt(sum(x * x for x in ri))
        maxres = max(maxres, res)
    dev = mp.mpf(0)
    for i in range(n):
        for j in range(n):
            d = sum(V[k, i] * V[k, j] for k in range(n)) - (1 if i == j else 0)
            dev = max(dev, abs(d))
    ck(name + '_eigvec_residuals', maxres < mp.mpf('1e-80'))
    ck(name + '_eigvec_orthonormal', dev < mp.mpf('1e-80'))
    trA = sum(Mmat[i][i] for i in range(n))
    trE = sum(E[i] for i in range(n))
    ck(name + '_trace_consistency', abs(trA - trE) < mp.mpf('1e-70'))
    tol = maxres + dev * max(abs(E[0]), abs(E[n - 1])) + CERT_ERR + mp.mpf('1e-85')
    return sorted(mp.mpf(E[i]) for i in range(n)), tol

def minors_positive(Mmat, name):
    """All leading principal minors positive (Sylvester PD certificate)."""
    n = len(Mmat)
    vals = []
    for k in range(1, n + 1):
        sub = mp.matrix([[Mmat[i][j] for j in range(k)] for i in range(k)])
        d = mp.det(sub)
        vals.append(d)
        ck(name + '_minor_' + str(k), d > mp.mpf('1e-12'))
    return vals

def shift(Mmat, s):
    n = len(Mmat)
    return [[Mmat[i][j] - (s if i == j else mp.mpf(0)) for j in range(n)]
            for i in range(n)]

def symmetrize(Mmat):
    n = len(Mmat)
    return [[(Mmat[i][j] + Mmat[j][i]) / 2 for j in range(n)] for i in range(n)]

# ---------------------------------------------------------------------------
# Item 3 (section 1): endpoint moments a2, a4, a6, a8
# ---------------------------------------------------------------------------
out = {'status': 'PASS_NUMERIC_EVIDENCE_WITHIN_SCOPE',
       'program': 'independent reviewer reproduction (no author code reused)',
       'dps': DPS, 'lattice': '(pi/12) Z^2, weights exp(-|k|^2/2), |k|<=30',
       'tail_certificate': {'cut_index_N0': N0,
                            'first_omitted_shell': n1,
                            'geometric_ratio_bound': S(rho),
                            'tail_bound_all_orders_le_8': S(TAIL)},
       'items': {}}

# The planar deviations a_{2j} - (2j-1)!! are O(1e-117..1e-123), so the moment
# block runs at 220 dps (requirement is >= 60 dps; the rest runs at 100 dps).
a = {0: mp.mpf(1)}
with mp.workdps(220):
    al = mp.pi / 12
    aw = {n: mp.exp(-(al * n) ** 2 / 2) for n in range(-N0, N0 + 1)}
    Zw = sum(aw.values())
    for j in range(1, 5):
        tot = sum(aw[n] * (al * n) ** (2 * j) for n in range(-N0, N0 + 1))
        a[2 * j] = +(tot / Zw)
# cross-check against the generic 100-dps code path
for j in range(1, 5):
    ck('moment_codepath_consistency_%d' % (2 * j),
       abs(a[2 * j] - ((-1) ** j) * k1(2 * j, mp.mpf(0))) < mp.mpf('1e-80'))
# independent reproduction of the author's MC-RETURN03 diagnostic decimals
author_diag = {2: '-9.65254179895991305500968634889e-123',
               4: '5.50194882540715044135552121887e-120',
               6: '-3.11951811112966366103108544392e-117'}
planar = {2: 1, 4: 3, 6: 15, 8: 105}
mom_rep = {}
for j in range(1, 5):
    dev = a[2 * j] - planar[2 * j]
    ck('a%d_positive' % (2 * j), a[2 * j] > 0)
    mom_rep['a%d' % (2 * j)] = S(a[2 * j])
    mom_rep['a%d_minus_planar_%d' % (2 * j, planar[2 * j])] = S(dev)
    ck('a%d_deviation_below_1e_98' % (2 * j), abs(dev) < mp.mpf('1e-98'))
    if 2 * j in author_diag:
        ref = mp.mpf(author_diag[2 * j])
        ck('a%d_author_diagnostic_reproduced' % (2 * j),
           abs(dev - ref) < abs(ref) * mp.mpf('1e-30'))
        mom_rep['a%d_author_diagnostic_agreement' % (2 * j)] = '30 digits'
ck('a2_below_2', a[2] < 2)
ck('a4_below_4', a[4] < 4)
ck('a6_below_16', a[6] < 16)
ck('a8_below_106', a[8] < 106)
# exact-correction signs (MC-RETURN03): a2 < 1, a4 > 3, a6 < 15
ck('a2_strictly_below_1', a[2] < 1)
ck('a4_strictly_above_3', a[4] > 3)
ck('a6_strictly_below_15', a[6] < 15)
# bounds used inside section 6 of the derivation
ck('a2_above_99_100', a[2] > M(Q(99, 100)))
ck('a2_below_101_100', a[2] < M(Q(101, 100)))
ck('a4_below_301_100', a[4] < M(Q(301, 100)))
sup2 = mp.mpf(0)
for i in range(5):
    for j in range(5 - i):
        v = a[2 * i] * a[2 * j]
        sup2 = max(sup2, v)
ck('derivative_L2_sup_le_11', mp.sqrt(sup2) <= 11)
ck('order4_product_a6a2_below_32', a[6] * a[2] < 32)
ck('order4_product_a4a4_below_16', a[4] * a[4] < 16)
out['items']['item3_endpoint_moments'] = {
    'moments': mom_rep,
    'sup_{|alpha|<=4} E|d^alpha f|^2': S(sup2),
    'sup_L2_norm': S(mp.sqrt(sup2)), 'bound': '11'}

# ---------------------------------------------------------------------------
# Items 1 + 7 (section 2): L2 Hermite error table and Taylor remainder inputs
# ---------------------------------------------------------------------------
COEF = [Q(1, 128), Q(7, 384), Q(1, 8), Q(1, 48), Q(1, 24), Q(5, 96)]
POW = [4, 3, 2, 2, 2, 1]
NAMES = ['value', 'x_gradient', 'avg_y_gradient', 'div_x_gradient_over_2',
         'div_y_gradient', 'cubic_hermite']

def U0_stat_terms(i):
    pt, jet = U0_JETS[i]
    return [(M(U0_SCALE[i]), pt, jet)]

def taylor_terms(deriv, deg, sgn, rm):
    """f_deriv(+/- r/2, 0) minus its degree-`deg` Taylor polynomial in x at 0."""
    pt = (sgn * rm / 2, mp.mpf(0))
    terms = [(mp.mpf(1), pt, deriv)]
    from math import factorial
    for j in range(deg + 1):
        c = -mp.mpf(sgn) ** j * (rm / 2) ** j / factorial(j)
        terms.append((c, (mp.mpf(0), mp.mpf(0)), (deriv[0] + j, deriv[1])))
    return terms

item1 = {}
item7 = {}
ssq_bound_coeff = sum(c * c for c in COEF)
ck('summed_coefficient_identity', ssq_bound_coeff == Q(1541, 73728))
ck('summed_coefficient_value', 121 * ssq_bound_coeff == Q(186461, 73728))
ck('summed_coefficient_below_4', 121 * ssq_bound_coeff < 4)
for r in RUNGS:
    rm = M(r)
    errs = []
    for i in range(6):
        terms = U_row_terms(r, i) + [(-c, p, j) for (c, p, j) in U0_stat_terms(i)]
        errs.append(mp.sqrt(linstat_variance(terms)))
    rung = {}
    total2 = mp.mpf(0)
    for i in range(6):
        bnd = 11 * M(COEF[i]) * rm ** POW[i]
        ck('item1_%s_r_%s_below_bound' % (NAMES[i], str(r)),
           errs[i] < bnd - CERT_ERR)
        rung[NAMES[i]] = {'exact_L2_error': S(errs[i]),
                          'displayed_bound': S(bnd),
                          'margin_ratio_bound_over_exact': S(bnd / errs[i])}
        total2 += errs[i] ** 2
    nb = M(121 * ssq_bound_coeff) * rm ** 2
    ck('item1_total_L2sq_r_%s' % str(r), total2 < nb < 4 * rm ** 2)
    rung['TOTAL_E||Vr-V0||^2'] = {'exact': S(total2),
                                  'bound_(186461/73728)r^2': S(nb),
                                  'margin_ratio': S(nb / total2)}
    item1['r=' + str(r)] = rung

    # Item 7: integral Taylor remainders (exact L2 values vs displayed bounds)
    rem = {}
    b4 = 11 * rm ** 4 / 384
    b3 = 11 * rm ** 3 / 48
    b2 = 11 * rm ** 2 / 8
    for sgn, tag in [(1, '+'), (-1, '-')]:
        v = mp.sqrt(linstat_variance(taylor_terms((0, 0), 3, sgn, rm)))
        ck('item7_f_deg3_%s_r_%s' % (tag, str(r)), v < b4 - CERT_ERR)
        rem['f(%s r/2) deg3' % tag] = {'exact': S(v), 'bound': S(b4),
                                       'margin_ratio': S(b4 / v)}
        v = mp.sqrt(linstat_variance(taylor_terms((1, 0), 2, sgn, rm)))
        ck('item7_fx_deg2_%s_r_%s' % (tag, str(r)), v < b3 - CERT_ERR)
        rem['f_x(%s r/2) deg2' % tag] = {'exact': S(v), 'bound': S(b3),
                                         'margin_ratio': S(b3 / v)}
        v = mp.sqrt(linstat_variance(taylor_terms((0, 1), 2, sgn, rm)))
        ck('item7_fy_deg2_%s_r_%s' % (tag, str(r)), v < b3 - CERT_ERR)
        rem['f_y(%s r/2) deg2' % tag] = {'exact': S(v), 'bound': S(b3),
                                         'margin_ratio': S(b3 / v)}
        v = mp.sqrt(linstat_variance(taylor_terms((0, 1), 1, sgn, rm)))
        ck('item7_fy_deg1_%s_r_%s' % (tag, str(r)), v < b2 - CERT_ERR)
        rem['f_y(%s r/2) deg1 (row-3 input)' % tag] = {
            'exact': S(v), 'bound': S(b2), 'margin_ratio': S(b2 / v)}
    item7['r=' + str(r)] = rem
out['items']['item1_L2_hermite_error_table'] = item1
out['items']['item7_L2_taylor_remainder_inputs'] = item7

# ---------------------------------------------------------------------------
# Item 2 (sections 3 and 6): finite-r covariance interval, Schur complement,
# conditional mean
# ---------------------------------------------------------------------------
def solve_vec(A, b):
    n = len(A)
    Am = mp.matrix(A)
    bm = mp.matrix(b)
    x = mp.lu_solve(Am, bm)
    r = Am * x - bm
    res = mp.sqrt(sum(mp.mpf(r[i]) ** 2 for i in range(n)))
    ck('solve_vec_residual', res < mp.mpf('1e-60'))
    return [mp.mpf(x[i]) for i in range(n)]

def solve_mat(A, B):
    n = len(A)
    m = len(B[0])
    Am = mp.matrix(A)
    cols = []
    for j in range(m):
        bj = mp.matrix([B[i][j] for i in range(len(B))])
        xj = mp.lu_solve(Am, bj)
        rj = Am * xj - bj
        res = mp.sqrt(sum(mp.mpf(rj[i]) ** 2 for i in range(n)))
        ck('solve_mat_residual', res < mp.mpf('1e-55'))
        cols.append([mp.mpf(xj[i]) for i in range(n)])
    return [[cols[j][i] for j in range(m)] for i in range(n)]

def negshift(Mmat, s):
    n = len(Mmat)
    return [[(s if i == j else mp.mpf(0)) - Mmat[i][j] for j in range(n)]
            for i in range(n)]

def blocks(G):
    A = [row[:6] for row in G[:6]]
    C = [row[6:] for row in G[:6]]       # Cov(U, J), 6 x 4
    D = [row[6:] for row in G[6:]]       # Cov(J), 4 x 4
    return A, C, D

def beta0_mat():
    z = mp.mpf(0)
    return [[-a[2], z, z, z, z, z],
            [z, z, -a[2] / 2, z, z, z],
            [z, -a[2] / 2, z, z, z, z],
            [z, z, -a[4] / (6 * a[2]), z, z, z]]

def matvec(Mmat, v):
    return [sum(Mmat[i][j] * v[j] for j in range(len(v)))
            for i in range(len(Mmat))]

def nrm(v):
    return mp.sqrt(sum(x * x for x in v))

def conditional(r):
    stats = V_stats(r)
    G = symmetrize(cov_block(stats, stats))
    A, C, D = blocks(G)
    x = solve_vec(A, u_vec(r))
    mu = [sum(C[j][i] * x[j] for j in range(6)) for i in range(4)]
    X = solve_mat(A, C)
    Sg = symmetrize([[D[i][j] - sum(C[k][i] * X[k][j] for k in range(6))
                      for j in range(4)] for i in range(4)])
    return G, A, C, D, mu, Sg

# Endpoint objects (r = 0): U0/J covariance, exact beta0 check, endpoint floor
stats0 = [U0_stat_terms(i) for i in range(6)] + [J_terms(j) for j in range(4)]
G0 = symmetrize(cov_block(stats0, stats0))
A0, C0, D0 = blocks(G0)
# Cov(J,U0) A0^-1 = (A0^-1 Cov(U0,J))^T
X0 = solve_mat(A0, C0)
beta0_exact = [[X0[j][i] for j in range(6)] for i in range(4)]
b0 = beta0_mat()
dev = max(abs(beta0_exact[i][j] - b0[i][j]) for i in range(4) for j in range(6))
ck('beta0_formula_matches_exact_regression', dev < mp.mpf('1e-20'))
e0, tol0 = eigs(G0, 'Gamma0')
ck('endpoint_floor_31_250', e0[0] - tol0 > M(Q(31, 250)))
trG0 = sum(G0[i][i] for i in range(10))
ck('V0_L2_below_7', mp.sqrt(trG0) < 7)
out['items']['item2_endpoint'] = {
    'lambda_min(Gamma_0)': S(e0[0]),
    'endpoint_floor_claim': '31/250 = 0.124',
    'certified_tol': S(tol0),
    '||V_0||_L2': S(mp.sqrt(trG0)), 'V0_bound': '7',
    'beta0_max_abs_deviation_from_displayed_formula': S(dev),
    'tr_D': S(sum(D0[i][i] for i in range(4))), 'tr_D_bound': '76/9 < 9'}

item2 = {}
for r, tag in [(Q(1, 1600), '1/1600'), (Q(1, 800), '1/800 (control)')]:
    G, A, C, D, mu, Sg = conditional(r)
    eG, tolG = eigs(G, 'Gamma_' + tag)
    minors_positive(shift(G, M(Q(13, 125))), 'Gamma_' + tag + '_minus_13over125I')
    minors_positive(negshift(G, 81), '81I_minus_Gamma_' + tag)
    ck('lambda_min_Gamma_' + tag, eG[0] - tolG > M(Q(13, 125)))
    ck('lambda_max_Gamma_' + tag, eG[-1] + tolG < 81)
    eS, tolS = eigs(Sg, 'Sigma_' + tag)
    minors_positive(shift(Sg, M(Q(1, 10))), 'Sigma_' + tag + '_minus_1over10I')
    minors_positive(negshift(Sg, 9), '9I_minus_Sigma_' + tag)
    ck('lambda_min_Sigma_' + tag, eS[0] - tolS > M(Q(1, 10)))
    ck('lambda_max_Sigma_' + tag, eS[-1] + tolS < 9)
    trG = sum(G[i][i] for i in range(10))
    ck('trace_Gamma_' + tag + '_below_81', trG < 81)
    b0u = matvec(b0, u_vec(r))
    dmu = [mu[i] - b0u[i] for i in range(4)]
    entry = {'lambda_min(Gamma_r)': S(eG[0]), 'floor': '13/125 = 0.104',
             'lambda_max(Gamma_r)': S(eG[-1]), 'op_bound': '81',
             'tr(Gamma_r)': S(trG),
             'lambda_min(Sigma_r)': S(eS[0]), 'Sigma_floor': '1/10',
             'lambda_max(Sigma_r)': S(eS[-1]), 'Sigma_cap': '9',
             'conditional_mean_mu_r': [S(x) for x in mu],
             '||mu_r||': S(nrm(mu)), 'mean_bound': '3',
             '||beta0 u_r||': S(nrm(b0u)),
             '||mu_r - beta0 u_r||': S(nrm(dmu)), 'deviation_bound': '6/5',
             '||u_r||': S(nrm(u_vec(r))), 'u_r_bound': '2'}
    # perturbation modulus evidence: ||Gamma_r - Gamma_0||_op <= 32r
    Dg = symmetrize([[G[i][j] - G0[i][j] for j in range(10)] for i in range(10)])
    eD, tolD = eigs(Dg, 'dGamma_' + tag)
    mod = max(abs(eD[0]), abs(eD[-1])) + tolD
    entry['||Gamma_r-Gamma_0||_op_exact'] = S(mod)
    entry['perturbation_bound_32r'] = S(32 * M(r))
    ck('perturbation_modulus_' + tag, mod < 32 * M(r))
    if r == Q(1, 1600):
        ck('mean_norm_below_3', nrm(mu) < 3)
        ck('mean_deviation_below_6_5', nrm(dmu) <= M(Q(6, 5)))
    item2['r=' + tag] = entry
out['items']['item2_covariance_interval'] = item2

# ---------------------------------------------------------------------------
# Item 4 (section 6): conditional density floor at r = 1/1600 over K_J
# ---------------------------------------------------------------------------
r = Q(1, 1600)
G, A, C, D, mu, Sg = conditional(r)
dlt = M(DELTA)
box = [(-mp.mpf(11), mp.mpf(1)), (2 - dlt, 2 + dlt), (-dlt, dlt), (-dlt, dlt)]
Sinv = solve_mat(Sg, [[mp.mpf(1 if i == j else 0) for j in range(4)]
                      for i in range(4)])
eS, _ = eigs(Sg, 'Sigma_density')
detS = mp.mpf(1)
for ev in eS:
    detS *= ev
ck('detSigma_consistency', abs(detS - mp.det(mp.matrix(Sg))) < mp.mpf('1e-60'))

def quadform(j):
    d = [j[i] - mu[i] for i in range(4)]
    return sum(d[i] * sum(Sinv[i][k] * d[k] for k in range(4)) for i in range(4))

def log10density(j):
    qf = quadform(j)
    return (-2 * mp.log10(2 * mp.pi) - mp.log10(detS) / 2
            - qf * mp.log10(mp.e) / 2)

import itertools
corners = list(itertools.product(*[(lo, hi) for (lo, hi) in box]))
corner_vals = [(log10density(list(j)), list(j)) for j in corners]
corner_vals.sort(key=lambda t: t[0])
cmin, cmin_pt = corner_vals[0]
# adversarial scan: every edge (other three coords fixed at bounds), 21 points
scan_min = cmin
for dim in range(4):
    others = [d for d in range(4) if d != dim]
    for fixed in itertools.product(*[(box[d][0], box[d][1]) for d in others]):
        for s in range(21):
            j = [mp.mpf(0)] * 4
            for idx, d in enumerate(others):
                j[d] = fixed[idx]
            lo, hi = box[dim]
            j[dim] = lo + (hi - lo) * s / 20
            scan_min = min(scan_min, log10density(j))
# coarse 5-per-dimension grid (625 interior points)
grid_min = cmin
axes = [[lo + (hi - lo) * s / 4 for s in range(5)] for (lo, hi) in box]
for j in itertools.product(*axes):
    grid_min = min(grid_min, log10density(list(j)))
# -2 log phi = quadform + const is a CONVEX quadratic (Sinv PD), so its maximum
# over the box is attained at a vertex: the corner minimum is the global box
# minimum.  The scans are adversarial evidence only.
ck('density_min_at_corner', scan_min >= cmin - mp.mpf('1e-12')
   and grid_min >= cmin - mp.mpf('1e-12'))
ck('density_floor_1129_strictly_below_computed', cmin > -1129)
natural = (-2 * mp.log10(2 * mp.pi) - 2 * mp.log10(9)
           - 1125 * mp.log10(mp.e))
out['items']['item4_density_floor'] = {
    'r': '1/1600',
    'log10_min_density_over_KJ_corners': S(cmin),
    'argmin_corner_(q,A,B,D3)': [S(x) for x in cmin_pt],
    'log10_min_edge_scan': S(scan_min),
    'log10_min_5d_grid_scan': S(grid_min),
    'displayed_floor_m_*': '10^-1129',
    'margin_orders_of_magnitude': S(cmin - (-1129)),
    'derivations_own_natural_floor_(2pi)^-2 9^-2 e^-1125': S(natural),
    'mu_r': [S(x) for x in mu],
    'det(Sigma_r)': S(detS)}

# ---------------------------------------------------------------------------
# Item 5 (section 5, evidence): representer norms and V-moments at r = 0.025
# ---------------------------------------------------------------------------
r5 = Q(1, 40)
stats5 = V_stats(r5)
G5 = symmetrize(cov_block(stats5, stats5))
rm5 = M(r5)
z_samples = [(mp.mpf(0), mp.mpf(0)), (rm5 / 2, mp.mpf(0)), (mp.mpf(1), mp.mpf(1)),
             (mp.mpf('3.7'), mp.mpf('-5.2')), (mp.mpf(12), mp.mpf(12)),
             (mp.mpf('23.9'), mp.mpf('0.4')), (mp.mpf('5.5'), mp.mpf('18.25')),
             (mp.mpf('-9.1'), mp.mpf('-2.2'))]
alphas = [(i, j) for i in range(5) for j in range(5 - i)]
maxC = mp.mpf(0)
maxC_info = None
for z in z_samples:
    for al in alphas:
        vec = []
        for st in stats5:
            tot = mp.mpf(0)
            for (c, wpt, beta) in st:
                tot += c * cov_eval(al, beta, (z[0] - wpt[0], z[1] - wpt[1]))
            vec.append(tot)
        nv = nrm(vec)
        if nv > maxC:
            maxC = nv
            maxC_info = {'z': [S(z[0]), S(z[1])], 'alpha': al}
ck('representer_norm_below_99', maxC <= 10)
trG5 = sum(G5[i][i] for i in range(10))
trG5sq = sum(G5[i][j] ** 2 for i in range(10) for j in range(10))
EV4 = trG5 ** 2 + 2 * trG5sq
ck('EV_L1_below_9', mp.sqrt(trG5) <= 9)
ck('EV4_isserlis_below_3trsq', EV4 <= 3 * trG5 ** 2)
out['items']['item5_B3_B4_evidence'] = {
    'r': '0.025',
    'max_||d^alpha C_r(z)||_2_over_samples': S(maxC),
    'max_location': maxC_info, 'bound': '99 (=11*9)',
    'E||V||_upper_(Jensen_sqrt_trGamma)': S(mp.sqrt(trG5)), 'bound': '9',
    'E||V||^4_exact_isserlis': S(EV4),
    '3(tr_Gamma)^2': S(3 * trG5 ** 2),
    'tr_Gamma_r': S(trG5)}

# ---------------------------------------------------------------------------
# Item 6 (section 7): exact rational final arithmetic (never floats)
# ---------------------------------------------------------------------------
import sympy as sp
K = 2 * 10 ** 24
B3 = 10 ** 96
B4 = 10 ** 24
rstar = Q(1, 10 ** 28)
mexp = -1129
ck('K_is_2_times_B4', K == 2 * B4)
ck('radius_below_R', rstar <= Q(1, 1600))
v = 256 * K * rstar
ck('taylor_radius_256Kr', v == Q(512, 10000) and v < 1)
geo = 16 * DELTA + 8 * K * rstar
ck('geometric_error_exact', geo == Q(1, 64) + Q(1, 625))
ck('geometric_error_chain', geo < Q(3, 64) < Q(1, 16))
ck('prefactor_integer_inequality', 260 * 10 ** 10 > 2 ** 40)
ck('prefactor_floor', 260 * Q(1, 2 ** 40) > Q(1, 10 ** 10))
# 1 - q >= 16 m delta^4 r * 65 r^4 / (4 B3 r^2) = 260 m delta^4 / B3 * r^3
ck('coefficient_simplification_260', Q(16 * 65, 4) == 260)
cexp = mexp - 10 - 96
ck('exponent_chain', mexp - 96 == -1225 and cexp == -1235)
cstar = {'base': 10, 'exponent': cexp, 'representation': 'exact_rational_power'}
ck('cstar_exact_power_of_ten', cstar['base'] == 10 and cstar['exponent'] == -1235
   and isinstance(cstar['exponent'], int))
# full chain: 260 * 10^-1129 * 2^-40 / 10^96 > 10^-1235  (exact rational)
lhs_coeff = 260 * Q(1, 2 ** 40) * Q(1, 10 ** 1129) * Q(1, 10 ** 96)
ck('final_chain_strictly_above_cstar', lhs_coeff > Q(1, 10 ** 1235))
ck('final_chain_within_factor_3', lhs_coeff < 3 * Q(1, 10 ** 1235))
# u_r exact identity and det T_r = -r^-5 (symbolic, independent of numerics)
rs = sp.symbols('r', positive=True)
bs = sp.Rational(6, 5)
Tr = sp.Matrix([[sp.Rational(1, 2), rs / 8, 0, sp.Rational(1, 2), -rs / 8, 0],
                [-sp.Rational(3, 2) / rs, -sp.Rational(1, 4), 0,
                 sp.Rational(3, 2) / rs, -sp.Rational(1, 4), 0],
                [0, 0, sp.Rational(1, 2), 0, 0, sp.Rational(1, 2)],
                [0, -sp.Rational(1, 2) / rs, 0, 0, sp.Rational(1, 2) / rs, 0],
                [0, 0, -1 / rs, 0, 0, 1 / rs],
                [2 / rs ** 3, 1 / rs ** 2, 0, -2 / rs ** 3, 1 / rs ** 2, 0]])
pin = sp.Matrix([bs, 0, 0, bs - rs ** 3 / 6, 0, 0])
ur = sp.simplify(Tr * pin)
target = sp.Matrix([bs - rs ** 3 / 12, -rs ** 2 / 4, 0, 0, 0, sp.Rational(1, 3)])
ck('u_r_exact_identity', sp.simplify(ur - target) == sp.zeros(6, 1))
ck('det_T_r', sp.simplify(Tr.det() + rs ** -5) == 0)
out['items']['item6_exact_rational_arithmetic'] = {
    '256*K*r_*': str(v), '16delta+8Kr_*': str(geo),
    '260*10^10_vs_2^40': [str(260 * 10 ** 10), str(2 ** 40)],
    '260*delta^4': str(260 * Q(1, 2 ** 40)),
    'coefficient_260*m*delta^4/B3_exponent_form': '260*2^-40*10^(-1129-96)',
    'c_*': cstar, 'r_*': {'base': 10, 'exponent': -28},
    'note': 'all tiny constants held as exact Fractions / powers of ten; no floats'}

# ---------------------------------------------------------------------------
out['check_count'] = len(CHECKS)
out['checks'] = CHECKS
out['scope'] = ('Numeric evidence and independent reproduction of the computable '
                'components only. Analytic inequality steps (tail algebra, '
                'integral-remainder bounds, variational Schur bound, topology/'
                'weight linkage) are per the lead analytic verdict. This '
                'program is evidence, not a proof certificate.')
print(json.dumps(out, indent=2, sort_keys=True))
