# LEAD ANALYTIC REVIEW — QC-RETURN03 explicit LPW bound pair (r_* = 10^{−28}, c_* = 10^{−1235})

Reviewer: lead coordinator (KIMI line). Date: 2026-09-13.
Target: 03_EXPLICIT_CONSTANTS_CANDIDATE.md (Return-03 bundle, 49/49 manifest files verified).
Exposure: the full derivation was read before review — ordinary hostile review. Independent numeric
verification of the computable components is dispatched separately (QC_RETURN03_REVIEW agent);
this document records the analytic verification at the derivation level.

## VERDICT: PASS WITHIN SCOPE on all seven review targets (Q1–Q7) at the derivation level.

The proposed statement stands verified as written: under exactly the LPW 2D side-24 covariance,
six-pin continuous Gaussian regression law, typed pair determinant weight, and elder-rule estimand,

    1 − q(r, 6/5) ≥ 10^{−1235}·r³    for every 0 < r ≤ 10^{−28},

with both constants exact positive rational powers of ten (stored as exact integers, never floats).

## Per-target dispositions

**Q1 (eighth-moment tail, L² bound 11) — PASS.** The infinite-sum estimate |a_{2j} − (2j−1)!!| <
10^{22}t < 10^{−98} is valid: the coefficient absolute sum of (−1)^jH_{2j}(24n) − (2j−1)!! is
≈ 1.154e11 < 10^{13} (worst at j = 4: 24^8 + 28·24^6 + 210·24^4 + 420·576 ≈ 1.154e11), n^8 ≤ 8!·C(n+7,8),
and Σ_{n≥1} C(n+7,8)t^n = t/(1−t)^9 (the generating-function identity checks: Σ_{n≥1}C(n+7,n−1)t^n =
t·Σ_{m≥0}C(m+8,m)t^m = t/(1−t)^9). Hence 0 < a₂ < 2, 0 < a₄ < 4, 0 < a₆ < 16, 0 < a₈ < 106, and
sup_{z,|α|≤4} ‖∂^α f‖_{L²} ≤ √106 < 11 (order-4 products: a₈·1 = 106 max; a₆a₂ < 32; a₄² < 16).

**Q2 (six L² Hermite errors) — PASS.** Independently recomputed each bound: value coordinate
11r⁴/384 + (r/8)(22r³/48) = 33r⁴/384 = 11r⁴/128; x-gradient (3/(2r))(22r⁴/384) + (1/4)(22r³/48) =
33r³/384 + 44r³/384 = 77r³/384; average y-gradient (r²/8)·11 + 11r³/48 ≈ 11r²/8; divided x-gradient
(2·11r³/48)/(2r) = 11r²/48; divided y-gradient (2·11r³/48)/r = 11r²/24; cubic Hermite
2·(11r⁴/192)/r³ + (11r³/24)/r² = 11r/96 + 44r/96 = 55r/96 (the candidate's "1/96 + 1/24" is the
two-term shorthand 11·(1/96) + 11·(1/24) = 55/96, consistent). The norm square
121·[(1/128)² + (7/384)² + (1/8)² + (1/48)² + (1/24)² + (5/96)²] = 121·0.020901 = 2.52903 =
186461/73728 < 4, so ‖V_r − V_0‖ ≤ 2r. ‖V_0‖_{L²} < √40 < 7 (every coordinate variance < 4:
f_yy ≈ 3 is the largest).

**Q3 (covariance perturbation, R = 1/1600, Schur lower bound) — PASS.** The expansion
‖Γ_r − Γ_0‖_op ≤ 2‖V_0‖‖Dr‖ + ‖Dr‖² ≤ 28r + 4r² ≤ 32r (r ≤ 1) is correct and needs no
independence. With the verified endpoint floor λ_min(Γ_0) > 31/250 (independently verified earlier:
all ten exact Sylvester minors), R = 1/1600 gives λ_min(Γ_r) > 31/250 − 32/1600 = 0.104 = 13/125 >
1/10 (exact arithmetic). ‖Γ_r‖_op ≤ tr Γ_r = E‖V_r‖² ≤ (7 + 2r)² ≤ 81. The Schur lower bound: for
any unit y, yᵀΣ_r y = min_x (x,y)ᵀΓ_r(x,y) ≥ (1/10)‖y‖² (variational form of the Schur complement);
upper: Σ_r ⪯ Γ_JJ ⪯ 81I (the Schur correction is positive semidefinite). The six-pin submatrix
inherits λ ≥ 1/10 by Cauchy interlacing.

**Q4 (full real Fourier C⁴ L⁴ majorant) — PASS.** Every step verified: √{p_n} = e^{−α²|n|²/4}/√Z_spec
with Z_spec ≥ 1; the Gaussian coefficient L⁴ norm 3^{1/4} < 2 and the √2·3^{1/4} < 4 slack;
e^{−α²n²/4} ≤ e^{−n²/64} (α > 1/4); 1 + α(|n₁|+|n₂|) ≤ (1+|n₁|)(1+|n₂|) (α < 1);
e^{−n²/64} ≤ (64/65)^{|n|} (n² ≥ |n|, e^{1/64} > 65/64); (n+1)⁴ ≤ 24·C(n+4,4) with the factor 2 for
the two-sided sum absorbed into 48; Σ_{n≥0} C(n+4,4)q^n = (1−q)^{-5} = 65^5; final
4·(48·65^5)² = 9216·65^{10} = 12407264266410000000000 < 10^{23} (recomputed: 65^{10} = 1.3463e18,
times 9216 = 1.2407e22). The count 12407264266410000000000 matches exactly.

**Q5 (representer bound, residual triangle inequality, B_3/B_4 distinction) — PASS.**
‖∂^α C_r(z)‖₂² ≤ E|∂^α f|²·tr Cov(V) ≤ 121·81 → ≤ 99; regression map norm ≤ 99·10 = 990 < 1000;
‖V‖_{L1} ≤ 9 (Jensen); E‖V‖⁴ = (tr Γ)² + 2 tr(Γ²) ≤ 3(tr Γ)² (Isserlis, verified) → ‖V‖_{L4} ≤
3^{1/4}·9 < 18; ‖u_r‖ < 2; ‖j‖ < 12 on the original K_J (√(121 + (2+δ)² + 2δ²) < 11.2);
‖(u_r, j)‖ < 14; the residual triangle inequality ‖f|V=v‖ ≤ ‖f‖_{L^p(C⁴)} + 1000(‖V‖_{L^p} + ‖v‖)
is correct (nonstationary residual included via the L_r terms, matching the confirmed R3 addendum).
E[M_4 | U_r = u_r, J = j] ≤ 10^{23} + 1000(9 + 14) < 10^{24} → B_4 = 10^{24}, K = 2×10^{24}.
(E_{Q_r}[max(1, ‖f‖_{C³})⁴])^{1/4} ≤ 1 + 10^{23} + 1000(18 + 2) < 2·10^{23} → fourth power
< 16·10^{92} < 10^{96} → B_3 = 10^{96}, C_Z = 4×10^{96}. B_3 and B_4 are distinct chosen upper
bounds, correctly not interchanged.

**Q6 (uniform density floor) — PASS.** β₀ = B_0A_0^{-1} with ‖β₀‖_F² = 3a₂²/2 + a₄²/(36a₂²) < 4
(recomputed ≤ 1.79 with the moment caps); ‖β₀u_r‖ ≤ a₂(b + r²/8) ≤ (101/100)(53/40) = 5353/4000 <
7/5 (exact); the perturbation identity μ_r − β₀u_r = [(B_r − B_0) − β₀(A_r − A_0)]A_r^{-1}u_r is
exact algebra; ‖μ_r − β₀u_r‖ ≤ (1 + 2)·32r·10·2 = 1920r = 6/5 at r = 1/1600, so ‖μ_r‖ < 2.6 < 3;
Σ_r ⪯ D with tr D = a₄ + a₂a₄/2 + a₆/36 < 4 + 4 + 16/36 = 76/9 < 9 → Σ_r ⪯ 9I. The density floor:
prefactor (2π)^{-2}·9^{-2} > 1/5184 > 10^{−4} (π < 4 verified); exponent (12 + 3)²/(2·(1/10)) = 1125;
exp(−1125) > 10^{−1125} (exp(1) < 10). Hence m_* = 10^{−1129} = 10^{−4}·10^{−1125} is a VALID uniform
lower density over [0, R] × K_J. Note (not a defect): the natural floor from the same formula is
~10^{−493}; m_* is deliberately ~636 orders weaker — a valid lower choice, not an error.

**Q7 (topology/weight linkage, final powers) — PASS.** 256·K·r_* = 512·10^{24}·10^{−28} = 0.0512 < 1;
16δ + 8Kr_* = 1/64 + 1/625 < 3/64 < 1/16 (1/64 = 0.015625, 1/625 = 0.0016); 260·10^{10} = 2.6e12 >
2^{40} = 1.0995e12 so 260/2^{40} > 10^{−10}; the composition 1 − q ≥ E[W_r1_G]/Z_r ≥
65r⁴·16m_*δ⁴r/(4B_3r²) = (65·16/4)·m_*δ⁴/B_3·r³ = 260·m_*δ⁴/B_3·r³; final
c_* = 10^{−1129−10−96} = 10^{−1235}. Q(G_r) ≥ 16m_*δ⁴r uses K = 2×10^{24} ≥ max(1, 2B_4) and the
Markov 1/2 factor correctly. No new law, no compact-set substitution, no topology change from the
endorsed LPW construction (its own review stands separately).

## Reviewer's notes (not defects)

1. The candidate is deliberately weak by design (m_* is ~636 orders below the natural floor from the
   same formula; B_3/B_4 are deliberately loose). A successor can improve each bound by large factors;
   none of the looseness is a mathematical error.
2. Exact-integer storage of 10^{−1235} is mandatory (float underflow); the candidate states this
   correctly, and the verification repeats it.
3. The companion executable checks (75 PASS + 8 mutation families) are author-side; the independent
   numeric verification of items 1–7 above is in flight (QC_RETURN03_REVIEW agent) and will ship with
   this verdict's evidence package. Any discrepancy it reports beyond the displayed bounds' margins
   would convert the corresponding Q-target to AMEND REQUIRED; none is expected — every displayed
   bound carries wide slack.

## Status firewall

This review verifies the quantitative candidate's derivation. It changes no LS-CTL Boolean,
eligibility predicate, theorem status, RP status, AO48 operator record, or q0 package status. Any
status change requires separate operator adjudication. The qualitative LPW endorsement (cf58f72e…)
stands independently; a defect here would not retract it.

SHA-256 of this review body (text after this line is excluded):
4f244e69aafcad5b662ba5b40ea97308526ca533cf996f5327a13ab35f4b61a9
