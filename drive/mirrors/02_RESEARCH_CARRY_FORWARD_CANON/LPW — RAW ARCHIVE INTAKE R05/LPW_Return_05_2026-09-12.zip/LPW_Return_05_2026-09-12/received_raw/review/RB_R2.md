# RB_R2 — Independent review, interface R2: Six-/ten-coordinate Gaussian limit

**Reviewer:** RB (KIMI independent review, review agent RB).
**Target:** `02_LOCAL_PATH_LOWER_BOUND_CANDIDATE.md` v1.0, SHA-256
`cf58f72eb0399c626160c143b50f674ff3bd5c449225211edd6fd378a374e1a5` (matches MANIFEST.sha256).
**Review packet:** `03_INDEPENDENT_REVIEW_PACKET.md`, SHA-256
`b3b1371f4d0f0b4b7f2ccac61742b241ec549cb145765f60fc4ccf278a871536` (matches MANIFEST).
**Reviewed scope:** candidate §1 (exact object), §5 (six-pin Hermite normalization), §6
(nondegenerate conditional jet density), plus the r = 0 endpoint of the uniform bounds used in §7–§10.
**Exposure/independence disclosure:** ordinary hostile review — I read the full candidate first,
then independently re-derived every formula below from the definitions (basis, pin order,
spectral representation) before comparing with the candidate's displays. I do not claim blind
discovery. All algebra was recomputed with sympy 1.14 from scratch; all numerics were recomputed
with mpmath 1.3 at 50 dps from the spectral definition, not from any author artifact.
**Tools run:** `RB_R2_part1_symbolic.py` (sympy, exact), `RB_R2_part2_spectral.py` (mpmath 50 dps).
Both fail-closed (`ck()` → `SystemExit(1)`; no bare asserts). `python` vs `python -O` program
outputs byte-identical for both scripts (verified by diff). Scripts and outputs:
`REVIEW_LPW/RB_R2_part{1,2}_*.py`, `p{1,2}_normal.out`, `p{1,2}_opt.out`.

All numerical values below are **evidence, not proof**. Every numerical eigenvalue statement
carries a certified a posteriori residual plus a certified spectral-truncation tail; those two
certified bounds are rigorous.

---

## 1. V, T_r, det T_r = −r^{−5}, u_r — VERIFIED EXACTLY

Candidate lines relied on: §5, lines 183–213 ("Put the raw pin vector in the order P6_r = …",
"Let V be the 6x6 matrix … on the polynomial basis (1, x, y, x^2, xy, x^3). Its determinant is
exactly -1", "D_r = diag(1,r,r,r^2,r^2,r^3), R_r = diag(1,r,r,1,r,r), T_r = D_r^{-1}V^{-1}R_r",
the displayed T_r, "det T_r = -r^{-5}", "u_r = T_r(b,0,0,b-r^3/6,0,0)^T = (b-r^3/12,-r^2/4,0,0,0,1/3)^T").

Independent reconstruction (row-major: value/x-/y-derivative evaluations at m = (−1/2,0), then
s = (1/2,0); columns the basis (1,x,y,x²,xy,x³)):

    V = [[1,-1/2,0, 1/4,   0,-1/8],
         [0,   1,0,  -1,   0, 3/4],
         [0,   0,1,   0,-1/2,   0],
         [1, 1/2,0, 1/4,   0, 1/8],
         [0,   1,0,   1,   0, 3/4],
         [0,   0,1,   0, 1/2,   0]]

sympy exact: **det V = −1** ✓. Reconstructed `D_r^{-1} V^{-1} R_r` equals the candidate's
displayed T_r entry-for-entry (exact symbolic difference = zero matrix) ✓. Determinant:
det T_r = det(D_r^{−1})·det(V^{−1})·det(R_r) = r^{−9}·(−1)·r⁴ = **−r^{−5}** (also confirmed by
direct symbolic det) ✓; hence T_r invertible for every r > 0 ✓, so conditioning on U_r = T_r P6_r
is the same Gaussian conditioning (invertible linear image of the pin vector; σ-algebras equal) ✓.

Observed vector: symbolic T_r·(b,0,0,b−r³/6,0,0)ᵀ = **(b − r³/12, −r²/4, 0, 0, 0, 1/3)** ✓,
with limit (b,0,0,0,0,1/3) as r→0⁺ — hence u_r stays in a compact set (candidate line 223) ✓.

## 2. U_r → U_0 in Gaussian L², incl. covariances — VERIFIED

Candidate lines relied on: §5, lines 215–221 ("U_r converges in Gaussian L2 to
U_0 = (f(0),f_x(0),f_y(0),f_{xx}(0)/2,f_{xy}(0),f_{xxx}(0)/6)… the y-derivative data interpolate
f_y along the x-axis by its constant and linear terms. Higher x powers contribute errors tending
to zero. For the remaining four coordinates the cubic Hermite interpolation is exact through
degree three. Taylor remainder estimates prove the stated convergence, also after taking
covariance against any fixed derivative evaluation of f.").

Independent check (sympy, general degree-6 polynomial germ with 28 symbolic coefficients — by
Taylor's theorem this is the general smooth germ up to o(|z|⁶)):

- x-axis coordinates (1: value, 2: x-derivative, 4: x²-coefficient, 6: x³-coefficient): the cubic
  Hermite interpolation on [−1/2,1/2] is exact through degree three; on a general germ the
  remainders are −r⁴(2c₄₀+c₆₀r²)/32, −c₅₀r⁴/16, r²(8c₄₀+3c₆₀r²)/16, c₅₀r²/2 respectively —
  all O(r²) or better, with targets f(0), f_x(0), f_xx(0)/2, f_xxx(0)/6 recovered exactly. ✓
- y-containing coordinates: coord 3 = (f_y(M_r)+f_y(S_r))/2 = constant term of the linear
  interpolant of f_y on the axis, coord 5 = (f_y(S_r)−f_y(M_r))/r = its slope; limits f_y(0) and
  f_xy(0), remainders r²(4c₂₁+c₄₁r²)/16 and 0 on cubics. Coord 3's O(r²) remainder carries the
  x²y coefficient — precisely the candidate's "higher x powers contribute errors tending to zero".
  The candidate's exactness sentence ("remaining four coordinates … exact through degree three")
  is accurate as stated: it excludes the two y-coordinates. ✓
- Pointwise deterministic bound: |U_r,i − U_0,i| ≤ C·r·(‖f‖_{C³}+‖f‖_{C⁴}) near 0; L² convergence
  follows from E‖f‖_{C^k}^p < ∞ (Fourier majorant, candidate §7 lines 281–293 — argument is
  correct for the periodized field: coefficients √a_n decay like e^{−|n|²/…}, the L^p sum is
  finite). Covariance against any fixed derivative evaluation D then converges by Cauchy–Schwarz:
  |Cov(U_r,i−U_0,i, D)| ≤ ‖U_r,i−U_0,i‖₂‖D‖₂ → 0. ✓
- Numeric rate evidence (analytic targets on a test field): max|U_r − U_0| = 3.50e-3, 3.50e-5,
  3.50e-7 at r = 10⁻¹, 10⁻², 10⁻³ — clean O(r²). Evidence only. ✓

## 3. Ten-jet positive definiteness: argument VERIFIED; endpoint eigenvalue CERTIFIED numerically

Candidate lines relied on: §6, lines 234–236 ("The pair (U_0,J) is an invertible
rescaling/reordering of the complete ten-dimensional third-order jet… variance of a nonzero
linear combination … positive weighted lattice sum of |P(ik)|^2 … A nonzero polynomial cannot
vanish on all of Z^2 … Every spectral weight is positive.").

Argument check: for the exact periodized field every dual frequency k ∈ (π/12)ℤ² carries weight
w(k) = e^{−|k|²/2}/Z > 0 (candidate line 30; full lattice support, no truncation). A linear
combination Σ c_α ∂^α f(0) has variance Σ_k w(k)|P(ik)|² with P(z) = Σ c_α z^α a complex
polynomial of degree ≤ 3. Vanishing of the sum forces P(iπ n/12) = 0 for all n ∈ ℤ², hence
P ≡ 0 (the candidate's fix-one-coordinate argument is the standard proof), hence c = 0. Sound. ✓
(U_0, J) is a diagonal rescaling of the raw ten-jet (factors 1,1,1,2,1,6,1,2,2,6), so PD of one
is PD of the other. ✓

Numerical endpoint certificate (evidence + certified bounds). Spectral sums over n ∈ [−114,114]²
(covers |k| ≤ 30), Z-normalized, mpmath 50 dps. Cross-checks: Z = 288/π to 25 digits (Poisson
identity vs the candidate's real-space normalization, line 27) ✓; Var(f_x) = 1 (real-space
−K_xx(0) = 1) ✓. Certified truncation tails (shell bound
Σ_{max|n_i|≥115} 8m^p e^{−a m²} ≤ 8M₀^p(1+1/(aM₀))e^{−aM₀²}, M₀ = 115, a = π²/288):
Z-tail ≤ 1.8e-194, |k|⁶-weighted tail ≤ 1.1e-184. Eigenvalue certification: A − QΛQᵀ residual in
Frobenius norm (≤ 6.9e-50) plus the tail operator bound.

    λ_min(Cov of the full ten-jet (U_0, J) at r = 0) = 0.126553449667289…
    CERTIFIED: λ_min ≥ 0.1265534497  (residual 6.9e-50, tail 1.2e-185)
    r = 0 Schur complement (conditional covariance of J | U_0): λ_min = 1/6 = 0.16666…, det = 1/12.

This certifies the r = 0 endpoint of the uniform-lower-bound claim (candidate line 238).

## 4. Continuity down to r = 0 — argument VERIFIED; rung numerics

Candidate lines relied on: §6, line 238 ("It follows by continuity that the covariance of
(U_r,J) has a uniform positive eigenvalue lower bound on some [0,r_G]. Its Schur complement gives
a uniformly positive-definite conditional covariance … conditional means and covariance matrices
vary continuously down to r=0.").

Argument check: by §2 above, each coordinate of U_r converges in L², so every entry of
Γ_r = Cov(U_r, J) is continuous on [0,1] including r = 0 (Cauchy–Schwarz against the L² limit);
Γ_0 is positive definite (§3, certified). λ_min is continuous, so λ_min(Γ_r) ≥ λ_min(Γ_0)/2 > 0
on some [0, r_G] — a compactness/continuity statement, existential (no explicit r_G is produced
or needed at the candidate's existential scope). The Schur complement S_r = Γ_JJ − Γ_JU Γ_UU^{−1}
Γ_UJ is a continuous rational function of the entries on the PD cone, positive definite for each
r ≤ r_G (Schur criterion), so uniformly PD on the compact interval; conditional means
μ_r = Γ_JU Γ_UU^{−1} u_r are continuous since u_r is (§1) and the inverse is continuous. Chain
sound. ✓

Rung numerics on the exact field (evidence; each value carries eig-residual ≤ 1.5e-43 and
certified tail ≤ 6.3e-185):

| r | λ_min Γ_r (10×10) | λ_min Schur (4×4) | det S_r | cond. mean μ_r |
|---|---|---|---|---|
| 0.5 | 0.127079283116 | 0.166444131526 | 0.0888179 | (−1.22495, 0, ~0, 0) |
| 0.25 | 0.126728545251 | 0.166651760352 | 0.0846512 | (−1.20795, 0, ~0, 0) |
| 0.1 | 0.126583534251 | 0.166666277503 | 0.0835421 | (−1.20141, 0, ~0, 0) |
| 0.05 | 0.126561045749 | 0.166666642275 | 0.0833854 | (−1.20036, 0, ~0, 0) |
| 0.025 | 0.126555353381 | 0.166666665141 | 0.0833464 | (−1.20009, 0, ~0, 0) |
| 0 (certified) | 0.1265534497 (lower bound) | 0.166666666667 | 0.0833333 | — |

Monotone approach of rung values to the certified r = 0 endpoint (gap ~2e-6 at r = 0.025,
consistent with O(r²)) is direct numerical evidence for the continuity claim. Evidence, not proof.

## 5. Density lower bound m > 0 — chain VERIFIED; density evaluations

Candidate lines relied on: §6, lines 240–246 ("The density of J under Q_r therefore has a positive
lower bound m on the fixed compact box K_J = [−11,1]×[2−δ,2+δ]×[−δ,δ]² for
0≤r≤min(r_G,1)… determinants are bounded above and below, its inverse covariance is bounded, and
its means and arguments are bounded.").

Chain check: under Q_r, J ∼ N(μ_r, S_r) exactly (Gaussian regression; the regression version is
the stipulated conditioning version, candidate line 32–38). On the compact set
[0, min(r_G,1)] × K_J: (r,j) ↦ density is continuous down to r = 0 (§4) and positive; explicitly,
det S_r bounded above (entries bounded by C–S against raw jet variances) and below (uniform PD,
§4), S_r^{−1} bounded (uniform PD), μ_r bounded (continuity + compact u_r), j bounded (K_J
compact). Hence the Gaussian density (2π)^{−2}(det S)^{−1/2}exp(−½(j−μ)ᵀS^{−1}(j−μ)) ≥ m > 0
uniformly. Sound. ✓

Density evaluations at r = 0.025, δ = 1/1024 (evidence): conditional mean μ_r ≈ (−1.20009, 0, 0, 0);

- center of the thin event's box, j_c = (−10r, 2, 0, 0) = (−0.25, 2, 0, 0):
  density = 1.2832e-3 (Mahalanobis quadratic form 8.450);
- minimum over the 16 corners j = (−10r ± 2rδ, 2 ± δ, ±δ, ±δ):
  density = 1.2781e-3 (at (−0.249951, 2.00098, +δ, −δ), quadratic form 8.458);
- maximum over center+corners: 1.2882e-3.
- vol(E_r) = 32δ⁴r = 7.2760e-13 at r = 0.025; (min observed density)×vol ≈ 9.30e-16.

The density is small but uniformly positive across the box at this rung, with variation < 1%
between center and corners — consistent with a uniform m > 0. Evidence, not proof (the proof is
the compactness chain above, which is verified).

## 6. Thin event — VERIFIED

Candidate lines relied on: §6, lines 248–260 (definition of E_r, "For r<=1 it is contained in
K_J", "volume (4δr)(2δ)^3 = 32δ^4 r"), line 375 ("Set C = q/(2r)"), line 230 (q = f_yy(0)).

- q = f_yy(0) verbatim from J = (q,A,B,D₃) = (f_yy(0), f_xxy(0)/2, f_xyy(0)/2, f_yyy(0)/6) ✓.
- Rescaled y² coefficient: F_r(x,y) = (f(rx,ry)−b)/r³ (line 339); its exact quadratic Taylor
  coefficient in y is (r²/2)f_yy(0)/r³ = f_yy(0)/(2r) = q/(2r) — an exact identity, not an
  approximation ✓. The candidate's warning (line 269) that q/(2r) is not a fixed-density
  coordinate is correctly reflected in the volume factor: the q-interval [−10r−2rδ, −10r+2rδ]
  has width 4rδ, not 2δ. ✓
- Inclusion for r ≤ 1: |q| ≤ 2r(5+δ) ≤ 2(5+1/1024) = 10.0020 < 11 and q ≤ 2r(δ−5) < 0 < 1, so the
  q-component lies in [−11,1]; the other three components are exactly the K_J intervals. ✓
- Volume: (4δr)(2δ)³ = 32δ⁴r ✓ (numeric cross-check at r = 0.025: 7.275957614e-13 ✓).

## Findings

1. **(Observation, non-blocking)** The uniform interval [0, r_G] is obtained by pure
   continuity/compactness and is non-explicit; no computable r_G, m, or K is produced. This is
   within the candidate's declared existential scope (§1 line 58: "It does not provide evaluated
   numerical constants") and is not a defect of the R2 interface. The certified endpoint
   λ_min(Γ_0) ≥ 0.1265 and rung values ≥ 0.1265 down to r = 0.025 (evidence) indicate the
   continuity radius is not pathologically small in practice.
2. **(Observation, non-blocking)** Candidate line 221's exactness sentence is correct only
   because it is restricted to the four x-axis coordinates; the y-coordinates converge with an
   O(r²) error driven by the x²y jet coefficient. The candidate states exactly this; my
   independent germ computation confirms the division of labor. No misstatement.
3. No correctness defects found in §1/§5/§6 within the R2 scope. Every displayed formula (V,
   det V = −1, T_r, det T_r = −r^{−5}, u_r, U_0, the volume 32δ⁴r, C = q/(2r)) was independently
   reproduced; every analytic argument (L² limit with covariance convergence, full-lattice
   spectral PD, continuity/Schur chain, Gaussian density lower bound) checks out.

## Remaining gaps / out-of-scope notes

- The Gaussian-moment input E‖f‖_{C^k}^p < ∞ (candidate §7) was sanity-checked as an argument but
  its conditional-in-J strengthening is interface R3's charge, not re-adjudicated here.
- Numerics are evidence with certified truncation tails and certified eigen residuals; they are
  not used as a proof ingredient — the proof chain verified above is purely analytic
  (continuity + compactness + the full-lattice spectral support argument).

## R2 DISPOSITION: **PASS WITHIN SCOPE**

Scope note: PASS covers §1, §5, §6 and the r = 0 endpoint/uniform-continuity inputs they supply
to §7–§10, at the pinned file hash above. It does not certify R1 (law/topology), R3 (conditional
C⁴ control), R4 (deterministic lift), R5 (normalizer powers), or R6 (scope/status), which are
other reviewers' interfaces.

**Blocking objection:** none.
