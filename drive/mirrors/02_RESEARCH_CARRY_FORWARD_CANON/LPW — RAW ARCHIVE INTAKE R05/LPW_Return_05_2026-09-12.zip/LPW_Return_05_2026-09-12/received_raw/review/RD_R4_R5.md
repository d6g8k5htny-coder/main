# RD — Independent review of LPW-CAND-20260912, interfaces R4 and R5

**Reviewer:** RD (KIMI independent review line, ordinary hostile review).
**Target:** `INBOX_Q0_Next_Phase/Q0_Next_Phase_2026-09-12/02_LOCAL_PATH_LOWER_BOUND_CANDIDATE.md`, v1.0, 2026-09-12.
**Target SHA-256:** `cf58f72eb0399c626160c143b50f674ff3bd5c449225211edd6fd378a374e1a5` (matches `MANIFEST.sha256`).
**Packet:** `03_INDEPENDENT_REVIEW_PACKET.md`, SHA-256 `b3b1371f4d0f0b4b7f2ccac61742b241ec549cb145765f60fc4ccf278a871536` (matches manifest).
**Reviewed scope:** candidate §4, §8, §9, §10 in full, plus §2–§3 and §6–§7 as inputs. R4 = deterministic lift; R5 = normalizer and final powers. R1/R2/R3/R6 are other reviewers' interfaces; where R4/R5 consume their inputs this is flagged, not re-disposed.

**Exposure/independence disclosure:** I read the complete candidate before deriving anything; this is an ordinary hostile review, not blind reconstruction, and I make no claim of independent discovery of the construction. All coefficients below were re-derived by hand from the pin equations before being encoded, and only then checked with my own script. I did not run the author's `verify_local_path.py` and did not reuse its code; my script is a separate lineage.

**Tools actually run:** my own script `REVIEW_LPW/rd_r4r5_verify.py` (SHA-256 `47fcd6c64631551164798dece2422b033543d56e8650da6a392ddb9ac5148b7d`), sympy 1.14.0, exact rational/symbolic arithmetic only; fail-closed `ck()` (raises on first failure), no bare asserts; 91 checks PASS. Normal and `-O` outputs byte-identical: SHA-256 `45f4d4718d917c1ead7a8a014d6c7e51c8be7f9758b492b64d654bb92731397d` for both `out_normal.json` and `out_opt.json`. Manual derivations (below) are the primary evidence; the script cross-checks them.

---

## R4 — DETERMINISTIC LIFT: **PASS WITHIN SCOPE**

### R4(i) — 1D pin Taylor identities under M₄ ≤ K: all six verified

Let h(t) = f(t,0), k(t) = f_y(t,0). Pins: h(±r/2) = b, b−r³/6; h′(±r/2) = 0; k(±r/2) = 0. Fourth-derivative inputs: |h⁗| = |f_xxxx| ≤ K and |k‴| = |f_xxxy| ≤ K (f_xxxy is a genuine 4th-order derivative, so k‴ is bounded by K **directly** — no Lipschitz/fifth-derivative step is needed; I checked this typing explicitly).

Taylor with integral remainder, expand about 0, remainder per endpoint |ρ(t)| ≤ K(r/2)³/6 = Kr³/48 (gradient order) and K(r/2)⁴/24 = Kr⁴/384 (value order; script recomputes both integrals exactly: r³/48, r⁴/384).

- **Difference of gradient equations** (odd part cancels h‴(0)): 0 = r·h″(0) + ρ(r/2) − ρ(−r/2), so |f_xx(0)| ≤ 2(Kr³/48)/r = **Kr²/24**. ✓ Same for k: |f_xy(0)| ≤ Kr³/24·(1/r)·... = **Kr²/24** via |k‴| ≤ K directly. ✓
- **Sum of gradient equations**: |2h′(0) + (r²/4)h‴(0)| ≤ Kr³/24, so |f_x(0)/r² + f_xxx(0)/8| ≤ **Kr/48**. ✓ Identically |f_y(0)/r² + f_xxy(0)/8| ≤ **Kr/48** (the candidate's constant, not merely a looser one). ✓
- **Value difference**: −r³/6 = r h′(0) + r³h‴(0)/24 + e_v, |e_v| ≤ 2·Kr⁴/384 = Kr⁴/192 ✓ (candidate's number). With h′(0) = −r²h‴(0)/8 + e_x, |e_x| ≤ Kr³/48 ✓: −r³/6 = −r³h‴(0)/12 + r e_x + e_v, so |f_xxx(0) − 2| ≤ 12(Kr⁴/48 + Kr⁴/192)/r³ = 12·(5Kr/192)·... = **5Kr/16**. ✓
- **Midpoint value** (average of value equations): |(f(0)−b)/r³ + 1/12| ≤ (Kr²/24)/(8r) + Kr/384 = Kr/192 + Kr/384 = **Kr/128**. ✓
- **First derivative**: |f_x(0)/r² + 1/4| ≤ Kr/48 + (5Kr/16)/8 = 8Kr/384 + 15Kr/384 = **23Kr/384**. ✓

Every coefficient matches the candidate. Cross-check: the exact quartic family h(t) = Σaᵢtⁱ with |h⁗| = K and imposed pins was solved symbolically; all five displayed bounds hold with explicit nonnegative slack, and the difference-based bound |f_xx(0)| ≤ Kr²/24 **saturates** (h″(0) = ±Kr²/24), confirming no constant can be improved by this method and none was overstated. (Sum-based quantities vanish on quartics — their extremizers are bang-bang h⁗ — which is why those checks assert slack ≥ 0, not equality.)

### R4(ii) — 2D C² remainder (9/2)Kr: verified

For |β| = 4, |∂^β F_r| = r^{|β|−3}|∂^β f| ≤ rK (exactly one net power of r — script verifies the chain-rule scaling entrywise on all bivariate monomials of order ≤ 3). The ℓ¹ Taylor majorant Σ_{|β|=m}|z^β|/β! = (|x|+|y|)^m/m! was verified symbolically for m = 2,3,4. On D = [−2,1/2]×[−1,1], |x|+|y| ≤ 3, so the |α|-derivative remainder ≤ Kr·3^{4−|α|}/(4−|α|)!: values 27/8 (|α|=0), 9/2 (|α|=1), 9/2 (|α|=2); max = **9/2**. ✓ D is convex and contains 0, so segment remainders apply; rD ⊂ (−12,12)² for r ≤ 1, one chart. ✓

### R4(iii) — total 2089Kr/384 < 8Kr: recomputed term by term

F_J matches the six pins exactly for all (A,B,C,D₃) (script), and matches F* at (2,0,−5,0) (script). T₃ − F_J is supported on {1, x, y, x², xy, x³} with discrepancies Kr/128, 23Kr/384, Kr/48, Kr/48 (= |f_xx|/(2r)), Kr/24 (= |f_xy|/r), 5Kr/96 (= |f_xxx−2|/6). Monomial C² norms on D recomputed exactly (critical-point + edge + corner enumeration): **1, 2, 1, 4, 2, 12** ✓. Sum: 3/384 + 46/384 + 8/384 + 32/384 + 32/384 + 240/384 + 1728/384 = **2089/384 ≈ 5.44 < 8**. ✓ Matches the candidate's ledger including its term list.

### R4(iv) — basis C² norms: verified exactly

‖(x²−1/4)y‖ = 4 (attained by |∂_xy| = |2x| at x=−2; value sup is 15/4 < 4), ‖xy²‖ = 4, ‖y²‖ = 2, ‖y³‖ = 6 — all by exact enumeration. ✓ E_r targets are C* = −5, A* = 2, B* = 0, D₃* = 0, so ‖F_J − F*‖ ≤ δ(4+4+2+6) = **16δ**. ✓

### R4(v) — final tolerance: verified

16/1024 + 8/256 = 1/64 + 2/64 = **3/64 < 1/16**. ✓ r₀ = min(r_G, 1, (256K)^{-1}) forces Kr ≤ 1/256; using the sharper 2089/384 instead of 8 only improves the margin (actual total ≤ 0.0369). Constants fixed before r varies. ✓

### R4(vi) — Hessian scaling and weight: verified

∂_ij F_r(z) = r^{-1} f_ij(rz), i.e. **H_f(rz) = r·H_{F_r}(z)** — verified entrywise. det of a 2×2 scales by r², the pair product by r⁴ (script: det(rA) = r²det A, pair = r⁴). Typing indicators are scale-invariant for r > 0. §4 interval arithmetic recomputed from ε = 1/16: det H_G(m) ≥ (15/16)(159/16) − (33/16)² = 2385/256 − 1089/256 = **81/16 = 5.0625 > 5**; det H_G(s) ≤ −(15/16)(159/16) − (31/16)² = −2385/256 − 961/256 = **−1673/128 ≈ −13.07 < −13**; product ≥ 135513/2048 ≈ 66.17 ≥ **65 = 5·13**. Hence W_r ≥ 65r⁴ on the event. ✓

### R4(vii) — strict typing: verified

H_G(m): first diagonal ≤ −1+ε = −15/16 < 0 with det > 0 ⇒ negative definite. H_G(s): first diagonal ≥ 1−ε = 15/16 > 0, second ≤ −10+ε < 0, det ≤ −1673/128 < 0 ⇒ saddle. Entrywise C² error ≤ 3/64 < ε covers m and s (both in D). ✓

Supporting §3/§4 facts independently re-verified: R(x) = (2x+1)²(12x²+8x−17)/240; R + 99/1280 = (4x+5)²(48x²−40x+1)/3840 with 48x²+40x+1 positive-coefficient for −x > 0 and interval min 33 > 0 at x = −1/2; R(−5/4) = −99/1280; R(−2) = 9/16; clearance 1/6 − 99/1280 − 1/16 = **103/3840 > 0**; endpoint floor 9/16 − 1/16 = **1/2 > 0**; path stays in D (y ∈ [0, 3/4]); min path −179/1280 > −1/6 (strict).

**R4 objection list:** none.

---

## R5 — NORMALIZER AND FINAL POWERS: **PASS WITHIN SCOPE**

### R5(i) — Z_r ≤ C_Z r²: independently derived; polarity correct

Under Q_r the endpoint gradients vanish a.s. Along the x-axis ∫f_xx = f_x(S_r) − f_x(M_r) = 0, so f_xx has zero mean on an interval of length r; max−min ≤ r·sup|f_xxx| ≤ rM_3; zero mean forces sup|f_xx| ≤ max−min ≤ rM_3 at **both** stations. (Script: worst-case mean-deviation integral ∫|t−u|du = r²/2 ≤ r², so the candidate's rM_3 is even conservative.) Same for f_xy via f_y. |f_yy| ≤ M_3. Hence per station |det H| ≤ rM_3·M_3 + (rM_3)² = M_3²r(1+r) ≤ **2rM_3²** for r ≤ 1 (deficit factors exactly as M_3²r(r−1) ≤ 0). Pair: W_r ≤ **4r²M_3⁴** (indicator ≤ 1). Then Z_r ≤ 4r² E_{Q_r}M_3⁴ ≤ **C_Z r², C_Z = 4B_3**. **Polarity confirmed:** the final quotient has Z_r in the denominator, so an *upper* bound on Z_r is exactly what a *lower* probability bound needs; no sign/polarity swap occurs. Uniformity: B_3 = sup_{0<r≤min(r_G,1)} E_{Q_r}M_3⁴ < ∞ rests on the six-pin specialization of §7's regression argument (bounded Γ_r^{-1}, bounded u_r, finite unconditional C³ moments via the Fourier majorant) — that input belongs to interfaces R2/R3 and is flagged as a cross-interface dependency, not re-disposed here; the R5 derivation from it is exact. All constants (B_3, C_Z) are r-independent. ✓

### R5(ii) — Z_r > 0 on (0, r₀]: logic verified, no circularity

Z_r ≥ E_{Q_r}[W_r·1_{G_r}] ≥ 65r⁴·16mδ⁴r = 1040mδ⁴r⁵ > 0, since on G_r the weight floor 65r⁴ > 0 holds (R4(vi)) and Q_r(G_r) > 0 (§6–§7 estimates made entirely under Q_r). Ordering: G_r is constructed and lower-bounded under Q_r **before** P_r = W_r dQ_r/Z_r is ever used; the positivity proof does not pass through P_r or q. No circular grounding. ✓

### R5(iii) — volume: verified

E_r in J = (q, A, B, D₃) coordinates: q/(2r) ∈ [−5−δ, −5+δ] gives q-width **4δr** (the unique r-width direction); A, B, D₃ each width 2δ. Volume = 4δr·(2δ)³ = **32δ⁴r** exactly. Containment E_r ⊂ K_J for r ≤ 1: 2(5+δ) = 10.002 ≤ 11 ✓. The J-map has constant Jacobian and m is defined as a lower bound for the J-density directly, so no Jacobian factor is lost. ✓

### R5(iv) — weighted numerator: verified

E_{Q_r}[W_r·1_{G_r}] ≥ 65r⁴·Q_r(G_r) ≥ 65r⁴·16mδ⁴r = **1040mδ⁴r⁵** (65·16 = 1040 ✓). The Markov-halving integration over the box (≥ (1/2)·m·vol = 16mδ⁴r) is arithmetically correct; the uniformity of the conditional tail is R3's interface. ✓

### R5(v) — quotient: verified

1040mδ⁴r⁵/(C_Zr²) = **(1040mδ⁴/C_Z)r³**; power ledger 1 + 4 − 2 = 3 ✓. c = 1040mδ⁴/C_Z = 260mδ⁴/B_3 with δ = 1/1024 (script simplifies to 65mr³/(68719476736·C_Z) identically). ✓

### R5(vi) — final composition: verified within R4/R5 scope

G_r ⊂ {D_f(M_r) ≠ S_r}: on G_r, ‖F_r − F*‖_{C²(D)} ≤ 3/64 < 1/16 (R4(v)), so §4 supplies the strict path witness (min −179/1280 > −1/6, endpoint ≥ 1/2 > 0) and §2's criterion converts it to D_f(M_r) ≠ S_r (the topological step itself is R1's interface). Then 1 − q = P_r{D≠S} ≥ P_r(G_r) = E_{Q_r}[W_r1_{G_r}]/Z_r ≥ cr³. **No adjacency conditioning enters anywhere**: Q_r is the bare six-pin regression law (§1 states this explicitly and nothing in §§6–10 adds a gradient-adjacency condition), W_r is the unmodified pair-determinant weight, and q is the unconditioned typed merge-tree probability. No third-point count, no Bonferroni subtraction. ✓

**R5 objection list:** none. One explicit dependency note (not an objection): finiteness of B_3 and positivity/uniformity of m are Gaussian-side inputs owned by R2/R3; R5's arithmetic from those inputs is exact and its polarity is correct.

---

## Dispositions (separate, at the exact pinned file version)

- **R4 — DETERMINISTIC LIFT: PASS WITHIN SCOPE.** All seven sub-items (i)–(vii) independently re-derived and machine-cross-checked; every coefficient (24, 48, 5/16, 128, 23/384, 9/2, 2089/384, 4/4/2/6, 3/64, r⁴, 81/16, −1673/128, 65) reproduced; no blocking or non-blocking objections.
- **R5 — NORMALIZER AND FINAL POWERS: PASS WITHIN SCOPE.** All six sub-items (i)–(vi) independently derived; polarity of the normalizer bound confirmed correct; positivity grounding non-circular; powers 1+4−2 = 3 and c = 1040mδ⁴/C_Z confirmed; no adjacency conditioning present. Cross-interface dependencies (B_3 < ∞, m > 0 uniformity, topological criterion) are correctly delegated to R1/R2/R3 and are not objections within R5.

**Blocking objections for anything not PASS WITHIN SCOPE:** none — both interfaces pass.

**Review/test gaps remaining (outside my interfaces):** R1 (law/topology), R2 (covariance limit), R3 (conditional C⁴ uniformity), R6 (scope/status) must report separately before any endorsement; my PASS covers only the deterministic analysis of §4/§8/§9/§10 at the pinned hash.

**Artifacts:** `REVIEW_LPW/rd_r4r5_verify.py` (SHA-256 `47fcd6c64631551164798dece2422b033543d56e8650da6a392ddb9ac5148b7d`), outputs `out_normal.json` = `out_opt.json` (SHA-256 `45f4d4718d917c1ead7a8a014d6c7e51c8be7f9758b492b64d654bb92731397d`, byte-identical across `python3` and `python3 -O`), 91/91 checks PASS, fail-closed.
