# RC_R3 — Independent review, interface R3: Conditional C4 norm control

**Reviewer:** RC (KIMI independent review, review agent RC)
**Date:** 2026-09-12
**Target:** `INBOX_Q0_Next_Phase/Q0_Next_Phase_2026-09-12/02_LOCAL_PATH_LOWER_BOUND_CANDIDATE.md`, v1.0
**Target SHA-256:** `cf58f72eb0399c626160c143b50f674ff3bd5c449225211edd6fd378a374e1a5` (matches MANIFEST.sha256 line 3)
**Review packet:** `03_INDEPENDENT_REVIEW_PACKET.md`, SHA-256 `b3b1371f4d0f0b4b7f2ccac61742b241ec549cb145765f60fc4ccf278a871536` (matches manifest)
**Reviewed scope:** §7 in full (uniform conditional remainder control), with §1 (law and regression-version convention), §5 (Hermite normalization), §6 (covariance nondegeneracy, density floor) read for context; §8–§10 consulted only where §7's outputs are consumed.
**Exposure/independence disclosure:** Ordinary hostile review. I read the complete candidate first; no blind reconstruction is claimed. All derivations below were redone independently; all numerics were computed from the spectral definition, not from author scripts. One review lineage; counts once.

**VERDICT: PASS WITHIN SCOPE** (no blocking objection; two non-blocking amendment requests A1, A2; verdict inherits R2's uniform-eigenvalue and density-floor obligations).

---

## 1. The claim under attack (§7)

With M₄(f) = max_{|α|=4} sup_{T²₂₄} |∂ᵅf|, V_r = (U_r, J) the ten-jet frame, Γ_r = Cov(V_r), the candidate asserts

    B₄ = sup_{0<r≤min(r_G,1), j∈K_J} E[M₄(f) | U_r = u_r, J = j] < ∞,

then K = max(1, 2B₄), pointwise Markov Q_r(M₄ ≤ K | J = j) ≥ 1/2 for every j ∈ K_J, and integration over the thin jet box gives Q_r(E_r ∩ {M₄ ≤ K}) ≥ ½Q_r(E_r) ≥ 16mδ⁴r.

## 2. Link-by-link findings

### Link 1 — regression representation and version (SOUND)

ρ_r = f − C_rΓ_r^{−1}V_r is jointly Gaussian with V_r and Cov(ρ_r(z), V_r) = C_r(z) − C_r(z)Γ_r^{−1}Γ_r = 0 identically, hence ρ_r ⊥ V_r; the residual law (centered Gaussian, covariance K − C_rΓ_r^{−1}C_rᵀ) carries no v-dependence. The disintegration v ↦ Law(ρ_r + C_rΓ_r^{−1}v) is a regular conditional distribution **defined for every v**, not merely a.e. — it is the standard Gaussian-regression disintegration, fixed once and for all. The mean map v ↦ m_{r,v} = C_rΓ_r^{−1}v is linear with C^∞ representers, hence continuous into C⁴; ρ_r has C⁴ (indeed C^∞) paths since f does (Gaussian spectral decay) and the subtracted term is smooth. So the "continuous Gaussian regression version" exists, is canonical, and makes every conditional probability below well-defined at the prescribed (probability-zero) pin/jet values. No further regularity is needed; the field's smoothness is available from the covariance. **No defect.**

### Link 2 — representer C⁴ bounds via covariance Cauchy–Schwarz (SOUND)

∂ᵅ_z C_{r,j}(z) = Cov(∂ᵅf(z), V_{r,j}) is legitimate: all derivative moments exist (spectral sums Σ w_k k^{2α} converge for every α since w_k ∝ e^{−|k|²/2}), so differentiation passes under the covariance. Cauchy–Schwarz then gives, for |α| ≤ 4,

    sup_z |∂ᵅC_{r,j}(z)| ≤ sup_z (Var ∂ᵅf(z))^{1/2} · (Var V_{r,j})^{1/2}.

First factor: the field is stationary on the flat torus (covariance depends on displacement mod 24), so Var ∂ᵅf(z) = Σ w̃_k k^{2α} is z-independent and finite. Second factor — the place an r→0 blow-up could hide, since T_r has entries up to 2/r³: I re-derived every row of the displayed T_r. Each row is a Hermite difference quotient in which the singular terms cancel exactly (row 6: (2/r³)[f(M)−f(S)] + (1/r²)[f_x(M)+f_x(S)] = f_xxx(0)/6 + O(r); rows 2, 4, 5 similarly → f_x, f_xx/2, f_xy). Hence U_r → U_0 in Gaussian L² as §5 claims, Var(V_{r,j}) is bounded on [0, r_G], and no r-dependent blow-up survives. The candidate's "no C⁴ convergence of the representers is required" is correct: pointwise-in-z Cauchy–Schwarz suffices. **No defect.** (Numerical corroboration: T_r applied to the pinned vector reproduces the claimed u_r to 5.5e-57.)

### Link 3 — moment bound for the residual (SOUND, one presentation gap → A1)

The unconditional bound E‖f‖_{C^k}^p < ∞ via Minkowski on Σ √a_n (1+|n|)^k |ξ_n| is correct: a_n ∝ e^{−π²|n|²/288}, so the L^p-sum converges for every finite p, k.

However, the natural phrasing "apply the same Fourier majorant to the residual, whose Schur-reduced covariance is still Gaussianly decaying" is **not literally valid**: ρ_r is *nonstationary* (conditioning on point evaluations breaks translation invariance), so it has no diagonal spectral representation to majorize. The argument that actually closes the step — and the one §7 in fact gestures at with "Taking C⁴ norms in the regression formula" — is the triangle inequality:

    M₄(ρ_r) ≤ M₄(f) + M₄(C_rΓ_r^{−1}V_r)
            ≤ M₄(f) + ‖Γ_r^{−1}‖ · |V_r|₂ · max_j ‖C_{r,j}‖_{C⁴},

a sum of (a) the unconditional C⁴ seminorm with all moments finite and (b) a product of uniformly bounded deterministic factors (Link 2, and ‖Γ_r^{−1}‖ bounded on [0, r_G] from §6) times a Gaussian vector norm with bounded moments. Hence E M₄(ρ_r) is uniformly bounded on (0, r_G]. The substance is present in the candidate, but the residual-side moment bound should be stated this way explicitly rather than by analogy with the stationary majorant. **Amendment request A1 (non-blocking, two-line clarification).**

### Link 4 — Markov step and every uniformity claim (SOUND)

M₄ is a seminorm (max of C⁰-seminorms), so for the fixed regression version,

    E[M₄(f) | V_r = v] = E M₄(ρ_r + m_{r,v}) ≤ E M₄(ρ_r) + M₄(m_{r,v}).

Uniformity over r ∈ (0, min(r_G,1)] and v = (u_r, j), j ∈ K_J:
(i) ‖Γ_r^{−1}‖ bounded on [0, r_G] — rests on §6's uniform positive eigenvalue lower bound (an R2 deliverable; numerically λ_min(Γ_r) = 0.12652 at r = 0.025, λ_max = 3.567);
(ii) v bounded — u_r = (b − r³/12, −r²/4, 0,0,0, 1/3) stays in a fixed compact for r ≤ 1, K_J is fixed compact;
(iii) E M₄(ρ_r) uniform — Link 3;
(iv) M₄(m_{r,v}) ≤ ‖Γ_r^{−1}‖·|v|·max_j‖C_{r,j}‖_{C⁴} uniform — Links 2, (i), (ii).
So B₄ < ∞. Markov then gives, **for the fixed everywhere-defined version**, Q_r(M₄ ≤ K | V_r = v) ≥ 1 − B₄/K ≥ 1/2 at *every* v in the range — the promotion from a.e.-v to every v is not achieved by continuity alone but by the fact that the version itself is the canonical regression disintegration; continuity of v ↦ Law(ρ_r + m_{r,v}) is an additional consistency guarantee. **No defect.**

### Link 5 — integration over the thin jet box (SOUND)

Under Q_r (the six-pin regression law) the pins make U_r deterministic (= u_r). The identification "Q_r given J = j" = "P given (U_r, J) = (u_r, j)" is the iterated disintegration of the jointly Gaussian triple (f, U_r, J); the intermediate law of J given U_r = u_r is Gaussian with the Schur-complement covariance, uniformly positive definite on [0, r_G] by §6, hence with density p_J(j) ≥ m > 0 on K_J (R2 deliverable). Then

    Q_r(E_r ∩ {M₄ ≤ K}) = ∫_{E_r-box} Q_r(M₄ ≤ K | J = j) p_J(j) dj
                        ≥ (1/2) ∫ p_J = (1/2) Q_r(E_r) ≥ 16mδ⁴r.

The disintegration identity itself is version-independent (integrations against the density p_J(j)dj are unaffected by a.e. redefinition), so even a hostile reader who distrusts the pointwise reading loses nothing. **No measure-theoretic gap found.**

### Link 6 — attempted breaks

- **(i) Version trap:** not triggered. The conditional probability used is the canonical regression version evaluated at prescribed values; Markov is applied pointwise to that version, and the integrated conclusion is version-insensitive anyway. No a.e.-defined object is misused at a prescribed value.
- **(ii) Hidden r-dependence of B₄:** all three channels checked — Γ_r^{−1} (uniform eigenvalue floor on [0, r_G], §6/R2), Var(V_{r,j}) (exact Hermite cancellation in every row of T_r, re-derived), E M₄(ρ_r) (triangle bound with uniform factors). Also u_r compact. No blow-up found. Note the sup defining B₄ runs only over (0, min(r_G,1)]; no bound is claimed or needed beyond r_G.
- **(iii) Subtraction-order error:** absent. The route is multiplicative — a pointwise-in-j Markov lower bound 1/2 integrated over the O(r) box — never a subtractive P(M₄ > K) ≤ 1/2 against O(r) mass. Polarity confirmed correct: the conditional bound holds *inside* the thin event, which is exactly what an O(r) jet-box mass requires.
- **(iv) Independence misuse:** none asserted or needed. The bound is uniform over j in the box, so arbitrary dependence between E_r (a J-event) and {M₄ ≤ K} is absorbed.

## 3. Non-blocking observations

- **A1 (amendment request, presentational):** §7 should state explicitly that the residual's C⁴-moment bound comes from the triangle inequality through the representers (residual is nonstationary; the stationary Fourier majorant does not apply to it directly). One or two lines; no mathematical content changes.
- **A2 (amendment request, trivial):** M₄ is defined in §7 as max over |α| = 4 (the review-prompt phrasing used |α| ≤ 4). §8 consumes only 4th-order remainders, so |α| = 4 suffices; the argument is identical either way. State the convention once.
- Γ_r invertibility for r > 0: §6's eigenvalue floor on [0, r_G] covers the interval used; nondegeneracy at each fixed r > 0 also follows from the same spectral argument as at r = 0 (functionals at distinct points involve linearly independent exponentials e^{ik·z_j} over the fully supported lattice). No gap, but §6's "by continuity" yields exactly a neighborhood [0, r_G] — which is all that is used.
- **Dependency:** this verdict presupposes R2's confirmations of (a) the uniform positive eigenvalue lower bound for Γ_r on [0, r_G] and (b) the density floor m > 0 on K_J. My numerics verify both at the single point r = 0.025 (evidence, not the uniform proof).

## 4. Numerical evidence — NOT PROOF

Script: `REVIEW_LPW/rc_r3_numeric.py` (SHA-256 `8e29544f1a96c87216f980c84334532b6d130dd7e5d13ef69371b75cf9601bfa`); output `REVIEW_LPW/rc_r3_numeric_output.txt` (SHA-256 `ba14804930a7ae7bcee64cdb90c0ada10f0961f2dd290ce88520c51a5b7c15ec`). Fail-closed (ck() → SystemExit(1), no bare asserts); `python3` and `python3 -O` outputs byte-identical (cmp clean, both exit 0). mpmath, 60 dps; exact periodized field, dual lattice (π/12)ℤ², masses ∝ e^{−|k|²/2}, Euclidean truncation |k| ≤ 30 (|n|² ≤ 13131); r = 0.025, j_c = (−10r, 2, 0, 0) = (−0.25, 2, 0, 0).

Self-checks inside the run: truncation corner mass 2.7e-194 (ball vs factorized square); ball/square normalizations agree to 6.6e-60 (60-dps accumulation noise); Var f(0) = 1 exactly; Var f_x factorized vs direct 2D-ball sum agree; T_r·(pins) reproduces the claimed u_r to 5.5e-57; all conditional variances positive; all conditional covariance matrices positive definite; ALL CHECKS PASSED.

Key displays:

1. **Γ_r at r = 0.025:** eigenvalues 0.12652, 0.12656, 0.32779, 0.40196, 0.40201, 0.85501, 0.99984, 1.63794, 1.63810, 3.56701 — positive definite, well conditioned; consistent with a uniform floor on [0, r_G].
2. **Conditional derivative vector** (mean, sd, exact E[(∂ᵅf(z))² | U_r = u_r, J = j_c]) at z₁ = (−r/4, 0), z₂ = r(−2, 3/4), z₃ = (0, r/2), z₄ = (12, 12): conditional means reproduce the imposed jet exactly where expected (f_xxy mean ≈ 4.000 = 2A; f_yy mean ≈ −0.2500 = −10r; f_xxx mean ≈ 2.02 near the prescribed 2); conditional sd's collapse near the pins (sd of f(z₁) = 2.8e-9) and at the antipode the conditional law is indistinguishable from the unconditional at ~1e-56 (sd's √1, √3, √15, √105 — the planar Gaussian spectral moments reproduced on the lattice). Confirms the regression conditioning is correctly implemented and is spatially local.
3. **Monte-Carlo-free moment estimate** for an M₄-like quantity at v = (u_r, j_c): 48×48 torus grid (h = 0.5), Gaussian union bound E sup_grid |∂ᵅf| ≤ max|μ| + σ_max √(2 ln 2G) plus a one-level order-5 mesh correction h·Σ(B at children), recursion explicitly truncated at one level (labeled lower-tier display):

       Σ_{|α|=4} (B_cond + mesh corr) = 526.5 ;  Σ_{|α|=4} B_uncond = 128.3.

   The conditional bound exceeds the unconditional one only through the deterministic mean shift of the imposed jet (max |μ| up to 15.9 for ∂^{(4,0)} near the pins); conditional sd's never exceed unconditional ones (Schur reduction), max σ = 10.247 = √105. Reading: at r = 0.025, j = j_c, E[M₄ | v] sits at an O(10²) scale with nothing singular in sight — consistent with B₄ < ∞ and K = max(1, 2B₄) finite. This says nothing about uniformity in r; it is evidence at one (r, j), offered as a falsifiable display, not as a component of the proof.

## 5. Tools actually run

- `sha256sum` on target and packet (both match MANIFEST.sha256).
- Full analytic re-derivation by hand: regression independence, Cauchy–Schwarz representer bounds, all six rows of T_r, Markov/disintegration chain (documented above).
- `python3 rc_r3_numeric.py` and `python3 -O rc_r3_numeric.py` (mpmath 1.3.0, Python 3.12.12): exit 0 both, byte-identical outputs.
- No author scripts were executed; no content from author executables was used.

## 6. Disposition

**R3: PASS WITHIN SCOPE.**

Blocking objection: **none.** The conditional C⁴ control is uniform in (r, j) as required, the Markov-then-integrate route is measure-theoretically clean at the prescribed pin/jet values, and none of the four designated break lines (version trap, hidden r-dependence, subtraction-order, independence misuse) survives contact with the text.

Non-blocking amendment requests: A1 (state the residual moment bound via the triangle inequality/representers, not via a residual-side Fourier majorant — the residual is nonstationary), A2 (state the M₄ index convention once). Dependencies handed to R2: uniform Γ_r eigenvalue floor on [0, r_G] and density floor m > 0 on K_J.
