# RA — Independent review of LPW-CAND-20260912, interfaces R1 (law and topology) and R6 (scope and status)

**Reviewer lineage:** RA (KIMI independent review), one lineage, counted once.
**Target (exact):** `/mnt/agents/output/K3_SIDE24_LB/INBOX_Q0_Next_Phase/Q0_Next_Phase_2026-09-12/02_LOCAL_PATH_LOWER_BOUND_CANDIDATE.md`, version 1.0, 2026-09-12.
SHA-256 at review time: `cf58f72eb0399c626160c143b50f674ff3bd5c449225211edd6fd378a374e1a5` — **byte-identical to the MANIFEST.sha256 pin** (verified by direct `sha256sum` against `MANIFEST.sha256` in the same directory).

**Exposure / independence disclosure (per packet protocol, "ordinary hostile review" branch):** I read the complete candidate (all 519 lines, §0–§13) **before** forming any judgment, and I also read the review packet `03_INDEPENDENT_REVIEW_PACKET.md`. This is therefore **not** a blind reconstruction and I do not claim independent discovery of the construction. It is an ordinary hostile review: I re-derived every load-bearing identity I rely on, attacked the stated interfaces adversarially, and pinned every reliance to exact quoted lines of the candidate. Cross-check records read: `W10_dependency/W10_REPORT.md` (§1 estimand firewall, §2.1–2.2), `SIDE24_pre_peer_review_v2/manuscript_v2_2026-09-13.md` (Preliminary 2.3/2.5, Definitions 2.6–2.8, Definition 3.10, Theorem 3.11, Proposition 3.20, Lemma 3.5), `INBOX 00_READ_FIRST.md`, `KIMI_EXPORT_2026-08-03/KIMI-AUD-012.md` (GP-DER-118 absence record).

**Executable checks actually run (fail-closed discipline):** a SymPy script, every acceptance gate `ck()` raising `SystemExit` on failure, no bare asserts. 12 checks, all PASS (transcript reproduced inline below). Scope note: checks 1–4 pin the pin-law identification I rely on for R1; checks 5–12 pin only the strict inequalities and exact identities that R1(b)'s topology consumes. The full §5/§6 covariance limit, §7 conditional C4 bound, §8 Taylor lift, and §9 normalizer are interfaces R2–R5 (other review lines); I deliberately do not certify them here.

---

## R1 — LAW AND TOPOLOGY

### R1(a) — Identification of the candidate's q against the estimand of record

**Estimand of record (visible, local).** W10 §1 (the designated firewall) states, verbatim:

> "The **typed pair-Palm law** P⁰_r is the regular conditional law given the corrected pin basis (manuscript (2.7)) at the pair (M, S), M = (−r/2, 0), S = (r/2, 0), values f(M) = b, f(S) = b − ℓ, ∇f = 0 at both, with RN weight W_r = |det H_M det H_S|·1_typed and normalizer Z_r ≍ r²" (W10_REPORT.md line 24)

> "| p_r | P⁰_r{ D(M) = S } | merge-tree pairing probability of the typed pair |" (line 30)

> "**Identification for this campaign:** the theorem target's q(r, 6/5) **is p_r** (the typed merge-tree pairing probability)." (line 40)

Manuscript Preliminary 2.5 (line 110–115): the typed pair-Palm law is "the regular conditional law of f given the jets (2.7) pinned at prescribed values … exact Radon–Nikodym weight dP⁰/dP = W_r/Z_r, W_r = |det H_M det H_S| 1_type, Z_r ≍ r²". Manuscript (3.3) pins "f(M) = b, f(S) = b − ℓ" with ℓ = r³/6 (line 81: "ℓ = r³/6 the *window width*").

**Candidate's objects (quoted).**

- Line 32–36: "Let Q_r be the **continuous Gaussian regression version** of the conditional law with pins \(f(M_r)=b,\ f(S_r)=b-r^3/6,\ \nabla f(M_r)=\nabla f(S_r)=0\)."
- Lines 42–46: "\(W_r=|\det H_f(M_r)\det H_f(S_r)|\mathbf 1\{H_f(M_r)\prec0,\ \det H_f(S_r)<0\},\ Z_r=\mathbb E_{Q_r}W_r\)" and "define P_r by dP_r=W_r dQ_r/Z_r."
- Line 48: "These are the same six-pin and determinant-weight conventions used in GP-DER-118-v1.10, Section 0, and the typed merge-tree interpretation specified by W10, Section 1. There is **no additional conditioning on gradient adjacency**."
- Line 50: "Let q(r,b)=P_r{D_f(M_r)=S_r}, where D_f is the superlevel elder-rule death partner under the program's usual well-defined persistence interpretation."

**Point-by-point comparison.**

1. **Stations and pin values — exact match.** M_r = (−r/2, 0), S_r = (r/2, 0) (candidate line 32; W10 line 24; manuscript line 81). Pin values f(M) = b, f(S) = b − r³/6 with b = 6/5 and ℓ = r³/6: candidate pins the saddle **exactly** at b − r³/6, i.e. exactly at the firewall's "f(S) = b − ℓ". No window-averaged or integrated-over-heights law is used.

2. **Window vs exact pin value (the designated trap) — resolved, no hidden difference.** Manuscript Definition 2.8 (line 123) reads: "Under the typed pair-Palm law at level b with the saddle's height in the *window* [b−ℓ, b] …". Read literally and in isolation, that phrase could describe a law conditioned on the *event* f(S) ∈ [b−ℓ, b] (a positive-probability mixture over saddle heights), which would be a **different** estimand from the candidate's exact pin. Three records of the program itself fix the exact-pin reading: (i) the W10 §1 firewall, which the packet designates as the estimand of record, states "values f(M) = b, f(S) = b − ℓ" and "the theorem target's q(r, 6/5) **is p_r**"; (ii) manuscript Definition 3.10/(3.3) pins "f(S) = b − ℓ" exactly; (iii) Preliminary 2.5 says the jets are "pinned at prescribed values" (exact Kronecker conditioning, Preliminary 2.3: "All conditionings in this manuscript are exact instances of (2.4)"). Conclusion: Def 2.8's "window" is loose documentation phrasing (it names which saddle heights the *family* of pair-Palm laws considers); the estimand of record is the exact-pin p_r, and the candidate's q is defined at exactly that pin. **No amendment required of the candidate;** the ambiguity is in the manuscript's prose, already adjudicated by the firewall.

3. **Basis of the pin span — identical σ-algebra, verified symbolically.** Manuscript (2.7) uses the "corrected pin basis"
   V_r = ( f(M), ∇f(M), (∇f(S)−∇f(M))/r, (f(S)−f(M)−(r/2)(∂₁f(S)+∂₁f(M)))/r³ );
   the candidate uses the raw basis P6_r = (f(M_r), f_x(M_r), f_y(M_r), f(S_r), f_x(S_r), f_y(S_r)) (line 183) and then its own invertible Hermite normalization U_r = T_r P6_r (lines 191–206). Gaussian conditioning at prescribed values depends only on the **span** of the conditioning functionals (the regression formula (2.4) is equivariant under invertible linear reparametrization of P). Fail-closed check: the change-of-basis matrix from P6_r to the manuscript's V_r has determinant exactly r⁻⁵ ≠ 0 for all r > 0 (PASS), and evaluated at the candidate's pinned values it yields the manuscript-side prescribed values (b, 0, 0, 0, 0, −1/6), i.e. f(S) − f(M) = −r³/6 exactly (PASS). So the two bases define the same conditional law at the same prescribed point. The manuscript's trapezoidal correction is "load-bearing" (Preliminary 2.5) only for its *blow-up asymptotics* (Theorem 3.11(ii): it "removes the bias that the naive basis carries" in the limit covariance); it does not change the law at any fixed r > 0. The candidate performs its own blow-up with its own T_r, so no inconsistency arises. Fail-closed checks on the candidate's displayed T_r (lines 199–204): det T_r = −r⁻⁵ exactly, hence invertible for every r > 0, so "The transformed pin vector U_r=T_r P6_r therefore defines the same Gaussian conditioning, not another law" (line 206) is correct; T_r·(b,0,0,b−r³/6,0,0)ᵀ = (b−r³/12, −r²/4, 0, 0, 0, 1/3)ᵀ exactly as claimed (line 212), hence u_r stays in a compact set as r → 0 (line 223). (Convention pinned: displayed T_r = D_r⁻¹(Vᵀ)⁻¹R_r with V the (value, ∂ₓ, ∂ᵧ)-at-{m,s} evaluation matrix on basis (1, x, y, x², xy, x³), det V = −1 as claimed at line 189.)

4. **Radon–Nikodym weight and type indicators — exact match.** Program: W_r = |det H_M det H_S|·1_type with type = {M a nondegenerate maximum, S a nondegenerate index-1 saddle} (Preliminary 2.5: "a maximum at M and a saddle at S at prescribed heights"; W10 line 66 confirms the saddle convention "typed saddle (det H_Y < 0)"). In dimension two, nondegenerate maximum ⟺ H ≺ 0 and index-1 saddle ⟺ det H < 0; the candidate's indicator 1{H_f(M_r) ≺ 0, det H_f(S_r) < 0} is exactly this. The boundary (degenerate Hessian) is a measure-zero set under the Gaussian conditional law, so the open strict inequalities coincide a.s. with any closed typing convention. The weight structure dP_r = W_r dQ_r/Z_r with Z_r = E_{Q_r} W_r is exactly Preliminary 2.5's "dP⁰/dP = W_r/Z_r" (the pin-density factor from Kac–Rice is a constant at the prescribed values and is absorbed in Z_r). Candidate's Z_r ≍ r² usage (upper bound C_Z r² plus positivity, lines 452–455) is consistent with the program's certified Z_r ≍ r² (Theorem 3.11(i)).

5. **No adjacency conditioning — exact match.** The program's p_r carries no adjacency conditioning; the adjacency event enters only through the partition p_r = a_r q_r^adj + η_r (W10 lines 33–38), with "no η_r loss incurred anywhere in the lower-bound chain" (W10 line 42(i)). Candidate line 48: "no additional conditioning on gradient adjacency"; line 488 (η_r bullet): "the event directly implies failure of typed elder pairing … this proof neither estimates nor sets η_r to zero." Consistent with the firewall.

6. **The D_f interpretation — exact match, with one documentation note.** W10 line 26: "write D(M) for the elder-rule death partner of the maximum M (superlevel merge tree)". Candidate line 50: "D_f is the superlevel elder-rule death partner". Same object. (Documentation note, not a candidate defect: manuscript Definition 2.7 says "sublevel-set component born at height β (a maximum…)", which is terminologically inverted — sublevel components are born at minima; the pairing of maxima with saddles is the superlevel filtration. W10 §1 and the candidate both correctly say "superlevel".) The candidate additionally offers the convention-free fallback (line 50): "one may formulate the conclusion directly as a lower bound for the path-defined preemption event, avoiding dependence on any tie-breaking convention." That fallback is legitimate because the constructed clearance is strict (see R1(b)).

7. **Conditioning version — consistent with the program's convention.** Candidate line 32 uses "the continuous Gaussian regression version" and line 38 explains why ("these pins are probability-zero events, so an arbitrary almost-everywhere version of a conditional probability is not a suitable definition at a prescribed pin value"); line 319 repeats the discipline for the J-conditioning ("Use this continuous Gaussian regression version for every j, not an arbitrarily redefined conditional version"). This matches the program's Kronecker-exact conditioning (Preliminary 2.3, "exact instances of (2.4)") and the firewall's "regular conditional law". The well-posedness of the limiting covariance argument is R2's interface; the *version choice* asserted here is the correct one and matches.

8. **GP-DER-118-v1.10 cross-check — CANNOT-VERIFY-locally (scoped residue, named missing object).** The candidate's line 48 and §13 (line 511) assert its conventions equal those of "GP-DER-118-v1.10, Drive ID 1qc6ep2S4PIoPMEWDsdDQI1dr0LOwJiK9, Section 0. Whole-file SHA-256 c1d6e559274d7e87a3fa92f44cb2534a5e277a3b5941fd40db380599ddba0564; frozen body 9b7901e112a4857e3ea59942858684f72fc09a2825b1efa859360dd8fa55f014." That file's **body is absent from the local corpus**: exhaustive search (`grep -rln "GP-DER-118"` over /mnt/agents/output) finds only references, and KIMI-AUD-012 records explicitly: "the v1.10 BODY itself remains ABSENT - REQUEST UPLOAD stands for it". The INBOX 00_READ_FIRST.md states the Drive-side raw source was re-hashed and matches ("GP-DER-118-v1.10's 30,933-byte whole-file identity and 29,293-byte frozen-body identity both match the recorded hashes"), but the content is not locally inspectable. **Exact missing object named:** GP-DER-118-v1.10 body (Drive ID above; whole-file sha256 c1d6e559…; frozen body 9b7901e1…). This residue is non-blocking for R1 because the estimand *of record* for this review (W10 §1 + manuscript Preliminary 2.5 / Definition 2.8) is local and the match against it is exact on every coordinate (items 1–7). If the GP-DER-118 Section 0 conventions were ever found to differ from W10 §1, the candidate's line-48 assertion — not its mathematics — would need amendment.

**R1(a) conclusion:** the candidate's q(r, 6/5) **is** the program's typed pair-Palm merge-tree probability p_r: same six pins at the same stations with the same prescribed values (exact pin f(S) = b − r³/6, not a window mixture), same pin span (basis-independent σ-algebra, det r⁻⁵ ≠ 0 verified), same determinant weight and type indicators (H_M ≺ 0, det H_S < 0), same RN structure W_r dQ_r/Z_r, no adjacency conditioning, same superlevel elder-rule D_f. No hidden difference found against any locally inspectable record. Sole residue: the GP-DER-118 Section 0 equality asserted at line 48 is CANNOT-VERIFY-locally (missing object named above).

### R1(b) — The topological implication: proof, adversarial attacks, and assumption audit

**Claim under attack (candidate §2, lines 62–70):** "Let a continuous function on the torus have a strict local maximum M of height b and a candidate saddle S of height s<b. Suppose a continuous path gamma starts at M, ends at a point z with f(z)>b, and satisfies min_t f(γ(t))>s. Choose a level h strictly between s and that minimum. M and z are in the same superlevel component at h. That component contains a point above b, and hence an older birth than the maximum M under the superlevel elder rule. Thus M's component has already lost its separate surviving identity by level h; it cannot first die at S at level s." Conclusion: D_f(M) ≠ S.

**Independent proof (reconstructed, then formalized).** Read the argument within the program's persistence-admissible class (assumptions audited below). Consider the superlevel filtration X_h = {f ≥ h}, h decreasing. (i) Since min f(γ) > s strictly, an h with s < h < min f(γ) exists; γ ⊂ X_h, so M and z lie in one connected component C_h of X_h. (ii) The birth level of C_h is β(C_h) = sup{f(w) : w ∈ C_h} ≥ f(z) > b = f(M) = β_M, the birth level of M's own component. (iii) In the elder rule, when two superlevel components merge, the component with the strictly older (higher) birth survives and the younger dies, paired with the merge saddle. Let h* = sup{h' : M and z lie in the same component of X_{h'}} — the merge level of M's natal component with the component carrying z. By (i), h* ≥ h > s. At level h*, M's natal component (birth b) merges with a component of birth > b; being strictly younger, it **dies** at h*. (iv) Hence the elder-rule death partner D_f(M) is a critical point at level h* ≥ h > s = f(S), so D_f(M) ≠ S — regardless of what that partner is, and regardless of tie-breaking conventions at any level, because h* is **strictly** above s. ∎

The strictness of both hypotheses (f(z) > b and min f(γ) > s) is exactly what makes the conclusion convention-free: the death level is bounded away from s by the margin min f(γ) − s > 0. The candidate's construction supplies this strictness with exact rational margins, which I re-verified fail-closed: the witness path height satisfies R(x) + 99/1280 = (4x+5)²(48x²−40x+1)/3840 identically (PASS), the quadratic factor is positive on the whole interval [−2, −1/2] (values 273 and 33 at the endpoints, vertex at x = 5/12 outside the interval; PASS), so min R = −99/1280 > −1/6 with margin 103/3840 > 0 (PASS); the endpoint R(−2) = 9/16 > 0 (PASS); and the margins survive the ε = 1/16 C²-robustness: 1/6 − 99/1280 − 1/16 = 103/3840 > 0 (PASS), endpoint ≥ 1/2 > 0 (PASS). On the event G_r the physical path rγ_* therefore has f > b + r³/2 at its endpoint and min f ≥ b − (179/1280)r³ > b − r³/6 = f(S_r): the implication's hypotheses hold with a uniform positive clearance. (The C²-robustness and Taylor-lift steps that place G_r inside the ε-tube are R4's interface; I verified only the arithmetic endpoints I consume.)

**Adversarial attacks requested by the packet/lead — all four fail:**

1. **"M dies earlier at another saddle."** Not a counterexample: the claim is only D_f(M) ≠ S, and the candidate says so explicitly (line 70: "The conclusion is D_f(M) != S, **not** identification of a particular third saddle as the death partner. M might have died even earlier."). My proof in fact *forces* the death partner to be at level ≥ h > s, which subsumes this case.

2. **"The component containing z was born above b."** That is the mechanism, not an escape: any component of X_h containing z has birth ≥ f(z) > b, so M's natal component is strictly younger at the merge and dies. For M to survive to level s, the component containing M at level h would need birth ≤ b — contradicting z ∈ C_h with f(z) > b. No valid elder-rule interpretation (older birth survives) can keep M's natal component alive past h*.

3. **"The empty-component birth convention."** Manuscript Def 2.7: "The elder rule is negative-safe (birth of the empty component is sup ∅ = −∞)". Could z's component be "empty-born" (−∞) and hence *younger* than M, letting M survive the merge and die later at S? No: C_h contains z with f(z) > b, so tracing C_h upward it contains points at every level up to at least f(z); its birth is ≥ f(z) > b, not −∞. On a compact torus with a Morse (or tame) realization every superlevel component traces back to an actual maximum; the −∞ convention only governs components with no ancestral maximum, which cannot contain a point of height > b at level h < b. No rescue.

4. **"Ties."** (a) Birth tie: would need the merging older component born exactly at b, i.e. f(z) = b — excluded by the strict hypothesis f(z) > b. (b) Merge-level tie with S: would need h* = s — excluded since h* ≥ h > s. (c) Simultaneous merges of several components at one level (a non-distinct critical value): the death level of M's component is still ≥ h > s under *every* tie-resolution, because the connectivity statement at level h is tie-independent. The program additionally has distinct critical values a.s. (W10 line 24, "Bulinskaya package; full spectral support"), removing even the appearance of (c) under the law. No tie-breaking convention can produce D_f(M) = S.

**Assumption audit — what the implication actually needs, and whether the estimand already includes it.**

- **(T1) Well-defined superlevel merge tree / elder-rule pairing for the realization.** Sufficient: f Morse (all critical points nondegenerate), with distinct critical values for unambiguous pairing. *Already in the estimand:* W10 line 24 — "A.s. Morse with distinct critical values (Bulinskaya package; full spectral support)"; manuscript Proposition 3.3 (Bulinskaya regularity). The Gaussian field under Q_r (hence under P_r ⋐ Q_r) inherits this a.s.
- **(T2) Measurability of {D_f(M) = S}.** *Already in the estimand:* manuscript Proposition 3.20 ("measurability and exact Palm disintegration, certified at the FOUNDATION grade"); W10 line 42(iv) confirms theorem-grade measurability for the persistence mark.
- **(T3) NOT needed: Morse–Smale, gradient trajectories, ω-limits, saddle–saddle-connection exclusion.** The proof above uses only connectivity of superlevel sets and the elder rule; no flow line appears. This matches the candidate (line 72: "This criterion is pathwise. It needs neither gradient trajectories nor a Morse–Smale hypothesis.") and matters programmatically: the program's a.s.-Morse–Smale input (SARD-G) is graded "specialist-reviewed-conditional" (W10 line 24), and it is consumed only by *separatrix/ω-limit readings* (Lemma 3.5 exhaustion) of the merge tree — readings this route never takes. The merge-tree estimand p_r itself is defined on the a.s.-Morse set without Morse–Smale. The candidate's line 490 is therefore accurate: "No Morse–Smale connection theorem is used … no separate global genericity theorem is silently marked closed."
- **Scope honesty on "continuous function":** as literally stated (line 62, "Let a continuous function…"), the criterion's conclusion D_f(M) ≠ S presupposes D_f is defined; for pathological continuous f (infinitely many nesting components) the merge tree need not exist. The candidate itself restricts the interpretation (line 50: "under the program's usual well-defined persistence interpretation"), so read as a statement about the program's a.s. persistence-admissible realizations it is sound. This is a phrasing scope note, not a defect: on G_r every realization is C∞ with nondegenerate pinned critical points, and the a.s. Morse package covers the law.

**R1(b) conclusion:** the implication is **proved**, tie-free, and strictly stronger than needed (death level ≥ h > s). Every requested escape route (earlier death, older-born z-component, empty-birth convention, ties) fails. The required hypotheses (T1)–(T2) are exactly the program's own estimand definitional package; the candidate adds no Morse–Smale or trajectory assumption, and the program's estimand does not carry one for the merge-tree reading.

**R1 DISPOSITION: PASS WITHIN SCOPE.**
Scope boundaries of the PASS: (i) the identification is verified against the locally inspectable estimand of record (W10 §1 firewall; manuscript Preliminary 2.3/2.5, Definitions 2.6–2.8, 3.10); (ii) the single CANNOT-VERIFY-locally residue is the equality with GP-DER-118-v1.10 Section 0 asserted at candidate line 48 — missing object named in R1(a).8 (Drive ID 1qc6ep2S4PIoPMEWDsdDQI1dr0LOwJiK9; whole-file sha256 c1d6e559274d7e87a3fa92f44cb2534a5e277a3b5941fd40db380599ddba0564; frozen body 9b7901e112a4857e3ea59942858684f72fc09a2825b1efa859360dd8fa55f014) — non-blocking because the firewall document of record is local and matches exactly; (iii) the topology PASS covers the implication G_r ⊆ {D_f(M_r) ≠ S_r} given the event's strict clearances; the analytic placement of G_r inside the ε-tube and its positive P_r-measure are interfaces R2–R5.
**Blocking objection: none.**

---

## R6 — SCOPE AND STATUS

Method: full-corpus greps of the candidate (planar/sampled/measured/certificate patterns; kernel usage; constant definitions) plus line-by-line audit of the constant ledger and boundary statements. Quote-pinned findings per item.

### (i) Every constant fixed independently of r on (0, r₀] — VERIFIED (quantifier structure)

Complete inventory of the constants and where each is fixed:

| constant | value / definition | fixing point (quoted) | r-dependence |
|---|---|---|---|
| δ | 1/1024 | line 240: "Fix delta=1/1024." | none |
| K_J | [−11,1]×[2−δ,2+δ]×[−δ,δ]² | lines 242–244 | none (δ fixed) |
| m | uniform lower bound of the conditional J-density on K_J over 0 ≤ r ≤ min(r_G,1) | lines 240–246: "has a positive lower bound m on the fixed compact box … for 0<=r<=min(r_G,1)" | none — one number from continuity on a compact parameter set |
| r_G | continuity radius of Cov(U_r, J) at r = 0 | line 238: "a uniform positive eigenvalue lower bound on some [0,r_G]" | none |
| B_4 | sup over 0<r≤min(r_G,1), j∈K_J of E[M_4(f) | U_r=u_r, J=j] | lines 314–317 | none — a supremum over the whole interval |
| K | max(1, 2B_4) | line 319 | none |
| B_3 | sup over 0<r≤min(r_G,1) of E_{Q_r} M_3⁴ | line 451 | none |
| C_Z | 4B_3 | line 452 | none |
| r₀ | min{r_G, 1, (256K)⁻¹} | line 403 | none |
| c | 1040 m δ⁴ / C_Z | line 470 | none |
| B_3/B_4-class bounds | exact rationals (65, 81/16, 1673/128, 2089/384, 103/3840) | §§3–4, 8 | none |

The quantifier order is correct: every constant is either an explicit number, a continuity radius at r = 0, or a supremum over the entire interval (0, min(r_G,1)] — none is chosen per-r, and line 470 states the order explicitly: "All constants were fixed before r was allowed to vary on (0,r0]." The *analytic content* behind m > 0, B_3 < ∞, B_4 < ∞ (the uniform conditional density floor and the conditional C⁴ moment) is the burden of interfaces R2/R3 and is **not** certified here; R6 verifies only that the claims are structurally r-uniform, which they are. No circularity: m and K enter only through Q_r(E_r ∩ {M_4 ≤ K}) ≥ 16mδ⁴r (line 328) and the final c; r₀ depends on K and r_G only; c on m, δ, C_Z only.

### (ii) No sampled finite-difference modulus used as a proof input — VERIFIED

Affirmative checks: line 177: "These are interval-safe entrywise bounds, not eigenvalues inferred from a numerical sample." Line 246: "No sampled finite-difference or H-B3 assumption is involved." Line 478 (Λ/H-B3 bullet): "no spatial third-point intensity is integrated. The rare-jet event has an ordinary four-dimensional Gaussian density under the six-pin law." Negative checks: a full-candidate grep for sampled/measured/certificate patterns (`sampled`, `finite-difference`, `measured`, `0.946`, `0.9144`, `0.9001`, `certificate`, `[C-…]`) finds only the disclaimer at line 20 ("not the advertised 0.9144-class constant") and the boundary items quoted above; the candidate cites **no** machine certificate, **no** measured constant, and **no** rung table anywhere. Every numeric input is an exact rational derived in the text (the 103/3840 clearance, 81/16 and 1673/128 Hessian bounds, 2089/384 lift bound), and the two I consumed for R1(b) re-verified fail-closed (see R1(b)).

### (iii) No exact planar moment substituted for a periodized moment — VERIFIED (§1, §5, §6 audited)

- §1, lines 24–30: the covariance is the exact periodized kernel "K_{24}(z)= [Σ_{n∈Z²} exp(−|z+24n|²/2)] / [Σ_{n∈Z²} exp(−|24n|²/2)]" with the explicit declaration "No planar-kernel substitution or assertion of exact planar Gaussian spectral moments is used." The spectral description is the dual lattice: "every dual-lattice frequency k in (pi/12) Z^2 has a strictly positive weight proportional to exp(−|k|²/2)."
- §5 (Hermite normalization): pure polynomial algebra — the basis (1, x, y, x², xy, x³), V, D_r, R_r, T_r. No kernel value, planar or periodized, enters; the only covariance fact used is the (qualitative) L²-convergence of U_r to U_0 (lines 215–221), a property of the periodized field's smoothness.
- §6 (jet rank): lines 234–236: "That jet has positive-definite covariance for the exact periodized field. Indeed, the variance of a nonzero linear combination of its derivatives is a positive weighted lattice sum of |P(ik)|² … A nonzero polynomial cannot vanish on all of Z² … Every spectral weight is positive." This argument uses **only** full support of the periodized spectral measure on (π/12)Z² (the polynomial vanishing argument descends to Z² by scaling); it never evaluates or substitutes a planar moment. The density-floor argument (lines 240–246) is a continuity/compactness statement about the periodized field's Gaussian regression parameters.
- §7 (moments): lines 281–293 use the periodized Fourier coefficients on Z² with Gaussian decay ("a_n decays Gaussianly") — again lattice-side, no planar substitution.
- Cross-check: the manuscript's one explicitly planar theorem (Theorem 3.13, "planar collar determinant … 3D-separated planar kernel") is nowhere cited or re-used by the candidate. Grep for `planar` over the candidate returns only the two disclaimers (lines 30, 500) and the §12 review target naming the correct object ("positive spectral support for the exact normalized periodic field, not a finite truncation or a PDE-constrained monochromatic model", line 500).

### (iv) No old theorem/status silently promoted — VERIFIED

- Line 5 (disposition): "COMPLETE AUTHOR-SIDE ANALYTIC CANDIDATE … NO PROGRAM PROMOTION. This is a new route, not a repaired or promoted K3-THM-001."
- Line 20: "The route does not claim any of the old WP, H-B3, exit, Bonferroni, or sharp-coefficient obligations have been proved. It does not consume them."
- §11 (lines 474–492) enumerates each old bottleneck (WP, Λ/H-B3, triple-Palm, Bonferroni, far-field floor, Γ-LOC/exit, η_r, SARD-G) and states for each why it is not a premise; line 492: "The old obligations remain open for the old quantitative/limiting-coefficient route."
- Line 490 (SARD-G): "Compatibility with the precise canonical persistence interpretation is still an explicit review item; no separate global genericity theorem is silently marked closed." — consistent with my R1(b) finding that the route needs no Morse–Smale input and does not consume the conditional SARD-G grade.
- §13, line 513: GP-LB-STAT-004 "remains unchanged"; line 515: "The present route does not adopt W10's representative-height integrand as an exact integral or its numerical grades."
- Line 519 (final disposition): "The program's accepted lower-theorem status stays OPEN until independent mathematical review and the applicable control action." Also packet-consistent: line 507 requires reviewers to "preserve the failed candidate and issue a numbered correction" and forbids using "the exact-algebra PASS as a substitute for these checks."
No promotion, no back-door closure of LS-CTL/RP/q0 status anywhere in the candidate.

### (v) Conclusion targets only existential c, r₀ — VERIFIED

- Theorem statement, lines 52–58: "**Candidate theorem LPW.** There exist c>0 and r0>0 such that 1−q(r,6/5) ≥ c r³ (0<r≤r0). … It does **not** provide evaluated numerical constants. Its scope is fixed b=6/5, fixed side 24, dimension two, and the exact typed pair-Palm law above."
- Line 472: "It does not identify a limiting coefficient, an optimal lower bound, a useful numerical radius, or a two-sided law. It does not transfer the result to dimension three or to an adjacent-conditioned pairing probability."
- η_r firewall retained, line 488: "Any later adjacent-law restatement must still carry the exact eta_r identity; this proof neither estimates nor sets eta_r to zero."
- No liminf coefficient, no numerical constant, no lifetime-density (ν₂₄) claim, no dimension-3 statement, no adjacency variant appears anywhere in the conclusion chain (§10 composition ends at the existential c = 1040mδ⁴/C_Z, line 470).

**R6 DISPOSITION: PASS WITHIN SCOPE.**
Scope boundary of the PASS: items (i)–(iii) are verified at the level of quantifier structure, input provenance, and kernel identity; the *finiteness and positivity* of the r-uniform constants m, B_3, B_4 (the analytic heart of §6–§7) is the burden of interfaces R2/R3 and is explicitly not certified by this review. Items (iv)–(v) are verified completely.
**Blocking objection: none.**

---

## Fail-closed executable transcript (SymPy; ck() → SystemExit on any failure; no bare asserts)

1. PASS — manuscript (2.7)-to-P6 change-of-basis det = r⁻⁵ ≠ 0 for all r > 0 → identical pin σ-algebra (same conditional law).
2. PASS — manuscript-basis prescribed values at the candidate's pins = (b, 0, 0, 0, 0, −1/6) ⟺ f(S) = b − r³/6 exact pin.
3. PASS — candidate V (basis-evaluation matrix, line 189) det = −1 exactly.
4. PASS — displayed T_r (lines 199–204): det = −r⁻⁵ (invertible ∀ r > 0; same conditioning); T_r·(b,0,0,b−r³/6,0,0)ᵀ = (b−r³/12, −r²/4, 0, 0, 0, 1/3)ᵀ exactly (line 212); displayed T_r ≡ D_r⁻¹(Vᵀ)⁻¹R_r (convention pinned).
5. PASS — R(x) = F_*(γ_*(x)) equals the claimed factored form (2x+1)²(12x²+8x−17)/240 (line 110).
6. PASS — R(x) + 99/1280 = (4x+5)²(48x²−40x+1)/3840 identically (lines 115–118).
7. PASS — 48x²−40x+1 > 0 on [−2, −1/2] (endpoint values 273, 33; vertex at 5/12 outside) → min R = −99/1280 with equality only at x = −5/4.
8. PASS — strict clearance −99/1280 > −1/6 (margin 103/3840 > 0): tie-exclusion at the saddle level.
9. PASS — R(−2) = 9/16 > 0: physical endpoint f > b strictly.
10. PASS — robust clearance 1/6 − 99/1280 − 1/16 = 103/3840 > 0 (line 153).
11. PASS — perturbed endpoint ≥ 9/16 − 1/16 = 1/2 > 0 (line 155).
12. PASS — ALL RA CHECKS PASSED (SystemExit would have fired on any failure).

## Summary of dispositions

| interface | disposition | blocking objection |
|---|---|---|
| **R1 — law and topology** | **PASS WITHIN SCOPE** | none |
| **R6 — scope and status** | **PASS WITHIN SCOPE** | none |

Non-blocking residues (named, for the record): (a) GP-DER-118-v1.10 Section 0 convention equality (candidate line 48) is CANNOT-VERIFY-locally — body absent from the corpus (KIMI-AUD-012: "the v1.10 BODY itself remains ABSENT - REQUEST UPLOAD stands for it"); Drive ID 1qc6ep2S4PIoPMEWDsdDQI1dr0LOwJiK9; whole-file sha256 c1d6e559274d7e87a3fa92f44cb2534a5e277a3b5941fd40db380599ddba0564; frozen body 9b7901e112a4857e3ea59942858684f72fc09a2825b1efa859360dd8fa55f014. The estimand of record (W10 §1) is local and matches exactly, so this does not block R1. (b) Manuscript Definition 2.8's "window" phrasing is loose prose; the exact-pin reading is fixed by the W10 firewall and manuscript (3.3) — a documentation note about the manuscript, not a candidate defect. (c) The finiteness/positivity of m, B_3, B_4 and the conditional-C⁴ uniformity are R2/R3 burdens; R1/R6 PASSes are conditional on those interfaces' own dispositions, exactly as the packet's per-interface protocol intends.
