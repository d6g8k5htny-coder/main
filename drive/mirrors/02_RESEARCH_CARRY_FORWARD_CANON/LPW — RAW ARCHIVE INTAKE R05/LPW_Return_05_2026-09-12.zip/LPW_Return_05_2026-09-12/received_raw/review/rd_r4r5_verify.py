#!/usr/bin/env python3
"""RD (R4/R5) independent symbolic verification for LPW-CAND-20260912.

Independent re-derivation of:
  R4: 1D pin Taylor identities, 2D C^2 remainder (9/2)Kr, 2089/384 ledger,
      basis C^2 norms, 3/64 < 1/16 tolerance, Hessian scaling and interval
      determinant bounds, strict typing.
  R5: normalizer algebra (2rM3^2 per station, 4r^2M3^4, C_Z=4B_3), jet-box
      volume 32 delta^4 r, numerator 1040 m delta^4 r^5, quotient c r^3.

Fail-closed ck(); no bare asserts; exact rational/symbolic sympy only.
Scope: deterministic algebra/arithmetic of sections 4, 8, 9, 10. This is NOT
a Gaussian-probability certificate and does not by itself close R2/R3 inputs.
"""
from __future__ import annotations
import json
import sys
try:
    import sympy as s
except ImportError:
    print('DEPENDENCY_ERROR: sympy required', file=sys.stderr)
    raise SystemExit(2)

checks = []

def ck(name, truth, value=None):
    passed = bool(truth)
    row = {'name': name, 'pass': passed}
    if value is not None:
        row['value'] = str(value)
    checks.append(row)
    if not passed:
        raise ValueError('CHECK_FAILED:' + name)

def exact_sup_poly_rect(p, x, y, xlo, xhi, ylo, yhi):
    """Exact sup of polynomial p on a rectangle: corners + interior critical
    points + edge critical points, all solved symbolically."""
    cands = set()
    px, py = s.diff(p, x), s.diff(p, y)
    # corners
    for xv in (xlo, xhi):
        for yv in (ylo, yhi):
            cands.add(s.simplify(p.subs({x: xv, y: yv})))
    # interior critical points
    try:
        sols = s.solve([px, py], [x, y], dict=True)
        for sol in sols:
            if x in sol and y in sol:
                xv, yv = sol[x], sol[y]
                if xv.is_real and yv.is_real and xlo <= xv <= xhi and ylo <= yv <= yhi:
                    cands.add(s.simplify(p.subs({x: xv, y: yv})))
    except Exception:
        pass
    # edge critical points
    for yv in (ylo, yhi):
        q = p.subs(y, yv)
        for rt in s.solve(s.diff(q, x), x):
            if rt.is_real and xlo <= rt <= xhi:
                cands.add(s.simplify(q.subs(x, rt)))
    for xv in (xlo, xhi):
        q = p.subs(x, xv)
        for rt in s.solve(s.diff(q, y), y):
            if rt.is_real and ylo <= rt <= yhi:
                cands.add(s.simplify(q.subs(y, rt)))
    return cands

def c2_norm_exact(p, x, y, xlo, xhi, ylo, yhi):
    """Exact C^2 norm (max over |alpha|<=2 of sup |d^alpha p|) on rectangle."""
    derivs = [p, s.diff(p, x), s.diff(p, y),
              s.diff(p, x, 2), s.diff(p, x, y), s.diff(p, y, 2)]
    best = s.Rational(0)
    for d in derivs:
        cands = exact_sup_poly_rect(d, x, y, xlo, xhi, ylo, yhi)
        for c in cands:
            if not c.is_real:
                raise ValueError('NONREAL_CANDIDATE')
            best = s.Max(best, abs(c))
    return s.simplify(best)

def main() -> int:
    x, y, t = s.symbols('x y t', real=True)
    r, K, m, CZ, B3, M3 = s.symbols('r K m CZ B3 M3', positive=True)
    delta = s.Rational(1, 1024)
    eps = s.Rational(1, 16)

    # ---------------- Section 3 witness (prerequisite for R4) ----------------
    g = x**3/3 - x/4 - s.Rational(1, 12)
    Fstar = g + 2*(x**2 - s.Rational(1, 4))*y - 5*y**2
    Mp = {x: -s.Rational(1, 2), y: 0}
    Sp = {x: s.Rational(1, 2), y: 0}
    ck('R4pre_Fstar_value_m', Fstar.subs(Mp) == 0)
    ck('R4pre_Fstar_value_s', Fstar.subs(Sp) == -s.Rational(1, 6))
    ck('R4pre_Fstar_grad', [s.diff(Fstar, v).subs(p) for v in (x, y) for p in (Mp, Sp)] == [0, 0, 0, 0])
    H = s.hessian(Fstar, (x, y))
    Hm, Hs = H.subs(Mp), H.subs(Sp)
    ck('R4pre_Hm', Hm == s.Matrix([[-1, -2], [-2, -10]]))
    ck('R4pre_Hs', Hs == s.Matrix([[1, 2], [2, -10]]))
    ck('R4pre_dets', Hm.det() == 6 and Hs.det() == -14)

    ypath = (x**2 - s.Rational(1, 4))/5
    Rpoly = Fstar.subs(y, ypath)
    ck('R4pre_path_start', ypath.subs(x, -s.Rational(1, 2)) == 0)
    ck('R4pre_path_end', ypath.subs(x, -2) == s.Rational(3, 4))
    ck('R4pre_path_in_D', s.solve(s.diff(ypath, x), x) == [0]
       and ypath.subs(x, -2) == s.Rational(3, 4) and ypath.subs(x, -s.Rational(1, 2)) == 0)
    ck('R4pre_R_factorization',
       s.expand(Rpoly - (2*x + 1)**2*(12*x**2 + 8*x - 17)/240) == 0)
    ck('R4pre_R_shift_factorization',
       s.expand(Rpoly + s.Rational(99, 1280) - (4*x + 5)**2*(48*x**2 - 40*x + 1)/3840) == 0)
    z = s.symbols('z', positive=True)
    quad_neg = s.Poly((48*x**2 - 40*x + 1).subs(x, -z), z)
    ck('R4pre_quad_positive_for_negative_x', all(c > 0 for c in quad_neg.all_coeffs()))
    # exact interval floor of the quadratic on [-2,-1/2]: decreasing there
    dq = s.diff(48*x**2 - 40*x + 1, x)
    ck('R4pre_quad_decreasing_on_interval',
       s.simplify(dq.subs(x, -s.Rational(1, 2))) < 0 and s.solve(dq, x) == [s.Rational(5, 12)])
    ck('R4pre_quad_interval_min', (48*x**2 - 40*x + 1).subs(x, -s.Rational(1, 2)) == 33)
    ck('R4pre_R_min_value', Rpoly.subs(x, -s.Rational(5, 4)) == -s.Rational(99, 1280))
    ck('R4pre_R_endpoint', Rpoly.subs(x, -2) == s.Rational(9, 16))

    # ---------------- Section 4 robust neighborhood ----------------
    margin = s.Rational(1, 6) - s.Rational(99, 1280) - eps
    ck('R4_clearance_exact', margin == s.Rational(103, 3840) and margin > 0, margin)
    ck('R4_path_floor_above_saddle', -s.Rational(99, 1280) - eps == -s.Rational(179, 1280)
       and -s.Rational(179, 1280) > -s.Rational(1, 6))
    ck('R4_endpoint_floor', s.Rational(9, 16) - eps == s.Rational(1, 2))
    hm_floor = (1 - eps)*(10 - eps) - (2 + eps)**2
    hs_ceil = -(1 - eps)*(10 - eps) - (2 - eps)**2
    ck('R4_det_Hm_floor_exact', hm_floor == s.Rational(81, 16) and hm_floor > 5, hm_floor)
    ck('R4_det_Hs_ceiling_exact', hs_ceil == -s.Rational(1673, 128) and hs_ceil < -13, hs_ceil)
    ck('R4_weight_product', s.Rational(81, 16)*s.Rational(1673, 128) > 65 and 5*13 == 65,
       s.Rational(81, 16)*s.Rational(1673, 128))
    # strict typing under entrywise error eps: signs of diagonal entries
    ck('R4_typing_m_first_diag_negative', -1 + eps < 0)
    ck('R4_typing_m_negdef_via_det', hm_floor > 0)
    ck('R4_typing_s_first_diag_positive', 1 - eps > 0)
    ck('R4_typing_s_second_diag_negative', -10 + eps < 0)
    ck('R4_typing_s_saddle_via_det', hs_ceil < 0)

    # ---------------- Section 8 (i): 1D pin Taylor identities ----------------
    # h(t)=f(t,0): pins h(+/-r/2)=b, b-r^3/6; h'(+/-r/2)=0; |h''''|<=K.
    # Exact remainder integrals (symbolic, fail-closed):
    svar = s.symbols('svar', real=True)
    rem_grad = s.integrate((r/2 - svar)**2, (svar, 0, r/2)) / 2   # (1/2)int(t-s)^2 ds
    ck('R4i_grad_remainder_each', s.simplify(rem_grad - r**3/48) == 0, rem_grad)
    # |h''(0)| <= (2*Kr^3/48)/r = Kr^2/24
    ck('R4i_fxx_bound', s.simplify((2*rem_grad*K)/r - K*r**2/24) == 0)
    # sum equation: |2h'(0) + r^2/4 h'''(0)| <= 2*K*r^3/48 -> |h'/r^2+h'''/8| <= Kr/48
    ck('R4i_fx_fxxx_combination', s.simplify((2*rem_grad*K)/(2*r**2) - K*r/48) == 0)
    rem_val = s.integrate((r/2 - svar)**3, (svar, 0, r/2)) / 6    # (1/6)int(t-s)^3 ds
    ck('R4i_value_remainder_each', s.simplify(rem_val - r**4/384) == 0, rem_val)
    # candidate's e_v bound: difference of the two value remainders
    ck('R4i_ev_bound', s.simplify(2*rem_val*K - K*r**4/192) == 0)
    # candidate's e_x bound from the summed gradient equation
    ck('R4i_ex_bound', s.simplify((2*rem_grad*K)/2 - K*r**3/48) == 0)
    # |f_xxx(0)-2| <= 12*(r*Kr^3/48 + Kr^4/192)/r^3 = 5Kr/16
    third = 12*(K*r**4/48 + K*r**4/192)/r**3
    ck('R4i_fxxx_minus_2', s.simplify(third - 5*K*r/16) == 0, third)
    # midpoint: |(h(0)-b)/r^3 + 1/12| <= (Kr^2/24)/(8r) + Kr/384 = Kr/128
    mid = (K*r**2/24)/(8*r) + K*r/384
    ck('R4i_midpoint_value', s.simplify(mid - K*r/128) == 0, mid)
    # |f_x(0)/r^2 + 1/4| <= Kr/48 + (5Kr/16)/8 = 23Kr/384
    fxq = K*r/48 + s.Rational(5, 16)*K*r/8
    ck('R4i_fx_quarter', s.simplify(fxq - 23*K*r/384) == 0, fxq)
    # k(t)=f_y(t,0): k(+/-r/2)=0; |k'''|=|f_xxxy|<=K (4th derivative).
    # difference: |r k'(0)| <= 2*K*(r/2)^3/6 = Kr^3/24 -> |f_xy(0)| <= Kr^2/24
    ck('R4i_fxy_bound', s.simplify((2*rem_grad*K)/r - K*r**2/24) == 0)
    # sum: |2k(0) + r^2/4 k''(0)| <= Kr^3/24 -> |f_y(0)/r^2 + f_xxy(0)/8| <= Kr/48
    ck('R4i_fy_fxxy_combination', s.simplify((2*rem_grad*K)/(2*r**2) - K*r/48) == 0)

    # Quartic sanity check: h(t)=sum a_i t^i, pins imposed, a4 = +/-K/24
    # (constant |h''''|=K). The claimed bounds must hold with nonnegative
    # slack (difference-based bounds saturate; sum-based bounds do not, since
    # their extremizers are bang-bang, not polynomial). Slack must be an exact
    # nonnegative monomial in the positive symbols K, r.
    posvars = (K, r)

    def nonneg_monomial(e):
        e = s.simplify(e)
        coeff, rest = e.as_coeff_Mul()
        if not (coeff.is_rational and coeff >= 0):
            return False
        for fct in s.Mul.make_args(rest):
            if fct == 1:
                continue
            if fct in posvars:
                continue
            if fct.is_Pow and fct.base in posvars and fct.exp.is_rational and fct.exp > 0:
                continue
            return False
        return True

    a0, a1, a2, a3 = s.symbols('a0 a1 a2 a3')
    bsym = s.Symbol('b', real=True)
    for sign in (1, -1):
        a4 = sign*K/24
        h = a0 + a1*t + a2*t**2 + a3*t**3 + a4*t**4
        hp = s.diff(h, t)
        sol = s.solve([
            h.subs(t, r/2) - (bsym - r**3/6),
            h.subs(t, -r/2) - bsym,
            hp.subs(t, r/2), hp.subs(t, -r/2)], [a0, a1, a2, a3], dict=True)
        if len(sol) != 1:
            raise ValueError('QUARTIC_SOLVE_AMBIGUOUS')
        sol = sol[0]
        h2 = s.simplify(sol[a2]*2)      # f_xx(0)
        h1 = s.simplify(sol[a1])        # f_x(0)
        h3 = s.simplify(sol[a3]*6)      # f_xxx(0)
        h0 = s.simplify(sol[a0])        # f(0)
        quartic_cases = [
            ('fxx', h2, K*r**2/24),
            ('combo', h1/r**2 + h3/8, K*r/48),
            ('fxxx', h3 - 2, 5*K*r/16),
            ('mid', (h0 - bsym)/r**3 + s.Rational(1, 12), K*r/128),
            ('fxq', h1/r**2 + s.Rational(1, 4), 23*K*r/384),
        ]
        for label, qty, bound in quartic_cases:
            qty = s.simplify(qty)
            if bsym in qty.free_symbols:
                raise ValueError('QUARTIC_B_NOT_ELIMINATED:' + label)
            ck('R4i_quartic_%s_%d' % (label, sign),
               nonneg_monomial(bound - qty) and nonneg_monomial(bound + qty),
               qty)
        # difference-based bounds must saturate on this extremal quartic
        ck('R4i_quartic_fxx_saturates_%d' % sign, s.simplify(abs(h2) - K*r**2/24) == 0)

    # ---------------- Section 8 (ii): 2D C^2 Taylor remainder ----------------
    # fourth derivatives of F_r carry exactly one net power of r:
    # d^beta F_r = r^{|beta|-3} d^beta f -> |.| <= r K for |beta|=4.
    # combinatorial identity sum_{|beta|=m} z^beta/beta! = (|x|+|y|)^m/m!:
    for mord in (2, 3, 4):
        lhs = sum(x**i*y**(mord - i)/s.factorial(i)/s.factorial(mord - i)
                  for i in range(mord + 1))
        ck('R4ii_multinomial_%d' % mord,
           s.expand(lhs - (x + y)**mord/s.factorial(mord)) == 0)
    rem_bounds = {0: 3**4/s.factorial(4), 1: 3**3/s.factorial(3), 2: 3**2/s.factorial(2)}
    ck('R4ii_remainder_values',
       rem_bounds[0] == s.Rational(27, 8) and rem_bounds[1] == s.Rational(9, 2)
       and rem_bounds[2] == s.Rational(9, 2))
    ck('R4ii_remainder_max_is_9_2', max(rem_bounds.values()) == s.Rational(9, 2))

    # |x|+|y| <= 3 on D=[-2,1/2]x[-1,1]
    ck('R4ii_D_l1_radius', 2 + 1 == 3)

    # ---------------- Section 8 (iii): 2089/384 ledger ----------------
    # monomial C^2 norms on D: separable monomials -> exact corner sups
    def mono_c2(ax, ay):
        p = x**ax*y**ay
        return c2_norm_exact(p, x, y, -2, s.Rational(1, 2), -1, 1)
    mono_norms = {(0, 0): 1, (1, 0): 2, (0, 1): 1, (2, 0): 4, (1, 1): 2, (3, 0): 12}
    for (ax, ay), expect in mono_norms.items():
        got = mono_c2(ax, ay)
        ck('R4iii_monomial_norm_%d_%d' % (ax, ay), got == expect, got)
    ledger = (s.Rational(1, 128)*1          # constant:  Kr/128        * 1
              + s.Rational(23, 384)*2       # x:         23Kr/384      * 2
              + s.Rational(1, 48)*1         # y:         Kr/48         * 1
              + s.Rational(1, 48)*4         # x^2:       Kr/48         * 4
              + s.Rational(1, 24)*2         # xy:        Kr/24         * 2
              + s.Rational(5, 96)*12        # x^3:       5Kr/96        * 12
              + s.Rational(9, 2))           # Taylor remainder
    ck('R4iii_ledger_total', ledger == s.Rational(2089, 384), ledger)
    ck('R4iii_ledger_lt_8', ledger < 8)

    # ---------------- Section 8 (iv): basis C^2 norms ----------------
    basis_norms = [((x**2 - s.Rational(1, 4))*y, 4, 'x2qy'),
                   (x*y**2, 4, 'xy2'),
                   (y**2, 2, 'y2'),
                   (y**3, 6, 'y3')]
    for p, expect, label in basis_norms:
        got = c2_norm_exact(p, x, y, -2, s.Rational(1, 2), -1, 1)
        ck('R4iv_basis_norm_%s' % label, got == expect, got)
    ck('R4iv_FJ_minus_Fstar', 4 + 4 + 2 + 6 == 16)

    # ---------------- Section 8 (v): final tolerance ----------------
    tol = 16*delta + 8*s.Rational(1, 256)
    ck('R4v_tolerance', tol == s.Rational(3, 64) and tol < s.Rational(1, 16), tol)

    # ---------------- Section 8 (vi): Hessian scaling ----------------
    # F_r(z)=(f(rz)-b)/r^3. For every bivariate monomial f(u,v)=u^p v^q the
    # chain rule must give d^2F_r/dx^2 = (1/r) f_uu(rz); check all |.|<=3.
    u, v = s.symbols('u v', real=True)
    scale_ok = True
    for p_ in range(4):
        for q_ in range(4 - p_):
            fu = u**p_*v**q_
            Fr = fu.subs({u: r*x, v: r*y})/r**3
            for d1 in (x, y):
                for d2 in (x, y):
                    got = s.diff(Fr, d1, d2)
                    want = s.diff(fu, d1.subs({x: u, y: v}), d2.subs({x: u, y: v})
                                  ).subs({u: r*x, v: r*y})/r
                    if s.simplify(got - want) != 0:
                        scale_ok = False
    # H_f(rz) = r H_{F_r}(z), entrywise
    ck('R4vi_hessian_entry_scale', scale_ok)
    A11, A12, A22 = s.symbols('A11 A12 A22', real=True)
    Amat = s.Matrix([[A11, A12], [A12, A22]])
    ck('R4vi_det_scales_r2', s.simplify((r*Amat).det() - r**2*Amat.det()) == 0)
    ck('R4vi_pair_scales_r4', s.simplify((r*Amat).det()*(r*Amat).det()
                                         - r**4*Amat.det()**2) == 0)
    ck('R4vi_weight_floor', 65 > 0 and s.Rational(81, 16) > 5
       and s.Rational(1673, 128) > 13 and 5*13 == 65)

    # ---------------- Section 9/10: R5 normalizer and powers ----------------
    # zero-mean + Lipschitz: |phi(t)| <= (1/r) int |t-u| du * L <= rL.
    # exact worst-case integral at the endpoint:
    uint = s.integrate(r/2 - svar, (svar, -r/2, r/2))   # int |r/2 - u| du
    ck('R5i_mean_deviation_integral', s.simplify(uint - r**2/2) == 0, uint)
    ck('R5i_mean_deviation_le_r', s.simplify(uint/r - r/2) == 0)
    det_station = r*M3*M3 + (r*M3)**2         # |f_xx f_yy| + f_xy^2
    ck('R5i_station_det_bound', s.simplify(det_station - (r*M3**2 + r**2*M3**2)) == 0)
    # det_station <= 2 r M3^2 exactly when 0<r<=1: deficit factors as M3^2 r (r-1)
    ck('R5i_station_det_le_2rM3sq',
       s.factor(det_station - 2*r*M3**2) == r*(r - 1)*M3**2)
    pair_weight = (2*r*M3**2)**2
    ck('R5i_pair_weight', s.simplify(pair_weight - 4*r**2*M3**4) == 0)
    ck('R5i_CZ_definition',
       s.simplify((4*r**2*B3 - CZ*r**2).subs(CZ, 4*B3)) == 0)

    # jet-box volume: one r-width direction, three fixed-width directions
    vol = (4*delta*r)*(2*delta)**3
    ck('R5iii_volume', s.simplify(vol - 32*delta**4*r) == 0, vol)
    # E_r inside K_J for r <= 1: 2*(5+delta) <= 11
    ck('R5iii_box_containment', 2*(5 + delta) <= 11)
    # Markov halving then integration over the box
    ck('R5iv_half_mass', s.simplify(m*vol/2 - 16*m*delta**4*r) == 0)
    numerator = 65*r**4*16*m*delta**4*r
    ck('R5iv_numerator', s.simplify(numerator - 1040*m*delta**4*r**5) == 0)
    ck('R5iv_65_times_16', 65*16 == 1040)
    quotient = s.simplify(numerator/(CZ*r**2))
    ck('R5v_quotient', s.simplify(quotient - 1040*m*delta**4/CZ*r**3) == 0, quotient)
    ck('R5v_power_ledger', 1 + 4 - 2 == 3)
    ck('R5v_c_with_CZ_4B3', s.simplify(1040*m*delta**4/(4*B3) - 260*m*delta**4/B3) == 0)
    # Z_r > 0 grounded by the same event (lower bound strictly positive)
    ck('R5ii_Z_positivity_grounding', s.simplify(1040*m*delta**4*r**5).subs(
        {m: s.Rational(1, 100), r: s.Rational(1, 100)}) > 0)

    # F_J satisfies the six pins exactly for every coefficient choice
    A, B, C, D3 = s.symbols('A B C D3', real=True)
    FJ = g + A*(x**2 - s.Rational(1, 4))*y + B*x*y**2 + C*y**2 + D3*y**3
    ck('R4pre_FJ_pins', FJ.subs(Mp) == 0 and FJ.subs(Sp) == -s.Rational(1, 6)
       and [s.diff(FJ, v).subs(p) for v in (x, y) for p in (Mp, Sp)] == [0, 0, 0, 0])
    # F_J - F* coefficient match under E_r: |C-(-5)|<=d, |A-2|<=d, |B|<=d, |D3|<=d
    ck('R4iv_E_r_targets', s.simplify(FJ.subs({A: 2, B: 0, C: -5, D3: 0}) - Fstar) == 0)

    report = {'artifact': 'LPW-CAND-20260912', 'reviewer': 'RD',
              'interfaces': ['R4', 'R5'],
              'scope': 'DETERMINISTIC ALGEBRA OF SECTIONS 4,8,9,10 ONLY',
              'result': 'PASS', 'checks_passed': len(checks), 'checks': checks,
              'independent_review_completed': False,
              'theorem_promotion_authorized': False}
    print(json.dumps(report, sort_keys=True, indent=2))
    return 0

if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except ValueError as exc:
        print(json.dumps({'artifact': 'LPW-CAND-20260912', 'reviewer': 'RD',
                          'interfaces': ['R4', 'R5'], 'result': 'REJECTED',
                          'error': str(exc), 'checks': checks}, sort_keys=True, indent=2))
        raise SystemExit(1)
