# LEAD EVIDENCE PACK — KIMI independent review of LPW-CAND-20260912

Reviewer: lead coordinator (KIMI line). Exposure: the full candidate and review packet were read before
review — this is ordinary hostile review, not blind reconstruction. All computations below are independent
of the author's verify_local_path.py lineage (sympy/mpmath, separate process).

## A. Algebraic core — INDEPENDENTLY VERIFIED (sympy, exact rational arithmetic)

- F*(x,y) = x³/3 − x/4 − 1/12 + 2(x²−1/4)y − 5y²: F*(m) = 0, F*(s) = −1/6, ∇F* = 0 at both
  (m = (−1/2,0), s = (1/2,0)); H*(m) = [[−1,−2],[−2,−10]], det 6 (negative definite);
  H*(s) = [[1,2],[2,−10]], det −14 (saddle). VERIFIED.
- Path height R(x) = F*(γ*(x)) = (2x+1)²(12x²+8x−17)/240 identically; R(x) + 99/1280 =
  (4x+5)²(48x²−40x+1)/3840 identically; 48x²−40x+1 > 0 on [−2, −1/2] (roots 0.026…, 0.807…); min R =
  −99/1280 at x = −5/4; R(−2) = 9/16. VERIFIED.
- Clearance: 1/6 − 99/1280 − 1/16 = 640/3840 − 297/3840 − 240/3840 = 103/3840 > 0. VERIFIED
  (an early partial check of mine misread the display; the candidate's arithmetic is correct).
- C² perturbation (ε = 1/16): det H_G(m) ≥ (1−ε)(10−ε) − (2+ε)² = 81/16 > 5;
  det H_G(s) ≤ −(1−ε)(10−ε) − (2−ε)² = −1673/128 < −13; |det product| ≥ 65 (actual ≥ 66.17);
  endpoint G ≥ 9/16 − 1/16 = 1/2 > 0; path min ≥ −179/1280 > −1/6. VERIFIED.

## B. Hermite normalization — INDEPENDENTLY VERIFIED (sympy)

- V (row-major evaluations at m, s on (1,x,y,x²,xy,x³)): det V = −1. VERIFIED.
- Displayed T_r: det = −r^{−5}, invertible for all r > 0. VERIFIED.
- u_r = T_r·(b,0,0,b−r³/6,0,0)ᵀ = (b − r³/12, −r²/4, 0, 0, 0, 1/3). VERIFIED.
- Each row of T_r reproduces the claimed derivative-frame limit with trapezoidal corrections:
  (f(M)+f(S))/2 + (r/8)(f_x(M)−f_x(S)) → f(0) + O(r⁴) (the r² terms cancel exactly);
  (3/(2r))(f(S)−f(M)) − (1/4)(f_x(M)+f_x(S)) → f_x(0) + O(r⁴) (exact through cubics);
  (f_x(S)−f_x(M))/(2r) → f_xx(0)/2 + O(r²); (f_y(S)−f_y(M))/r → f_xy(0) + O(r²);
  (2/r³)(f(M)−f(S)) + (1/r²)(f_x(M)+f_x(S)) → f_xxx(0)/6 exactly
  (−f_xxx/12 + f_xxx/4 = f_xxx/6). VERIFIED.
- Note: the formula "T_r = D_r^{-1}V^{-1}R_r" holds with the ROW-major V (the reconstruction
  R_r·T_r^{-1}·D_r^{-1} is exactly the row-major evaluation matrix, det −1); a column-major reading
  fails — the displayed matrix is the correct object, and the formula is consistent under the
  row-major reading. Noted for the record (cosmetic; no mathematical content affected).

## C. Taylor lift coefficients — INDEPENDENTLY VERIFIED (hand derivation, term-by-term)

- |f_xx(0)| ≤ Kr²/24 (subtract endpoint gradient equations; remainders Kr³/48 each);
  |f_x(0)/r² + f_xxx(0)/8| ≤ Kr/48 (add them);
  |f_xxx(0) − 2| ≤ Kr/4 + Kr/16 = 5Kr/16 (value difference + substitution);
  |(f(0)−b)/r³ + 1/12| ≤ Kr/192 + Kr/384 = Kr/128;
  |f_x(0)/r² + 1/4| ≤ 5Kr/128 + Kr/48 = 23Kr/384;
  |f_y(0)/r² + f_xxy(0)/8| ≤ Kr/48 (the y-gradient equation — the term completing the sum);
  remainder (9/2)Kr; monomial C² bounds on D: 1→1, x→2, y→1, x²→4, xy→2, x³→12.
  Total: 3 + 46 + 8 + 32 + 32 + 240 + 1728 = 2089/384 exactly, < 8K. VERIFIED.
- Tolerance: 16δ + 8Kr ≤ 16/1024 + 8/256 = 3/64 < 1/16 at r₀ = min(r_G, 1, (256K)^{-1}). VERIFIED.
- Hessian scaling H_f(rz) = r·H_{F_r}(z); det scales by r² per station; pair by r⁴; on the event
  W_r ≥ (81/16)(1673/128) r⁴ ≥ 65r⁴. VERIFIED.
- Physical path: min f = b − (179/1280)r³ > b − r³/6 = f(S) (179·6 = 1074 < 1280); endpoint
  f ≥ b + r³/2 > b; rD ⊂ one torus chart for r ≤ 1. VERIFIED.

## D. Ten-jet Gaussian limit — NUMERICAL EVIDENCE (exact field, mpmath dps 60, |k| ≤ 30)

- Covariance of the ten-jet (U_0, J) at the origin: positive definite, min eigenvalue 0.12655
  (computed from exact lattice sums; truncation tail < 1e-60 at KMAX = 30).
- Schur complement Cov(J | U_0) = diag(2, 1/2, 1/2, 1/6) at machine precision (exact rationals).
- Conditional mean E[J | U_0 = u_0] = (−b, 0, 0, 0) at u_0 = (b, 0, 0, 0, 0, 1/3).
- Gaussian density of J at the thin-box center (r = 0.025, q = −10r, A = 2, B = D_3 = 0):
  1.28e-3, and 1.29e-3 at the box corners — concrete positivity of the density the candidate
  bounds below by m (the uniform-in-r argument is continuity + compactness; this display is
  evidence at the r → 0 endpoint, not a proof of uniformity).
- Structural note (supports the power ledger): on the thin event both diagonal Hessian entries
  are O(r) (f_yy ≈ −10r), so |det H| per station is O(r²) and the weight 65r⁴ is r² times the
  generic typed O(r)·O(r) — consistent with Z_r ≤ C_Z r² and the quotient r^{1+4−2} = r³.

## E. Estimand cross-check (against the program's records)

- The candidate's pins (f(M) = b, f(S) = b − r³/6, ∇f = 0 at M = (−r/2,0), S = (r/2,0)) are exactly
  the program's typed pair-Palm pins (manuscript Definition 2.8; the C024/C025 construction:
  "M = (−r/2,0): jet (b,0,0); S = (r/2,0): jet (b−ℓ,0,0)", ℓ = r³/6).
- The candidate's Q_r spans the same conditioning as the manuscript's corrected pin basis V_r
  (Preliminary 2.5) and as the raw six pins (all three bases span the raw six-pin space); the
  T_r transformation is a third basis of the same span. Same Gaussian conditioning.
- Weight W_r = |det H_M det H_S|·1{H_M ≺ 0, det H_S < 0} matches the manuscript's
  W_r = |det H_M det H_S|·indicators (M max, S saddle); Z_r ≍ r² consistent with the campaign's
  G.7 normalizer theorem (c_Z r² ≤ Z_r ≤ C_Z r²); the candidate needs only the upper bound and
  positivity (the constructed event supplies Z_r > 0).
- q(r,b) = P_r{D_f(M) = S} matches W10's estimand q(r,6/5) = p_r = P⁰_r{D(M) = S} (no adjacency
  conditioning; the η_r channel is untouched — the candidate's event implies failure of the typed
  elder pairing directly).
- NOT locally verifiable: the byte-level match with GP-DER-118-v1.10 Section 0 (a Drive-side file
  not in the local corpus; the author's package reports its hashes reverified: whole-file c1d6e559…,
  body 9b7901e1…). Scoped as CANNOT-VERIFY-locally; the conventions are consistent with every
  record in the local corpus.

## F. Topology — the lead's own attempt to break it

Attempted obstruction: an elder-rule interpretation where M still dies at S despite the path.
Analysis: at level h ∈ (s, min f(γ)), M and z (f(z) > b) share a superlevel component; that
component's birth is ≥ f(z) > b = birth(M), hence strictly older. At level s, the saddle S merges
components; M's class is not the oldest present, so M does not die at S (it may have died earlier —
also a failure of D(M) = S). The argument is pathwise: no Morse–Smale, no gradient trajectories, no
count of any third saddle. The empty-birth convention (sup ∅ = −∞) does not touch it. The one
requirement is the elder rule itself (already part of the estimand's definition). UNBROKEN.

## G. Remaining scrutiny (for the record)

- The conditional C⁴ moment (R3) is the candidate's most delicate step; RC's independent referee
  pass is in flight. The lead's own read: the regression-representer argument is sound at the proof
  level (representers' C⁴ norms uniform by Cauchy–Schwarz + covariance convergence; residual's
  moments v-independent and finite by Minkowski; Γ_r^{-1} bounded on [0, r_G]; the regression
  version makes the pointwise-in-v Markov inequality exact rather than a.e.), matching the standard
  Palm-Kac–Rice technique for Gaussian fields.
