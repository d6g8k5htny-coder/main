#!/usr/bin/env python3
"""
rb_r2_part2_spectral_v2.py -- CORRECTED rung spectral computation (new version).

Predecessor (FROZEN, unchanged): RB_R2_part2_spectral.py, which zeroed covariance
entries with odd total derivative order |alpha+beta| -- correct only at separation
t = 0. For t != 0, odd x-order pairs are nonzero SINE sums. This corrected version
uses the full cos+sin spectral form throughout (kE cos sums, kS sine sums).

Consumers of the predecessor's finite-r data: RB_R2.md's rung-table evidence lines
(gamma_r rung table, the single-rung density display at r = 0.025). Those lines are
covered by REVIEW_LPW/RB_R2_RUNGTABLE_ERRATA.md. The endpoint (r = 0) computations
are exact and unaffected. The corrected density at r = 0.025 is 1.2832254e-3
(RB's omitted-sine value was 1.2831682e-3).

Fail-closed (ck -> SystemExit; no bare asserts). Deterministic; no wall clock.
Both python and python -O must produce byte-identical program output.
"""
import sys
import numpy as np
import mpmath
from mpmath import mpf, mp

def ck(cond, msg="check"):
    if not cond:
        print("CHECK FAILED:", msg)
        raise SystemExit(1)
    print("[ok]", msg)

mp.dps = 60
PI12 = mp.pi/12; KMAX = 30
JMAX = int(mp.ceil(KMAX/PI12)) + 1
ks = [j*PI12 for j in range(-JMAX, JMAX+1)]
ws = [mp.e**(-k*k/2) for k in ks]
Z1 = sum(ws)

def kE(n, d):
    if n % 2: return mpf(0)
    return sum(wj*(kj**n)*mp.cos(kj*d) for kj, wj in zip(ks, ws))/Z1
def kS(n, d):
    if n % 2 == 0: return mpf(0)
    return sum(wj*(kj**n)*mp.sin(kj*d) for kj, wj in zip(ks, ws))/Z1
def kL(n, s):
    if n % 2 == 0: return ((-1)**(n//2)) * kE(n, s)
    return ((-1)**((n+1)//2)) * kS(n, s)
def cov2(a, c, dx, dy):
    return ((-1)**(c[0]+c[1])) * kL(a[0]+c[0], dx) * kL(a[1]+c[1], dy)

def pin_U(r, i):
    M = (-r/2); S = (r/2)
    rows = [
        [(M,(0,0),mpf('0.5')),(M,(1,0),r/8),(S,(0,0),mpf('0.5')),(S,(1,0),-r/8)],
        [(M,(0,0),-3/(2*r)),(M,(1,0),mpf('-0.25')),(S,(0,0),3/(2*r)),(S,(1,0),mpf('-0.25'))],
        [(M,(0,1),mpf('0.5')),(S,(0,1),mpf('0.5'))],
        [(M,(1,0),-1/(2*r)),(S,(1,0),1/(2*r))],
        [(M,(0,1),-1/r),(S,(0,1),1/r)],
        [(M,(0,0),2/r**3),(M,(1,0),1/r**2),(S,(0,0),-2/r**3),(S,(1,0),1/r**2)],
    ]
    return rows[i]
JETS = [(0,2,mpf(1)),(2,1,mpf('0.5')),(1,2,mpf('0.5')),(0,3,mpf(1)/6)]

def covU(i1, i2, r):
    tot = mpf(0)
    for (x1, a1, c1) in pin_U(r, i1):
        for (x2, a2, c2) in pin_U(r, i2):
            tot += c1*c2*cov2(a1, a2, x1-x2, 0)
    return tot
def covUJ(i, jet, r):
    (jx, jy, cj) = jet
    tot = mpf(0)
    for (x1, a1, c1) in pin_U(r, i):
        tot += c1*cj*cov2(a1, (jx, jy), x1, 0)
    return tot
def covJJ(j1, j2):
    (a1x,a1y,c1),(a2x,a2y,c2) = j1, j2
    return c1*c2*cov2((a1x,a1y),(a2x,a2y),0,0)

# spectral truncation tail certificate
tail = 2*mp.e**(-mpf(KMAX)**2/2)*mpf(KMAX)**6*(1 + 4/mpf(KMAX)**2)
ck(tail < mpf('1e-60'), "tail < 1e-60 at KMAX=30 for n<=6 (measured %s)" % mp.nstr(tail, 3))

# sine-term sanity: odd x-order entries are NONZERO at nonzero separation
v = cov2((2,0),(1,1), mpf('0.0375'), mpf('-0.006'))
ck(abs(v) > mpf('1e-6'), "odd x-order pair (f_xx(M), f_xy(S)) nonzero at separation: %s" % mp.nstr(v, 5))
v0 = cov2((2,0),(1,1), 0, 0)
ck(abs(v0) < mpf('1e-80'), "same pair vanishes at zero separation (odd x-order): %s" % mp.nstr(abs(v0), 3))

# full ten-jet covariance at rungs; endpoint and rung certificates
U0_FRAME = [(0,0,mpf(1)),(1,0,mpf(1)),(0,1,mpf(1)),(2,0,mpf('0.5')),(1,1,mpf(1)),(3,0,mpf(1)/6)]
def gamma_0():
    # endpoint: U_0 = (f, f_x, f_y, f_xx/2, f_xy, f_xxx/6), J as JETS
    G = np.zeros((10, 10))
    JET10 = U0_FRAME + JETS
    for i,(ax,ay,ci) in enumerate(JET10):
        for j,(bx,by,cj) in enumerate(JET10):
            G[i,j] = float(ci*cj*cov2((ax,ay),(bx,by),0,0))
    return G

def gamma_r(r):
    G = np.zeros((10, 10))
    for i in range(6):
        for j in range(6): G[i,j] = float(covU(i,j,r))
        for jj in range(4):
            G[i,6+jj] = float(covUJ(i, JETS[jj], r)); G[6+jj,i] = G[i,6+jj]
    for a in range(4):
        for b in range(4): G[6+a,6+b] = float(covJJ(JETS[a],JETS[b]))
    return G

r0 = mpf('0.025')
G0 = gamma_0()
ev0 = np.linalg.eigvalsh(G0)
ck(abs(min(ev0) - 0.126553449667289) < 1e-12,
   "endpoint lambda_min(Gamma_0) = %.15f (reference 0.126553449667289)" % min(ev0))
A6 = G0[:6,:6]; Bm = G0[:6,6:]; D = G0[6:,6:]
Schur0 = D - Bm.T @ np.linalg.inv(A6) @ Bm
print("endpoint Schur diagonal:", ["%.12f" % Schur0[i,i] for i in range(4)])
ck(abs(Schur0[0,0] - 2) < 1e-10 and abs(Schur0[1,1] - 0.5) < 1e-10 and abs(Schur0[2,2] - 0.5) < 1e-10
   and abs(Schur0[3,3] - 1/6) < 1e-10,
   "endpoint Schur = diag(2, 1/2, 1/2, 1/6) (planar reference; finite-torus moment forms per reconciliation)")

Gr = gamma_r(r0)
evr = np.linalg.eigvalsh(Gr)
print("rung lambda_min(Gamma_r) at r = 0.025: %.10f" % min(evr))
A6r = Gr[:6,:6]; Bmr = Gr[:6,6:]; Dr = Gr[6:,6:]
Schurr = Dr - Bmr.T @ np.linalg.inv(A6r) @ Bmr
u = np.array([1.2 - float(r0)**3/12, -float(r0)**2/4, 0,0,0, 1/3])
mu = Bmr.T @ np.linalg.inv(A6r) @ u
d = np.array([-10*float(r0), 2.0, 0, 0]) - mu
dens = np.exp(-0.5 * d @ np.linalg.inv(Schurr) @ d) / ((2*np.pi)**2 * np.sqrt(np.linalg.det(Schurr)))
ck(abs(dens - 1.2832254e-3)/1.2832254e-3 < 1e-6,
   "corrected rung density of J at thin-box center = %.10e (reference 1.2832254e-3 at 7-digit precision; sine terms included; relative deviation %.1e)" % (dens, abs(dens - 1.2832254e-3)/1.2832254e-3))

print("CERTIFICATE: PASS (rb_r2_part2_spectral_v2, full cos+sin spectral form)")
