# RB_R2 Part 1: independent symbolic reconstruction of V, T_r, det T_r, u_r.
# Reviewer RB, ordinary hostile review (candidate read first). Fail-closed.
import sympy as sp

def ck(cond, msg):
    if not cond:
        print("FAIL:", msg)
        raise SystemExit(1)

r, b = sp.symbols('r b', positive=True)

# Basis (1, x, y, x^2, xy, x^3); points m=(-1/2,0), s=(1/2,0)
x, y = sp.symbols('x y')
basis = [1, x, y, x**2, x*y, x**3]
m = (sp.Rational(-1, 2), 0)
s = (sp.Rational(1, 2), 0)

def eval_row(pt, d):
    # d: (dx, dy) derivative order
    row = []
    for p in basis:
        q = sp.diff(p, x, d[0], y, d[1])
        row.append(sp.simplify(q.subs({x: pt[0], y: pt[1]})))
    return row

# Row-major: value/x-/y-derivative evaluations at m then s
V = sp.Matrix([
    eval_row(m, (0, 0)),
    eval_row(m, (1, 0)),
    eval_row(m, (0, 1)),
    eval_row(s, (0, 0)),
    eval_row(s, (1, 0)),
    eval_row(s, (0, 1)),
])
print("V =")
sp.printing.print_latex(V) if False else None
for row in V.tolist():
    print("   ", row)
detV = V.det()
print("det V =", detV)
ck(detV == -1, "det V != -1")

D_r = sp.diag(1, r, r, r**2, r**2, r**3)
R_r = sp.diag(1, r, r, 1, r, r)
T_r = sp.simplify(D_r.inv() * V.inv() * R_r)
print("T_r (reconstructed) =")
for row in T_r.tolist():
    print("   ", row)

# Candidate's displayed matrix (columns follow P6_r = (f(M),f_x(M),f_y(M),f(S),f_x(S),f_y(S)))
T_cand = sp.Matrix([
    [sp.Rational(1,2),  r/8,              0, sp.Rational(1,2), -r/8,              0],
    [-sp.Rational(3,2)/r, -sp.Rational(1,4), 0, sp.Rational(3,2)/r, -sp.Rational(1,4), 0],
    [0,                 0,  sp.Rational(1,2), 0,                 0,  sp.Rational(1,2)],
    [0, -1/(2*r),       0, 0,  1/(2*r),       0],
    [0,                 0, -1/r,              0,                 0,  1/r],
    [2/r**3,  1/r**2,   0, -2/r**3,  1/r**2,  0],
])
diff = sp.simplify(T_r - T_cand)
ck(diff == sp.zeros(6), "reconstructed T_r != displayed T_r")
print("T_r matches displayed matrix: True")

detT = sp.simplify(T_r.det())
print("det T_r =", detT)
ck(detT == -1/r**5, "det T_r != -r^-5")
ck(sp.simplify(D_r.det()) == r**9 and sp.simplify(R_r.det()) == r**4,
   "det D_r != r^9 or det R_r != r^4")
print("det check via factors: det(D^-1)*det(V^-1)*det(R) = (r^-9)*(-1)*(r^4) = -r^-5 OK")
print("Invertible for all r>0: det = -r^-5 != 0 OK")

# Transformed observed vector for prescribed pins (b,0,0,b-r^3/6,0,0)
P = sp.Matrix([b, 0, 0, b - r**3/6, 0, 0])
u_r = sp.simplify(T_r * P)
print("u_r =", list(u_r))
u_expect = sp.Matrix([b - r**3/12, -r**2/4, 0, 0, 0, sp.Rational(1,3)])
ck(sp.simplify(u_r - u_expect) == sp.zeros(6, 1), "u_r mismatch")
print("u_r matches candidate: (b - r^3/12, -r^2/4, 0, 0, 0, 1/3) OK")

# Limit as r->0+: u_r -> (b, 0, 0, 0, 0, 1/3): compact (bounded) observed vector.
u0lim = [sp.limit(ui, r, 0, dir='+') for ui in u_r]
print("lim_{r->0+} u_r =", u0lim)

# --- Part 2 symbolic support: U_r acting on the pin data of a GENERAL
# --- degree-6 polynomial germ g (symbolic coefficients). Taylor's theorem
# --- reduces any smooth field to such a germ plus o(|z|^6); the cubic-jet
# --- limit must come out exactly, with remainders supported on the
# --- degree >= 4 coefficients only.
print("General degree-6 germ check:")
deg6 = []
coefs = {}
for i in range(7):
    for j in range(7 - i):
        a = sp.Symbol(f'c{i}{j}')
        coefs[(i, j)] = a
        deg6.append(a * x**i * y**j)
g6 = sum(deg6)
M = (-r/2, 0); S = (r/2, 0)
def g6v(pt): return g6.subs({x: pt[0], y: pt[1]})
def g6x(pt): return sp.diff(g6, x).subs({x: pt[0], y: pt[1]})
def g6y(pt): return sp.diff(g6, y).subs({x: pt[0], y: pt[1]})
P6 = sp.Matrix([g6v(M), g6x(M), g6y(M), g6v(S), g6x(S), g6y(S)])
U = T_r * P6
# targets: g(0)=c00, g_x(0)=c10, g_y(0)=c01, g_xx/2=c20, g_xy=c11, g_xxx/6=c30
targets = [coefs[(0,0)], coefs[(1,0)], coefs[(0,1)], coefs[(2,0)], coefs[(1,1)], coefs[(3,0)]]
names = ['f(0)', 'f_x(0)', 'f_y(0)', 'f_xx(0)/2', 'f_xy(0)', 'f_xxx(0)/6']
for i in range(6):
    d = sp.expand(U[i] - targets[i])
    # the limit condition: every surviving term has r-power >= 1
    poly = sp.Poly(d, r)
    minexp = None
    for (ex,), coeff in poly.terms():
        if sp.simplify(coeff) == 0:
            continue
        if minexp is None or ex < minexp:
            minexp = ex
    ck(minexp is None or minexp >= 1,
       f"coordinate {i+1}: remainder has r-power {minexp}: {d}")
    print(f"  coord {i+1} ({names[i]}): remainder = {sp.factor(d)}  [min r-power {minexp}]")
print("All six coordinates: exact jet limit on a general germ; remainders O(r^2) or better")
print("(coord 3 remainder carries the degree-3 x^2y coefficient at O(r^2), exactly the")
print(" 'higher x powers contribute errors tending to zero' of candidate line 221) OK")

# Numerical convergence check on a concrete analytic test field (evidence only;
# targets are exact analytic derivatives, not finite differences).
import numpy as np
tf = sp.cos(x + sp.Rational(3,10)*y) + sp.Rational(7,10)*sp.sin(2*x - y) + x**2/10 + x*y/5
tfl = sp.lambdify((x, y), tf, 'numpy')
tfx = sp.lambdify((x, y), sp.diff(tf, x), 'numpy')
tfy = sp.lambdify((x, y), sp.diff(tf, y), 'numpy')
tgt_exact = [float(sp.diff(tf, x, i, y, j).subs({x: 0, y: 0}))
             for (i, j) in [(0,0),(1,0),(0,1),(2,0),(1,1),(3,0)]]
tgt_exact = np.array([tgt_exact[0], tgt_exact[1], tgt_exact[2],
                      tgt_exact[3]/2, tgt_exact[4], tgt_exact[5]/6])
for rr in (1e-1, 1e-2, 1e-3):
    Tv = np.array(T_cand.subs(r, sp.Float(rr)).tolist(), dtype=float)
    Pv = np.array([tfl(-rr/2,0), tfx(-rr/2,0), tfy(-rr/2,0),
                   tfl(rr/2,0), tfx(rr/2,0), tfy(rr/2,0)])
    err = float(np.max(np.abs(Tv @ Pv - tgt_exact)))
    print(f"  numeric check r={rr}: max|U_r - U_0| = {err:.3e} (expect ~O(r^2))")
print("Numeric convergence evidence OK (analytic targets; labeled evidence)")

# Hermite exactness: interpolation operator is exact on cubics. Verify:
# apply T_r to the pin data of a GENERAL cubic g(x,y) evaluated at physical
# points (+-r/2,0) and check we recover exactly its derivative-jet at 0.
a0, a1, a2, a3, a4, a5, a6, a7, a8, a9 = sp.symbols('a0:10')
g = (a0 + a1*x + a2*y + a3*x**2 + a4*x*y + a5*y**2
     + a6*x**3 + a7*x**2*y + a8*x*y**2 + a9*y**3)
def gv(pt): return g.subs({x: pt[0], y: pt[1]})
def gx(pt): return sp.diff(g, x).subs({x: pt[0], y: pt[1]})
def gy(pt): return sp.diff(g, y).subs({x: pt[0], y: pt[1]})
P6g = sp.Matrix([gv(M), gx(M), gy(M), gv(S), gx(S), gy(S)])
Ug = sp.simplify(T_r * P6g)
gtargets = [a0, a1, a2, a3, a4, a6]  # g(0),g_x,g_y,g_xx/2,g_xy,g_xxx/6
# Candidate's exact claim (line 221): x-axis coordinates (1,2,4,6) are exact
# through degree three; y-coordinates (3,5) interpolate f_y by its constant
# and linear terms, with higher x powers contributing errors tending to zero.
for i in (0, 1, 3, 5):
    resid = sp.simplify(Ug[i] - gtargets[i])
    ck(resid == 0, f"x-axis coordinate {i+1} not exact on cubics: {resid}")
print("x-axis coords (1,2,4,6): cubic Hermite exactness through degree three OK")
for i in (2, 4):
    resid = sp.expand(Ug[i] - gtargets[i])
    poly = sp.Poly(resid, r)
    minexp = min(ex for (ex,), c in poly.terms() if sp.simplify(c) != 0) if resid != 0 else None
    ck(minexp is None or minexp >= 1, f"y-coordinate {i+1} error does not vanish: {resid}")
    print(f"  y-coord {i+1}: error on cubics = {resid} (vanishes as r->0, O(r^{minexp})) OK")
print("y-coordinate interpolation statement verified: constant+linear interp of f_y, higher x powers -> O(r^2) error OK")

print("PART1_ALL_CHECKS_PASSED")
