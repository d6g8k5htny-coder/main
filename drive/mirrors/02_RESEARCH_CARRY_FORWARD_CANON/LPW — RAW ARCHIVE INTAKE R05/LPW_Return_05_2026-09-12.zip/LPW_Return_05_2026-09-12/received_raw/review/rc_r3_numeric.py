# RC_R3_NUMERIC — lower-tier numerical evidence for review interface R3 of
# LPW-CAND-20260912 (02_LOCAL_PATH_LOWER_BOUND_CANDIDATE.md, sha256
# cf58f72eb0399c626160c143b50f674ff3bd5c449225211edd6fd378a374e1a5).
#
# NOT A PROOF. Evidence display only.
#
# Exact periodized field: dual lattice k in (pi/12) Z^2, spectral masses
# proportional to exp(-|k|^2/2), truncated to |k| <= 30 (Euclidean ball).
# r = 0.025, six pins (b = 6/5), thin-box center j_c = (-10r, 2, 0, 0).
#
# Computes, conditioning on V_r = (U_r, J) = (u_r, j_c):
#   * conditional mean and covariance of the derivative vector
#     (d^alpha f(z), |alpha| <= 4) at sample points z;
#   * exact E[(d^alpha f(z))^2 | V_r = v];
#   * a Monte-Carlo-free union bound for E[M_4-like | V_r = v] over a
#     48 x 48 torus grid with a one-level (order-5) mesh correction,
#     recursion explicitly truncated and labeled;
#   * gamma_r eigenvalues, conditional-variance nonnegativity checks.
#
# Fail-closed: every check goes through ck(); failure -> SystemExit(1).
# No bare asserts. Program output is deterministic and must be byte-identical
# under `python3 rc_r3_numeric.py` and `python3 -O rc_r3_numeric.py`.

import sys
from mpmath import mp, mpf, mpc, matrix, nstr, exp as mexp, cos as mcos, sin as msin, pi as mpi, sqrt as msqrt, log as mlog, eigsy

mp.dps = 60

FAILED = []

def ck(cond, msg):
    if not cond:
        FAILED.append(msg)
        print("CHECK-FAIL: " + msg)
        sys.stdout.flush()
        raise SystemExit(1)

def note(msg):
    print(msg)

# ---------------------------------------------------------------- lattice
# k = (pi/12) n, |k| <= 30  <=>  |n| <= 360/pi = 114.591559...
NBOUND2 = 13131          # floor((360/pi)^2); |n|^2 <= 13131 <=> |k| <= 30
N1 = 114                 # 1D truncation for factorized sums (covers the ball)

w1 = [mexp(-(mpi * n / 12) ** 2 / 2) for n in range(-N1, N1 + 1)]
kn = [mpi * n / 12 for n in range(-N1, N1 + 1)]

W1sq = sum(w1) ** 2
# direct 2D normalization over the Euclidean ball
W2ball = mpf(0)
for i1 in range(2 * N1 + 1):
    n1 = i1 - N1
    for i2 in range(2 * N1 + 1):
        n2 = i2 - N1
        if n1 * n1 + n2 * n2 <= NBOUND2:
            W2ball += w1[i1] * w1[i2]
# exact corner mass: square minus ball (this is the true truncation gap)
corner = mpf(0)
for i1 in range(2 * N1 + 1):
    n1 = i1 - N1
    for i2 in range(2 * N1 + 1):
        n2 = i2 - N1
        if n1 * n1 + n2 * n2 > NBOUND2:
            corner += w1[i1] * w1[i2]
rel = abs(W2ball - W1sq) / W2ball
note("W2(ball)          = " + nstr(W2ball, 30))
note("W1^2 (square)     = " + nstr(W1sq, 30))
note("|W2-W1^2|/W2      = " + nstr(rel, 10) + "  (60-dps accumulation noise)")
note("corner mass (square-ball) = " + nstr(corner, 10))
ck(corner < mpf("1e-150"), "ball-vs-square truncation mass too large")
ck(rel < mpf("1e-45"), "ball-vs-square sums disagree beyond rounding")

# ------------------------------------------------- 1D spectral moment sums
# F_a(t) = sum_n w1(n) k^a e^{i k t}, a = 0..10 ; factorizes 2D sums.
Fcache = {}

def F(a, t):
    key = (a, t)
    if key in Fcache:
        return Fcache[key]
    acc = mpc(0)
    ct = [mcos(k * t) for k in kn]
    st = [msin(k * t) for k in kn]
    for a2 in range(0, 11):
        s = mpc(0)
        for i in range(2 * N1 + 1):
            s += w1[i] * (kn[i] ** a2) * mpc(ct[i], st[i])
        Fcache[(a2, t)] = s
    return Fcache[key]

def Gcov(g1, g2, dx, dy):
    # sum_k what_k k^gamma e^{i k.Delta}, gamma=(g1,g2), factorized
    return F(g1, dx) * F(g2, dy) / W2ball

_ipows = [1, mpc(0, 1), -1, mpc(0, -1)]

def covD(alpha, z, beta, zp):
    # Cov( d^alpha f(z), d^beta f(z') ) for the real stationary field
    a = alpha[0] + alpha[1]
    b = beta[0] + beta[1]
    val = _ipows[a % 4] * _ipows[(3 * b) % 4] * Gcov(
        alpha[0] + beta[0], alpha[1] + beta[1], z[0] - zp[0], z[1] - zp[1])
    # (-i)^b = i^{3b}; result is real by symmetry
    return val.real

# direct 2D-ball cross-check of one factorized covariance entry
def covD_direct(alpha, z, beta, zp):
    s = mpf(0)
    ph = _ipows[(alpha[0] + alpha[1]) % 4] * _ipows[(3 * (beta[0] + beta[1])) % 4]
    g1 = alpha[0] + beta[0]
    g2 = alpha[1] + beta[1]
    for i1 in range(2 * N1 + 1):
        n1 = i1 - N1
        for i2 in range(2 * N1 + 1):
            n2 = i2 - N1
            if n1 * n1 + n2 * n2 <= NBOUND2:
                k1 = kn[i1]
                k2 = kn[i2]
                s += w1[i1] * w1[i2] * (k1 ** g1) * (k2 ** g2) * mcos(
                    k1 * (z[0] - zp[0]) + k2 * (z[1] - zp[1]))
    return (ph * s / W2ball).real

v_fx_fact = covD((1, 0), (0, 0), (1, 0), (0, 0))
v_fx_dir = covD_direct((1, 0), (0, 0), (1, 0), (0, 0))
note("Var f_x factorized = " + nstr(v_fx_fact, 30))
note("Var f_x direct2D   = " + nstr(v_fx_dir, 30))
ck(abs(v_fx_fact - v_fx_dir) < mpf("1e-40"), "factorized vs direct 2D mismatch")
ck(abs(covD((0, 0), (0, 0), (0, 0), (0, 0)) - 1) < mpf("1e-40"),
   "field not unit variance")

# ------------------------------------------------------------- pins, T_r
r = mpf("0.025")
b = mpf(6) / 5
M = (-r / 2, mpf(0))
S = (r / 2, mpf(0))
O = (mpf(0), mpf(0))

# raw 10-vector Y: 6 pins then J-block with Hermite scales
Yspec = [((0, 0), M, 1), ((1, 0), M, 1), ((0, 1), M, 1),
         ((0, 0), S, 1), ((1, 0), S, 1), ((0, 1), S, 1),
         ((0, 2), O, 1), ((2, 1), O, mpf(1) / 2),
         ((1, 2), O, mpf(1) / 2), ((0, 3), O, mpf(1) / 6)]

# T_r exactly as displayed in candidate section 5
Tr = matrix([[mpf(1) / 2, r / 8, 0, mpf(1) / 2, -r / 8, 0],
             [-3 / (2 * r), -mpf(1) / 4, 0, 3 / (2 * r), -mpf(1) / 4, 0],
             [0, 0, mpf(1) / 2, 0, 0, mpf(1) / 2],
             [0, -1 / (2 * r), 0, 0, 1 / (2 * r), 0],
             [0, 0, -1 / r, 0, 0, 1 / r],
             [2 / r ** 3, 1 / r ** 2, 0, -2 / r ** 3, 1 / r ** 2, 0]])

pins_raw = matrix([b, 0, 0, b - r ** 3 / 6, 0, 0])
u_r = Tr * pins_raw
u_claim = matrix([b - r ** 3 / 12, -r ** 2 / 4, 0, 0, 0, mpf(1) / 3])
err_u = max(abs(u_r[i] - u_claim[i]) for i in range(6))
note("|u_r - claimed|    = " + nstr(err_u, 10))
ck(err_u < mpf("1e-55"), "T_r action on pins disagrees with claimed u_r")

# ------------------------------------------------------------- Gamma_r
SigY = matrix(10, 10)
for i in range(10):
    ai, zi, si = Yspec[i]
    for j in range(10):
        aj, zj, sj = Yspec[j]
        SigY[i, j] = si * sj * covD(ai, zi, aj, zj)

L = matrix(10, 10)
for i in range(6):
    for j in range(6):
        L[i, j] = Tr[i, j]
for i in range(4):
    L[6 + i, 6 + i] = 1

Gam = L * SigY * L.T
ev, _P = eigsy(Gam)
ev = sorted(ev)
note("Gamma_r eigenvalues (ascending):")
for e in ev:
    note("   " + nstr(e, 20))
ck(min(ev) > 0, "Gamma_r not positive definite at r=0.025")

GamInv = Gam ** -1
# sanity: GamInv * Gam ~ I
iderr = max(abs((GamInv * Gam)[i, j] - (1 if i == j else 0))
            for i in range(10) for j in range(10))
ck(iderr < mpf("1e-40"), "Gamma inversion inaccurate")

j_c = (-10 * r, mpf(2), mpf(0), mpf(0))
v = matrix(list(u_r) + list(j_c))
note("v = (u_r, j_c):")
note("   " + nstr(v, 15))

# --------------------------------------------- conditioning of derivatives
def cond_mean_var(alpha, z):
    # returns (mean, var) of d^alpha f(z) given V_r = v
    cY = [0] * 10
    for j in range(10):
        aj, zj, sj = Yspec[j]
        cY[j] = sj * covD(alpha, z, aj, zj)
    cV = matrix(1, 10)
    for j in range(10):
        cV[0, j] = sum(L[j, l] * cY[l] for l in range(10))
    mean = (cV * GamInv * v)[0]
    var = covD(alpha, z, alpha, z) - (cV * GamInv * cV.T)[0, 0]
    return mean, var

def all_derivs(maxord):
    out = []
    for tot in range(maxord + 1):
        for a1 in range(tot, -1, -1):
            out.append((a1, tot - a1))
    return out

A_LE4 = all_derivs(4)
A_EQ4 = [a for a in A_LE4 if a[0] + a[1] == 4]
A_EQ5 = [a for a in all_derivs(5) if a[0] + a[1] == 5]

samples = [("z1=(-r/4,0)", (-r / 4, mpf(0))),
           ("z2=r*(-2,3/4)", (-2 * r, 3 * r / 4)),
           ("z3=(0,r/2)", (mpf(0), r / 2)),
           ("z4=(12,12) antipode", (mpf(12), mpf(12)))]

for name, z in samples:
    note("--- conditional derivative vector at " + name + " ---")
    Sig = matrix(len(A_LE4), len(A_LE4))
    mu = []
    for i, a1 in enumerate(A_LE4):
        m1, _ = cond_mean_var(a1, z)
        mu.append(m1)
        for j, a2 in enumerate(A_LE4):
            cY1 = [0] * 10
            cY2 = [0] * 10
            for l in range(10):
                al, zl, sl = Yspec[l]
                cY1[l] = sl * covD(a1, z, al, zl)
                cY2[l] = sl * covD(a2, z, al, zl)
            cV1 = matrix(1, 10)
            cV2 = matrix(1, 10)
            for jj in range(10):
                cV1[0, jj] = sum(L[jj, l] * cY1[l] for l in range(10))
                cV2[0, jj] = sum(L[jj, l] * cY2[l] for l in range(10))
            Sig[i, j] = covD(a1, z, a2, z) - (cV1 * GamInv * cV2.T)[0, 0]
    evs, _Ps = eigsy(Sig)
    ck(min(evs) > 0, "conditional covariance degenerate at " + name)
    note("   min eig cond.cov = " + nstr(min(evs), 12)
         + "   max eig = " + nstr(max(evs), 12))
    for i, a in enumerate(A_LE4):
        va = Sig[i, i]
        ck(va > 0, "nonpositive conditional variance at " + name)
        e2 = va + mu[i] ** 2
        note("   d(%d,%d) f: mean=%s  sd=%s  E[.^2|v]=%s"
             % (a[0], a[1], nstr(mu[i], 12), nstr(msqrt(va), 12),
                nstr(e2, 12)))

# --------------------------------------- grid union bound for E[M_4 | v]
GN = 48
h = mpf(24) / GN
gridx = [i * h for i in range(GN)]
ln2G = msqrt(2 * mlog(2 * GN * GN))

def grid_stats(alpha):
    mx_mu = mpf(0)
    mx_sd = mpf(0)
    for gx in gridx:
        for gy in gridx:
            z = (gx, gy)
            m1, v1 = cond_mean_var(alpha, z)
            ck(v1 > -mpf("1e-30"), "conditional variance < 0 on grid")
            if v1 < 0:
                v1 = mpf(0)
            if abs(m1) > mx_mu:
                mx_mu = abs(m1)
            s1 = msqrt(v1)
            if s1 > mx_sd:
                mx_sd = s1
    return mx_mu, mx_sd

note("--- grid union bound (G=%d, h=%s) ---" % (GN * GN, nstr(h, 6)))
tot_cond = mpf(0)
tot_unc = mpf(0)
for alpha in A_EQ4:
    mm, ms = grid_stats(alpha)
    Bc = mm + ms * ln2G
    # unconditional comparison (same formula, no conditioning)
    vu = covD(alpha, (0, 0), alpha, (0, 0))
    Bu = msqrt(vu) * ln2G
    # one-level mesh correction via order-5 children
    corr = mpf(0)
    for child in [(alpha[0] + 1, alpha[1]), (alpha[0], alpha[1] + 1)]:
        m5, s5 = grid_stats(child)
        corr += m5 + s5 * ln2G
    corr *= h
    note(("d(%d,%d): max|mu|=%s maxsd=%s  B_cond=%s  +meshcorr=%s  "
          "B_uncond=%s") % (alpha[0], alpha[1], nstr(mm, 12),
                            nstr(ms, 12), nstr(Bc, 12), nstr(corr, 12),
                            nstr(Bu, 12)))
    tot_cond += Bc + corr
    tot_unc += Bu

note("sum_{|a|=4} (B_cond + mesh corr) = " + nstr(tot_cond, 15))
note("   (recursion truncated at one mesh level; labeled evidence only)")
note("sum_{|a|=4} B_uncond            = " + nstr(tot_unc, 15))
note("implied evidence scale for E[M_4|v] at r=0.025, j=j_c; "
     "compare K = max(1, 2 B_4) in candidate section 7")

note("ALL CHECKS PASSED")
