# ERRATA — RB_R2.md rung-table lines (sine-omission defect; endpoint unaffected)

Date: 2026-09-13. Author of this note: lead coordinator, on the LPW_CONSTANT agent's finding
(MANIFEST entry falsify.py 435b40ce…, receipted F1–F8 PASS).

## The defect

RB's R2 rung script (RB_R2_part2_spectral.py) zeroes covariance entries with odd |α + β| total
derivative order. That is correct only at separation t = 0: for t ≠ 0, pairs with odd x-order are
nonzero SINE sums (the odd part of the spectral kernel is a sine series, not zero). The rung table
(Γ_r at r > 0) therefore carries O(r) entry errors — e.g., the Var(U_6)-class entries are off at the
~8/r⁴-sensitivity class at small r, and the reported density of J at r = 0.025 was 1.2831682e-3
versus the corrected 1.2832254e-3 (the gap is exactly the omitted sine terms; the constant agent's
corrected T_r route and profile route agree to 2.1e-56 and reproduce every reference value).

## Scope and impact

- UNAFFECTED (exact at the endpoint r = 0): the ten-jet covariance Γ_0, its certified eigenfloor
  (λ_min = 0.126553449667289 as evidence; the proved floor 0.124 from the author-side supplement),
  the Schur complement diag(2, 1/2, 1/2, 1/6) (planar reference; finite-torus moment forms per the
  reconciliation), the conditional mean (−a₂b, 0, 0, 0), and every Q1–Q7 disposition of the
  qualitative review — the LPW endorsement (cf58f72e…) is untouched (its proof uses r → 0
  continuity and compactness, and the corrected density is slightly HIGHER, strengthening the
  density-floor evidence).
- AFFECTED (rung-dependent evidence lines in RB_R2.md §4–§5): the Γ_r rung table's O(r)-order
  entries and the single-rung density display at r = 0.025 (corrected value 1.2832254e-3). These
  were evidence displays, not proof inputs; the corrections change nothing in any disposition.
- The uniformity claims (continuity down to r = 0; the compactness argument for the density floor)
  are analytic and unaffected; the certified interval modulus of the LPW_CONSTANT agent
  (‖Γ_r − Γ_0‖_F ≤ 19.071156·R on [0, 1e-5]) is the radius certificate of record and is independent
  of RB's rung script.

## Correction of record

RB_R2.md is a frozen report and is NOT edited. This note stands as the errata of record for its
rung-table lines. Any future rung computation must use the full cos+sin spectral form (the pattern
of verify_g9_periodized_transfer_v1.py's kL/kE/kS machinery, or the constant agent's corrected
T_r route).
