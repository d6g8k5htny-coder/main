# ADDENDUM 2 to KIMI_LPW_REVIEW_VERDICT.md — custody and diagnostic corrections (2026-09-13)

The sealed verdict (body d399e28378d177f88d08032c81f1573f35c9af2b600b9b775ebfe40f555cbbad) and the
sealed Addendum 1 (body ca58855f8344c1c1…) remain unchanged in the record. This second addendum repairs
two defects identified by the author-side's Return-03 package (zip sha256 fb81f8c1774d851775a025ac08750fa9e98e7b04d0e6844e7aebfd14456de2c7, 306,334 B).
The LPW endorsement itself (all six interfaces PASS WITHIN SCOPE at cf58f72e…e1a5) is untouched.

## 1. Malformed whole-file digest (custody defect, owned)

Addendum 1 §"Sealed" and the README printed the verdict's whole-file hash as
`04bcbdf2013d83b113c18518bd101bb8c1a96e01e8c66a6aab2d2390e5e4d1e3cf` — 66 hexadecimal characters; a
SHA-256 digest has 64. This was a transcription slip in the addendum drafting, not a hidden-file issue.
Recomputed from the actual bytes of REVIEW_LPW/KIMI_LPW_REVIEW_VERDICT.md (9,219 B):

    whole-file SHA-256 = 04bcbdf2013d83b149a8933a332a078c303af347335ee40f154f37ba195ad448

(the printed prefix `04bcbdf2013d83b1` is correct). The README_BUNDLE.md hash line has been corrected in
place (it is a packaging file, not a sealed transcript) and the bundle MANIFEST.sha256 rebuilt; the
declared body hash d399e28378d177f88d08032c81f1573f35c9af2b600b9b775ebfe40f555cbbad is unaffected and
remains governed by the stated extraction rule (hash the exact byte prefix before the unique marker
line, preserving all preceding bytes including blank lines — never a trim-and-append operation).

## 2. The a₄ − 3 sign (diagnostic defect, owned)

My earlier quick computation printed `a_4 − 3 ≈ −4.0219e-124`. That is wrong in sign and magnitude.
Cause identified (mine): a wrong fourth-derivative formula in the quick check (a `−24·Σn⁴·e^{−288n²}`
form instead of the correct fourth Hermite form (24n)⁴ − 6(24n)² + 3). The author-side's exact identity
is correct:

    a_4 − 3 = 2·Σ_{n≥1} (331776n⁴ − 3456n²)·e^{−288n²} / (1 + 2·Σ_{n≥1} e^{−288n²}) > 0,

with every numerator summand strictly positive (3456n²(96n² − 1) > 0 for n ≥ 1). Independently
recomputed at 150 dps with the correct Hermite form:

    a_4 − 3 = +5.5019488254071504413555…e-120  (positive),

agreeing with the author-side's value 5.50194882540715044135552121887e-120 to 1.8e-150. Their
exponential enclosure 5.50194e-120 < a₄ − 3 < 5.50196e-120 is consistent. The a₂ − 1 diagnostic
(−9.6525e-123) stands as previously recorded (its sign is negative and correct). The proved endpoint
floor λ_min(Γ_{0,24}) > 0.124 is unaffected (it used a much looser absolute correction bound that
accommodates the corrected value).

## 3. Raw reviewer archive (the actual transfer)

The author-side correctly notes that PDFs describe the bundle but are not the bundle. The raw archive
is now produced as a single ZIP of REVIEW_LPW (29 files + MANIFEST.sha256 + README_BUNDLE.md), with
whole-file sha256 for every member and the extraction rule for the verdict's declared body hash stated
in the README. It contains: the verdict and both addenda; the lead evidence pack; the four interface
reports (RA/RB/RC/RD); all interface scripts; both-mode transcripts (byte-identical for RB/RC/RD; RD's
original transcripts are present as out_normal.json/out_opt.json and independently reproduction-confirmed
by a lead rerun matching the reported hash prefix 45f4d471…); exit receipts; ENVIRONMENT_LOCK.json
(python 3.12.12, mpmath 1.3.0, numpy 2.2.5, sympy 1.14.0, scipy 1.16.2 for W2_sanity). Packaging note
(unchanged from README): RA did not persist a standalone script to the shared tree; its transcript is
embedded in RA_R1_R6.md, and per the author's own instruction no manufactured "recovered script" is
included — a reconstruction would carry a new identity and an accurate exposure record if ever produced.

## 4. The Return-03 quantitative candidate

The new explicit-constants candidate (r_* = 10^{−28}, c_* = 10^{−1235}: 1 − q(r, 6/5) ≥ 10^{−1235}·r³
for 0 < r ≤ 10^{−28}) is under independent KIMI review at its own Q1–Q7 targets. It does not inherit
the qualitative endorsement. Preliminary verification (lead, already complete): the covariance
perturbation algebra ‖Γ_r − Γ_0‖_op ≤ 2‖V_0‖‖V_r − V_0‖ + ‖V_r − V_0‖² ≤ 28r + 4r² ≤ 32r is correct;
the endpoint floor 31/250 > 1/8 is verified (Sylvester minors, prior addendum); the choice R = 1/1600
then gives λ_min(Γ_r) > 31/250 − 32/1600 = 13/125 > 1/10 by correct arithmetic; the density exponent
(R_J + M)²/(2λ) = (12+3)²/(2·(1/10)) = 1125 gives a natural floor ~10^{−493} (the candidate's
m_* = 10^{−1129} is a valid but deliberately much weaker lower choice, ~636 orders below the natural
floor); δ⁴ = 2^{−40} and 260/2^{40} > 10^{−10}, so c = 260·m_*·δ⁴/B_3 ≥ 10^{−1129−10−96} = 10^{−1235}
as printed; and r_* = 10^{−28} < (256K)^{-1} = (512·10^{24})^{-1} ≈ 1.95e-27, so the Taylor radius is
respected. The full Q1–Q7 dispositions (the L² estimates ‖V_r − V_0‖ ≤ 2r and ‖V_0‖ < 7, the β₀ mean
bound ‖μ_r‖ < 3, the Σ_r bounds, the full-Fourier B_3 = 10^{96} and B_4 = 10^{24}, and the r_* =
10^{−28} < min(R, 1, (256K)^{-1}) radius logic) are the review's remaining items; its verdict ships
separately. A defect in the quantitative extension would not touch the qualitative LPW endorsement.

SHA-256 of this addendum body (text after this line is excluded):
55511a324250f532a28bdda860ae9604e43b22d278668cd52f650ca455fa611d
