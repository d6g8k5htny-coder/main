# RB_R2 Parts 3-5: exact periodized Bargmann-Fock field, side-24 torus.
# Spectral representation: frequencies k in (pi/12) Z^2, weights e^{-|k|^2/2},
# Z-normalized (equivalent to the candidate's real-space K_24 by Poisson
# summation; checked numerically below). mpmath >= 50 dps. Fail-closed.
# All numerical eigenvalue/density outputs are EVIDENCE, not proof.
from mpmath import mp, mpf, pi, exp, sqrt, cos, matrix, fabs, log10

mp.dps = 50

def ck(cond, msg):
    if not cond:
        print("FAIL:", msg)
        raise SystemExit(1)

h = pi/12                      # lattice spacing
a = h*h/2                      # exponent coefficient in e^{-a |n|^2}
NB = 114                       # sum n in [-114,114]^2; tail: max|n_i|>=115
M0 = 115                       # tail shell start

# ---------------- rigorous tail bounds ----------------
# Z_e = sum_{max|n_i|>=115} e^{-a|n|^2} <= sum_{m>=115} 8m e^{-a m^2}
#      <= 8 M0 (1 + 1/(a M0)) e^{-a M0^2}   (m e^{-a m^2/2} decreasing for m>M0)
# T6  = sum_tail e^{-a|n|^2} |k|^6 <= sum_{m>=115} 8m e^{-a m^2} (h sqrt2 m)^6
#      <= 8 (h sqrt2)^6 M0^7 (1 + 1/(a M0)) e^{-a M0^2}
ck(a*M0*M0 > 7, "tail decrease condition fails")
geom = (1 + 1/(a*M0)) * exp(-a*M0*M0)
Z_e = 8*M0*geom
T6 = 8*(h*sqrt(2))**6 * M0**7 * geom
print(f"certified tail bounds: Z_e <= {mp.nstr(Z_e,5)}  T6 <= {mp.nstr(T6,5)}")

# ---------------- spectral moment engine ----------------
# M(gamma; t) = (1/Z) sum_n w(n) k^gamma cos(k1 t), k = h n, w = e^{-a|n|^2}
# Moments with gamma1 or gamma2 odd vanish identically by lattice symmetry.
def moments(ts):
    # returns dict (g1,g2,tindex) -> mpf, for even g1,g2, g1+g2<=6
    gam = [(i, j) for i in range(0, 7, 2) for j in range(0, 7 - i, 2)]
    acc = {(g, ti): mpf(0) for g in gam for ti in range(len(ts))}
    Z = mpf(0)
    ct = [cos(h*t) for t in ts]
    for n1 in range(-NB, NB+1):
        k1 = h*n1
        p1 = [mpf(1)]
        for i in range(1, 7):
            p1.append(p1[-1]*k1)
        c1 = [cos(k1*t) for t in ts]
        for n2 in range(-NB, NB+1):
            k2 = h*n2
            w = exp(-a*(n1*n1 + n2*n2))
            Z += w
            p2 = [mpf(1)]
            for j in range(1, 7):
                p2.append(p2[-1]*k2)
            for (g1, g2) in gam:
                base = w*p1[g1]*p2[g2]
                for ti in range(len(ts)):
                    acc[((g1, g2), ti)] += base*c1[ti]
    out = {}
    for key in acc:
        out[key] = acc[key]/Z
    return out, Z

# t = z1_x - z2_x values needed: 0, r/2, r for each rung r (cos is even)
# ---------------- covariance of derivative evaluations ----------------
# Cov(d^alpha f(z1), d^beta f(z2)) = (-1)^((|a|+|b|)/2+|b|) M(alpha+beta; t)
# when |a|+|b| even, else 0.  z1-z2 = (t,0).
def covE(Mm, al, be, ti):
    s = al[0]+al[1]+be[0]+be[1]
    if s % 2 == 1:
        return mpf(0)
    g1, g2 = al[0]+be[0], al[1]+be[1]
    if g1 % 2 == 1 or g2 % 2 == 1:
        return mpf(0)   # odd moments vanish by lattice symmetry k -> -k
    sign = -1 if (((s//2) + be[0]+be[1]) % 2 == 1) else 1
    return sign*Mm[((g1, g2), ti)]

# derivative index sets
P6_comps = [((0,0)), ((1,0)), ((0,1))]   # value, dx, dy at each pin
J_comps  = [((0,2), 1), ((2,1), 2), ((1,2), 2), ((0,3), 6)]  # (alpha, factorial scale)
U0_scales = [1, 1, 1, 2, 1, 6]

def eigfloor(A):
    # certified lower bound for min eigenvalue of symmetric mp matrix A
    n = A.rows
    E, Q = __import__('mpmath').eigsy(A)
    Lam = matrix(n, n)
    for i in range(n):
        Lam[i, i] = E[i]
    R = A - Q*Lam*Q.T
    fro = mpf(0)
    for i in range(n):
        for j in range(n):
            fro += R[i, j]**2
    fro = sqrt(fro)
    return min(E), fro

print("\n=== rung loop (exact periodized field, truncation |n|<=114, tails certified) ===")
rungs = [mpf('0.5'), mpf('0.25'), mpf('0.1'), mpf('0.05'), mpf('0.025')]
bb = mpf(6)/5
delta = mpf(1)/1024

results = {}
for r in rungs:
    ts = [mpf(0), r/2, r]
    Mm, Z = moments(ts)
    # t-index for pair of points: z values in {-r/2, 0, r/2}
    def tindex(z1, z2):
        d = fabs(z1-z2)
        if d == 0: return 0
        if d == r/2: return 1
        if d == r: return 2
        raise SystemExit(1)
    # P6 covariance: pins at (-r/2,0) and (r/2,0)
    pts = [-r/2, r/2]
    C6 = matrix(6, 6)
    for p in range(2):
        for q in range(2):
            ti = tindex(pts[p], pts[q])
            for i in range(3):
                for j in range(3):
                    C6[3*p+i, 3*q+j] = covE(Mm, P6_comps[i], P6_comps[j], ti)
    # J covariance (at origin, scaled)
    CJ = matrix(4, 4)
    for i in range(4):
        for j in range(4):
            CJ[i, j] = covE(Mm, J_comps[i][0], J_comps[j][0], 0)/(J_comps[i][1]*J_comps[j][1])
    # cross P6 x J
    CX = matrix(6, 4)
    for p in range(2):
        ti = tindex(pts[p], mpf(0))
        for i in range(3):
            for j in range(4):
                CX[3*p+i, j] = covE(Mm, P6_comps[i], J_comps[j][0], ti)/J_comps[j][1]
    # T_r reconstructed independently from V
    V = matrix([  # rows: val,dx,dy at m=(-1/2,0) then s=(1/2,0); cols basis 1,x,y,x^2,xy,x^3
        [1, mpf(-1)/2, 0, mpf(1)/4, 0, mpf(-1)/8],
        [0, 1, 0, -1, 0, mpf(3)/4],
        [0, 0, 1, 0, mpf(-1)/2, 0],
        [1, mpf(1)/2, 0, mpf(1)/4, 0, mpf(1)/8],
        [0, 1, 0, 1, 0, mpf(3)/4],
        [0, 0, 1, 0, mpf(1)/2, 0]])
    Dd = matrix(6, 6)
    for i, d in enumerate([1, r, r, r**2, r**2, r**3]):
        Dd[i, i] = d
    Rr = matrix(6, 6)
    for i, d in enumerate([1, r, r, 1, r, r]):
        Rr[i, i] = d
    Tr = Dd**-1 * V**-1 * Rr
    # displayed matrix cross-check (numeric)
    Td = matrix([
        [mpf(1)/2, r/8, 0, mpf(1)/2, -r/8, 0],
        [-3/(2*r), mpf(-1)/4, 0, 3/(2*r), mpf(-1)/4, 0],
        [0, 0, mpf(1)/2, 0, 0, mpf(1)/2],
        [0, -1/(2*r), 0, 0, 1/(2*r), 0],
        [0, 0, -1/r, 0, 0, 1/r],
        [2/r**3, 1/r**2, 0, -2/r**3, 1/r**2, 0]])
    dmax = max(fabs(Tr[i, j]-Td[i, j]) for i in range(6) for j in range(6))
    ck(dmax < mpf('1e-40'), f"T_r mismatch at r={r}: {dmax}")
    # joint covariance of (U_r, J)
    GU = Tr*C6*Tr.T
    GX = Tr*CX
    G = matrix(10, 10)
    for i in range(6):
        for j in range(6):
            G[i, j] = GU[i, j]
    for i in range(6):
        for j in range(4):
            G[i, 6+j] = GX[i, j]
            G[6+j, i] = GX[i, j]
    for i in range(4):
        for j in range(4):
            G[6+i, 6+j] = CJ[i, j]
    lamG, froG = eigfloor(G)
    # Schur complement: conditional covariance of J given U_r
    S = CJ - GX.T*(GU**-1)*GX
    lamS, froS = eigfloor(S)
    # entrywise tail error: each covariance entry built from moments with
    # |error| <= (T6 + Mmax*Z_e)/Z ; propagate crudely (tails ~1e-180)
    Mmax = max(fabs(v) for v in Mm.values())
    e_mom = (T6 + Mmax*Z_e)/Z
    e_F = sqrt(mpf(100))*e_mom          # Frobenius bound for any 10x10 block
    # Schur error: dS <= dCJ + 2||GX^T GU^-1||_F dG + ||GX^T GU^-1||_F^2 dGU
    nrm = mpf(0)
    Ginv = GU**-1
    W = GX.T*Ginv
    nrmW = sqrt(sum(W[i, j]**2 for i in range(4) for j in range(6)))
    e_S = e_F + 2*nrmW*e_F + nrmW**2*e_F
    # conditional mean of J given U_r = u_r
    ur = matrix([bb - r**3/12, -r**2/4, 0, 0, 0, mpf(1)/3])
    mu = W*ur
    results[r] = dict(lamG=lamG, froG=froG, lamS=lamS, froS=froS,
                      eG=e_F, eS=e_S, mu=mu, S=S, Z=Z)
    print(f"r={mp.nstr(r,4)}: lam_min(Gamma_r)={mp.nstr(lamG,12)} "
          f"(eig-res {mp.nstr(froG,3)}, tail {mp.nstr(e_F,3)})  "
          f"lam_min(Schur)={mp.nstr(lamS,12)} (res {mp.nstr(froS,3)}, tail {mp.nstr(e_S,3)})")
    print(f"    cond mean mu_r = {[mp.nstr(mu[i],8) for i in range(4)]}, det S = {mp.nstr(__import__('mpmath').det(S),10)}")

# ---------------- r = 0 endpoint: full 10-jet ----------------
print("\n=== r = 0 endpoint: ten-jet covariance of exact field ===")
Mm, Z = moments([mpf(0)])
ck(abs(Z - 288/pi) < Z_e + mpf('1e-40'),
   f"Poisson/normalization check fails: Z={mp.nstr(Z,20)} vs 288/pi={mp.nstr(288/pi,20)}")
print(f"Z = {mp.nstr(Z,25)}; 288/pi = {mp.nstr(288/pi,25)} (Poisson identity OK within tail)")
varfx = Mm[((2,0), 0)]/1   # Var f_x should be 1 (matches real-space K_xx(0)=-1)
ck(abs(varfx - 1) < mpf('1e-40'), f"Var f_x != 1: {mp.nstr(varfx,30)}")
print(f"Var(f_x) = {mp.nstr(varfx,25)} (planar value 1; periodization invisible at this scale) OK")

order10 = [((0,0),1), ((1,0),1), ((0,1),1), ((2,0),2), ((1,1),1), ((3,0),6),
           ((0,2),1), ((2,1),2), ((1,2),2), ((0,3),6)]
G0 = matrix(10, 10)
for i in range(10):
    for j in range(10):
        (ai, si), (aj, sj) = order10[i], order10[j]
        G0[i, j] = covE(Mm, ai, aj, 0)/(si*sj)
lam0, fro0 = eigfloor(G0)
Mmax = max(fabs(v) for v in Mm.values())
e_F0 = sqrt(mpf(100))*(T6 + Mmax*Z_e)/Z
print(f"lam_min(Gamma_0) = {mp.nstr(lam0,15)}")
print(f"  eigen residual (Frobenius) = {mp.nstr(fro0,5)}, spectral tail bound = {mp.nstr(e_F0,5)}")
print(f"  CERTIFIED lower bound: lam_min >= {mp.nstr(lam0 - fro0 - e_F0,10)}")
ck(lam0 - fro0 - e_F0 > 0, "r=0 endpoint not certified positive definite")
# also Schur at r=0 (conditional covariance of J given U_0)
GU0 = G0[:6, :6]; GX0 = G0[:6, 6:]; CJ0 = G0[6:, 6:]
S0 = CJ0 - GX0.T*(GU0**-1)*GX0
lamS0, froS0 = eigfloor(S0)
print(f"r=0 Schur: lam_min = {mp.nstr(lamS0,15)} (res {mp.nstr(froS0,5)}), det S0 = {mp.nstr(__import__('mpmath').det(S0),12)}")

# ---------------- part 5: density evaluation at r = 0.025 ----------------
print("\n=== density of J under Q_r on E_r box, r = 0.025 (EVIDENCE) ===")
r = mpf('0.025')
S = results[r]['S']; mu = results[r]['mu']
detS = __import__('mpmath').det(S)
Sinv = S**-1
def density(j):
    d = matrix(4, 1)
    for i in range(4):
        d[i, 0] = j[i] - mu[i]
    qf = (d.T*Sinv*d)[0, 0]
    return (2*pi)**-2 * detS**-mpf('0.5') * exp(-qf/2), qf
center = [-10*r, mpf(2), mpf(0), mpf(0)]
vals = []
pc, qc = density(center)
vals.append(pc)
print(f"center j_c = {[mp.nstr(v,6) for v in center]}: density = {mp.nstr(pc,10)} (quad form {mp.nstr(qc,6)})")
import itertools
mincorner = None
for sg in itertools.product([1, -1], repeat=4):
    j = [ -10*r + sg[0]*2*r*delta, mpf(2)+sg[1]*delta, sg[2]*delta, sg[3]*delta ]
    pv, qv = density(j)
    vals.append(pv)
    if mincorner is None or pv < mincorner[0]:
        mincorner = (pv, j, qv)
print(f"min over 16 corners: density = {mp.nstr(mincorner[0],10)} at j = {[mp.nstr(v,6) for v in mincorner[1]]} (quad {mp.nstr(mincorner[2],6)})")
print(f"max over corners+center (reference): {mp.nstr(max(vals),10)}")
# probability mass scale of E_r (density lower bound x volume), evidence:
vol = 32*delta**4*r
print(f"vol(E_r) = 32 delta^4 r = {mp.nstr(vol,10)};  min-density*vol = {mp.nstr(min(vals)*vol,10)}")

print("\nPART2_ALL_CHECKS_PASSED")
