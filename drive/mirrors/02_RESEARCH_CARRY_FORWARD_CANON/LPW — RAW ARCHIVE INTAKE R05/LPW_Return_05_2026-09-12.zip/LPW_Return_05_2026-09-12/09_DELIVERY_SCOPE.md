# Final handoff scope

The return package is the complete offline layout referenced by the read-first and Kimi work-order files. received_archives/ holds the four unchanged Kimi archives; received_raw/ duplicates their extracted contents for direct inspection. Historical sources and the pre-update R04 evidence state are preserved separately.

The full25MB outer upload is retained onDrive and has its complete hash/member receipt here. It is not redundantly embedded in this returnZIP. All nestedZIPs inside that outer upload were opened and CRCchecked. Detailed mathematical review was limited to the current packages and explicitly described source interfaces; no claim is made to have independently reproved every historical file.

Accepted qualitative/fallback results remain distinct from the received improvedcertificate, which needs the listed amendment. The new6.238e-44 Rayleigh/interval repair is an author-side candidate, not a silently altered Kimi approval.

Execution inventory:14 received-program replays;39 new interval checks in each of normal/optimized modes, byte-identical;19 exact received-claim audit checks in both modes, byte-identical; the oversized headline mutation rejected in both modes. The original constant falsifier also reproduced its ownF1–F8 outputs. W8's long sweep was not rerun.

The manifest covers all package files except itself. The finalZIP delivery receipt is external to theZIP to avoid a circular hash claim.
