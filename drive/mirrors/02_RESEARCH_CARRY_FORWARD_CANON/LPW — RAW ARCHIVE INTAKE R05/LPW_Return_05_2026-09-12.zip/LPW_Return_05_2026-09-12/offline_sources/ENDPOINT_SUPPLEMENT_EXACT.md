# Exact periodic endpoint formulas and a conservative positive eigenfloor

**Record:** LPW-ENDPOINT-20260912-v1.0.  
**Status:** new author-side derivation with exact symbolic/rational checks. Not a replay of Kimi RB's unavailable code. Not a finite-r interval certificate, not an evaluation of c or r0, and not a claim of originality.

The reviewer correctly separates the analytic nondegeneracy argument from numerical evidence in the lead pack. The purpose here is to remove exact-planar substitution from any subsequent numerical certificate and to supply a conservative endpoint bound whose justification is fully displayed.

## 1. Keep the exact periodic moments

The exact one-dimensional factor of the normalized side-24 covariance is

\[
k_{24}(t)=\frac{\sum_{n\in\mathbb Z}e^{-(t+24n)^2/2}}
{\sum_{n\in\mathbb Z}e^{-(24n)^2/2}}.
\]

The two-dimensional covariance is k24(x)k24(y). Define

\[
a_2=-k_{24}''(0),\qquad a_4=k_{24}^{(4)}(0),\qquad
 a_6=-k_{24}^{(6)}(0).
\]

These are positive even spectral moments. They are close to 1,3,15 but must not be replaced by those values in exact-torus claims. In particular,

\[
a_2=1-\frac{576\sum_{n\in\mathbb Z}n^2e^{-288n^2}}
{\sum_{n\in\mathbb Z}e^{-288n^2}}<1.
\]

The numerator being subtracted is strictly positive. Thus even the equality a2=1 is false at exact finite side.

Use the candidate's ordered vector

\[
U_0=(f,f_x,f_y,f_{xx}/2,f_{xy},f_{xxx}/6),\qquad
J=(f_{yy},f_{xxy}/2,f_{xyy}/2,f_{yyy}/6).
\]

For u0=(b,0,0,0,0,1/3), product symmetry and Gaussian regression give the exact formulas

\[
\boxed{\mathbb E[J\mid U_0=u_0]=(-a_2b,0,0,0)}
\]

and

\[
\boxed{\operatorname{Cov}(J\mid U_0)=
\operatorname{diag}\left(
 a_4-a_2^2,
 \frac{a_2(a_4-a_2^2)}4,
 \frac{a_2(a_4-a_2^2)}4,
 \frac{a_6-a_4^2/a_2}{36}
\right).}
\]

### Derivation by orthogonal residuals

The residual for q=f_yy is q+a2*f; it is uncorrelated with every coordinate of U0. The residuals for A=f_xxy/2 and B=f_xyy/2 are A+(a2/2)f_y and B+(a2/2)f_x. The residual for D3=f_yyy/6 is D3+(a4/(6a2))f_y. Parity removes all mixed residual covariances except the potentially nonzero A,D3 pair; there the cancellation is

    Cov(A,D3) - Cov(A,f_y)Cov(f_y,D3)/Var(f_y)
      = a2*a4/12 - [(-a2^2/2)(-a4/6)]/a2 = 0.

The four residual variances are exactly the diagonal entries above. Their projections on u0 yield the displayed mean. The script also verifies these identities by symbolic Schur complementation of the full ten-dimensional covariance.

Substituting a2=1,a4=3,a6=15 gives diag(2,1/2,1/2,1/6) and mean (-b,0,0,0). These are exact **planar reference** identities, not exact finite-torus identities.

## 2. A conservative rigorous bound on the periodic correction

Put t=exp(-288). The Taylor series for exp(3) through degree eight exceeds 20, and 20^96>10^120. Therefore

    0<t<10^-120<1/2.

For j=1,2,3, the absolute coefficient sum of the probabilists' Hermite polynomial H_(2j) is at most 76. For n>=1,

    |H_(2j)(24n)| <= 76(25n)^6.

Also n^2>=n and t<1/2, so

    sum_{n>=1} n^6 t^(n^2)
      <= t sum_{n>=1} n^6 2^(-(n-1))
      = 18732 t.

The normalization denominator S0 satisfies S0>=1 and S0-1<=4t. Consequently, for each moment a2j and its planar value m2j=(2j-1)!!,

    |a2j-m2j|
      <= [2*76*25^6*18732 + 60]t
      = 695132812500060 t
      < 10^-105.

This estimate is deliberately very loose. It is an infinite-sum bound, not a truncation followed by an assumed tail. The integer arithmetic and the generating-function value 18732 are checked exactly in check_review.py.

## 3. Ten-dimensional endpoint eigenfloor

Let Gflat be the covariance of the stated ordered (U0,J) vector for the planar reference field. The exact leading principal minors of Gflat-(1/8)I are:

    7/8
    49/64
    343/512
    931/4096
    6517/32768
    931/786432
    4263/2097152
    11571/16777216
    11571/134217728
    203/1073741824.

All are positive. Hence Gflat-(1/8)I is positive definite, and lambda_min(Gflat)>1/8.

Each covariance entry is a product of at most two one-dimensional moments of total derivative order at most six, multiplied by jet scaling factors of absolute value at most one. Odd entries vanish exactly by symmetry. The relevant planar moment magnitudes are at most 15. With epsilon=10^-105,

    max_ij |G24_ij-Gflat_ij| < 30 epsilon + epsilon^2 <31 epsilon.

For the symmetric 10-by-10 difference matrix,

    ||G24-Gflat||_op <= ||G24-Gflat||_F
                        <=10 max_ij |G24_ij-Gflat_ij|
                        <10^-102.

Applying the Rayleigh quotient bound to every unit vector yields

\[
\lambda_{\min}(G_{24})>
\frac18-10^{-102}>
\boxed{\frac{31}{250}=0.124.}
\]

This is an explicit positive bound for the **exact side-24 endpoint covariance**, in this precisely normalized ten-jet basis. It does not use the reported 6.9e-50 eigenpair residual or RB's reported spectral tail. It does not assert a finite-r radius over which the same eigenfloor holds; a modulus for Gamma_r-G24 remains needed for quantitative r_G.

The script verifies the Sylvester minors and all rational numerical inequalities above. The infinite-sum comparison and Rayleigh argument are the written analytic parts of the certificate, not a Lean proof.

## 4. Rounding correction

The pasted report's lower endpoint 0.1265534497 exceeds its reported central value 0.126553449667289 by 3.2711e-11. The narrow rounded floor is therefore not justified by that display. The value 0.124 above is conservative, basis-specific and proved by a separate argument; it should not be represented as Kimi's certificate.

## 5. Density diagnostics and the constant m

For the planar endpoint reference only,

\[
\phi_{0,\infty}(q,A,B,D_3)
=\frac{\sqrt3}{2\pi^2}
\exp\left[-\frac{(q+b)^2}{4}-A^2-B^2-3D_3^2\right].
\]

At b=6/5, q=0,A=2,B=D3=0 this is approximately 0.001121261590047301. Plugging q=-1/4 into the same endpoint reference gives approximately 0.001282523307077429, explaining the scale of the reported single-rung diagnostic without making it a uniform floor.

For the original compact box K_J=[-11,1] x [2-delta,2+delta] x [-delta,delta]^2, delta=1/1024, the exact planar reference minimum is at q=-11,A=2+delta,|B|=|D3|=delta and equals

\[
\frac{\sqrt3}{2\pi^2}
\exp\left[-\frac{2401}{100}-(2+\delta)^2-4\delta^2\right]
\approx5.98334320198\times10^{-14}.
\]

These floating evaluations are labelled diagnostics. They are not interval enclosures for the exact finite-r field. A quantitative successor can greatly improve the floor by explicitly using a tighter compact set covering only the thin boxes for the chosen small radius. It must then state the changed compact set and redo the uniform conditional moment and density bounds there.

## 6. Boundary of this supplement

Established here by the displayed author-side derivation: exact moment-dependent endpoint Schur/mean identities; a coarse strictly positive exact-torus endpoint eigenfloor. Still open here: uniform finite-r moment/covariance enclosure; evaluated B3 and B4; a certified global m over the selected parameter set; explicit c and r0; independent review of this supplement. No program status is promoted.
