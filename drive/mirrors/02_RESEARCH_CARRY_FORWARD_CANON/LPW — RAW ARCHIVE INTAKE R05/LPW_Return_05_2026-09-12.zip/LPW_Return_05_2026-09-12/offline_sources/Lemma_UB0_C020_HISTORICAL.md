# Lemma UB0 — Two-Sided Channel Decomposition for the Elder-Rule Selection Probability

**Cycle:** C020 (channel closure) · **Date:** 2026-07-09
**Snapshot:** C020_ChannelClosure_snapshot.json, sha256 `89c32ebcc38f4225bbaa45ed8aab96ad79c23705a1de98e49a9fe81b6be4a512`
**Epistemic label:** **Derived-architecture.** The decomposition identity and the Bonferroni squeeze are exact given the witness definitions; the loop absorption is cited from the C011/master-source mechanism; the elder-verdict locality step is architecture-grade (stated as an explicit hypothesis (γ-LOC), supported by measurement, not proven); the constant is Measured under the pre-registered protocol with the in-cycle estimator supersession (slice → Λ-exact) and the null-rigidity incident repair fully documented in `C020_Observed_Update.json`.

---

## 0. Setting and the object

Work under the fold-pair Palm law of the C006 program: a centered stationary Gaussian field on $\mathbb{T}_L^2$ satisfying (H1+), (H2′), Assumption MS, conditioned on the pair jets
$$
f(x_M)=b,\ \nabla f(x_M)=0,\qquad f(x_S)=b-\ell,\ \nabla f(x_S)=0,
$$
at separation $r=|x_M-x_S|$, with the elder-rule window height $\ell=r^3/6$, restricted to typed configurations ($x_M$ a max, $x_S$ a saddle) by the $W_2=|\det H_M||\det H_S|\,\mathbf 1_{\text{typed}}$ Kac–Rice weight. Testbed: Bargmann–Fock, $b=1.2$, $r=0.05$, $\ell=2.0833\times10^{-5}$.

The estimand is the master source's selection probability (cited verbatim from the frozen definition):

> *"Let $q(r,b,\ell)$ denote the conditional probability that the elder-rule death at $x_S$ is paired with the nearby maximum $x_M$, rather than with a competing older component."* (Unified_Master_Source, §Def-q, l. 512)

> *"**Theorem A — Conditional Form.** … under the fold-pair Palm law at separation $r$ and birth height $b\in B$, let $q(r,b)$ be the probability that the candidate maximum–saddle fold pair is the actual $H_0$ elder-rule persistence pair. Then $\sup_{b\in B}|q(r,b)-1|\to 0$"* (l. 3778)

This lemma packages the exact **two-sided** reduction of $1-q$ to a single Palm integral, replacing the retired pinned zone-bound route (OBL-UB-PALM, discharged this cycle).

---

## 1. Failure characterization (partner exchange)

Under the Palm law, the elder-rule pairing at $x_S$ fails **iff**, in the merge tree at height $f(x_S)=b-\ell$, the component merged into by the death at $x_S$ carries a maximum **older** (higher) than $x_M$. By the Morse–Smale merge mechanics (Assumption MS, master source §S3–S4), on the failure event exactly one of two exchange geometries realizes:

- **(α) window-saddle preemption.** Some *other* saddle $y \ne x_S$ with $f(y)\in(b-\ell,\,b)$ is adjacent to $x_M$ (one ascending separatrix branch terminates at $x_M$) while its other branch terminates at a maximum with value $>b$. Then the component of $x_M$ is already merged into an older component strictly above height $b-\ell$, and the death at $x_S$ pairs with $x_M$'s component only through the elder — the pair $(x_M,x_S)$ is not the persistence pair.
- **(β∖α) direct gain coincidence.** No such window saddle exists, but $x_S$'s second ascending branch terminates at a maximum $M_2\ne x_M$ with $G:=f(M_2)-f(x_S)\in(0,\ell)$, i.e. $f(M_2)\in(b-\ell,b)$: a *younger-looking but actually older-by-value* partner exchange at the gain scale.

**Identity (exact given MS typing and the witness definitions):**
$$
1-q(r,b)\;=\;\mathbb P_{\mathrm{Palm}}(\alpha)\;+\;\mathbb P_{\mathrm{Palm}}(\beta\setminus\alpha)\;+\;\mathrm{err},
$$
where $\mathrm{err}$ collects (i) loop/crater witnesses, (ii) multi-witness overlaps, and (iii) boundary/degenerate typings of Palm-measure zero. Terms (i)–(ii) are controlled in §3–§4.

**Converse (lower-bound direction).** Each α-witness *forces* failure: adjacency of a window saddle to $x_M$ with elder other side places $x_M$'s component inside an older component before height $b-\ell$; the death at $x_S$ then cannot pair with $x_M$. Likewise each β-witness with $G\in(0,\ell)$ and $M_2$ in a distinct component forces the exchange. Hence
$$
1-q \;\ge\; \mathbb P(\exists\ \text{α-witness}) \;\vee\; \mathbb P(\exists\ \text{β-witness, distinct component}).
$$

---

## 2. Witness counting and the two-sided squeeze

Let $N_{\mathrm{qual}}$ be the number of **qualifying** window saddles: $y$ critical, saddle-typed, $f(y)\in(b-\ell,b)$, adjacent to $x_M$, other-branch terminal a maximum with value $>b$. Then
$$
\{\alpha\}\;=\;\{N_{\mathrm{qual}}\ge 1\},\qquad
\mathbb E[N_{\mathrm{qual}}]-\tfrac12\mathbb E[N_{\mathrm{qual}}(N_{\mathrm{qual}}-1)]\;\le\;\mathbb P(N_{\mathrm{qual}}\ge1)\;\le\;\mathbb E[N_{\mathrm{qual}}].
$$
The factorial-moment correction is the **LB_Bonferroni** pair term: two distinct window saddles in the Palm geometry cost an extra window factor and an extra area factor; by the same counting as the archive's Lemma LB pair estimate it is $O(r^3)\cdot O(r^3)=O(r^6)$, i.e. $O(r^3)$ *relative*. (Label: Derived, same mechanism as the archived LB pair bound; not re-measured this cycle.)

The β term is bounded above by its own Kac–Rice mirror: $\mathbb P(\beta)\le \int \Lambda_{\max}(y)\,B(y)\,dy$ with $\Lambda_{\max}$ the exact bottom-edge-window maximum intensity and $B$ the S-branch terminal indicator — **measured dead**: corridor ceiling $2.6\times10^{-8}$ in coefficient units; strata band $\mathbb P(G\le\ell)\in[0,\,8\times10^{-42}]$ (C020 M1a/M1b). The β channel is rigidity-killed and drops from the constant.

**Squeeze:**
$$
\boxed{\ 1-q(r,b)\;=\;\mathbb E[N_{\mathrm{qual}}]\,\bigl(1+O(r^3)\bigr)\;=\;C^*\,r^3\,\bigl(1+O(r^3)\bigr)\ }
$$
with $C^*=\mathbb E[N_{\mathrm{qual}}]/r^3$ the single Palm integral of §5.

---

## 3. Loop absorption and the rim unification

**Cited mechanism (C011 / master source, verbatim):**

> *"If the two arms already belong to the same component globally, the saddle may instead create or close a loop. This is a loop/crater obstruction."* (l. 2881)
> *"A loop or crater obstruction occurs when the local saddle does not merge the component born at $x_M$ with a genuinely different component."* (l. 3204)
> *"Thus loop/crater failures are absorbed into the same obstruction decomposition."* (l. 3227)
> *"If the loop/crater obstruction is defined through critical witnesses, it can be absorbed into the inner/annulus/far/band events."* (l. 3304)

C011's operational form: $A_{\mathrm{loop}}$ = self-merge ⟹ the max–min pass saddle of the loop lies in the window ⟹ $A_{\mathrm{loop}}\subseteq\{N_w\ge1\}$ — loop witnesses are *window saddles that fail the qualification test* (both branches in $x_M$'s component), hence they inflate $N_w$ but **not** $N_{\mathrm{qual}}$, and contribute $0$ to both sides of the squeeze.

**C020 rim unification (new, measured).** The summit window-disk of radius $\delta_w=\sqrt{2\ell/\mathrm{stiff}}\approx0.005$ around $x_M$ realizes this dichotomy *geometrically*:

- **Disk interior:** window saddles are pure loop saddles — both separatrix branches terminate at $x_M$. Measured: both→M $=1.0000$, Pre $=0.0000$ at five core points (compatible ensemble). Non-qualifying; absorbed exactly as cited.
- **Disk rim:** window saddles with one branch to $x_M$ and one to the elder landscape. Measured: Pre $=0.92$–$1.00$ at seven fringe points, esc $=0$. **Qualifying** — these are α-witnesses, and their ridge line merges with the C019 arch filament at $y\approx0.010$–$0.012$: arch and rim are one connected ridge system, one α mechanism, one integral.

The transition is sharp (both→M jumps $1.000\to0.000$ across one measurement cell), consistent with the program's uniformly step-like flow geometry.

---

## 4. Elder-verdict locality (γ-LOC) — architecture step

**Hypothesis (γ-LOC).** The qualification verdict of a window saddle $y$ — adjacency to $x_M$ and the other-branch terminal's value comparison against $b$ — is measurable with respect to the field on the union of (i) the $O(r)$ pair neighborhood and (ii) the other branch's ascent tube up to its terminal, and the terminal-value law stabilizes: for rim/arch saddles the other branch exits the conditioned zone with running height $>b$ and terminates at an ambient maximum of value $>b$ with probability $1-O(\text{exp})$.

**Support (measured, this cycle):** monotone ascent from height $\ge b-\ell$ plus the measured exit-ridge rigidity ($m^*$ profile $4.6$–$9.7\sigma$ above $b$ at the probes) forces the escaping branch's path-max above $b$; in the compatible ensemble every fringe flow resolved at an elder terminal (esc $=0$, $N=11{,}200$ pooled fringe flows). Ambient maxima with value in $(b-\ell,b)$ have intensity $O(\ell)$ — negligible. Terminating at a torus image of $x_M$ has value exactly $b$ (excluded by the strict inequality) and requires descending below the running height — impossible under ascent.

γ-LOC is the step that makes $\mathbb E[N_{\mathrm{qual}}]$ a *local* Palm functional evaluable by the C020 instrument. It is stated as architecture: the program's remaining route to full proof is a quantitative off-pair decorrelation bound (carried obligation OBL-FAR-DECAY).

---

## 5. The needle estimator (Λ-exact) and the constant

**Estimator lemma (derived and verified).** For a window $(v_{\mathrm{lo}},v_{\mathrm{hi}})$ and typing $T$, the per-area intensity of window critical points at $y$ under the pair-Palm law is
$$
\Lambda(y)\;=\;\varphi_2\!\bigl(\nabla f(y)=0\,\big|\,\mathcal J_6\bigr)\cdot
\Bigl[\Phi\!\Bigl(\tfrac{v_{\mathrm{hi}}-\mu_t}{s_t}\Bigr)-\Phi\!\Bigl(\tfrac{v_{\mathrm{lo}}-\mu_t}{s_t}\Bigr)\Bigr]\cdot
\frac{\mathbb E\bigl[W_3\mathbf 1_T\,\big|\,\text{9 pins at } v^*=\mathrm{clip}(\mu_t)\bigr]}{\mathbb E[W_2\,|\,\mathcal J_6]},
$$
where $(\mu_t,s_t)$ are the conditional mean/sd of $f(y)$ given $\nabla f(y)=0$ and the six pair pins, and the Hessian factor's height sensitivity is $O(s_t)\cdot O(1)$ — negligible, making the $v$-integration exact.

*Why this replaced the slice convention:* G-U2 measured $\lambda(y;v)$ varying **seven orders** across the $\ell$-window at fixed $y$ — the third point's conditional height is a needle, $s_t=0.068\,\ell$ at the arch and $10^{-4}\,\ell$ near $x_M$ (where the null functional $\bigl(f(x_M)-f(y)\bigr)/\sqrt2$ is jet-rigid at $\sqrt{\lambda_{\min}}=4.7\times10^{-9}$). The window count survives via the co-area sweep of the needle center across the window (observed directly: peak-height index marching monotonically across the transverse plateau), but the pointwise mid-window slice is a sliced indicator, not an intensity. Brute 11-point $v$-quadrature validates the closed form at ratio $0.951$ (trapezoid on an under-resolved needle overshoots $\sim5\%$, understood). Row-level corrections vs the slice run both directions ($\times3.3$ at the filament root, $\times0.66$ past the peak).

**Compatibility requirement (incident-derived).** The factor-2 evaluation height must be the needle center: $v^*=\mathrm{clip}(\mu_t,\,v_{\mathrm{lo}},\,v_{\mathrm{hi}})$ with **no interior margin**. Near $x_M$ the admissible band around $\mu_t$ is the null-sd $\sim5\times10^{-9}$; the retired $0.02\,\ell$ margin displaced the conditioning $57$ null-sd off-manifold, inflating $\mathbb E[W_3\mathbf 1_T]$ by $4\times10^4$ and manufacturing $22\sigma$ far-field artifacts (full forensics in the observed update). All near-$x_M$ quantities in this package are compatible-ensemble values.

**The constant (measured, pre-registered protocol):**
$$
C^*\;=\;\frac{1}{r^3}\int \Lambda(y)\,\mathrm{AO}(y)\,dA
\;=\;\underbrace{0.8275}_{\text{arch}}\;+\;\underbrace{0.1427}_{\text{rim}}
\;=\;\mathbf{0.9702\;\pm\;0.06},
$$
with AO the measured qualification probability (flow instrument; $\mathrm{AO}\approx1$ on the arch support, Pre map on the rim), error budget: factor-2 MC $\sim1\%$, row/column quadrature $\sim3\%$, $y$-trapezoid $\sim3\%$, Pre/AO interpolation $\sim2\%$, splice $\sim1\%$, denominator $0.3\%$, model gap (G-U1 two-covariance concordance $0.989$–$1.003$) $\le1\%$, retired-clip residual on arch tails $\le2\%$ — RSS $\approx\pm6\%$.

Supersede chain (in scope, never overwritten): $c_\alpha$: $1.097$ (C019 slice convention) → $0.8275$ (Λ-exact, arch) → $\mathbf{0.9702}$ (unified, arch + rim). The C019 value stands in the record as the mid-slice-convention integral; the estimand changed, not the data.

---

## 6. Statement

**Lemma UB0.** Under (H1+), (H2′), Assumption MS, the fold-pair Palm law at separation $r$, window $\ell=r^3/6$, and hypothesis (γ-LOC): with $N_{\mathrm{qual}}$ the qualifying-window-saddle count of §2,
$$
1-q(r,b)\;=\;\mathbb E[N_{\mathrm{qual}}]\;+\;O(r^6)\;=\;C^*(b)\,r^3\;\bigl(1+O(r^3)\bigr),
$$
two-sided, with the β/gain channel contributing $\le 2.6\times10^{-8}$ in coefficient units at the testbed slice (measured by two independent instruments) and the loop population contributing exactly $0$ (C011 absorption; rim dichotomy measured). At $(b,r)=(1.2,\,0.05)$ on Bargmann–Fock: $C^*=0.970\pm0.06$.

**What would falsify the architecture:** a rim/arch flow whose other branch terminates below $b$ at an off-image maximum (none in $11{,}200$ pooled compatible-ensemble fringe flows); a violation of the γ-LOC tube-locality by long-range conditioning leakage (constrained by the far-decorrelation probes; formal bound carried as OBL-FAR-DECAY); or an $O(r^6)$ pair term anomalously large at smaller $r$ (testable at the $r=0.025$ rung).
