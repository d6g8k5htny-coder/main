# The Constants of the r³ Law — canonical table as of C020 (2026-07-09)

Single source of truth; supersedes Constants_Table_Canonical_07-09-26.md (C019 edition) and all earlier
tables (supersede-never-overwrite: priors retained in archive; scope chains explicit). b = 1.2, κ = 1,
ℓ = r³/6, BF testbed. Weighting convention always stated: [PINNED] = six-functional pin conditioning;
[PALM] = W₂ = |det H_M||det H_S|·1_typed weighted (the q-operative law).

**Headline (C020):** 1 − q = C*·r³·(1 + O(r³)), **two-sided**, with **C\* = 0.970 ± 0.06** [PALM, measured,
pre-registered protocol]. The β/gain channel is rigidity-killed (≤ 2.6×10⁻⁸ coefficient); the α carrier is
one connected ridge system (arch filament + summit-disk rim); the estimator is the exact window integral
Λ (the slice convention is retired program-wide).

## Exact
| constant | value | source |
|---|---|---|
| (U3) pair-Hessian Gram | det = (1/540) r¹⁸ | C009 |
| Lemma P limiting Gram | det = 13824; diag (2,2,6,6,6,24) | C012 |
| 9×9 free-jet Gram | det = 3,981,312 = 13824 × 288 | C013 |
| on-axis pinned laws | Var(f_t) = (2/3)τ⁶; Var(f) = τ⁸/24 | C012 |
| transverse pinned laws | Var(f_t) = σ⁴/2; Var(f_s) = 2σ² | C012 |
| E\|det H\| at f = b | 2.414589 (saddle 0.987295, extrema 1.427295) | C012 |
| ρ_saddle(b), ρ_max(b) | 0.030513, 0.044111 per area per height | C012 |
| deep-slab octave ratio | 1/8 exact | C012/C009 |
| six-pin tilt law ρ₆(0) | 0.196817 | LemmaP-general + B2-comp addendum |
| lam_Palm disintegration identity | λ = φ(y-jet01 \| 6 pins) · E[W₃1\|9]/E[W₂1\|6] | C019 (derived-and-verified) |
| **Λ window-integral closed form** | Λ(y) = φ₂(∇f(y)=0\|6)·[Φ-window(μ_t, s_t)]·E[W₃1\|9 @ v*=μ_t]/E[W₂1\|6] | **C020** (derived-and-verified: brute v-quadrature concordance 0.951; the v-integration is exact because the Hessian factor's height sensitivity is O(s_t)) |
| near-M null functional | (f(M) − f(y))/√2, conditional sd √λ_min = 4.7×10⁻⁹ at δ ≈ 0.005 | C020 (exact mp eigenstructure; the compatibility constraint governing near-M conditioning) |

## Measured — asymptotic-regime Kac–Rice instruments [PALM unless noted]
| constant | value | note |
|---|---|---|
| **C\* (sharp two-sided constant)** | **0.9702 ± 0.06** | **C020**: (1/r³)∫Λ·AO dA, unified quadrature; upper adds ledger < 1.5×10⁻³ (ratio 1.0015) |
| c_α supersede chain | 1.10 ± 0.09 (C019, slice convention) → 0.8275 (C020, Λ-exact, arch) → **0.9702 (unified, arch + rim)** | scope: the estimand changed (window integral vs mid-slice), not the data; C019's 1.10 stands as the slice-convention record and its band [0.9, 1.3] contains the unified value ✓ |
| rim addition | +0.1427 | the summit window-disk rim (δ_w ≈ 0.005): qualifying saddles, Pre = 0.92–1.00 at 7 fringe points; ridge merges with the arch at y ≈ 0.010–0.012 |
| loop-disk interior | Pre = 0.0000, both→M = 1.0000 (5 core points) | non-qualifying; C011 loop absorption realized geometrically |
| needle widths σ_t/ℓ | 0.068 (arch) / 10⁻⁴ (near-M) | C020 G-U2: λ(y;v) varies 7 orders across the window at fixed y — the slice convention's falsifier |
| **c_β (gain channel)** | **≤ 2.6×10⁻⁸ coefficient** (corridor Kac–Rice); P(G ≤ ℓ) ∈ [0, 8×10⁻⁴²] (strata) | **C020 fork branch (iii)**: rigidity-killed; exit ridge 4.6–9.7σ above b (probes at 0.15/0.2/0.3); gain support edge 0.0062 = 300ℓ untilted; dam floor ~10⁻⁶/depth; B = 0.0000 at 10 stations |
| M1b bulk gain CDF | P(G ≤ 0.01) = 0.0385; P(G ≤ 0.03) = 0.162 | strata-assembled; G-C1 FAILED-AS-WRITTEN at 3.52σ vs direct (monotone-tail convention bias, diagnosed, both records stand; small-ε ladder unaffected) |
| G-U1 two-model concordance | ratios 0.9891–1.0029 (6 arch stations) | discrete-Gram vs analytic-BF at the e^±15 density scale; the single-method flag on the α landscape lifts |
| ∫ λ_Palm dA (arch region, slice) | 6.59 | retained as the slice-convention record; window-integrated replacement: ∫Λ dA = 1.216×10⁻⁴ |
| on-arch A·O | 0.992–1.000 (A ≡ 1.0000) | C019, 8 stations |
| λ_Palm at O(1) | ≈ 0.0047 (trigger rows) | C018; death valley λ ~ e⁻²⁰⁰ (C019) |
| Palm halo trigger c₁ | 0.0643 ± 0.0008 | C018; halo carries no load post-KILL |
| two-point window intensity λ₂pt(d) | 1.83e-2 / 7.36e-3 / 3.77e-3 / 1.74e-3 at d = 0.2/0.5/1/2 | C018; feeds LB_Bonferroni |
| adjacency complement c_a | ≈ 0.019·r; Palm adjacency 1.0000 | C013 |
| B2 tail adjacency | ≈ 0.92 on \|μ_S\| ≤ r | C013, reinstated by C014-KILL |
| third-point max channel | → 0 (≤ 3e-4 at r = 0.05) | C014-KILL |
| C_inner / C_annulus / C_strip [PINNED] | 23.5 (r⁵) / 0.188 / 0.044 | **scaffolding-only as of C020**: OBL-UB-PALM discharged by the channel decomposition; these pinned zone constants no longer enter any bound; retained for the record |

## Measured — moderate-r field instruments (not asymptotic)
| constant | value | note |
|---|---|---|
| p_∞(1.2) gain density | ≈ 1.19 (r = 0.40) | **demoted (C020, OBL-LB-RESTATE)**: the (H2′) smooth-density mechanism is moderate-r phenomenology; the C011 CDF bend was the rigidity onset |
| q(r) | 0.55 (r = 0.7); ~0.89 corr. (r = 0.4) | c_eff 1.31–1.7 brackets the asymptotic 0.97 from above ✓ |
| far-zone enhancement | 2.6–3.4× at O(1)-shell | C016: fixed-shell effect |
| failure split | saddle:W₂:loop ≈ 64:26:0.3 (r = 0.7) | drifts saddle-ward as r ↓ |
| moderate-r joint constants | branch 3: transient (P-J6) | phenomenology |

## The assembled statement (supersedes the C019 paragraph)
**1 − q(r, b) = C\*·r³·(1 + O(r³)), two-sided at architecture grade, C\* = 0.970 ± 0.06 at (b, r) = (1.2, 0.05).**
Both sides are carried by the same Palm integral E[N_qual] = ∫Λ·AO dA (Lemma_UB0.md): **lower** = Bonferroni
(E[N] − pair term, O(r⁶) by LB_Bonferroni) × LB0 [Proved] × R0 (derived-architecture) × γ-LOC (architecture);
**upper** = E[N] + β-ceiling (2.6×10⁻⁸, measured two ways) + ledger (valley 3.5×10⁻⁵; far ≤ 6.2×10⁻⁴
max-station heuristic / 2.5×10⁻⁴ pooled; overlap O(r⁶)) — upper/lower coefficient ratio 1.0015. The pinned
zone-decomposition upper route (annulus/strip/far constants) is retired; OBL-UB-PALM is discharged by
replacement. Remaining to full proof: OBL-LB-ARCH (rigorous positivity), OBL-FAR-DECAY (γ-LOC
quantitative), OBL-BETA-FAR (far-zone β ceiling), and the r = 0.025 rung for the O(r³) relative term.
