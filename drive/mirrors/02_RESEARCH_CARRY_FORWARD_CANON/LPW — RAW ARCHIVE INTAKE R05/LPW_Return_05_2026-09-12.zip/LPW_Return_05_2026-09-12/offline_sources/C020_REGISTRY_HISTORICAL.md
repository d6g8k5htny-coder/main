# Registry_Reconciliation — obligations ledger and record hygiene (as of C020, 2026-07-09)

Supersedes Registry_Reconciliation.md (C019 edition); companion to Constants_Table_Canonical_C020.md,
Lemma_UB0.md, and C020_Observed_Update.json. Supersede-never-overwrite: nothing below deletes an archive
entry; every change is a scoped supersession.

## 1. Obligations ledger (complete, current)

| ID | content | status | discharge / carrier |
|---|---|---|---|
| MS-Sard / R0 | a.s. Morse–Smale for the conditioned flow | derived-architecture | MS_Shift_R0_Closure.md; residue → OBL-R0-UNIF |
| OBL-R0-UNIF | uniformity of the 18×18 nondegeneracy + constant chase | OPEN (bookkeeping grade) | carried |
| OBL-UB-PALM | re-derive upper-bound channel constants under Palm weighting | **DISCHARGED (C020)** — by *replacement*, not re-derivation: the pinned zone-bound route (annulus/strip/far constants) is retired; the two-sided constant is one Palm integral, E[N_qual] = ∫Λ·AO dA, with the β channel measured dead and the ledger within budget. The pinned constants become scaffolding-only (table note). | Lemma_UB0.md; C020_Observed_Update |
| OBL-C019-1 | second independent λ method at arch scale; E1 band [0.9, 1.3] adjudication | **DISCHARGED (C020)** — G-U1 two-covariance-model concordance (ratios 0.989–1.003, 6 stations); the unified constant 0.970 lies inside the committed band; the slice value 1.097 is superseded in scope (estimand change, G-U2-driven). | C020 gates |
| OBL-C019-2 | MID other-branch mechanism; marginal-typed polish artifact | OPEN (instrument hygiene) | carried |
| OBL-LBB-1 | two-point measurement at d ∈ {0.02, 0.05, 0.1} on the arch | OPEN | carried (not executed in C020; the O(r⁶) pair bound rests on the C018 d ≥ 0.2 values + the LB mechanism) |
| OBL-LB-ARCH | rigorous positivity of ∫Λ·AO dA | OPEN — the sole remaining lower-bound obligation; basis strengthened by C020 (Λ-exact estimator, two-model concordance, rim map) | Corridor_Mechanism_KILL §3; Lemma_UB0 §6 |
| **OBL-BETA-FAR** | rigorous ceiling for the far-zone window-edge-terminal β channel (∫_far Λ_max·B_far) | **NEW (C020)** | route: adjacency-type decay + the measured support edge (Gmin = 0.0062 = 300ℓ) |
| **OBL-LB-RESTATE** | restate Lemma LB's p_∞ mechanism as moderate-r; asymptotic lower bound carried by α alone | **NEW (C020)** | fork branch (iii) consequence |
| **OBL-RIM-REFINE** | rim quadrature densification + Pre-map refinement (~2% interpolation systematic) | **NEW (C020)** | optional escape-radius study attached |
| **OBL-CLIP-ARCH** | quantify the ≤ 2% arch systematic from the retired clip margins (re-run two arch rows margin-free) | **NEW (C020)** | error-budget hygiene |
| OBL-FAR-DECAY | quantitative off-pair decorrelation (γ-LOC formalization) | OPEN | carried; now load-bearing for Lemma_UB0's architecture step |
| κ_β (gain-channel multiplier) | — | **MOOT (C020)** under fork branch (iii): c_β ≤ 2.6×10⁻⁸; no multiplier enters the constant | C020_Observed_Update |
| File-5 B2-positivity ghost debt | — | DISCHARGED (C015) | LemmaP_Discharge_2.md |
| OBL-C017-1 / OBL-C017-2 / OBL-LB-ADJ | — | DISCHARGED / DISCHARGED / SUPERSEDED (C018–C019, unchanged) | prior registry |

## 2. FAILED-AS-WRITTEN ledger additions (C020; recorded without rescue)

- **G-C1 (continuity, 3.52σ at ε = 0.03):** the committed monotone upper-tail convention + 1σ z-binning
  bias the strata-assembled bulk CDF against the direct run. Both records stand; the small-ε ladder
  (load-bearing) has zero tail contribution and is unaffected.
- **G-U2 (window flatness):** the flatness premise itself was false (needle σ_t = 0.068ℓ at the arch,
  10⁻⁴ℓ near M). Drove the in-cycle estimator supersession (slice → Λ-exact). The gate as committed was
  mis-designed; recorded as such.
- **P-U2 (correction ledger, inner budget):** blown by the 372-coefficient alarm; resolved into (a) the
  genuine rim channel (+0.143, unified into α) and (b) the null-rigidity incident (below).

## 3. Instrument incident record (C020)

**Null-rigidity off-manifold conditioning (near-M zone).** The 9-pin Gram at δ ≈ 0.003–0.005 from M has
λ_min = 2.2×10⁻¹⁷ with null functional (f(M) − f(y))/√2; the retired 0.02ℓ interior clip margin displaced
the factor-2 height 57 null-sd off the compatible manifold, inflating E[W₃1] ×4×10⁴ and manufacturing
22σ far-field artifacts (measured; linear response 0.4σ-of-mountain per null-sd). Exposed by physical
forensics (f = 21–23 at escape positions). Repair: margin-free v* = clip(μ_t, window). All near-M records
superseded by compatible-ensemble reruns (*_v2 files); distorted records retained. Arch rows unaffected
(≤ 2% residual, budgeted, → OBL-CLIP-ARCH). Class: v2.1-lesson recurrence (near-degenerate conditioning
+ off-manifold target = silent ensemble distortion).

## 4. Reconciliation notes carried unchanged

C014 part-2 dual-account resolution (operative: KILL account (B)); C014p2 snapshot-absence flag;
C015/C016/C017 date-field corrections — all as in the C019 registry, unchanged.
