# Additive R3 clarification and exact-source bridge

**Target:** LPW-CAND-20260912 v1.0, full-file SHA-256 cf58f72eb0399c626160c143b50f674ff3bd5c449225211edd6fd378a374e1a5.  
**Status:** author-side addendum proposed in response to Kimi A1/A2; no change to reviewed bytes; no new independent endorsement claimed.

## A1. The residual need not be stationary

Use the maximum C^k norm

    ||h||_{C^k} = max_{|alpha|<=k} sup_x |partial^alpha h(x)|.

Let V_r=(U_r,J) be the ten-coordinate Gaussian vector, Gamma_r its covariance, and C_r(x)=Cov(f(x),V_r), with C_r(x) a row vector. Put

    L_r v = C_r Gamma_r^{-1} v,
    g_r = f-L_r V_r.

The Gaussian residual g_r is independent of V_r. It is generally nonstationary. No stationarity of g_r is needed below.

Set

    C4_* = sup_{r,x,|alpha|<=4} ||partial^alpha C_r(x)||_2,
    G_*  = sup_r ||Gamma_r^{-1}||_2,
    A4   = C4_* G_*.

The candidate's covariance convergence and covariance Cauchy-Schwarz argument make C4_* finite, and positive-definite endpoint continuity makes G_* finite on a sufficiently small fixed interval. Therefore, for every deterministic v,

    ||L_r v||_{C^4} <= A4 ||v||_2.

For p>=1 the triangle inequality followed by the scalar L^p triangle inequality gives

    (E ||g_r||_{C^4}^p)^(1/p)
       <= (E ||f||_{C^4}^p)^(1/p)
          + A4 (E ||V_r||_2^p)^(1/p).

This estimate uses no independence between f and V_r. The first moment term is finite by the absolute Fourier-series majorant. The second is uniformly finite since V_r is finite-dimensional Gaussian with uniformly bounded covariance.

The conditional law at every prescribed v is the continuous Gaussian regression version

    f | {V_r=v}  =law  g_r+L_r v.

For v=(u_r,j), j in K_J, the v values occupy a bounded set. At p=1,

    sup_{r,j} E[||f||_{C^4} | U_r=u_r,J=j]
       <= F4_1 + A4(V10_1+R10) < infinity,

where F4_1=(E||f||_{C^4}), V10_1=sup_r E||V_r||_2 and R10=sup_{r,j}||(u_r,j)||_2. This is the explicit nonstationary residual bound underlying B4. Conditioning is evaluated through the continuous regression kernel at every j; no arbitrary almost-everywhere version is substituted.

Consequently, choosing K>=max(1,2B4) gives the conditional Markov bound at every point of the thin jet box. The integration order remains:

    Q_r(E_r intersect {M4<=K})
      = integral_{E_r} Q_r(M4<=K | J=j) p_r(j) dj
      >= (1/2) integral_{E_r} p_r(j) dj.

One must not replace this with a fixed unconditional tail subtraction from the O(r) box mass.

## A2. M4 is the exact-order seminorm

Keep the original candidate definition:

    M4(f) = max_{|alpha|=4} sup_x |partial^alpha f(x)|.

The full norm ||f||_{C^4}, defined with |alpha|<=4, dominates M4 and is used to prove its conditional moment bound. The Taylor remainder uses only the exact-order derivatives. Thus there is no redefinition of M4 or change in the candidate constants; a full-norm upper bound is simply a valid upper bound for the seminorm.

Likewise retain M3=max(1,||f||_{C^3}) in the normalizer proof, and B3=sup_r E_{Q_r}M3^4. B3 and B4 are different quantities and must not be interchanged.

## S1. Exact source supplied, without transferring conclusions

The attached `inputs/GP-DER-118-v1.10.md` is a raw Drive download of ID 1qc6ep2S4PIoPMEWDsdDQI1dr0LOwJiK9, not an OCR reconstruction.

Whole file: 30,933 bytes; SHA-256 c1d6e559274d7e87a3fa92f44cb2534a5e277a3b5941fd40db380599ddba0564.

Frozen theorem body: 29,293 bytes; SHA-256 9b7901e112a4857e3ea59942858684f72fc09a2825b1efa859360dd8fa55f014.

Extraction: the unique lines BEGIN_FROZEN_THEOREM_BODY and END_FROZEN_THEOREM_BODY are excluded; normalize line endings to LF and retain exactly one terminal LF. The accompanying script checks both identities.

The Section 0 correspondence is:

| GP-DER-118 v1.10 | LPW |
|---|---|
| Q_{6,r}, pins at M=(-r/2,0), S=(r/2,0) | Q_r, identical pins |
| values b and b-r^3/6; both gradients zero | identical |
| W_r^{exact}=abs(det H_M det H_S) times max/saddle indicators | W_r, identical |
| Z_r^{exact}=E_{Q6,r}W_r^{exact} | Z_r, identical |
| dP_r^{MS}=W_r^{exact} dQ6,r/Z_r^{exact} | dP_r=W_r dQ_r/Z_r |
| selected-branch event A_r | NOT the same as LPW's event D_f(M_r)!=S_r |

This closes the author-side source-access task and supplies the exact object for RA's review. It does not retroactively turn RA's previous CANNOT-VERIFY-locally into a performed check. The LPW conclusion is a different event under the same base law, not a proof of P0.1.
