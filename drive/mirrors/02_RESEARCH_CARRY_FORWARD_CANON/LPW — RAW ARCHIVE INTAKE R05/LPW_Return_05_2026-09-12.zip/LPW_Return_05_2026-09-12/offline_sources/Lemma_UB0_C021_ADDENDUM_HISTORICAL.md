# Lemma UB0 — Addendum A (C021): revision of §3 after the ball-fix and the second rung

**Date:** 2026-07-09 · **Scope:** supersedes-in-scope the §3 subsection "C020 rim unification" of
Lemma_UB0.md; the §3 loop-absorption citations and the §1–§2, §4–§6 content are unchanged.
**Basis:** c020_ballfix_*.json (r = 0.05 re-measurement at ism radius 0.001), C021 AO map
(18 stations, r = 0.025), C021_Observed_Update.json.

## A.1 What changes

The C020 dichotomy — *"disk interior: pure loop saddles (both→M = 1.0000) / disk rim: qualifying"* —
is **retired as measured geometry**. The interior both→M = 1.0000 values were asserted by the flow's
isM ball (radius 0.005, scale-coincident with δ_w at r = 0.05), not measured: launches inside the ball
terminated 'M' on both branches at step one. Re-measured at ism 0.001 with the same seeds, the r = 0.05
interior points give Pre = 0.9981, 0.8103, 0.9821, 0.9995 with both→M ≤ 0.005 — the window-disk
**interior qualifies**. At r = 0.025 (measured with the scaled ball from the start) the same holds at
all 18 stations: Pre = 0.91–1.00, both→M ≤ 0.005, terminal forensics confirming genuine elder maxima
(heights 1.20–2.74 at distances 0.28–2.7).

## A.2 What the corrected picture is

The α carrier is one connected ridge system whose **entire measured support qualifies**:
qual/raw = 0.9997 (r = 0.05, ballfix-corrected) and 0.99986 (r = 0.025). A saddle anywhere on the
structure — rim, flank, or crest — has one separatrix branch into $x_M$ and one that rides the
conditioned ridge network out to a genuine elder maximum. The physical intuition that motivated the
loop-disk picture ("from height b − O(ℓ) hugging the summit, everything nearby is lower, so both
branches must curl in") fails because the *conditioned* landscape is not radially monotone: the exit
ridge system threads the summit neighborhood at window-adjacent heights, and the outward branch finds
it. The measured monotone-ascent gains along these branches are what the γ-LOC support in §4 already
recorded.

## A.3 Status of the loop absorption

**No loop population was measured at either rung.** The C011 absorption mechanism
($A_{\mathrm{loop}} \subseteq \{N_w \ge 1\}$, non-qualifying, contributing 0 to both sides of the
squeeze — citations in §3 unchanged) is retained in the lemma as the **architecture safety net**: it
guarantees that *if* loop saddles exist anywhere in the window population, they cannot enter
$N_{\mathrm{qual}}$ or the failure probability. What changes is the claim of where they live: nowhere
that carries measurable Palm mass at r ∈ {0.05, 0.025}. Obligation OBL-LOOP-LOCATE (bookkeeping grade)
records the residual question.

## A.4 Numerical consequences

- $C^*(0.05)$: 0.9702 → **0.9728** (ballfix-corrected; +0.0026, inside ±0.055; both values stand,
  supersede-in-scope of the Pre-map override).
- $C^*(0.025)$ = **0.9461 ± 0.066** with the qual weighting ≈ 1 (the Pre map is unity to
  measurement precision on the whole structure).
- The two-rung law: $1-q = C^*\,r^3\,(1+O(r^3))$, $C^* = 0.96 \pm 0.05$, two-sided per §2, with the
  β term ≤ 2.6×10⁻⁸ (r = 0.05) and support-gap-dead at 894 ℓ (r = 0.025).
- §6's falsifier list gains one resolved entry: *"a rim/arch flow whose other branch terminates below
  b at an off-image maximum"* — none in 11,200 (C020) + 28,800 (C021) + 6,400 (ballfix) pooled flows.
