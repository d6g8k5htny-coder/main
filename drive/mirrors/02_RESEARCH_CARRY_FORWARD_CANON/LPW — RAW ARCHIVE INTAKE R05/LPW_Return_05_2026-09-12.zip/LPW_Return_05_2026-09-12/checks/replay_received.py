from pathlib import Path
import subprocess,json,hashlib,shutil,sys,os,time
W=Path('/mnt/data/LPW_Return_05_work');EX=W/'extracted';R=W/'runs';R.mkdir(exist_ok=True)
packages={'constant':next(EX.glob('KIMI_LPW_CONSTANT_PACKAGE*'))/'LPW_CONSTANT','review':next(EX.glob('KIMI_LPW_REVIEW_BUNDLE*')),'qc':next(EX.glob('KIMI_QC_NUMERICAL_PACKAGE*'))/'QC_RETURN03_REVIEW'}
for key,src in packages.items():
 dst=R/key
 if not dst.exists():shutil.copytree(src,dst)
env={'PATH':os.environ['PATH'],'HOME':str(R),'LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC','PYTHONDONTWRITEBYTECODE':'1','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'}
jobs=[('constant','lpw_constant.py','out_normal.txt',160),('review','RB_R2_part1_symbolic.py','p1_normal.out',90),('review','rd_r4r5_verify.py','out_normal.json',90),('review','rc_r3_numeric.py','rc_r3_numeric_output.txt',120),('review','rb_r2_part2_spectral_v2.py','rb_v2_out_normal.txt',120),('qc','qc_return03_numeric.py','OUTPUT_NORMAL.json',160),('constant','falsify.py','falsify_normal.txt',300)]
results=[]
for pkg,script,ref,cap in jobs:
 for opt in (False,True):
  cmd=[sys.executable]+(['-O'] if opt else [])+[script]
  tag=f'{pkg}__{Path(script).stem}__'+('optimized' if opt else 'normal')
  start=time.monotonic();rec={'tag':tag,'cmd':cmd,'package':pkg,'script_sha256':hashlib.sha256((R/pkg/script).read_bytes()).hexdigest(),'timeout_seconds':cap}
  try:
   p=subprocess.run(cmd,cwd=R/pkg,env=env,capture_output=True,timeout=cap)
   (R/(tag+'.stdout')).write_bytes(p.stdout);(R/(tag+'.stderr')).write_bytes(p.stderr)
   refdata=(packages[pkg]/ref).read_bytes()
   rec.update(exit=p.returncode,stdout_bytes=len(p.stdout),stderr_bytes=len(p.stderr),stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),reference_sha256=hashlib.sha256(refdata).hexdigest(),byte_identical_to_received=p.stdout==refdata,stderr_preview=p.stderr.decode(errors='replace')[:1000])
  except subprocess.TimeoutExpired as e:
   rec.update(status='TIMEOUT',exit=None);(R/(tag+'.stdout')).write_bytes(e.stdout or b'');(R/(tag+'.stderr')).write_bytes(e.stderr or b'')
  rec['elapsed_seconds']=round(time.monotonic()-start,3);results.append(rec);(W/'REPLAY_RECEIPT.json').write_text(json.dumps(results,indent=2)+'\n')
  print(json.dumps(rec),flush=True)
print('DONE',flush=True)
