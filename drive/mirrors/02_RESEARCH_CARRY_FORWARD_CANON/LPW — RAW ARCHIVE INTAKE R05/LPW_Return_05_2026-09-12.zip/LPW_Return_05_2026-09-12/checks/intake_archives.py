from pathlib import Path,PurePosixPath
import zipfile,hashlib,json,stat,re,collections
ROOT=Path('/mnt/data/LPW_Return_05_work'); ROOT.mkdir(exist_ok=True)
rows=[]; files=[]; seen={}; total=0

def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''): h.update(b)
 return h.hexdigest()

def walk(p,ancestry,depth=0):
 global total
 sha=digest(p); record={'archive':str(p),'ancestry':ancestry,'sha256':sha,'bytes':p.stat().st_size,'depth':depth};rows.append(record)
 if depth>10: raise ValueError('DEPTH')
 with zipfile.ZipFile(p) as z:
  inf=z.infolist(); record.update(members=len(inf),uncompressed_bytes=sum(x.file_size for x in inf))
  if record['uncompressed_bytes']>400_000_000: raise ValueError('TOO_LARGE')
  names=set(); folded=set(); problems=[]
  for i in inf:
   s=i.filename; pp=PurePosixPath(s); mode=i.external_attr>>16
   if pp.is_absolute() or '..' in pp.parts or '\\' in s or any(ord(c)<32 for c in s) or re.match(r'^[A-Za-z]:',s):problems.append('PATH:'+s)
   if s in names:problems.append('DUPLICATE:'+s)
   if s.casefold() in folded and s not in names:problems.append('CASE:'+s)
   if stat.S_ISLNK(mode):problems.append('SYMLINK:'+s)
   if i.flag_bits&1:problems.append('ENCRYPTED:'+s)
   names.add(s);folded.add(s.casefold())
  record['safety_problems']=problems
  if problems: raise ValueError(str(problems))
  bad=z.testzip();record['crc']='PASS' if bad is None else bad
  if bad:raise ValueError('CRC:'+bad)
  if sha in seen:record['same_content_as']=seen[sha];return
  dest=ROOT/'extracted'/(p.stem[:65]+'__'+sha[:12]);dest.mkdir(parents=True,exist_ok=True)
  record['extracted_to']=str(dest);seen[sha]=str(dest)
  for i in inf:
   if i.is_dir():continue
   data=z.read(i);total+=len(data)
   if total>1_000_000_000:raise ValueError('TOTAL_CAP')
   out=dest/i.filename;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data)
   files.append({'archive_sha256':sha,'member':i.filename,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'local_path':str(out)})
  for i in inf:
   if not i.is_dir() and i.filename.lower().endswith('.zip'):walk(dest/i.filename,ancestry+[i.filename],depth+1)

walk(Path('/mnt/data/SepOKComputer_Project_Gap_Closure.zip'),['SepOKComputer_Project_Gap_Closure.zip'])
(ROOT/'ARCHIVE_AUDIT.json').write_text(json.dumps({'archives':rows,'archive_occurrences':len(rows),'unique_archives':len(seen),'unique_extracted_member_occurrences':len(files),'total_extracted_bytes':total},indent=2)+'\n')
(ROOT/'MEMBER_HASH_LEDGER.json').write_text(json.dumps(files,indent=2)+'\n')
print('ARCHIVES',len(rows),'UNIQUE',len(seen),'FILES',len(files),'BYTES',total)
for r in rows: print(r['bytes'],r['sha256'],r['members'],r['crc'],'/'.join(r['ancestry']))
