from pathlib import Path,PurePosixPath
import json,re,hashlib,collections
root=Path('/mnt/data/LPW_Return_05_work'); arcs=json.loads((root/'ARCHIVE_AUDIT.json').read_text())['archives'];out=[];bodies=[]
for arc in arcs:
 if 'extracted_to' not in arc:continue
 base=Path(arc['extracted_to'])
 for mf in base.rglob('*'):
  if not mf.is_file() or not mf.name.lower().endswith('.sha256'):continue
  items=[]
  for ln,line in enumerate(mf.read_text(errors='replace').splitlines(),1):
   if not line.strip() or line.startswith('#'):continue
   m=re.match(r'^([0-9a-fA-F]{64})\s+(?:(\d+)\s+)?(.+?)\s*$',line)
   if not m:items.append({'line':ln,'status':'UNPARSED','text':line[:180]});continue
   sha,n,path=m.groups();path=path.removeprefix('*')
   pp=PurePosixPath(path)
   rec={'line':ln,'path':path,'declared_sha256':sha,'declared_bytes':int(n) if n else None}
   if pp.is_absolute() or '..' in pp.parts:rec['status']='EXTERNAL_OR_UNSAFE_REFERENCE';items.append(rec);continue
   target=mf.parent/path
   if not target.is_file():rec['status']='MISSING'
   else:
    data=target.read_bytes();actual=hashlib.sha256(data).hexdigest();rec.update(actual_sha256=actual,actual_bytes=len(data));rec['status']='MATCH' if actual==sha.lower() and (n is None or int(n)==len(data)) else 'MISMATCH'
   items.append(rec)
  out.append({'manifest':str(mf),'archive':arc['sha256'],'counts':dict(collections.Counter(x['status'] for x in items)),'entries':items})
 # body markers only four current packages
 if any(s in base.name for s in ['KIMI_LPW_REVIEW_BUNDLE','KIMI_LPW_CONSTANT_PACKAGE','KIMI_QC_NUMERICAL_PACKAGE','KIMI_W8_V3_PACKAGE']):
  for p in base.rglob('*.md'):
   data=p.read_bytes(); matches=list(re.finditer(rb'(?m)^SHA-256 of (?:this|the) [^\n]*body[^\n]*',data))
   for m in matches:
    tail=data[m.start():]; found=re.search(rb'\b[0-9a-f]{64}\b',tail)
    rec={'file':str(p),'marker_offset':m.start(),'whole_bytes':len(data),'whole_sha256':hashlib.sha256(data).hexdigest(),'body_sha256':hashlib.sha256(data[:m.start()]).hexdigest()}
    if found:rec['declared_body_sha256']=found.group().decode();rec['matches']=rec['declared_body_sha256']==rec['body_sha256']
    bodies.append(rec)
(root/'MANIFEST_AUDIT.json').write_text(json.dumps(out,indent=2)+'\n');(root/'BODY_HASH_AUDIT.json').write_text(json.dumps(bodies,indent=2)+'\n')
for x in out:
 if any(s in x['manifest'].split('/extracted/')[1].split('/')[0] for s in ['KIMI_LPW','KIMI_QC','KIMI_W8']):print(x['manifest'],x['counts'])
print('BODY HASHES')
for x in bodies:print(Path(x['file']).name,x.get('matches'),x['body_sha256'])
print('other manifests',len(out))
