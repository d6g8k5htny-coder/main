#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXPECTED = [
    "ResearchFormalCoreR1.lean",
    "ResearchFormalCoreR1/Algebra.lean",
    "ResearchFormalCoreR1/Status.lean",
    "FORMALIZATION_MATRIX.json",
    "README.md",
    "lakefile.toml",
]
REQUIRED_THEOREMS = {
    "ec005_fold_gap",
    "ec008_factor_expansion",
    "ec010_generic",
    "ec010_transverse",
    "ec011_scalar_cancellation",
    "ec014_contact_power",
}
FORBIDDEN_THEOREMS = {
    "ec008_matrix_determinant",
    "ec011_adjoint_orbit_full",
    "ec012_majorant_full",
    "ec013_elder_geometry_full",
    "ec014_six_pin_determinant",
    "p01_uniform_exact_field",
    "ec019_terminal",
    "p02_exact_field_law",
    "theoremB_full_kappa",
}
FORBIDDEN_TOKENS = re.compile(r"\b(sorry|admit|axiom)\b")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    errors: list[str] = []
    for rel in EXPECTED:
        if not (ROOT / rel).is_file():
            errors.append(f"MISSING:{rel}")

    lean_text = "\n".join(
        p.read_text(encoding="utf-8")
        for p in sorted(ROOT.rglob("*.lean"))
    )
    hits = sorted(set(FORBIDDEN_TOKENS.findall(lean_text)))
    if hits:
        errors.append("FORBIDDEN_PLACEHOLDER_TOKENS:" + ",".join(hits))

    found = set(re.findall(r"\btheorem\s+([A-Za-z0-9_']+)", lean_text))
    missing = sorted(REQUIRED_THEOREMS - found)
    if missing:
        errors.append("MISSING_THEOREMS:" + ",".join(missing))
    overclaims = sorted(FORBIDDEN_THEOREMS & found)
    if overclaims:
        errors.append("FORBIDDEN_OVERCLAIM_THEOREMS:" + ",".join(overclaims))

    matrix = json.loads((ROOT / "FORMALIZATION_MATRIX.json").read_text(encoding="utf-8"))
    if matrix.get("compilation_state") != "CI-PENDING-NO-LEAN-RUNTIME":
        errors.append("COMPILATION_STATE_NOT_FAIL_CLOSED")
    if matrix.get("claims", {}).get("Theorem-B-Unconditional") != "PROVEN-HERE-STATUS-RETRACTED":
        errors.append("THEOREM_B_STATUS_NOT_RETRACTED")

    members = {}
    for rel in EXPECTED + ["static_audit.py"]:
        path = ROOT / rel
        if path.is_file():
            members[rel] = {"bytes": path.stat().st_size, "sha256": sha256(path)}

    report = {
        "schema": "research-formal-core-static-audit/1.0",
        "valid": not errors,
        "errors": errors,
        "lean_runtime_present": False,
        "compilation_attempted": False,
        "required_theorems": sorted(REQUIRED_THEOREMS),
        "found_theorems": sorted(found),
        "forbidden_placeholders_found": hits,
        "members": members,
    }
    out = ROOT / "STATIC_AUDIT_REPORT.json"
    out.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["valid"] else 1


if __name__ == "__main__":
    sys.exit(main())
