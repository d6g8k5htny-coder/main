# research-formal-core-r1

Additive source-recovery successor for GP-FOR-001.

## What this package does

- Publishes reconstructable Lean source for the narrow algebraic companions actually supported by Drive evidence.
- Encodes heavy/open claims as `ClaimRecord` metadata rather than axioms or placeholder theorems.
- Contains no `sorry`, `admit`, or `axiom` declaration.
- Separates exact identities, polynomial/scalar companions, partial definitions, logical interfaces, numerical metadata, conditional wrappers, and the retracted unconditional Theorem B status.

## What this package does not do

- It does not reproduce the missing `research-formal-core-2026-07-24.zip` bytes or its declared hash.
- It does not establish that the original Lean drafts compiled.
- It does not compile in the present runtime because no Lean/Lake executable is installed.
- It does not prove EC-008's matrix construction, EC-011's ODE theorem, EC-012's real-power majorant, EC-013's geometry, EC-014's matrix determinant, interval certificates, P0.1, EC-019, P0.2, or unconditional Theorem B.

## Required compilation gate

1. Freeze an exact Lean toolchain and Mathlib revision.
2. Run `lake build` in a clean environment.
3. Record all compiler output and source hashes.
4. Correct any statement or syntax mismatch without silently weakening a theorem.
5. Obtain an organizationally distinct source review.
