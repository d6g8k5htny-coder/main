# research-formal-core-r2

Additive source-recovery successor to GP-FOR-189 / `research-formal-core-r1`.
The Lean namespace remains `ResearchFormalCoreR1` for source compatibility.

## New in r2

- Adds `ResearchFormalCoreR1/ProbabilityCompanions.lean`.
- Encodes narrow algebraic companions for P02-LM-008:
  - exact `r²` cancellation;
  - cross-multiplied numerator/denominator transfer;
  - quotient bound after supplied Cauchy–Schwarz and normalizer premises.
- Encodes narrow algebraic companions for P02-LM-009:
  - deterministic fifth-power bad-event threshold;
  - the `(R^5)^8 = R^40` identity used with a 40th moment;
  - the final `r^4 ≤ r^3` ledger on `0 ≤ r ≤ 1`.

## What this package does

- Publishes reconstructable Lean source for narrow identities supported by Drive evidence.
- Encodes heavy/open claims as `ClaimRecord` metadata rather than axioms or placeholder theorems.
- Contains no `sorry`, `admit`, or `axiom` declaration.
- Separates theorem companions from the probability, Gaussian-process, dynamics, and governance layers they do not formalize.

## What this package does not do

- It does not reproduce the missing original GP-FOR-001 bundle or its declared hash.
- It does not establish that any source compiles: no Lean/Lake runtime or exact Mathlib lock is available here.
- It does not formalize the measure-theoretic Cauchy–Schwarz step, conditional expectations, exact determinant moments, or normalizer theorem behind P02-LM-008.
- It does not formalize Markov's inequality, all-moments quantification, changing-law uniformity, or the full super-polynomial theorem behind P02-LM-009.
- It does not prove P0.1, P0.2, or any theorem promotion claim.

## Required compilation gate

1. Freeze an exact Lean toolchain and Mathlib revision.
2. Run `lake build` in a clean environment.
3. Record all compiler output and source hashes.
4. Correct any statement or syntax mismatch without silently weakening a theorem.
5. Obtain an organizationally distinct source review.
