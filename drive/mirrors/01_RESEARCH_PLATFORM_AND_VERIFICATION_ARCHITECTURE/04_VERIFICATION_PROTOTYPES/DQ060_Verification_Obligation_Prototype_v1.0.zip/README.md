# DQ-060 Verification Obligation Prototype v1.0

This sandbox package is an executable, fail-closed prototype for machine-readable claim obligations.

## Contents

- `verification_obligation_schema.json` — declarative VO-1.0 JSON Schema.
- `verify_obligations.py` — standard-library verifier.
- `tb_g3b_verification_project.json` — live-project fixture containing the original TB-G3B split, corrected trichotomy, and dependency propagation example.
- `run_regressions.py` — mutation suite.
- `baseline_report.json` — expected rejection of the original nonexhaustive split.
- `dq060_regression_results.json` — 12/12 passing regression record.
- `SHA256SUMS.txt` — exact identities.

## Execution

```bash
python verify_obligations.py tb_g3b_verification_project.json --out report.json
python run_regressions.py
```

The baseline project intentionally contains both the rejected original certificate and accepted corrected certificate, so the whole project returns nonzero. Removing the original certificate produces an accepted corrected project.

## Enforced invariants

1. Unique claim and obligation IDs.
2. Known dependencies and acyclic DAG.
3. Effective status is bounded by the weakest dependency.
4. Requested status cannot exceed effective evidence.
5. Refutation-first gate on claims that request a nontrivial positive status.
6. Tier-2 positive obligations require both an adversarial-review PASS and a dedicated refutation PASS.
7. Finite case certificates must cover every assignment exactly once, have no dead rules, and explicitly name every allowed residual class.
8. Negative results (`REFUTED`, `AMEND_REQUIRED`, `HOLD`, `BLOCKED`) propagate fail closed.

## Scope firewall

This prototype does not alter live scientific labels, promote a theorem, accept a package root, seal a package, or constitute formal proof. It is an isolated executable control artifact. Live adoption requires a separately reviewed migration plan and rollback.
