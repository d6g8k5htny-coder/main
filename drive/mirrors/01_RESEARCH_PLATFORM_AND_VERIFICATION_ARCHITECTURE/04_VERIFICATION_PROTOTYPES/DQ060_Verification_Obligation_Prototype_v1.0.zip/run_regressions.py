#!/usr/bin/env python3
from __future__ import annotations
import copy
import json
from pathlib import Path

from verify_obligations import verify

ROOT = Path(__file__).resolve().parent
BASE = json.loads((ROOT / "tb_g3b_verification_project.json").read_text(encoding="utf-8"))


def run_case(name, mutate, expect_accept):
    project = copy.deepcopy(BASE)
    mutate(project)
    report = verify(project)
    passed = report.accepted == expect_accept
    return {
        "test": name,
        "expected_accept": expect_accept,
        "actual_accept": report.accepted,
        "passed": passed,
        "finding_codes": [f.code for f in report.findings],
        "effective_status": report.effective_status,
        "case_acceptance": {k: v["accepted"] for k, v in report.case_results.items()},
    }


def no_change(p):
    return None


def remove_original_bad_certificate(p):
    p["case_certificates"] = [c for c in p["case_certificates"] if c["certificate_id"] != "TBG3B-ORIGINAL-THREE-CASE"]


def remove_corrected_lsame_rule(p):
    cert = next(c for c in p["case_certificates"] if c["certificate_id"] == "TBG3B-CORRECTED-TRICHOTOMY")
    cert["rules"] = [r for r in cert["rules"] if r["rule_id"] != "self-same"]


def add_ambiguous_rule(p):
    cert = next(c for c in p["case_certificates"] if c["certificate_id"] == "TBG3B-CORRECTED-TRICHOTOMY")
    cert["rules"].append({"rule_id": "ambiguous", "when": {"prior_merge": False}, "class": "COUNTED:OTHER"})


def add_dead_rule(p):
    cert = next(c for c in p["case_certificates"] if c["certificate_id"] == "TBG3B-CORRECTED-TRICHOTOMY")
    cert["rules"].append({"rule_id": "dead", "when": {"prior_merge": "IMPOSSIBLE"}, "class": "COUNTED:DEAD"})


def add_cycle(p):
    p["claims"][0]["dependencies"] = ["LS-DER-025-SYNTHESIS"]


def add_unknown_dependency(p):
    p["claims"][3]["dependencies"] = ["DOES-NOT-EXIST"]


def duplicate_claim(p):
    p["claims"].append(copy.deepcopy(p["claims"][0]))


def remove_refutation(p):
    c = next(c for c in p["claims"] if c["claim_id"] == "LS-DER-035-CORRECTED-TRICHOTOMY")
    for ob in c["obligations"]:
        ob["artifacts"] = [a for a in ob["artifacts"] if a["role"] != "REFUTATION"]


def overclaim_dependency(p):
    c = next(c for c in p["claims"] if c["claim_id"] == "LS-DER-025-SYNTHESIS")
    c["requested_status"] = "ADVERSARIALLY_SURVIVED"


def remove_tier_artifact(p):
    c = next(c for c in p["claims"] if c["claim_id"] == "LS-DER-023-TBG3A")
    c["obligations"][0]["artifacts"] = [a for a in c["obligations"][0]["artifacts"] if a["role"] != "ADVERSARIAL_REVIEW"]


def mark_upstream_repaired(p):
    c = next(c for c in p["claims"] if c["claim_id"] == "LS-DER-024-DETERMINISTIC-INCLUSION")
    c["local_status"] = "ADVERSARIALLY_SURVIVED"
    c["requested_status"] = "ADVERSARIALLY_SURVIVED"
    c["obligations"][0]["status"] = "ADVERSARIALLY_SURVIVED"
    c["obligations"][0]["max_feasible_tier"] = "TIER2_ADVERSARIAL"
    c["obligations"][0]["artifacts"] = [
        {"artifact_id": "REPAIR-REVIEW", "role": "ADVERSARIAL_REVIEW", "result": "PASS"},
        {"artifact_id": "REPAIR-REF", "role": "REFUTATION", "result": "PASS"}
    ]
    s = next(c for c in p["claims"] if c["claim_id"] == "LS-DER-025-SYNTHESIS")
    s["requested_status"] = "ADVERSARIALLY_SURVIVED"


TESTS = [
    ("baseline_rejects_original_gap", no_change, False),
    ("corrected_certificate_only_accepts", remove_original_bad_certificate, True),
    ("mutation_missing_lsame_rejected", lambda p: (remove_original_bad_certificate(p), remove_corrected_lsame_rule(p)), False),
    ("mutation_ambiguous_rules_rejected", lambda p: (remove_original_bad_certificate(p), add_ambiguous_rule(p)), False),
    ("mutation_dead_rule_rejected", lambda p: (remove_original_bad_certificate(p), add_dead_rule(p)), False),
    ("dependency_cycle_rejected", lambda p: (remove_original_bad_certificate(p), add_cycle(p)), False),
    ("unknown_dependency_rejected", lambda p: (remove_original_bad_certificate(p), add_unknown_dependency(p)), False),
    ("duplicate_claim_rejected", lambda p: (remove_original_bad_certificate(p), duplicate_claim(p)), False),
    ("missing_refutation_rejected", lambda p: (remove_original_bad_certificate(p), remove_refutation(p)), False),
    ("downstream_overclaim_rejected", lambda p: (remove_original_bad_certificate(p), overclaim_dependency(p)), False),
    ("missing_max_tier_artifact_rejected", lambda p: (remove_original_bad_certificate(p), remove_tier_artifact(p)), False),
    ("upstream_repair_allows_propagated_upgrade", lambda p: (remove_original_bad_certificate(p), mark_upstream_repaired(p)), True)
]

results = [run_case(*t) for t in TESTS]
summary = {
    "suite": "DQ060-REGRESSION-1.0",
    "passed": sum(r["passed"] for r in results),
    "total": len(results),
    "all_passed": all(r["passed"] for r in results),
    "results": results,
}
(ROOT / "dq060_regression_results.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps(summary, indent=2, sort_keys=True))
raise SystemExit(0 if summary["all_passed"] else 1)
