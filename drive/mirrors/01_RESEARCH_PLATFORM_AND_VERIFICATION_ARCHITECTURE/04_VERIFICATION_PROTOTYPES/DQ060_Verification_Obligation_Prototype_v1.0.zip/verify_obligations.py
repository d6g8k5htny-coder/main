#!/usr/bin/env python3
"""Fail-closed verifier for Verification Obligation projects (VO-1.0).

Standard-library only. It validates the executable subset of the VO schema,
checks dependency DAGs and weakest-link status propagation, enforces
refutation-first gating, and exhaustively evaluates finite case certificates.
"""
from __future__ import annotations

import argparse
import itertools
import json
import sys
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Iterable

SCHEMA_VERSION = "VO-1.0"
NEGATIVE_STATUSES = {"REFUTED", "AMEND_REQUIRED", "BLOCKED", "HOLD"}
PASS_RESULTS = {"PASS"}
TIER_ROLE = {
    "TIER0_FINITE": {"FINITE_CHECK"},
    "TIER0_ALGEBRA": {"ALGEBRA_CHECK"},
    "TIER1_FORMAL": {"FORMAL_PROOF"},
    "TIER2_ADVERSARIAL": {"ADVERSARIAL_REVIEW", "REFUTATION"},
}


class VerificationError(Exception):
    pass


@dataclass
class Finding:
    code: str
    severity: str
    subject: str
    message: str


@dataclass
class Report:
    project_id: str
    accepted: bool
    findings: list[Finding]
    effective_status: dict[str, str]
    case_results: dict[str, dict[str, Any]]


def require(condition: bool, message: str) -> None:
    if not condition:
        raise VerificationError(message)


def load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def validate_shape(project: dict[str, Any]) -> None:
    require(isinstance(project, dict), "project must be an object")
    require(project.get("schema_version") == SCHEMA_VERSION, "unsupported schema_version")
    for key in ("project_id", "status_order", "claims", "case_certificates"):
        require(key in project, f"missing required key: {key}")
    require(isinstance(project["project_id"], str) and project["project_id"], "project_id must be nonempty")
    statuses = project["status_order"]
    require(isinstance(statuses, list) and len(statuses) >= 5, "status_order must contain at least five statuses")
    require(len(statuses) == len(set(statuses)), "status_order contains duplicates")
    require(isinstance(project["claims"], list), "claims must be an array")
    require(isinstance(project["case_certificates"], list), "case_certificates must be an array")

    seen_claims: set[str] = set()
    seen_obligations: set[str] = set()
    for claim in project["claims"]:
        require(isinstance(claim, dict), "claim must be an object")
        for key in ("claim_id", "statement", "dependencies", "local_status", "requested_status", "obligations", "refutation_required"):
            require(key in claim, f"claim missing {key}")
        cid = claim["claim_id"]
        require(isinstance(cid, str) and cid, "claim_id must be nonempty")
        require(cid not in seen_claims, f"duplicate claim_id: {cid}")
        seen_claims.add(cid)
        require(claim["local_status"] in statuses, f"unknown local_status on {cid}")
        require(claim["requested_status"] in statuses, f"unknown requested_status on {cid}")
        require(isinstance(claim["dependencies"], list), f"dependencies must be array on {cid}")
        require(len(claim["dependencies"]) == len(set(claim["dependencies"])), f"duplicate dependency on {cid}")
        require(isinstance(claim["obligations"], list), f"obligations must be array on {cid}")
        for ob in claim["obligations"]:
            require(isinstance(ob, dict), f"obligation must be object on {cid}")
            for key in ("obligation_id", "statement", "max_feasible_tier", "status", "artifacts"):
                require(key in ob, f"obligation missing {key} on {cid}")
            oid = ob["obligation_id"]
            require(oid not in seen_obligations, f"duplicate obligation_id: {oid}")
            seen_obligations.add(oid)
            require(ob["max_feasible_tier"] in TIER_ROLE, f"unknown tier on {oid}")
            require(ob["status"] in statuses, f"unknown obligation status on {oid}")
            require(isinstance(ob["artifacts"], list), f"artifacts must be array on {oid}")
            for art in ob["artifacts"]:
                require(isinstance(art, dict), f"artifact must be object on {oid}")
                require(art.get("role") in set().union(*TIER_ROLE.values(), {"SOURCE_IDENTITY"}), f"unknown artifact role on {oid}")
                require(art.get("result") in {"PASS", "FAIL", "COUNTEREXAMPLE", "BLOCKED", "NOT_RUN"}, f"unknown artifact result on {oid}")

    for cert in project["case_certificates"]:
        require(isinstance(cert, dict), "case certificate must be object")
        for key in ("certificate_id", "variables", "rules", "allowed_residual_classes"):
            require(key in cert, f"case certificate missing {key}")
        require(isinstance(cert["variables"], dict) and cert["variables"], "variables must be nonempty object")
        for name, values in cert["variables"].items():
            require(isinstance(name, str) and name, "variable name must be nonempty")
            require(isinstance(values, list) and values, f"domain must be nonempty for {name}")
            require(len(values) == len({json.dumps(v, sort_keys=True) for v in values}), f"duplicate values in {name}")
        require(isinstance(cert["rules"], list), "rules must be array")
        require(isinstance(cert["allowed_residual_classes"], list), "allowed_residual_classes must be array")


def topo_order(claims: dict[str, dict[str, Any]]) -> list[str]:
    state: dict[str, int] = {cid: 0 for cid in claims}
    out: list[str] = []

    def visit(cid: str, stack: list[str]) -> None:
        if state[cid] == 1:
            cycle = " -> ".join(stack + [cid])
            raise VerificationError(f"dependency cycle: {cycle}")
        if state[cid] == 2:
            return
        state[cid] = 1
        for dep in claims[cid]["dependencies"]:
            if dep not in claims:
                raise VerificationError(f"unknown dependency {dep} referenced by {cid}")
            visit(dep, stack + [cid])
        state[cid] = 2
        out.append(cid)

    for cid in claims:
        visit(cid, [])
    return out


def status_min(statuses: Iterable[str], rank: dict[str, int]) -> str:
    return min(statuses, key=lambda s: rank[s])


def compute_effective_status(project: dict[str, Any]) -> dict[str, str]:
    claims = {c["claim_id"]: c for c in project["claims"]}
    order = topo_order(claims)
    rank = {s: i for i, s in enumerate(project["status_order"])}
    effective: dict[str, str] = {}
    for cid in order:
        c = claims[cid]
        deps = [effective[d] for d in c["dependencies"]]
        candidates = [c["local_status"], *deps]
        negatives = [s for s in candidates if s in NEGATIVE_STATUSES]
        effective[cid] = status_min(negatives, rank) if negatives else status_min(candidates, rank)
    return effective


def artifact_passes_tier(ob: dict[str, Any]) -> bool:
    tier = ob["max_feasible_tier"]
    artifacts = ob["artifacts"]
    if tier == "TIER2_ADVERSARIAL":
        has_review = any(a["role"] == "ADVERSARIAL_REVIEW" and a["result"] == "PASS" for a in artifacts)
        has_refutation = any(a["role"] == "REFUTATION" and a["result"] == "PASS" for a in artifacts)
        return has_review and has_refutation
    required_roles = TIER_ROLE[tier]
    return any(a["role"] in required_roles and a["result"] in PASS_RESULTS for a in artifacts)


def has_refutation_attempt(claim: dict[str, Any]) -> bool:
    return any(
        a["role"] == "REFUTATION" and a["result"] in {"PASS", "COUNTEREXAMPLE", "FAIL"}
        for ob in claim["obligations"] for a in ob["artifacts"]
    )


def match_rule(assignment: dict[str, Any], when: dict[str, Any]) -> bool:
    for key, expected in when.items():
        if key not in assignment:
            return False
        if expected != "*" and assignment[key] != expected:
            return False
    return True


def evaluate_case_certificate(cert: dict[str, Any]) -> dict[str, Any]:
    names = list(cert["variables"].keys())
    domains = [cert["variables"][n] for n in names]
    uncovered: list[dict[str, Any]] = []
    ambiguous: list[dict[str, Any]] = []
    forbidden_residuals: list[dict[str, Any]] = []
    class_counts: dict[str, int] = {}
    rule_counts: dict[str, int] = {r["rule_id"]: 0 for r in cert["rules"]}

    for values in itertools.product(*domains):
        assignment = dict(zip(names, values))
        matches = [r for r in cert["rules"] if match_rule(assignment, r["when"])]
        if not matches:
            uncovered.append(assignment)
            continue
        if len(matches) > 1:
            ambiguous.append({"assignment": assignment, "rules": [r["rule_id"] for r in matches]})
            continue
        rule = matches[0]
        cls = rule["class"]
        rule_counts[rule["rule_id"]] += 1
        class_counts[cls] = class_counts.get(cls, 0) + 1
        if cls.startswith("RESIDUAL:") and cls not in cert["allowed_residual_classes"]:
            forbidden_residuals.append({"assignment": assignment, "class": cls})

    dead_rules = [rid for rid, count in rule_counts.items() if count == 0]
    accepted = not uncovered and not ambiguous and not forbidden_residuals and not dead_rules
    return {
        "accepted": accepted,
        "total_assignments": int(__import__("math").prod(len(d) for d in domains)),
        "class_counts": class_counts,
        "uncovered": uncovered,
        "ambiguous": ambiguous,
        "forbidden_residuals": forbidden_residuals,
        "dead_rules": dead_rules,
    }


def verify(project: dict[str, Any]) -> Report:
    findings: list[Finding] = []
    case_results: dict[str, dict[str, Any]] = {}
    effective: dict[str, str] = {}
    try:
        validate_shape(project)
        effective = compute_effective_status(project)
    except VerificationError as exc:
        findings.append(Finding("STRUCTURE", "ERROR", project.get("project_id", "UNKNOWN"), str(exc)))
        return Report(project.get("project_id", "UNKNOWN"), False, findings, effective, case_results)

    rank = {s: i for i, s in enumerate(project["status_order"])}
    claims = {c["claim_id"]: c for c in project["claims"]}

    for cert in project["case_certificates"]:
        result = evaluate_case_certificate(cert)
        case_results[cert["certificate_id"]] = result
        if not result["accepted"]:
            findings.append(Finding("CASE_CERT", "ERROR", cert["certificate_id"], json.dumps({k: v for k, v in result.items() if k != "accepted"}, sort_keys=True)))

    for cid, claim in claims.items():
        for ob in claim["obligations"]:
            if ob["status"] not in NEGATIVE_STATUSES and not artifact_passes_tier(ob):
                findings.append(Finding("UNDISCHARGED_MAX_TIER", "ERROR", ob["obligation_id"], f"No PASS artifact at declared max feasible tier {ob['max_feasible_tier']}"))
        if claim["refutation_required"] and rank[claim["requested_status"]] >= rank.get("SELF_CONSISTENT", 0) and not has_refutation_attempt(claim):
            findings.append(Finding("MISSING_REFUTATION", "ERROR", cid, "Requested status requires a dedicated refutation artifact"))
        if rank[claim["requested_status"]] > rank[effective[cid]]:
            findings.append(Finding("STATUS_EXCEEDS_EVIDENCE", "ERROR", cid, f"requested={claim['requested_status']} effective={effective[cid]}"))

    return Report(project["project_id"], not findings, findings, effective, case_results)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    try:
        project = load_json(args.project)
        report = verify(project)
    except (OSError, json.JSONDecodeError) as exc:
        print(json.dumps({"accepted": False, "error": str(exc)}, indent=2))
        return 2
    payload = asdict(report)
    text = json.dumps(payload, indent=2, sort_keys=True)
    if args.out:
        args.out.write_text(text + "\n", encoding="utf-8")
    print(text)
    return 0 if report.accepted else 1


if __name__ == "__main__":
    sys.exit(main())
